
//--TRIMMABLE-BOUNDARY-START(14732)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm, $uUnI, $cCKL) {
    "use strict";
    let _;
    let $Lgofwa;
    let $OPfrmi;
    let $HDEKva;
    let $hPuQCk;
    let $eYqmKa;
    let $vbFVlb;
    let $QumODb;
    let $bYgVVh;
    let $DYDEri;
    let $FPxssf;
    let $iEOIHj;
    let $KqMhIa;
    let $XomiYa;
    let $iUkDLf;
    let $tYssal;
    let $OnhBLe;
    let $yhbMmk;
    let $TUoeci;
    let $jaAEGe;
    let $lqLhfb;
    let $rHYKSc;
    let $PUbAXd;
    let $croyLb;
    let $KapxBc;
    let $zfLTcb;
    let $UsyCXb;
    let $HdJtCi;
    let $OurGGd;
    let $rJISka;
    let $RufmCk;
    let $dhsjVe;
    let $ovqsPc;
    let $HxFggb;
    let $NCtkFi;
    let $kNrTya;
    let $BlhNUb;
    let $vsWhuk;
    let $rZPGsk;
    let $NtDHgl;
    let $sTyxjb;
    let $bSLtVj;
    let $Klreph;
    let $ZBiRMf;
    let $vBkNrk;
    let $zRIpkh;
    let $dPzEvd;
    let $wObKSi;
    let $CcgxZd;
    let $AFXKEh;
    let $oKWWTi;
    let $jsGPtc;
    let $krIHjc;
    let $JVrjPc;
    let $XgYJYf;
    let $DcoxAb;
    let $GXNEtj;
    let $foXCfc;
    let $CwWCXd;
    let $XyUyWe;
    let $aSzAfl;
    let $Qhlpic;
    let $YReoRi;
    let $lIJKok;
    let $uhQoxg;
    let $FMJMDb;
    let $DXmUIk;
    let $yMUzDb;
    let $AbdQfb;
    let $aULFni;
    let $unuveb;
    let $uhCErg;
    let $DeKfIk;
    let $HqEMAc;
    let $RiMxej;
    let $bibhvj;
    let $kixYQj;
    let $mYtLgi;
    let $NpJosf;
    let $Texhij;
    let $PsGaug;
    let $sOAKrc;
    let $AZLajg;
    let $qMhpTk;
    let $Bqjnth;
    let $MbdbRe;
    let $qdNawb;
    let $kiLYag;
    let $RefjBa;
    let $Rblkmj;
    let $bTTTpj;
    let $dKRfFf;
    let $JieLga;
    let $QVGLBd;
    let $VkbUwg;
    let $AZziBa;
    let $BslRAc;
    let $xLijJc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.PowerHouse.Common", 
    {
  "h": 14732,
  "f": "LivingThing.Core.IOT.PowerHouse.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.PowerHouse.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.PowerHouse.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuUG93ZXJIb3VzZS5Db21tb24uUG93ZXJIb3VzZVNtYXJ0RGV2aWNlIjogew0KICAgICAgIk5hbWUiOiAiUG93ZXIgSG91c2UiLA0KICAgICAgIlNlcnZpY2VMaW5rIjogIlBvd2VySG91c2UvQXBwIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJNb25pdG9yIHBvd2VyIGdlbmVyYXRvciBob3VzZSBwZXJmb3JtYW5jZSIsDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1lbmdpbmUtb3V0bGluZSIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiNGOTQzMjEiDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(276876)
        $asm.$cls(`$mXnX.LCIPCH.IPowerHouseHubServer`, ($self) => class IPowerHouseHubServer
        {
            static $h = 276876;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 276876
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICH.IIOTDeviceHubServer, $.$kVHt.LCFCH.IComponentHubServer, $.$kVHt.LCFCH.IPluginHubServer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Hubs.IPowerHouseHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Hubs${separator}IPowerHouseHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(276876)
        
        

        //--TRIMMABLE-BOUNDARY-START(3946892)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsCustomAttributesProvider`, ($self) => class PowerHouseDeviceGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298914188)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298914188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298914188)
            
            static $h = 3946892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298914188),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3946892,
      "h": 4298914188,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298914188)
  ],
  "h": 3946892
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3946892)
        
        

        //--TRIMMABLE-BOUNDARY-START(5257612)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesCustomAttributesProvider`, ($self) => class PowerHouseDeviceScopeStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300224908)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300224908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTDeviceScopeStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300224908)
            
            static $h = 5257612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300224908),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5257612,
      "h": 4300224908,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300224908)
  ],
  "h": 5257612
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceScopeStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5257612)
        
        

        //--TRIMMABLE-BOUNDARY-START(2439564)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseServiceFeatureTypeCustomAttributesProvider`, ($self) => class PowerHouseServiceFeatureTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297406860)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297406860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297406860)
            
            static $h = 2439564;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297406860),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2439564,
      "h": 4297406860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297406860)
  ],
  "h": 2439564
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceFeatureTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceFeatureTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2439564)
        
        

        //--TRIMMABLE-BOUNDARY-START(539020)
        $asm.$cls(`$mXnX.LCIPCM.PowerHosuseReceivedStatusModelCustomAttributesProvider`, ($self) => class PowerHosuseReceivedStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295506316)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295506316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295506316)
            
            static $h = 539020;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295506316),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 539020,
      "h": 4295506316,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295506316)
  ],
  "h": 539020
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHosuseReceivedStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(539020)
        
        

        //--TRIMMABLE-BOUNDARY-START(1849740)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceSendDataModelCustomAttributesProvider`, ($self) => class PowerHouseDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296817036)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296817036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296817036)
            
            static $h = 1849740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296817036),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1849740,
      "h": 4296817036,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296817036)
  ],
  "h": 1849740
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1849740)
        
        

        //--TRIMMABLE-BOUNDARY-START(1325452)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class PowerHouseDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296292748)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296292748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296292748)
            
            static $h = 1325452;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296292748),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1325452,
      "h": 4296292748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296292748)
  ],
  "h": 1325452
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1325452)
        
        

        //--TRIMMABLE-BOUNDARY-START(2111884)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceStatusModelCustomAttributesProvider`, ($self) => class PowerHouseDeviceStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297079180)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297079180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICM.IOTDeviceStatusModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297079180)
            
            static $h = 2111884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297079180),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2111884,
      "h": 4297079180,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297079180)
  ],
  "h": 2111884
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2111884)
        
        

        //--TRIMMABLE-BOUNDARY-START(4995468)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseServiceSettingsCustomAttributesProvider`, ($self) => class PowerHouseServiceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299962764)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299962764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299962764)
            
            static $h = 4995468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299962764),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4995468,
      "h": 4299962764,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299962764)
  ],
  "h": 4995468
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseServiceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4995468)
        
        

        //--TRIMMABLE-BOUNDARY-START(2832780)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseServiceTierTypeCustomAttributesProvider`, ($self) => class PowerHouseServiceTierTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297800076)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297800076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297800076)
            
            static $h = 2832780;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297800076),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2832780,
      "h": 4297800076,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297800076)
  ],
  "h": 2832780
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceTierTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2832780)
        
        

        //--TRIMMABLE-BOUNDARY-START(5519756)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceStatesCustomAttributesProvider`, ($self) => class PowerHouseDeviceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300487052)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300487052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTDeviceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300487052)
            
            static $h = 5519756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300487052),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5519756,
      "h": 4300487052,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300487052)
  ],
  "h": 5519756
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5519756)
        
        

        //--TRIMMABLE-BOUNDARY-START(4471180)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsCustomAttributesProvider`, ($self) => class PowerHouseDeviceScopeSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299438476)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299438476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDeviceScopeSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299438476)
            
            static $h = 4471180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299438476),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4471180,
      "h": 4299438476,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299438476)
  ],
  "h": 4471180
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceScopeSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4471180)
        
        

        //--TRIMMABLE-BOUNDARY-START(211340)
        $asm.$cls(`$mXnX.LCIPC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295178636)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295178636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295178636)
            
            static $h = 211340;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295178636),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 211340,
      "h": 4295178636,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295178636)
  ],
  "h": 211340
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(211340)
        
        

        //--TRIMMABLE-BOUNDARY-START(4209036)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class PowerHouseDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299176332)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299176332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299176332)
            
            static $h = 4209036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299176332),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4209036,
      "h": 4299176332,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299176332)
  ],
  "h": 4209036
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4209036)
        
        

        //--TRIMMABLE-BOUNDARY-START(145804)
        $asm.$cls(`$mXnX.LCIPC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295113100)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295113100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseDeviceCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceCommandModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceScopeModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceSendDataModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseServiceFeatureType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseServiceFeatureTypeCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseServiceFeatureTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseServiceModelCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCM.PowerHouseServiceTierType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCM.PowerHouseServiceTierTypeCustomAttributesProvider, $.$mXnX.LCIPCM.PowerHouseServiceTierTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsCustomAttributesProvider, $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsCustomAttributesProvider, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsCustomAttributesProvider, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsCustomAttributesProvider, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$1.PowerHouseDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$1.PowerHouseDeviceSettingsCustomAttributesProvider, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$1.PowerHouseServiceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$1.PowerHouseServiceSettingsCustomAttributesProvider, $.$mXnX.LCIPCS$1.PowerHouseServiceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesCustomAttributesProvider, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$2.PowerHouseDeviceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$2.PowerHouseDeviceStatesCustomAttributesProvider, $.$mXnX.LCIPCS$2.PowerHouseDeviceStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mXnX.LCIPCS$2.PowerHouseServiceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mXnX.LCIPCS$2.PowerHouseServiceStatesCustomAttributesProvider, $.$mXnX.LCIPCS$2.PowerHouseServiceStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295113100)
            
            static $h = 145804;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295113100),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 145804,
      "h": 4295113100,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295113100)
  ],
  "h": 145804
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(145804)
        
        

        //--TRIMMABLE-BOUNDARY-START(670092)
        $asm.$cls(`$mXnX.LCIPCM.PowerHosuseReceivedStatusModelTypeDescriptorBuilder`, ($self) => class PowerHosuseReceivedStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590604684)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590604684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TUoeci ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":670092,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590604684)
            
            //--TRIMMABLE-BOUNDARY-START(4295637388)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295637388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295637388)
            
            //--TRIMMABLE-BOUNDARY-START(4295637388)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295637388)
            
            static $h = 670092;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590604684),
    {
      "r": 65537,
      "n": "Register",
      "d": 670092,
      "h": 8590604684,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590604684)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295637388),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 670092,
      "h": 4295637388,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295637388)
  ],
  "h": 670092
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHosuseReceivedStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(670092)
        
        

        //--TRIMMABLE-BOUNDARY-START(932236)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceCommandModelTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590866828)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590866828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHouseDeviceCommandModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHouseDeviceCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eYqmKa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":932236,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHouseDeviceCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590866828)
            
            //--TRIMMABLE-BOUNDARY-START(4295899532)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295899532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295899532)
            
            //--TRIMMABLE-BOUNDARY-START(4295899532)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295899532)
            
            static $h = 932236;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590866828),
    {
      "r": 65537,
      "n": "Register",
      "d": 932236,
      "h": 8590866828,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590866828)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295899532),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 932236,
      "h": 4295899532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295899532)
  ],
  "h": 932236
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(932236)
        
        

        //--TRIMMABLE-BOUNDARY-START(2570636)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseServiceModelCustomAttributesProvider`, ($self) => class PowerHouseServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297537932)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297537932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297537932)
            
            static $h = 2570636;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297537932),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2570636,
      "h": 4297537932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297537932)
  ],
  "h": 2570636
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2570636)
        
        

        //--TRIMMABLE-BOUNDARY-START(3815820)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsTypeDescriptorBuilder`, ($self) => class PowerHouseDashboardGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593750412)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593750412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Lgofwa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3815820,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593750412)
            
            //--TRIMMABLE-BOUNDARY-START(4298783116)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298783116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298783116)
            
            //--TRIMMABLE-BOUNDARY-START(4298783116)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298783116)
            
            static $h = 3815820;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593750412),
    {
      "r": 65537,
      "n": "Register",
      "d": 3815820,
      "h": 8593750412,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593750412)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298783116),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3815820,
      "h": 4298783116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298783116)
  ],
  "h": 3815820
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDashboardGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3815820)
        
        

        //--TRIMMABLE-BOUNDARY-START(5781900)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseServiceStatesCustomAttributesProvider`, ($self) => class PowerHouseServiceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300749196)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300749196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300749196)
            
            static $h = 5781900;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300749196),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5781900,
      "h": 4300749196,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300749196)
  ],
  "h": 5781900
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseServiceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5781900)
        
        

        //--TRIMMABLE-BOUNDARY-START(4864396)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceSettingsTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594798988)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594798988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$1.PowerHouseDeviceSettingsTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$1.PowerHouseDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PUbAXd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4864396,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$1.PowerHouseDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594798988)
            
            //--TRIMMABLE-BOUNDARY-START(4299831692)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299831692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299831692)
            
            //--TRIMMABLE-BOUNDARY-START(4299831692)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299831692)
            
            static $h = 4864396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594798988),
    {
      "r": 65537,
      "n": "Register",
      "d": 4864396,
      "h": 8594798988,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594798988)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299831692),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4864396,
      "h": 4299831692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299831692)
  ],
  "h": 4864396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4864396)
        
        

        //--TRIMMABLE-BOUNDARY-START(3684748)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsCustomAttributesProvider`, ($self) => class PowerHouseDashboardGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298652044)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298652044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298652044)
            
            static $h = 3684748;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298652044),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3684748,
      "h": 4298652044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298652044)
  ],
  "h": 3684748
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDashboardGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3684748)
        
        

        //--TRIMMABLE-BOUNDARY-START(1587596)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceScopeModelCustomAttributesProvider`, ($self) => class PowerHouseDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296554892)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296554892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296554892)
            
            static $h = 1587596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296554892),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1587596,
      "h": 4296554892,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296554892)
  ],
  "h": 1587596
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1587596)
        
        

        //--TRIMMABLE-BOUNDARY-START(4733324)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceSettingsCustomAttributesProvider`, ($self) => class PowerHouseDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299700620)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299700620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299700620)
            
            static $h = 4733324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299700620),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4733324,
      "h": 4299700620,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299700620)
  ],
  "h": 4733324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4733324)
        
        

        //--TRIMMABLE-BOUNDARY-START(1980812)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591915404)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591915404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lqLhfb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1980812,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591915404)
            
            //--TRIMMABLE-BOUNDARY-START(4296948108)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296948108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296948108)
            
            //--TRIMMABLE-BOUNDARY-START(4296948108)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296948108)
            
            static $h = 1980812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591915404),
    {
      "r": 65537,
      "n": "Register",
      "d": 1980812,
      "h": 8591915404,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591915404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296948108),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1980812,
      "h": 4296948108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296948108)
  ],
  "h": 1980812
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1980812)
        
        

        //--TRIMMABLE-BOUNDARY-START(407948)
        $asm.$cls(`$mXnX.LCIPC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295375244)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295375244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $QumODb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $bYgVVh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $DYDEri ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.IServiceRemoteService$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $FPxssf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $iEOIHj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $KqMhIa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $XomiYa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $iUkDLf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $tYssal ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $OnhBLe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking().$ctor$3(impl);
                }, $yhbMmk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":407948,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295375244)
            
            static $h = 407948;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295375244),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 407948,
      "h": 4295375244,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295375244)
  ],
  "h": 407948
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(407948)
        
        

        //--TRIMMABLE-BOUNDARY-START(5912972)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseServiceStatesTypeDescriptorBuilder`, ($self) => class PowerHouseServiceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595847564)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595847564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$2.PowerHouseServiceStatesTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$2.PowerHouseServiceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HDEKva ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5912972,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$2.PowerHouseServiceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595847564)
            
            //--TRIMMABLE-BOUNDARY-START(4300880268)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300880268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300880268)
            
            //--TRIMMABLE-BOUNDARY-START(4300880268)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300880268)
            
            static $h = 5912972;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595847564),
    {
      "r": 65537,
      "n": "Register",
      "d": 5912972,
      "h": 8595847564,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595847564)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300880268),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5912972,
      "h": 4300880268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300880268)
  ],
  "h": 5912972
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseServiceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5912972)
        
        

        //--TRIMMABLE-BOUNDARY-START(2701708)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseServiceModelTypeDescriptorBuilder`, ($self) => class PowerHouseServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592636300)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592636300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHouseServiceModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHouseServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KapxBc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2701708,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHouseServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592636300)
            
            //--TRIMMABLE-BOUNDARY-START(4297669004)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297669004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297669004)
            
            //--TRIMMABLE-BOUNDARY-START(4297669004)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297669004)
            
            static $h = 2701708;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592636300),
    {
      "r": 65537,
      "n": "Register",
      "d": 2701708,
      "h": 8592636300,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592636300)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297669004),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2701708,
      "h": 4297669004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297669004)
  ],
  "h": 2701708
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2701708)
        
        

        //--TRIMMABLE-BOUNDARY-START(801164)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceCommandModelCustomAttributesProvider`, ($self) => class PowerHouseDeviceCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295768460)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295768460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICM.IOTDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295768460)
            
            static $h = 801164;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295768460),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 801164,
      "h": 4295768460,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295768460)
  ],
  "h": 801164
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(801164)
        
        

        //--TRIMMABLE-BOUNDARY-START(4340108)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594274700)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594274700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UsyCXb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4340108,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594274700)
            
            //--TRIMMABLE-BOUNDARY-START(4299307404)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299307404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299307404)
            
            //--TRIMMABLE-BOUNDARY-START(4299307404)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299307404)
            
            static $h = 4340108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594274700),
    {
      "r": 65537,
      "n": "Register",
      "d": 4340108,
      "h": 8594274700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594274700)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299307404),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4340108,
      "h": 4299307404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299307404)
  ],
  "h": 4340108
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4340108)
        
        

        //--TRIMMABLE-BOUNDARY-START(2308492)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592243084)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592243084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $AFXKEh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2308492,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592243084)
            
            //--TRIMMABLE-BOUNDARY-START(4297275788)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297275788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297275788)
            
            //--TRIMMABLE-BOUNDARY-START(4297275788)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297275788)
            
            static $h = 2308492;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592243084),
    {
      "r": 65537,
      "n": "Register",
      "d": 2308492,
      "h": 8592243084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592243084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297275788),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2308492,
      "h": 4297275788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297275788)
  ],
  "h": 2308492
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2308492)
        
        

        //--TRIMMABLE-BOUNDARY-START(1194380)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591128972)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591128972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vBkNrk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1194380,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHouseDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591128972)
            
            //--TRIMMABLE-BOUNDARY-START(4296161676)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296161676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296161676)
            
            //--TRIMMABLE-BOUNDARY-START(4296161676)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296161676)
            
            static $h = 1194380;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591128972),
    {
      "r": 65537,
      "n": "Register",
      "d": 1194380,
      "h": 8591128972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591128972)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296161676),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1194380,
      "h": 4296161676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296161676)
  ],
  "h": 1194380
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1194380)
        
        

        //--TRIMMABLE-BOUNDARY-START(1063308)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceModelCustomAttributesProvider`, ($self) => class PowerHouseDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296030604)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296030604)
            
            //--TRIMMABLE-BOUNDARY-START(8590997900)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590997900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$mXnX.LCIPCM.PowerHouseDeviceModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("FuelTankId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((1), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("GridMeterId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((1), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("GeneratorMeterId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((1), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$mXnX.LCIPCM.PowerHouseDeviceModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $RufmCk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1063308,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $dhsjVe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1063308,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590997900)
            
            static $h = 1063308;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590997900),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1063308,
      "h": 8590997900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590997900)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296030604),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1063308,
      "h": 4296030604,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296030604)
  ],
  "h": 1063308
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1063308)
        
        

        //--TRIMMABLE-BOUNDARY-START(5388684)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceScopeStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595323276)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595323276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OurGGd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5388684,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595323276)
            
            //--TRIMMABLE-BOUNDARY-START(4300355980)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300355980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300355980)
            
            //--TRIMMABLE-BOUNDARY-START(4300355980)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300355980)
            
            static $h = 5388684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595323276),
    {
      "r": 65537,
      "n": "Register",
      "d": 5388684,
      "h": 8595323276,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595323276)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300355980),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5388684,
      "h": 4300355980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300355980)
  ],
  "h": 5388684
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceScopeStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5388684)
        
        

        //--TRIMMABLE-BOUNDARY-START(4602252)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceScopeSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594536844)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594536844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ovqsPc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4602252,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594536844)
            
            //--TRIMMABLE-BOUNDARY-START(4299569548)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299569548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299569548)
            
            //--TRIMMABLE-BOUNDARY-START(4299569548)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299569548)
            
            static $h = 4602252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594536844),
    {
      "r": 65537,
      "n": "Register",
      "d": 4602252,
      "h": 8594536844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594536844)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299569548),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4602252,
      "h": 4299569548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299569548)
  ],
  "h": 4602252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceScopeSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4602252)
        
        

        //--TRIMMABLE-BOUNDARY-START(5978508)
        $asm.$cls(`$mXnX.LCIPC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4300945804)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300945804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mXnX.LCIPCM.PowerHouseDeviceCommandModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCM.PowerHouseDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCM.PowerHouseServiceModelTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$1.PowerHouseDeviceSettingsTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$1.PowerHouseServiceSettingsTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$2.PowerHouseDeviceStatesTypeDescriptorBuilder.Register();
                $.$mXnX.LCIPCS$2.PowerHouseServiceStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4300945804)
            
            static $h = 5978508;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300945804),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 5978508,
      "h": 4300945804,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4300945804)
  ],
  "h": 5978508
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5978508)
        
        

        //--TRIMMABLE-BOUNDARY-START(1456524)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591391116)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591391116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rZPGsk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1456524,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591391116)
            
            //--TRIMMABLE-BOUNDARY-START(4296423820)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296423820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296423820)
            
            //--TRIMMABLE-BOUNDARY-START(4296423820)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296423820)
            
            static $h = 1456524;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591391116),
    {
      "r": 65537,
      "n": "Register",
      "d": 1456524,
      "h": 8591391116,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591391116)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296423820),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1456524,
      "h": 4296423820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296423820)
  ],
  "h": 1456524
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1456524)
        
        

        //--TRIMMABLE-BOUNDARY-START(4077964)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594012556)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594012556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sTyxjb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4077964,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594012556)
            
            //--TRIMMABLE-BOUNDARY-START(4299045260)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299045260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299045260)
            
            //--TRIMMABLE-BOUNDARY-START(4299045260)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299045260)
            
            static $h = 4077964;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594012556),
    {
      "r": 65537,
      "n": "Register",
      "d": 4077964,
      "h": 8594012556,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594012556)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299045260),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4077964,
      "h": 4299045260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299045260)
  ],
  "h": 4077964
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4077964)
        
        

        //--TRIMMABLE-BOUNDARY-START(5126540)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseServiceSettingsTypeDescriptorBuilder`, ($self) => class PowerHouseServiceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595061132)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595061132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$1.PowerHouseServiceSettingsTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$1.PowerHouseServiceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Klreph ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5126540,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$1.PowerHouseServiceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595061132)
            
            //--TRIMMABLE-BOUNDARY-START(4300093836)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300093836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300093836)
            
            //--TRIMMABLE-BOUNDARY-START(4300093836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300093836)
            
            static $h = 5126540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595061132),
    {
      "r": 65537,
      "n": "Register",
      "d": 5126540,
      "h": 8595061132,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595061132)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300093836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5126540,
      "h": 4300093836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300093836)
  ],
  "h": 5126540
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseServiceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5126540)
        
        

        //--TRIMMABLE-BOUNDARY-START(2177420)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension`, ($self) => class PowerHouseDeviceStatusModelExtension
        {
            //--TRIMMABLE-BOUNDARY-START(21477013900)
            static /*IEnumerable<TankDataClassificationModel> */ GetTanks(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477013900);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.ToList($.$cCKL.LCITCM.TankDataClassificationModel, $.$sl.SL.Enumerable.Where($.$cCKL.LCITCM.TankDataClassificationModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$cCKL.LCITCM.TankDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$cCKL.LCITCM.TankDataClassificationModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.Tank;
                    }, $Qhlpic ??= {"r":1605809,"p":[{"n":"s","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t !== null;
                    }, $YReoRi ??= {"r":262145,"p":[{"n":"t","p":1605809}],"n":"","d":2177420,"h":0,"f":17825794})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477013900)
            
            //--TRIMMABLE-BOUNDARY-START(73016621452)
            static /*IEnumerable<EnergyMeterDeviceDataClassificationModel> */ GetUtilities(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016621452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.ToList($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Where($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.Utility;
                    }, $lIJKok ??= {"r":1206180,"p":[{"n":"s","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t !== null;
                    }, $uhQoxg ??= {"r":262145,"p":[{"n":"t","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016621452)
            
            //--TRIMMABLE-BOUNDARY-START(4297144716)
            static /*IEnumerable<EnergyMeterDeviceDataClassificationModel> */ GetGenerators(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297144716);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.ToList($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Where($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.Generator;
                    }, $FMJMDb ??= {"r":1206180,"p":[{"n":"s","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t !== null;
                    }, $DXmUIk ??= {"r":262145,"p":[{"n":"t","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297144716)
            
            //--TRIMMABLE-BOUNDARY-START(68721654156)
            static /*TimeSpan */ GetTotalUtilityRuntime(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721654156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.TimeSpan().$ctor$6(0, 0, $.$sl.SL.Enumerable.Sum$17($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Int32))().$ctor(this,  (/*u*/ u) =>
                    {
                        return (u.Utility?.Runtime ?? null) ?? 0;
                    }, $yMUzDb ??= {"r":655361,"p":[{"n":"u","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721654156)
            
            //--TRIMMABLE-BOUNDARY-START(51541784972)
            static /*TimeSpan */ GetTotalGeneratorRuntime(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541784972);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.TimeSpan().$ctor$6(0, 0, $.$sl.SL.Enumerable.Sum$17($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Int32))().$ctor(this,  (/*u*/ u) =>
                    {
                        return (u.Generator?.Runtime ?? null) ?? 0;
                    }, $AbdQfb ??= {"r":655361,"p":[{"n":"u","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541784972)
            
            //--TRIMMABLE-BOUNDARY-START(60131719564)
            static /*TimeSpan */ GetTotalUpTime(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131719564);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.TimeSpan.op_Addition($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityRuntime(statuses), $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorRuntime(statuses));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131719564)
            
            //--TRIMMABLE-BOUNDARY-START(25771981196)
            static /*TimeSpan */ GetTotalDownTime(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses, /*DateTime*/ start, /*DateTime*/ end)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771981196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.TimeSpan.op_Subtraction(($.$$.S.DateTime.op_Subtraction$1(end, start)), $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUpTime(statuses));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771981196)
            
            //--TRIMMABLE-BOUNDARY-START(55836752268)
            static /*IEnumerable<(DateTime, int)> */ GetTotalRunTimeByDate(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836752268);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Select$1($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Int32), $.$sl.SL.Enumerable.OrderBy$1($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.DateTime, $.$sl.SL.Enumerable.GroupBy$7($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime, $.$sl.SL.Enumerable.Concat($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Utility;
                    }, $aULFni ??= {"r":1206180,"p":[{"n":"c","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})), $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Generator;
                    }, $unuveb ??= {"r":1206180,"p":[{"n":"c","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime))().$ctor(this,  (/*g*/ g) =>
                    {
                        return g.StartDate;
                    }, $uhCErg ??= {"r":65994753,"p":[{"n":"g","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.DateTime))().$ctor(this,  (/**/ d) =>
                    {
                        return d.SL$IGrouping$$$$Key;
                    }, $DeKfIk ??= {"r":65994753,"p":[{"n":"d","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Int32)))().$ctor(this,  (/**/ g) =>
                    {
                        return new ($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Int32))().$ctor$3(g.SL$IGrouping$$$$Key, $.$sl.SL.Enumerable.Sum$17($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, g, new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.Int32))().$ctor(this,  (/*gg*/ gg) =>
                        {
                            return gg.Runtime;
                        }, $HqEMAc ??= {"r":655361,"p":[{"n":"gg","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})));
                    }, $RiMxej ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Int32).$h,"p":[{"n":"g","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836752268)
            
            //--TRIMMABLE-BOUNDARY-START(64426686860)
            static /*double */ GetTotalUtilityEnergy(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426686860);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Sum$16($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/**/ u) =>
                    {
                        return (u.Utility?.TotalEnergy ?? null) ?? 0;
                    }, $bibhvj ??= {"r":1179649,"p":[{"n":"u","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426686860)
            
            //--TRIMMABLE-BOUNDARY-START(47246817676)
            static /*double */ GetTotalGeneratorEnergy(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246817676);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Sum$16($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/*u*/ u) =>
                    {
                        return (u.Generator?.TotalEnergy ?? null) ?? 0;
                    }, $kixYQj ??= {"r":1179649,"p":[{"n":"u","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246817676)
            
            //--TRIMMABLE-BOUNDARY-START(30066948492)
            static /*double */ GetTotalEnergy(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066948492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityEnergy(statuses) + $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorEnergy(statuses);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066948492)
            
            //--TRIMMABLE-BOUNDARY-START(34361915788)
            static /*IEnumerable<(DateTime, double)> */ GetTotalEnergyByDate(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361915788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Select$1($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Double), $.$sl.SL.Enumerable.OrderBy$1($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.DateTime, $.$sl.SL.Enumerable.GroupBy$7($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime, $.$sl.SL.Enumerable.Concat($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Utility;
                    }, $mYtLgi ??= {"r":1206180,"p":[{"n":"c","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})), $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*u*/ u) =>
                    {
                        return u.Generator;
                    }, $NpJosf ??= {"r":1206180,"p":[{"n":"u","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime))().$ctor(this,  (/*g*/ g) =>
                    {
                        return g.StartDate;
                    }, $Texhij ??= {"r":65994753,"p":[{"n":"g","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.DateTime))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.SL$IGrouping$$$$Key;
                    }, $PsGaug ??= {"r":65994753,"p":[{"n":"d","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Double)))().$ctor(this,  (/*g*/ g) =>
                    {
                        return new ($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Double))().$ctor$3(g.SL$IGrouping$$$$Key, $.$sl.SL.Enumerable.Sum$16($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, g, new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.Double))().$ctor(this,  (/*gg*/ gg) =>
                        {
                            return gg.TotalEnergy;
                        }, $sOAKrc ??= {"r":1179649,"p":[{"n":"gg","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})));
                    }, $AZLajg ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Double).$h,"p":[{"n":"g","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361915788)
            
            //--TRIMMABLE-BOUNDARY-START(38656883084)
            static /*double */ GetTotalFuelInflow(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656883084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Sum$16($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                    {
                        return (t.Tank?.DeliveryQuantity ?? null) ?? 0;
                    }, $qMhpTk ??= {"r":1179649,"p":[{"n":"t","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656883084)
            
            //--TRIMMABLE-BOUNDARY-START(42951850380)
            static /*double */ GetTotalFuelOutflow(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951850380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Sum$16($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                    {
                        return (t.Tank?.UsageQuantity ?? null) ?? 0;
                    }, $Bqjnth ??= {"r":1179649,"p":[{"n":"t","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951850380)
            
            //--TRIMMABLE-BOUNDARY-START(12887079308)
            static /*EnergyMeterDeviceDataClassificationModel */ GetSum(/*IEnumerable<EnergyMeterDeviceDataClassificationModel>*/ summaries)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887079308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*EnergyMeterDeviceDataClassificationModel*/ let sum = new $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel().$ctor$2();
                let $en1 = summaries.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let s = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (s === null)
                        {
                            continue;
                        }
                        sum.RedEnergy += s.RedEnergy;
                        sum.BlueEnergy += s.BlueEnergy;
                        sum.YellowEnergy += s.YellowEnergy;
                        sum.Runtime += s.Runtime;
                    }
                }
                return sum;
            }
            //--TRIMMABLE-BOUNDARY-END(12887079308)
            
            //--TRIMMABLE-BOUNDARY-START(8592112012)
            static /*Dictionary<DateTime, (EnergyMeterDeviceDataClassificationModel Utility, EnergyMeterDeviceDataClassificationModel Generator, EnergyMeterDeviceDataClassificationModel Sum)> */ GetGroupByDate(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592112012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.ToDictionary$5($.$$.S.DateTime, $.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$sl.SL.Enumerable.Distinct$1($.$$.S.DateTime, $.$sl.SL.Enumerable.OrderBy$1($.$$.S.DateTime, $.$$.S.DateTime, $.$sl.SL.Enumerable.Select$1($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime, $.$sl.SL.Enumerable.Concat($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Utility;
                    }, $MbdbRe ??= {"r":1206180,"p":[{"n":"c","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})), $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Generator;
                    }, $qdNawb ??= {"r":1206180,"p":[{"n":"c","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.StartDate;
                    }, $kiLYag ??= {"r":65994753,"p":[{"n":"c","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.DateTime, $.$$.S.DateTime))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d;
                    }, $RefjBa ??= {"r":65994753,"p":[{"n":"d","p":65994753}],"n":"","d":2177420,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$$.S.DateTime, $.$$.S.DateTime))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c;
                    }, $Rblkmj ??= {"r":65994753,"p":[{"n":"c","p":65994753}],"n":"","d":2177420,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))().$ctor(this,  (/*c*/ c) =>
                    {
                        /*var*/ let u = $.$sl.SL.Enumerable.SingleOrDefault$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Boolean))().$ctor(this,  (/*u*/ u) =>
                        {
                            return $.$$.S.DateTime.op_Equality(u.Utility.StartDate, c);
                        }, $bTTTpj ??= {"r":262145,"p":[{"n":"u","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}));
                        /*var*/ let g = $.$sl.SL.Enumerable.SingleOrDefault$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Boolean))().$ctor(this,  (/*u*/ u) =>
                        {
                            return $.$$.S.DateTime.op_Equality(u.Generator.StartDate, c);
                        }, $dKRfFf ??= {"r":262145,"p":[{"n":"u","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}));
                        return new ($.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor$3(u.Utility, g.Generator, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetSum($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), [u.Utility, g.Generator], null, null)));
                    }, $JieLga ??= {"r":$.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h,"p":[{"n":"c","p":65994753}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592112012)
            
            //--TRIMMABLE-BOUNDARY-START(17182046604)
            static /*IEnumerable<(DateTime Date, EnergyMeterDeviceDataClassificationModel Summary)> */ GetSumByDate(/*this IEnumerable<PowerHouseDeviceStatusModel>*/ statuses)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182046604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Select$1($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$sl.SL.Enumerable.OrderBy$1($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.DateTime, $.$sl.SL.Enumerable.GroupBy$7($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime, $.$sl.SL.Enumerable.Concat($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Utility;
                    }, $QVGLBd ??= {"r":1206180,"p":[{"n":"c","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794})), $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Generator;
                    }, $VkbUwg ??= {"r":1206180,"p":[{"n":"c","p":2046348}],"n":"","d":2177420,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.DateTime))().$ctor(this,  (/*g*/ g) =>
                    {
                        return g.StartDate;
                    }, $AZziBa ??= {"r":65994753,"p":[{"n":"g","p":1206180}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.DateTime))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.SL$IGrouping$$$$Key;
                    }, $BslRAc ??= {"r":65994753,"p":[{"n":"d","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":2177420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))().$ctor(this,  (/*g*/ g) =>
                    {
                        return new ($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor$3(g.SL$IGrouping$$$$Key, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetSum(g));
                    }, $xLijJc ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h,"p":[{"n":"g","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":2177420,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182046604)
            
            static $h = 2177420;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477013900),
    {
      "r": $.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTanks",
      "d": 2177420,
      "h": 21477013900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477013900),
//--TRIMMABLE-BOUNDARY-START(73016621452),
    {
      "r": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetUtilities",
      "d": 2177420,
      "h": 73016621452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016621452),
//--TRIMMABLE-BOUNDARY-START(4297144716),
    {
      "r": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetGenerators",
      "d": 2177420,
      "h": 4297144716,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297144716),
//--TRIMMABLE-BOUNDARY-START(68721654156),
    {
      "r": 186646529,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalUtilityRuntime",
      "d": 2177420,
      "h": 68721654156,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68721654156),
//--TRIMMABLE-BOUNDARY-START(51541784972),
    {
      "r": 186646529,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalGeneratorRuntime",
      "d": 2177420,
      "h": 51541784972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541784972),
//--TRIMMABLE-BOUNDARY-START(60131719564),
    {
      "r": 186646529,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalUpTime",
      "d": 2177420,
      "h": 60131719564,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131719564),
//--TRIMMABLE-BOUNDARY-START(25771981196),
    {
      "r": 186646529,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        },
        {
          "n": "start",
          "p": 65994753
        },
        {
          "n": "end",
          "p": 65994753
        }
      ],
      "n": "GetTotalDownTime",
      "d": 2177420,
      "h": 25771981196,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771981196),
//--TRIMMABLE-BOUNDARY-START(55836752268),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Int32)).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalRunTimeByDate",
      "d": 2177420,
      "h": 55836752268,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836752268),
//--TRIMMABLE-BOUNDARY-START(64426686860),
    {
      "r": 1179649,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalUtilityEnergy",
      "d": 2177420,
      "h": 64426686860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426686860),
//--TRIMMABLE-BOUNDARY-START(47246817676),
    {
      "r": 1179649,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalGeneratorEnergy",
      "d": 2177420,
      "h": 47246817676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246817676),
//--TRIMMABLE-BOUNDARY-START(30066948492),
    {
      "r": 1179649,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalEnergy",
      "d": 2177420,
      "h": 30066948492,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066948492),
//--TRIMMABLE-BOUNDARY-START(34361915788),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Double)).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalEnergyByDate",
      "d": 2177420,
      "h": 34361915788,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361915788),
//--TRIMMABLE-BOUNDARY-START(38656883084),
    {
      "r": 1179649,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalFuelInflow",
      "d": 2177420,
      "h": 38656883084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656883084),
//--TRIMMABLE-BOUNDARY-START(42951850380),
    {
      "r": 1179649,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetTotalFuelOutflow",
      "d": 2177420,
      "h": 42951850380,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951850380),
//--TRIMMABLE-BOUNDARY-START(12887079308),
    {
      "r": 1206180,
      "p": [
        {
          "n": "summaries",
          "p": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h
        }
      ],
      "n": "GetSum",
      "d": 2177420,
      "h": 12887079308,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12887079308),
//--TRIMMABLE-BOUNDARY-START(8592112012),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetGroupByDate",
      "d": 2177420,
      "h": 8592112012,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592112012),
//--TRIMMABLE-BOUNDARY-START(17182046604),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": "GetSumByDate",
      "d": 2177420,
      "h": 17182046604,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182046604)
  ],
  "h": 2177420
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModelExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceStatusModelExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2177420)
        
        

        //--TRIMMABLE-BOUNDARY-START(1718668)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceScopeModelTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591653260)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591653260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCM.PowerHouseDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCM.PowerHouseDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $foXCfc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1718668,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCM.PowerHouseDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591653260)
            
            //--TRIMMABLE-BOUNDARY-START(4296685964)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296685964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296685964)
            
            //--TRIMMABLE-BOUNDARY-START(4296685964)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296685964)
            
            static $h = 1718668;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591653260),
    {
      "r": 65537,
      "n": "Register",
      "d": 1718668,
      "h": 8591653260,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591653260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296685964),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1718668,
      "h": 4296685964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296685964)
  ],
  "h": 1718668
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1718668)
        
        

        //--TRIMMABLE-BOUNDARY-START(5650828)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceStatesTypeDescriptorBuilder`, ($self) => class PowerHouseDeviceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595585420)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595585420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mXnX.LCIPCS$2.PowerHouseDeviceStatesTypeDescriptor()
                        const $t1 = $.$mXnX.LCIPCS$2.PowerHouseDeviceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XyUyWe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5650828,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mXnX.LCIPCS$2.PowerHouseDeviceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595585420)
            
            //--TRIMMABLE-BOUNDARY-START(4300618124)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300618124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300618124)
            
            //--TRIMMABLE-BOUNDARY-START(4300618124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300618124)
            
            static $h = 5650828;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595585420),
    {
      "r": 65537,
      "n": "Register",
      "d": 5650828,
      "h": 8595585420,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595585420)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300618124),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5650828,
      "h": 4300618124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300618124)
  ],
  "h": 5650828
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5650828)
        
        

        //--TRIMMABLE-BOUNDARY-START(80268)
        $asm.$cls(`$mXnX.LCIPC.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179949452)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17179949452)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295047564)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295047564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295047564)
            
            //--TRIMMABLE-BOUNDARY-START(4295047564)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295047564)
            
            static $h = 80268;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179949452),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884982156,
        "f": 50331649
      },
      "n": "Paths",
      "d": 80268,
      "h": 17179949452,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179949452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295047564),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 80268,
      "h": 4295047564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295047564)
  ],
  "h": 80268
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(80268)
        
        

        //--TRIMMABLE-BOUNDARY-START(3357068)
        $asm.$cls(`$mXnX.LCIPC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593291660)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593291660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$mXnX.LCIPC.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mXnX.LCIPC.PowerHouseDashboardScopeFactory, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceScopeFactory))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mXnX.LCIPC.PowerHouseDashboardScopeFactory, x);
                }, $NCtkFi ??= {"r":28611985,"p":[{"n":"x","p":327718}],"n":"","d":3357068,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), $.$mXnX.LCIPC.PowerHouseDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType), $.$mXnX.LCIPC.PowerHouseDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mXnX.LCIPC.PowerHouseDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mXnX.LCIPC.PowerHouseDeviceFamily, x);
                }, $kNrTya ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3357068,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mXnX.LCIPC.PowerHouseDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $BlhNUb ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3357068,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mXnX.LCIPC.PowerHouseDeviceFamily, x);
                }, $vsWhuk ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3357068,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel), $.$XBGm.LCICPB.BinaryPacketProtocol$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolDecoder$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolEncoder$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolCommands$$($.$mXnX.LCIPC.PowerHouseSmartDevice), services);
                $.$mXnX.LCIPC.MockingFactoryExtension.AddGeneratedMockedServices(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593291660)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mXnX.LCIPC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298324364)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298324364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298324364)
            
            //--TRIMMABLE-BOUNDARY-START(4298324364)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298324364)
            
            static $h = 3357068;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593291660),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3357068,
      "h": 8593291660,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593291660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298324364),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3357068,
      "h": 4298324364,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298324364)
  ],
  "h": 3357068
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3357068)
        
        

        //--TRIMMABLE-BOUNDARY-START(473484)
        $asm.$cls(`$mXnX.LCIPCM.PowerHosuseReceivedStatusModel`, ($self) => class PowerHosuseReceivedStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295440780)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295440780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295440780)
            
            //--TRIMMABLE-BOUNDARY-START(4295440780)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295440780)
            
            static $h = 473484;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295440780),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 473484,
      "h": 4295440780,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295440780)
  ],
  "h": 473484
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHosuseReceivedStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(473484)
        
        

        //--TRIMMABLE-BOUNDARY-START(2374028)
        $asm.$str(`$mXnX.LCIPCM.PowerHouseServiceFeatureType`, ($self) => class PowerHouseServiceFeatureType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2374028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297341324)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297341324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297341324)
            
            //--TRIMMABLE-BOUNDARY-START(4297341324)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297341324)
            
            static $h = 2374028;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592308620),
    {
      "t": 2374028,
      "n": "None",
      "d": 2374028,
      "h": 8592308620,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592308620)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297341324),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2374028,
      "h": 4297341324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297341324)
  ],
  "h": 2374028
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceFeatureType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceFeatureType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2374028)
        
        

        //--TRIMMABLE-BOUNDARY-START(2767244)
        $asm.$str(`$mXnX.LCIPCM.PowerHouseServiceTierType`, ($self) => class PowerHouseServiceTierType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2767244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297734540)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297734540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297734540)
            
            //--TRIMMABLE-BOUNDARY-START(4297734540)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297734540)
            
            static $h = 2767244;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592701836),
    {
      "t": 2767244,
      "n": "None",
      "d": 2767244,
      "h": 8592701836,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592701836)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297734540),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2767244,
      "h": 4297734540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297734540)
  ],
  "h": 2767244
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceTierType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2767244)
        
        

        //--TRIMMABLE-BOUNDARY-START(1784204)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceSendDataModel`, ($self) => class PowerHouseDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296751500)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296751500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296751500)
            
            //--TRIMMABLE-BOUNDARY-START(4296751500)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296751500)
            
            static $h = 1784204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296751500),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1784204,
      "h": 4296751500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296751500)
  ],
  "h": 1784204
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1784204)
        
        

        //--TRIMMABLE-BOUNDARY-START(604556)
        $asm.$cls(`$mXnX.LCIPCM.PowerHosuseReceivedStatusModelTypeDescriptor`, ($self) => class PowerHosuseReceivedStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295571852)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295571852);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel, this, factory);
                    }, $jaAEGe ??= {"r":65537,"n":"","d":604556,"h":0,"f":17825794}), 0, "PowerHosuseReceivedStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseDeviceReceivedDataModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModelTypeDescriptorBuilder.g.cs", "PowerHosuseReceivedStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295571852)
            
            //--TRIMMABLE-BOUNDARY-START(12885506444)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885506444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885506444)
            
            //--TRIMMABLE-BOUNDARY-START(17180473740)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180473740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180473740)
            
            //--TRIMMABLE-BOUNDARY-START(8590539148)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590539148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590539148)
            
            static $h = 604556;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885506444),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 604556,
      "h": 12885506444,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885506444),
//--TRIMMABLE-BOUNDARY-START(17180473740),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 473484,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 604556,
      "h": 17180473740,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180473740),
//--TRIMMABLE-BOUNDARY-START(8590539148),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 473484,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 604556,
      "h": 8590539148,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590539148)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295571852),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 604556,
      "h": 4295571852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295571852)
  ],
  "h": 604556
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHosuseReceivedStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(604556)
        
        

        //--TRIMMABLE-BOUNDARY-START(3881356)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings`, ($self) => class PowerHouseDeviceGlobalSettings extends $.$XBGm.LCICS$2.IOTDeviceGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298848652)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298848652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298848652)
            
            //--TRIMMABLE-BOUNDARY-START(4298848652)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4298848652)
            
            static $h = 3881356;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDeviceGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298848652),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3881356,
      "h": 4298848652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298848652)
  ],
  "h": 3881356
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3881356)
        
        

        //--TRIMMABLE-BOUNDARY-START(3619212)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings`, ($self) => class PowerHouseDashboardGlobalSettings extends $.$XBGm.LCICS$2.IOTDashboardGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298586508)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298586508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298586508)
            
            //--TRIMMABLE-BOUNDARY-START(4298586508)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4298586508)
            
            static $h = 3619212;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDashboardGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298586508),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3619212,
      "h": 4298586508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298586508)
  ],
  "h": 3619212
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDashboardGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3619212)
        
        

        //--TRIMMABLE-BOUNDARY-START(5454220)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceStates`, ($self) => class PowerHouseDeviceStates extends $.$XBGm.LCICS$3.IOTDeviceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4300421516)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300421516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300421516)
            
            //--TRIMMABLE-BOUNDARY-START(4300421516)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4300421516)
            
            static $h = 5454220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTDeviceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300421516),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5454220,
      "h": 4300421516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300421516)
  ],
  "h": 5454220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5454220)
        
        

        //--TRIMMABLE-BOUNDARY-START(5192076)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates`, ($self) => class PowerHouseDeviceScopeStates extends $.$XBGm.LCICS$3.IOTDeviceScopeStates
        {
            //--TRIMMABLE-BOUNDARY-START(4300159372)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300159372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300159372)
            
            //--TRIMMABLE-BOUNDARY-START(4300159372)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4300159372)
            
            static $h = 5192076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTDeviceScopeStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300159372),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5192076,
      "h": 4300159372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300159372)
  ],
  "h": 5192076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceScopeStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5192076)
        
        

        //--TRIMMABLE-BOUNDARY-START(4405644)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings`, ($self) => class PowerHouseDeviceScopeSettings extends $.$XBGm.LCICS$2.IOTDeviceScopeSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299372940)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299372940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299372940)
            
            //--TRIMMABLE-BOUNDARY-START(4299372940)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299372940)
            
            static $h = 4405644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDeviceScopeSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299372940),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4405644,
      "h": 4299372940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299372940)
  ],
  "h": 4405644
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICS$2.IIOTDeviceScopeSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceScopeSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4405644)
        
        

        //--TRIMMABLE-BOUNDARY-START(735628)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceCommandModel`, ($self) => class PowerHouseDeviceCommandModel extends $.$XBGm.LCICM.IOTDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295702924)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295702924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295702924)
            
            //--TRIMMABLE-BOUNDARY-START(4295702924)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295702924)
            
            static $h = 735628;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295702924),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 735628,
      "h": 4295702924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295702924)
  ],
  "h": 735628
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(735628)
        
        

        //--TRIMMABLE-BOUNDARY-START(2046348)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceStatusModel`, ($self) => class PowerHouseDeviceStatusModel extends $.$XBGm.LCICM.IOTDeviceStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(81606424972)
            /*EnergyMeterDeviceDataClassificationModel?*/ Utility = null;
            //--TRIMMABLE-BOUNDARY-END(81606424972)
            
            //--TRIMMABLE-BOUNDARY-START(21476882828)
            /*EnergyMeterDeviceDataClassificationModel?*/ Generator = null;
            //--TRIMMABLE-BOUNDARY-END(21476882828)
            
            //--TRIMMABLE-BOUNDARY-START(77311457676)
            /*TankDataClassificationModel?*/ Tank = null;
            //--TRIMMABLE-BOUNDARY-END(77311457676)
            
            //--TRIMMABLE-BOUNDARY-START(17181915532)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181915532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181915532)
            
            //--TRIMMABLE-BOUNDARY-START(17181915532)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17181915532)
            
            static $h = 2046348;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81606424972),
    {
      "p": 1206180,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246686604,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016490380,
        "f": 83886081
      },
      "n": "Utility",
      "d": 2046348,
      "h": 81606424972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606424972),
//--TRIMMABLE-BOUNDARY-START(21476882828),
    {
      "p": 1206180,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066817420,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836621196,
        "f": 83886081
      },
      "n": "Generator",
      "d": 2046348,
      "h": 21476882828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476882828),
//--TRIMMABLE-BOUNDARY-START(77311457676),
    {
      "p": 1605809,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656752012,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426555788,
        "f": 83886081
      },
      "n": "Tank",
      "d": 2046348,
      "h": 77311457676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311457676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181915532),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2046348,
      "h": 17181915532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181915532)
  ],
  "h": 2046348
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2046348)
        
        

        //--TRIMMABLE-BOUNDARY-START(5716364)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseServiceStates`, ($self) => class PowerHouseServiceStates extends $.$XBGm.LCICS$3.IOTServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4300683660)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300683660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300683660)
            
            //--TRIMMABLE-BOUNDARY-START(4300683660)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4300683660)
            
            static $h = 5716364;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300683660),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5716364,
      "h": 4300683660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300683660)
  ],
  "h": 5716364
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseServiceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5716364)
        
        

        //--TRIMMABLE-BOUNDARY-START(4929932)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseServiceSettings`, ($self) => class PowerHouseServiceSettings extends $.$XBGm.LCICS$2.IOTServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299897228)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299897228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299897228)
            
            //--TRIMMABLE-BOUNDARY-START(4299897228)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4299897228)
            
            static $h = 4929932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299897228),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4929932,
      "h": 4299897228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299897228)
  ],
  "h": 4929932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseServiceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4929932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1915276)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceSendDataModelTypeDescriptor`, ($self) => class PowerHouseDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296882572)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296882572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, this, factory);
                    }, $rHYKSc ??= {"r":65537,"n":"","d":1915276,"h":0,"f":17825794}), 0, "PowerHouseDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseDeviceSendDataModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModelTypeDescriptorBuilder.g.cs", "PowerHouseDeviceSendDataModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296882572)
            
            //--TRIMMABLE-BOUNDARY-START(12886817164)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886817164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886817164)
            
            //--TRIMMABLE-BOUNDARY-START(17181784460)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181784460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181784460)
            
            //--TRIMMABLE-BOUNDARY-START(8591849868)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591849868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591849868)
            
            static $h = 1915276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886817164),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1915276,
      "h": 12886817164,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886817164),
//--TRIMMABLE-BOUNDARY-START(17181784460),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1784204,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1915276,
      "h": 17181784460,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181784460),
//--TRIMMABLE-BOUNDARY-START(8591849868),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1784204,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1915276,
      "h": 8591849868,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591849868)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296882572),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1915276,
      "h": 4296882572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296882572)
  ],
  "h": 1915276
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1915276)
        
        

        //--TRIMMABLE-BOUNDARY-START(3750284)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsTypeDescriptor`, ($self) => class PowerHouseDashboardGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298717580)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298717580);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings, this, factory);
                    }, $OPfrmi ??= {"r":65537,"n":"","d":3750284,"h":0,"f":17825794}), 0, "PowerHouseDashboardGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Settings_PowerHouseDashboardGlobalSettings_LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettingsTypeDescriptorBuilder.g.cs", "PowerHouseDashboardGlobalSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298717580)
            
            //--TRIMMABLE-BOUNDARY-START(12888652172)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888652172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888652172)
            
            //--TRIMMABLE-BOUNDARY-START(17183619468)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183619468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDashboardGlobalSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDashboardGlobalSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183619468)
            
            //--TRIMMABLE-BOUNDARY-START(8593684876)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593684876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593684876)
            
            static $h = 3750284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888652172),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3750284,
      "h": 12888652172,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888652172),
//--TRIMMABLE-BOUNDARY-START(17183619468),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3619212,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3750284,
      "h": 17183619468,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183619468),
//--TRIMMABLE-BOUNDARY-START(8593684876),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3619212,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3750284,
      "h": 8593684876,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593684876)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298717580),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3750284,
      "h": 4298717580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298717580)
  ],
  "h": 3750284
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDashboardGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDashboardGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDashboardGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3750284)
        
        

        //--TRIMMABLE-BOUNDARY-START(4012428)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsTypeDescriptor`, ($self) => class PowerHouseDeviceGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298979724)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298979724);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings, this, factory);
                    }, $bSLtVj ??= {"r":65537,"n":"","d":4012428,"h":0,"f":17825794}), 0, "PowerHouseDeviceGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Settings_PowerHouseDeviceGlobalSettings_LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettingsTypeDescriptorBuilder.g.cs", "PowerHouseDeviceGlobalSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298979724)
            
            //--TRIMMABLE-BOUNDARY-START(12888914316)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888914316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888914316)
            
            //--TRIMMABLE-BOUNDARY-START(17183881612)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183881612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDeviceGlobalSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183881612)
            
            //--TRIMMABLE-BOUNDARY-START(8593947020)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593947020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593947020)
            
            static $h = 4012428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888914316),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4012428,
      "h": 12888914316,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888914316),
//--TRIMMABLE-BOUNDARY-START(17183881612),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3881356,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4012428,
      "h": 17183881612,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183881612),
//--TRIMMABLE-BOUNDARY-START(8593947020),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3881356,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4012428,
      "h": 8593947020,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593947020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298979724),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4012428,
      "h": 4298979724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298979724)
  ],
  "h": 4012428
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4012428)
        
        

        //--TRIMMABLE-BOUNDARY-START(5323148)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesTypeDescriptor`, ($self) => class PowerHouseDeviceScopeStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4300290444)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300290444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, this, factory);
                    }, $rJISka ??= {"r":65537,"n":"","d":5323148,"h":0,"f":17825794}), 0, "PowerHouseDeviceScopeStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\States_PowerHouseDeviceScopeStates_LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStatesTypeDescriptorBuilder.g.cs", "PowerHouseDeviceScopeStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300290444)
            
            //--TRIMMABLE-BOUNDARY-START(12890225036)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890225036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTDeviceScopeStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890225036)
            
            //--TRIMMABLE-BOUNDARY-START(17185192332)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185192332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTDeviceScopeStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTDeviceScopeStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185192332)
            
            //--TRIMMABLE-BOUNDARY-START(8595257740)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595257740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595257740)
            
            static $h = 5323148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890225036),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5323148,
      "h": 12890225036,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890225036),
//--TRIMMABLE-BOUNDARY-START(17185192332),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5192076,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5323148,
      "h": 17185192332,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185192332),
//--TRIMMABLE-BOUNDARY-START(8595257740),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5192076,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5323148,
      "h": 8595257740,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595257740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300290444),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5323148,
      "h": 4300290444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300290444)
  ],
  "h": 5323148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceScopeStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5323148)
        
        

        //--TRIMMABLE-BOUNDARY-START(5585292)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseDeviceStatesTypeDescriptor`, ($self) => class PowerHouseDeviceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseDeviceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4300552588)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300552588);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$2.PowerHouseDeviceStatesTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$2.PowerHouseDeviceStates, this, factory);
                    }, $aSzAfl ??= {"r":65537,"n":"","d":5585292,"h":0,"f":17825794}), 0, "PowerHouseDeviceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\States_PowerHouseDeviceStates_LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStatesTypeDescriptorBuilder.g.cs", "PowerHouseDeviceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300552588)
            
            //--TRIMMABLE-BOUNDARY-START(12890487180)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890487180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890487180)
            
            //--TRIMMABLE-BOUNDARY-START(17185454476)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185454476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTDeviceStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTDeviceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185454476)
            
            //--TRIMMABLE-BOUNDARY-START(8595519884)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595519884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$2.PowerHouseDeviceStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$2.PowerHouseDeviceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595519884)
            
            static $h = 5585292;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseDeviceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890487180),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5585292,
      "h": 12890487180,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890487180),
//--TRIMMABLE-BOUNDARY-START(17185454476),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5454220,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5585292,
      "h": 17185454476,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185454476),
//--TRIMMABLE-BOUNDARY-START(8595519884),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5454220,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5585292,
      "h": 8595519884,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595519884)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300552588),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5585292,
      "h": 4300552588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300552588)
  ],
  "h": 5585292
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseDeviceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseDeviceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5585292)
        
        

        //--TRIMMABLE-BOUNDARY-START(4536716)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsTypeDescriptor`, ($self) => class PowerHouseDeviceScopeSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299504012)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299504012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, this, factory);
                    }, $HxFggb ??= {"r":65537,"n":"","d":4536716,"h":0,"f":17825794}), 0, "PowerHouseDeviceScopeSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Settings_PowerHouseDeviceScopeSettings_LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettingsTypeDescriptorBuilder.g.cs", "PowerHouseDeviceScopeSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299504012)
            
            //--TRIMMABLE-BOUNDARY-START(12889438604)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889438604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDeviceScopeSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889438604)
            
            //--TRIMMABLE-BOUNDARY-START(17184405900)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184405900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDeviceScopeSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDeviceScopeSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184405900)
            
            //--TRIMMABLE-BOUNDARY-START(8594471308)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594471308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594471308)
            
            static $h = 4536716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889438604),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4536716,
      "h": 12889438604,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889438604),
//--TRIMMABLE-BOUNDARY-START(17184405900),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4405644,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4536716,
      "h": 17184405900,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184405900),
//--TRIMMABLE-BOUNDARY-START(8594471308),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4405644,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4536716,
      "h": 8594471308,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594471308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299504012),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4536716,
      "h": 4299504012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299504012)
  ],
  "h": 4536716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceScopeSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4536716)
        
        

        //--TRIMMABLE-BOUNDARY-START(866700)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceCommandModelTypeDescriptor`, ($self) => class PowerHouseDeviceCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295833996)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295833996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHouseDeviceCommandModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, this, factory);
                    }, $vbFVlb ??= {"r":65537,"n":"","d":866700,"h":0,"f":17825794}), 0, "PowerHouseDeviceCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseDeviceCommandModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModelTypeDescriptorBuilder.g.cs", "PowerHouseDeviceCommandModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295833996)
            
            //--TRIMMABLE-BOUNDARY-START(12885768588)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885768588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885768588)
            
            //--TRIMMABLE-BOUNDARY-START(17180735884)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180735884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceCommandModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180735884)
            
            //--TRIMMABLE-BOUNDARY-START(8590801292)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590801292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHouseDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590801292)
            
            static $h = 866700;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885768588),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 866700,
      "h": 12885768588,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885768588),
//--TRIMMABLE-BOUNDARY-START(17180735884),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 735628,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 866700,
      "h": 17180735884,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180735884),
//--TRIMMABLE-BOUNDARY-START(8590801292),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 735628,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 866700,
      "h": 8590801292,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590801292)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295833996),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 866700,
      "h": 4295833996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295833996)
  ],
  "h": 866700
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(866700)
        
        

        //--TRIMMABLE-BOUNDARY-START(2242956)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor`, ($self) => class PowerHouseDeviceStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297210252)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297210252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, this, factory);
                    }, $oKWWTi ??= {"r":65537,"n":"","d":2242956,"h":0,"f":17825794}), 0, "PowerHouseDeviceStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseDeviceStatusModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModelTypeDescriptorBuilder.g.cs", "PowerHouseDeviceStatusModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297210252)
            
            //--TRIMMABLE-BOUNDARY-START(12887144844)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887144844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Utility"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel.$type, $.$discardRef(), "Utility", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Utility")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Utility";
                        $i1.DelaredOn = "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, ($.$cast(target, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).Utility);
                        }, $jsGPtc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2242956,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Utility = value.AsReference($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel);
                        }, $krIHjc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2242956,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Generator"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel.$type, $.$discardRef(), "Generator", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Generator")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Generator";
                        $i3.DelaredOn = "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, ($.$cast(target, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).Generator);
                        }, $JVrjPc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2242956,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Generator = value.AsReference($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel);
                        }, $XgYJYf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2242956,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tank"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel.$type, $.$discardRef(), "Tank", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tank")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$cCKL.LCITCM.TankDataClassificationModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Tank";
                        $i5.DelaredOn = "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$cCKL.LCITCM.TankDataClassificationModel, ($.$cast(target, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).Tank);
                        }, $DcoxAb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2242956,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Tank = value.AsReference($.$cCKL.LCITCM.TankDataClassificationModel);
                        }, $GXNEtj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2242956,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887144844)
            
            //--TRIMMABLE-BOUNDARY-START(17182112140)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182112140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceStatusModel));
                {
                    /*var*/ let _Utility = _target.Utility;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Utility"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Utility, ($v) => _Utility = $v, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))
                    {
                        _target.Utility = _Utility;
                    }
                }
                {
                    /*var*/ let _Generator = _target.Generator;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Generator"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Generator, ($v) => _Generator = $v, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))
                    {
                        _target.Generator = _Generator;
                    }
                }
                {
                    /*var*/ let _Tank = _target.Tank;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tank"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$cCKL.LCITCM.TankDataClassificationModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Tank, ($v) => _Tank = $v, $.$cCKL.LCITCM.TankDataClassificationModel)))
                    {
                        _target.Tank = _Tank;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182112140)
            
            //--TRIMMABLE-BOUNDARY-START(8592177548)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592177548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592177548)
            
            static $h = 2242956;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887144844),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2242956,
      "h": 12887144844,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887144844),
//--TRIMMABLE-BOUNDARY-START(17182112140),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2046348,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2242956,
      "h": 17182112140,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182112140),
//--TRIMMABLE-BOUNDARY-START(8592177548),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2046348,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2242956,
      "h": 8592177548,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592177548)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297210252),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2242956,
      "h": 4297210252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297210252)
  ],
  "h": 2242956
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2242956)
        
        

        //--TRIMMABLE-BOUNDARY-START(5847436)
        $asm.$cls(`$mXnX.LCIPCS$2.PowerHouseServiceStatesTypeDescriptor`, ($self) => class PowerHouseServiceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4300814732)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300814732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$2.PowerHouseServiceStatesTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$2.PowerHouseServiceStates, this, factory);
                    }, $hPuQCk ??= {"r":65537,"n":"","d":5847436,"h":0,"f":17825794}), 0, "PowerHouseServiceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\States_PowerHouseServiceStates_LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStatesTypeDescriptorBuilder.g.cs", "PowerHouseServiceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300814732)
            
            //--TRIMMABLE-BOUNDARY-START(12890749324)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890749324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890749324)
            
            //--TRIMMABLE-BOUNDARY-START(17185716620)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185716620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTServiceStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185716620)
            
            //--TRIMMABLE-BOUNDARY-START(8595782028)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595782028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$2.PowerHouseServiceStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseServiceStates)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$2.PowerHouseServiceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseServiceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$2.PowerHouseServiceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595782028)
            
            static $h = 5847436;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890749324),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5847436,
      "h": 12890749324,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890749324),
//--TRIMMABLE-BOUNDARY-START(17185716620),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5716364,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5847436,
      "h": 17185716620,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185716620),
//--TRIMMABLE-BOUNDARY-START(8595782028),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5716364,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5847436,
      "h": 8595782028,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595782028)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300814732),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5847436,
      "h": 4300814732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300814732)
  ],
  "h": 5847436
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$2.PowerHouseServiceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}States${separator}PowerHouseServiceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5847436)
        
        

        //--TRIMMABLE-BOUNDARY-START(5061004)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseServiceSettingsTypeDescriptor`, ($self) => class PowerHouseServiceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseServiceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300028300)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300028300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$1.PowerHouseServiceSettingsTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$1.PowerHouseServiceSettings, this, factory);
                    }, $ZBiRMf ??= {"r":65537,"n":"","d":5061004,"h":0,"f":17825794}), 0, "PowerHouseServiceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Settings_PowerHouseServiceSettings_LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettingsTypeDescriptorBuilder.g.cs", "PowerHouseServiceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300028300)
            
            //--TRIMMABLE-BOUNDARY-START(12889962892)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889962892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889962892)
            
            //--TRIMMABLE-BOUNDARY-START(17184930188)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184930188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTServiceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184930188)
            
            //--TRIMMABLE-BOUNDARY-START(8594995596)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594995596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$1.PowerHouseServiceSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$1.PowerHouseServiceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594995596)
            
            static $h = 5061004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseServiceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889962892),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5061004,
      "h": 12889962892,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889962892),
//--TRIMMABLE-BOUNDARY-START(17184930188),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4929932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5061004,
      "h": 17184930188,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184930188),
//--TRIMMABLE-BOUNDARY-START(8594995596),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4929932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5061004,
      "h": 8594995596,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594995596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300028300),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5061004,
      "h": 4300028300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300028300)
  ],
  "h": 5061004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseServiceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseServiceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5061004)
        
        

        //--TRIMMABLE-BOUNDARY-START(1259916)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel`, ($self) => class PowerHouseDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296227212)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296227212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296227212)
            
            //--TRIMMABLE-BOUNDARY-START(4296227212)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296227212)
            
            static $h = 1259916;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296227212),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1259916,
      "h": 4296227212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296227212)
  ],
  "h": 1259916
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1259916)
        
        

        //--TRIMMABLE-BOUNDARY-START(1390988)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelTypeDescriptor`, ($self) => class PowerHouseDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296358284)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296358284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, this, factory);
                    }, $NtDHgl ??= {"r":65537,"n":"","d":1390988,"h":0,"f":17825794}), 0, "PowerHouseDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseDeviceReceivedDataModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "PowerHouseDeviceReceivedDataModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296358284)
            
            //--TRIMMABLE-BOUNDARY-START(12886292876)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886292876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886292876)
            
            //--TRIMMABLE-BOUNDARY-START(17181260172)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181260172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHosuseReceivedStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181260172)
            
            //--TRIMMABLE-BOUNDARY-START(8591325580)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591325580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591325580)
            
            static $h = 1390988;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886292876),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1390988,
      "h": 12886292876,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886292876),
//--TRIMMABLE-BOUNDARY-START(17181260172),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1259916,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1390988,
      "h": 17181260172,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181260172),
//--TRIMMABLE-BOUNDARY-START(8591325580),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1259916,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1390988,
      "h": 8591325580,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591325580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296358284),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1390988,
      "h": 4296358284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296358284)
  ],
  "h": 1390988
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1390988)
        
        

        //--TRIMMABLE-BOUNDARY-START(3029388)
        $asm.$cls(`$mXnX.LCIPC.PowerHouseDataConverter`, ($self) => class PowerHouseDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297996684)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297996684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297996684)
            
            //--TRIMMABLE-BOUNDARY-START(4297996684)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297996684)
            
            static $h = 3029388;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297996684),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3029388,
      "h": 4297996684,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297996684)
  ],
  "h": 3029388
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.PowerHouseDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}PowerHouseDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3029388)
        
        

        //--TRIMMABLE-BOUNDARY-START(342412)
        $asm.$cls(`$mXnX.LCIPCH.IPowerHouseServiceHubClient`, ($self) => class IPowerHouseServiceHubClient
        {
            static $h = 342412;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 342412
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Hubs.IPowerHouseServiceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Hubs${separator}IPowerHouseServiceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(342412)
        
        

        //--TRIMMABLE-BOUNDARY-START(3488140)
        $asm.$cls(`$mXnX.LCIPCS.IPowerHouseRemoteService`, ($self) => class IPowerHouseRemoteService
        {
            static $h = 3488140;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298455436),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetReport",
      "o": "LCIPCS$IPowerHouseRemoteService$GetReport",
      "d": 3488140,
      "h": 4298455436,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298455436)
  ],
  "h": 3488140,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Services${separator}IPowerHouseRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3488140)
        
        

        $asm.$typeProxy("$mXnX.LCIPCM.PowerHouseServiceModel", "$mXnX.LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel");
        $asm.$typeProxy("$mXnX.LCIPCM.PowerHouseDeviceScopeModel", "$mXnX.LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel");
        $asm.$typeProxy("$mXnX.LCIPCM.PowerHouseDeviceModel", "$mXnX.LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel");
        $asm.$typeProxy("$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings", "$mXnX.LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings");
        $asm.$typeProxy("$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler", "$mXnX.LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseDeviceStatusHandler");
        //--TRIMMABLE-BOUNDARY-START(4667788)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceSettings`, ($self) => class PowerHouseDeviceSettings extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $self, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299635084)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299635084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299635084)
            
            //--TRIMMABLE-BOUNDARY-START(4299635084)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299635084)
            
            static $h = 4667788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299635084),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4667788,
      "h": 4299635084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299635084)
  ],
  "h": 4667788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4667788)
        
        

        //--TRIMMABLE-BOUNDARY-START(997772)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceModel`, ($self) => class PowerHouseDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $self, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590932364)
            /*string */ get FuelTankId()
            {
                return $.$strNN(this.UniqueId) + "/Tank";
            }
            //--TRIMMABLE-BOUNDARY-END(8590932364)
            
            //--TRIMMABLE-BOUNDARY-START(42950670732)
            /*string */ get GridMeterId()
            {
                return $.$strNN(this.UniqueId) + "/Grid";
            }
            //--TRIMMABLE-BOUNDARY-END(42950670732)
            
            //--TRIMMABLE-BOUNDARY-START(12885899660)
            /*string */ get GeneratorMeterId()
            {
                return $.$strNN(this.UniqueId) + "/Generator";
            }
            //--TRIMMABLE-BOUNDARY-END(12885899660)
            
            //--TRIMMABLE-BOUNDARY-START(4295965068)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295965068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295965068)
            
            //--TRIMMABLE-BOUNDARY-START(4295965068)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295965068)
            
            static $h = 997772;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590932364),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475834252,
        "f": 50331649
      },
      "n": "FuelTankId",
      "d": 997772,
      "h": 8590932364,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590932364),
//--TRIMMABLE-BOUNDARY-START(42950670732),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655703436,
        "f": 50331649
      },
      "n": "GridMeterId",
      "d": 997772,
      "h": 42950670732,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950670732),
//--TRIMMABLE-BOUNDARY-START(12885899660),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065768844,
        "f": 50331649
      },
      "n": "GeneratorMeterId",
      "d": 997772,
      "h": 12885899660,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885899660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295965068),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 997772,
      "h": 4295965068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295965068)
  ],
  "h": 997772
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(997772)
        
        

        //--TRIMMABLE-BOUNDARY-START(2505100)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseServiceModel`, ($self) => class PowerHouseServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297472396)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297472396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297472396)
            
            //--TRIMMABLE-BOUNDARY-START(4297472396)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297472396)
            
            static $h = 2505100;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297472396),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2505100,
      "h": 4297472396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297472396)
  ],
  "h": 2505100
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$mXnX.LCIPCM.PowerHouseServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2505100)
        
        

        //--TRIMMABLE-BOUNDARY-START(3422604)
        $asm.$cls(`$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler`, ($self) => class IPowerHouseDeviceStatusHandler
        {
            static $h = 3422604;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3422604
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Services${separator}IPowerHouseDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3422604)
        
        

        //--TRIMMABLE-BOUNDARY-START(4143500)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings`, ($self) => class PowerHouseDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $self, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299110796)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299110796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299110796)
            
            //--TRIMMABLE-BOUNDARY-START(4299110796)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299110796)
            
            static $h = 4143500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299110796),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4143500,
      "h": 4299110796,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299110796)
  ],
  "h": 4143500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4143500)
        
        

        //--TRIMMABLE-BOUNDARY-START(1522060)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceScopeModel`, ($self) => class PowerHouseDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $self, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296489356)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296489356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296489356)
            
            //--TRIMMABLE-BOUNDARY-START(4296489356)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296489356)
            
            static $h = 1522060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296489356),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1522060,
      "h": 4296489356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296489356)
  ],
  "h": 1522060
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1522060)
        
        

        //--TRIMMABLE-BOUNDARY-START(3225996)
        $asm.$cls(`$mXnX.LCIPC.PowerHouseDeviceModelDefinition`, ($self) => class PowerHouseDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4298193292)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298193292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298193292)
            
            //--TRIMMABLE-BOUNDARY-START(4298193292)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298193292)
            
            static $h = 3225996;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298193292),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3225996,
      "h": 4298193292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298193292)
  ],
  "h": 3225996
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.PowerHouseDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}PowerHouseDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3225996)
        
        

        //--TRIMMABLE-BOUNDARY-START(3553676)
        $asm.$cls(`$mXnX.LCIPCS.IPowerHouseRemoteService_Mocking`, ($self) => class IPowerHouseRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298520972)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298520972);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298520972)
            
            //--TRIMMABLE-BOUNDARY-START(38658259340)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel>> */ LCIPCS$IPowerHouseRemoteService$GetReport(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658259340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$mXnX.LCIPCS.IPowerHouseRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$type;
                    $i1.MethodName = "GetReport";
                    return $i1;
                })();
                return this.InvokeAsync($.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38658259340)
            
            //--TRIMMABLE-BOUNDARY-START(42953226636)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel>> */ Publish(/*LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel*/ dashboard)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953226636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i2.MethodName = "Publish";
                    return $i2;
                })();
                return this.InvokeAsync($.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel), $.$fPer.LCFCD.WireTransportModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$mXnX.LCIPCM.PowerHouseServiceModel.$type, dashboard) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42953226636)
            
            //--TRIMMABLE-BOUNDARY-START(8593488268)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Models.UserServiceSubscriptionModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel>>> */ LCFCCR$ISubscriptionBasedRemoteService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$LoadServices(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593488268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel)).$type;
                    $i3.MethodName = "LoadServices";
                    return $i3;
                })();
                return this.InvokeAsync($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593488268)
            
            //--TRIMMABLE-BOUNDARY-START(34363292044)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCR$IServiceRemoteService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceTierType$ChangeServiceTier(/*string*/ contextId, /*LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType*/ newTier, /*System.DateTime*/ expiryDate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363292044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$uvJL.LCFCR.IServiceRemoteService$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i4.MethodName = "ChangeServiceTier";
                    return $i4;
                })();
                return this.InvokeAsync($.$uvJL.LCFCR.IServiceRemoteService$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType), $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, contextId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$mXnX.LCIPCM.PowerHouseServiceTierType.$type, $.$box(newTier, $.$mXnX.LCIPCM.PowerHouseServiceTierType)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, expiryDate) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34363292044)
            
            //--TRIMMABLE-BOUNDARY-START(12888455564)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel>> */ LCFCD$ICreateDataService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888455564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i5.MethodName = "Create";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$mXnX.LCIPCM.PowerHouseServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888455564)
            
            //--TRIMMABLE-BOUNDARY-START(21478390156)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478390156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i6.MethodName = "ReadMany";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$mXnX.LCIPCM.PowerHouseServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478390156)
            
            //--TRIMMABLE-BOUNDARY-START(25773357452)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773357452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i7.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i7.MethodName = "ReadSingle";
                    return $i7;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.WireTransportModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$mXnX.LCIPCM.PowerHouseServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773357452)
            
            //--TRIMMABLE-BOUNDARY-START(30068324748)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068324748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i8.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i8.MethodName = "Update";
                    return $i8;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$mXnX.LCIPCM.PowerHouseServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30068324748)
            
            //--TRIMMABLE-BOUNDARY-START(17183422860)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183422860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$type;
                    $i9.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i9.MethodName = "Delete";
                    return $i9;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$mXnX.LCIPCM.PowerHouseServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183422860)
            
            //--TRIMMABLE-BOUNDARY-START(4347434385)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Services.IIOTServicesRemoteService<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel>.Publish(LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel)
            LCICS$1$IIOTServicesRemoteService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceTierType$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$LivingThing$Core$IOT$PowerHouse$Common$Settings$PowerHouseServiceSettings$LivingThing$Core$IOT$PowerHouse$Common$States$PowerHouseServiceStates$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseDeviceScopeModel$LivingThing$Core$IOT$PowerHouse$Common$Settings$PowerHouseDeviceScopeSettings$LivingThing$Core$IOT$PowerHouse$Common$States$PowerHouseDeviceScopeStates$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseDeviceModel$LivingThing$Core$IOT$PowerHouse$Common$Settings$PowerHouseDeviceSettings$LivingThing$Core$IOT$PowerHouse$Common$Settings$PowerHouseDeviceHardwareSettings$LivingThing$Core$IOT$PowerHouse$Common$States$PowerHouseDeviceStates$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseDeviceStatusModel$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseDeviceCommandModel$Publish()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4347434385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Publish(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4347434385)
            
            static $h = 3553676;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42953226636),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel)).$h,
      "p": [
        {
          "n": "dashboard",
          "p": 2505100
        }
      ],
      "n": "Publish",
      "d": 3553676,
      "h": 42953226636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42953226636)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298520972),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3553676,
      "h": 4298520972,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298520972)
  ],
  "h": 3553676
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Services${separator}IPowerHouseRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3553676)
        
        

        //--TRIMMABLE-BOUNDARY-START(4798860)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceSettingsTypeDescriptor`, ($self) => class PowerHouseDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299766156)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299766156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$1.PowerHouseDeviceSettingsTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, this, factory);
                    }, $croyLb ??= {"r":65537,"n":"","d":4798860,"h":0,"f":17825794}), 0, "PowerHouseDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Settings_PowerHouseDeviceSettings_LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettingsTypeDescriptorBuilder.g.cs", "PowerHouseDeviceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299766156)
            
            //--TRIMMABLE-BOUNDARY-START(12889700748)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889700748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889700748)
            
            //--TRIMMABLE-BOUNDARY-START(17184668044)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184668044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceFeatureType, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseDeviceStatusHandler, LivingThing.Core.IOT.PowerHouse.Common.Hubs.IPowerHouseServiceHubClient, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseRemoteService>.IOTDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184668044)
            
            //--TRIMMABLE-BOUNDARY-START(8594733452)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594733452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$1.PowerHouseDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594733452)
            
            static $h = 4798860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889700748),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4798860,
      "h": 12889700748,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889700748),
//--TRIMMABLE-BOUNDARY-START(17184668044),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4667788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4798860,
      "h": 17184668044,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184668044),
//--TRIMMABLE-BOUNDARY-START(8594733452),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4667788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4798860,
      "h": 8594733452,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594733452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299766156),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4798860,
      "h": 4299766156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299766156)
  ],
  "h": 4798860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4798860)
        
        

        //--TRIMMABLE-BOUNDARY-START(2636172)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseServiceModelTypeDescriptor`, ($self) => class PowerHouseServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297603468)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297603468);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHouseServiceModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHouseServiceModel, this, factory);
                    }, $zfLTcb ??= {"r":65537,"n":"","d":2636172,"h":0,"f":17825794}), 0, "PowerHouseServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseServiceModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModelTypeDescriptorBuilder.g.cs", "PowerHouseServiceModelTypeDescriptor", 47);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297603468)
            
            //--TRIMMABLE-BOUNDARY-START(12887538060)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887538060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887538060)
            
            //--TRIMMABLE-BOUNDARY-START(17182505356)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182505356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceFeatureType, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseDeviceStatusHandler, LivingThing.Core.IOT.PowerHouse.Common.Hubs.IPowerHouseServiceHubClient, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182505356)
            
            //--TRIMMABLE-BOUNDARY-START(8592570764)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592570764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHouseServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHouseServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseServiceModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHouseServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHouseServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592570764)
            
            static $h = 2636172;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887538060),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2636172,
      "h": 12887538060,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887538060),
//--TRIMMABLE-BOUNDARY-START(17182505356),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2505100,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2636172,
      "h": 17182505356,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182505356),
//--TRIMMABLE-BOUNDARY-START(8592570764),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2505100,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2636172,
      "h": 8592570764,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592570764)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297603468),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2636172,
      "h": 4297603468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297603468)
  ],
  "h": 2636172
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2636172)
        
        

        //--TRIMMABLE-BOUNDARY-START(1128844)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor`, ($self) => class PowerHouseDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296096140)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296096140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHouseDeviceModel, this, factory);
                    }, $zRIpkh ??= {"r":65537,"n":"","d":1128844,"h":0,"f":17825794}), 0, "PowerHouseDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseDeviceModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModelTypeDescriptorBuilder.g.cs", "PowerHouseDeviceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296096140)
            
            //--TRIMMABLE-BOUNDARY-START(12886030732)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886030732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FuelTankId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mXnX.LCIPCM.PowerHouseDeviceModel.$type, $.$discardRef(), "FuelTankId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FuelTankId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "FuelTankId";
                        $i1.DelaredOn = "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mXnX.LCIPCM.PowerHouseDeviceModel)).FuelTankId);
                        }, $dPzEvd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1128844,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GridMeterId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mXnX.LCIPCM.PowerHouseDeviceModel.$type, $.$discardRef(), "GridMeterId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GridMeterId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "GridMeterId";
                        $i3.DelaredOn = "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mXnX.LCIPCM.PowerHouseDeviceModel)).GridMeterId);
                        }, $wObKSi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1128844,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GeneratorMeterId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mXnX.LCIPCM.PowerHouseDeviceModel.$type, $.$discardRef(), "GeneratorMeterId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GeneratorMeterId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "GeneratorMeterId";
                        $i5.DelaredOn = "LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mXnX.LCIPCM.PowerHouseDeviceModel)).GeneratorMeterId);
                        }, $CcgxZd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1128844,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886030732)
            
            //--TRIMMABLE-BOUNDARY-START(17180998028)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180998028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceFeatureType, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseDeviceStatusHandler, LivingThing.Core.IOT.PowerHouse.Common.Hubs.IPowerHouseServiceHubClient, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceModel));
                {
                    /*var*/ let _FuelTankId = _target.FuelTankId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FuelTankId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FuelTankId, ($v) => _FuelTankId = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _GridMeterId = _target.GridMeterId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GridMeterId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _GridMeterId, ($v) => _GridMeterId = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _GeneratorMeterId = _target.GeneratorMeterId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GeneratorMeterId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _GeneratorMeterId, ($v) => _GeneratorMeterId = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180998028)
            
            //--TRIMMABLE-BOUNDARY-START(8591063436)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591063436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHouseDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHouseDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591063436)
            
            static $h = 1128844;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886030732),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1128844,
      "h": 12886030732,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886030732),
//--TRIMMABLE-BOUNDARY-START(17180998028),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 997772,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1128844,
      "h": 17180998028,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180998028),
//--TRIMMABLE-BOUNDARY-START(8591063436),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 997772,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1128844,
      "h": 8591063436,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591063436)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296096140),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1128844,
      "h": 4296096140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296096140)
  ],
  "h": 1128844
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1128844)
        
        

        //--TRIMMABLE-BOUNDARY-START(4274572)
        $asm.$cls(`$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsTypeDescriptor`, ($self) => class PowerHouseDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299241868)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299241868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, this, factory);
                    }, $HdJtCi ??= {"r":65537,"n":"","d":4274572,"h":0,"f":17825794}), 0, "PowerHouseDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Settings_PowerHouseDeviceHardwareSettings_LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "PowerHouseDeviceHardwareSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299241868)
            
            //--TRIMMABLE-BOUNDARY-START(12889176460)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889176460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889176460)
            
            //--TRIMMABLE-BOUNDARY-START(17184143756)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184143756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceFeatureType, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseDeviceStatusHandler, LivingThing.Core.IOT.PowerHouse.Common.Hubs.IPowerHouseServiceHubClient, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184143756)
            
            //--TRIMMABLE-BOUNDARY-START(8594209164)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594209164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594209164)
            
            static $h = 4274572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889176460),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4274572,
      "h": 12889176460,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889176460),
//--TRIMMABLE-BOUNDARY-START(17184143756),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4143500,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4274572,
      "h": 17184143756,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184143756),
//--TRIMMABLE-BOUNDARY-START(8594209164),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4143500,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4274572,
      "h": 8594209164,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594209164)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299241868),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4274572,
      "h": 4299241868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299241868)
  ],
  "h": 4274572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Settings${separator}PowerHouseDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4274572)
        
        

        //--TRIMMABLE-BOUNDARY-START(1653132)
        $asm.$cls(`$mXnX.LCIPCM.PowerHouseDeviceScopeModelTypeDescriptor`, ($self) => class PowerHouseDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296620428)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296620428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mXnX.LCIPCM.PowerHouseDeviceScopeModelTypeDescriptor.GenerateProperties($.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, this, factory);
                    }, $CwWCXd ??= {"r":65537,"n":"","d":1653132,"h":0,"f":17825794}), 0, "PowerHouseDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.PowerHouse.Common\\Models_PowerHouseDeviceScopeModel_LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModelTypeDescriptorBuilder.g.cs", "PowerHouseDeviceScopeModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296620428)
            
            //--TRIMMABLE-BOUNDARY-START(12886555020)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886555020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886555020)
            
            //--TRIMMABLE-BOUNDARY-START(17181522316)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181522316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceTierType, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseServiceFeatureType, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseServiceSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseServiceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceScopeSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceScopeStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceModel, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceSettings, LivingThing.Core.IOT.PowerHouse.Common.Settings.PowerHouseDeviceHardwareSettings, LivingThing.Core.IOT.PowerHouse.Common.States.PowerHouseDeviceStates, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceStatusModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceCommandModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceReceivedDataModel, LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceSendDataModel, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseDeviceStatusHandler, LivingThing.Core.IOT.PowerHouse.Common.Hubs.IPowerHouseServiceHubClient, LivingThing.Core.IOT.PowerHouse.Common.Services.IPowerHouseRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181522316)
            
            //--TRIMMABLE-BOUNDARY-START(8591587724)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591587724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel)))
                {
                    /*var*/ let result = $.$mXnX.LCIPCM.PowerHouseDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591587724)
            
            static $h = 1653132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886555020),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1653132,
      "h": 12886555020,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886555020),
//--TRIMMABLE-BOUNDARY-START(17181522316),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1522060,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1653132,
      "h": 17181522316,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181522316),
//--TRIMMABLE-BOUNDARY-START(8591587724),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1522060,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1653132,
      "h": 8591587724,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591587724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296620428),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1653132,
      "h": 4296620428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296620428)
  ],
  "h": 1653132
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mXnX.LCIPCM.PowerHouseDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.Models.PowerHouseDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}Models${separator}PowerHouseDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1653132)
        
        

        //--TRIMMABLE-BOUNDARY-START(3291532)
        $asm.$cls(`$mXnX.LCIPC.PowerHouseSmartDevice`, ($self) => class PowerHouseSmartDevice extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($self, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings).SmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(8593226124)
            $ctor$3(/*PowerHouseDashboardScope*/ scope, /*PowerHouseDeviceModel*/ model)
            {
                super.$ctor$2($.$cast($.$sl.SL.Enumerable.First$1($.$XBGm.LCICI.IIOTDeviceFamily, scope.Factory.DeviceFamilies), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice)), scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593226124);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593226124)
            
            //--TRIMMABLE-BOUNDARY-START(4298258828)
            $ctor$2(/*IIOTDeviceFamily<PowerHouseSmartDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*PowerHouseDeviceModel*/ model)
            {
                super.$ctor$2(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298258828);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298258828)
            
            static $h = 3291532;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings).SmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593226124),
    {
      "p": [
        {
          "n": "scope",
          "p": 2898316
        },
        {
          "n": "model",
          "p": 997772
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3291532,
      "h": 8593226124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593226124),
//--TRIMMABLE-BOUNDARY-START(4298258828),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 997772
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3291532,
      "h": 4298258828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298258828)
  ],
  "h": 3291532
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.PowerHouseSmartDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}PowerHouseSmartDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3291532)
        
        

        //--TRIMMABLE-BOUNDARY-START(3094924)
        $asm.$cls(`$mXnX.LCIPC.PowerHouseDeviceDefinition`, ($self) => class PowerHouseDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298062220)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298062220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298062220)
            
            //--TRIMMABLE-BOUNDARY-START(4298062220)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298062220)
            
            static $h = 3094924;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298062220),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3094924,
      "h": 4298062220,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298062220)
  ],
  "h": 3094924
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.PowerHouseDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}PowerHouseDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3094924)
        
        

        //--TRIMMABLE-BOUNDARY-START(2963852)
        $asm.$cls(`$mXnX.LCIPC.PowerHouseDashboardScopeFactory`, ($self) => class PowerHouseDashboardScopeFactory extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings).SmartGenericServerDeviceScopeFactory
        {
            //--TRIMMABLE-BOUNDARY-START(8592898444)
            $ctor$1(/*ServiceFactory*/ services, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ deviceStore, /*IIOTDeviceFamily<PowerHouseSmartDevice>*/ family, /*IServerRemoteService*/ serverRemoteService, /*IIOTDeviceDataConverter<PowerHouseDeviceReceivedDataModel, PowerHouseDeviceStatusModel>*/ converter)
            {
                super.$ctor$2(services, config, scopeStore, deviceStore, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice)), [family], null, null), serverRemoteService, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592898444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Converter = converter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592898444)
            
            //--TRIMMABLE-BOUNDARY-START(12887865740)
            /*IIOTDeviceDataConverter<PowerHouseDeviceReceivedDataModel, PowerHouseDeviceStatusModel>*/ Converter = null;
            //--TRIMMABLE-BOUNDARY-END(12887865740)
            
            //--TRIMMABLE-BOUNDARY-START(17182833036)
            /*string */ get DashboardLink()
            {
                return "PowerHouse";
            }
            //--TRIMMABLE-BOUNDARY-END(17182833036)
            
            //--TRIMMABLE-BOUNDARY-START(42952636812)
            /*PowerHouseDashboardScope? */ GetScope$1(/*PowerHouseServiceModel*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952636812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mXnX.LCIPC.PowerHouseDashboardScope().$ctor$3(this, service);
            }
            //--TRIMMABLE-BOUNDARY-END(42952636812)
            
            //--TRIMMABLE-BOUNDARY-START(38657669516)
            /*PowerHouseDashboardScope */ GetScope(/*PowerHouseDeviceScopeModel*/ scope, /*IEnumerable<PowerHouseDeviceModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657669516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mXnX.LCIPC.PowerHouseDashboardScope().$ctor$2(this, scope, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(38657669516)
            
            static $h = 2963852;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings).SmartGenericServerDeviceScopeFactory; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887865740),
    {
      "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772767628,
        "f": 50331649
      },
      "n": "Converter",
      "d": 2963852,
      "h": 12887865740,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887865740),
//--TRIMMABLE-BOUNDARY-START(17182833036),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362702220,
        "f": 50364417
      },
      "n": "DashboardLink",
      "d": 2963852,
      "h": 17182833036,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182833036)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952636812),
    {
      "r": 2898316,
      "p": [
        {
          "n": "service",
          "p": 2505100
        }
      ],
      "n": "GetScope",
      "o": "@$1",
      "d": 2963852,
      "h": 42952636812,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952636812),
//--TRIMMABLE-BOUNDARY-START(38657669516),
    {
      "r": 2898316,
      "p": [
        {
          "n": "scope",
          "p": 1522060
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceModel).$h
        }
      ],
      "n": "GetScope",
      "d": 2963852,
      "h": 38657669516,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657669516)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592898444),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "deviceStore",
          "p": 1283473
        },
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice).$h
        },
        {
          "n": "serverRemoteService",
          "p": 1309651
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2963852,
      "h": 8592898444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592898444)
  ],
  "h": 2963852
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.PowerHouseDashboardScopeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}PowerHouseDashboardScopeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2963852)
        
        

        //--TRIMMABLE-BOUNDARY-START(3160460)
        $asm.$cls(`$mXnX.LCIPC.PowerHouseDeviceFamily`, ($self) => class PowerHouseDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings).ConfiguredServerDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298127756)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<PowerHouseDeviceReceivedDataModel, PowerHouseDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<PowerHouseDeviceReceivedDataModel, PowerHouseDeviceStatusModel>*/ converter)
            {
                super.$ctor$3(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298127756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298127756)
            
            static $h = 3160460;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings).ConfiguredServerDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298127756),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3160460,
      "h": 4298127756,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298127756)
  ],
  "h": 3160460
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$mXnX.LCIPC.PowerHouseSmartDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$XBGm.LCICI.IIOTServerDeviceFamily ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.PowerHouseDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}PowerHouseDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3160460)
        
        

        //--TRIMMABLE-BOUNDARY-START(2898316)
        $asm.$cls(`$mXnX.LCIPC.PowerHouseDashboardScope`, ($self) => class PowerHouseDashboardScope extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel).iSmartGenericDeviceServiceAsScope
        {
            //--TRIMMABLE-BOUNDARY-START(8592832908)
            $ctor$3(/*PowerHouseDashboardScopeFactory*/ factory, /*PowerHouseServiceModel*/ service)
            {
                super.$ctor$5(factory, service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592832908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592832908)
            
            //--TRIMMABLE-BOUNDARY-START(4297865612)
            $ctor$2(/*PowerHouseDashboardScopeFactory*/ factory, /*PowerHouseDeviceScopeModel*/ scope, /*IEnumerable<PowerHouseDeviceModel>*/ _devices)
            {
                super.$ctor$4(factory, scope, _devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297865612);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297865612)
            
            //--TRIMMABLE-BOUNDARY-START(12887800204)
            /*Task<PowerHouseSmartDevice?> */ GetDevice(/*PowerHouseDeviceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887800204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$mXnX.LCIPC.PowerHouseSmartDevice, new $.$mXnX.LCIPC.PowerHouseSmartDevice().$ctor$3(this, model));
            }
            //--TRIMMABLE-BOUNDARY-END(12887800204)
            
            static $h = 2898316;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$mXnX.LCIPC.PowerHouseSmartDevice, $.$mXnX.LCIPCM.PowerHouseServiceModel, $.$mXnX.LCIPCM.PowerHouseServiceTierType, $.$mXnX.LCIPCM.PowerHouseServiceFeatureType, $.$mXnX.LCIPCS$1.PowerHouseServiceSettings, $.$mXnX.LCIPCS$2.PowerHouseServiceStates, $.$mXnX.LCIPCM.PowerHouseDeviceScopeModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceScopeSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceScopeStates, $.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$mXnX.LCIPCS$1.PowerHouseDeviceSettings, $.$mXnX.LCIPCS$1.PowerHouseDeviceHardwareSettings, $.$mXnX.LCIPCS$2.PowerHouseDeviceStates, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$mXnX.LCIPCM.PowerHouseDeviceCommandModel, $.$mXnX.LCIPCM.PowerHouseDeviceReceivedDataModel, $.$mXnX.LCIPCM.PowerHouseDeviceSendDataModel, $.$mXnX.LCIPCS.IPowerHouseDeviceStatusHandler, $.$mXnX.LCIPCH.IPowerHouseServiceHubClient, $.$mXnX.LCIPCS.IPowerHouseRemoteService, $.$mXnX.LCIPCS$1.PowerHouseDeviceGlobalSettings, $.$mXnX.LCIPCM.PowerHosuseReceivedStatusModel).iSmartGenericDeviceServiceAsScope; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887800204),
    {
      "r": $.$$.STT.Task$$($.$mXnX.LCIPC.PowerHouseSmartDevice).$h,
      "p": [
        {
          "n": "model",
          "p": 997772
        }
      ],
      "n": "GetDevice",
      "d": 2898316,
      "h": 12887800204,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887800204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592832908),
    {
      "p": [
        {
          "n": "factory",
          "p": 2963852
        },
        {
          "n": "service",
          "p": 2505100
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2898316,
      "h": 8592832908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592832908),
//--TRIMMABLE-BOUNDARY-START(4297865612),
    {
      "p": [
        {
          "n": "factory",
          "p": 2963852
        },
        {
          "n": "scope",
          "p": 1522060
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2898316,
      "h": 4297865612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297865612)
  ],
  "h": 2898316
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Common.PowerHouseDashboardScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Common${separator}PowerHouseDashboardScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2898316)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway", "NetJs.LivingThing.Core.IOT.EnergyMeter.Common", "NetJs.LivingThing.Core.IOT.TankTalks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(14732)
