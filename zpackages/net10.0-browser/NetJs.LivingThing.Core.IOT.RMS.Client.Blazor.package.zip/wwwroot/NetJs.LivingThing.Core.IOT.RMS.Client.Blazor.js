
//--TRIMMABLE-BOUNDARY-START(49473)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm, $OgAC) {
    "use strict";
    let _;
    let $pDGvWj;
    let $lFBgod;
    let $qsGfqd;
    let $KKqFHe;
    let $FoVsDd;
    let $ncpIha;
    let $XGmuca;
    let $fpuNVb;
    let $zfvDIi;
    let $tDdmda;
    let $LPcMmf;
    let $evJDmd;
    let $kAOGfd;
    let $vzszZc;
    let $JzDxkc;
    let $KYAxbk;
    let $IcAhac;
    let $cfALFc;
    let $VKHUNk;
    let $RrOAia;
    let $ftTahj;
    let $rnQvbj;
    let $DRBpQh;
    let $kTpdDg;
    let $ZuCkYf;
    let $CRafre;
    let $zxtUta;
    let $kpxBje;
    let $aNBWSf;
    let $FEWBhb;
    let $SncJGc;
    let $tKjdCa;
    let $aufhYc;
    let $BlxTii;
    let $PzGKdk;
    let $AvXKbf;
    let $yxIcyj;
    let $UhBwvh;
    let $dQpvji;
    let $dRqjMj;
    let $BJwyWe;
    let $UTaDok;
    let $InutHh;
    let $yjfjcf;
    let $HPgKjg;
    let $HAXfod;
    let $RuyCSj;
    let $HPIzwc;
    let $AAVCCa;
    let $wMULvi;
    let $ZTNxqb;
    let $qcFyRf;
    let $AsHLDb;
    let $NfRjWb;
    let $uOBYOg;
    let $UmIJbg;
    let $FpEdAf;
    let $nSfwrh;
    let $UXqFIc;
    let $lkdpHk;
    let $oYrNyj;
    let $hBytcj;
    let $CPBSuk;
    let $XjwuQk;
    let $OpGvpb;
    let $nQXyhk;
    let $qrmQCc;
    let $kFyjBb;
    let $SNVSek;
    let $wfUbqj;
    let $gGiHdj;
    let $VmLDij;
    let $sbEIgc;
    let $Oqziqi;
    let $yJtiRd;
    let $htkjMk;
    let $UVuBhl;
    let $mDeVvj;
    let $bvUwYd;
    let $nMsdnf;
    let $jXaOia;
    let $aekQEc;
    let $bcsfCe;
    let $pUwsze;
    let $ehHBrf;
    let $uNiMni;
    let $EmdHGd;
    let $xDBOpe;
    let $yaVQSd;
    let $dUAKle;
    let $GYLTJd;
    let $CAHptj;
    let $ciYKud;
    let $UuHmWa;
    let $onfiVd;
    let $kXpkKd;
    let $USjZee;
    let $Uzcgie;
    let $DPNKYk;
    let $PrsLGg;
    let $fcHKnh;
    let $ehikKd;
    let $cQWGuk;
    let $AtXTWc;
    let $gbdKjf;
    let $oNZLRa;
    let $MAqMcl;
    let $ggqNMf;
    let $WZJEZg;
    let $MqEfbl;
    let $WKRZNk;
    let $gaYMPh;
    let $AZbuOa;
    let $QVMVxh;
    let $efScja;
    let $Zihoac;
    let $rIpxjk;
    let $pJtNZf;
    let $Jowouj;
    let $tBdRGk;
    let $tQlDNj;
    let $BMALCb;
    let $qVpOtd;
    let $gXPDoe;
    let $ZPRhJg;
    let $cVxaoh;
    let $eMlsBe;
    let $BRcTba;
    let $hyuIOi;
    let $UKAouk;
    let $EhbkGc;
    let $UKpwua;
    let $NLHhxb;
    let $hzjfOi;
    let $uXNbaj;
    let $bALFAa;
    let $IALslk;
    let $CvlUXj;
    let $OqxPnb;
    let $GtTUri;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.RMS.Client.Blazor", 
    {
  "h": 49473,
  "f": "LivingThing.Core.IOT.RMS.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.RMS.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.RMS.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1360193)
        $asm.$cls(`$QoDz.LCIRC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296327489)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296327489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QoDz.LCIRCP.Settings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QoDz.LCIRCP.SettingsCustomAttributesProvider, $.$QoDz.LCIRCP.SettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QoDz.LCIRCPS.StationSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QoDz.LCIRCPS.StationSettingsCustomAttributesProvider, $.$QoDz.LCIRCPS.StationSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296327489)
            
            static $h = 1360193;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296327489),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1360193,
      "h": 4296327489,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296327489)
  ],
  "h": 1360193
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1360193)
        
        

        //--TRIMMABLE-BOUNDARY-START(2408769)
        $asm.$cls(`$QoDz.LCIRCP.SettingsCustomAttributesProvider`, ($self) => class SettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297376065)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297376065)
            
            //--TRIMMABLE-BOUNDARY-START(8592343361)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592343361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QoDz.LCIRCP.SettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$hDPm.LCFCC$1.ServiceInjectAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCC$1.ServiceInjectAttribute), [(() =>
                        {
                            //new $.$hDPm.LCFCC$1.ServiceInjectAttribute()
                            const $t3 = $.$hDPm.LCFCC$1.ServiceInjectAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCC$1.ServiceInjectAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QoDz.LCIRCP.SettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $JzDxkc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2408769,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $KYAxbk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2408769,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592343361)
            
            static $h = 2408769;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592343361),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2408769,
      "h": 8592343361,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592343361)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297376065),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2408769,
      "h": 4297376065,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297376065)
  ],
  "h": 2408769
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.SettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}SettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2408769)
        
        

        //--TRIMMABLE-BOUNDARY-START(3785025)
        $asm.$cls(`$QoDz.LCIRC.Utility`, ($self) => class Utility
        {
            //--TRIMMABLE-BOUNDARY-START(17183654209)
            static /*ViewConfiguration */ get PopupConfiguration()
            {
                return (() =>
                {
                    //new $.$hDPm.LCFCI.ViewConfiguration()
                    const $t1 = $.$hDPm.LCFCI.ViewConfiguration;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Theme = $.$fPer.LCFC.Theme.None;
                    $i1.Class = "bd";
                    $i1.PageBackgroundTheme = $.$fPer.LCFC.Theme.Card;
                    $i1.BodyAttributes = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "pd");
                        return $i2;
                    })();
                    $i1.ContentAttributes = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                        const $t3 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("field-input-class"), "corner");
                        return $i3;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(17183654209)
            
            //--TRIMMABLE-BOUNDARY-START(12888686913)
            static /*string */ PDFPath(/*this Type*/ component, /*Dictionary<string, object>?*/ parameters, /*IClientUnitOfWork*/ unitOfWork, /*string?*/ fileName, /*string?*/ printContentSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888686913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hostComponentPath = `https://${$.$strNN(unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$RemoteHost)}/RMS/pdfHost?h=${$.$strNN(component.FullName)}&${$.$strNN((parameters !== null ? $.$$.S.String.Join$11($.$$.S.String, /*&*/ 38, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String, parameters, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String))().$ctor(this,  (/**/ p) =>
                {
                    return `${$.$strNN(p.Key)}=${$.$strNN($.$dsp(p.Value, $.$$.S.Object, ($t) => $t.ToString))}`;
                }, $IcAhac ??= {"r":1310721,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":3785025,"h":0,"f":17825794}))) : ""))}`;
                return `https://${$.$strNN(unitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$RemoteHost)}/${$.$strNN("pdf"/*HttpExtension.PdfPath*/)}?url=${$.$strNN($.$swh.SW.HttpUtility.UrlEncode$3(hostComponentPath))}&fileName=${$.$strNN(fileName ?? component.Name)}&contentSelector=${$.$strNN($.$swh.SW.HttpUtility.UrlEncode$3(printContentSelector))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(12888686913)
            
            static $h = 3785025;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183654209),
    {
      "p": 67131050,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593719617,
        "f": 50331681
      },
      "n": "PopupConfiguration",
      "d": 3785025,
      "h": 17183654209,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17183654209)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888686913),
    {
      "r": 1310721,
      "p": [
        {
          "n": "component",
          "p": 188547073
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "printContentSelector",
          "p": 1310721
        }
      ],
      "n": "PDFPath",
      "d": 3785025,
      "h": 12888686913,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12888686913)
  ],
  "h": 3785025
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Utility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Utility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3785025)
        
        

        //--TRIMMABLE-BOUNDARY-START(1687873)
        $asm.$cls(`$QoDz.LCIRC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591622465)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591622465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCPA.Assets, "LivingThing.Core.IOT.RMS.Client", "Pages\\Assets\\Assets", "Assets", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Devices" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 9, null, null, "mdi mdi-account"/*MaterialDesignIconNames.Account*/, 12328240n | 1n | 2n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCPA.Devices, "LivingThing.Core.IOT.RMS.Client", "Pages\\Assets\\Devices", "Devices", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Devices" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 10, null, null, "mdi mdi-devices"/*MaterialDesignIconNames.Devices*/, 12328240n | 1n | 2n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCP.Dashboard, "LivingThing.Core.IOT.RMS.Client", "Pages\\Dashboard", "Dashboard", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 1, null, null, "mdi mdi-view-dashboard"/*MaterialDesignIconNames.ViewDashboard*/, 12328240n | 1n | 2n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCPG.Gateways, "LivingThing.Core.IOT.RMS.Client", "Pages\\Gateways\\Gateways", "Gateways", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Gateways" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 3, null, null, "mdi mdi-access-point"/*MaterialDesignIconNames.AccessPoint*/, 12328240n | 1n | 2n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCPG.GatewaySettings, "LivingThing.Core.IOT.RMS.Client", "Pages\\Gateways\\GatewaySettings", "Gateway Settings", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Gateway/Settings/{ParameterKey}/{*catchAll}" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 3, null, null, "mdi mdi-access-point"/*MaterialDesignIconNames.AccessPoint*/, 12328240n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCP.Settings, "LivingThing.Core.IOT.RMS.Client", "Pages\\Settings", "Settings", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Settings" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 2147483647/*int.MaxValue*/, null, null, "mdi mdi-cog"/*MaterialDesignIconNames.Cog*/, 7600n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCPS.Station, "LivingThing.Core.IOT.RMS.Client", "Pages\\Stations\\Station", "Station", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Station/{ParameterKey}/{*catchAll}" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 3, null, null, "mdi mdi-office-building"/*MaterialDesignIconNames.OfficeBuilding*/, 12328240n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCPS.Stations, "LivingThing.Core.IOT.RMS.Client", "Pages\\Stations\\Stations", "Stations", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Stations" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("iRMS", 3, null, null, "mdi mdi-office-building"/*MaterialDesignIconNames.OfficeBuilding*/, 12328240n | 1n | 2n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$QoDz.LCIRCPS.StationSettings, "LivingThing.Core.IOT.RMS.Client", "Pages\\Stations\\StationSettings", "Station Settings", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/RMS/Station/Settings/{ParameterKey}/{*catchAll}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591622465)
            
            //--TRIMMABLE-BOUNDARY-START(4296655169)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296655169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296655169)
            
            //--TRIMMABLE-BOUNDARY-START(4296655169)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296655169)
            
            static $h = 1687873;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591622465),
    {
      "r": 65537,
      "n": "Build",
      "d": 1687873,
      "h": 8591622465,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591622465)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296655169),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1687873,
      "h": 4296655169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296655169)
  ],
  "h": 1687873
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1687873)
        
        

        //--TRIMMABLE-BOUNDARY-START(442689)
        $asm.$cls(`$QoDz.LCIRC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295409985)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295409985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$QoDz.LCIRC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295409985)
            
            static $h = 442689;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295409985),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 442689,
      "h": 4295409985,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295409985)
  ],
  "h": 442689
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442689)
        
        

        //--TRIMMABLE-BOUNDARY-START(2933057)
        $asm.$cls(`$QoDz.LCIRCPS.StationSettingsTypeDescriptorBuilder`, ($self) => class StationSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592867649)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592867649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QoDz.LCIRCPS.StationSettingsTypeDescriptor()
                        const $t1 = $.$QoDz.LCIRCPS.StationSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qrmQCc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2933057,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QoDz.LCIRCPS.StationSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592867649)
            
            //--TRIMMABLE-BOUNDARY-START(4297900353)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297900353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297900353)
            
            //--TRIMMABLE-BOUNDARY-START(4297900353)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297900353)
            
            static $h = 2933057;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592867649),
    {
      "r": 65537,
      "n": "Register",
      "d": 2933057,
      "h": 8592867649,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592867649)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297900353),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2933057,
      "h": 4297900353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297900353)
  ],
  "h": 2933057
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Stations${separator}StationSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2933057)
        
        

        //--TRIMMABLE-BOUNDARY-START(2539841)
        $asm.$cls(`$QoDz.LCIRCP.SettingsTypeDescriptorBuilder`, ($self) => class SettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592474433)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592474433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QoDz.LCIRCP.SettingsTypeDescriptor()
                        const $t1 = $.$QoDz.LCIRCP.SettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Client.Pages.Settings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yJtiRd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2539841,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QoDz.LCIRCP.Settings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592474433)
            
            //--TRIMMABLE-BOUNDARY-START(4297507137)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297507137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297507137)
            
            //--TRIMMABLE-BOUNDARY-START(4297507137)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297507137)
            
            static $h = 2539841;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592474433),
    {
      "r": 65537,
      "n": "Register",
      "d": 2539841,
      "h": 8592474433,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592474433)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297507137),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2539841,
      "h": 4297507137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297507137)
  ],
  "h": 2539841
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.SettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}SettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2539841)
        
        

        //--TRIMMABLE-BOUNDARY-START(2801985)
        $asm.$cls(`$QoDz.LCIRCPS.StationSettingsCustomAttributesProvider`, ($self) => class StationSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297769281)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297769281)
            
            //--TRIMMABLE-BOUNDARY-START(8592736577)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592736577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QoDz.LCIRCPS.StationSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$hDPm.LCFCC$1.ServiceInjectAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCC$1.ServiceInjectAttribute), [(() =>
                        {
                            //new $.$hDPm.LCFCC$1.ServiceInjectAttribute()
                            const $t3 = $.$hDPm.LCFCC$1.ServiceInjectAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCC$1.ServiceInjectAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QoDz.LCIRCPS.StationSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $OpGvpb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2801985,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $nQXyhk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2801985,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592736577)
            
            static $h = 2801985;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592736577),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2801985,
      "h": 8592736577,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592736577)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297769281),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2801985,
      "h": 4297769281,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297769281)
  ],
  "h": 2801985
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Stations${separator}StationSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2801985)
        
        

        //--TRIMMABLE-BOUNDARY-START(180545)
        $asm.$cls(`$QoDz._LCIRCSS.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295147841)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295147841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295147841)
            
            static $h = 180545;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295147841),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 180545,
      "h": 4295147841,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295147841)
  ],
  "h": 180545
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.RMS.Client.Shared.StationView.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}StationView${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180545)
        
        

        //--TRIMMABLE-BOUNDARY-START(246081)
        $asm.$cls(`$QoDz._LCIRCST.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295213377)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295213377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295213377)
            
            //--TRIMMABLE-BOUNDARY-START(8590180673)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590180673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590180673)
            
            static $h = 246081;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295213377),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 246081,
      "h": 4295213377,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295213377),
//--TRIMMABLE-BOUNDARY-START(8590180673),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 246081,
      "h": 8590180673,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590180673)
  ],
  "h": 246081
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.RMS.Client.Shared.TopHeader.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}TopHeader${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(246081)
        
        

        //--TRIMMABLE-BOUNDARY-START(115009)
        $asm.$cls(`$QoDz._LCIRCSO.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295082305)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295082305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295082305)
            
            static $h = 115009;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295082305),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 115009,
      "h": 4295082305,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295082305)
  ],
  "h": 115009
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.RMS.Client.Shared.Onboard.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}Onboard${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(115009)
        
        

        //--TRIMMABLE-BOUNDARY-START(3719489)
        $asm.$cls(`$QoDz.LCIRC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298686785)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298686785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$QoDz.LCIRCP.SettingsTypeDescriptorBuilder.Register();
                $.$QoDz.LCIRCPS.StationSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298686785)
            
            static $h = 3719489;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298686785),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3719489,
      "h": 4298686785,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298686785)
  ],
  "h": 3719489
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3719489)
        
        

        //--TRIMMABLE-BOUNDARY-START(3129665)
        $asm.$cls(`$QoDz.LCIRCS.RMSStationAttendantPolicyRequirement`, ($self) => class RMSStationAttendantPolicyRequirement extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4298096961)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298096961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298096961)
            
            //--TRIMMABLE-BOUNDARY-START(4298096961)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298096961)
            
            static $h = 3129665;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298096961),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3129665,
      "h": 4298096961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298096961)
  ],
  "h": 3129665
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Services.RMSStationAttendantPolicyRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Services${separator}RMSStationAttendantPolicyRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3129665)
        
        

        //--TRIMMABLE-BOUNDARY-START(2998593)
        $asm.$cls(`$QoDz.LCIRC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592933185)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592933185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$QoDz.LCIRC.NavigationMenuBuilder.Build();
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$QoDz.LCIRCV.RMSClientAppViewModel, services);
                $.$sZVd.LCFCA.ClientApplicationExtension.AddApplication($.$QoDz.LCIRCP.Dashboard, services, (() =>
                {
                    //new $.$sZVd.LCFCA.ClientApplicationModel$$($.$QoDz.LCIRCP.Dashboard)()
                    const $t1 = $.$sZVd.LCFCA.ClientApplicationModel$$($.$QoDz.LCIRCP.Dashboard);
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Categories = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "IOT", "Business" ], null, null);
                    $i1.Name = "RMS";
                    $i1.Title = "iSmart RMS";
                    $i1.Description = "IOT, Cloud and AI driven remote monitoring system management and reporting";
                    $i1.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "RMS/Home", "RMS" ], null, null);
                    $i1.Features = 1120/*ApplicationServiceFeatures.Default*/ | 16/*ApplicationServiceFeatures.UseRouter*/;
                    $i1.Theme = $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#00AEFF";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })());
                    $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("_content/LivingThing.Core.IOT.RMS.Client.Blazor/logo.png");
                    return $i1;
                })());
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$maa.MAA.IAuthorizationHandler, $.$QoDz.LCIRCS.RMSStationAttendantPolicyHandler, services);
                $.$maa.MED.AuthorizationServiceCollectionExtensions.AddAuthorizationCore(services, new ($.$$.S.Action$$($.$maa.MAA.AuthorizationOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    options.AddPolicy$1("Attendant", new ($.$$.S.Action$$($.$maa.MAA.AuthorizationPolicyBuilder))().$ctor(this,  (/*policy*/ policy) =>
                    {
                        return policy.AddRequirements($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$maa.MAA.IAuthorizationRequirement), [ new $.$QoDz.LCIRCS.RMSStationAttendantPolicyRequirement().$ctor$1() ], null, null));
                    }, $LPcMmf ??= {"r":65537,"p":[{"n":"policy","p":721008}],"n":"","d":2998593,"h":0,"f":17825794}));
                }, $evJDmd ??= {"r":65537,"p":[{"n":"options","p":589936}],"n":"","d":2998593,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget), $.$QoDz.LCIRCDD$1.DieselTankCoverDeviceRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget), $.$QoDz.LCIRCDD$2.DoorOpenedDeviceRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget), $.$QoDz.LCIRCDD.DCVoltageDeviceRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget), $.$QoDz.LCIRCDR$1.RelayCoilDeviceRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget), $.$QoDz.LCIRCDR.RegisterViewDeviceRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.CameraDevice.CameraWidget), $.$QoDz.LCIRCDC.CameraDeviceRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592933185)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$QoDz.LCIRC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297965889)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297965889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297965889)
            
            //--TRIMMABLE-BOUNDARY-START(4297965889)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297965889)
            
            static $h = 2998593;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592933185),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2998593,
      "h": 8592933185,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592933185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297965889),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2998593,
      "h": 4297965889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297965889)
  ],
  "h": 2998593
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2998593)
        
        

        //--TRIMMABLE-BOUNDARY-START(1622337)
        $asm.$cls(`$QoDz.LCIRC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181491521)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCDC.CameraView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCDC.CameraView().$ctor$5();
                    }, $UTaDok ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCDD.DCVoltageView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCDD.DCVoltageView().$ctor$5();
                    }, $InutHh ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCDD$1.DieselTankCoverView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCDD$1.DieselTankCoverView().$ctor$5();
                    }, $yjfjcf ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCDD$2.DoorOpenedView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCDD$2.DoorOpenedView().$ctor$5();
                    }, $HPgKjg ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCDR.RegisterView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCDR.RegisterView().$ctor$5();
                    }, $HAXfod ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCDR$1.RelayCoilView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCDR$1.RelayCoilView().$ctor$5();
                    }, $RuyCSj ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRC.LandingPageLayout.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRC.LandingPageLayout().$ctor$3();
                    }, $HPIzwc ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRC.LandingPageLayout2.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRC.LandingPageLayout2().$ctor$3();
                    }, $AAVCCa ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRC.MainLayout.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRC.MainLayout().$ctor$5();
                    }, $wMULvi ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCPA.Assets.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCPA.Assets().$ctor$3();
                    }, $ZTNxqb ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCPA.Devices.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCPA.Devices().$ctor$3();
                    }, $qcFyRf ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCP.Dashboard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCP.Dashboard().$ctor$4();
                    }, $AsHLDb ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCPG.Gateways.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCPG.Gateways().$ctor$3();
                    }, $NfRjWb ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCP.Index.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCP.Index().$ctor$3();
                    }, $uOBYOg ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCP.Login.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCP.Login().$ctor$3();
                    }, $UmIJbg ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCP.Pricing.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCP.Pricing().$ctor$3();
                    }, $FpEdAf ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCP.Settings.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCP.Settings().$ctor$3();
                    }, $nSfwrh ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCPS.Station.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCPS.Station().$ctor$5();
                    }, $UXqFIc ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCPS.Stations.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCPS.Stations().$ctor$3();
                    }, $lkdpHk ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCPS.StationSettings.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCPS.StationSettings().$ctor$5();
                    }, $oYrNyj ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCS$1.Onboard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCS$1.Onboard().$ctor$3();
                    }, $hBytcj ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCS$1.StationView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCS$1.StationView().$ctor$5();
                    }, $CPBSuk ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QoDz.LCIRCS$1.NoActionTopHeader.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QoDz.LCIRCS$1.NoActionTopHeader().$ctor$5();
                    }, $XjwuQk ??= {"r":2752627,"n":"","d":1622337,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17181491521)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4296589633)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296589633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296589633)
            
            //--TRIMMABLE-BOUNDARY-START(4296589633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296589633)
            
            static $h = 1622337;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181491521),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886524225,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 1622337,
      "h": 17181491521,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181491521)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296589633),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1622337,
      "h": 4296589633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296589633)
  ],
  "h": 1622337
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1622337)
        
        

        //--TRIMMABLE-BOUNDARY-START(4178241)
        $asm.$cls(`$QoDz.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299145537)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299145537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299145537)
            
            //--TRIMMABLE-BOUNDARY-START(4299145537)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299145537)
            
            static $h = 4178241;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299145537),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4178241,
      "h": 4299145537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299145537)
  ],
  "h": 4178241
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4178241)
        
        

        //--TRIMMABLE-BOUNDARY-START(4243777)
        $asm.$cls(`$QoDz.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299211073)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299211073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299211073)
            
            //--TRIMMABLE-BOUNDARY-START(4299211073)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299211073)
            
            static $h = 4243777;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299211073),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4243777,
      "h": 4299211073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299211073)
  ],
  "h": 4243777,
  "a": [
    {
      "t": 4178241,
      "c": 4299145537
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4243777)
        
        

        //--TRIMMABLE-BOUNDARY-START(3588417)
        $asm.$str(`$QoDz.LCIRCS$1.TopHeaderContext`, ($self) => class TopHeaderContext extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34363326785)
            /*bool*/ IsMobile = false;
            //--TRIMMABLE-BOUNDARY-END(34363326785)
            
            //--TRIMMABLE-BOUNDARY-START(38658294081)
            /*string?*/ ItemClass = null;
            //--TRIMMABLE-BOUNDARY-END(38658294081)
            
            //--TRIMMABLE-BOUNDARY-START(12888490305)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888490305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888490305)
            
            //--TRIMMABLE-BOUNDARY-START(12888490305)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12888490305)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.IsMobile = this.IsMobile;
                copy.ItemClass = this.ItemClass;
                return copy;
            }
            static $h = 3588417;
            static $z = 5;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363326785),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478424897,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47248228673,
        "f": 83886081
      },
      "n": "IsMobile",
      "d": 3588417,
      "h": 34363326785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363326785),
//--TRIMMABLE-BOUNDARY-START(38658294081),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068359489,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838163265,
        "f": 83886081
      },
      "n": "ItemClass",
      "d": 3588417,
      "h": 38658294081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658294081)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888490305),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3588417,
      "h": 12888490305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888490305)
  ],
  "h": 3588417
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.TopHeaderContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}TopHeaderContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3588417)
        
        

        //--TRIMMABLE-BOUNDARY-START(1753409)
        $asm.$cls(`$QoDz.LCIRCP.AboutUs`, ($self) => class AboutUs extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591688001)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591688001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionName", "Title");
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(3, "<h2>About Us</h2>");
                }), $BJwyWe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1753409,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(4, "\r\n\r\n");
                __builder.AddMarkupContent(5, "<section class=\"bg-card pd-10\"><div class=\"container text-center\"><h1>We are on a mission to ensure integrity and accountability at the RMS.</h1>\r\n        <h1>We envision a nearest future where RMS owners run their businesses with peace of mind.</h1>\r\n        <h1>We are your closest ally having understood what your pain points are at the RMS.</h1>\r\n        <h1>We provide Fuel Flow Intelligence and Insight into your RMS operations.</h1>\r\n        <h1>We ensure you are at the top of things and in the loop on the operations of your RMS, even when you are not physically there.</h1>\r\n        <h1>We are the <b class=\"cl-primary\">iRMS</b> Team.</h1></div></section>");
            }
            //--TRIMMABLE-BOUNDARY-END(8591688001)
            
            //--TRIMMABLE-BOUNDARY-START(4296720705)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296720705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296720705)
            
            //--TRIMMABLE-BOUNDARY-START(4296720705)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296720705)
            
            static $h = 1753409;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591688001),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1753409,
      "h": 8591688001,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591688001)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296720705),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1753409,
      "h": 4296720705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296720705)
  ],
  "h": 1753409,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1491265,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/AboutUs",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.AboutUs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}AboutUs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1753409)
        
        

        //--TRIMMABLE-BOUNDARY-START(2081089)
        $asm.$cls(`$QoDz.LCIRCPG.GatewaySettings`, ($self) => class GatewaySettings extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8592015681)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592015681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592015681)
            
            //--TRIMMABLE-BOUNDARY-START(4297048385)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297048385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297048385)
            
            //--TRIMMABLE-BOUNDARY-START(4297048385)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297048385)
            
            static $h = 2081089;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592015681),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2081089,
      "h": 8592015681,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592015681)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297048385),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2081089,
      "h": 4297048385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297048385)
  ],
  "h": 2081089
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Gateways.GatewaySettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Gateways${separator}GatewaySettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2081089)
        
        

        //--TRIMMABLE-BOUNDARY-START(311617)
        $asm.$cls(`$QoDz.LCIRC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590246209)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590246209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590246209)
            
            //--TRIMMABLE-BOUNDARY-START(4295278913)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295278913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295278913)
            
            //--TRIMMABLE-BOUNDARY-START(4295278913)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295278913)
            
            static $h = 311617;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590246209),
    {
      "r": 65537,
      "n": "Execute",
      "d": 311617,
      "h": 8590246209,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590246209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295278913),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 311617,
      "h": 4295278913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295278913)
  ],
  "h": 311617
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311617)
        
        

        //--TRIMMABLE-BOUNDARY-START(377153)
        $asm.$cls(`$QoDz.LCIRC._NavigationMenu`, ($self) => class _NavigationMenu extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590311745)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590311745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "exclude /Pages/Pricing\r\nexclude /Pages/AboutUs\r\nexclude /Pages/pdfHost\r\nexclude /Pages/Login\r\nexclude /Pages/Index\r\nexclude /Pages/Attendants/AttendantLoggedInView\r\n\r\n\r\n");
            }
            //--TRIMMABLE-BOUNDARY-END(8590311745)
            
            //--TRIMMABLE-BOUNDARY-START(4295344449)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295344449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295344449)
            
            //--TRIMMABLE-BOUNDARY-START(4295344449)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295344449)
            
            static $h = 377153;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590311745),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 377153,
      "h": 8590311745,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590311745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295344449),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 377153,
      "h": 4295344449,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295344449)
  ],
  "h": 377153
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client._NavigationMenu`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}_NavigationMenu`; }
        });
        //--TRIMMABLE-BOUNDARY-END(377153)
        
        

        //--TRIMMABLE-BOUNDARY-START(1032513)
        $asm.$cls(`$QoDz.LCIRCDE.EnergyMeterView`, ($self) => class EnergyMeterView extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590967105)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590967105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590967105)
            
            //--TRIMMABLE-BOUNDARY-START(4295999809)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295999809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295999809)
            
            //--TRIMMABLE-BOUNDARY-START(4295999809)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295999809)
            
            static $h = 1032513;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590967105),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1032513,
      "h": 8590967105,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590967105)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295999809),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1032513,
      "h": 4295999809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295999809)
  ],
  "h": 1032513
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.EnergyMeter.EnergyMeterView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}EnergyMeter${separator}EnergyMeterView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1032513)
        
        

        //--TRIMMABLE-BOUNDARY-START(3653953)
        $asm.$cls(`$QoDz.LCIRCS$1.UtilityView`, ($self) => class UtilityView extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8593588545)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593588545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8593588545)
            
            //--TRIMMABLE-BOUNDARY-START(17183523137)
            static /*RenderFragment? */ Trend(/*string?*/ value, /*double*/ now, /*double?*/ last)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183523137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (last === null)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(0, value);
                    }, $MAqMcl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3653953,"h":0,"f":17825794});
                }
                if ($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(last) === 0 && now === 0)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(1, value);
                    }, $ggqNMf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3653953,"h":0,"f":17825794});
                }
                /*var*/ let perc = $.$$.S.Nullable$$($.$$.S.Double).Value$get.call(last) === 0 ? (now !== 0 ? 100 : 0) : (now - $.$$.S.Nullable$$($.$$.S.Double).Value$get.call(last)) * 100 / $.$$.S.Nullable$$($.$$.S.Double).Value$get.call(last);
                if (perc === 0)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(2, value);
                    }, $WZJEZg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3653953,"h":0,"f":17825794});
                }
                if (perc > 0)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(3, "\r\n    ");
                        __builder2.OpenElement(4, "span");
                        __builder2.AddAttribute$5(5, "class", "mgy-a");
                        __builder2.AddContent$4(6, value);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(7, "\r\n    ");
                        __builder2.OpenElement(8, "small");
                        __builder2.AddAttribute$5(9, "class", "cl-success text-right fsz-10 mgl-1 mgy-a stack lh-1");
                        /*double?*/ let __ca1__;
                        __builder2.AddAttribute$5(10, "title", $.$strNN($.$strNN("Up" + " from") + " ") + $.$strNN((((__ca1__ = last) !== null ? $.$$.S.Double.ToString$3.call($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(__ca1__), "#,##0") : null))));
                        __builder2.AddMarkupContent(11, "<img src=\"_content/LivingThing.Core.IOT.RMS.Client.Blazor/uptrend.svg\" class=\"hx-01\">\r\n        ");
                        __builder2.AddContent$4(12, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(perc, "0", false));
                        __builder2.AddMarkupContent(13, "%\r\n    ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(14, "\r\n");
                    }, $MqEfbl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3653953,"h":0,"f":17825794});
                }
                else 
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(15, "\r\n    ");
                        __builder2.OpenElement(16, "span");
                        __builder2.AddAttribute$5(17, "class", "mgy-a");
                        __builder2.AddContent$4(18, value);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(19, "\r\n    ");
                        __builder2.OpenElement(20, "small");
                        __builder2.AddAttribute$5(21, "class", "cl-error text-right fsz-10 mgl-1 mgy-a stack lh-1");
                        /*double?*/ let __ca2__;
                        __builder2.AddAttribute$5(22, "title", $.$strNN($.$strNN("Down" + " from") + " ") + $.$strNN((((__ca2__ = last) !== null ? $.$$.S.Double.ToString$3.call($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(__ca2__), "#,##0") : null))));
                        __builder2.AddMarkupContent(23, "<img src=\"_content/LivingThing.Core.IOT.RMS.Client.Blazor/downtrend.svg\" class=\"hx-01\">\r\n        ");
                        __builder2.AddContent$4(24, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(perc, "0", false));
                        __builder2.AddMarkupContent(25, "%\r\n    ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(26, "\r\n");
                    }, $WKRZNk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3653953,"h":0,"f":17825794});
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183523137)
            
            //--TRIMMABLE-BOUNDARY-START(12888555841)
            static /*RenderFragment */ DashboardCard(/*string*/ icon, /*string*/ label, /*OneOf<string?, RenderFragment?>*/ value, /*string?*/ link, /*RenderFragment?*/ more)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888555841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (link !== null)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(27, "a");
                        __builder2.AddAttribute$5(28, "href", link);
                        __builder2.AddAttribute$5(29, "class", "bg-card corner clip bd row");
                        __builder2.OpenElement(30, "div");
                        __builder2.AddAttribute$5(31, "class", "bg-primary-01 flex pos-rel corner-br-5 col-2");
                        __builder2.AddMarkupContent(32, "<div class=\"wx-03 hx-03 pos-abs bg-card round r-0 t-0 mgr--4\"></div>\r\n            ");
                        __builder2.OpenElement(33, "i");
                        __builder2.AddAttribute$5(34, "class", $.$strNN($.$strNN($.$strNN($.$strNN("mg-a" + " ") + $.$strNN((icon))) + " fsz-100") + " cl-primary") + " op-7");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(35, "\r\n        ");
                        __builder2.OpenElement(36, "div");
                        __builder2.AddAttribute$5(37, "class", "pd stack col-8");
                        __builder2.OpenElement(38, "h3");
                        __builder2.AddAttribute$5(39, "class", "mg-0 text-right op-8");
                        __builder2.AddContent$4(40, label);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(41, "\r\n            ");
                        __builder2.OpenElement(42, "h2");
                        __builder2.AddAttribute$5(43, "class", "mg-0 text-right flex flex-end");
                        if (value.IsT0)
                        {
                            __builder2.AddContent$4(44, value.AsT0);
                        }
                        else if (value.IsT1)
                        {
                            __builder2.AddContent$1(45, value.AsT1);
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(46, "\r\n            ");
                        __builder2.AddContent$1(47, more);
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $gaYMPh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3653953,"h":0,"f":17825794});
                }
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(48, "div");
                    __builder2.AddAttribute$5(49, "class", "bg-card corner clip bd row");
                    __builder2.OpenElement(50, "div");
                    __builder2.AddAttribute$5(51, "class", "bg-primary-01 flex pos-rel corner-br-5 col-2");
                    __builder2.AddMarkupContent(52, "<div class=\"wx-03 hx-03 pos-abs bg-card round r-0 t-0 mgr--4\"></div>\r\n            ");
                    __builder2.OpenElement(53, "i");
                    __builder2.AddAttribute$5(54, "class", $.$strNN($.$strNN($.$strNN($.$strNN("mg-a" + " ") + $.$strNN((icon))) + " fsz-100") + " cl-primary") + " op-7");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(55, "\r\n        ");
                    __builder2.OpenElement(56, "div");
                    __builder2.AddAttribute$5(57, "class", "pd stack col-8");
                    __builder2.OpenElement(58, "h3");
                    __builder2.AddAttribute$5(59, "class", "mg-0 text-right op-8");
                    __builder2.AddContent$4(60, label);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(61, "\r\n            ");
                    __builder2.OpenElement(62, "h2");
                    __builder2.AddAttribute$5(63, "class", "mg-0 text-right flex flex-end");
                    if (value.IsT0)
                    {
                        __builder2.AddContent$4(64, value.AsT0);
                    }
                    else if (value.IsT1)
                    {
                        __builder2.AddContent$1(65, value.AsT1);
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(66, "\r\n            ");
                    __builder2.AddContent$1(67, more);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(68, "\r\n");
                }, $AZbuOa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3653953,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12888555841)
            
            //--TRIMMABLE-BOUNDARY-START(4298621249)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298621249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298621249)
            
            //--TRIMMABLE-BOUNDARY-START(4298621249)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298621249)
            
            static $h = 3653953;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593588545),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3653953,
      "h": 8593588545,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593588545),
//--TRIMMABLE-BOUNDARY-START(17183523137),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "now",
          "p": 1179649
        },
        {
          "n": "last",
          "p": $.$typeNullable($.$$.S.Double).$h
        }
      ],
      "n": "Trend",
      "d": 3653953,
      "h": 17183523137,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17183523137),
//--TRIMMABLE-BOUNDARY-START(12888555841),
    {
      "r": 6881395,
      "p": [
        {
          "n": "icon",
          "p": 1310721
        },
        {
          "n": "label",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$mac.MAC.RenderFragment).$h
        },
        {
          "n": "link",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "more",
          "p": 6881395,
          "f": 65
        }
      ],
      "n": "DashboardCard",
      "d": 3653953,
      "h": 12888555841,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12888555841)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298621249),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3653953,
      "h": 4298621249,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298621249)
  ],
  "h": 3653953
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.UtilityView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}UtilityView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3653953)
        
        

        //--TRIMMABLE-BOUNDARY-START(1818945)
        $asm.$cls(`$QoDz.LCIRCPA.Assets`, ($self) => class Assets extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21476655425)
            /*string */ get OptimizedComponentName()
            {
                return "assets";
            }
            //--TRIMMABLE-BOUNDARY-END(21476655425)
            
            //--TRIMMABLE-BOUNDARY-START(8591753537)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591753537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591753537)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296786241)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296786241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296786241)
            
            //--TRIMMABLE-BOUNDARY-START(4296786241)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296786241)
            
            static $h = 1818945;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476655425),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181688129,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1818945,
      "h": 21476655425,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476655425)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591753537),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1818945,
      "h": 8591753537,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591753537)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296786241),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1818945,
      "h": 4296786241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296786241)
  ],
  "h": 1818945,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "iRMS",
          "t": 1310721
        },
        {
          "v": 9,
          "t": 655361
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "v": "mdi mdi-account",
          "t": 1310721
        },
        {
          "v": 12328243,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1556801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/__RMS/Devices__",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Assets.Assets`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Assets${separator}Assets`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1818945)
        
        

        //--TRIMMABLE-BOUNDARY-START(2212161)
        $asm.$cls(`$QoDz.LCIRCP.Login`, ($self) => class Login extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21477048641)
            /*string */ get OptimizedComponentName()
            {
                return "login";
            }
            //--TRIMMABLE-BOUNDARY-END(21477048641)
            
            //--TRIMMABLE-BOUNDARY-START(8592146753)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592146753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hv-10 bg-fill row col-5");
                __builder.AddAttribute$5(2, "style", $.$strNN($.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("rmsBg.png", true, false, false)))) + ");background-position:") + " left,top;");
                if ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.Width ?? null) > 1000)
                {
                    __builder.AddMarkupContent(3, "<div class=\"pd-10 stack\"><h1 class=\"cl-primary fsz-50 mg-a\">iSmart RMS</h1></div>");
                }
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", $.$strNN($.$strNN($.$strNN($.$strNN("mgl-a" + " miwx-") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsDesktop ?? null) ?? false) ? "5" : "3"))) + " pd") + " stack") + " pd-10");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-card" + " mgt-a") + " mgb-5") + " pd") + " mgx-a") + "  miwx-") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsDesktop ?? null) ?? false) ? "5" : "3")));
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "flex");
                __builder.OpenElement(10, "img");
                __builder.AddAttribute$5(11, "src", this.ResolvePath("logo.png", true, false, false));
                __builder.AddAttribute$5(12, "class", "mahx-1 mawx-1 mgl-a mgy-a");
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n                ");
                __builder.AddMarkupContent(14, "<h1 class=\"text-center head mgl mgr-a mgy-a\">Login</h1>");
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n            ");
                __builder.AddMarkupContent(16, "<p class=\"text-center\">Begin your journey to an accountable filling station!</p>");
                __builder.CloseElement();
                __builder.AddMarkupContent(17, "\r\n        ");
                __builder.OpenElement(18, "div");
                __builder.AddAttribute$5(19, "class", $.$strNN($.$strNN($.$strNN("mgx-a" + " mgb-a") + " bg-card") + " miwx-") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsDesktop ?? null) ?? false) ? "5" : "3")));
                __builder.OpenElement(20, "div");
                __builder.AddAttribute$5(21, "class", "pd bg-card");
                __builder.AddContent$1(22, this.UnitOfWork.LCFCI$IClientUnitOfWork$ClientAuthentication.LCFCI$IClientAuthenticationService$Authenticate((() =>
                {
                    //new $.$hDPm.LCFCI.AuthenticationParameter()
                    const $t1 = $.$hDPm.LCFCI.AuthenticationParameter;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Flags = 7/*LoginActionFlags.Default*/ | (this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$IsMobile ? 0/*LoginActionFlags.None*/ : 8/*LoginActionFlags.AllowDemoLogin*/);
                    return $i1;
                })()));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8592146753)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4297179457)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297179457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297179457)
            
            //--TRIMMABLE-BOUNDARY-START(4297179457)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297179457)
            
            static $h = 2212161;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477048641),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182081345,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2212161,
      "h": 21477048641,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21477048641)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592146753),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2212161,
      "h": 8592146753,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592146753)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297179457),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2212161,
      "h": 4297179457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297179457)
  ],
  "h": 2212161,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Login",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Login`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Login`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2212161)
        
        

        //--TRIMMABLE-BOUNDARY-START(1425729)
        $asm.$cls(`$QoDz.LCIRC.LandingPageLayout`, ($self) => class LandingPageLayout extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(30066196801)
            /*RenderFragment?*/ Body = null;
            //--TRIMMABLE-BOUNDARY-END(30066196801)
            
            //--TRIMMABLE-BOUNDARY-START(133145411905)
            /*RMSClientAppViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(133145411905)
            
            //--TRIMMABLE-BOUNDARY-START(25771229505)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(25771229505)
            
            //--TRIMMABLE-BOUNDARY-START(85900771649)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(85900771649)
            
            //--TRIMMABLE-BOUNDARY-START(90195738945)
            /*string */ get OptimizedComponentName()
            {
                return "landingpagelayout";
            }
            //--TRIMMABLE-BOUNDARY-END(90195738945)
            
            //--TRIMMABLE-BOUNDARY-START(128850444609)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850444609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Body":
                    this.Body = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(128850444609)
            
            //--TRIMMABLE-BOUNDARY-START(81605804353)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605804353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ViewModel = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(81605804353)
            
            //--TRIMMABLE-BOUNDARY-START(34361164097)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361164097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<style>\r\n    body {\r\n        -font-family: cursive !important;\r\n        font-size: 20px !important;\r\n    }\r\n\r\n        body button {\r\n            -font-family: cursive !important;\r\n            font-size: 20px !important;\r\n        }\r\n\r\n    p {\r\n        line-height: 2;\r\n    }\r\n\r\n    section > div {\r\n        max-width: 1200px;\r\n        margin: 0 auto;\r\n    }\r\n\r\n    .section {\r\n        max-width: 1200px;\r\n        margin: 0 auto;\r\n    }\r\n\r\n    input {\r\n        font-size: 30px;\r\n        -font-family: cursive !important;\r\n    }\r\n</style>\r\n\r\n");
                __builder.OpenElement(1, "div");
                __builder.AddAttribute$5(2, "class", "lp RMS");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "hv-9 bg-fill stack pos-rel");
                __builder.AddAttribute$5(5, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("station.jpg", true, false, false)))) + ");");
                __builder.OpenElement(6, "LandingPageNavigationBar");
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n        ");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "pos-abs r-0 b-0 mgb-10 mgr-10 z-1");
                __builder.OpenElement(10, "img");
                __builder.AddAttribute$5(11, "src", this.ResolvePath("dashondevices.png", true, false, false));
                __builder.AddAttribute$5(12, "class", "hv-4 op-9");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n        ");
                __builder.AddMarkupContent(14, "<div class=\"flex mawx-6 z-2 mgy-a\" style=\"margin-left: 7%;\"><div class=\"mgy-a pd-10 bg-card-09 stack\"><h1 class=\"mgb-0\">\r\n                    iRMS\r\n                    <i class=\"mdi mdi-chart-line cl-primary\"></i></h1>\r\n                <h3 class=\"mgt-0\">\r\n                    Secure + Highly Scalable RMS management\r\n                    solution powered by IOT, Cloud and AI.\r\n                </h3>\r\n                <p class=\"mgt-0\">iRMS install and deploy in minutes. No downtime.</p>\r\n                <a class=\"bg-primary pdx-20 pdy-5 fsz-20 text-center\" href=\"RMS?autoLogin=demo\">View Demo ></a>\r\n                <a class=\"bg-primary pdx-20 pdy-5 fsz-20 mgt-10  text-center\" href=\"RMS/Pricing\">Get Started ></a></div></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n\r\n    ");
                __builder.AddContent$1(16, this.Body);
                __builder.AddMarkupContent(17, "\r\n\r\n    ");
                __builder.OpenElement(18, "div");
                __builder.AddAttribute$5(19, "class", "bg-black pd-10 row responsive col-3");
                __builder.OpenElement(20, "div");
                __builder.AddAttribute$5(21, "class", "stack miwx-3");
                __builder.OpenElement(22, "div");
                __builder.AddAttribute$5(23, "class", "flex");
                __builder.OpenElement(24, "img");
                __builder.AddAttribute$5(25, "src", this.ResolvePath("nozzle.png", true, false, false));
                __builder.AddAttribute$5(26, "class", "hx-05");
                __builder.CloseElement();
                __builder.AddMarkupContent(27, "\r\n                ");
                __builder.AddMarkupContent(28, "<h2 class=\"mgy-a mgl\"><span class=\"cl-primary\">i</span>RMS\r\n                </h2>");
                __builder.CloseElement();
                __builder.AddMarkupContent(29, "\r\n            ");
                __builder.AddMarkupContent(30, "<small class=\"op-7 mgt-2\">Powered by iSmart\u2122</small>\r\n            ");
                __builder.AddMarkupContent(31, "<small class=\"mg-0\">By SAKE INNOVATIONS AND TECHNOLOGIES</small>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(34361164097)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21476262209)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476262209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476262209)
            
            //--TRIMMABLE-BOUNDARY-START(21476262209)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476262209)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133145411905)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(133145411905)
                
                //--TRIMMABLE-BOUNDARY-START(25771229505)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(25771229505)
                
                //--TRIMMABLE-BOUNDARY-START(85900771649)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(85900771649)
                
            }
            static $h = 1425729;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066196801),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541033281,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375608129,
        "f": 83886081
      },
      "n": "Body",
      "d": 1425729,
      "h": 30066196801,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066196801),
//--TRIMMABLE-BOUNDARY-START(133145411905),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310837057,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555477313,
        "f": 83886081
      },
      "n": "ViewModel",
      "d": 1425729,
      "h": 133145411905,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145411905),
//--TRIMMABLE-BOUNDARY-START(25771229505),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951098689,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785673537,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 1425729,
      "h": 25771229505,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771229505),
//--TRIMMABLE-BOUNDARY-START(85900771649),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130967873,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965542721,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1425729,
      "h": 85900771649,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900771649),
//--TRIMMABLE-BOUNDARY-START(90195738945),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720902465,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1425729,
      "h": 90195738945,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90195738945)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850444609),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1425729,
      "h": 128850444609,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850444609),
//--TRIMMABLE-BOUNDARY-START(81605804353),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1425729,
      "h": 81605804353,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605804353),
//--TRIMMABLE-BOUNDARY-START(34361164097),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1425729,
      "h": 34361164097,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361164097)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476262209),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1425729,
      "h": 21476262209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476262209)
  ],
  "h": 1425729
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.LandingPageLayout`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}LandingPageLayout`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1425729)
        
        

        //--TRIMMABLE-BOUNDARY-START(2146625)
        $asm.$cls(`$QoDz.LCIRCP.Index`, ($self) => class Index extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21476983105)
            /*string */ get OptimizedComponentName()
            {
                return "index";
            }
            //--TRIMMABLE-BOUNDARY-END(21476983105)
            
            //--TRIMMABLE-BOUNDARY-START(8592081217)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592081217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<section class=\"bg-card pd-10\"><div class=\"container text-center\"><h1>The last RMS station management system you'll need</h1>\r\n        <div class=\"row responsive col-3\"><div><div class=\"mg miwx-15 text-center corner-5 bd pd stack bg-chart1-01 hf\"><h3 class=\"mg-0\">Simple</h3>\r\n                    <i class=\"mdi mdi-hand-pointing-up fsz-100 cl-chart1\"></i>\r\n                    <p>\r\n                        We got rid of all the complexities so you can concentrate on what realy matters, your\r\n                        business of\r\n                        selling fuel.\r\n                    </p></div></div>\r\n            <div><div class=\"mg miwx-15 text-center corner-5 bd pd stack bg-chart1-01 hf\"><h3 class=\"mg-0\">Secure</h3>\r\n                    <i class=\"mdi mdi-shield fsz-100 cl-chart1\"></i>\r\n                    <p>\r\n                        We understand that the internet can be a scary place sometimes, if not thread carefully. We\r\n                        built iRMS\r\n                        from ground up with military grade security.\r\n                    </p></div></div>\r\n            <div><div class=\"mg miwx-15 text-center corner-5 bd pd stack bg-chart1-01 hf\"><h3 class=\"mg-0\">Stay in Control</h3>\r\n                    <i class=\"mdi mdi-controller fsz-100 cl-chart1\"></i>\r\n                    <p>\r\n                        Business can be difficult when you are not there to manage it yourself.\r\n                        With iRMS, you are always in the loop on what happens to your product in your station.\r\n                    </p></div></div></div>\r\n        <p class=\"mgt-15\">\r\n            iRMS is an IOT, Cloud and AI end to end solution that combine hardware,\r\n            web portal and mobile application\r\n            giving you real-time monitoring and control over your fuel.\r\n        </p>\r\n        <div class=\"flex\"><div class=\"mgx-a wx-1 hx-1 bg-chart2-01 round stack\"><i class=\"mdi mdi-devices mgt-a cl-chart2\"></i>\r\n                <h3 class=\"mg-0\">IOT</h3>\r\n                <small class=\"mgb-a\">device</small></div>\r\n            <div class=\"flex fill\"><i class=\"mdi mdi-arrow-right mgy-a cl-chart2\"></i>\r\n                <div class=\"bd mgy-a bd-chart2 fill\"></div>\r\n                <i class=\"mdi mdi-arrow-right mgy-a cl-chart2\"></i></div>\r\n            <div class=\"mgx-a wx-1 hx-1 bg-chart2-01 round stack\"><i class=\"mdi mdi-cloud mgt-a cl-chart2\"></i>\r\n                <h3 class=\"mgt-0 mgb-a\">Cloud</h3></div>\r\n            <div class=\"flex fill\"><i class=\"mdi mdi-arrow-right mgy-a cl-chart2\"></i>\r\n                <div class=\"bd mgy-a bd-chart2 fill\"></div>\r\n                <i class=\"mdi mdi-arrow-right mgy-a cl-chart2\"></i></div>\r\n            <div class=\"mgx-a wx-1 hx-1 bg-chart2-01 round stack\"><i class=\"mdi mdi-brain mgt-a cl-chart2\"></i>\r\n                <h3 class=\"mgt-0 mgb-a\">AI</h3></div></div>\r\n        <div class=\"flex\"><small class=\"wx-15\">\r\n                Collects data from pump\r\n            </small>\r\n            <small class=\"flex fill\"></small>\r\n            <small class=\"wx-15\">\r\n                Record, persist and analyze data\r\n            </small>\r\n            <small class=\"flex fill\"></small>\r\n            <small class=\"wx-15\">\r\n                Query data, report patterns over chat client\r\n            </small></div></div></section>\r\n\r\n");
                __builder.OpenElement(1, "section");
                __builder.AddAttribute$5(2, "class", "bg--card pd-10");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "row responsive col-2");
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "miwx-3 pd hx-3 bg-contain");
                __builder.AddAttribute$5(7, "style", $.$strNN($.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("nozzle.png", true, false, false)))) + ");background-repeat:") + " no-repeat;");
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n        ");
                __builder.AddMarkupContent(9, "<div class=\"miwx-3 text-center\"><h1 class=\"text-center\">Track every drop</h1>\r\n            <p>\r\n                With a robust tracking tool, report and reconciliation system that track and stop thefts, this is\r\n                the\r\n                last fuel management solution you will ever need.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n\r\n");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "bg-fill");
                __builder.AddAttribute$5(13, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/fuelthief2.jpg", true, false, false)))) + ");");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$5(15, "class", "bg-card-09");
                __builder.OpenElement(16, "div");
                __builder.AddAttribute$5(17, "class", "section pd-10 container");
                __builder.AddMarkupContent(18, "<h1 class=\"text-center\">Is your fuel walking away</h1>\r\n            ");
                __builder.AddMarkupContent(19, "<p class=\"text-center\">\r\n                Fuel theft at RMS is almost becoming a norm. There are various means now\r\n                used to perpetrate this evil.\r\n            </p>\r\n            ");
                __builder.AddMarkupContent(20, "<div class=\"row responsive col-3\"><div><div class=\"mg miwx-15 text-center corner-5 bd pd stack bg-chart2 hf\"><h3 class=\"mg-0\">Totalizer Jam</h3>\r\n                        <i class=\"mdi mdi-counter fsz-50\"></i>\r\n                        <p>\r\n                            They stick a magnet to the magnetic totalizer, preventing it from counting while they\r\n                            make their sales.\r\n                        </p></div></div>\r\n                <div><div class=\"mg miwx-15 text-center corner-5 bd pd stack bg-chart2 hf\"><h3 class=\"mg-0\">Board swapping</h3>\r\n                        <i class=\"mdi mdi-swap-horizontal fsz-50\"></i>\r\n                        <p>\r\n                            Well since the internal board records its own totalizer, thy sap the board for another\r\n                            and sell without your knowledge\r\n                        </p></div></div>\r\n                <div><div class=\"mg miwx-15 text-center corner-5 bd pd stack bg-chart2 hf\"><h3 class=\"mg-0\">Siphon</h3>\r\n                        <i class=\"mdi mdi-pump fsz-50\"></i>\r\n                        <p>\r\n                            Pumping product out of underground tank with an\r\n                            electric or manual pump.\r\n                        </p></div></div></div>\r\n            <div class=\"mg-10\"></div>\r\n            ");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$5(22, "class", "row responsive col-2 text-center");
                __builder.AddMarkupContent(23, "<div class=\"miwx-3 text-center pdx-10 \"><p>\r\n                        I give it to you that if you owns a filling station,\r\n                        you lose at least 25% of your income to different revenue siphon scheme.\r\n                        We know it because we have been there too and we've seen it happens over an over.\r\n                    </p>\r\n                    <p>\r\n                        Are your fuel walking away from your station, unpaid for?\r\n                        iRMS tracks every lifecycle of your\r\n                        product from the point of dipense into your tank to sales into customers tank or container.\r\n                    </p></div>\r\n                ");
                __builder.OpenElement(24, "div");
                __builder.AddAttribute$5(25, "class", "miwx-3 pd mihx-3 bg-fill corner-10");
                __builder.AddAttribute$5(26, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/fuelthief2.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(27, "\r\n\r\n");
                __builder.OpenElement(28, "section");
                __builder.AddAttribute$5(29, "class", "bg-card mgt---10");
                __builder.OpenElement(30, "div");
                __builder.AddAttribute$5(31, "class", "row responsive col-2 pdy pdx-10");
                __builder.OpenElement(32, "div");
                __builder.AddAttribute$5(33, "class", "miwx-3 pd mihx-3 bg-contain bg-no-repeat");
                __builder.AddAttribute$5(34, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/fuelpump.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.AddMarkupContent(35, "\r\n        ");
                __builder.AddMarkupContent(36, "<div class=\"miwx-3\"><h3 class=\"text-center mgb-0\">But my pump is not automatable!</h3>\r\n            <h1 class=\"text-center mgt-0\">Says who?</h1>\r\n            <div class=\"grid colm-15 gap-1\"><div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">Wayne Dart</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">EagleStar</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">Lafeng</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">Sanki</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">Tatsuno</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">Tokheim</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">BlueSky</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-chart5-01 hf\"><h3 class=\"mg-0\">Censtar</h3>\r\n                    <i class=\"mdi mdi-check-all cl-success fsz-30\"></i></div>\r\n                <div class=\"mg text-center corner-5 bd pd stack bg-success-03 hf\"><h3 class=\"mg-0\">Any Pump</h3>\r\n                    <i class=\"mdi mdi-check-circle cl-success fsz-30\"></i></div></div>\r\n            <p>\r\n                US pump? UK Pump? German Pump? Chinese Pump? No Problem.\r\n            </p>\r\n            <p>\r\n                Our state of the art solution works with any fuel pump in the\r\n                market. Infact if you operate an analog pump/meter, iRMS already works with it.\r\n            </p>\r\n            <p>\r\n                As long as your pump is spitting fuel\uD83D\uDE00, we report every outflow.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(37, "\r\n\r\n");
                __builder.OpenElement(38, "section");
                __builder.AddAttribute$5(39, "class", "bg-card mgt-10");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$5(41, "class", "row responsive col-2 bg-card mgt-10");
                __builder.AddMarkupContent(42, "<div class=\"miwx-3 pdx-10 pdy\"><h1 class=\"text-center\">Zero downtime, Zero civil work</h1>\r\n            <p>\r\n                Forget those ages of 2 weeks of installation of an automation system.\r\n                iRMS is installed in 5 minutes.\r\n                And reporting starts immediately.\r\n            </p>\r\n            <p>iRMS is installed directly into your pump head and report every sale happening on the pump</p></div>\r\n        ");
                __builder.OpenElement(43, "div");
                __builder.AddAttribute$5(44, "class", "mihx-3 miwx-3 bg-fill corner-5");
                __builder.AddAttribute$5(45, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/civil-work.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(46, "\r\n\r\n");
                __builder.OpenElement(47, "section");
                __builder.AddAttribute$5(48, "class", "bg-card mgt-10");
                __builder.OpenElement(49, "div");
                __builder.AddAttribute$5(50, "class", "row responsive col-2");
                __builder.OpenElement(51, "div");
                __builder.AddAttribute$5(52, "class", "miwx-3 mihx-45 bg-fill");
                __builder.AddAttribute$5(53, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/att-login.gif", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.AddMarkupContent(54, "\r\n        ");
                __builder.AddMarkupContent(55, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">Attendant Login</h1>\r\n            <p>\r\n                Track and know who sells what.\r\n            </p>\r\n            <p>\r\n                Make your attendant login with a card or password to their shift time before a pump will sell.\r\n            </p>\r\n            <p>\r\n                With geo-verification,\r\n                iRMS will even make sure they are physically in the station before a pump is released for them\r\n                to sell.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(56, "\r\n\r\n");
                __builder.OpenElement(57, "section");
                __builder.AddAttribute$5(58, "class", "bg-card mgt-10");
                __builder.OpenElement(59, "div");
                __builder.AddAttribute$5(60, "class", "row responsive col-2 bg-card");
                __builder.AddMarkupContent(61, "<div class=\"miwx-3 pdx-10\"><h1 class=\"text-center\">Fuel Voucher</h1>\r\n            <p>\r\n                Sell your fuel using voucher numbers, pre-generated by you.\r\n            </p>\r\n            <p>\r\n                When a voucher is redeemed, the exact amount carried by the voiucher is sold in fuel.\r\n                No short-change, no games.\r\n            </p></div>\r\n        ");
                __builder.OpenElement(62, "div");
                __builder.AddAttribute$5(63, "class", "miwx-3 flex");
                __builder.OpenElement(64, "img");
                __builder.AddAttribute$5(65, "src", this.ResolvePath("server/fuelcard.jpg", true, false, false));
                __builder.AddAttribute$5(66, "class", "mgx-a mawx-3 corner-10");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(67, "\r\n\r\n");
                __builder.OpenElement(68, "section");
                __builder.AddAttribute$5(69, "class", "bg-card mgt-10");
                __builder.OpenElement(70, "div");
                __builder.AddAttribute$5(71, "class", "row responsive col-2 bg-card");
                __builder.OpenElement(72, "div");
                __builder.AddAttribute$5(73, "class", "flex");
                __builder.OpenElement(74, "img");
                __builder.AddAttribute$5(75, "src", this.ResolvePath("server/fuelpriceup.jpg", true, false, false));
                __builder.AddAttribute$5(76, "class", "mawf mgx-a");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(77, "\r\n        ");
                __builder.AddMarkupContent(78, "<div class=\"miwx-3 pdx-10\"><h1 class=\"text-center\">Fuel Price Change and History</h1>\r\n            <p>\r\n                Remember those days when fuel price could change 10 time in a week? Uhm uhm.\r\n                And you have to call your pump engineer every single time to go and change the fuel price again?\r\n            </p>\r\n            <p>\r\n                Well, not anymore. Change your fuel price globally from your app and see your pump updates their\r\n                prices automatically in split seconds.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(79, "\r\n\r\n");
                __builder.OpenElement(80, "section");
                __builder.AddAttribute$5(81, "class", "bg-card mgt-10");
                __builder.OpenElement(82, "div");
                __builder.AddAttribute$5(83, "class", "row responsive col-2");
                __builder.AddMarkupContent(84, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">Pump Lock and Alert</h1>\r\n            <p>\r\n                Suspecting fraud? Lock your pump from the app with one click and it stops selling.\r\n            </p>\r\n            <p>\r\n                Someone opens the pump lid without authorization? Get alerted via email, Telegram or WhatsApp\r\n                immediately.\r\n            </p>\r\n            <p>\r\n                Someone disconnected the automation device? Get alerted via email, Telegram or WhatsApp immediately.\r\n            </p></div>\r\n        ");
                __builder.OpenElement(85, "div");
                __builder.AddAttribute$5(86, "class", "mihx-3 pd bg-fill");
                __builder.AddAttribute$5(87, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/toll-road.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(88, "\r\n\r\n");
                __builder.OpenElement(89, "section");
                __builder.AddAttribute$5(90, "class", "bg-card mgt-10");
                __builder.OpenElement(91, "div");
                __builder.AddAttribute$5(92, "class", "row responsive col-2 bg-card");
                __builder.OpenElement(93, "div");
                __builder.AddAttribute$5(94, "class", "mihx-3 bg-fill");
                __builder.AddAttribute$5(95, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/tanks.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.AddMarkupContent(96, "\r\n        ");
                __builder.AddMarkupContent(97, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">Tank gauges, Tank-Talks</h1>\r\n            <p>iRMS integrate seamlessly with our state of the art tank monitoring solution, Tank-Talks.</p>\r\n            <p>\r\n                Track current volume across all tanks in your stations.\r\n                Reconcile tank outflow against sales made by pumps connected to tanks and detect discrepancies.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(98, "\r\n\r\n");
                __builder.OpenElement(99, "section");
                __builder.AddAttribute$5(100, "class", "bg-card mgt-10");
                __builder.OpenElement(101, "div");
                __builder.AddAttribute$5(102, "class", "row responsive col-2 bg-card");
                __builder.AddMarkupContent(103, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">Automated daily report</h1>\r\n            <p>No time to check sales? No problem.</p>\r\n            <p>\r\n                iRMS deliver sales report to you daily/weekly via email or your chat client like WhatsApp and\r\n                Telegram.\r\n            </p>\r\n            <p>\r\n                Monitor every sale, detect anomalies, and flag suspicious activity with powerful analytics.\r\n                Get\r\n                automatic daily reports and access full transaction history across attendants, pumps, and shifts.\r\n            </p></div>\r\n        ");
                __builder.OpenElement(104, "div");
                __builder.AddAttribute$5(105, "class", "mihx-3 bg-fill");
                __builder.AddAttribute$5(106, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/report.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(107, "\r\n\r\n");
                __builder.OpenElement(108, "section");
                __builder.AddAttribute$5(109, "class", "bg-card mgt-10");
                __builder.OpenElement(110, "div");
                __builder.AddAttribute$5(111, "class", "row responsive col-2 bg-card");
                __builder.OpenElement(112, "div");
                __builder.AddAttribute$5(113, "class", "mihx-3 bg-fill corner-10");
                __builder.AddAttribute$5(114, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/security.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.AddMarkupContent(115, "\r\n        ");
                __builder.AddMarkupContent(116, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">Military Grade Securities</h1>\r\n            <h3>iRMS was built to be a vault.</h3>\r\n            <p>iRMS was built on iSmart\u2122 and inherits its tough security protocols and measures.</p>\r\n            <p>Using best-in-class security protocols and specs, you station data has never been more secured.</p>\r\n            <p>\r\n                Starting from the hardware collecting data from your station and sending to the cloud,\r\n                down to you sending commands to your pump;\r\n                your data are highly encrypted end to end.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(117, "\r\n\r\n");
                __builder.OpenElement(118, "section");
                __builder.AddAttribute$5(119, "class", "bg-card mgt-10");
                __builder.OpenElement(120, "div");
                __builder.AddAttribute$5(121, "class", "row responsive col-2 bg-card");
                __builder.AddMarkupContent(122, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">Snap, Secured and Signed OTA Updates</h1>\r\n            <p>\r\n                We are always improving on the features and securities of\r\n                our solutions.\r\n            </p>\r\n            <p>\r\n                Which is why our hardware are OTA (over the air) update enabled.\r\n                Making sure you always get the best and always protected.\r\n            </p>\r\n            <p>\r\n                And while we were at it, we also made sure bad guys can't hijack the process.\r\n                Our firmware update process is encrypted and signed by secure cryptography protocols.\r\n            </p></div>\r\n        ");
                __builder.OpenElement(123, "div");
                __builder.AddAttribute$5(124, "class", "mihx-3 bg-fill");
                __builder.AddAttribute$5(125, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/update.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(126, "\r\n\r\n");
                __builder.OpenElement(127, "section");
                __builder.AddAttribute$5(128, "class", "bg-card mgt-10");
                __builder.OpenElement(129, "div");
                __builder.AddAttribute$5(130, "class", "row responsive col-2");
                __builder.OpenElement(131, "div");
                __builder.AddAttribute$5(132, "class", "mihx-3 bg-fill");
                __builder.AddAttribute$5(133, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/api.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.AddMarkupContent(134, "\r\n        ");
                __builder.AddMarkupContent(135, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">Server Sale, API and Webhook</h1>\r\n            <p>\r\n                Authorize your pump from the cloud, set amount, price and volume to sell.\r\n                Get feedback when such sale is completed/aborted.\r\n            </p>\r\n            <p>\r\n                iRMS lets you build your own custom solution on top of her strong foundations and priciples\r\n                with\r\n                easy to use and compiant API and Webhook.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(136, "\r\n\r\n");
                __builder.OpenElement(137, "section");
                __builder.AddAttribute$5(138, "class", "bg-card mgt-10");
                __builder.OpenElement(139, "div");
                __builder.AddAttribute$5(140, "class", "row responsive col-2 bg-card");
                __builder.AddMarkupContent(141, "<div class=\"miwx-3 pd-10\"><h1 class=\"text-center\">AI Integration</h1>\r\n            <p>\r\n                Chat with your station \"AI manager\" directly, not \"The manager\".\r\n                AI wont lie about sales made.\r\n            </p>\r\n            <p>\r\n                iRMS integrate smoothly with your prefered chat client; Telegram, WhatsApp.\r\n            </p>\r\n            <p>\r\n                Ask your station AI salient question like \"How much sale has been made today\" or \"Change pump price\r\n                of\r\n                petrol to 1020\" and see it spin into action in seconds.\r\n            </p></div>\r\n        ");
                __builder.OpenElement(142, "div");
                __builder.AddAttribute$5(143, "class", "mihx-3 bg-fill");
                __builder.AddAttribute$5(144, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("server/ai.jpg", true, false, false)))) + ");");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(145, "\r\n\r\n");
                __builder.AddMarkupContent(146, "<section class=\"bg-card mgt-10 pd-10\"><h1 class=\"text-center\">Built for the Real RMS</h1>\r\n    <p class=\"text-center\">\r\n        Whether you run one station or a national network, iRMS delivers rugged, enterprise-grade\r\n        control\r\n        at your fingertips.\r\n    </p></section>");
            }
            //--TRIMMABLE-BOUNDARY-END(8592081217)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4297113921)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297113921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297113921)
            
            //--TRIMMABLE-BOUNDARY-START(4297113921)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297113921)
            
            static $h = 2146625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476983105),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182015809,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2146625,
      "h": 21476983105,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476983105)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592081217),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2146625,
      "h": 8592081217,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592081217)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297113921),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2146625,
      "h": 4297113921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297113921)
  ],
  "h": 2146625,
  "a": [
    {
      "t": 30640470,
      "c": 25800444246,
      "n": [
        {
          "n": "OpenGraphTitle",
          "v": "iRMS",
          "t": 1310721
        },
        {
          "n": "OpenGraphDescription",
          "v": "Secure \u002B Highly Scalable RMS management solution powered by IOT, Cloud and AI",
          "t": 1310721
        },
        {
          "n": "OpenGraphImage",
          "v": "_content/LivingThing.Core.IOT.RMS.Client.Blazor/logo.png",
          "t": 1310721
        },
        {
          "n": "OpenGraphPath",
          "v": "RMS/Index",
          "t": 1310721
        },
        {
          "n": "OpenGraphType",
          "v": 2,
          "t": 30902614
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1425729,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Index",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Home",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Index`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Index`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2146625)
        
        

        //--TRIMMABLE-BOUNDARY-START(1491265)
        $asm.$cls(`$QoDz.LCIRC.LandingPageLayout2`, ($self) => class LandingPageLayout2 extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(30066262337)
            /*RenderFragment?*/ Body = null;
            //--TRIMMABLE-BOUNDARY-END(30066262337)
            
            //--TRIMMABLE-BOUNDARY-START(133145477441)
            /*RMSClientAppViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(133145477441)
            
            //--TRIMMABLE-BOUNDARY-START(25771295041)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(25771295041)
            
            //--TRIMMABLE-BOUNDARY-START(85900837185)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(85900837185)
            
            //--TRIMMABLE-BOUNDARY-START(90195804481)
            /*string */ get OptimizedComponentName()
            {
                return "landingpagelayout2";
            }
            //--TRIMMABLE-BOUNDARY-END(90195804481)
            
            //--TRIMMABLE-BOUNDARY-START(128850510145)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850510145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Body":
                    this.Body = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(128850510145)
            
            //--TRIMMABLE-BOUNDARY-START(81605869889)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605869889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ViewModel = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(81605869889)
            
            //--TRIMMABLE-BOUNDARY-START(34361229633)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361229633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<style>\r\n    body {\r\n        -font-family: cursive !important;\r\n        font-size: 20px !important;\r\n    }\r\n\r\n    body button {\r\n        -font-family: cursive !important;\r\n        font-size: 20px !important;\r\n    }\r\n\r\n    p {\r\n        line-height: 2;\r\n    }\r\n\r\n    section > div {\r\n        max-width: 1200px;\r\n        margin: 0 auto;\r\n    }\r\n\r\n    .section {\r\n        max-width: 1200px;\r\n        margin: 0 auto;\r\n    }\r\n\r\n    input {\r\n        font-size: 30px;\r\n        -font-family: cursive !important;\r\n    }\r\n</style>\r\n\r\n");
                __builder.OpenElement(1, "div");
                __builder.AddAttribute$5(2, "class", "lp RMS");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "hv-4 bg-fill stack pos-rel");
                __builder.AddAttribute$5(5, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("station.jpg", true, false, false)))) + ");");
                __builder.OpenElement(6, "LandingPageNavigationBar");
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n        ");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "flex mawx-6 z-2 mgy-a");
                __builder.AddAttribute$5(10, "style", "margin-left: 7%;");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "mgy-a pd-10 bg-card-08 stack");
                __builder.OpenComponent$1($.$mac.MACS.SectionOutlet, 13);
                __builder.AddComponentParameter(14, "SectionName", "Title");
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n\r\n    ");
                __builder.AddContent$1(16, this.Body);
                __builder.AddMarkupContent(17, "\r\n\r\n    ");
                __builder.OpenElement(18, "div");
                __builder.AddAttribute$5(19, "class", "bg-black pd-10 row responsive col-3");
                __builder.OpenElement(20, "div");
                __builder.AddAttribute$5(21, "class", "stack miwx-3");
                __builder.OpenElement(22, "div");
                __builder.AddAttribute$5(23, "class", "flex");
                __builder.OpenElement(24, "img");
                __builder.AddAttribute$5(25, "src", this.ResolvePath("nozzle.png", true, false, false));
                __builder.AddAttribute$5(26, "class", "hx-05");
                __builder.CloseElement();
                __builder.AddMarkupContent(27, "\r\n                ");
                __builder.AddMarkupContent(28, "<h2 class=\"mgy-a mgl\"><span class=\"cl-primary\">i</span>RMS\r\n                </h2>");
                __builder.CloseElement();
                __builder.AddMarkupContent(29, "\r\n            ");
                __builder.AddMarkupContent(30, "<small class=\"op-7 mgt-2\">Powered by iSmart\u2122</small>\r\n            ");
                __builder.AddMarkupContent(31, "<small class=\"mg-0\">By SAKE INNOVATIONS AND TECHNOLOGIES</small>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(34361229633)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21476327745)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476327745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476327745)
            
            //--TRIMMABLE-BOUNDARY-START(21476327745)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476327745)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133145477441)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(133145477441)
                
                //--TRIMMABLE-BOUNDARY-START(25771295041)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(25771295041)
                
                //--TRIMMABLE-BOUNDARY-START(85900837185)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(85900837185)
                
            }
            static $h = 1491265;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066262337),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541098817,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375673665,
        "f": 83886081
      },
      "n": "Body",
      "d": 1491265,
      "h": 30066262337,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066262337),
//--TRIMMABLE-BOUNDARY-START(133145477441),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310902593,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555542849,
        "f": 83886081
      },
      "n": "ViewModel",
      "d": 1491265,
      "h": 133145477441,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145477441),
//--TRIMMABLE-BOUNDARY-START(25771295041),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951164225,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785739073,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 1491265,
      "h": 25771295041,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771295041),
//--TRIMMABLE-BOUNDARY-START(85900837185),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131033409,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965608257,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1491265,
      "h": 85900837185,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900837185),
//--TRIMMABLE-BOUNDARY-START(90195804481),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720968001,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1491265,
      "h": 90195804481,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90195804481)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850510145),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1491265,
      "h": 128850510145,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850510145),
//--TRIMMABLE-BOUNDARY-START(81605869889),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1491265,
      "h": 81605869889,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605869889),
//--TRIMMABLE-BOUNDARY-START(34361229633),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1491265,
      "h": 34361229633,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361229633)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476327745),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1491265,
      "h": 21476327745,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476327745)
  ],
  "h": 1491265
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.LandingPageLayout2`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}LandingPageLayout2`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1491265)
        
        

        //--TRIMMABLE-BOUNDARY-START(2670913)
        $asm.$cls(`$QoDz.LCIRCPS.Stations`, ($self) => class Stations extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42952343873)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(42952343873)
            
            //--TRIMMABLE-BOUNDARY-START(38657376577)
            /*string */ get OptimizedComponentName()
            {
                return "stations";
            }
            //--TRIMMABLE-BOUNDARY-END(38657376577)
            
            //--TRIMMABLE-BOUNDARY-START(34362409281)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362409281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34362409281)
            
            //--TRIMMABLE-BOUNDARY-START(12887572801)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887572801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionName", "Header");
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$QoDz.LCIRCS$1.TopHeader$$($.$QoDz.LCIRCPS.Stations), 3);
                    __builder2.AddComponentParameter(4, "Title", "Stations");
                    __builder2.CloseComponent();
                }), $qsGfqd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2670913,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(5, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$OgAC.LCIRCM.RMSStationModel), 6);
                __builder.AddComponentParameter(7, "ItemName", "Station");
                __builder.AddComponentParameter(8, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 27073296294678532n | 64n | 128n | 256n | 72057594037927936n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(9, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                __builder.AddComponentParameter(10, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel), (this.Service.Selected?.Service?.Scopes ?? null)));
                __builder.AddAttribute$3(11, "Commands", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolCommand$$$($.$OgAC.LCIRCM.RMSStationModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$OgAC.LCIRCM.RMSStationModel))))().$ctor(this, ( (/*command*/ command) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        if (command.Context !== null)
                        {
                            __builder2.OpenElement(12, "a");
                            __builder2.AddAttribute$5(13, "class", $.$strNN($.$strNN($.$strNN(($.$hDPm.LCFCCD$1.DataListItemToolBar.ButtonClass)) + " mdi") + " mdi-cog") + " mgx-2");
                            __builder2.AddAttribute$5(14, "title", "Station Settings");
                            __builder2.AddAttribute$5(15, "href", `/RMS/Station/Settings/${$.$strNN($.$dspc(command.Context.Data.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN(command.Context.Data.Title)}`);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(16, "\r\n            ");
                            __builder2.OpenElement(17, "a");
                            __builder2.AddAttribute$5(18, "class", $.$strNN($.$strNN(($.$hDPm.LCFCCD$1.DataListItemToolBar.ButtonClass)) + " mdi") + " mdi-chevron-right");
                            __builder2.AddAttribute$5(19, "title", "Open Station");
                            __builder2.AddAttribute$5(20, "href", `/RMS/Station/${$.$strNN($.$dspc(command.Context.Data.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN(command.Context.Data.Title)}`);
                            __builder2.CloseElement();
                        }
                    }, $KKqFHe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2670913,"h":0,"f":17825794});
                }), $FoVsDd ??= {"r":6881395,"p":[{"n":"command","p":$.$hDPm.LCFCCD$1.DataListToolCommand$$$($.$OgAC.LCIRCM.RMSStationModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$OgAC.LCIRCM.RMSStationModel)).$h}],"n":"","d":2670913,"h":0,"f":17825794}));
                __builder.AddAttribute$3(21, "GridView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$2.GridViewContext$$($.$OgAC.LCIRCM.RMSStationModel)))().$ctor(this, ( (/*item*/ item) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                    }, $ncpIha ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2670913,"h":0,"f":17825794});
                }), $XGmuca ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$2.GridViewContext$$($.$OgAC.LCIRCM.RMSStationModel).$h}],"n":"","d":2670913,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12887572801)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592605505)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592605505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592605505)
            
            //--TRIMMABLE-BOUNDARY-START(8592605505)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592605505)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42952343873)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(42952343873)
                
            }
            static $h = 2670913;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952343873),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067441985,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542278465,
        "f": 83886081
      },
      "n": "Service",
      "d": 2670913,
      "h": 42952343873,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952343873),
//--TRIMMABLE-BOUNDARY-START(38657376577),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477507393,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2670913,
      "h": 38657376577,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657376577)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362409281),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2670913,
      "h": 34362409281,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362409281),
//--TRIMMABLE-BOUNDARY-START(12887572801),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2670913,
      "h": 12887572801,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887572801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592605505),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2670913,
      "h": 8592605505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592605505)
  ],
  "h": 2670913,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "iRMS",
          "t": 1310721
        },
        {
          "v": 3,
          "t": 655361
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "v": "mdi mdi-office-building",
          "t": 1310721
        },
        {
          "v": 12328243,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1556801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Stations",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Stations.Stations`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Stations${separator}Stations`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2670913)
        
        

        //--TRIMMABLE-BOUNDARY-START(2343233)
        $asm.$cls(`$QoDz.LCIRCP.Settings`, ($self) => class Settings extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(47246983489)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(47246983489)
            
            //--TRIMMABLE-BOUNDARY-START(42952016193)
            /*Task *//*async*/  SaveSettings()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952016193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.UpdateSettings($.$OgAC.LCIRCS$1.RMSServiceSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, this.Service.Selected.Service.Identifier, this.Service.Selected.Service.Settings), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (this.Service.Selected.Service.Stations !== null)
                    {
                        let $en2 = this.Service.Selected.Service.Stations.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let station = $en2.SCG$IEnumerator$$$Current;
                            {
                                let $t3, $r3;
                                ($t3 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.UpdateSettings($.$OgAC.LCIRCS$1.RMSStationSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, station.Identifier, station.Settings), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42952016193)
            
            //--TRIMMABLE-BOUNDARY-START(38657048897)
            /*string */ get OptimizedComponentName()
            {
                return "settings";
            }
            //--TRIMMABLE-BOUNDARY-END(38657048897)
            
            //--TRIMMABLE-BOUNDARY-START(34362081601)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362081601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34362081601)
            
            //--TRIMMABLE-BOUNDARY-START(12887245121)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887245121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionName", "Header");
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$QoDz.LCIRCS$1.TopHeader$$($.$QoDz.LCIRCP.Settings), 3);
                    __builder2.AddComponentParameter(4, "Title", "SETTINGS");
                    __builder2.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(6, "button");
                            __builder3.AddAttribute$5(7, "class", "miwx-1 bg-card corner pdx-5 pdy-3");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 8, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.SaveSettings)));
                            __builder3.AddContent$4(9, "SAVE");
                            __builder3.CloseElement();
                        }, $cfALFc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2343233,"h":0,"f":17825794});
                    }), $VKHUNk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext).$h}],"n":"","d":2343233,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $RrOAia ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2343233,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(10, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 11);
                __builder.AddComponentParameter(12, "TabLocation", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarSide, ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? true) ? 3/*SideBarSide.Top*/ : 1/*SideBarSide.Left*/), $.$hDPm.LCFCCS$7.SideBarSide));
                __builder.AddComponentParameter(13, "sidebar-bar-class", "bg-card mgr mgb corner pd miwx-15");
                __builder.AddComponentParameter(14, "selected-title-class", "cl-primary fw-bold");
                __builder.AddComponentParameter(15, "title-class", "nobreak");
                __builder.AddAttribute$3(16, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 17);
                    __builder2.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(19, "Global");
                        }, $ftTahj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2343233,"h":0,"f":17825794});
                    }), $rnQvbj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2343233,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(20, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if ((this.Service.Selected?.Service ?? null) !== null)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$OgAC.LCIRCS$1.RMSServiceSettings), 21);
                                __builder3.AddComponentParameter(22, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.FormBuilderFeatures, 0/*FormBuilderFeatures.Default*/ | 2/*FormBuilderFeatures.ServerUpdate*/), $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                                __builder3.AddComponentParameter(23, "sidebar-bar-class", "pd bg-card mgt corner");
                                __builder3.AddComponentParameter(24, "tabs-selected-title-class", "cl-primary fw-bold");
                                __builder3.AddComponentParameter(25, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OgAC.LCIRCS$1.RMSServiceSettings, this.Service.Selected.Service.Settings));
                                __builder3.AddComponentParameter(26, "ModelChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$OgAC.LCIRCS$1.RMSServiceSettings), $.$mac.MAC.EventCallback.Factory.Create$6($.$OgAC.LCIRCS$1.RMSServiceSettings, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$OgAC.LCIRCS$1.RMSServiceSettings, this, new ($.$$.S.Action$$($.$OgAC.LCIRCS$1.RMSServiceSettings))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.Service.Selected.Service.Settings = __value;
                                }, $DRBpQh ??= {"r":65537,"p":[{"n":"__value","p":5779110}],"n":"","d":2343233,"h":0,"f":17825794}), this.Service.Selected.Service.Settings))));
                                __builder3.AddComponentParameter(27, "ModelExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$OgAC.LCIRCS$1.RMSServiceSettings)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Service"), "Selected"), "Service"), "Settings"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $kTpdDg ??= {"r":38797349,"n":"","d":2343233,"h":0,"f":17825794})).Invoke())));
                                __builder3.SetKey(this.Service.Selected.Service);
                                __builder3.CloseComponent();
                            }
                        }, $ZuCkYf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2343233,"h":0,"f":17825794});
                    }), $CRafre ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2343233,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    if ((this.Service.Selected?.Service?.Stations ?? null) !== null)
                    {
                        let $en4 = $.$sl.SL.Enumerable.OrderBy$1($.$OgAC.LCIRCM.RMSStationModel, $.$$.S.String, this.Service.Selected.Service.Stations, new ($.$$.S.Func$$$($.$OgAC.LCIRCM.RMSStationModel, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Title;
                        }, $zxtUta ??= {"r":1310721,"p":[{"n":"s","p":2961062}],"n":"","d":2343233,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let _station = $en4.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let station = _station;
                                __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 28);
                                __builder2.AddAttribute$3(29, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.AddContent$4(30, station.Title);
                                    }, $kpxBje ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2343233,"h":0,"f":17825794});
                                }), $aNBWSf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2343233,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(31, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                    {
                                        if ((this.Service.Selected?.Service ?? null) !== null)
                                        {
                                            __builder3.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$OgAC.LCIRCS$1.RMSStationSettings), 32);
                                            __builder3.AddComponentParameter(33, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.FormBuilderFeatures, 0/*FormBuilderFeatures.Default*/ | 2/*FormBuilderFeatures.ServerUpdate*/), $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                                            __builder3.AddComponentParameter(34, "sidebar-bar-class", "pd bg-card mgt corner");
                                            __builder3.AddComponentParameter(35, "selected-title-class", "cl-primary fw-bold");
                                            __builder3.AddComponentParameter(36, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OgAC.LCIRCS$1.RMSStationSettings, station.Settings));
                                            __builder3.AddComponentParameter(37, "ModelChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$OgAC.LCIRCS$1.RMSStationSettings), $.$mac.MAC.EventCallback.Factory.Create$6($.$OgAC.LCIRCS$1.RMSStationSettings, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$OgAC.LCIRCS$1.RMSStationSettings, this, new ($.$$.S.Action$$($.$OgAC.LCIRCS$1.RMSStationSettings))().$ctor(this,  (/**/ __value) =>
                                            {
                                                return station.Settings = __value;
                                            }, $FEWBhb ??= {"r":65537,"p":[{"n":"__value","p":6041254}],"n":"","d":2343233,"h":0,"f":17825794}), station.Settings))));
                                            __builder3.AddComponentParameter(38, "ModelExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$OgAC.LCIRCS$1.RMSStationSettings)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(station), "Settings"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $SncJGc ??= {"r":38797349,"n":"","d":2343233,"h":0,"f":17825794})).Invoke())));
                                            __builder3.CloseComponent();
                                        }
                                    }, $tKjdCa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2343233,"h":0,"f":17825794});
                                }), $aufhYc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2343233,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                        }
                    }
                }), $BlxTii ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2343233,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12887245121)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592277825)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592277825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592277825)
            
            //--TRIMMABLE-BOUNDARY-START(8592277825)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592277825)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47246983489)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(47246983489)
                
            }
            static $h = 2343233;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246983489),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067114305,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836918081,
        "f": 83886081
      },
      "n": "Service",
      "d": 2343233,
      "h": 47246983489,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246983489),
//--TRIMMABLE-BOUNDARY-START(38657048897),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477179713,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2343233,
      "h": 38657048897,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657048897)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952016193),
    {
      "r": 178454529,
      "n": "SaveSettings",
      "d": 2343233,
      "h": 42952016193,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42952016193),
//--TRIMMABLE-BOUNDARY-START(34362081601),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2343233,
      "h": 34362081601,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362081601),
//--TRIMMABLE-BOUNDARY-START(12887245121),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2343233,
      "h": 12887245121,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887245121)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592277825),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2343233,
      "h": 8592277825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592277825)
  ],
  "h": 2343233,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "iRMS",
          "t": 1310721
        },
        {
          "v": 2147483647,
          "t": 655361
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "v": "mdi mdi-cog",
          "t": 1310721
        },
        {
          "v": 7600,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1556801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Settings",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Settings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Settings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2343233)
        
        

        //--TRIMMABLE-BOUNDARY-START(2015553)
        $asm.$cls(`$QoDz.LCIRCPG.Gateways`, ($self) => class Gateways extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(73016459585)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(73016459585)
            
            //--TRIMMABLE-BOUNDARY-START(25771819329)
            /*RemoteClientConnectionProxy*/ Connection = null;
            //--TRIMMABLE-BOUNDARY-END(25771819329)
            
            //--TRIMMABLE-BOUNDARY-START(30066786625)
            static /*bool */ FilterGatewaySettings(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066786625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return descriptor.LCFCD$1$IPropertyDescriptor$DeclaredOnType.LCFCD$1$ITypeDescriptor$Name !== $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$NzWm.LCIDGM$1.GatewayServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$NzWm.LCIDGM$1.GatewayDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$NzWm.LCIDGM$1.GatewayDeviceModel, $.$NzWm.LCIDGS$1.GatewayDeviceSettings, $.$NzWm.LCIDGS$1.GatewayDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$NzWm.LCIDGM$1.GatewayDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$NzWm.LCIDGM$1.GatewayDeviceReceivedDataModel, $.$NzWm.LCIDGM$1.GatewayDeviceSendDataModel, $.$NzWm.LCIDGS.IGatewayDeviceStatusHandler, $.$NzWm.LCIDGH.IGatewayDeviceHubClient, $.$NzWm.LCIDGS.IGatewayRemoteService).iSmartDeviceHardwareSettings.$type.Name && descriptor.LCFCD$1$IPropertyDescriptor$DeclaredOnType.LCFCD$1$ITypeDescriptor$Name !== $.$XBGm.LCICSi.iSmartDeviceHardwareSettingsBase.$type.Name && descriptor.LCFCD$1$IPropertyDescriptor$DeclaredOnType.LCFCD$1$ITypeDescriptor$Name !== $.$XBGm.LCICS$2.IOTDeviceHardwareSettings.$type.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(30066786625)
            
            //--TRIMMABLE-BOUNDARY-START(21476852033)
            /*Task *//*async*/  ConfigureHardware(/*GatewayDeviceModel*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476852033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let vm = new ($.$ntej.LCICV.DeviceSettingsViewModel$$($.$NzWm.LCIDGS$1.GatewayDeviceHardwareSettings))().$ctor$6(this.UnitOfWork, $.$fPer.LCFCO.OneOf$$$($.$XBGm.LCICI.IIOTDevice, $.$XBGm.LCICI.IIOTDeviceModel).op_Implicit$1(device), this.Connection);
                    ($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$ntej.LCICD$1.DeviceSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Configure Gateway ${$.$strNN(device.Name)}`, false), null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ builder, /*sequenceNumber*/ sequenceNumber) =>
                    {
                        builder.AddAttribute$4(sequenceNumber++, "ViewModel", vm);
                        builder.AddAttribute$4(sequenceNumber++, "Features", $.$box(7/*DeviceSettingsFeatures.Default*/ & ~1/*DeviceSettingsFeatures.Local*/, $.$ntej.LCICD$1.DeviceSettingsFeatures));
                        builder.AddAttribute$3(sequenceNumber++, "PropertyFilter", new $.$fPer.LCFCD$1.PropertyDescriptorFilter().$ctor($.$QoDz.LCIRCPG.Gateways, $.$QoDz.LCIRCPG.Gateways.FilterGatewaySettings));
                    }, $vzszZc ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"sequenceNumber","p":655361}],"n":"","d":2015553,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t2 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.ViewFeatures = 5632/*ViewFeatures.Default*/ | 32/*ViewFeatures.Header*/ | 128/*ViewFeatures.Closable*/ | 8192/*ViewFeatures.Border*/ | 1/*ViewFeatures.OKToolBar*/;
                        $i2.PageBackgroundTheme = $.$fPer.LCFC.Theme.Tertiary;
                        return $i2;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476852033)
            
            //--TRIMMABLE-BOUNDARY-START(68721492289)
            /*Task *//*async*/  ReloadGateway(/*GatewayDeviceModel*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721492289);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let client = this.Connection.get_Item$3("Gateway/" + $.$strNN(device.UniqueId));
                    ($t3 = $.$NzWm.LCIDGP$1.GatewayProtocolCommands$$($.$NzWm.LCIDG.GatewayDevice).Reload(client), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68721492289)
            
            //--TRIMMABLE-BOUNDARY-START(64426524993)
            /*string */ get OptimizedComponentName()
            {
                return "gateways";
            }
            //--TRIMMABLE-BOUNDARY-END(64426524993)
            
            //--TRIMMABLE-BOUNDARY-START(60131557697)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131557697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
                this.Connection = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$KuVO.LCFCC.RemoteClientConnectionProxy, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60131557697)
            
            //--TRIMMABLE-BOUNDARY-START(17181884737)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181884737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$NzWm.LCIDGP.Gateways, 0);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17181884737)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886917441)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886917441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886917441)
            
            //--TRIMMABLE-BOUNDARY-START(12886917441)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886917441)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73016459585)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(73016459585)
                
                //--TRIMMABLE-BOUNDARY-START(25771819329)
                this.Connection = null;
                //--TRIMMABLE-BOUNDARY-END(25771819329)
                
            }
            static $h = 2015553;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016459585),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836590401,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196328769,
        "f": 83886081
      },
      "n": "Service",
      "d": 2015553,
      "h": 73016459585,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016459585),
//--TRIMMABLE-BOUNDARY-START(25771819329),
    {
      "p": 2485934,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656721217,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606394177,
        "f": 83886081
      },
      "n": "Connection",
      "d": 2015553,
      "h": 25771819329,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771819329),
//--TRIMMABLE-BOUNDARY-START(64426524993),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246655809,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2015553,
      "h": 64426524993,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64426524993)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066786625),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "descriptor",
          "p": 40733014
        }
      ],
      "n": "FilterGatewaySettings",
      "d": 2015553,
      "h": 30066786625,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30066786625),
//--TRIMMABLE-BOUNDARY-START(21476852033),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 5961279
        }
      ],
      "n": "ConfigureHardware",
      "d": 2015553,
      "h": 21476852033,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476852033),
//--TRIMMABLE-BOUNDARY-START(68721492289),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 5961279
        }
      ],
      "n": "ReloadGateway",
      "d": 2015553,
      "h": 68721492289,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68721492289),
//--TRIMMABLE-BOUNDARY-START(60131557697),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2015553,
      "h": 60131557697,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131557697),
//--TRIMMABLE-BOUNDARY-START(17181884737),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2015553,
      "h": 17181884737,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181884737)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886917441),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2015553,
      "h": 12886917441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886917441)
  ],
  "h": 2015553,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "iRMS",
          "t": 1310721
        },
        {
          "v": 3,
          "t": 655361
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "v": "mdi mdi-access-point",
          "t": 1310721
        },
        {
          "v": 12328243,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1556801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Gateways",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Gateways.Gateways`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Gateways${separator}Gateways`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2015553)
        
        

        //--TRIMMABLE-BOUNDARY-START(2277697)
        $asm.$cls(`$QoDz.LCIRCP.Pricing`, ($self) => class Pricing extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25772081473)
            /*RMSDeviceFamily*/ Family = null;
            //--TRIMMABLE-BOUNDARY-END(25772081473)
            
            //--TRIMMABLE-BOUNDARY-START(4297244993)
            /*IOTServiceTierType*/ _tier = 0;
            //--TRIMMABLE-BOUNDARY-END(4297244993)
            
            //--TRIMMABLE-BOUNDARY-START(17182146881)
            /*Task *//*async*/  BeginOnboard(/*IOTServiceTierType*/ tier)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182146881);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._tier = tier;
                    ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$ClientAuthentication.LCFCI$IClientAuthenticationService$AuthenticateAsync($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, true, true, true, false, false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                    {
                        return this.onboardWizard();
                    }, $gGiHdj ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":2277697,"h":0,"f":17825794}), null, null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.PageBackgroundTheme = $.$fPer.LCFC.Theme.Transparent;
                        $i3.ViewFeatures = 5632/*ViewFeatures.Default*/ | 128/*ViewFeatures.Closable*/;
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182146881)
            
            //--TRIMMABLE-BOUNDARY-START(55836852545)
            /*string */ get OptimizedComponentName()
            {
                return "pricing";
            }
            //--TRIMMABLE-BOUNDARY-END(55836852545)
            
            //--TRIMMABLE-BOUNDARY-START(47246917953)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246917953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Family = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OgAC.LCIRC.RMSDeviceFamily, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(47246917953)
            
            //--TRIMMABLE-BOUNDARY-START(21477114177)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477114177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionName", "Title");
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(3, "<h2>PRICING</h2>");
                }), $VmLDij ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2277697,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(4, "\r\n\r\n");
                __builder.OpenElement(5, "section");
                __builder.AddAttribute$5(6, "class", "bg-card pd-10");
                __builder.OpenElement(7, "div");
                __builder.AddAttribute$5(8, "class", "container");
                __builder.AddMarkupContent(9, "<h1> Flexible Pricing Model.</h1>\r\n        ");
                __builder.AddMarkupContent(10, "<p>\r\n            Whether you are a one man station owner or a multinational with thousands of branches, there is a\r\n            suitable iRMS pricing offer for you.\r\n        </p>\r\n        ");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "row responsive col-3");
                let $en4 = this.Family.DeviceDescriptor.ServiceTiers.SCG$IEnumerable$$$GetEnumerator();
                while ($en4.SC$1$IEnumerator$MoveNext())
                {
                    let _tier = $en4.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let tier = _tier;
                        __builder.OpenElement(13, "div");
                        __builder.OpenElement(14, "div");
                        __builder.AddAttribute$5(15, "class", "mg miwx-15 bd pd stack bg-chart1-01 hf");
                        __builder.OpenElement(16, "h3");
                        __builder.AddAttribute$5(17, "class", "mg-0 text-center");
                        __builder.AddContent$3(18, $.$box(tier.ServiceType, $.$XBGm.LCICM.IOTServiceTierType));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(19, "\r\n                        ");
                        __builder.OpenElement(20, "p");
                        __builder.AddAttribute$5(21, "class", "text-center text-italic");
                        __builder.AddContent$4(22, (tier.Schema?.Description ?? null));
                        __builder.CloseElement();
                        /*var*/ let allFeatures = $.$sl.SL.Enumerable.Except$1($.$XBGm.LCICM.IOTServiceFeatureType, $.$$.S.Enum.GetValues$1($.$XBGm.LCICM.IOTServiceFeatureType), $.$$.SRC.RuntimeHelpers.CreateArray($.$XBGm.LCICM.IOTServiceFeatureType.$type, [  ], null, null));
                        /*var*/ let features = tier.ServiceFeatures;
                        let $en5 = allFeatures.SCG$IEnumerable$$$GetEnumerator();
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let feature = $en5.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let schema = $.$fPer.LCFCT.EnumExtensions.GetSchema($.$box(feature, $.$XBGm.LCICM.IOTServiceFeatureType));
                                /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca1__;
                                /*var*/ let value = ((__ca1__ = schema) !== null ? $.$fPer.LCFCA$1.SchemaAttibutesExtension.GetOption(__ca1__, "Value") : null);
                                /*var*/ let title = $.$fPer.LCFCT.EnumExtensions.GetEnumTitle($.$box(feature, $.$XBGm.LCICM.IOTServiceFeatureType));
                                if (value !== null && !((features & (feature)) == (feature)))
                                {
                                    continue;
                                }
                                __builder.OpenElement(23, "div");
                                __builder.AddAttribute$5(24, "class", "flex bdb pdy");
                                __builder.OpenElement(25, "span");
                                __builder.AddAttribute$5(26, "class", "fill");
                                __builder.AddContent$4(27, title);
                                __builder.CloseElement();
                                if (value !== null)
                                {
                                    __builder.OpenElement(28, "b");
                                    __builder.AddContent$4(29, value);
                                    __builder.CloseElement();
                                }
                                else if (((features & (feature)) == (feature)))
                                {
                                    __builder.AddMarkupContent(30, "<i class=\"mdi mdi-check-circle-outline cl-success\"></i>");
                                }
                                else 
                                {
                                    __builder.AddMarkupContent(31, "<i class=\"mdi mdi-close-circle-outline cl-error\"></i>");
                                }
                                __builder.CloseElement();
                            }
                        }
                        __builder.OpenElement(32, "table");
                        __builder.AddAttribute$5(33, "class", "wf mgt");
                        __builder.AddMarkupContent(34, "<thead><tr><th></th>\r\n                                    <th class=\"text-right \">SETUP</th>\r\n                                    <th class=\"text-right\">MONTHLY</th></tr></thead>\r\n                            ");
                        __builder.OpenElement(35, "tbody");
                        __builder.OpenElement(36, "tr");
                        __builder.AddMarkupContent(37, "<th>PUMP</th>\r\n                                    ");
                        __builder.OpenElement(38, "td");
                        __builder.AddAttribute$5(39, "class", "text-right  cl-primary");
                        __builder.AddContent$4(40, "\u20A6"/*Money.NairaSymbol*/);
                        /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca2__;
                        __builder.AddContent$4(41, ((__ca2__ = tier.Schema) !== null ? $.$fPer.LCFCA$1.SchemaAttibutesExtension.GetOption(__ca2__, "PumpSetupAmount") : null));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(42, "\r\n                                    ");
                        __builder.OpenElement(43, "td");
                        __builder.AddAttribute$5(44, "class", "text-right cl-primary");
                        __builder.AddContent$4(45, "\u20A6"/*Money.NairaSymbol*/);
                        /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca3__;
                        __builder.AddContent$4(46, ((__ca3__ = tier.Schema) !== null ? $.$fPer.LCFCA$1.SchemaAttibutesExtension.GetOption(__ca3__, "PumpMonthlyAmount") : null));
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(47, "\r\n                                ");
                        __builder.OpenElement(48, "tr");
                        __builder.AddMarkupContent(49, "<th>TANK</th>\r\n                                    ");
                        __builder.OpenElement(50, "td");
                        __builder.AddAttribute$5(51, "class", "text-right  cl-primary");
                        __builder.AddContent$4(52, "\u20A6"/*Money.NairaSymbol*/);
                        /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca4__;
                        __builder.AddContent$4(53, ((__ca4__ = tier.Schema) !== null ? $.$fPer.LCFCA$1.SchemaAttibutesExtension.GetOption(__ca4__, "TankSetupAmount") : null));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(54, "\r\n                                    ");
                        __builder.OpenElement(55, "td");
                        __builder.AddAttribute$5(56, "class", "text-right cl-primary");
                        __builder.AddContent$4(57, "\u20A6"/*Money.NairaSymbol*/);
                        /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca5__;
                        __builder.AddContent$4(58, ((__ca5__ = tier.Schema) !== null ? $.$fPer.LCFCA$1.SchemaAttibutesExtension.GetOption(__ca5__, "TankMonthlyAmount") : null));
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(59, "\r\n                        ");
                        __builder.OpenElement(60, "button");
                        __builder.AddAttribute$5(61, "class", "bg-primary pd mgt-10 fsz-30");
                        __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 62, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                        {
                            return this.BeginOnboard(tier.ServiceType);
                        }, $sbEIgc ??= {"r":178454529,"n":"","d":2277697,"h":0,"f":17825794})));
                        __builder.AddContent$4(63, "ONBOARD");
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21477114177)
            
            //--TRIMMABLE-BOUNDARY-START(51541885249)
            /*RenderFragment */ onboardWizard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541885249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$QoDz.LCIRCS$1.Onboard, 64);
                    __builder2.AddComponentParameter(65, "Tier", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$XBGm.LCICM.IOTServiceTierType, this._tier), $.$XBGm.LCICM.IOTServiceTierType));
                    __builder2.CloseComponent();
                }, $Oqziqi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2277697,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(51541885249)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887179585)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887179585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887179585)
            
            //--TRIMMABLE-BOUNDARY-START(12887179585)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12887179585)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25772081473)
                this.Family = null;
                //--TRIMMABLE-BOUNDARY-END(25772081473)
                
            }
            static $h = 2277697;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772081473),
    {
      "p": 4009638,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362016065,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426787137,
        "f": 83886081
      },
      "n": "Family",
      "d": 2277697,
      "h": 25772081473,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772081473),
//--TRIMMABLE-BOUNDARY-START(55836852545),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951950657,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2277697,
      "h": 55836852545,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836852545)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182146881),
    {
      "r": 178454529,
      "p": [
        {
          "n": "tier",
          "p": 42964369
        }
      ],
      "n": "BeginOnboard",
      "d": 2277697,
      "h": 17182146881,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(17182146881),
//--TRIMMABLE-BOUNDARY-START(47246917953),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2277697,
      "h": 47246917953,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246917953),
//--TRIMMABLE-BOUNDARY-START(21477114177),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2277697,
      "h": 21477114177,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21477114177),
//--TRIMMABLE-BOUNDARY-START(51541885249),
    {
      "r": 6881395,
      "n": "onboardWizard",
      "d": 2277697,
      "h": 51541885249,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541885249)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297244993),
    {
      "t": 42964369,
      "n": "_tier",
      "d": 2277697,
      "h": 4297244993,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297244993)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887179585),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2277697,
      "h": 12887179585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887179585)
  ],
  "h": 2277697,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1491265,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Pricing",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Pricing`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Pricing`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2277697)
        
        

        //--TRIMMABLE-BOUNDARY-START(3326273)
        $asm.$cls(`$QoDz.LCIRCS$1.Onboard`, ($self) => class Onboard extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(3391809)
            static $_Station;
            static get Station()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3391809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$QoDz.LCIRCS$1.Onboard;
                return $cls.$_Station ??= $asm.$ncls(`$QoDz.LCIRCS$1.Onboard.Station`, ($self) => class Station extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(60132933953)
                    /*string?*/ Name = null;
                    //--TRIMMABLE-BOUNDARY-END(60132933953)
                    
                    //--TRIMMABLE-BOUNDARY-START(21478228289)
                    /*string?*/ Address = null;
                    //--TRIMMABLE-BOUNDARY-END(21478228289)
                    
                    //--TRIMMABLE-BOUNDARY-START(25773195585)
                    /*bool*/ Collapsed = false;
                    //--TRIMMABLE-BOUNDARY-END(25773195585)
                    
                    //--TRIMMABLE-BOUNDARY-START(55837966657)
                    /*bool */ IsValid()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55837966657);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return !$.$$.S.String.IsNullOrEmpty(this.Name) && !$.$$.S.String.IsNullOrEmpty(this.Address);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55837966657)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183260993)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17183260993);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183260993)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183260993)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183260993)
                    
                    static $h = 3391809;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60132933953),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542999361,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902737729,
        "f": 83886081
      },
      "n": "Name",
      "d": 3391809,
      "h": 60132933953,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132933953),
//--TRIMMABLE-BOUNDARY-START(21478228289),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363130177,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722868545,
        "f": 83886081
      },
      "n": "Address",
      "d": 3391809,
      "h": 21478228289,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478228289),
//--TRIMMABLE-BOUNDARY-START(25773195585),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953064769,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312803137,
        "f": 83886081
      },
      "n": "Collapsed",
      "d": 3391809,
      "h": 25773195585,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773195585)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55837966657),
    {
      "r": 262145,
      "n": "IsValid",
      "d": 3391809,
      "h": 55837966657,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55837966657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183260993),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3391809,
      "h": 17183260993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183260993)
  ],
  "d": 3326273,
  "h": 3391809
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.Onboard+Station`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}Onboard${separator}Station`; }
                }, $cls, ($v) => $cls.$_Station = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3391809)
            
            //--TRIMMABLE-BOUNDARY-START(47247966529)
            /*string?*/ name = null;
            //--TRIMMABLE-BOUNDARY-END(47247966529)
            
            //--TRIMMABLE-BOUNDARY-START(42952999233)
            /*ResourceData*/ logo;
            //--TRIMMABLE-BOUNDARY-END(42952999233)
            
            //--TRIMMABLE-BOUNDARY-START(73017770305)
            /*List<Station>*/ stations = null;
            //--TRIMMABLE-BOUNDARY-END(73017770305)
            
            //--TRIMMABLE-BOUNDARY-START(85902672193)
            /*WizardSteps?*/ wizard = null;
            //--TRIMMABLE-BOUNDARY-END(85902672193)
            
            //--TRIMMABLE-BOUNDARY-START(77312737601)
            /*IOTServiceTierType*/ Tier = 0;
            //--TRIMMABLE-BOUNDARY-END(77312737601)
            
            //--TRIMMABLE-BOUNDARY-START(12888228161)
            /*void */ AddStation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888228161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sl.SL.Enumerable.Any$1($.$QoDz.LCIRCS$1.Onboard.Station, this.stations))
                {
                    $.$sl.SL.Enumerable.ElementAt$1($.$QoDz.LCIRCS$1.Onboard.Station, this.stations, (($.$sl.SL.Enumerable.Count$1($.$QoDz.LCIRCS$1.Onboard.Station, this.stations) - 1) | 0)).Collapsed = true;
                }
                this.stations.Add(new $.$QoDz.LCIRCS$1.Onboard.Station().$ctor$1());
            }
            //--TRIMMABLE-BOUNDARY-END(12888228161)
            
            //--TRIMMABLE-BOUNDARY-START(55837901121)
            /*void */ RemoveStation(/*Station*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837901121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.stations.Remove(model);
            }
            //--TRIMMABLE-BOUNDARY-END(55837901121)
            
            //--TRIMMABLE-BOUNDARY-START(68722803009)
            /*bool*/ settingUp = false;
            //--TRIMMABLE-BOUNDARY-END(68722803009)
            
            //--TRIMMABLE-BOUNDARY-START(21478162753)
            /*Task *//*async*/  Finish(/*ViewChangingEventArgs*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478162753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (context.ToName !== "End")
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    try
                    {
                        let $t6, $r6;
                        this.settingUp = true;
                        this.StateHasChanged();
                        /*var*/ let validStations = $.$sl.SL.Enumerable.Where($.$QoDz.LCIRCS$1.Onboard.Station, this.stations, new ($.$$.S.Func$$$($.$QoDz.LCIRCS$1.Onboard.Station, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                        {
                            return e.IsValid();
                        }, $QVMVxh ??= {"r":262145,"p":[{"n":"e","p":3391809}],"n":"","d":3326273,"h":0,"f":17825794}));
                        /*var*/ let mstations = $.$sl.SL.Enumerable.ToList($.$OgAC.LCIRCM.RMSStationModel, $.$sl.SL.Enumerable.Select($.$QoDz.LCIRCS$1.Onboard.Station, $.$OgAC.LCIRCM.RMSStationModel, validStations, new ($.$$.S.Func$$$$($.$QoDz.LCIRCS$1.Onboard.Station, $.$$.S.Int32, $.$OgAC.LCIRCM.RMSStationModel))().$ctor(this,  (/*s*/ s, /**/ i) =>
                        {
                            return (() =>
                            {
                                //new $.$OgAC.LCIRCM.RMSStationModel()
                                const $t1 = $.$OgAC.LCIRCM.RMSStationModel;
                                const $i1 = new $t1();
                                $i1.$ctor$8();
                                $i1.Name = s.Name;
                                $i1.Location = (() =>
                                {
                                    //new $.$fPer.LCFCDG.GeoLocation()
                                    const $t2 = $.$fPer.LCFCDG.GeoLocation;
                                    const $i2 = new $t2();
                                    $i2.$ctor$2();
                                    $i2.Address = s.Address;
                                    return $i2;
                                })();
                                $i1.Devices = $.$$.SRC.RuntimeHelpers.CreateArray($.$fPer.LCFCD.DataId.$type, [ new $.$fPer.LCFCD.DataId().$ctor$3(s.Name, null) ], null, null);
                                return $i1;
                            })();
                        }, $efScja ??= {"r":2961062,"p":[{"n":"s","p":3391809},{"n":"i","p":655361}],"n":"","d":3326273,"h":0,"f":17825794})));
                        /*var*/ let dashboard = (() =>
                        {
                            //new $.$OgAC.LCIRCM.RMSServiceModel()
                            const $t3 = $.$OgAC.LCIRCM.RMSServiceModel;
                            const $i3 = new $t3();
                            $i3.$ctor$10();
                            $i3.Name = this.name;
                            $i3.Icon = this.logo.HasValue ? (() =>
                            {
                                //new $.$Iaui.LCFCM.ResourceModel()
                                const $t4 = $.$Iaui.LCFCM.ResourceModel;
                                const $i4 = new $t4();
                                $i4.$ctor$3();
                                $i4.Data = $.$clone(this.logo);
                                return $i4;
                            })() : null;
                            $i3.ServiceTier = this.Tier;
                            $i3.ExpiryDate = $.$$.S.DateTime.UtcNow.AddDays(30);
                            $i3.Stations = mstations;
                            $i3.Devices = $.$sl.SL.Enumerable.ToList($.$OgAC.LCIRCM.RMSDeviceModel, $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$OgAC.LCIRCM.RMSDeviceModel, $.$sl.SL.Enumerable.Range(0, $.$sl.SL.Enumerable.Count$1($.$QoDz.LCIRCS$1.Onboard.Station, validStations)), new ($.$$.S.Func$$$($.$$.S.Int32, $.$OgAC.LCIRCM.RMSDeviceModel))().$ctor(this,  (/**/ station_i) =>
                            {
                                return (() =>
                                {
                                    //new $.$OgAC.LCIRCM.RMSDeviceModel()
                                    const $t5 = $.$OgAC.LCIRCM.RMSDeviceModel;
                                    const $i5 = new $t5();
                                    $i5.$ctor$8();
                                    $i5.Station = $.$sl.SL.Enumerable.ElementAt$1($.$OgAC.LCIRCM.RMSStationModel, mstations, station_i);
                                    $i5.Identifier = new $.$fPer.LCFCD.DataId().$ctor$3($.$sl.SL.Enumerable.ElementAt$1($.$QoDz.LCIRCS$1.Onboard.Station, validStations, station_i).Name, null);
                                    $i5.Name = "Device " + station_i;
                                    $i5.UniqueId = "Pending" + $.$strNN($.$fPer.LCFCS$6.StringExtension.GetRandomString(4, true, true, false));
                                    return $i5;
                                })();
                            }, $Zihoac ??= {"r":1584806,"p":[{"n":"station_i","p":655361}],"n":"","d":3326273,"h":0,"f":17825794})));
                            return $i3;
                        })();
                        ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$OgAC.LCIRCM.RMSServiceModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OgAC.LCIRCM.RMSServiceModel), [ dashboard ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    }
                    finally
                    {
                        {
                            this.settingUp = false;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21478162753)
            
            //--TRIMMABLE-BOUNDARY-START(51542933825)
            /*string */ get OptimizedComponentName()
            {
                return "onboard";
            }
            //--TRIMMABLE-BOUNDARY-END(51542933825)
            
            //--TRIMMABLE-BOUNDARY-START(81607704897)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607704897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch7 = parameter.Name;
                switch($switch7)
                {
                    case "Tier":
                    this.Tier = $.$cast(parameter.Value, $.$XBGm.LCICM.IOTServiceTierType);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81607704897)
            
            //--TRIMMABLE-BOUNDARY-START(17183195457)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183195457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACF.EditForm, 0);
                __builder.AddComponentParameter(1, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                __builder.AddComponentParameter(2, "class", "clip");
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*_*/ _0) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 4);
                        __builder2.AddComponentParameter(5, "Class", "bg-card bd corner-10 pd-10 mawx-7 mgx-a");
                        __builder2.AddComponentParameter(6, "NextButtonText", "Continue");
                        __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 8);
                            __builder3.AddComponentParameter(9, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$$.STT.ValueTask))().$ctor(this,  (/**/ c) =>
                            {
                                return c.Showing === false && $.$$.S.String.IsNullOrEmpty(this.name) ? (() =>
                                {
        throw new $.$$.S.InvalidOperationException().$ctor$12("Business name is required")                        })() : $.$$.STT.ValueTask.CompletedTask;
                            }, $rIpxjk ??= {"r":181338113,"p":[{"n":"c","p":38098602}],"n":"","d":3326273,"h":0,"f":17825794}))));
                            __builder3.AddAttribute$3(10, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(11, "<h1>What's the name of your company/business?</h1>\r\n            ");
                                    __builder4.AddMarkupContent(12, "<span class=\"op-7\">e.g Ade Oil and Gas</span>\r\n\r\n            ");
                                    __builder4.OpenElement(13, "input");
                                    __builder4.AddAttribute$5(14, "type", "text");
                                    __builder4.AddAttribute$5(15, "class", "d-block pd-5 bd corner fsz-20");
                                    __builder4.AddAttribute$5(16, "placeholder", "Business Name");
                                    __builder4.AddAttribute$5(17, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.name, null));
                                    __builder4.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 18, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                                    {
                                        return this.name = __value;
                                    }, $pJtNZf ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":3326273,"h":0,"f":17825794}), this.name, null));
                                    __builder4.SetUpdatesAttributeName("value");
                                    __builder4.CloseElement();
                                }, $Jowouj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3326273,"h":0,"f":17825794});
                            }), $tBdRGk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":3326273,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(19, "\r\n        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 20);
                            __builder3.AddAttribute$3(21, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(22, "<h1>Upload your business Logo?</h1>\r\n            ");
                                    __builder4.AddMarkupContent(23, "<span class=\"op-7\">Skip if you dont have one. iRMS logo will be used instead.</span>\r\n\r\n            ");
                                    $.$QoDz._LCIRCSO.TypeInference.CreateInputEditor_0($.$fPer.LCFCD.ResourceData, __builder4, 24, 25, 14n, 26, "d-block pd-5 bd corner fsz-20", 27, "Business Name", 28, $.$clone(this.logo), 29, $.$mac.MAC.EventCallback.Factory.Create$6($.$fPer.LCFCD.ResourceData, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fPer.LCFCD.ResourceData, this, new ($.$$.S.Action$$($.$fPer.LCFCD.ResourceData))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        return this.logo = $.$clone(__value);
                                    }, $tQlDNj ??= {"r":65537,"p":[{"n":"__value","p":36800854}],"n":"","d":3326273,"h":0,"f":17825794}), $.$clone(this.logo))), 30, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                    {
                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "logo"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                    }, $BMALCb ??= {"r":38797349,"n":"","d":3326273,"h":0,"f":17825794})).Invoke()));
                                }, $qVpOtd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3326273,"h":0,"f":17825794});
                            }), $gXPDoe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":3326273,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(31, "\r\n        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 32);
                            __builder3.AddComponentParameter(33, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$$.STT.ValueTask))().$ctor(this,  (/*c*/ c) =>
                            {
                                return c.Showing === false && ($.$$.S.String.IsNullOrEmpty(($.$sl.SL.Enumerable.FirstOrDefault$3($.$QoDz.LCIRCS$1.Onboard.Station, this.stations)?.Name ?? null)) || $.$$.S.String.IsNullOrEmpty(($.$sl.SL.Enumerable.FirstOrDefault$3($.$QoDz.LCIRCS$1.Onboard.Station, this.stations)?.Address ?? null))) ? (() =>
                                {
        throw new $.$$.S.InvalidOperationException().$ctor$12("At least one station with name, addressand nozzles is required")                        })() : $.$$.STT.ValueTask.CompletedTask;
                            }, $ZPRhJg ??= {"r":181338113,"p":[{"n":"c","p":38098602}],"n":"","d":3326273,"h":0,"f":17825794}))));
                            __builder3.AddAttribute$3(34, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(35, "<h1>How many stations/branches do you have under your company/business?</h1>\r\n            ");
                                    __builder4.AddMarkupContent(36, "<span class=\"op-7\">\r\n                If you intend to start with few stations only, enter only the ones to start\r\n                with.\r\n            </span>");
                                    /*int*/ let i = 1;
                                    let $en8 = this.stations.GetEnumerator();
                                    while ($en8.MoveNext())
                                    {
                                        let _station = $en8.Current;
                                        {
                                            /*var*/ let station = _station;
                                            __builder4.OpenElement(37, "div");
                                            __builder4.AddAttribute$5(38, "class", "stack bd corner-5 pd-8 pos-rel mgb");
                                            __builder4.OpenElement(39, "div");
                                            __builder4.AddAttribute$5(40, "class", "pos-abs t-0 l-0 wx-05 hx-05 bg-primary round flex clickable");
                                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 41, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                return station.Collapsed = !station.Collapsed;
                                            }, $cVxaoh ??= {"r":65537,"n":"","d":3326273,"h":0,"f":17825794})));
                                            __builder4.OpenElement(42, "span");
                                            __builder4.AddAttribute$5(43, "class", "mg-a");
                                            __builder4.AddContent$3(44, $.$box(i, $.$$.S.Int32));
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            if (!station.Collapsed)
                                            {
                                                __builder4.OpenElement(45, "input");
                                                __builder4.AddAttribute$5(46, "type", "text");
                                                __builder4.AddAttribute$5(47, "class", "pd-5 bd corner fsz-20 mgt");
                                                __builder4.AddAttribute$5(48, "placeholder", "Station Name");
                                                __builder4.AddAttribute$5(49, "value", $.$mac.MAC.BindConverter.FormatValue$28(station.Name, null));
                                                __builder4.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 50, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return station.Name = __value;
                                                }, $eMlsBe ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":3326273,"h":0,"f":17825794}), station.Name, null));
                                                __builder4.SetUpdatesAttributeName("value");
                                                __builder4.CloseElement();
                                                __builder4.AddMarkupContent(51, "\r\n                        ");
                                                __builder4.OpenElement(52, "input");
                                                __builder4.AddAttribute$5(53, "type", "text");
                                                __builder4.AddAttribute$5(54, "class", "pd-5 bd corner fsz-20 mgt");
                                                __builder4.AddAttribute$5(55, "placeholder", "Address");
                                                __builder4.AddAttribute$5(56, "value", $.$mac.MAC.BindConverter.FormatValue$28(station.Address, null));
                                                __builder4.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 57, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return station.Address = __value;
                                                }, $BRcTba ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":3326273,"h":0,"f":17825794}), station.Address, null));
                                                __builder4.SetUpdatesAttributeName("value");
                                                __builder4.CloseElement();
                                            }
                                            else 
                                            {
                                                __builder4.OpenElement(58, "span");
                                                __builder4.AddAttribute$5(59, "class", "pos-abs t-0 l-0 hx-05 fsz-30 miwx-1 flex mgl-20");
                                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 60, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                                {
                                                    return station.Collapsed = !station.Collapsed;
                                                }, $hyuIOi ??= {"r":65537,"n":"","d":3326273,"h":0,"f":17825794})));
                                                __builder4.OpenElement(61, "span");
                                                __builder4.AddAttribute$5(62, "class", "mgy-a");
                                                __builder4.AddContent$4(63, station.Name);
                                                __builder4.CloseElement();
                                                __builder4.CloseElement();
                                            }
                                            __builder4.OpenElement(64, "button");
                                            __builder4.AddAttribute$5(65, "class", "pos-abs t-0 r-0 hx-05 bg-error corner-5 fsz-30 miwx-1 flex");
                                            __builder4.AddAttribute$5(66, "title", "Remove");
                                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 67, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                return this.RemoveStation(station);
                                            }, $UKAouk ??= {"r":65537,"n":"","d":3326273,"h":0,"f":17825794})));
                                            __builder4.AddMarkupContent(68, "<span class=\"mg-a mdi mdi-close\">Remove</span>");
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            i++;
                                        }
                                    }
                                    __builder4.OpenElement(69, "button");
                                    __builder4.AddAttribute$5(70, "class", "pd-3 bg-secondary fsz-30 corner-5 wf mgt mdi mdi-plus");
                                    __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 71, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.AddStation)));
                                    __builder4.AddContent$4(72, "Add Station");
                                    __builder4.CloseElement();
                                }, $EhbkGc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3326273,"h":0,"f":17825794});
                            }), $UKpwua ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":3326273,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(73, "\r\n        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 74);
                            __builder3.AddComponentParameter(75, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~(this.settingUp ? 3/*WizardFeatures.Controls*/ : 0/*WizardFeatures.None*/)), $.$hDPm.LCFCCW$1.WizardFeatures));
                            __builder3.AddComponentParameter(76, "NextButtonText", "Finish Setup");
                            __builder3.AddComponentParameter(77, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$mac.MAC.EventCallback.Factory.Create$10($.$hDPm.LCFCCM$6.ViewChangingEventArgs, this, new ($.$$.S.Func$$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$$.STT.Task))().$ctor(this, this.Finish))));
                            __builder3.AddAttribute$3(78, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    if (!this.settingUp)
                                    {
                                        __builder4.AddMarkupContent(79, "<h1>We have all we need for now!</h1>\r\n                ");
                                        __builder4.AddMarkupContent(80, "<p>We are now going to setup your iRMS dashboard.</p>\r\n                ");
                                        __builder4.AddMarkupContent(81, "<p>Note that we still need to install iRMS devices into your station before your pumps and tanks will come online.</p>\r\n                ");
                                        __builder4.AddMarkupContent(82, "<p>After setting up your dashbaord, we will connect you to one of  iRMS personnel that will handle your installation.</p>");
                                    }
                                    else 
                                    {
                                        __builder4.AddMarkupContent(83, "<h1>Setting things up</h1>\r\n                ");
                                        __builder4.AddMarkupContent(84, "<p>Installing dashboard...</p>\r\n                ");
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 85);
                                        __builder4.CloseComponent();
                                    }
                                }, $NLHhxb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3326273,"h":0,"f":17825794});
                            }), $hzjfOi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":3326273,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(86, "\r\n        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 87);
                            __builder3.AddComponentParameter(88, "Name", "End");
                            __builder3.AddComponentParameter(89, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                            __builder3.AddAttribute$3(90, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(91, "<h1>Congratulations</h1>\r\n            ");
                                    __builder4.AddMarkupContent(92, "<p>Your iRMS dashboard is ready to use.</p>\r\n            ");
                                    __builder4.AddMarkupContent(93, "<a class=\"pd-5 bg-primary fsz-30 corner-5 wf mgt-10 d-block text-center\" href=\"RMS\" target=\"_blank\">Launch Dashboard</a>");
                                }, $uXNbaj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3326273,"h":0,"f":17825794});
                            }), $bALFAa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":3326273,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $IALslk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3326273,"h":0,"f":17825794}));
                        __builder2.AddComponentReferenceCapture(94, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this.wizard = $.$cast(__value, $.$hDPm.LCFCCW$1.WizardSteps);
                        }, $CvlUXj ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":3326273,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $OqxPnb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3326273,"h":0,"f":17825794});
                }), $GtTUri ??= {"r":6881395,"p":[{"n":"_","p":131188}],"n":"","d":3326273,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17183195457)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8593260865)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593260865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593260865)
            
            //--TRIMMABLE-BOUNDARY-START(8593260865)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8593260865)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42952999233)
                this.logo = $.$default($.$fPer.LCFCD.ResourceData);
                //--TRIMMABLE-BOUNDARY-END(42952999233)
                
                //--TRIMMABLE-BOUNDARY-START(73017770305)
                this.stations = (() =>
                {
                    //new $.$$.SCG.List$$($.$QoDz.LCIRCS$1.Onboard.Station)()
                    const $t9 = $.$$.SCG.List$$($.$QoDz.LCIRCS$1.Onboard.Station);
                    const $i9 = new $t9();
                    $i9.$ctor$1();
                    $i9.Add(new $.$QoDz.LCIRCS$1.Onboard.Station().$ctor$1());
                    return $i9;
                })();
                //--TRIMMABLE-BOUNDARY-END(73017770305)
                
            }
            static $h = 3326273;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77312737601),
    {
      "p": 42964369,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658031937,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427835713,
        "f": 83886081
      },
      "n": "Tier",
      "d": 3326273,
      "h": 77312737601,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77312737601),
//--TRIMMABLE-BOUNDARY-START(51542933825),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068097345,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3326273,
      "h": 51542933825,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51542933825)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888228161),
    {
      "r": 65537,
      "n": "AddStation",
      "d": 3326273,
      "h": 12888228161,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12888228161),
//--TRIMMABLE-BOUNDARY-START(55837901121),
    {
      "r": 65537,
      "p": [
        {
          "n": "model",
          "p": 3391809
        }
      ],
      "n": "RemoveStation",
      "d": 3326273,
      "h": 55837901121,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55837901121),
//--TRIMMABLE-BOUNDARY-START(21478162753),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 38098602
        }
      ],
      "n": "Finish",
      "d": 3326273,
      "h": 21478162753,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21478162753),
//--TRIMMABLE-BOUNDARY-START(81607704897),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3326273,
      "h": 81607704897,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81607704897),
//--TRIMMABLE-BOUNDARY-START(17183195457),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3326273,
      "h": 17183195457,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17183195457)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47247966529),
    {
      "t": 1310721,
      "n": "name",
      "d": 3326273,
      "h": 47247966529,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47247966529),
//--TRIMMABLE-BOUNDARY-START(42952999233),
    {
      "t": 36800854,
      "n": "logo",
      "d": 3326273,
      "h": 42952999233,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42952999233),
//--TRIMMABLE-BOUNDARY-START(73017770305),
    {
      "t": $.$$.SCG.List$$($.$QoDz.LCIRCS$1.Onboard.Station).$h,
      "n": "stations",
      "d": 3326273,
      "h": 73017770305,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73017770305),
//--TRIMMABLE-BOUNDARY-START(85902672193),
    {
      "t": 59004586,
      "n": "wizard",
      "d": 3326273,
      "h": 85902672193,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85902672193),
//--TRIMMABLE-BOUNDARY-START(68722803009),
    {
      "t": 262145,
      "n": "settingUp",
      "d": 3326273,
      "h": 68722803009,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68722803009)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593260865),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3326273,
      "h": 8593260865,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593260865)
  ],
  "h": 3326273
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$QoDz.LCIRCS$1.Onboard.Station ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.Onboard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}Onboard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3326273)
        
        

        //--TRIMMABLE-BOUNDARY-START(1884481)
        $asm.$cls(`$QoDz.LCIRCPA.Devices`, ($self) => class Devices extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25771688257)
            /*RemoteClientConnectionProxy*/ Connection = null;
            //--TRIMMABLE-BOUNDARY-END(25771688257)
            
            //--TRIMMABLE-BOUNDARY-START(68721361217)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(68721361217)
            
            //--TRIMMABLE-BOUNDARY-START(30066655553)
            static /*bool */ FilterPumpSettings(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066655553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return descriptor.LCFCD$1$IPropertyDescriptor$DeclaredOnType.LCFCD$1$ITypeDescriptor$Name === $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings.$type.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(30066655553)
            
            //--TRIMMABLE-BOUNDARY-START(21476720961)
            /*Task *//*async*/  ConfigureHardware(/*RMSDeviceModel*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476720961);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let vm = new ($.$ntej.LCICV.DeviceSettingsViewModel$$($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings))().$ctor$6(this.UnitOfWork, $.$fPer.LCFCO.OneOf$$$($.$XBGm.LCICI.IIOTDevice, $.$XBGm.LCICI.IIOTDeviceModel).op_Implicit$1(device), this.Connection);
                    ($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$ntej.LCICD$1.DeviceSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Configure ${$.$strNN(device.Name)}`, false), null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /**/ sequenceNumber) =>
                    {
                        builder.AddAttribute$4(sequenceNumber++, "ViewModel", vm);
                        builder.AddAttribute$4(sequenceNumber++, "Features", $.$box(7/*DeviceSettingsFeatures.Default*/ & ~1/*DeviceSettingsFeatures.Local*/, $.$ntej.LCICD$1.DeviceSettingsFeatures));
                        builder.AddAttribute$3(sequenceNumber++, "PropertyFilter", new $.$fPer.LCFCD$1.PropertyDescriptorFilter().$ctor($.$QoDz.LCIRCPA.Devices, $.$QoDz.LCIRCPA.Devices.FilterPumpSettings));
                    }, $kAOGfd ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"sequenceNumber","p":655361}],"n":"","d":1884481,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t2 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.ViewFeatures = 5632/*ViewFeatures.Default*/ | 32/*ViewFeatures.Header*/ | 128/*ViewFeatures.Closable*/ | 8192/*ViewFeatures.Border*/ | 1/*ViewFeatures.OKToolBar*/;
                        $i2.PageBackgroundTheme = $.$fPer.LCFC.Theme.Tertiary;
                        return $i2;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476720961)
            
            //--TRIMMABLE-BOUNDARY-START(64426393921)
            /*string */ get OptimizedComponentName()
            {
                return "devices";
            }
            //--TRIMMABLE-BOUNDARY-END(64426393921)
            
            //--TRIMMABLE-BOUNDARY-START(60131426625)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131426625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Connection = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$KuVO.LCFCC.RemoteClientConnectionProxy, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60131426625)
            
            //--TRIMMABLE-BOUNDARY-START(17181753665)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181753665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17181753665)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886786369)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886786369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886786369)
            
            //--TRIMMABLE-BOUNDARY-START(12886786369)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886786369)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771688257)
                this.Connection = null;
                //--TRIMMABLE-BOUNDARY-END(25771688257)
                
                //--TRIMMABLE-BOUNDARY-START(68721361217)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(68721361217)
                
            }
            static $h = 1884481;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771688257),
    {
      "p": 2485934,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656590145,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77311295809,
        "f": 83886081
      },
      "n": "Connection",
      "d": 1884481,
      "h": 25771688257,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771688257),
//--TRIMMABLE-BOUNDARY-START(68721361217),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836459329,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901230401,
        "f": 83886081
      },
      "n": "Service",
      "d": 1884481,
      "h": 68721361217,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68721361217),
//--TRIMMABLE-BOUNDARY-START(64426393921),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246524737,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1884481,
      "h": 64426393921,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64426393921)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066655553),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "descriptor",
          "p": 40733014
        }
      ],
      "n": "FilterPumpSettings",
      "d": 1884481,
      "h": 30066655553,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066655553),
//--TRIMMABLE-BOUNDARY-START(21476720961),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 1584806
        }
      ],
      "n": "ConfigureHardware",
      "d": 1884481,
      "h": 21476720961,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476720961),
//--TRIMMABLE-BOUNDARY-START(60131426625),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1884481,
      "h": 60131426625,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131426625),
//--TRIMMABLE-BOUNDARY-START(17181753665),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1884481,
      "h": 17181753665,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181753665)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886786369),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1884481,
      "h": 12886786369,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886786369)
  ],
  "h": 1884481
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Assets.Devices`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Assets${separator}Devices`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1884481)
        
        

        //--TRIMMABLE-BOUNDARY-START(3195201)
        $asm.$cls(`$QoDz.LCIRCS$1.Editor<>`, (T) => $asm.$gt(`$QoDz.LCIRCS$1.Editor<>`, [T], ($self) => class Editor$$ extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(137442148673)
            /*string */ get OptimizedComponentName()
            {
                return "editor";
            }
            //--TRIMMABLE-BOUNDARY-END(137442148673)
            
            //--TRIMMABLE-BOUNDARY-START(176096854337)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096854337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Model":
                    this.Model = $.$cast(parameter.Value, T);
                    return true;
                    case "ModelChanged":
                    this.ModelChanged = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$(T));
                    return true;
                    case "FieldOrder":
                    this.FieldOrder = $.$cast(parameter.Value, $.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Int32));
                    return true;
                    case "FilterProperty":
                    this.FilterProperty = $.$cast(parameter.Value, $.$fPer.LCFCD$1.PropertyDescriptorFilter);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(176096854337)
            
            //--TRIMMABLE-BOUNDARY-START(120262279489)
            /*T?*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(120262279489)
            
            //--TRIMMABLE-BOUNDARY-START(124557246785)
            /*EventCallback<T>*/ ModelChanged;
            //--TRIMMABLE-BOUNDARY-END(124557246785)
            
            //--TRIMMABLE-BOUNDARY-START(34362933569)
            /*Func<IPropertyDescriptor, int>?*/ FieldOrder = null;
            //--TRIMMABLE-BOUNDARY-END(34362933569)
            
            //--TRIMMABLE-BOUNDARY-START(42952868161)
            /*PropertyDescriptorFilter?*/ FilterProperty = null;
            //--TRIMMABLE-BOUNDARY-END(42952868161)
            
            //--TRIMMABLE-BOUNDARY-START(128852214081)
            /*object? */ get ModelValue()
            {
                return $.$box(this.Model, T);
            }
            //--TRIMMABLE-BOUNDARY-END(128852214081)
            
            //--TRIMMABLE-BOUNDARY-START(47247835457)
            /*Type */ get FormType()
            {
                return T.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(47247835457)
            
            //--TRIMMABLE-BOUNDARY-START(38657900865)
            /*IEnumerable<IObservableDataDescriptor> */ get Fields()
            {
                return $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCF$2.DescriptorField, $.$fPer.LCFCD$1.IObservableDataDescriptor, this.descriptors, new ($.$$.S.Func$$$($.$hDPm.LCFCCF$2.DescriptorField, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/**/ d) =>
                {
                    return d.Descriptor;
                }, $bvUwYd ??= {"r":40536406,"p":[{"n":"d","p":22959786}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(38657900865)
            
            //--TRIMMABLE-BOUNDARY-START(30067966273)
            /*IEnumerable<DescriptorField>*/ descriptors = null;
            //--TRIMMABLE-BOUNDARY-END(30067966273)
            
            //--TRIMMABLE-BOUNDARY-START(133147181377)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147181377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Model === null)
                {
                    this.Model = new T().$gctor();
                    this.ModelChanged.InvokeAsync$1(this.Model);
                }
                /*var*/ let observables = $.$fPer.LCFCD$1.DataDescriptorExtensions.AutoWireDependencies($.$sl.SL.Enumerable.ToList($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCD$1.IObservableDataDescriptor, $.$sl.SL.Enumerable.OrderBy$1($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Int32, $.$fPer.LCFCD.DataDescriptorFactory.From$1(T, null).LCFCD$1$ITypeDescriptor$ApplyTo($.$fPer.LCFCA$1.SchemaContext.op_Implicit$1(1/*SchemaType.Form*/), this.ServiceFactory, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider)), [ $.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider).op_Implicit($.$box(this.Model, T)), $.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider).op_Implicit(this.FilterProperty) ], null, null)).LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$Values, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                {
                    return (this.FieldOrder?.Invoke(c) ?? null) ?? 0;
                }, $nMsdnf ??= {"r":655361,"p":[{"n":"c","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.LCFCD$1$IPropertyDescriptor$GetObservable($.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider).op_Implicit($.$box(this.Model, T)), null);
                }, $jXaOia ??= {"r":40536406,"p":[{"n":"p","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))), $.$fPer.LCFCA$1.SchemaContext.op_Implicit$1(1/*SchemaType.Form*/), $.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider).op_Implicit($.$box(this.Model, T)));
                this.descriptors = $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.ToList($.$hDPm.LCFCCF$2.DescriptorField$$(T), $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$hDPm.LCFCCF$2.DescriptorField$$(T), $.$sl.SL.Enumerable.Where($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$sl.SL.Enumerable.Where($.$fPer.LCFCD$1.IObservableDataDescriptor, observables, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return (this.FilterProperty?.Invoke((() =>
                    {
                        //new $.$fPer.LCFCA$1.SchemaContext()
                        const $t2 = $.$fPer.LCFCA$1.SchemaContext;
                        const $i2 = new $t2();
                        $i2.$ctor$3(1/*SchemaType.Form*/);
                        $i2.Context = $.$box(this.Model, T);
                        $i2.Services = this.ServiceFactory;
                        return $i2;
                    })(), p.LCFCD$1$IObservableDataDescriptor$Property) ?? null) ?? true;
                }, $aekQEc ??= {"r":262145,"p":[{"n":"p","p":40536406}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return p !== null;
                }, $bcsfCe ??= {"r":262145,"p":[{"n":"p","p":40536406}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$hDPm.LCFCCF$2.DescriptorField$$(T)))().$ctor(this,  (/*g*/ g) =>
                {
                    return new ($.$hDPm.LCFCCF$2.DescriptorField$$(T))().$ctor$2(this, g);
                }, $pUwsze ??= {"r":$.$hDPm.LCFCCF$2.DescriptorField$$(T).$h,"p":[{"n":"g","p":40536406}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCF$2.DescriptorField$$(T)), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCF$2.DescriptorField));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(133147181377)
            
            //--TRIMMABLE-BOUNDARY-START(25772998977)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772998977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "grid colm-3 gap-2");
                let $en3 = $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCF$2.DescriptorField, this.descriptors, new ($.$$.S.Func$$$($.$hDPm.LCFCCF$2.DescriptorField, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                {
                    return !o.Descriptor.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType.IsEnum || (o.Descriptor.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType.IsEnum && $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$8($.$$.S.FlagsAttribute, o.Descriptor.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType) === null);
                }, $ehHBrf ??= {"r":262145,"p":[{"n":"o","p":22959786}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let _observable = $en3.SCG$IEnumerator$$$Current;
                    {
                        if (_observable.Descriptor.LCFCD$1$IObservableDataDescriptor$IsCommented(1/*SchemaType.Form*/))
                        {
                            continue;
                        }
                        /*var*/ let observable = _observable.Descriptor;
                        __builder.OpenElement(2, "div");
                        __builder.AddAttribute$5(3, "class", "stack");
                        __builder.OpenElement(4, "label");
                        __builder.AddAttribute$5(5, "class", "text-italic mgb-2");
                        __builder.AddContent$4(6, observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$Label);
                        if (observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$Unit !== null)
                        {
                            __builder.AddContent$4(7, " (");
                            __builder.AddContent$4(8, observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$Unit);
                            __builder.AddContent$4(9, ")");
                        }
                        __builder.CloseElement();
                        __builder.AddMarkupContent(10, "\r\n            ");
                        __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$hDPm.LCFCI.IFormField), 11);
                        __builder.AddComponentParameter(12, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.IFormField, _observable));
                        __builder.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddContent$1(14, $.$hDPm.LCFCCI$1.InputEditor$$(T).Dynamic$2(this, observable, $.$fPer.LCFC.Theme.None, "bd corner", (4131/*InputEditorFeatures.Default*/ & ~2/*InputEditorFeatures.BorderBottom*/ & ~8/*InputEditorFeatures.Highlight*/) | 4/*InputEditorFeatures.BorderAll*/, null, null));
                        }), $uNiMni ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n");
                __builder.OpenElement(16, "div");
                __builder.AddAttribute$5(17, "class", "grid colm-2 gap-2 mgt-10");
                let $en4 = $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCF$2.DescriptorField, this.descriptors, new ($.$$.S.Func$$$($.$hDPm.LCFCCF$2.DescriptorField, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.Descriptor.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType.IsEnum && $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$8($.$$.S.FlagsAttribute, o.Descriptor.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType) !== null;
                }, $EmdHGd ??= {"r":262145,"p":[{"n":"o","p":22959786}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                while ($en4.SC$1$IEnumerator$MoveNext())
                {
                    let _observable = $en4.SCG$IEnumerator$$$Current;
                    {
                        if (_observable.Descriptor.LCFCD$1$IObservableDataDescriptor$IsCommented(1/*SchemaType.Form*/))
                        {
                            continue;
                        }
                        /*var*/ let observable = _observable.Descriptor;
                        /*var*/ let options = $.$$.S.Enum.GetValues(observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType);
                        /*var*/ let baseId = $.$$.S.Guid.NewGuid().ToString();
                        /*int*/ let i = 1;
                        let $en5 = $.$$.S.Array.GetEnumerator.call(options);
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let _option = $en5.SC$1$IEnumerator$Current;
                            {
                                /*var*/ let option = _option;
                                if ($.$dspc(option, $.$$.S.Object, ($t) => $t.Equals$1, observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$DefaultValue))
                                {
                                    continue;
                                }
                                /*DelegateValueBinder<bool>*/ let binder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.Boolean))().$ctor$4(new ($.$$.S.Func$$($.$$.S.Boolean))().$ctor(this,  () =>
                                {
                                    return $.$fPer.LCFCT.EnumExtensions.IsEnumSet(observable.LCFCD$IValueProvider$Value, option, observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType);
                                }, $xDBOpe ??= {"r":262145,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/**/ v) =>
                                {
                                    return observable.LCFCD$IValueProvider$Value = v ? $.$fPer.LCFCT.EnumExtensions.SetEnum(observable.LCFCD$IValueProvider$Value, option, observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType) : $.$fPer.LCFCT.EnumExtensions.ClearEnum(observable.LCFCD$IValueProvider$Value, option, observable.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$SystemType);
                                }, $yaVQSd ??= {"r":65537,"p":[{"n":"v","p":262145}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder.OpenElement(18, "div");
                                __builder.AddAttribute$5(19, "class", "flex");
                                __builder.OpenElement(20, "input");
                                __builder.AddAttribute$5(21, "type", "checkbox");
                                __builder.AddAttribute$5(22, "class", "mgy-a clickable");
                                __builder.AddAttribute$5(23, "id", $.$strNN(baseId) + "_" + i);
                                __builder.AddAttribute$2(24, "checked", binder.Value);
                                __builder.AddAttribute$2(25, "value", $.$mac.MAC.BindConverter.FormatValue(binder.Value, null));
                                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 26, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return binder.Value = __value;
                                }, $dUAKle ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), binder.Value, null));
                                __builder.SetUpdatesAttributeName("value");
                                __builder.CloseElement();
                                __builder.AddMarkupContent(27, "\r\n                ");
                                __builder.OpenElement(28, "label");
                                __builder.AddAttribute$5(29, "class", "text-italic mgy-a mgl clickable");
                                __builder.AddAttribute$5(30, "for", $.$strNN(baseId) + "_" + i);
                                __builder.AddContent$4(31, $.$fPer.LCFCT.EnumExtensions.GetTitle(($.$cast(option, $.$$.S.Enum))));
                                __builder.CloseElement();
                                __builder.CloseElement();
                                i++;
                            }
                        }
                    }
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25772998977)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(34423854762)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IFormBuilder.ModelValue.get
            get LCFCI$IFormBuilder$ModelValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38718822058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ModelValue;
            }
            //--TRIMMABLE-BOUNDARY-END(34423854762)
            
            //--TRIMMABLE-BOUNDARY-START(25833920170)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IFormBuilder.FormType.get
            get LCFCI$IFormBuilder$FormType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8654050986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FormType;
            }
            //--TRIMMABLE-BOUNDARY-END(25833920170)
            
            //--TRIMMABLE-BOUNDARY-START(17243985578)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IFormBuilder.Fields.get
            get LCFCI$IFormBuilder$Fields()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4359083690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Fields;
            }
            //--TRIMMABLE-BOUNDARY-END(17243985578)
            
            //--TRIMMABLE-BOUNDARY-START(21478031681)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478031681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478031681)
            
            //--TRIMMABLE-BOUNDARY-START(21478031681)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21478031681)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(120262279489)
                this.Model = $.$default(T);
                //--TRIMMABLE-BOUNDARY-END(120262279489)
                
                //--TRIMMABLE-BOUNDARY-START(124557246785)
                this.ModelChanged = $.$default($.$mac.MAC.EventCallback$$(T));
                //--TRIMMABLE-BOUNDARY-END(124557246785)
                
                //--TRIMMABLE-BOUNDARY-START(30067966273)
                this.descriptors = null;
                //--TRIMMABLE-BOUNDARY-END(30067966273)
                
            }
            static $H = 3195201;
            static $h = 3195201;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137442148673),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115967312193,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 137442148673,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137442148673),
//--TRIMMABLE-BOUNDARY-START(120262279489),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90197508417,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 163211952449,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 83886081
      },
      "n": "Model",
      "d": this.$h,
      "H": 120262279489,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120262279489),
//--TRIMMABLE-BOUNDARY-START(124557246785),
    {
      "p": $.$mac.MAC.EventCallback$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98787443009,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 171801887041,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 83886081
      },
      "n": "ModelChanged",
      "d": this.$h,
      "H": 124557246785,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124557246785),
//--TRIMMABLE-BOUNDARY-START(34362933569),
    {
      "p": $.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55837770049,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 146032083265,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 83886081
      },
      "n": "FieldOrder",
      "d": this.$h,
      "H": 34362933569,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34362933569),
//--TRIMMABLE-BOUNDARY-START(42952868161),
    {
      "p": 42305878,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73017639233,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 154622017857,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 83886081
      },
      "n": "FilterProperty",
      "d": this.$h,
      "H": 42952868161,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952868161),
//--TRIMMABLE-BOUNDARY-START(128852214081),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107377377601,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "ModelValue",
      "d": this.$h,
      "H": 128852214081,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128852214081),
//--TRIMMABLE-BOUNDARY-START(47247835457),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81607573825,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "FormType",
      "d": this.$h,
      "H": 47247835457,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247835457),
//--TRIMMABLE-BOUNDARY-START(38657900865),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64427704641,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Fields",
      "d": this.$h,
      "H": 38657900865,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657900865)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176096854337),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 176096854337,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176096854337),
//--TRIMMABLE-BOUNDARY-START(133147181377),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": this.$h,
      "H": 133147181377,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(133147181377),
//--TRIMMABLE-BOUNDARY-START(25772998977),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 25772998977,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25772998977)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067966273),
    {
      "t": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCF$2.DescriptorField).$h,
      "n": "descriptors",
      "d": this.$h,
      "H": 30067966273,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30067966273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21478031681),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 21478031681,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478031681)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 4
    }
  ],
  "r": 1,
  "H": 3195201,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCI.IFormBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.Editor<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}Editor$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3195201)
        
        

        //--TRIMMABLE-BOUNDARY-START(3064129)
        $asm.$cls(`$QoDz.LCIRCS.RMSStationAttendantPolicyHandler`, ($self) => class RMSStationAttendantPolicyHandler extends $.$maa.MAA.AuthorizationHandler$$($.$QoDz.LCIRCS.RMSStationAttendantPolicyRequirement)
        {
            //--TRIMMABLE-BOUNDARY-START(12887966017)
            /*RMSClientAppViewModel*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(12887966017)
            
            //--TRIMMABLE-BOUNDARY-START(4298031425)
            $ctor$2(/*RMSClientAppViewModel*/ service)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298031425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298031425)
            
            //--TRIMMABLE-BOUNDARY-START(8592998721)
            /*Task *//*async*/  HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*RMSStationAttendantPolicyRequirement*/ requirement)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592998721);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!((context.User.Identity?.SSP$1$IIdentity$IsAuthenticated ?? null) ?? false))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    ($t1 = this.service.EnsureLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*LivingThing.Core.Frameworks.Common.Models.UserServiceSubscriptionModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>?*/ let __ca1__;
                    /*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel?*/ let __ca2__;
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Common.Models.IOTServiceAttendantModel>?*/ let __ca3__;
                    if ((__ca1__ = this.service.Selected) !== null ? ((__ca2__ = __ca1__.Service) !== null ? ((__ca3__ = __ca2__.LoginAttendants) !== null ? $.$sl.SL.Enumerable.Any$1($.$XBGm.LCICM.IOTServiceAttendantModel, __ca3__) : false) : false) : false)
                    {
                        context.Succeed(requirement);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8592998721)
            
            static $h = 3064129;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maa.MAA.AuthorizationHandler$$($.$QoDz.LCIRCS.RMSStationAttendantPolicyRequirement); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592998721),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        },
        {
          "n": "requirement",
          "p": 3129665
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 3064129,
      "h": 8592998721,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(8592998721)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887966017),
    {
      "t": 3916097,
      "n": "service",
      "d": 3064129,
      "h": 12887966017,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887966017)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298031425),
    {
      "p": [
        {
          "n": "service",
          "p": 3916097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3064129,
      "h": 4298031425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298031425)
  ],
  "h": 3064129
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Services.RMSStationAttendantPolicyHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Services${separator}RMSStationAttendantPolicyHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3064129)
        
        

        //--TRIMMABLE-BOUNDARY-START(1950017)
        $asm.$cls(`$QoDz.LCIRCP.Dashboard`, ($self) => class Dashboard extends $.$lJUR.LCFCS.ApplicationLayoutPage
        {
            //--TRIMMABLE-BOUNDARY-START(68721426753)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(68721426753)
            
            //--TRIMMABLE-BOUNDARY-START(51541557569)
            /*IMessagePipeFactory*/ MessagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(51541557569)
            
            //--TRIMMABLE-BOUNDARY-START(64426459457)
            /*int*/ sequenceNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(64426459457)
            
            //--TRIMMABLE-BOUNDARY-START(60131492161)
            /*Task *//*async*/  Reload()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131492161);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.Reload(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.sequenceNumber++;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60131492161)
            
            //--TRIMMABLE-BOUNDARY-START(55836524865)
            /*string */ get OptimizedComponentName()
            {
                return "dashboard applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(55836524865)
            
            //--TRIMMABLE-BOUNDARY-START(47246590273)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246590273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
                this.MessagePipe = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(47246590273)
            
            //--TRIMMABLE-BOUNDARY-START(17181819201)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181819201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionName", "Header");
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$QoDz.LCIRCS$1.TopHeader$$($.$QoDz.LCIRCP.Dashboard), 3);
                    __builder2.AddComponentParameter(4, "Title", "DASHBOARD");
                    __builder2.AddComponentParameter(5, "OnDateRangeChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Reload))));
                    __builder2.CloseComponent();
                }), $pDGvWj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1950017,"h":0,"f":17825794}));
                __builder.CloseComponent();
                /*LivingThing.Core.Frameworks.Common.Models.UserServiceSubscriptionModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>?*/ let __ca1__;
                /*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel?*/ let __ca2__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel>?*/ let __ca3__;
                if (((__ca1__ = this.Service.Selected) !== null ? ((__ca2__ = __ca1__.Service) !== null ? ((__ca3__ = __ca2__.Scopes) !== null ? $.$sl.SL.Enumerable.Count$1($.$OgAC.LCIRCM.RMSStationModel, __ca3__) : null) : null) : null) === 1)
                {
                    __builder.OpenComponent$1($.$QoDz.LCIRCS$1.StationView, 6);
                    __builder.AddComponentParameter(7, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OgAC.LCIRCM.RMSStationModel, $.$sl.SL.Enumerable.First$1($.$OgAC.LCIRCM.RMSStationModel, this.Service.Selected.Service.Scopes)));
                    __builder.CloseComponent();
                }
                else 
                {
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181819201)
            
            //--TRIMMABLE-BOUNDARY-START(12886851905)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886851905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886851905)
            
            //--TRIMMABLE-BOUNDARY-START(12886851905)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12886851905)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(68721426753)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(68721426753)
                
                //--TRIMMABLE-BOUNDARY-START(51541557569)
                this.MessagePipe = null;
                //--TRIMMABLE-BOUNDARY-END(51541557569)
                
            }
            static $h = 1950017;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721426753),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951622977,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901295937,
        "f": 83886081
      },
      "n": "Service",
      "d": 1950017,
      "h": 68721426753,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68721426753),
//--TRIMMABLE-BOUNDARY-START(51541557569),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771753793,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77311361345,
        "f": 83886081
      },
      "n": "MessagePipe",
      "d": 1950017,
      "h": 51541557569,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541557569),
//--TRIMMABLE-BOUNDARY-START(55836524865),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361688385,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1950017,
      "h": 55836524865,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836524865)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131492161),
    {
      "r": 178454529,
      "n": "Reload",
      "d": 1950017,
      "h": 60131492161,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(60131492161),
//--TRIMMABLE-BOUNDARY-START(47246590273),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1950017,
      "h": 47246590273,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246590273),
//--TRIMMABLE-BOUNDARY-START(17181819201),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1950017,
      "h": 17181819201,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181819201)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64426459457),
    {
      "t": 655361,
      "n": "sequenceNumber",
      "d": 1950017,
      "h": 64426459457,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64426459457)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886851905),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1950017,
      "h": 12886851905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886851905)
  ],
  "h": 1950017,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "iRMS",
          "t": 1310721
        },
        {
          "v": 1,
          "t": 655361
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "v": "mdi mdi-view-dashboard",
          "t": 1310721
        },
        {
          "v": 12328243,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1556801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Dashboard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Dashboard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1950017)
        
        

        //--TRIMMABLE-BOUNDARY-START(3522881)
        $asm.$cls(`$QoDz.LCIRCS$1.TopHeader<>`, (T) => $asm.$gt(`$QoDz.LCIRCS$1.TopHeader<>`, [T], ($self) => class TopHeader$$ extends $.$hDPm.LCFCC$1.BaseModelContainer$$($.$QoDz.LCIRCS$1.TopHeaderContext)
        {
            //--TRIMMABLE-BOUNDARY-START(137442476353)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(137442476353)
            
            //--TRIMMABLE-BOUNDARY-START(107377705281)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(107377705281)
            
            //--TRIMMABLE-BOUNDARY-START(184687116609)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(184687116609)
            
            //--TRIMMABLE-BOUNDARY-START(188982083905)
            /*RenderFragment?*/ TitleView = null;
            //--TRIMMABLE-BOUNDARY-END(188982083905)
            
            //--TRIMMABLE-BOUNDARY-START(111672672577)
            /*EventCallback*/ OnDateRangeChanged;
            //--TRIMMABLE-BOUNDARY-END(111672672577)
            
            //--TRIMMABLE-BOUNDARY-START(115967639873)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967639873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$add_BoxChanged(new ($.$fPer.LCFC.AsyncEventHandler$$($.$vWqU.LCFCC.BoxSize))().$ctor(this, this.UI_BoxChanged));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(115967639873)
            
            //--TRIMMABLE-BOUNDARY-START(197572018497)
            /*Task *//*async*/  UI_BoxChanged(/*object*/ sender, /*BoxSize?*/ e)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197572018497);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Client.Blazor\\TopHeader.razor.cs", "UI_BoxChanged", 35), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197572018497)
            
            //--TRIMMABLE-BOUNDARY-START(38658228545)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658228545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$add_BoxChanged(new ($.$fPer.LCFC.AsyncEventHandler$$($.$vWqU.LCFCC.BoxSize))().$ctor(this, this.UI_BoxChanged));
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(38658228545)
            
            //--TRIMMABLE-BOUNDARY-START(34363261249)
            /*Task */ DateRateChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363261249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnDateRangeChanged.InvokeAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(34363261249)
            
            //--TRIMMABLE-BOUNDARY-START(128852541761)
            /*Task *//*async*/  Print()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128852541761);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.PrintElement$1(this.JavaScript, "page-content", null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128852541761)
            
            //--TRIMMABLE-BOUNDARY-START(124557574465)
            /*string */ get PDFPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017966913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$QoDz.LCIRC.Utility.PDFPath(T.$type, null, this.UnitOfWork, `Report.pdf`, "#page-content,wait(5000)");
            }
            //--TRIMMABLE-BOUNDARY-END(124557574465)
            
            //--TRIMMABLE-BOUNDARY-START(133147509057)
            /*Task *//*async*/  SendAsEmail()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133147509057);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let email = ($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$$.S.String, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Email addresses", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Please enter destination emails, separated by space!", false), null, 0n, null, 0, 4, 4131, null, null, "Emails", null, $.$QoDz.LCIRC.Utility.PopupConfiguration), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    /*var*/ let hostPath = `https://${$.$strNN(this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$RemoteHost)}/pdfHost?h=${$.$strNN(T.$type.GetType$1().FullName)}`;
                    ($t4 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendHTMLEmail(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, "RMS", `Report`, `RMS/pdfHost?h=${$.$strNN($.$$.S.Object.GetType.call(this).FullName)}`, null, $.$$.S.String.Split$1.call(email, /* */ 32, 0)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.SnackBar($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Sent", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Emails sent successfully`, false), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t5 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.PageBackgroundTheme = $.$fPer.LCFC.Theme.Primary;
                        return $i5;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133147509057)
            
            //--TRIMMABLE-BOUNDARY-START(120262607169)
            /*string */ get OptimizedComponentName()
            {
                return "topheader";
            }
            //--TRIMMABLE-BOUNDARY-END(120262607169)
            
            //--TRIMMABLE-BOUNDARY-START(193277051201)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193277051201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch6 = parameter.Name;
                switch($switch6)
                {
                    case "Title":
                    this.Title = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "TitleView":
                    this.TitleView = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "OnDateRangeChanged":
                    this.OnDateRangeChanged = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(193277051201)
            
            //--TRIMMABLE-BOUNDARY-START(103082737985)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082737985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
                this.JavaScript = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(103082737985)
            
            //--TRIMMABLE-BOUNDARY-START(30068293953)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068293953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACW.PageTitle, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(2, this.Title);
                }), $PrsLGg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.OpenComponent$1($.$macw.MACF.EditForm, 4);
                __builder.AddComponentParameter(5, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                __builder.AddComponentParameter(6, "Class", `fill flex ${$.$strNN(this.Class)} pos-rel bg-primary-01 pd mgb corner`);
                __builder.AddAttribute$3(7, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(8, "h3");
                        __builder2.AddAttribute$5(9, "class", "mgy-a fsz-18 cl-primary");
                        if (this.TitleView !== null)
                        {
                            __builder2.AddContent$1(10, this.TitleView);
                        }
                        else 
                        {
                            __builder2.AddContent$4(11, this.Title);
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(12, "\r\n    <div class=\"fill\"></div>");
                        if ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false)
                        {
                            __builder2.OpenElement(13, "popup");
                            __builder2.AddAttribute$6(14, "class");
                            __builder2.AddMarkupContent(15, "<button class=\"mdi mdi-chevron-down bg-transparent fsz-20\" tabindex=\"-1\"></button>\r\n            ");
                            __builder2.OpenElement(16, "pop");
                            __builder2.AddAttribute$5(17, "class", "at toptobottom righttoright sd z-2");
                            __builder2.OpenElement(18, "div");
                            __builder2.AddAttribute$5(19, "class", "stack pd bg-card");
                            __builder2.AddContent$1(20, (this.ChildContent?.Invoke($.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext).op_Implicit$1((() =>
                            {
                                //new $.$QoDz.LCIRCS$1.TopHeaderContext()
                                const $t7 = $.$QoDz.LCIRCS$1.TopHeaderContext;
                                const $i7 = new $t7();
                                $i7.$ctor$2();
                                $i7.IsMobile = true;
                                $i7.ItemClass = "mgb";
                                return $i7;
                            })())) ?? null));
                            if (this.OnDateRangeChanged.HasDelegate)
                            {
                                $.$QoDz._LCIRCST.TypeInference.CreateInputEditor_0($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), __builder2, 21, 22, 55n, 23, "bg-card cl-text mgb", 24, this.Service.DashboardDateRange, 25, $.$mac.MAC.EventCallback.Factory.Create$6($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), new ($.$$.S.Func$$$($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    this.Service.DashboardDateRange = $.$clone(__value);
                                    return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.DateRateChanged));
                                }, $fcHKnh ??= {"r":178454529,"p":[{"n":"__value","p":$.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this.Service.DashboardDateRange), this.Service.DashboardDateRange)), 26, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Service"), "DashboardDateRange"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $ehikKd ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke()));
                            }
                            if (T.$type !== $.$$.S.Object.$type)
                            {
                                __builder2.OpenElement(27, "popup");
                                __builder2.AddAttribute$5(28, "class", "pd bg-card cl-text mgl pos-rel corner");
                                __builder2.AddMarkupContent(29, "<div tabindex=\"-1\" class=\"clickable nowrap flex\"><span class=\"fill\">Actions</span>\r\n                                <i class=\"mdi mdi-chevron-down\"></i></div>\r\n                            ");
                                __builder2.OpenElement(30, "pop");
                                __builder2.AddAttribute$5(31, "class", "at toptobottom righttoright miwx-15 z-2");
                                __builder2.OpenElement(32, "div");
                                __builder2.AddAttribute$5(33, "class", "bg-card corner bd stack");
                                __builder2.OpenElement(34, "div");
                                __builder2.AddAttribute$5(35, "class", "bg-card pd clickable");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 36, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Print)));
                                __builder2.AddContent$4(37, "Print");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(38, "\r\n                                    ");
                                __builder2.OpenElement(39, "a");
                                __builder2.AddAttribute$5(40, "class", "bg-card pd bdt clickable");
                                __builder2.AddAttribute$5(41, "href", this.PDFPath);
                                __builder2.AddAttribute$5(42, "target", "_blank");
                                __builder2.AddContent$4(43, "Export PDF");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(44, "\r\n                                    ");
                                __builder2.OpenElement(45, "div");
                                __builder2.AddAttribute$5(46, "class", "bg-card pd bdt clickable");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 47, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.SendAsEmail)));
                                __builder2.AddContent$4(48, "Send as Email");
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        else 
                        {
                            __builder2.AddContent$1(49, (this.ChildContent?.Invoke($.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext).op_Implicit$1((() =>
                            {
                                //new $.$QoDz.LCIRCS$1.TopHeaderContext()
                                const $t8 = $.$QoDz.LCIRCS$1.TopHeaderContext;
                                const $i8 = new $t8();
                                $i8.$ctor$2();
                                $i8.ItemClass = "mgl";
                                return $i8;
                            })())) ?? null));
                            if (this.OnDateRangeChanged.HasDelegate)
                            {
                                $.$QoDz._LCIRCST.TypeInference.CreateInputEditor_1($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), __builder2, 50, 51, 55n, 52, "bg-card cl-text mgl", 53, this.Service.DashboardDateRange, 54, $.$mac.MAC.EventCallback.Factory.Create$6($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), new ($.$$.S.Func$$$($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)), $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    this.Service.DashboardDateRange = $.$clone(__value);
                                    return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.DateRateChanged));
                                }, $cQWGuk ??= {"r":178454529,"p":[{"n":"__value","p":$.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this.Service.DashboardDateRange), this.Service.DashboardDateRange)), 55, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Service"), "DashboardDateRange"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $AtXTWc ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke()));
                            }
                            if (T.$type !== $.$$.S.Object.$type)
                            {
                                __builder2.OpenElement(56, "popup");
                                __builder2.AddAttribute$5(57, "class", "pd bg-card cl-text mgl pos-rel corner");
                                __builder2.AddMarkupContent(58, "<span tabindex=\"-1\" class=\"clickable nowrap\">\r\n                    Actions\r\n                    <i class=\"mdi mdi-chevron-down\"></i></span>\r\n                ");
                                __builder2.OpenElement(59, "pop");
                                __builder2.AddAttribute$5(60, "class", "at toptobottom righttoright miwx-15 z-2");
                                __builder2.OpenElement(61, "div");
                                __builder2.AddAttribute$5(62, "class", "bg-card corner bd stack");
                                __builder2.OpenElement(63, "div");
                                __builder2.AddAttribute$5(64, "class", "bg-card pd clickable");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 65, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Print)));
                                __builder2.AddContent$4(66, "Print");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(67, "\r\n                        ");
                                __builder2.OpenElement(68, "a");
                                __builder2.AddAttribute$5(69, "class", "bg-card pd bdt clickable");
                                __builder2.AddAttribute$5(70, "href", this.PDFPath);
                                __builder2.AddAttribute$5(71, "target", "_blank");
                                __builder2.AddContent$4(72, "Export PDF");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(73, "\r\n                        ");
                                __builder2.OpenElement(74, "div");
                                __builder2.AddAttribute$5(75, "class", "bg-card pd bdt clickable");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 76, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.SendAsEmail)));
                                __builder2.AddContent$4(77, "Send as Email");
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                    }, $gbdKjf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $oNZLRa ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(30068293953)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25773326657)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773326657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25773326657)
            
            //--TRIMMABLE-BOUNDARY-START(25773326657)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(25773326657)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(137442476353)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(137442476353)
                
                //--TRIMMABLE-BOUNDARY-START(107377705281)
                this.JavaScript = null;
                //--TRIMMABLE-BOUNDARY-END(107377705281)
                
                //--TRIMMABLE-BOUNDARY-START(111672672577)
                this.OnDateRangeChanged = $.$default($.$mac.MAC.EventCallback);
                //--TRIMMABLE-BOUNDARY-END(111672672577)
                
            }
            static $H = 3522881;
            static $h = 3522881;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseModelContainer$$($.$QoDz.LCIRCS$1.TopHeaderContext); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137442476353),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81607901505,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 163212280129,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 137442476353,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137442476353),
//--TRIMMABLE-BOUNDARY-START(107377705281),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47248163137,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 146032410945,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 83886081
      },
      "n": "JavaScript",
      "d": this.$h,
      "H": 107377705281,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377705281),
//--TRIMMABLE-BOUNDARY-START(184687116609),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90197836097,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 171802214721,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 83886081
      },
      "n": "Title",
      "d": this.$h,
      "H": 184687116609,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184687116609),
//--TRIMMABLE-BOUNDARY-START(188982083905),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98787770689,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 180392149313,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 83886081
      },
      "n": "TitleView",
      "d": this.$h,
      "H": 188982083905,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188982083905),
//--TRIMMABLE-BOUNDARY-START(111672672577),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55838097729,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 154622345537,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 83886081
      },
      "n": "OnDateRangeChanged",
      "d": this.$h,
      "H": 111672672577,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111672672577),
//--TRIMMABLE-BOUNDARY-START(124557574465),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73017966913,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331650
      },
      "n": "PDFPath",
      "d": this.$h,
      "H": 124557574465,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124557574465),
//--TRIMMABLE-BOUNDARY-START(120262607169),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64428032321,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 120262607169,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120262607169)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115967639873),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": this.$h,
      "H": 115967639873,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(115967639873),
//--TRIMMABLE-BOUNDARY-START(197572018497),
    {
      "r": 178454529,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 417192
        }
      ],
      "n": "UI_BoxChanged",
      "d": this.$h,
      "H": 197572018497,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(197572018497),
//--TRIMMABLE-BOUNDARY-START(38658228545),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 38658228545,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38658228545),
//--TRIMMABLE-BOUNDARY-START(34363261249),
    {
      "r": 178454529,
      "n": "DateRateChanged",
      "d": this.$h,
      "H": 34363261249,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34363261249),
//--TRIMMABLE-BOUNDARY-START(128852541761),
    {
      "r": 178454529,
      "n": "Print",
      "d": this.$h,
      "H": 128852541761,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(128852541761),
//--TRIMMABLE-BOUNDARY-START(133147509057),
    {
      "r": 178454529,
      "n": "SendAsEmail",
      "d": this.$h,
      "H": 133147509057,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(133147509057),
//--TRIMMABLE-BOUNDARY-START(193277051201),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 193277051201,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193277051201),
//--TRIMMABLE-BOUNDARY-START(103082737985),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 103082737985,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103082737985),
//--TRIMMABLE-BOUNDARY-START(30068293953),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 30068293953,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30068293953)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25773326657),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 25773326657,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773326657)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 3522881,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.TopHeader<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}TopHeader$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3522881)
        
        

        //--TRIMMABLE-BOUNDARY-START(1229121)
        $asm.$cls(`$QoDz.LCIRCDR$1.RelayCoilDeviceRenderer`, ($self) => class RelayCoilDeviceRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591163713)
            /*RenderFragment */ RenderToFragment(/*RelayCoilDevice.RelayCoilWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591163713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QoDz.LCIRCDR$1.RelayCoilView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591163713)
            
            //--TRIMMABLE-BOUNDARY-START(4296196417)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296196417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296196417)
            
            //--TRIMMABLE-BOUNDARY-START(4296196417)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296196417)
            
            static $h = 1229121;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591163713),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 929446
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1229121,
      "h": 8591163713,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591163713)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296196417),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1229121,
      "h": 4296196417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296196417)
  ],
  "h": 1229121
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.RelayCoil.RelayCoilDeviceRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}RelayCoil${separator}RelayCoilDeviceRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1229121)
        
        

        //--TRIMMABLE-BOUNDARY-START(770369)
        $asm.$cls(`$QoDz.LCIRCDD$1.DieselTankCoverDeviceRenderer`, ($self) => class DieselTankCoverDeviceRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590704961)
            /*RenderFragment */ RenderToFragment(/*DieselTankCoverDevice.DieselTankCoverWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590704961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QoDz.LCIRCDD$1.DieselTankCoverView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590704961)
            
            //--TRIMMABLE-BOUNDARY-START(4295737665)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295737665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295737665)
            
            //--TRIMMABLE-BOUNDARY-START(4295737665)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295737665)
            
            static $h = 770369;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590704961),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 536230
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 770369,
      "h": 8590704961,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590704961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295737665),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 770369,
      "h": 4295737665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295737665)
  ],
  "h": 770369
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.DieselTankCover.DieselTankCoverDeviceRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}DieselTankCover${separator}DieselTankCoverDeviceRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(770369)
        
        

        //--TRIMMABLE-BOUNDARY-START(901441)
        $asm.$cls(`$QoDz.LCIRCDD$2.DoorOpenedDeviceRenderer`, ($self) => class DoorOpenedDeviceRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590836033)
            /*RenderFragment */ RenderToFragment(/*DoorOpenedDevice.DoorOpenedWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590836033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QoDz.LCIRCDD$2.DoorOpenedView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590836033)
            
            //--TRIMMABLE-BOUNDARY-START(4295868737)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295868737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295868737)
            
            //--TRIMMABLE-BOUNDARY-START(4295868737)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295868737)
            
            static $h = 901441;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590836033),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 667302
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 901441,
      "h": 8590836033,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590836033)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295868737),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 901441,
      "h": 4295868737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295868737)
  ],
  "h": 901441
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.DoorOpened.DoorOpenedDeviceRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}DoorOpened${separator}DoorOpenedDeviceRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(901441)
        
        

        //--TRIMMABLE-BOUNDARY-START(639297)
        $asm.$cls(`$QoDz.LCIRCDD.DCVoltageDeviceRenderer`, ($self) => class DCVoltageDeviceRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590573889)
            /*RenderFragment */ RenderToFragment(/*DCVoltageDevice.DCVoltageWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590573889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QoDz.LCIRCDD.DCVoltageView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590573889)
            
            //--TRIMMABLE-BOUNDARY-START(4295606593)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295606593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295606593)
            
            //--TRIMMABLE-BOUNDARY-START(4295606593)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295606593)
            
            static $h = 639297;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590573889),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 405158
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 639297,
      "h": 8590573889,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590573889)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295606593),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 639297,
      "h": 4295606593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295606593)
  ],
  "h": 639297
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.DCVoltage.DCVoltageDeviceRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}DCVoltage${separator}DCVoltageDeviceRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(639297)
        
        

        //--TRIMMABLE-BOUNDARY-START(508225)
        $asm.$cls(`$QoDz.LCIRCDC.CameraDeviceRenderer`, ($self) => class CameraDeviceRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.CameraDevice.CameraWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590442817)
            /*RenderFragment */ RenderToFragment(/*CameraDevice.CameraWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590442817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QoDz.LCIRCDC.CameraView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590442817)
            
            //--TRIMMABLE-BOUNDARY-START(4295475521)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295475521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295475521)
            
            //--TRIMMABLE-BOUNDARY-START(4295475521)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295475521)
            
            static $h = 508225;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.CameraDevice.CameraWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590442817),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 274086
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 508225,
      "h": 8590442817,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590442817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295475521),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 508225,
      "h": 4295475521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295475521)
  ],
  "h": 508225
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.CameraDevice.CameraWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.Camera.CameraDeviceRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}Camera${separator}CameraDeviceRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(508225)
        
        

        //--TRIMMABLE-BOUNDARY-START(1163585)
        $asm.$cls(`$QoDz.LCIRCDR.RegisterViewDeviceRenderer`, ($self) => class RegisterViewDeviceRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8591098177)
            /*RenderFragment */ RenderToFragment(/*RegisterViewDevice.RegisterViewWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591098177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$QoDz.LCIRCDR.RegisterView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591098177)
            
            //--TRIMMABLE-BOUNDARY-START(4296130881)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296130881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296130881)
            
            //--TRIMMABLE-BOUNDARY-START(4296130881)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296130881)
            
            static $h = 1163585;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591098177),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 798374
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 1163585,
      "h": 8591098177,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591098177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296130881),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1163585,
      "h": 4296130881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296130881)
  ],
  "h": 1163585
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.RegisterView.RegisterViewDeviceRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}RegisterView${separator}RegisterViewDeviceRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1163585)
        
        

        //--TRIMMABLE-BOUNDARY-START(2474305)
        $asm.$cls(`$QoDz.LCIRCP.SettingsTypeDescriptor`, ($self) => class SettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QoDz.LCIRCP.Settings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297441601)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297441601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QoDz.LCIRCP.SettingsTypeDescriptor.GenerateProperties($.$QoDz.LCIRCP.Settings, this, factory);
                    }, $htkjMk ??= {"r":65537,"n":"","d":2474305,"h":0,"f":17825794}), 0, "SettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Client.Blazor\\Pages_Settings_LivingThing.Core.IOT.RMS.Client.Pages.SettingsTypeDescriptorBuilder.g.cs", "SettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297441601)
            
            //--TRIMMABLE-BOUNDARY-START(12887376193)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887376193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QoDz.LCIRCP.Settings.$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QoDz.LCIRCV.RMSClientAppViewModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Service";
                        $i1.DelaredOn = "LivingThing.Core.IOT.RMS.Client.Pages.Settings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QoDz.LCIRCP.SettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$QoDz.LCIRCV.RMSClientAppViewModel, ($.$cast(target, $.$QoDz.LCIRCP.Settings)).Service);
                        }, $UVuBhl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2474305,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QoDz.LCIRCP.SettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Service = value.AsReference($.$QoDz.LCIRCV.RMSClientAppViewModel);
                        }, $mDeVvj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2474305,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887376193)
            
            //--TRIMMABLE-BOUNDARY-START(17182343489)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Client.Pages.Settings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182343489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QoDz.LCIRCV.RMSClientAppViewModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$QoDz.LCIRCV.RMSClientAppViewModel)))
                    {
                        _target.Service = _Service;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182343489)
            
            //--TRIMMABLE-BOUNDARY-START(8592408897)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Client.Pages.Settings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592408897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QoDz.LCIRCP.Settings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QoDz.LCIRCP.Settings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QoDz.LCIRCP.Settings)))
                {
                    /*var*/ let result = $.$QoDz.LCIRCP.SettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QoDz.LCIRCP.Settings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QoDz.LCIRCP.Settings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QoDz.LCIRCP.Settings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592408897)
            
            static $h = 2474305;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QoDz.LCIRCP.Settings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887376193),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2474305,
      "h": 12887376193,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887376193),
//--TRIMMABLE-BOUNDARY-START(17182343489),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2343233,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2474305,
      "h": 17182343489,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182343489),
//--TRIMMABLE-BOUNDARY-START(8592408897),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2343233,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2474305,
      "h": 8592408897,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592408897)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297441601),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2474305,
      "h": 4297441601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297441601)
  ],
  "h": 2474305
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QoDz.LCIRCP.Settings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.SettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}SettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2474305)
        
        

        //--TRIMMABLE-BOUNDARY-START(3260737)
        $asm.$cls(`$QoDz.LCIRCS$1.NoActionTopHeader`, ($self) => class NoActionTopHeader extends $.$QoDz.LCIRCS$1.TopHeader$$($.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(17183129921)
            /*string */ get OptimizedComponentName()
            {
                return "noactiontopheader topheader";
            }
            //--TRIMMABLE-BOUNDARY-END(17183129921)
            
            //--TRIMMABLE-BOUNDARY-START(4298228033)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298228033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298228033)
            
            //--TRIMMABLE-BOUNDARY-START(4298228033)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4298228033)
            
            static $h = 3260737;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$QoDz.LCIRCS$1.TopHeader$$($.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183129921),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888162625,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3260737,
      "h": 17183129921,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183129921)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298228033),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3260737,
      "h": 4298228033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298228033)
  ],
  "h": 3260737
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.NoActionTopHeader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}NoActionTopHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3260737)
        
        

        //--TRIMMABLE-BOUNDARY-START(835905)
        $asm.$cls(`$QoDz.LCIRCDD$1.DieselTankCoverView`, ($self) => class DieselTankCoverView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(60130378049)
            /*StationView*/ Station = null;
            //--TRIMMABLE-BOUNDARY-END(60130378049)
            
            //--TRIMMABLE-BOUNDARY-START(42950508865)
            /*bool */ get Opened()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475672385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Gateway === null)
                {
                    return false;
                }
                /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status ?? null);
                /*var*/ let openLogic = this.ViewModel.Active === 0/*IOT.Common.Models.Logic.LOW*/ ? false : true;
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayCollectedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayDigitalInputs?*/ let __ca2__;
                return (((__ca1__ = stat) !== null ? ((__ca2__ = __ca1__.DigtalInputs) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.Boolean, __ca2__.States, this.ViewModel.Terminal) : false) : false)) === openLogic;
            }
            //--TRIMMABLE-BOUNDARY-END(42950508865)
            
            //--TRIMMABLE-BOUNDARY-START(47245476161)
            /*string */ get OptimizedComponentName()
            {
                return "dieseltankcoverview";
            }
            //--TRIMMABLE-BOUNDARY-END(47245476161)
            
            //--TRIMMABLE-BOUNDARY-START(64425345345)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425345345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Station":
                    this.Station = $.$cast(parameter.Value, $.$QoDz.LCIRCS$1.StationView);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(64425345345)
            
            //--TRIMMABLE-BOUNDARY-START(12885737793)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bd pd sd bg-card stack text-center"))));
                __builder.OpenElement(2, "h3");
                __builder.AddAttribute$5(3, "class", "mg-0");
                __builder.AddContent$4(4, this.ViewModel.Name);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "i");
                __builder.AddAttribute$5(7, "class", $.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-lock") + $.$strNN((this.Opened ? "-open" : ""))) + " fsz-50") + " cl-") + $.$strNN((this.Opened ? "error" : "success")));
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n    ");
                __builder.OpenElement(9, "h3");
                __builder.AddAttribute$5(10, "class", $.$strNN("mg-0" + " cl-") + $.$strNN((this.Opened ? "error" : "success")));
                __builder.AddContent$4(11, this.Opened ? "OPENED" : "SECURED");
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885737793)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590770497)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590770497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770497)
            
            //--TRIMMABLE-BOUNDARY-START(8590770497)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590770497)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130378049)
                this.Station = null;
                //--TRIMMABLE-BOUNDARY-END(60130378049)
                
            }
            static $h = 835905;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130378049),
    {
      "p": 3457345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655541569,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835410753,
        "f": 83886081
      },
      "n": "Station",
      "d": 835905,
      "h": 60130378049,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130378049),
//--TRIMMABLE-BOUNDARY-START(42950508865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475672385,
        "f": 50331650
      },
      "n": "Opened",
      "d": 835905,
      "h": 42950508865,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950508865),
//--TRIMMABLE-BOUNDARY-START(47245476161),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065606977,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 835905,
      "h": 47245476161,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245476161)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425345345),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 835905,
      "h": 64425345345,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425345345),
//--TRIMMABLE-BOUNDARY-START(12885737793),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 835905,
      "h": 12885737793,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885737793)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590770497),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 835905,
      "h": 8590770497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590770497)
  ],
  "h": 835905
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.DieselTankCover.DieselTankCoverView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}DieselTankCover${separator}DieselTankCoverView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(835905)
        
        

        //--TRIMMABLE-BOUNDARY-START(704833)
        $asm.$cls(`$QoDz.LCIRCDD.DCVoltageView`, ($self) => class DCVoltageView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(55835279681)
            /*StationView*/ Station = null;
            //--TRIMMABLE-BOUNDARY-END(55835279681)
            
            //--TRIMMABLE-BOUNDARY-START(64425214273)
            /*double? */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655410497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Gateway === null)
                {
                    return 0;
                }
                /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status ?? null);
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayCollectedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayAnalogInputs?*/ let __ca2__;
                /*var*/ let value = ((__ca1__ = stat) !== null ? ((__ca2__ = __ca1__.AnalogInputs) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.Double, __ca2__.Values, this.ViewModel.Terminal) : null) : null);
                if (value !== null)
                {
                    value = (value - this.ViewModel.Offset) * this.ViewModel.Scale;
                }
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(64425214273)
            
            //--TRIMMABLE-BOUNDARY-START(42950377793)
            /*string */ get OptimizedComponentName()
            {
                return "dcvoltageview";
            }
            //--TRIMMABLE-BOUNDARY-END(42950377793)
            
            //--TRIMMABLE-BOUNDARY-START(60130246977)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130246977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Station":
                    this.Station = $.$cast(parameter.Value, $.$QoDz.LCIRCS$1.StationView);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(60130246977)
            
            //--TRIMMABLE-BOUNDARY-START(12885606721)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885606721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bd pd sd bg-card stack text-center"))));
                __builder.OpenElement(2, "h3");
                __builder.AddAttribute$5(3, "class", "mg-0");
                __builder.AddContent$4(4, this.ViewModel.Name);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "h3");
                __builder.AddAttribute$5(7, "class", "mg-0 fsz-50 cl-success");
                /*double?*/ let __ca1__;
                __builder.AddContent$4(8, ((__ca1__ = this.Value) !== null ? $.$$.S.Double.ToString$3.call($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(__ca1__), "0.##") : null));
                __builder.AddContent$4(9, this.ViewModel.Unit);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885606721)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590639425)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590639425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590639425)
            
            //--TRIMMABLE-BOUNDARY-START(8590639425)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590639425)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835279681)
                this.Station = null;
                //--TRIMMABLE-BOUNDARY-END(55835279681)
                
            }
            static $h = 704833;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835279681),
    {
      "p": 3457345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065475905,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540312385,
        "f": 83886081
      },
      "n": "Station",
      "d": 704833,
      "h": 55835279681,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835279681),
//--TRIMMABLE-BOUNDARY-START(64425214273),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655410497,
        "f": 50331650
      },
      "n": "Value",
      "d": 704833,
      "h": 64425214273,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64425214273),
//--TRIMMABLE-BOUNDARY-START(42950377793),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475541313,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 704833,
      "h": 42950377793,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950377793)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130246977),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 704833,
      "h": 60130246977,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130246977),
//--TRIMMABLE-BOUNDARY-START(12885606721),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 704833,
      "h": 12885606721,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885606721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590639425),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 704833,
      "h": 8590639425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590639425)
  ],
  "h": 704833
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.DCVoltage.DCVoltageView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}DCVoltage${separator}DCVoltageView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(704833)
        
        

        //--TRIMMABLE-BOUNDARY-START(966977)
        $asm.$cls(`$QoDz.LCIRCDD$2.DoorOpenedView`, ($self) => class DoorOpenedView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(47245607233)
            /*string */ get OptimizedComponentName()
            {
                return "dooropenedview";
            }
            //--TRIMMABLE-BOUNDARY-END(47245607233)
            
            //--TRIMMABLE-BOUNDARY-START(64425476417)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425476417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Station":
                    this.Station = $.$cast(parameter.Value, $.$QoDz.LCIRCS$1.StationView);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(64425476417)
            
            //--TRIMMABLE-BOUNDARY-START(60130509121)
            /*StationView*/ Station = null;
            //--TRIMMABLE-BOUNDARY-END(60130509121)
            
            //--TRIMMABLE-BOUNDARY-START(42950639937)
            /*bool */ get Opened()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475803457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Gateway === null)
                {
                    return false;
                }
                /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status ?? null);
                /*var*/ let openLogic = this.ViewModel.Active === 0/*IOT.Common.Models.Logic.LOW*/ ? false : true;
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayCollectedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayDigitalInputs?*/ let __ca2__;
                return (((__ca1__ = stat) !== null ? ((__ca2__ = __ca1__.DigtalInputs) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.Boolean, __ca2__.States, this.ViewModel.Terminal) : false) : false)) === openLogic;
            }
            //--TRIMMABLE-BOUNDARY-END(42950639937)
            
            //--TRIMMABLE-BOUNDARY-START(12885868865)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885868865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bd pd sd bg-card stack text-center"))));
                __builder.OpenElement(2, "h3");
                __builder.AddAttribute$5(3, "class", "mg-0");
                __builder.AddContent$4(4, this.ViewModel.Name);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "i");
                __builder.AddAttribute$5(7, "class", $.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-door-") + $.$strNN((this.Opened ? "open" : "closed"))) + " fsz-50") + " cl-") + $.$strNN((this.Opened ? "error" : "success")));
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n    ");
                __builder.OpenElement(9, "h3");
                __builder.AddAttribute$5(10, "class", $.$strNN("mg-0" + " cl-") + $.$strNN((this.Opened ? "error" : "success")));
                __builder.AddContent$4(11, this.Opened ? "OPENED" : "SECURED");
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885868865)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590901569)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590901569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590901569)
            
            //--TRIMMABLE-BOUNDARY-START(8590901569)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590901569)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130509121)
                this.Station = null;
                //--TRIMMABLE-BOUNDARY-END(60130509121)
                
            }
            static $h = 966977;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245607233),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065738049,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 966977,
      "h": 47245607233,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245607233),
//--TRIMMABLE-BOUNDARY-START(60130509121),
    {
      "p": 3457345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655672641,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835541825,
        "f": 83886081
      },
      "n": "Station",
      "d": 966977,
      "h": 60130509121,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130509121),
//--TRIMMABLE-BOUNDARY-START(42950639937),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475803457,
        "f": 50331650
      },
      "n": "Opened",
      "d": 966977,
      "h": 42950639937,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950639937)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425476417),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 966977,
      "h": 64425476417,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425476417),
//--TRIMMABLE-BOUNDARY-START(12885868865),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 966977,
      "h": 12885868865,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885868865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590901569),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 966977,
      "h": 8590901569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590901569)
  ],
  "h": 966977
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.DoorOpened.DoorOpenedView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}DoorOpened${separator}DoorOpenedView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(966977)
        
        

        //--TRIMMABLE-BOUNDARY-START(1294657)
        $asm.$cls(`$QoDz.LCIRCDR$1.RelayCoilView`, ($self) => class RelayCoilView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(98785542465)
            /*StationView*/ Station = null;
            //--TRIMMABLE-BOUNDARY-END(98785542465)
            
            //--TRIMMABLE-BOUNDARY-START(25771098433)
            /*RemoteClientConnectionProxy*/ Connection = null;
            //--TRIMMABLE-BOUNDARY-END(25771098433)
            
            //--TRIMMABLE-BOUNDARY-START(17181163841)
            /*bool */ get Active()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361033025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Gateway === null)
                {
                    return false;
                }
                /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status ?? null);
                /*var*/ let activeLogic = this.ViewModel.Active === 0/*Logic.LOW*/ ? false : true;
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayCollectedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.Gateway.Models.GatewayRelayCoils?*/ let __ca2__;
                return (((__ca1__ = stat) !== null ? ((__ca2__ = __ca1__.DigitalOutputs) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.Boolean, __ca2__.States, this.ViewModel.Terminal) : false) : false)) === activeLogic;
            }
            //--TRIMMABLE-BOUNDARY-END(17181163841)
            
            //--TRIMMABLE-BOUNDARY-START(73015738689)
            /*Task *//*async*/  ON()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015738689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ViewModel.Gateway !== null)
                    {
                        /*var*/ let client = this.Connection.get_Item$3("Gateway/" + $.$strNN(this.ViewModel.Gateway));
                        /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status?.DigitalOutputs ?? null);
                        if (stat !== null)
                        {
                            let $t1, $r1;
                            ($t1 = $.$NzWm.LCIDGP$1.GatewayProtocolCommands$$($.$NzWm.LCIDG.GatewayDevice).Write(client, `${$.$strNN(stat.DeviceId)}:${$.$strNN(this.ViewModel.Terminal)}`, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.Byte.$type, [ 1 ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73015738689)
            
            //--TRIMMABLE-BOUNDARY-START(68720771393)
            /*Task *//*async*/  OFF()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720771393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ViewModel.Gateway !== null)
                    {
                        /*var*/ let client = this.Connection.get_Item$3("Gateway/" + $.$strNN(this.ViewModel.Gateway));
                        /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status?.DigitalOutputs ?? null);
                        if (stat !== null)
                        {
                            let $t2, $r2;
                            ($t2 = $.$NzWm.LCIDGP$1.GatewayProtocolCommands$$($.$NzWm.LCIDG.GatewayDevice).Write(client, `${$.$strNN(stat.DeviceId)}:${$.$strNN(this.ViewModel.Terminal)}`, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.Byte.$type, [ 0 ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720771393)
            
            //--TRIMMABLE-BOUNDARY-START(77310705985)
            /*string */ get OptimizedComponentName()
            {
                return "relaycoilview";
            }
            //--TRIMMABLE-BOUNDARY-END(77310705985)
            
            //--TRIMMABLE-BOUNDARY-START(103080509761)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080509761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "Station":
                    this.Station = $.$cast(parameter.Value, $.$QoDz.LCIRCS$1.StationView);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(103080509761)
            
            //--TRIMMABLE-BOUNDARY-START(64425804097)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425804097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Connection = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$KuVO.LCFCC.RemoteClientConnectionProxy, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(64425804097)
            
            //--TRIMMABLE-BOUNDARY-START(21476131137)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476131137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bd pd sd bg-card stack text-center"))));
                __builder.OpenElement(2, "h3");
                __builder.AddAttribute$5(3, "class", "mg-0");
                __builder.AddContent$4(4, this.ViewModel.Name);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "flex");
                __builder.OpenElement(8, "i");
                __builder.AddAttribute$5(9, "class", $.$strNN($.$strNN($.$strNN($.$strNN("clickable" + " mdi") + " mdi-power-off") + " fsz-50") + " cl-") + $.$strNN((!this.Active ? "error" : "success")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 10, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.OFF)));
                __builder.CloseElement();
                __builder.AddMarkupContent(11, "\r\n        ");
                __builder.OpenElement(12, "i");
                __builder.AddAttribute$5(13, "class", $.$strNN($.$strNN($.$strNN($.$strNN("clickable" + " mdi") + " mdi-power-on") + " fsz-50") + " cl-") + $.$strNN((!this.Active ? "error" : "success")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 14, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ON)));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n    ");
                __builder.OpenElement(16, "h3");
                __builder.AddAttribute$5(17, "class", $.$strNN("mg-0" + " cl-") + $.$strNN((!this.Active ? "error" : "success")));
                __builder.AddContent$4(18, this.Active ? (this.ViewModel.ActiveLabel ?? "ON") : (this.ViewModel.InactiveLabel ?? "OFF"));
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21476131137)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886196545)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886196545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886196545)
            
            //--TRIMMABLE-BOUNDARY-START(12886196545)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12886196545)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98785542465)
                this.Station = null;
                //--TRIMMABLE-BOUNDARY-END(98785542465)
                
                //--TRIMMABLE-BOUNDARY-START(25771098433)
                this.Connection = null;
                //--TRIMMABLE-BOUNDARY-END(25771098433)
                
            }
            static $h = 1294657;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98785542465),
    {
      "p": 3457345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130836801,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490575169,
        "f": 83886081
      },
      "n": "Station",
      "d": 1294657,
      "h": 98785542465,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785542465),
//--TRIMMABLE-BOUNDARY-START(25771098433),
    {
      "p": 2485934,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950967617,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900640577,
        "f": 83886081
      },
      "n": "Connection",
      "d": 1294657,
      "h": 25771098433,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771098433),
//--TRIMMABLE-BOUNDARY-START(17181163841),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361033025,
        "f": 50331650
      },
      "n": "Active",
      "d": 1294657,
      "h": 17181163841,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17181163841),
//--TRIMMABLE-BOUNDARY-START(77310705985),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540902209,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1294657,
      "h": 77310705985,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310705985)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015738689),
    {
      "r": 178454529,
      "n": "ON",
      "d": 1294657,
      "h": 73015738689,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73015738689),
//--TRIMMABLE-BOUNDARY-START(68720771393),
    {
      "r": 178454529,
      "n": "OFF",
      "d": 1294657,
      "h": 68720771393,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68720771393),
//--TRIMMABLE-BOUNDARY-START(103080509761),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1294657,
      "h": 103080509761,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103080509761),
//--TRIMMABLE-BOUNDARY-START(64425804097),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1294657,
      "h": 64425804097,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425804097),
//--TRIMMABLE-BOUNDARY-START(21476131137),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1294657,
      "h": 21476131137,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476131137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886196545),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1294657,
      "h": 12886196545,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886196545)
  ],
  "h": 1294657
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.RelayCoil.RelayCoilView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}RelayCoil${separator}RelayCoilView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1294657)
        
        

        //--TRIMMABLE-BOUNDARY-START(1098049)
        $asm.$cls(`$QoDz.LCIRCDR.RegisterView`, ($self) => class RegisterView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(90195411265)
            /*StationView*/ Station = null;
            //--TRIMMABLE-BOUNDARY-END(90195411265)
            
            //--TRIMMABLE-BOUNDARY-START(21475934529)
            /*RemoteClientConnectionProxy*/ Connection = null;
            //--TRIMMABLE-BOUNDARY-END(21475934529)
            
            //--TRIMMABLE-BOUNDARY-START(68720574785)
            /*byte[]? */ get Raw()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245738305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Gateway === null || this.ViewModel.Datasource === null)
                {
                    return null;
                }
                /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status ?? null);
                return stat?.GetRaw(this.ViewModel.Datasource) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(68720574785)
            
            //--TRIMMABLE-BOUNDARY-START(64425607489)
            /*string */ get OptimizedComponentName()
            {
                return "registerview";
            }
            //--TRIMMABLE-BOUNDARY-END(64425607489)
            
            //--TRIMMABLE-BOUNDARY-START(94490378561)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490378561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Station":
                    this.Station = $.$cast(parameter.Value, $.$QoDz.LCIRCS$1.StationView);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(94490378561)
            
            //--TRIMMABLE-BOUNDARY-START(60130640193)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130640193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Connection = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$KuVO.LCFCC.RemoteClientConnectionProxy, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60130640193)
            
            //--TRIMMABLE-BOUNDARY-START(17180967233)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180967233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bd pd sd bg-card stack"))));
                __builder.OpenElement(2, "h3");
                __builder.AddAttribute$5(3, "class", "mg-0 text-center");
                __builder.AddContent$4(4, this.ViewModel.Name);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenComponent$1($.$ntej.LCICS$2.IOTDeviceStatusByteArray, 6);
                __builder.AddComponentParameter(7, "Raw", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeArray($.$$.S.Byte), this.Raw));
                __builder.AddComponentParameter(8, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICS$2.IOTDeviceStatusByteArrayFeatures, 0/*IOTDeviceStatusByteArrayFeatures.Default*/ | 1/*IOTDeviceStatusByteArrayFeatures.BigEndian*/ | 4/*IOTDeviceStatusByteArrayFeatures.ColumnBytesPerCell2*/ | 512/*IOTDeviceStatusByteArrayFeatures.FormatDataDecimal*/), $.$ntej.LCICS$2.IOTDeviceStatusByteArrayFeatures));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180967233)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885999937)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885999937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885999937)
            
            //--TRIMMABLE-BOUNDARY-START(12885999937)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12885999937)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90195411265)
                this.Station = null;
                //--TRIMMABLE-BOUNDARY-END(90195411265)
                
                //--TRIMMABLE-BOUNDARY-START(21475934529)
                this.Connection = null;
                //--TRIMMABLE-BOUNDARY-END(21475934529)
                
            }
            static $h = 1098049;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195411265),
    {
      "p": 3457345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835672897,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900443969,
        "f": 83886081
      },
      "n": "Station",
      "d": 1098049,
      "h": 90195411265,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195411265),
//--TRIMMABLE-BOUNDARY-START(21475934529),
    {
      "p": 2485934,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065869121,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310509377,
        "f": 83886081
      },
      "n": "Connection",
      "d": 1098049,
      "h": 21475934529,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475934529),
//--TRIMMABLE-BOUNDARY-START(68720574785),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245738305,
        "f": 50331650
      },
      "n": "Raw",
      "d": 1098049,
      "h": 68720574785,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68720574785),
//--TRIMMABLE-BOUNDARY-START(64425607489),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655803713,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1098049,
      "h": 64425607489,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64425607489)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94490378561),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1098049,
      "h": 94490378561,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490378561),
//--TRIMMABLE-BOUNDARY-START(60130640193),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1098049,
      "h": 60130640193,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130640193),
//--TRIMMABLE-BOUNDARY-START(17180967233),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1098049,
      "h": 17180967233,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180967233)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885999937),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1098049,
      "h": 12885999937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885999937)
  ],
  "h": 1098049
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.RegisterView.RegisterView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}RegisterView${separator}RegisterView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1098049)
        
        

        //--TRIMMABLE-BOUNDARY-START(573761)
        $asm.$cls(`$QoDz.LCIRCDC.CameraView`, ($self) => class CameraView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.CameraDevice.CameraWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(107374756161)
            /*StationView*/ Station = null;
            //--TRIMMABLE-BOUNDARY-END(107374756161)
            
            //--TRIMMABLE-BOUNDARY-START(73015017793)
            /*RMSCameraNotification*/ Notification = null;
            //--TRIMMABLE-BOUNDARY-END(73015017793)
            
            //--TRIMMABLE-BOUNDARY-START(64425083201)
            /*byte[]? */ get InferenceResults()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065344833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Gateway === null || this.ViewModel.Datasource === null)
                {
                    return null;
                }
                /*var*/ let stat = (this.Station.GetStatus(this.ViewModel.Gateway)?.Status ?? null);
                /*var*/ let value = (stat?.GetRaw(this.ViewModel.Datasource) ?? null);
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(64425083201)
            
            //--TRIMMABLE-BOUNDARY-START(81604952385)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604952385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Notification.add_OnImageReceived(new ($.$$.S.EventHandler$$($.$OgAC.LCIRC.RMSCameraImageModel))().$ctor(this, this.Notification_OnImageReceived));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(81604952385)
            
            //--TRIMMABLE-BOUNDARY-START(21475410241)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475410241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Notification.remove_OnImageReceived(new ($.$$.S.EventHandler$$($.$OgAC.LCIRC.RMSCameraImageModel))().$ctor(this, this.Notification_OnImageReceived));
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(21475410241)
            
            //--TRIMMABLE-BOUNDARY-START(60130115905)
            /*int*/ imageSequence = 0;
            //--TRIMMABLE-BOUNDARY-END(60130115905)
            
            //--TRIMMABLE-BOUNDARY-START(77309985089)
            /*void */ Notification_OnImageReceived(/*object?*/ sender, /*RMSCameraImageModel*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309985089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.imageSequence++;
                _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Client.Blazor\\CameraView.razor.cs", "Notification_OnImageReceived", 49);
            }
            //--TRIMMABLE-BOUNDARY-END(77309985089)
            
            //--TRIMMABLE-BOUNDARY-START(85899919681)
            /*string */ get OptimizedComponentName()
            {
                return "cameraview";
            }
            //--TRIMMABLE-BOUNDARY-END(85899919681)
            
            //--TRIMMABLE-BOUNDARY-START(111669723457)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669723457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Station":
                    this.Station = $.$cast(parameter.Value, $.$QoDz.LCIRCS$1.StationView);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111669723457)
            
            //--TRIMMABLE-BOUNDARY-START(68720050497)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720050497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Notification = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OgAC.LCIRC.RMSCameraNotification, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68720050497)
            
            //--TRIMMABLE-BOUNDARY-START(17180442945)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180442945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bd sd bg-card stack text-center"))));
                __builder.OpenElement(2, "img");
                __builder.AddAttribute$5(3, "src", $.$strNN("RMS/Camera/" + $.$strNN((this.ViewModel.UniqueId))) + "?s=" + ($.$box(this.imageSequence, $.$$.S.Int32)));
                __builder.AddAttribute$5(4, "class", "mawx-2 mgx-a");
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "h3");
                __builder.AddAttribute$5(7, "class", "mgt mgb");
                __builder.AddContent$4(8, this.ViewModel.Name);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180442945)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885475649)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885475649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885475649)
            
            //--TRIMMABLE-BOUNDARY-START(12885475649)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12885475649)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(107374756161)
                this.Station = null;
                //--TRIMMABLE-BOUNDARY-END(107374756161)
                
                //--TRIMMABLE-BOUNDARY-START(73015017793)
                this.Notification = null;
                //--TRIMMABLE-BOUNDARY-END(73015017793)
                
            }
            static $h = 573761;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCD.CameraDevice.CameraWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374756161),
    {
      "p": 3457345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835148609,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079788865,
        "f": 83886081
      },
      "n": "Station",
      "d": 573761,
      "h": 107374756161,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374756161),
//--TRIMMABLE-BOUNDARY-START(73015017793),
    {
      "p": 3485350,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655279425,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489854273,
        "f": 83886081
      },
      "n": "Notification",
      "d": 573761,
      "h": 73015017793,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015017793),
//--TRIMMABLE-BOUNDARY-START(64425083201),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065344833,
        "f": 50331650
      },
      "n": "InferenceResults",
      "d": 573761,
      "h": 64425083201,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64425083201),
//--TRIMMABLE-BOUNDARY-START(85899919681),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245214017,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 573761,
      "h": 85899919681,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899919681)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604952385),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 573761,
      "h": 81604952385,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81604952385),
//--TRIMMABLE-BOUNDARY-START(21475410241),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 573761,
      "h": 21475410241,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475410241),
//--TRIMMABLE-BOUNDARY-START(77309985089),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 3223206
        }
      ],
      "n": "Notification_OnImageReceived",
      "d": 573761,
      "h": 77309985089,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77309985089),
//--TRIMMABLE-BOUNDARY-START(111669723457),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 573761,
      "h": 111669723457,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669723457),
//--TRIMMABLE-BOUNDARY-START(68720050497),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 573761,
      "h": 68720050497,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720050497),
//--TRIMMABLE-BOUNDARY-START(17180442945),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 573761,
      "h": 17180442945,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180442945)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130115905),
    {
      "t": 655361,
      "n": "imageSequence",
      "d": 573761,
      "h": 60130115905,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130115905)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885475649),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 573761,
      "h": 12885475649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885475649)
  ],
  "h": 573761
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Devices.Camera.CameraView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Devices${separator}Camera${separator}CameraView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(573761)
        
        

        //--TRIMMABLE-BOUNDARY-START(3457345)
        $asm.$cls(`$QoDz.LCIRCS$1.StationView`, ($self) => class StationView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCM.RMSStationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(150327312705)
            /*string */ get OptimizedComponentName()
            {
                return "stationview";
            }
            //--TRIMMABLE-BOUNDARY-END(150327312705)
            
            //--TRIMMABLE-BOUNDARY-START(128852476225)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852476225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
                this.GatewayOptions = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$NzWm.LCIDG.GatewayOptionReader, serviceProvider);
                this.Connection = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$KuVO.LCFCC.RemoteClientConnectionProxy, serviceProvider);
                this.MessagePipe = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
                this.Devices = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$XBGm.LCIC.IIOTDeviceWidgetFactory), serviceProvider);
                this.Updater = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBGm.LCICI.IOTDeviceUpdateEventSubscriptionChannel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(128852476225)
            
            //--TRIMMABLE-BOUNDARY-START(163212214593)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(163212214593)
            
            //--TRIMMABLE-BOUNDARY-START(51543064897)
            /*GatewayOptionReader*/ GatewayOptions = null;
            //--TRIMMABLE-BOUNDARY-END(51543064897)
            
            //--TRIMMABLE-BOUNDARY-START(38658163009)
            /*RemoteClientConnectionProxy*/ Connection = null;
            //--TRIMMABLE-BOUNDARY-END(38658163009)
            
            //--TRIMMABLE-BOUNDARY-START(133147443521)
            /*IMessagePipeFactory*/ MessagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(133147443521)
            
            //--TRIMMABLE-BOUNDARY-START(42953130305)
            /*IEnumerable<IIOTDeviceWidgetFactory>*/ Devices = null;
            //--TRIMMABLE-BOUNDARY-END(42953130305)
            
            //--TRIMMABLE-BOUNDARY-START(231931691329)
            /*IOTDeviceUpdateEventSubscriptionChannel*/ Updater = null;
            //--TRIMMABLE-BOUNDARY-END(231931691329)
            
            //--TRIMMABLE-BOUNDARY-START(223341756737)
            /*RMSClientStationViewModel*/ stationViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(223341756737)
            
            //--TRIMMABLE-BOUNDARY-START(55838032193)
            /*IEnumerable<GatewayDeviceModel>*/ gateways = null;
            //--TRIMMABLE-BOUNDARY-END(55838032193)
            
            //--TRIMMABLE-BOUNDARY-START(154622280001)
            /*UIRootWidget*/ rootWidget = null;
            //--TRIMMABLE-BOUNDARY-END(154622280001)
            
            //--TRIMMABLE-BOUNDARY-START(240521625921)
            /*Type[]*/ widgets = null;
            //--TRIMMABLE-BOUNDARY-END(240521625921)
            
            //--TRIMMABLE-BOUNDARY-START(137442410817)
            /*PageBuilderMode*/ mode = 0;
            //--TRIMMABLE-BOUNDARY-END(137442410817)
            
            //--TRIMMABLE-BOUNDARY-START(146032345409)
            /*Task *//*async*/  OnNewWidget(/*Widget*/ widget)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146032345409);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let mwidget;
                    if ($.$is(widget, $.$NzWm.LCIDG.IGatewayDatasourceWidget, { set $v($v){ mwidget = $v; } }))
                    {
                        /*GatewayDeviceModel?*/ let gateway = null;
                        if ($.$sl.SL.Enumerable.Count$1($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways) < 2)
                        {
                            gateway = $.$sl.SL.Enumerable.SingleOrDefault$3($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways);
                        }
                        else 
                        {
                            let $t1, $r1;
                            gateway = ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Select($.$NzWm.LCIDGM$1.GatewayDeviceModel, "Choose gateway", "This widget needs to auto-map itself on a gateway. But you have multiple gateways in this station, please choose one", new ($.$$.S.Func$$$($.$NzWm.LCIDGM$1.GatewayDeviceModel, $.$$.S.String))().$ctor(this,  (/**/ g) =>
                            {
                                return g.Name;
                            }, $GYLTJd ??= {"r":1310721,"p":[{"n":"g","p":5961279}],"n":"","d":3457345,"h":0,"f":17825794}), $.$sl.SL.Enumerable.ToArray($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        }
                        mwidget.LCIDG$IGatewayDatasourceWidget$DataGateway = gateway;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(146032345409)
            
            //--TRIMMABLE-BOUNDARY-START(124557508929)
            /*GatewayDeviceReceivedDataModel? */ GetStatus(/*string*/ gatewayId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124557508929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let gateway = $.$sl.SL.Enumerable.FirstOrDefault$1($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways, new ($.$$.S.Func$$$($.$NzWm.LCIDGM$1.GatewayDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.UniqueId === gatewayId;
                }, $CAHptj ??= {"r":262145,"p":[{"n":"e","p":5961279}],"n":"","d":3457345,"h":0,"f":17825794}));
                return gateway?.LiveReceived ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(124557508929)
            
            //--TRIMMABLE-BOUNDARY-START(227636724033)
            /*Task *//*async*/  ToggleBuild()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227636724033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.mode === 0/*PageBuilderMode.Read*/)
                    {
                        this.mode = 1/*PageBuilderMode.EditDragDrop*/;
                    }
                    else 
                    {
                        let $t2, $r2;
                        this.mode = 0/*PageBuilderMode.Read*/;
                        ($t2 = this.Save(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(227636724033)
            
            //--TRIMMABLE-BOUNDARY-START(141737378113)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141737378113);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.stationViewModel = $.$sl.SL.Enumerable.Single($.$QoDz.LCIRCV.RMSClientStationViewModel, this.Service.SelectedServiceViewModel.Scopes, new ($.$$.S.Func$$$($.$QoDz.LCIRCV.RMSClientStationViewModel, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                    {
                        return s.Model === this.ViewModel;
                    }, $ciYKud ??= {"r":262145,"p":[{"n":"s","p":4112705}],"n":"","d":3457345,"h":0,"f":17825794}));
                    /*var*/ let devs = this.ViewModel.GetDevices($.$OgAC.LCIRCM.RMSServiceModel, this.Service.Selected.Service);
                    this.gateways = $.$sl.SL.Enumerable.ToList($.$NzWm.LCIDGM$1.GatewayDeviceModel, (this.Service.Selected.Service.Gateways ?? $.$sl.SL.Enumerable.Empty($.$NzWm.LCIDGM$1.GatewayDeviceModel)));
                    this.GatewayOptions.Gateways = this.gateways;
                    this.Updater.add_OnDataReceived(new ($.$fPer.LCFC.AsyncEventHandler$$($.$XBGm.LCICI.IOTDeviceDataUpdateEventArgs))().$ctor(this, this.Updater_OnDataReceived));
                    this.ViewModel.Settings ??= new $.$OgAC.LCIRCS$1.RMSStationSettings().$ctor$4();
                    this.ViewModel.Settings.UI ??= new $.$bMcF.LFCW.PositionedGridWidget().$ctor$6();
                    this.rootWidget = (() =>
                    {
                        //new $.$bMcF.LFCW.UIRootWidget()
                        const $t4 = $.$bMcF.LFCW.UIRootWidget;
                        const $i4 = new $t4();
                        $i4.$ctor$7();
                        $i4.Children = $.$$.SRC.RuntimeHelpers.CreateArray($.$bMcF.LFCW.Widget.$type, [ this.ViewModel.Settings.UI ], null, null);
                        return $i4;
                    })();
                    let $en5 = this.ViewModel.Settings.UI.Children.SCG$IEnumerable$$$GetEnumerator();
                    while ($en5.SC$1$IEnumerator$MoveNext())
                    {
                        let widget = $en5.SCG$IEnumerator$$$Current;
                        {
                            let mwidget;
                            if ($.$is(widget, $.$NzWm.LCIDG.IGatewayDatasourceWidget, { set $v($v){ mwidget = $v; } }))
                            {
                                if ($.$sl.SL.Enumerable.Count$1($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways) < 2)
                                {
                                    mwidget.LCIDG$IGatewayDatasourceWidget$DataGateway = $.$sl.SL.Enumerable.SingleOrDefault$3($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways);
                                }
                                else 
                                {
                                    let bw;
                                    if ($.$is(mwidget, $.$NzWm.LCIDG.BaseGatewayDatasourceWidget, { set $v($v){ bw = $v; } }))
                                    {
                                        if (bw.Gateway !== null)
                                        {
                                            mwidget.LCIDG$IGatewayDatasourceWidget$DataGateway = $.$sl.SL.Enumerable.FirstOrDefault$1($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways, new ($.$$.S.Func$$$($.$NzWm.LCIDGM$1.GatewayDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                                            {
                                                return e.UniqueId === bw.Gateway;
                                            }, $UuHmWa ??= {"r":262145,"p":[{"n":"e","p":5961279}],"n":"","d":3457345,"h":0,"f":17825794}));
                                        }
                                    }
                                }
                            }
                        }
                    }
                    this.widgets = $.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$sl.SL.Enumerable.Select$1($.$XBGm.LCIC.IIOTDeviceWidgetFactory, $.$$.S.Type, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCIC.IIOTDeviceWidgetFactory, $.$$.S.Type))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.LCIC$IIOTDeviceWidgetFactory$WidgetType;
                    }, $onfiVd ??= {"r":188547073,"p":[{"n":"d","p":25138577}],"n":"","d":3457345,"h":0,"f":17825794})));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(141737378113)
            
            //--TRIMMABLE-BOUNDARY-START(47248097601)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248097601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Updater.remove_OnDataReceived(new ($.$fPer.LCFC.AsyncEventHandler$$($.$XBGm.LCICI.IOTDeviceDataUpdateEventArgs))().$ctor(this, this.Updater_OnDataReceived));
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(47248097601)
            
            //--TRIMMABLE-BOUNDARY-START(236226658625)
            /*Task */ Updater_OnDataReceived(/*object*/ sender, /*IOTDeviceDataUpdateEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236226658625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let gateway = $.$sl.SL.Enumerable.FirstOrDefault$1($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.gateways, new ($.$$.S.Func$$$($.$NzWm.LCIDGM$1.GatewayDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/**/ g) =>
                {
                    return g.UniqueId === e.Message.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id.UniqueId;
                }, $kXpkKd ??= {"r":262145,"p":[{"n":"g","p":5961279}],"n":"","d":3457345,"h":0,"f":17825794}));
                let gwd;
                if (gateway !== null && $.$is(e.Data, $.$NzWm.LCIDGM$1.GatewayDeviceReceivedDataModel, { set $v($v){ gwd = $v; } }))
                {
                    gateway.LiveReceived = gwd;
                    _ = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Client.Blazor\\StationView.razor.cs", "Updater_OnDataReceived", 131);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(236226658625)
            
            //--TRIMMABLE-BOUNDARY-START(120262541633)
            /*T? */ Get(T, /*Widget*/ widget, /*string*/ path, /*T?*/ defaultValue, /*bool*/ throws)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262541633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(120262541633)
            
            //--TRIMMABLE-BOUNDARY-START(219046789441)
            /*void */ Set(T, /*Widget*/ widget, /*string*/ path, /*T?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219046789441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(219046789441)
            
            //--TRIMMABLE-BOUNDARY-START(158917247297)
            /*Task *//*async*/  Save()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158917247297);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.UpdateSettings($.$OgAC.LCIRCS$1.RMSStationSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, this.ViewModel.Identifier, this.ViewModel.Settings), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    let $en7 = this.gateways.SCG$IEnumerable$$$GetEnumerator();
                    while ($en7.SC$1$IEnumerator$MoveNext())
                    {
                        let gw = $en7.SCG$IEnumerator$$$Current;
                        {
                            let $t8, $r8;
                            ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$NzWm.LCIDGM$1.GatewayDeviceModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$NzWm.LCIDGM$1.GatewayDeviceModel), [ gw ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158917247297)
            
            //--TRIMMABLE-BOUNDARY-START(34363195713)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363195713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$QoDz.LCIRCS$1.TopHeader$$($.$QoDz.LCIRCS$1.StationView), 0);
                __builder.AddComponentParameter(1, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Title));
                __builder.AddAttribute$3(2, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(3, "button");
                        __builder2.AddAttribute$5(4, "class", "bg-primary corner mgy-a pd miwx-1");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ToggleBuild)));
                        __builder2.AddContent$4(6, this.mode === 0/*PageBuilderMode.Read*/ ? "Build" : "Save");
                        __builder2.CloseElement();
                    }, $USjZee ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3457345,"h":0,"f":17825794});
                }), $Uzcgie ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext).$h}],"n":"","d":3457345,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(7, "\r\n\r\n");
                $.$QoDz._LCIRCSS.TypeInference.CreateCascadingValue_0($.$QoDz.LCIRCS$1.StationView, __builder, 8, 9, this, 10, new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$yyXP.LCFCP.PageBuilder, 11);
                    __builder2.AddComponentParameter(12, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bMcF.LFCW.UIRootWidget, this.rootWidget));
                    __builder2.AddComponentParameter(13, "Mode", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.PageBuilderMode, this.mode), $.$hDPm.LCFCI.PageBuilderMode));
                    __builder2.AddComponentParameter(14, "Widgets", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeArray($.$$.S.Type), this.widgets));
                    __builder2.AddComponentParameter(15, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$yyXP.LCFCP.PageBuilderFeatures, 60/*PageBuilderFeatures.Default*/ & ~4/*PageBuilderFeatures.WidgetTopToolBar*/ & ~8/*PageBuilderFeatures.WidgetBottomToolBar*/ & ~16/*PageBuilderFeatures.WidgetLeftToolBar*/ & ~32/*PageBuilderFeatures.WidgetRightToolBar*/), $.$yyXP.LCFCP.PageBuilderFeatures));
                    __builder2.AddComponentParameter(16, "OnNewWidget", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$bMcF.LFCW.Widget), $.$mac.MAC.EventCallback.Factory.Create$10($.$bMcF.LFCW.Widget, this, new ($.$$.S.Func$$$($.$bMcF.LFCW.Widget, $.$$.STT.Task))().$ctor(this, this.OnNewWidget))));
                    __builder2.CloseComponent();
                }, $DPNKYk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3457345,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(34363195713)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(55836028656)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSource.Get<T>(LivingThing.FluentUI.Core.Widgets.Widget, string, T?, bool)
            LFCD$IWidgetDataSource$Get()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836028656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55836028656)
            
            //--TRIMMABLE-BOUNDARY-START(4296355568)
            //Generated interface implemetation for LivingThing.FluentUI.Core.DataBinding.IWidgetDataSink.Set<T>(LivingThing.FluentUI.Core.Widgets.Widget, string, T?)
            LFCD$IWidgetDataSink$Set()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296355568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Set(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296355568)
            
            //--TRIMMABLE-BOUNDARY-START(30068228417)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068228417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30068228417)
            
            //--TRIMMABLE-BOUNDARY-START(30068228417)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(30068228417)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(163212214593)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(163212214593)
                
                //--TRIMMABLE-BOUNDARY-START(51543064897)
                this.GatewayOptions = null;
                //--TRIMMABLE-BOUNDARY-END(51543064897)
                
                //--TRIMMABLE-BOUNDARY-START(38658163009)
                this.Connection = null;
                //--TRIMMABLE-BOUNDARY-END(38658163009)
                
                //--TRIMMABLE-BOUNDARY-START(133147443521)
                this.MessagePipe = null;
                //--TRIMMABLE-BOUNDARY-END(133147443521)
                
                //--TRIMMABLE-BOUNDARY-START(42953130305)
                this.Devices = null;
                //--TRIMMABLE-BOUNDARY-END(42953130305)
                
                //--TRIMMABLE-BOUNDARY-START(231931691329)
                this.Updater = null;
                //--TRIMMABLE-BOUNDARY-END(231931691329)
                
                //--TRIMMABLE-BOUNDARY-START(223341756737)
                this.stationViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(223341756737)
                
                //--TRIMMABLE-BOUNDARY-START(55838032193)
                this.gateways = null;
                //--TRIMMABLE-BOUNDARY-END(55838032193)
                
                //--TRIMMABLE-BOUNDARY-START(154622280001)
                this.rootWidget = null;
                //--TRIMMABLE-BOUNDARY-END(154622280001)
                
                //--TRIMMABLE-BOUNDARY-START(240521625921)
                this.widgets = null;
                //--TRIMMABLE-BOUNDARY-END(240521625921)
                
            }
            static $h = 3457345;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OgAC.LCIRCM.RMSStationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150327312705),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787705153,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3457345,
      "h": 150327312705,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150327312705),
//--TRIMMABLE-BOUNDARY-START(163212214593),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377639745,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206161887553,
        "f": 83886081
      },
      "n": "Service",
      "d": 3457345,
      "h": 163212214593,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163212214593),
//--TRIMMABLE-BOUNDARY-START(51543064897),
    {
      "p": 1766975,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607835969,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188982018369,
        "f": 83886081
      },
      "n": "GatewayOptions",
      "d": 3457345,
      "h": 51543064897,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543064897),
//--TRIMMABLE-BOUNDARY-START(38658163009),
    {
      "p": 2485934,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427966785,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171802149185,
        "f": 83886081
      },
      "n": "Connection",
      "d": 3457345,
      "h": 38658163009,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38658163009),
//--TRIMMABLE-BOUNDARY-START(133147443521),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197770561,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197571952961,
        "f": 83886081
      },
      "n": "MessagePipe",
      "d": 3457345,
      "h": 133147443521,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133147443521),
//--TRIMMABLE-BOUNDARY-START(42953130305),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCIC.IIOTDeviceWidgetFactory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017901377,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180392083777,
        "f": 83886081
      },
      "n": "Devices",
      "d": 3457345,
      "h": 42953130305,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42953130305),
//--TRIMMABLE-BOUNDARY-START(231931691329),
    {
      "p": 30250385,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115967574337,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214751822145,
        "f": 83886081
      },
      "n": "Updater",
      "d": 3457345,
      "h": 231931691329,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231931691329)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128852476225),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 3457345,
      "h": 128852476225,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128852476225),
//--TRIMMABLE-BOUNDARY-START(146032345409),
    {
      "r": 178454529,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        }
      ],
      "n": "OnNewWidget",
      "d": 3457345,
      "h": 146032345409,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(146032345409),
//--TRIMMABLE-BOUNDARY-START(124557508929),
    {
      "r": 6223423,
      "p": [
        {
          "n": "gatewayId",
          "p": 1310721
        }
      ],
      "n": "GetStatus",
      "d": 3457345,
      "h": 124557508929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124557508929),
//--TRIMMABLE-BOUNDARY-START(227636724033),
    {
      "r": 178454529,
      "n": "ToggleBuild",
      "d": 3457345,
      "h": 227636724033,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(227636724033),
//--TRIMMABLE-BOUNDARY-START(141737378113),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 3457345,
      "h": 141737378113,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(141737378113),
//--TRIMMABLE-BOUNDARY-START(47248097601),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 3457345,
      "h": 47248097601,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47248097601),
//--TRIMMABLE-BOUNDARY-START(236226658625),
    {
      "r": 178454529,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 29791633
        }
      ],
      "n": "Updater_OnDataReceived",
      "d": 3457345,
      "h": 236226658625,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236226658625),
//--TRIMMABLE-BOUNDARY-START(120262541633),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": (T) => T.$h,
          "f": 65
        },
        {
          "n": "throws",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "g": [
        "T"
      ],
      "n": "Get",
      "d": 3457345,
      "h": 120262541633,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(120262541633),
//--TRIMMABLE-BOUNDARY-START(219046789441),
    {
      "r": 65537,
      "p": [
        {
          "n": "widget",
          "p": 9907952
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Set",
      "d": 3457345,
      "h": 219046789441,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(219046789441),
//--TRIMMABLE-BOUNDARY-START(158917247297),
    {
      "r": 178454529,
      "n": "Save",
      "d": 3457345,
      "h": 158917247297,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(158917247297),
//--TRIMMABLE-BOUNDARY-START(34363195713),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3457345,
      "h": 34363195713,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34363195713)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(223341756737),
    {
      "t": 4112705,
      "n": "stationViewModel",
      "d": 3457345,
      "h": 223341756737,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(223341756737),
//--TRIMMABLE-BOUNDARY-START(55838032193),
    {
      "t": $.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel).$h,
      "n": "gateways",
      "d": 3457345,
      "h": 55838032193,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55838032193),
//--TRIMMABLE-BOUNDARY-START(154622280001),
    {
      "t": 9514736,
      "n": "rootWidget",
      "d": 3457345,
      "h": 154622280001,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154622280001),
//--TRIMMABLE-BOUNDARY-START(240521625921),
    {
      "t": $.$typeArray($.$$.S.Type).$h,
      "n": "widgets",
      "d": 3457345,
      "h": 240521625921,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(240521625921),
//--TRIMMABLE-BOUNDARY-START(137442410817),
    {
      "t": 66606762,
      "n": "mode",
      "d": 3457345,
      "h": 137442410817,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137442410817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30068228417),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3457345,
      "h": 30068228417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068228417)
  ],
  "h": 3457345
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$bMcF.LFCD.IWidgetDataSource, $.$bMcF.LFCD.IWidgetDataSink ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Shared.StationView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Shared${separator}StationView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3457345)
        
        

        //--TRIMMABLE-BOUNDARY-START(2605377)
        $asm.$cls(`$QoDz.LCIRCPS.Station`, ($self) => class Station extends $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$OgAC.LCIRCM.RMSStationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(47247245633)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(47247245633)
            
            //--TRIMMABLE-BOUNDARY-START(34362343745)
            /*ValueTask<RMSStationModel> *//*async*/  GetParameterAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCIRCM.RMSStationModel, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362343745);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.EnsureLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let gw = $.$sl.SL.Enumerable.SingleOrDefault$1($.$OgAC.LCIRCM.RMSStationModel, this.Service.Selected.Service.Scopes, new ($.$$.S.Func$$$($.$OgAC.LCIRCM.RMSStationModel, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                    {
                        /*object?*/ let __ca1__;
                        return ((__ca1__ = s.Identifier.Id) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null) === this.ParameterKey;
                    }, $lFBgod ??= {"r":262145,"p":[{"n":"s","p":2961062}],"n":"","d":2605377,"h":0,"f":17825794}));
                    return $.$$.N.AsyncResolver.Result($asnycContext, gw);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362343745)
            
            //--TRIMMABLE-BOUNDARY-START(42952278337)
            /*string */ get OptimizedComponentName()
            {
                return "station applicationlayoutpage applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(42952278337)
            
            //--TRIMMABLE-BOUNDARY-START(38657311041)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657311041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(38657311041)
            
            //--TRIMMABLE-BOUNDARY-START(12887507265)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887507265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Parameter !== null)
                {
                    __builder.OpenComponent$1($.$QoDz.LCIRCS$1.StationView, 0);
                    __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OgAC.LCIRCM.RMSStationModel, this.Parameter));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887507265)
            
            //--TRIMMABLE-BOUNDARY-START(8592539969)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592539969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592539969)
            
            //--TRIMMABLE-BOUNDARY-START(8592539969)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592539969)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47247245633)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(47247245633)
                
            }
            static $h = 2605377;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$OgAC.LCIRCM.RMSStationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247245633),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067376449,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837180225,
        "f": 83886081
      },
      "n": "Service",
      "d": 2605377,
      "h": 47247245633,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247245633),
//--TRIMMABLE-BOUNDARY-START(42952278337),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477441857,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2605377,
      "h": 42952278337,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42952278337)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362343745),
    {
      "r": $.$$.STT.ValueTask$$($.$OgAC.LCIRCM.RMSStationModel).$h,
      "n": "GetParameterAsync",
      "d": 2605377,
      "h": 34362343745,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(34362343745),
//--TRIMMABLE-BOUNDARY-START(38657311041),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2605377,
      "h": 38657311041,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657311041),
//--TRIMMABLE-BOUNDARY-START(12887507265),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2605377,
      "h": 12887507265,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887507265)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592539969),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2605377,
      "h": 8592539969,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592539969)
  ],
  "h": 2605377,
  "a": [
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "iRMS",
          "t": 1310721
        },
        {
          "v": 3,
          "t": 655361
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "v": "mdi mdi-office-building",
          "t": 1310721
        },
        {
          "v": 12328240,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1556801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Station/{ParameterKey}/{*catchAll}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$fPer.LCFCD.IOpenGraphDataProviderFactory, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Stations.Station`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Stations${separator}Station`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2605377)
        
        

        //--TRIMMABLE-BOUNDARY-START(2736449)
        $asm.$cls(`$QoDz.LCIRCPS.StationSettings`, ($self) => class StationSettings extends $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$OgAC.LCIRCM.RMSStationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51542344001)
            /*RMSClientAppViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(51542344001)
            
            //--TRIMMABLE-BOUNDARY-START(34362474817)
            /*ValueTask<RMSStationModel> *//*async*/  GetParameterAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCIRCM.RMSStationModel, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362474817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.EnsureLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let gw = $.$sl.SL.Enumerable.SingleOrDefault$1($.$OgAC.LCIRCM.RMSStationModel, this.Service.Selected.Service.Scopes, new ($.$$.S.Func$$$($.$OgAC.LCIRCM.RMSStationModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        /*object?*/ let __ca1__;
                        return ((__ca1__ = s.Identifier.Id) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null) === this.ParameterKey;
                    }, $PzGKdk ??= {"r":262145,"p":[{"n":"s","p":2961062}],"n":"","d":2736449,"h":0,"f":17825794}));
                    return $.$$.N.AsyncResolver.Result($asnycContext, gw);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362474817)
            
            //--TRIMMABLE-BOUNDARY-START(47247376705)
            /*Task *//*async*/  SaveSettings()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47247376705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.UpdateSettings($.$OgAC.LCIRCS$1.RMSStationSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, this.RequiredParameter.Identifier, this.RequiredParameter.Settings), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47247376705)
            
            //--TRIMMABLE-BOUNDARY-START(42952409409)
            /*string */ get OptimizedComponentName()
            {
                return "stationsettings applicationlayoutpage applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(42952409409)
            
            //--TRIMMABLE-BOUNDARY-START(38657442113)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657442113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QoDz.LCIRCV.RMSClientAppViewModel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(38657442113)
            
            //--TRIMMABLE-BOUNDARY-START(12887638337)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887638337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionName", "Header");
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$QoDz.LCIRCS$1.TopHeader$$($.$QoDz.LCIRCP.Settings), 3);
                    __builder2.AddComponentParameter(4, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN(this.RequiredParameter.Title) + " SETTINGS"));
                    __builder2.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(6, "button");
                            __builder3.AddAttribute$5(7, "class", "miwx-1 bg-primary corner pdx-5 pdy-3");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 8, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.SaveSettings)));
                            __builder3.AddContent$4(9, "SAVE");
                            __builder3.CloseElement();
                        }, $AvXKbf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2736449,"h":0,"f":17825794});
                    }), $yxIcyj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$QoDz.LCIRCS$1.TopHeaderContext).$h}],"n":"","d":2736449,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $UhBwvh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2736449,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(10, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$OgAC.LCIRCS$1.RMSStationSettings), 11);
                __builder.AddComponentParameter(12, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.FormBuilderFeatures, 0/*FormBuilderFeatures.Default*/ | 2/*FormBuilderFeatures.ServerUpdate*/), $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                __builder.AddComponentParameter(13, "sidebar-bar-class", "pd bg-card mgt corner");
                __builder.AddComponentParameter(14, "selected-title-class", "cl-primary fw-bold");
                __builder.AddComponentParameter(15, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OgAC.LCIRCS$1.RMSStationSettings, this.RequiredParameter.Settings));
                __builder.AddComponentParameter(16, "ModelChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$OgAC.LCIRCS$1.RMSStationSettings), $.$mac.MAC.EventCallback.Factory.Create$6($.$OgAC.LCIRCS$1.RMSStationSettings, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$OgAC.LCIRCS$1.RMSStationSettings, this, new ($.$$.S.Action$$($.$OgAC.LCIRCS$1.RMSStationSettings))().$ctor(this,  (/**/ __value) =>
                {
                    return this.RequiredParameter.Settings = __value;
                }, $dQpvji ??= {"r":65537,"p":[{"n":"__value","p":6041254}],"n":"","d":2736449,"h":0,"f":17825794}), this.RequiredParameter.Settings))));
                __builder.AddComponentParameter(17, "ModelExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$OgAC.LCIRCS$1.RMSStationSettings)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "RequiredParameter"), "Settings"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $dRqjMj ??= {"r":38797349,"n":"","d":2736449,"h":0,"f":17825794})).Invoke())));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12887638337)
            
            //--TRIMMABLE-BOUNDARY-START(8592671041)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592671041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592671041)
            
            //--TRIMMABLE-BOUNDARY-START(8592671041)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592671041)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51542344001)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(51542344001)
                
            }
            static $h = 2736449;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$OgAC.LCIRCM.RMSStationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542344001),
    {
      "p": 3916097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067507521,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132278593,
        "f": 83886081
      },
      "n": "Service",
      "d": 2736449,
      "h": 51542344001,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542344001),
//--TRIMMABLE-BOUNDARY-START(42952409409),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477572929,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2736449,
      "h": 42952409409,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42952409409)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362474817),
    {
      "r": $.$$.STT.ValueTask$$($.$OgAC.LCIRCM.RMSStationModel).$h,
      "n": "GetParameterAsync",
      "d": 2736449,
      "h": 34362474817,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(34362474817),
//--TRIMMABLE-BOUNDARY-START(47247376705),
    {
      "r": 178454529,
      "n": "SaveSettings",
      "d": 2736449,
      "h": 47247376705,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(47247376705),
//--TRIMMABLE-BOUNDARY-START(38657442113),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2736449,
      "h": 38657442113,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657442113),
//--TRIMMABLE-BOUNDARY-START(12887638337),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2736449,
      "h": 12887638337,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887638337)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592671041),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2736449,
      "h": 8592671041,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592671041)
  ],
  "h": 2736449,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 1556801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/RMS/Station/Settings/{ParameterKey}/{*catchAll}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$fPer.LCFCD.IOpenGraphDataProviderFactory, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Stations${separator}StationSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2736449)
        
        

        //--TRIMMABLE-BOUNDARY-START(2867521)
        $asm.$cls(`$QoDz.LCIRCPS.StationSettingsTypeDescriptor`, ($self) => class StationSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QoDz.LCIRCPS.StationSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297834817)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297834817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QoDz.LCIRCPS.StationSettingsTypeDescriptor.GenerateProperties($.$QoDz.LCIRCPS.StationSettings, this, factory);
                    }, $kFyjBb ??= {"r":65537,"n":"","d":2867521,"h":0,"f":17825794}), 0, "StationSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Client.Blazor\\Pages_Stations_StationSettings_LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettingsTypeDescriptorBuilder.g.cs", "StationSettingsTypeDescriptor", 42);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297834817)
            
            //--TRIMMABLE-BOUNDARY-START(12887769409)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887769409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QoDz.LCIRCPS.StationSettings.$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QoDz.LCIRCV.RMSClientAppViewModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Service";
                        $i1.DelaredOn = "LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QoDz.LCIRCPS.StationSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$QoDz.LCIRCV.RMSClientAppViewModel, ($.$cast(target, $.$QoDz.LCIRCPS.StationSettings)).Service);
                        }, $SNVSek ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2867521,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QoDz.LCIRCPS.StationSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Service = value.AsReference($.$QoDz.LCIRCV.RMSClientAppViewModel);
                        }, $wfUbqj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2867521,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887769409)
            
            //--TRIMMABLE-BOUNDARY-START(17182736705)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182736705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QoDz.LCIRCV.RMSClientAppViewModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$QoDz.LCIRCV.RMSClientAppViewModel)))
                    {
                        _target.Service = _Service;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182736705)
            
            //--TRIMMABLE-BOUNDARY-START(8592802113)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592802113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QoDz.LCIRCPS.StationSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QoDz.LCIRCPS.StationSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QoDz.LCIRCPS.StationSettings)))
                {
                    /*var*/ let result = $.$QoDz.LCIRCPS.StationSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QoDz.LCIRCPS.StationSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QoDz.LCIRCPS.StationSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QoDz.LCIRCPS.StationSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592802113)
            
            static $h = 2867521;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QoDz.LCIRCPS.StationSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887769409),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2867521,
      "h": 12887769409,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887769409),
//--TRIMMABLE-BOUNDARY-START(17182736705),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2736449,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2867521,
      "h": 17182736705,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182736705),
//--TRIMMABLE-BOUNDARY-START(8592802113),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2736449,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2867521,
      "h": 8592802113,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592802113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297834817),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2867521,
      "h": 4297834817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297834817)
  ],
  "h": 2867521
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QoDz.LCIRCPS.StationSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.Pages.Stations.StationSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}Pages${separator}Stations${separator}StationSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2867521)
        
        

        $asm.$typeProxy("$QoDz.LCIRCV.RMSClientAppViewModel", "$QoDz.LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientAppViewModel");
        $asm.$typeProxy("$QoDz.LCIRCV.RMSClientServiceViewModel", "$QoDz.LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientServiceViewModel");
        $asm.$typeProxy("$QoDz.LCIRCV.RMSClientDeviceViewModel", "$QoDz.LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(4112705)
        $asm.$cls(`$QoDz.LCIRCV.RMSClientStationViewModel`, ($self) => class RMSClientStationViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $self, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299080001)
            $ctor$3(/*RMSClientServiceViewModel*/ service, /*RMSStationModel*/ model, /*IEnumerable<RMSClientDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299080001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299080001)
            
            static $h = 4112705;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299080001),
    {
      "p": [
        {
          "n": "service",
          "p": 4047169
        },
        {
          "n": "model",
          "p": 2961062
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$QoDz.LCIRCV.RMSClientDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4112705,
      "h": 4299080001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299080001)
  ],
  "h": 4112705
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$OgAC.LCIRCM.RMSStationModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientStationViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}ViewModels${separator}RMSClientStationViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4112705)
        
        

        //--TRIMMABLE-BOUNDARY-START(3981633)
        $asm.$cls(`$QoDz.LCIRCV.RMSClientDeviceViewModel`, ($self) => class RMSClientDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $self, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298948929)
            $ctor$7(/*RMSClientServiceViewModel*/ service, /*RMSDeviceModel*/ model, /*IEnumerable<RMSClientStationViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298948929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298948929)
            
            static $h = 3981633;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298948929),
    {
      "p": [
        {
          "n": "service",
          "p": 4047169
        },
        {
          "n": "model",
          "p": 1584806
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$QoDz.LCIRCV.RMSClientStationViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3981633,
      "h": 4298948929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298948929)
  ],
  "h": 3981633
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}ViewModels${separator}RMSClientDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3981633)
        
        

        //--TRIMMABLE-BOUNDARY-START(4047169)
        $asm.$cls(`$QoDz.LCIRCV.RMSClientServiceViewModel`, ($self) => class RMSClientServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $self, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299014465)
            $ctor$3(/*RMSClientAppViewModel*/ app, /*RMSServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299014465);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299014465)
            
            //--TRIMMABLE-BOUNDARY-START(8593981761)
            /*RMSClientStationViewModel */ GetDeviceScopeViewModel(/*RMSStationModel*/ model, /*IEnumerable<RMSClientDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593981761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$QoDz.LCIRCV.RMSClientStationViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8593981761)
            
            //--TRIMMABLE-BOUNDARY-START(12888949057)
            /*RMSClientDeviceViewModel */ GetDeviceViewModel(/*RMSDeviceModel*/ model, /*IEnumerable<RMSClientStationViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888949057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$QoDz.LCIRCV.RMSClientDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12888949057)
            
            static $h = 4047169;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593981761),
    {
      "r": 4112705,
      "p": [
        {
          "n": "model",
          "p": 2961062
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$QoDz.LCIRCV.RMSClientDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 4047169,
      "h": 8593981761,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593981761),
//--TRIMMABLE-BOUNDARY-START(12888949057),
    {
      "r": 3981633,
      "p": [
        {
          "n": "model",
          "p": 1584806
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$QoDz.LCIRCV.RMSClientStationViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 4047169,
      "h": 12888949057,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888949057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299014465),
    {
      "p": [
        {
          "n": "app",
          "p": 3916097
        },
        {
          "n": "model",
          "p": 2698918
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4047169,
      "h": 4299014465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299014465)
  ],
  "h": 4047169
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}ViewModels${separator}RMSClientServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4047169)
        
        

        //--TRIMMABLE-BOUNDARY-START(3916097)
        $asm.$cls(`$QoDz.LCIRCV.RMSClientAppViewModel`, ($self) => class RMSClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(17183785281)
            $ctor$5(/*IOTRootViewModel*/ root, /*RMSDeviceFamily*/ family, /*IHubConnector<IRMSServiceHubClient>*/ hubConnector)
            {
                super.$ctor$5(root, family, hubConnector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183785281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let date = $.$fPer.LCFCDC.DateTimeExtension.GetDate(2/*DateRange.Today*/, true, null);
                    this.DashboardDateRange = new ($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)))().$ctor$3(date.Start, date.End);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183785281)
            
            //--TRIMMABLE-BOUNDARY-START(21478752577)
            /*ValueRange<DateTime?>*/ DashboardDateRange;
            //--TRIMMABLE-BOUNDARY-END(21478752577)
            
            //--TRIMMABLE-BOUNDARY-START(90198229313)
            /*ValueRange<DateTime?> */ get PreviousDateRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133458241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.DashboardDateRange.Minimum === null || this.DashboardDateRange.Maximum === null)
                {
                    return new ($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)))();
                }
                /*var*/ let periodDays = ($.$$.S.DateTime.op_Subtraction$1($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.DashboardDateRange.Maximum).AddSeconds(1), $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.DashboardDateRange.Minimum))).Days;
                return $.$with(this.DashboardDateRange, ($clone) =>
                {
                    $clone.Minimum = $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.DashboardDateRange.Minimum).AddDays(-periodDays);
                    $clone.Maximum = $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.DashboardDateRange.Maximum).AddDays(-periodDays);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90198229313)
            
            //--TRIMMABLE-BOUNDARY-START(25773719873)
            /*string */ get DateRangeLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953589057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hasRange = (this.DashboardDateRange.Minimum?.Date ?? null) !== (this.DashboardDateRange.Maximum?.Date ?? null);
                if (!hasRange && this.DashboardDateRange.Minimum === $.$$.S.DateTime.UtcNow.Date)
                {
                    return "Today";
                }
                else 
                {
                    /*var*/ let r = (this.DashboardDateRange.Minimum?.ToString$3("MMM dd, yyyy") ?? null);
                    if (hasRange)
                    {
                        r += " - ";
                        r += (this.DashboardDateRange.Maximum?.ToString$3("MMM dd, yyyy") ?? null);
                    }
                    return r;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773719873)
            
            //--TRIMMABLE-BOUNDARY-START(85903262017)
            /*DataFilter */ get LoadParameter()
            {
                return this.DashboardDateRange.Minimum !== null && this.DashboardDateRange.Maximum !== null ? new $.$fPer.LCFCD.DataFilter().$ctor$22(null, null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, this.DashboardDateRange.Minimum, this.DashboardDateRange.Maximum, new $.$fPer.LCFCD.Sorting(), null) : super.LoadParameter;
            }
            //--TRIMMABLE-BOUNDARY-END(85903262017)
            
            //--TRIMMABLE-BOUNDARY-START(81608294721)
            /*RMSClientServiceViewModel */ GetServiceViewModel(/*RMSServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81608294721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$QoDz.LCIRCV.RMSClientServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(81608294721)
            
            //--TRIMMABLE-BOUNDARY-START(94493196609)
            /*ReportParameterModel*/ Report = null;
            //--TRIMMABLE-BOUNDARY-END(94493196609)
            
            //--TRIMMABLE-BOUNDARY-START(98788163905)
            /*RMSStationModel?*/ SelectedStation = null;
            //--TRIMMABLE-BOUNDARY-END(98788163905)
            
            //--TRIMMABLE-BOUNDARY-START(4319843729)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase<LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel>.UpdateStatus(object, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel?, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel?)
            LCICH$IIOTDeviceHubClientBase$$$$UpdateStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319843729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateStatus(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319843729)
            
            //--TRIMMABLE-BOUNDARY-START(4319778193)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase.Ping(object)
            LCICH$IIOTDeviceHubClientBase$Ping()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319778193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Ping(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319778193)
            
            //--TRIMMABLE-BOUNDARY-START(8614745489)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase.Pong(object)
            LCICH$IIOTDeviceHubClientBase$Pong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8614745489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pong(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8614745489)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21478752577)
                this.DashboardDateRange = $.$default($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                //--TRIMMABLE-BOUNDARY-END(21478752577)
                
                //--TRIMMABLE-BOUNDARY-START(94493196609)
                this.Report = (() =>
                {
                    //new $.$fPer.LCFCR$1.ReportParameterModel()
                    const $t1 = $.$fPer.LCFCR$1.ReportParameterModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Interval = 1/*PeriodicInterval.Minutely*/;
                    $i1.Range = 2/*DateRange.Today*/;
                    return $i1;
                })();
                //--TRIMMABLE-BOUNDARY-END(94493196609)
                
            }
            static $h = 3916097;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478752577),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363654465,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107378098497,
        "f": 83886081
      },
      "n": "DashboardDateRange",
      "d": 3916097,
      "h": 21478752577,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478752577),
//--TRIMMABLE-BOUNDARY-START(90198229313),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.DateTime)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133458241,
        "f": 50331649
      },
      "n": "PreviousDateRange",
      "d": 3916097,
      "h": 90198229313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90198229313),
//--TRIMMABLE-BOUNDARY-START(25773719873),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953589057,
        "f": 50331649
      },
      "n": "DateRangeLabel",
      "d": 3916097,
      "h": 25773719873,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773719873),
//--TRIMMABLE-BOUNDARY-START(85903262017),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543523649,
        "f": 50364417
      },
      "n": "LoadParameter",
      "d": 3916097,
      "h": 85903262017,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85903262017),
//--TRIMMABLE-BOUNDARY-START(94493196609),
    {
      "p": 56068438,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68723392833,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115968033089,
        "f": 83886081
      },
      "n": "Report",
      "d": 3916097,
      "h": 94493196609,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94493196609),
//--TRIMMABLE-BOUNDARY-START(98788163905),
    {
      "p": 2961062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77313327425,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124557967681,
        "f": 83886081
      },
      "n": "SelectedStation",
      "d": 3916097,
      "h": 98788163905,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98788163905)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81608294721),
    {
      "r": 4047169,
      "p": [
        {
          "n": "model",
          "p": 2698918
        }
      ],
      "n": "GetServiceViewModel",
      "d": 3916097,
      "h": 81608294721,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81608294721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183785281),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 4009638
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$OgAC.LCIRCH.IRMSServiceHubClient).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3916097,
      "h": 17183785281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183785281)
  ],
  "h": 3916097
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$vWqU.LCFCC.IClientRootService, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}ViewModels${separator}RMSClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3916097)
        
        

        //--TRIMMABLE-BOUNDARY-START(3850561)
        $asm.$cls(`$QoDz.LCIRCV.RMSClientAppDefinition`, ($self) => class RMSClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298817857)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298817857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298817857)
            
            //--TRIMMABLE-BOUNDARY-START(4298817857)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298817857)
            
            static $h = 3850561;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$QoDz.LCIRCV.RMSClientServiceViewModel, $.$QoDz.LCIRCV.RMSClientStationViewModel, $.$QoDz.LCIRCV.RMSClientDeviceViewModel, $.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298817857),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3850561,
      "h": 4298817857,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4298817857)
  ],
  "h": 3850561
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.ViewModels.RMSClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}ViewModels${separator}RMSClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3850561)
        
        

        //--TRIMMABLE-BOUNDARY-START(1556801)
        $asm.$cls(`$QoDz.LCIRC.MainLayout`, ($self) => class MainLayout extends $.$lJUR.LCFCS.ServiceLayout$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$OgAC.LCIRCM.RMSServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(12886458689)
            /*LayoutFeatures*/ static DefaultLayoutFeatures = 12328240n;
            //--TRIMMABLE-BOUNDARY-END(12886458689)
            
            //--TRIMMABLE-BOUNDARY-START(94490837313)
            /*string */ get NavigationMenuName()
            {
                return "iRMS";
            }
            //--TRIMMABLE-BOUNDARY-END(94490837313)
            
            //--TRIMMABLE-BOUNDARY-START(115965673793)
            /*string? */ get OpenGraphTitle()
            {
                return super.OpenGraphTitle ?? "iSmart RMS";
            }
            //--TRIMMABLE-BOUNDARY-END(115965673793)
            
            //--TRIMMABLE-BOUNDARY-START(111670706497)
            /*string? */ get OpenGraphDescription()
            {
                return super.OpenGraphDescription ?? "Manage filling station operations and sales end to end with iSmart";
            }
            //--TRIMMABLE-BOUNDARY-END(111670706497)
            
            //--TRIMMABLE-BOUNDARY-START(17181425985)
            /*string? */ get Description()
            {
                return super.Description ?? "Manage filling station operations and sales end to end with iSmart";
            }
            //--TRIMMABLE-BOUNDARY-END(17181425985)
            
            //--TRIMMABLE-BOUNDARY-START(124555608385)
            /*bool */ get ShouldShowSideBar()
            {
                return (this.ViewModel.Selected?.Service?.LoginAttendants ?? null) === null;
            }
            //--TRIMMABLE-BOUNDARY-END(124555608385)
            
            //--TRIMMABLE-BOUNDARY-START(107375739201)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375739201);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.IOT.RMS.Client.css", true, false, false) ], null, null));
                    ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Theme.LCFCC$IThemeAccessor$SetTheme$1(2/*DefinedTheme.Dark*/), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375739201)
            
            //--TRIMMABLE-BOUNDARY-START(103080771905)
            /*Task *//*async*/  Onboard()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080771905);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$QoDz.LCIRCS$1.Onboard, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t4 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.PageBackgroundTheme = $.$fPer.LCFC.Theme.Transparent;
                        $i4.ViewFeatures = 5632/*ViewFeatures.Default*/ | 128/*ViewFeatures.Closable*/;
                        return $i4;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103080771905)
            
            //--TRIMMABLE-BOUNDARY-START(120260641089)
            /*string */ get OptimizedComponentName()
            {
                return "mainlayout servicelayout applicationlayout";
            }
            //--TRIMMABLE-BOUNDARY-END(120260641089)
            
            //--TRIMMABLE-BOUNDARY-START(8591491393)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591491393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                __builder.AddContent$1(0, view);
            }
            //--TRIMMABLE-BOUNDARY-END(8591491393)
            
            //--TRIMMABLE-BOUNDARY-START(90195870017)
            /*RenderFragment */ get Login()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$QoDz.LCIRCP.Login, 1);
                    __builder2.CloseComponent();
                }, $fpuNVb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1556801,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(90195870017)
            
            //--TRIMMABLE-BOUNDARY-START(98785804609)
            /*RenderFragment<RenderFragment> */ get NoSubscription()
            {
                return new ($.$mac.MAC.RenderFragment$$($.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(2, "div");
                        __builder2.AddAttribute$5(3, "class", "hv-10 stack");
                        __builder2.OpenElement(4, "div");
                        __builder2.AddAttribute$5(5, "class", "mg-a pd bg-card corner stack text-center");
                        __builder2.OpenElement(6, "img");
                        __builder2.AddAttribute$5(7, "src", this.ResolvePath("logo.png", true, false, false));
                        __builder2.AddAttribute$5(8, "class", "mgx-a d-block wx-1");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(9, "\r\n            ");
                        __builder2.OpenElement(10, "p");
                        __builder2.AddContent$4(11, "You have no active subscription to ");
                        __builder2.AddContent$1(12, this.Title);
                        __builder2.AddContent$4(13, ". ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(14, "\r\n            ");
                        __builder2.AddMarkupContent(15, "<p>If you are an attendant, ask the admin to link your account to one of their attendants to gain access!</p>\r\n            ");
                        __builder2.AddMarkupContent(16, "<div class=\"flex\"><div class=\"mgy-a bdt fill\"></div>\r\n                <span class=\"mgx\">OR</span>\r\n                <div class=\"mgy-a bdt fill\"></div></div>\r\n            ");
                        __builder2.OpenElement(17, "div");
                        __builder2.AddAttribute$5(18, "class", "flex mgt");
                        __builder2.OpenElement(19, "button");
                        __builder2.AddAttribute$5(20, "class", "bg-primary pd corner mgx-a");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 21, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Onboard)));
                        __builder2.AddContent$4(22, "Onboard Now");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $zfvDIi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1556801,"h":0,"f":17825794});
                }, $tDdmda ??= {"r":6881395,"p":[{"n":"e","p":6881395}],"n":"","d":1556801,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(98785804609)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296524097)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296524097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296524097)
            
            //--TRIMMABLE-BOUNDARY-START(4296524097)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296524097)
            
            static $h = 1556801;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ServiceLayout$$$($.$QoDz.LCIRCV.RMSClientAppViewModel, $.$OgAC.LCIRCM.RMSServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94490837313),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951229761,
        "f": 50364417
      },
      "n": "NavigationMenuName",
      "d": 1556801,
      "h": 94490837313,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94490837313),
//--TRIMMABLE-BOUNDARY-START(115965673793),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721033537,
        "f": 50364417
      },
      "n": "OpenGraphTitle",
      "d": 1556801,
      "h": 115965673793,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965673793),
//--TRIMMABLE-BOUNDARY-START(111670706497),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131098945,
        "f": 50364417
      },
      "n": "OpenGraphDescription",
      "d": 1556801,
      "h": 111670706497,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111670706497),
//--TRIMMABLE-BOUNDARY-START(17181425985),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771360577,
        "f": 50364417
      },
      "n": "Description",
      "d": 1556801,
      "h": 17181425985,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181425985),
//--TRIMMABLE-BOUNDARY-START(124555608385),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900902721,
        "f": 50364420
      },
      "n": "ShouldShowSideBar",
      "d": 1556801,
      "h": 124555608385,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(124555608385),
//--TRIMMABLE-BOUNDARY-START(120260641089),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310968129,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1556801,
      "h": 120260641089,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120260641089),
//--TRIMMABLE-BOUNDARY-START(90195870017),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361295169,
        "f": 50364420
      },
      "n": "Login",
      "d": 1556801,
      "h": 90195870017,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(90195870017),
//--TRIMMABLE-BOUNDARY-START(98785804609),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$mac.MAC.RenderFragment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541164353,
        "f": 50364420
      },
      "n": "NoSubscription",
      "d": 1556801,
      "h": 98785804609,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(98785804609)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107375739201),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1556801,
      "h": 107375739201,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(107375739201),
//--TRIMMABLE-BOUNDARY-START(103080771905),
    {
      "r": 178454529,
      "n": "Onboard",
      "d": 1556801,
      "h": 103080771905,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(103080771905),
//--TRIMMABLE-BOUNDARY-START(8591491393),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1556801,
      "h": 8591491393,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591491393)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886458689),
    {
      "t": 67786410,
      "n": "DefaultLayoutFeatures",
      "d": 1556801,
      "h": 12886458689,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886458689)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296524097),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1556801,
      "h": 4296524097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296524097)
  ],
  "h": 1556801
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCH.IPageHeaderContentProvider, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Client.MainLayout`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Client${separator}MainLayout`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1556801)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway", "NetJs.LivingThing.Core.IOT.RMS.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(49473)
