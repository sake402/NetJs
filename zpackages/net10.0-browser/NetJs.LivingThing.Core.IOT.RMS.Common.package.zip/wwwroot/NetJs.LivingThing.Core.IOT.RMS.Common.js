
//--TRIMMABLE-BOUNDARY-START(11942)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm) {
    "use strict";
    let _;
    let $MNRDaj;
    let $DPAegh;
    let $eXjOwi;
    let $yrKGcl;
    let $awlbJf;
    let $zJtYSk;
    let $QZzkec;
    let $jsuZHd;
    let $yXSlsa;
    let $pMwJng;
    let $PMNekd;
    let $LhDfee;
    let $pARwYc;
    let $KSBJCi;
    let $ufNQFe;
    let $VTOWUh;
    let $CwegRc;
    let $CkEtzc;
    let $dkCrGi;
    let $mNwknc;
    let $lpxYEi;
    let $AMgYCg;
    let $HGfsfl;
    let $QtSoUh;
    let $xBNNRa;
    let $WRqMEk;
    let $zfPtae;
    let $aqnqYd;
    let $MgdTFg;
    let $vOIXYi;
    let $wCweQd;
    let $ewdkif;
    let $lERURf;
    let $jclIOj;
    let $tDRoGc;
    let $DLGLmb;
    let $vKVhNb;
    let $zfJnDe;
    let $nKVAmh;
    let $pLndnl;
    let $QBXaZa;
    let $nJvZih;
    let $ujAaWe;
    let $SOwGMk;
    let $UAAUWh;
    let $OcPEra;
    let $EJoyne;
    let $HqIVHh;
    let $Rmgmch;
    let $fhEnua;
    let $WtXZpd;
    let $vzsprj;
    let $SGpRPc;
    let $Egrvvj;
    let $TdoTHj;
    let $RbLIJg;
    let $ZeiJSa;
    let $UQuyla;
    let $prHRbc;
    let $mKktog;
    let $ZvHXoe;
    let $BZxFJe;
    let $NTlhWf;
    let $CseThh;
    let $nHmdtc;
    let $GspcTa;
    let $fEeHag;
    let $YcQXhg;
    let $RoEtCc;
    let $jhcUyh;
    let $KCXfCg;
    let $TNxrJe;
    let $YxdOMd;
    let $cCDuFc;
    let $qPLTnl;
    let $XOKMDf;
    let $Ozjbvh;
    let $hgyxZe;
    let $RjPsTj;
    let $SYlNkg;
    let $BQPGyi;
    let $wZhSOj;
    let $dVVeai;
    let $iMBWTk;
    let $xDaqEd;
    let $Bnjtpd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.RMS.Common", 
    {
  "h": 11942,
  "f": "LivingThing.Core.IOT.RMS.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.RMS.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.RMS.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuUk1TLkNvbW1vbi5STVNEZXZpY2UiOiB7DQogICAgICAiTmFtZSI6ICJSTVMiLA0KICAgICAgIlNlcnZpY2VMaW5rIjogIlJNUy9BcHAiLA0KICAgICAgIkRlc2NyaXB0aW9uIjogIlRyYWNrIGFuZCBtb25pdG9yIGZpbGxpbmcgc3RhdGlvbiBzYWxlcywgZ2VuZXJhdGUgcmVwb3J0cyBhbmQgbW9yZS4iLA0KICAgICAgIlNob3J0RGVzY3JpcHRpb24iOiAiVHJhY2sgYW5kIG1vbml0b3IgZmlsbGluZyBzdGF0aW9uIHNhbGVzLCBnZW5lcmF0ZSByZXBvcnRzIGFuZCBtb3JlLiIsDQogICAgICAiU2VjdXJpdGllcyI6ICJBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIiwNCiAgICAgICJGbGFncyI6ICJGZWF0dXJlZCxQdWJsaXNoZWQiLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZnVlbCIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiM2ODliZmYiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vUk1TL2ltZy9STVMuanBnIiwNCiAgICAgICJTdGF0dXNlcyI6IFtdLA0KICAgICAgIlN0YXR1c05hbWVzIjogIlN0YXR1cy5Mb2NhdGlvbixEZXZpY2UuU3RhdHVzLlRvdGFsaXplciIsDQogICAgICAiQWNjZXNzb3JpZXMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiQ2F0ZWdvcmllcyI6IFsgIkF1dG9tYXRpb24iIF0sDQogICAgICAgICAgIk5hbWUiOiAiRXZlbnRDb3VudGVyIiwNCiAgICAgICAgICAiU2hvcnREZXNjcmlwdGlvbiI6ICJJbnRlZ3JhdGUgd2l0aCBpbmR1c3RyaWFsIGNvdW50ZXIgc3lzdGVtIGFuZCBwdXQgdGhlbSBvbmxpbmUiLA0KICAgICAgICAgICJCYW5uZXJJbWFnZSI6ICJ\u002BL1JlbGF5L2ltZy9iYW5uZXIuanBnIiwNCiAgICAgICAgICAiVW5pdENvc3QiOiB7DQogICAgICAgICAgICAiVmFsdWUiOiAxMDAwMCwNCiAgICAgICAgICAgICJVbml0IjogIk5haXJhIg0KICAgICAgICAgIH0NCiAgICAgICAgfQ0KICAgICAgXQ0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1191590)
        $asm.$cls(`$OgAC.LCIRC.IRMSDeviceFactory`, ($self) => class IRMSDeviceFactory
        {
            static $h = 1191590;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1191590
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.IRMSDeviceFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}IRMSDeviceFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1191590)
        
        

        //--TRIMMABLE-BOUNDARY-START(4599462)
        $asm.$cls(`$OgAC.LCIRCS.IRMSStationRemoteService`, ($self) => class IRMSStationRemoteService
        {
            static $h = 4599462;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4599462,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Services.IRMSStationRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Services${separator}IRMSStationRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4599462)
        
        

        //--TRIMMABLE-BOUNDARY-START(1060518)
        $asm.$cls(`$OgAC.LCIRCH.IRMSHubServer`, ($self) => class IRMSHubServer
        {
            static $h = 1060518;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1060518
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICH.IIOTDeviceHubServer, $.$kVHt.LCFCH.IComponentHubServer, $.$kVHt.LCFCH.IPluginHubServer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Hubs.IRMSHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Hubs${separator}IRMSHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1060518)
        
        

        //--TRIMMABLE-BOUNDARY-START(3616422)
        $asm.$cls(`$OgAC.LCIRC.RMSConstants`, ($self) => class RMSConstants
        {
            //--TRIMMABLE-BOUNDARY-START(4298583718)
            /*string*/ static DashboardIdName = null;
            //--TRIMMABLE-BOUNDARY-END(4298583718)
            
            //--TRIMMABLE-BOUNDARY-START(8593551014)
            /*string*/ static StationIdName = null;
            //--TRIMMABLE-BOUNDARY-END(8593551014)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4298583718)
                    this.DashboardIdName = "ServiceId";
                    //--TRIMMABLE-BOUNDARY-END(4298583718)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8593551014)
                    this.StationIdName = "RMS.Station";
                    //--TRIMMABLE-BOUNDARY-END(8593551014)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3616422;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298583718),
    {
      "t": 1310721,
      "n": "DashboardIdName",
      "d": 3616422,
      "h": 4298583718,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4298583718),
//--TRIMMABLE-BOUNDARY-START(8593551014),
    {
      "t": 1310721,
      "n": "StationIdName",
      "d": 3616422,
      "h": 8593551014,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593551014)
  ],
  "h": 3616422
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3616422)
        
        

        //--TRIMMABLE-BOUNDARY-START(3223206)
        $asm.$cls(`$OgAC.LCIRC.RMSCameraImageModel`, ($self) => class RMSCameraImageModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38657928870)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(38657928870)
            
            //--TRIMMABLE-BOUNDARY-START(17183092390)
            /*string?*/ Base64Data = null;
            //--TRIMMABLE-BOUNDARY-END(17183092390)
            
            //--TRIMMABLE-BOUNDARY-START(12888125094)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888125094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888125094)
            
            //--TRIMMABLE-BOUNDARY-START(12888125094)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12888125094)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38657928870)
                this.Id = "";
                //--TRIMMABLE-BOUNDARY-END(38657928870)
                
            }
            static $h = 3223206;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657928870),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362961574,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837798054,
        "f": 83886081
      },
      "n": "Id",
      "d": 3223206,
      "h": 38657928870,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657928870),
//--TRIMMABLE-BOUNDARY-START(17183092390),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773026982,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247863462,
        "f": 83886081
      },
      "n": "Base64Data",
      "d": 3223206,
      "h": 17183092390,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183092390)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888125094),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3223206,
      "h": 12888125094,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888125094)
  ],
  "h": 3223206
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSCameraImageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSCameraImageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3223206)
        
        

        //--TRIMMABLE-BOUNDARY-START(1912486)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class RMSDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296879782)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296879782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$OgAC.LCIRCM.RMSReceivedStatus).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296879782)
            
            static $h = 1912486;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296879782),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1912486,
      "h": 4296879782,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296879782)
  ],
  "h": 1912486
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1912486)
        
        

        //--TRIMMABLE-BOUNDARY-START(3485350)
        $asm.$cls(`$OgAC.LCIRC.RMSCameraNotification`, ($self) => class RMSCameraNotification extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183354534)
            /*EventHandler<RMSCameraImageModel>?*/ OnImageReceived = null;
            //--TRIMMABLE-BOUNDARY-END(17183354534)
            
            //--TRIMMABLE-BOUNDARY-START(17183354534)
            //--TRIMMABLE-BOUNDARY-START(12888387238)
            add_OnImageReceived(/*EventHandler<RMSCameraImageModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888387238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnImageReceived = $.$$.S.Delegate.Combine$2(this.OnImageReceived, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12888387238)
            
            //--TRIMMABLE-BOUNDARY-START(30068256422)
            remove_OnImageReceived(/*EventHandler<RMSCameraImageModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068256422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnImageReceived = $.$$.S.Delegate.Remove(this.OnImageReceived, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30068256422)
            
            //--TRIMMABLE-BOUNDARY-END(17183354534)
            
            //--TRIMMABLE-BOUNDARY-START(21478321830)
            /*void */ RaiseImageReceived(/*RMSCameraImageModel*/ image)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478321830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnImageReceived?.Invoke(this, image);
            }
            //--TRIMMABLE-BOUNDARY-END(21478321830)
            
            //--TRIMMABLE-BOUNDARY-START(4298452646)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298452646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298452646)
            
            //--TRIMMABLE-BOUNDARY-START(4298452646)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298452646)
            
            static $h = 3485350;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478321830),
    {
      "r": 65537,
      "p": [
        {
          "n": "image",
          "p": 3223206
        }
      ],
      "n": "RaiseImageReceived",
      "d": 3485350,
      "h": 21478321830,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478321830)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298452646),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3485350,
      "h": 4298452646,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298452646)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(17183354534),
    {
      "e": $.$$.S.EventHandler$$($.$OgAC.LCIRC.RMSCameraImageModel).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$OgAC.LCIRC.RMSCameraImageModel).$h
          }
        ],
        "n": "add_OnImageReceived",
        "d": 3485350,
        "h": 12888387238,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$OgAC.LCIRC.RMSCameraImageModel).$h
          }
        ],
        "n": "remove_OnImageReceived",
        "d": 3485350,
        "h": 30068256422,
        "f": 285212673
      },
      "n": "OnImageReceived",
      "d": 3485350,
      "h": 17183354534,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(17183354534)
  ],
  "h": 3485350
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSCameraNotification`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSCameraNotification`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3485350)
        
        

        //--TRIMMABLE-BOUNDARY-START(3288742)
        $asm.$cls(`$OgAC.LCIRC.RMSCameraImageModelCustomAttributesProvider`, ($self) => class RMSCameraImageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298256038)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298256038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298256038)
            
            static $h = 3288742;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298256038),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3288742,
      "h": 4298256038,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298256038)
  ],
  "h": 3288742
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSCameraImageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSCameraImageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3288742)
        
        

        //--TRIMMABLE-BOUNDARY-START(2174630)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceSendDataModelCustomAttributesProvider`, ($self) => class RMSDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297141926)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297141926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297141926)
            
            static $h = 2174630;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297141926),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2174630,
      "h": 4297141926,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297141926)
  ],
  "h": 2174630
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2174630)
        
        

        //--TRIMMABLE-BOUNDARY-START(1650342)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceModelCustomAttributesProvider`, ($self) => class RMSDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296617638)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296617638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296617638)
            
            static $h = 1650342;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296617638),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1650342,
      "h": 4296617638,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296617638)
  ],
  "h": 1650342
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1650342)
        
        

        //--TRIMMABLE-BOUNDARY-START(5058214)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsCustomAttributesProvider`, ($self) => class RMSDeviceGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300025510)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300025510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300025510)
            
            static $h = 5058214;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300025510),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5058214,
      "h": 4300025510,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300025510)
  ],
  "h": 5058214
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5058214)
        
        

        //--TRIMMABLE-BOUNDARY-START(2436774)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceStatusModelCustomAttributesProvider`, ($self) => class RMSDeviceStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297404070)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297404070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICM.IOTDeviceStatusModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297404070)
            
            static $h = 2436774;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297404070),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2436774,
      "h": 4297404070,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297404070)
  ],
  "h": 2436774
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2436774)
        
        

        //--TRIMMABLE-BOUNDARY-START(5582502)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceSettingsCustomAttributesProvider`, ($self) => class RMSDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300549798)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300549798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300549798)
            
            static $h = 5582502;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300549798),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5582502,
      "h": 4300549798,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300549798)
  ],
  "h": 5582502
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5582502)
        
        

        //--TRIMMABLE-BOUNDARY-START(4796070)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsCustomAttributesProvider`, ($self) => class RMSDashboardGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299763366)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299763366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299763366)
            
            static $h = 4796070;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299763366),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4796070,
      "h": 4299763366,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299763366)
  ],
  "h": 4796070
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDashboardGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4796070)
        
        

        //--TRIMMABLE-BOUNDARY-START(6631078)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSServiceStatesCustomAttributesProvider`, ($self) => class RMSServiceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301598374)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301598374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4301598374)
            
            static $h = 6631078;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301598374),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6631078,
      "h": 4301598374,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301598374)
  ],
  "h": 6631078
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSServiceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSServiceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6631078)
        
        

        //--TRIMMABLE-BOUNDARY-START(6893222)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSStationStatesCustomAttributesProvider`, ($self) => class RMSStationStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301860518)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301860518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTDeviceScopeStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4301860518)
            
            static $h = 6893222;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301860518),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6893222,
      "h": 4301860518,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301860518)
  ],
  "h": 6893222
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSStationStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSStationStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6893222)
        
        

        //--TRIMMABLE-BOUNDARY-START(6106790)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSStationSettingsCustomAttributesProvider`, ($self) => class RMSStationSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301074086)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4301074086)
            
            //--TRIMMABLE-BOUNDARY-START(8596041382)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596041382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OgAC.LCIRCS$1.RMSStationSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("UI", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((1), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OgAC.LCIRCS$1.RMSStationSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $eXjOwi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":6106790,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $yrKGcl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":6106790,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICS$2.IOTDeviceScopeSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8596041382)
            
            static $h = 6106790;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596041382),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6106790,
      "h": 8596041382,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596041382)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4301074086),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 6106790,
      "h": 4301074086,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4301074086)
  ],
  "h": 6106790
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSStationSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6106790)
        
        

        //--TRIMMABLE-BOUNDARY-START(1519270)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceCommandModelTypeDescriptorBuilder`, ($self) => class RMSDeviceCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591453862)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591453862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCM.RMSDeviceCommandModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCM.RMSDeviceCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $awlbJf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1519270,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCM.RMSDeviceCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591453862)
            
            //--TRIMMABLE-BOUNDARY-START(4296486566)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296486566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296486566)
            
            //--TRIMMABLE-BOUNDARY-START(4296486566)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296486566)
            
            static $h = 1519270;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591453862),
    {
      "r": 65537,
      "n": "Register",
      "d": 1519270,
      "h": 8591453862,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591453862)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296486566),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1519270,
      "h": 4296486566,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296486566)
  ],
  "h": 1519270
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1519270)
        
        

        //--TRIMMABLE-BOUNDARY-START(5844646)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSServiceSettingsCustomAttributesProvider`, ($self) => class RMSServiceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300811942)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300811942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300811942)
            
            static $h = 5844646;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300811942),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5844646,
      "h": 4300811942,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300811942)
  ],
  "h": 5844646
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSServiceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5844646)
        
        

        //--TRIMMABLE-BOUNDARY-START(5320358)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class RMSDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300287654)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300287654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300287654)
            
            static $h = 5320358;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300287654),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5320358,
      "h": 4300287654,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300287654)
  ],
  "h": 5320358
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5320358)
        
        

        //--TRIMMABLE-BOUNDARY-START(3419814)
        $asm.$cls(`$OgAC.LCIRC.RMSCameraImageModelTypeDescriptorBuilder`, ($self) => class RMSCameraImageModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593354406)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593354406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.RMSCameraImageModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aqnqYd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3419814,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRC.RMSCameraImageModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593354406)
            
            //--TRIMMABLE-BOUNDARY-START(4298387110)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298387110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298387110)
            
            //--TRIMMABLE-BOUNDARY-START(4298387110)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298387110)
            
            static $h = 3419814;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593354406),
    {
      "r": 65537,
      "n": "Register",
      "d": 3419814,
      "h": 8593354406,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593354406)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298387110),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3419814,
      "h": 4298387110,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298387110)
  ],
  "h": 3419814
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSCameraImageModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSCameraImageModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3419814)
        
        

        //--TRIMMABLE-BOUNDARY-START(3026598)
        $asm.$cls(`$OgAC.LCIRCM.RMSStationModelCustomAttributesProvider`, ($self) => class RMSStationModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297993894)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297993894)
            
            //--TRIMMABLE-BOUNDARY-START(8592961190)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592961190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OgAC.LCIRCM.RMSStationModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates).$type, $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates)), [(() =>
                        {
                            //new $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates)()
                            const $t3 = $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates);
                            const $i3 = new $t3();
                            $i3.$ctor$3();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates)), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OgAC.LCIRCM.RMSStationModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $mNwknc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3026598,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $lpxYEi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3026598,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592961190)
            
            static $h = 3026598;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592961190),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3026598,
      "h": 8592961190,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592961190)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297993894),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3026598,
      "h": 4297993894,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297993894)
  ],
  "h": 3026598
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSStationModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSStationModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3026598)
        
        

        //--TRIMMABLE-BOUNDARY-START(2567846)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceStatusModelTypeDescriptorBuilder`, ($self) => class RMSDeviceStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592502438)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592502438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCM.RMSDeviceStatusModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCM.RMSDeviceStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yXSlsa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2567846,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCM.RMSDeviceStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592502438)
            
            //--TRIMMABLE-BOUNDARY-START(4297535142)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297535142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297535142)
            
            //--TRIMMABLE-BOUNDARY-START(4297535142)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297535142)
            
            static $h = 2567846;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592502438),
    {
      "r": 65537,
      "n": "Register",
      "d": 2567846,
      "h": 8592502438,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592502438)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297535142),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2567846,
      "h": 4297535142,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297535142)
  ],
  "h": 2567846
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2567846)
        
        

        //--TRIMMABLE-BOUNDARY-START(4927142)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsTypeDescriptorBuilder`, ($self) => class RMSDashboardGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594861734)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594861734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QZzkec ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4927142,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594861734)
            
            //--TRIMMABLE-BOUNDARY-START(4299894438)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299894438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299894438)
            
            //--TRIMMABLE-BOUNDARY-START(4299894438)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299894438)
            
            static $h = 4927142;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594861734),
    {
      "r": 65537,
      "n": "Register",
      "d": 4927142,
      "h": 8594861734,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594861734)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299894438),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4927142,
      "h": 4299894438,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299894438)
  ],
  "h": 4927142
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDashboardGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4927142)
        
        

        //--TRIMMABLE-BOUNDARY-START(6762150)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSServiceStatesTypeDescriptorBuilder`, ($self) => class RMSServiceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596696742)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596696742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$2.RMSServiceStatesTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$2.RMSServiceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CkEtzc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6762150,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$2.RMSServiceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596696742)
            
            //--TRIMMABLE-BOUNDARY-START(4301729446)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301729446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301729446)
            
            //--TRIMMABLE-BOUNDARY-START(4301729446)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301729446)
            
            static $h = 6762150;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596696742),
    {
      "r": 65537,
      "n": "Register",
      "d": 6762150,
      "h": 8596696742,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596696742)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301729446),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6762150,
      "h": 4301729446,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301729446)
  ],
  "h": 6762150
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSServiceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSServiceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6762150)
        
        

        //--TRIMMABLE-BOUNDARY-START(7089830)
        $asm.$cls(`$OgAC.LCIRC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4302057126)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4302057126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OgAC.LCIRCM.RMSDeviceCommandModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCM.RMSDeviceModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCM.RMSDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCM.RMSDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCM.RMSDeviceStatusModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCM.RMSServiceModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCM.RMSStationModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$1.RMSDeviceSettingsTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$1.RMSServiceSettingsTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$2.RMSServiceStatesTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$2.RMSDeviceStatesTypeDescriptorBuilder.Register();
                $.$OgAC.LCIRCS$2.RMSStationStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4302057126)
            
            static $h = 7089830;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4302057126),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 7089830,
      "h": 4302057126,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4302057126)
  ],
  "h": 7089830
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7089830)
        
        

        //--TRIMMABLE-BOUNDARY-START(5713574)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceSettingsTypeDescriptorBuilder`, ($self) => class RMSDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595648166)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595648166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$1.RMSDeviceSettingsTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$1.RMSDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WRqMEk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5713574,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$1.RMSDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595648166)
            
            //--TRIMMABLE-BOUNDARY-START(4300680870)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300680870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300680870)
            
            //--TRIMMABLE-BOUNDARY-START(4300680870)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300680870)
            
            static $h = 5713574;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595648166),
    {
      "r": 65537,
      "n": "Register",
      "d": 5713574,
      "h": 8595648166,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595648166)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300680870),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5713574,
      "h": 4300680870,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300680870)
  ],
  "h": 5713574
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5713574)
        
        

        //--TRIMMABLE-BOUNDARY-START(6500006)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSDeviceStatesTypeDescriptorBuilder`, ($self) => class RMSDeviceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596434598)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596434598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$2.RMSDeviceStatesTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$2.RMSDeviceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $AMgYCg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6500006,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$2.RMSDeviceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596434598)
            
            //--TRIMMABLE-BOUNDARY-START(4301467302)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301467302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301467302)
            
            //--TRIMMABLE-BOUNDARY-START(4301467302)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301467302)
            
            static $h = 6500006;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596434598),
    {
      "r": 65537,
      "n": "Register",
      "d": 6500006,
      "h": 8596434598,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596434598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301467302),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6500006,
      "h": 4301467302,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301467302)
  ],
  "h": 6500006
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSDeviceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6500006)
        
        

        //--TRIMMABLE-BOUNDARY-START(2043558)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class RMSDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591978150)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591978150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCM.RMSDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCM.RMSDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QtSoUh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2043558,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591978150)
            
            //--TRIMMABLE-BOUNDARY-START(4297010854)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297010854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297010854)
            
            //--TRIMMABLE-BOUNDARY-START(4297010854)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297010854)
            
            static $h = 2043558;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591978150),
    {
      "r": 65537,
      "n": "Register",
      "d": 2043558,
      "h": 8591978150,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591978150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297010854),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2043558,
      "h": 4297010854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297010854)
  ],
  "h": 2043558
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2043558)
        
        

        //--TRIMMABLE-BOUNDARY-START(1388198)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceCommandModelCustomAttributesProvider`, ($self) => class RMSDeviceCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296355494)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296355494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICM.IOTDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296355494)
            
            static $h = 1388198;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296355494),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1388198,
      "h": 4296355494,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296355494)
  ],
  "h": 1388198
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1388198)
        
        

        //--TRIMMABLE-BOUNDARY-START(994982)
        $asm.$cls(`$OgAC.LCIRC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295962278)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295962278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCM.RMSDeviceCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCM.RMSDeviceCommandModelCustomAttributesProvider, $.$OgAC.LCIRCM.RMSDeviceCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCM.RMSDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCM.RMSDeviceModelCustomAttributesProvider, $.$OgAC.LCIRCM.RMSDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCM.RMSDeviceReceivedDataModelCustomAttributesProvider, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCM.RMSDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCM.RMSDeviceSendDataModelCustomAttributesProvider, $.$OgAC.LCIRCM.RMSDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCM.RMSDeviceStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCM.RMSDeviceStatusModelCustomAttributesProvider, $.$OgAC.LCIRCM.RMSDeviceStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCM.RMSServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCM.RMSServiceModelCustomAttributesProvider, $.$OgAC.LCIRCM.RMSServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCM.RMSStationModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCM.RMSStationModelCustomAttributesProvider, $.$OgAC.LCIRCM.RMSStationModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRC.RMSCameraImageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRC.RMSCameraImageModelCustomAttributesProvider, $.$OgAC.LCIRC.RMSCameraImageModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsCustomAttributesProvider, $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsCustomAttributesProvider, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsCustomAttributesProvider, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$1.RMSDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$1.RMSDeviceSettingsCustomAttributesProvider, $.$OgAC.LCIRCS$1.RMSDeviceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$1.RMSServiceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$1.RMSServiceSettingsCustomAttributesProvider, $.$OgAC.LCIRCS$1.RMSServiceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$1.RMSStationSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$1.RMSStationSettingsCustomAttributesProvider, $.$OgAC.LCIRCS$1.RMSStationSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$2.RMSServiceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$2.RMSServiceStatesCustomAttributesProvider, $.$OgAC.LCIRCS$2.RMSServiceStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$2.RMSDeviceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$2.RMSDeviceStatesCustomAttributesProvider, $.$OgAC.LCIRCS$2.RMSDeviceStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OgAC.LCIRCS$2.RMSStationStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OgAC.LCIRCS$2.RMSStationStatesCustomAttributesProvider, $.$OgAC.LCIRCS$2.RMSStationStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295962278)
            
            static $h = 994982;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295962278),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 994982,
      "h": 4295962278,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295962278)
  ],
  "h": 994982
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(994982)
        
        

        //--TRIMMABLE-BOUNDARY-START(2895526)
        $asm.$cls(`$OgAC.LCIRCM.RMSServiceModelTypeDescriptorBuilder`, ($self) => class RMSServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592830118)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592830118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TNxrJe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2895526,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCM.RMSServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592830118)
            
            //--TRIMMABLE-BOUNDARY-START(4297862822)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297862822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297862822)
            
            //--TRIMMABLE-BOUNDARY-START(4297862822)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297862822)
            
            static $h = 2895526;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592830118),
    {
      "r": 65537,
      "n": "Register",
      "d": 2895526,
      "h": 8592830118,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592830118)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297862822),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2895526,
      "h": 4297862822,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297862822)
  ],
  "h": 2895526
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2895526)
        
        

        //--TRIMMABLE-BOUNDARY-START(1257126)
        $asm.$cls(`$OgAC.LCIRC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296224422)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296224422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$OgAC.LCIRCS.IRMSStationRemoteService, $.$OgAC.LCIRCS.IRMSStationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSStationRemoteService_Mocking().$ctor$3(impl);
                }, $nJvZih ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $ujAaWe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$OgAC.LCIRCM.RMSServiceModel, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $SOwGMk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $UAAUWh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.IServiceRemoteService$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $OcPEra ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $EJoyne ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $HqIVHh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $Rmgmch ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $fhEnua ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $WtXZpd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $vzsprj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$OgAC.LCIRCS.IRMSRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCIRCS.IRMSRemoteService_Mocking().$ctor$3(impl);
                }, $SGpRPc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking().$ctor$3(impl);
                }, $Egrvvj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking().$ctor$3(impl);
                }, $TdoTHj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking().$ctor$3(impl);
                }, $RbLIJg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking().$ctor$3(impl);
                }, $ZeiJSa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking().$ctor$3(impl);
                }, $UQuyla ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking().$ctor$3(impl);
                }, $prHRbc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking().$ctor$3(impl);
                }, $mKktog ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking().$ctor$3(impl);
                }, $ZvHXoe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking().$ctor$3(impl);
                }, $BZxFJe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking().$ctor$3(impl);
                }, $NTlhWf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking().$ctor$3(impl);
                }, $CseThh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking().$ctor$3(impl);
                }, $nHmdtc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking().$ctor$3(impl);
                }, $GspcTa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking().$ctor$3(impl);
                }, $fEeHag ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1257126,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296224422)
            
            static $h = 1257126;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296224422),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 1257126,
      "h": 4296224422,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296224422)
  ],
  "h": 1257126
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1257126)
        
        

        //--TRIMMABLE-BOUNDARY-START(6237862)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptorBuilder`, ($self) => class RMSStationSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596172454)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596172454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zfJnDe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6237862,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$1.RMSStationSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596172454)
            
            //--TRIMMABLE-BOUNDARY-START(4301205158)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301205158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301205158)
            
            //--TRIMMABLE-BOUNDARY-START(4301205158)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301205158)
            
            static $h = 6237862;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596172454),
    {
      "r": 65537,
      "n": "Register",
      "d": 6237862,
      "h": 8596172454,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596172454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301205158),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6237862,
      "h": 4301205158,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301205158)
  ],
  "h": 6237862
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSStationSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6237862)
        
        

        //--TRIMMABLE-BOUNDARY-START(5975718)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSServiceSettingsTypeDescriptorBuilder`, ($self) => class RMSServiceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595910310)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595910310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$1.RMSServiceSettingsTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$1.RMSServiceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $jclIOj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5975718,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$1.RMSServiceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595910310)
            
            //--TRIMMABLE-BOUNDARY-START(4300943014)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300943014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300943014)
            
            //--TRIMMABLE-BOUNDARY-START(4300943014)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300943014)
            
            static $h = 5975718;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595910310),
    {
      "r": 65537,
      "n": "Register",
      "d": 5975718,
      "h": 8595910310,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595910310)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300943014),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5975718,
      "h": 4300943014,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300943014)
  ],
  "h": 5975718
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSServiceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5975718)
        
        

        //--TRIMMABLE-BOUNDARY-START(6368934)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSDeviceStatesCustomAttributesProvider`, ($self) => class RMSDeviceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301336230)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301336230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTDeviceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4301336230)
            
            static $h = 6368934;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301336230),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6368934,
      "h": 4301336230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301336230)
  ],
  "h": 6368934
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSDeviceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6368934)
        
        

        //--TRIMMABLE-BOUNDARY-START(5189286)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsTypeDescriptorBuilder`, ($self) => class RMSDeviceGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595123878)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595123878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DLGLmb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5189286,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595123878)
            
            //--TRIMMABLE-BOUNDARY-START(4300156582)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300156582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300156582)
            
            //--TRIMMABLE-BOUNDARY-START(4300156582)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300156582)
            
            static $h = 5189286;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595123878),
    {
      "r": 65537,
      "n": "Register",
      "d": 5189286,
      "h": 8595123878,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595123878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300156582),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5189286,
      "h": 4300156582,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300156582)
  ],
  "h": 5189286
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5189286)
        
        

        //--TRIMMABLE-BOUNDARY-START(2764454)
        $asm.$cls(`$OgAC.LCIRCM.RMSServiceModelCustomAttributesProvider`, ($self) => class RMSServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297731750)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297731750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297731750)
            
            static $h = 2764454;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297731750),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2764454,
      "h": 4297731750,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297731750)
  ],
  "h": 2764454
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2764454)
        
        

        //--TRIMMABLE-BOUNDARY-START(1781414)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceModelTypeDescriptorBuilder`, ($self) => class RMSDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591716006)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591716006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCM.RMSDeviceModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCM.RMSDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $RjPsTj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1781414,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCM.RMSDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591716006)
            
            //--TRIMMABLE-BOUNDARY-START(4296748710)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296748710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296748710)
            
            //--TRIMMABLE-BOUNDARY-START(4296748710)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296748710)
            
            static $h = 1781414;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591716006),
    {
      "r": 65537,
      "n": "Register",
      "d": 1781414,
      "h": 8591716006,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591716006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296748710),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1781414,
      "h": 4296748710,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296748710)
  ],
  "h": 1781414
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1781414)
        
        

        //--TRIMMABLE-BOUNDARY-START(5451430)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class RMSDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595386022)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595386022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YcQXhg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5451430,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595386022)
            
            //--TRIMMABLE-BOUNDARY-START(4300418726)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300418726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300418726)
            
            //--TRIMMABLE-BOUNDARY-START(4300418726)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300418726)
            
            static $h = 5451430;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595386022),
    {
      "r": 65537,
      "n": "Register",
      "d": 5451430,
      "h": 8595386022,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595386022)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300418726),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5451430,
      "h": 4300418726,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300418726)
  ],
  "h": 5451430
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5451430)
        
        

        //--TRIMMABLE-BOUNDARY-START(3157670)
        $asm.$cls(`$OgAC.LCIRCM.RMSStationModelTypeDescriptorBuilder`, ($self) => class RMSStationModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593092262)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593092262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCM.RMSStationModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCM.RMSStationModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $jhcUyh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3157670,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCM.RMSStationModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593092262)
            
            //--TRIMMABLE-BOUNDARY-START(4298124966)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298124966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298124966)
            
            //--TRIMMABLE-BOUNDARY-START(4298124966)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298124966)
            
            static $h = 3157670;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593092262),
    {
      "r": 65537,
      "n": "Register",
      "d": 3157670,
      "h": 8593092262,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593092262)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298124966),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3157670,
      "h": 4298124966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298124966)
  ],
  "h": 3157670
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSStationModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSStationModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3157670)
        
        

        //--TRIMMABLE-BOUNDARY-START(2305702)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class RMSDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592240294)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592240294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCM.RMSDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCM.RMSDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dVVeai ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2305702,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCM.RMSDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592240294)
            
            //--TRIMMABLE-BOUNDARY-START(4297272998)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297272998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297272998)
            
            //--TRIMMABLE-BOUNDARY-START(4297272998)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297272998)
            
            static $h = 2305702;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592240294),
    {
      "r": 65537,
      "n": "Register",
      "d": 2305702,
      "h": 8592240294,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592240294)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297272998),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2305702,
      "h": 4297272998,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297272998)
  ],
  "h": 2305702
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2305702)
        
        

        //--TRIMMABLE-BOUNDARY-START(7024294)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSStationStatesTypeDescriptorBuilder`, ($self) => class RMSStationStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596958886)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596958886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OgAC.LCIRCS$2.RMSStationStatesTypeDescriptor()
                        const $t1 = $.$OgAC.LCIRCS$2.RMSStationStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.RMS.Common.States.RMSStationStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xDaqEd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":7024294,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OgAC.LCIRCS$2.RMSStationStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596958886)
            
            //--TRIMMABLE-BOUNDARY-START(4301991590)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301991590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301991590)
            
            //--TRIMMABLE-BOUNDARY-START(4301991590)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301991590)
            
            static $h = 7024294;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596958886),
    {
      "r": 65537,
      "n": "Register",
      "d": 7024294,
      "h": 8596958886,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596958886)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301991590),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 7024294,
      "h": 4301991590,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301991590)
  ],
  "h": 7024294
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSStationStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSStationStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7024294)
        
        

        //--TRIMMABLE-BOUNDARY-START(4337318)
        $asm.$cls(`$OgAC.LCIRC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594271910)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594271910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$OgAC.LCIRC.RMSDataConverter, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OgAC.LCIRC.RMSDataConverter, x);
                }, $PMNekd ??= {"r":$.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":4337318,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$OgAC.LCIRC.RMSDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$OgAC.LCIRC.RMSDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$OgAC.LCIRC.RMSDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OgAC.LCIRC.RMSDeviceFamily, x);
                }, $LhDfee ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":4337318,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OgAC.LCIRC.RMSDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $pARwYc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":4337318,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OgAC.LCIRC.RMSDeviceFamily, x);
                }, $KSBJCi ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":4337318,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$OgAC.LCIRC.RMSDashboardScopeFactory, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceScopeFactory))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OgAC.LCIRC.RMSDashboardScopeFactory, x);
                }, $ufNQFe ??= {"r":28611985,"p":[{"n":"x","p":327718}],"n":"","d":4337318,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$OgAC.LCIRC.RMSProtocolDecoder, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$OgAC.LCIRC.RMSProtocolEncoder, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$OgAC.LCIRC.RMSCommands, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel), $.$OgAC.LCIRC.RMSProtocol, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$OgAC.LCIRC.RMSCameraNotification, services);
                /*void*/  function RegisterDeviceFactory(T)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$XBGm.LCIC.IIOTDeviceWidgetFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$OgAC.LCIRC.IRMSDeviceFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8(T, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$OgAC.LCIRC.IRMSDeviceFactory))().$ctor(this,  (/**/ x) =>
                    {
                        return $.$box($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(T, x), T);
                    }, $VTOWUh ??= {"r":1191590,"p":[{"n":"x","p":327718}],"n":"","d":4337318,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCIC.IIOTDeviceWidgetFactory))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$box($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(T, x), T);
                    }, $CwegRc ??= {"r":25138577,"p":[{"n":"x","p":327718}],"n":"","d":4337318,"h":0,"f":17825794}));
                }
                RegisterDeviceFactory.call(this, $.$OgAC.LCIRCD.DieselTankCoverDevice);
                RegisterDeviceFactory.call(this, $.$OgAC.LCIRCD.DoorOpenedDevice);
                RegisterDeviceFactory.call(this, $.$OgAC.LCIRCD.DCVoltageDevice);
                RegisterDeviceFactory.call(this, $.$OgAC.LCIRCD.RelayCoilDevice);
                RegisterDeviceFactory.call(this, $.$OgAC.LCIRCD.RegisterViewDevice);
                RegisterDeviceFactory.call(this, $.$OgAC.LCIRCD.CameraDevice);
                $.$OgAC.LCIRC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$OgAC.LCIRC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$OgAC.LCIRC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8594271910)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OgAC.LCIRC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4299304614)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299304614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299304614)
            
            //--TRIMMABLE-BOUNDARY-START(4299304614)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299304614)
            
            static $h = 4337318;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594271910),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 4337318,
      "h": 8594271910,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594271910)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299304614),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4337318,
      "h": 4299304614,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299304614)
  ],
  "h": 4337318
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4337318)
        
        

        //--TRIMMABLE-BOUNDARY-START(732838)
        $asm.$cls(`$OgAC.LCIRCD.RegisterViewDevice`, ($self) => class RegisterViewDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(798374)
            static $_RegisterViewWidget;
            static get RegisterViewWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$OgAC.LCIRCD.RegisterViewDevice;
                return $cls.$_RegisterViewWidget ??= $asm.$ncls(`$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget`, ($self) => class RegisterViewWidget extends $.$NzWm.LCIDG.BaseGatewayDatasourceWidget
                {
                    //--TRIMMABLE-BOUNDARY-START(4295765670)
                    $ctor$5()
                    {
                        super.$ctor$4("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\RegisterViewDevice.cs", 17);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295765670);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295765670)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590732966)
                    $ctor$6(/*string?*/ component, /*int*/ line)
                    {
                        super.$ctor$4(component, line);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590732966);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590732966)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295765670)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$5();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295765670)
                    
                    static $h = 798374;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NzWm.LCIDG.BaseGatewayDatasourceWidget; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295765670),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 798374,
      "h": 4295765670,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295765670),
//--TRIMMABLE-BOUNDARY-START(8590732966),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 798374,
      "h": 8590732966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590732966)
  ],
  "d": 732838,
  "h": 798374,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-table"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$NzWm.LCIDG.IGatewayDatasourceWidget ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.RegisterViewDevice+RegisterViewWidget`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}RegisterViewDevice${separator}RegisterViewWidget`; }
                }, $cls, ($v) => $cls.$_RegisterViewWidget = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(798374)
            
            //--TRIMMABLE-BOUNDARY-START(4295700134)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295700134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register($.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget);
            }
            //--TRIMMABLE-BOUNDARY-END(4295700134)
            
            //--TRIMMABLE-BOUNDARY-START(55835307686)
            /*string? */ get Title()
            {
                return "Register";
            }
            //--TRIMMABLE-BOUNDARY-END(55835307686)
            
            //--TRIMMABLE-BOUNDARY-START(51540340390)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-table"/*MaterialDesignIconNames.Table*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540340390)
            
            //--TRIMMABLE-BOUNDARY-START(12885634726)
            /*string? */ get Description()
            {
                return "View raw register";
            }
            //--TRIMMABLE-BOUNDARY-END(12885634726)
            
            //--TRIMMABLE-BOUNDARY-START(60130274982)
            /*Type */ get WidgetType()
            {
                return $.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60130274982)
            
            //--TRIMMABLE-BOUNDARY-START(17205007761)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.IIOTDeviceWidgetFactory.WidgetType.get
            get LCIC$IIOTDeviceWidgetFactory$WidgetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25794942353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WidgetType;
            }
            //--TRIMMABLE-BOUNDARY-END(17205007761)
            
            //--TRIMMABLE-BOUNDARY-START(8590667430)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590667430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590667430)
            
            //--TRIMMABLE-BOUNDARY-START(8590667430)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590667430)
            
            static $h = 732838;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835307686),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655438502,
        "f": 50331649
      },
      "n": "Title",
      "d": 732838,
      "h": 55835307686,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835307686),
//--TRIMMABLE-BOUNDARY-START(51540340390),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065503910,
        "f": 50331649
      },
      "n": "Icon",
      "d": 732838,
      "h": 51540340390,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540340390),
//--TRIMMABLE-BOUNDARY-START(12885634726),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475569318,
        "f": 50331649
      },
      "n": "Description",
      "d": 732838,
      "h": 12885634726,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885634726),
//--TRIMMABLE-BOUNDARY-START(60130274982),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245373094,
        "f": 50331649
      },
      "n": "WidgetType",
      "d": 732838,
      "h": 60130274982,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130274982)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590667430),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 732838,
      "h": 8590667430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590667430)
  ],
  "h": 732838
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OgAC.LCIRC.IRMSDeviceFactory, $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$OgAC.LCIRCD.RegisterViewDevice.RegisterViewWidget ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.RegisterViewDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}RegisterViewDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(732838)
        
        

        //--TRIMMABLE-BOUNDARY-START(863910)
        $asm.$cls(`$OgAC.LCIRCD.RelayCoilDevice`, ($self) => class RelayCoilDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(929446)
            static $_RelayCoilWidget;
            static get RelayCoilWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(929446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$OgAC.LCIRCD.RelayCoilDevice;
                return $cls.$_RelayCoilWidget ??= $asm.$ncls(`$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget`, ($self) => class RelayCoilWidget extends $.$bMcF.LFCW.Widget
                {
                    //--TRIMMABLE-BOUNDARY-START(25770733222)
                    $ctor$3()
                    {
                        super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\RelayCoilDevice.cs", 16);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770733222);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770733222)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065700518)
                    $ctor$4(/*string?*/ component, /*int*/ line)
                    {
                        super.$ctor$2(component, line);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065700518);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065700518)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950602406)
                    /*string?*/ Gateway = null;
                    //--TRIMMABLE-BOUNDARY-END(42950602406)
                    
                    //--TRIMMABLE-BOUNDARY-START(137439882918)
                    /*GatewayRelayCoils.RelayCoilTerminals*/ Terminal = 0;
                    //--TRIMMABLE-BOUNDARY-END(137439882918)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360667814)
                    /*Logic*/ Active = 0;
                    //--TRIMMABLE-BOUNDARY-END(34360667814)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655635110)
                    /*string?*/ ActiveLabel = null;
                    //--TRIMMABLE-BOUNDARY-END(38655635110)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195242662)
                    /*string?*/ InactiveLabel = null;
                    //--TRIMMABLE-BOUNDARY-END(90195242662)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770733222)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770733222)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(34360667814)
                        this.Active = 1;
                        //--TRIMMABLE-BOUNDARY-END(34360667814)
                        
                    }
                    static $h = 929446;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950602406),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720406182,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965046438,
        "f": 83886081
      },
      "n": "Gateway",
      "d": 929446,
      "h": 42950602406,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 1766975,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950602406),
//--TRIMMABLE-BOUNDARY-START(137439882918),
    {
      "p": 9893439,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900275366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144915622,
        "f": 83886081
      },
      "n": "Terminal",
      "d": 929446,
      "h": 137439882918,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439882918),
//--TRIMMABLE-BOUNDARY-START(34360667814),
    {
      "p": 43095441,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540536998,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785177254,
        "f": 83886081
      },
      "n": "Active",
      "d": 929446,
      "h": 34360667814,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360667814),
//--TRIMMABLE-BOUNDARY-START(38655635110),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130471590,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375111846,
        "f": 83886081
      },
      "n": "ActiveLabel",
      "d": 929446,
      "h": 38655635110,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655635110),
//--TRIMMABLE-BOUNDARY-START(90195242662),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310340774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554981030,
        "f": 83886081
      },
      "n": "InactiveLabel",
      "d": 929446,
      "h": 90195242662,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195242662)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770733222),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 929446,
      "h": 25770733222,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770733222),
//--TRIMMABLE-BOUNDARY-START(30065700518),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 929446,
      "h": 30065700518,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065700518)
  ],
  "d": 863910,
  "h": 929446,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-switch"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.RelayCoilDevice+RelayCoilWidget`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}RelayCoilDevice${separator}RelayCoilWidget`; }
                }, $cls, ($v) => $cls.$_RelayCoilWidget = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(929446)
            
            //--TRIMMABLE-BOUNDARY-START(4295831206)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295831206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register($.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget);
            }
            //--TRIMMABLE-BOUNDARY-END(4295831206)
            
            //--TRIMMABLE-BOUNDARY-START(55835438758)
            /*string? */ get Title()
            {
                return "Actuator";
            }
            //--TRIMMABLE-BOUNDARY-END(55835438758)
            
            //--TRIMMABLE-BOUNDARY-START(51540471462)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-switch"/*MaterialDesignIconNames.Switch*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540471462)
            
            //--TRIMMABLE-BOUNDARY-START(12885765798)
            /*string? */ get Description()
            {
                return "Activate a relay";
            }
            //--TRIMMABLE-BOUNDARY-END(12885765798)
            
            //--TRIMMABLE-BOUNDARY-START(60130406054)
            /*Type */ get WidgetType()
            {
                return $.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60130406054)
            
            //--TRIMMABLE-BOUNDARY-START(17205007761)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.IIOTDeviceWidgetFactory.WidgetType.get
            get LCIC$IIOTDeviceWidgetFactory$WidgetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25794942353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WidgetType;
            }
            //--TRIMMABLE-BOUNDARY-END(17205007761)
            
            //--TRIMMABLE-BOUNDARY-START(8590798502)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590798502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590798502)
            
            //--TRIMMABLE-BOUNDARY-START(8590798502)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590798502)
            
            static $h = 863910;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835438758),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655569574,
        "f": 50331649
      },
      "n": "Title",
      "d": 863910,
      "h": 55835438758,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835438758),
//--TRIMMABLE-BOUNDARY-START(51540471462),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065634982,
        "f": 50331649
      },
      "n": "Icon",
      "d": 863910,
      "h": 51540471462,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540471462),
//--TRIMMABLE-BOUNDARY-START(12885765798),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475700390,
        "f": 50331649
      },
      "n": "Description",
      "d": 863910,
      "h": 12885765798,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885765798),
//--TRIMMABLE-BOUNDARY-START(60130406054),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245504166,
        "f": 50331649
      },
      "n": "WidgetType",
      "d": 863910,
      "h": 60130406054,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130406054)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590798502),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 863910,
      "h": 8590798502,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590798502)
  ],
  "h": 863910
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OgAC.LCIRC.IRMSDeviceFactory, $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$OgAC.LCIRCD.RelayCoilDevice.RelayCoilWidget ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.RelayCoilDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}RelayCoilDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(863910)
        
        

        //--TRIMMABLE-BOUNDARY-START(208550)
        $asm.$cls(`$OgAC.LCIRCD.CameraDevice`, ($self) => class CameraDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(274086)
            static $_CameraWidget;
            static get CameraWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$OgAC.LCIRCD.CameraDevice;
                return $cls.$_CameraWidget ??= $asm.$ncls(`$OgAC.LCIRCD.CameraDevice.CameraWidget`, ($self) => class CameraWidget extends $.$NzWm.LCIDG.BaseGatewayDatasourceWidget
                {
                    //--TRIMMABLE-BOUNDARY-START(8590208678)
                    $ctor$5()
                    {
                        super.$ctor$4("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\CameraDevice.cs", 16);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590208678);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590208678)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885175974)
                    $ctor$6(/*string?*/ component, /*int*/ line)
                    {
                        super.$ctor$4(component, line);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885175974);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885175974)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360012454)
                    /*string*/ UniqueId = null;
                    //--TRIMMABLE-BOUNDARY-END(34360012454)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590208678)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$5();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590208678)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(34360012454)
                        this.UniqueId = null;
                        //--TRIMMABLE-BOUNDARY-END(34360012454)
                        
                    }
                    static $h = 274086;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NzWm.LCIDG.BaseGatewayDatasourceWidget; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360012454),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475110566,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065045158,
        "f": 83886081
      },
      "n": "UniqueId",
      "d": 274086,
      "h": 34360012454,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360012454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590208678),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 274086,
      "h": 8590208678,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590208678),
//--TRIMMABLE-BOUNDARY-START(12885175974),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 274086,
      "h": 12885175974,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885175974)
  ],
  "d": 208550,
  "h": 274086,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-camera"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$NzWm.LCIDG.IGatewayDatasourceWidget ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.CameraDevice+CameraWidget`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}CameraDevice${separator}CameraWidget`; }
                }, $cls, ($v) => $cls.$_CameraWidget = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(274086)
            
            //--TRIMMABLE-BOUNDARY-START(4295175846)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295175846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register($.$OgAC.LCIRCD.CameraDevice.CameraWidget);
            }
            //--TRIMMABLE-BOUNDARY-END(4295175846)
            
            //--TRIMMABLE-BOUNDARY-START(55834783398)
            /*string? */ get Title()
            {
                return "Camera";
            }
            //--TRIMMABLE-BOUNDARY-END(55834783398)
            
            //--TRIMMABLE-BOUNDARY-START(51539816102)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-camera"/*MaterialDesignIconNames.Camera*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51539816102)
            
            //--TRIMMABLE-BOUNDARY-START(12885110438)
            /*string? */ get Description()
            {
                return "Camera";
            }
            //--TRIMMABLE-BOUNDARY-END(12885110438)
            
            //--TRIMMABLE-BOUNDARY-START(60129750694)
            /*Type */ get WidgetType()
            {
                return $.$OgAC.LCIRCD.CameraDevice.CameraWidget.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60129750694)
            
            //--TRIMMABLE-BOUNDARY-START(17205007761)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.IIOTDeviceWidgetFactory.WidgetType.get
            get LCIC$IIOTDeviceWidgetFactory$WidgetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25794942353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WidgetType;
            }
            //--TRIMMABLE-BOUNDARY-END(17205007761)
            
            //--TRIMMABLE-BOUNDARY-START(8590143142)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590143142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590143142)
            
            //--TRIMMABLE-BOUNDARY-START(8590143142)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590143142)
            
            static $h = 208550;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834783398),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654914214,
        "f": 50331649
      },
      "n": "Title",
      "d": 208550,
      "h": 55834783398,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834783398),
//--TRIMMABLE-BOUNDARY-START(51539816102),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064979622,
        "f": 50331649
      },
      "n": "Icon",
      "d": 208550,
      "h": 51539816102,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539816102),
//--TRIMMABLE-BOUNDARY-START(12885110438),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475045030,
        "f": 50331649
      },
      "n": "Description",
      "d": 208550,
      "h": 12885110438,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885110438),
//--TRIMMABLE-BOUNDARY-START(60129750694),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244848806,
        "f": 50331649
      },
      "n": "WidgetType",
      "d": 208550,
      "h": 60129750694,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129750694)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590143142),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 208550,
      "h": 8590143142,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590143142)
  ],
  "h": 208550
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OgAC.LCIRC.IRMSDeviceFactory, $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$OgAC.LCIRCD.CameraDevice.CameraWidget ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.CameraDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}CameraDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(208550)
        
        

        //--TRIMMABLE-BOUNDARY-START(470694)
        $asm.$cls(`$OgAC.LCIRCD.DieselTankCoverDevice`, ($self) => class DieselTankCoverDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(536230)
            static $_DieselTankCoverWidget;
            static get DieselTankCoverWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$OgAC.LCIRCD.DieselTankCoverDevice;
                return $cls.$_DieselTankCoverWidget ??= $asm.$ncls(`$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget`, ($self) => class DieselTankCoverWidget extends $.$bMcF.LFCW.Widget
                {
                    //--TRIMMABLE-BOUNDARY-START(17180405414)
                    $ctor$3()
                    {
                        super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\DieselTankCoverDevice.cs", 20);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180405414);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180405414)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475372710)
                    $ctor$4(/*string?*/ component, /*int*/ line)
                    {
                        super.$ctor$2(component, line);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475372710);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475372710)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065307302)
                    /*string?*/ Gateway = null;
                    //--TRIMMABLE-BOUNDARY-END(30065307302)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899882150)
                    /*GatewayDigitalInputs.DigitalTerminals*/ Terminal = 0;
                    //--TRIMMABLE-BOUNDARY-END(85899882150)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770340006)
                    /*Logic*/ Active = 0;
                    //--TRIMMABLE-BOUNDARY-END(25770340006)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180405414)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180405414)
                    
                    static $h = 536230;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065307302),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245176486,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014980262,
        "f": 83886081
      },
      "n": "Gateway",
      "d": 536230,
      "h": 30065307302,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 1766975,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065307302),
//--TRIMMABLE-BOUNDARY-START(85899882150),
    {
      "p": 7337535,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835111078,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604914854,
        "f": 83886081
      },
      "n": "Terminal",
      "d": 536230,
      "h": 85899882150,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899882150),
//--TRIMMABLE-BOUNDARY-START(25770340006),
    {
      "p": 43095441,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655241894,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425045670,
        "f": 83886081
      },
      "n": "Active",
      "d": 536230,
      "h": 25770340006,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770340006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180405414),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 536230,
      "h": 17180405414,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180405414),
//--TRIMMABLE-BOUNDARY-START(21475372710),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 536230,
      "h": 21475372710,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475372710)
  ],
  "d": 470694,
  "h": 536230,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-bus-stop-covered"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.DieselTankCoverDevice+DieselTankCoverWidget`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}DieselTankCoverDevice${separator}DieselTankCoverWidget`; }
                }, $cls, ($v) => $cls.$_DieselTankCoverWidget = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(536230)
            
            //--TRIMMABLE-BOUNDARY-START(4295437990)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295437990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register($.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget);
            }
            //--TRIMMABLE-BOUNDARY-END(4295437990)
            
            //--TRIMMABLE-BOUNDARY-START(55835045542)
            /*string? */ get Title()
            {
                return "Diesel Tank Cap Sensor";
            }
            //--TRIMMABLE-BOUNDARY-END(55835045542)
            
            //--TRIMMABLE-BOUNDARY-START(51540078246)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-bus-stop-covered"/*MaterialDesignIconNames.BusStopCovered*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540078246)
            
            //--TRIMMABLE-BOUNDARY-START(12885372582)
            /*string? */ get Description()
            {
                return "Diesel Tank opening cover detection";
            }
            //--TRIMMABLE-BOUNDARY-END(12885372582)
            
            //--TRIMMABLE-BOUNDARY-START(60130012838)
            /*Type */ get WidgetType()
            {
                return $.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60130012838)
            
            //--TRIMMABLE-BOUNDARY-START(17205007761)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.IIOTDeviceWidgetFactory.WidgetType.get
            get LCIC$IIOTDeviceWidgetFactory$WidgetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25794942353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WidgetType;
            }
            //--TRIMMABLE-BOUNDARY-END(17205007761)
            
            //--TRIMMABLE-BOUNDARY-START(8590405286)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590405286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590405286)
            
            //--TRIMMABLE-BOUNDARY-START(8590405286)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590405286)
            
            static $h = 470694;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835045542),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655176358,
        "f": 50331649
      },
      "n": "Title",
      "d": 470694,
      "h": 55835045542,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835045542),
//--TRIMMABLE-BOUNDARY-START(51540078246),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065241766,
        "f": 50331649
      },
      "n": "Icon",
      "d": 470694,
      "h": 51540078246,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540078246),
//--TRIMMABLE-BOUNDARY-START(12885372582),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475307174,
        "f": 50331649
      },
      "n": "Description",
      "d": 470694,
      "h": 12885372582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885372582),
//--TRIMMABLE-BOUNDARY-START(60130012838),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245110950,
        "f": 50331649
      },
      "n": "WidgetType",
      "d": 470694,
      "h": 60130012838,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130012838)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590405286),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 470694,
      "h": 8590405286,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590405286)
  ],
  "h": 470694
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OgAC.LCIRC.IRMSDeviceFactory, $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$OgAC.LCIRCD.DieselTankCoverDevice.DieselTankCoverWidget ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.DieselTankCoverDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}DieselTankCoverDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(470694)
        
        

        //--TRIMMABLE-BOUNDARY-START(339622)
        $asm.$cls(`$OgAC.LCIRCD.DCVoltageDevice`, ($self) => class DCVoltageDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(405158)
            static $_DCVoltageWidget;
            static get DCVoltageWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(405158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$OgAC.LCIRCD.DCVoltageDevice;
                return $cls.$_DCVoltageWidget ??= $asm.$ncls(`$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget`, ($self) => class DCVoltageWidget extends $.$bMcF.LFCW.Widget
                {
                    //--TRIMMABLE-BOUNDARY-START(25770208934)
                    $ctor$3()
                    {
                        super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\DCVoltageDevice.cs", 15);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770208934);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770208934)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065176230)
                    $ctor$4(/*string?*/ component, /*int*/ line)
                    {
                        super.$ctor$2(component, line);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065176230);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065176230)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360143526)
                    /*string?*/ Gateway = null;
                    //--TRIMMABLE-BOUNDARY-END(34360143526)
                    
                    //--TRIMMABLE-BOUNDARY-START(133144391334)
                    /*GatewayAnalogInputs.AnalogTerminals*/ Terminal = 0;
                    //--TRIMMABLE-BOUNDARY-END(133144391334)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604783782)
                    /*double*/ Offset = 0;
                    //--TRIMMABLE-BOUNDARY-END(81604783782)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899751078)
                    /*double*/ Scale = 0;
                    //--TRIMMABLE-BOUNDARY-END(85899751078)
                    
                    //--TRIMMABLE-BOUNDARY-START(137439358630)
                    /*string?*/ Unit = null;
                    //--TRIMMABLE-BOUNDARY-END(137439358630)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770208934)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770208934)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(85899751078)
                        this.Scale = 1;
                        //--TRIMMABLE-BOUNDARY-END(85899751078)
                        
                    }
                    static $h = 405158;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360143526),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950078118,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489685670,
        "f": 83886081
      },
      "n": "Gateway",
      "d": 405158,
      "h": 34360143526,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 1766975,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360143526),
//--TRIMMABLE-BOUNDARY-START(133144391334),
    {
      "p": 3405375,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719881894,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259489446,
        "f": 83886081
      },
      "n": "Terminal",
      "d": 405158,
      "h": 133144391334,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144391334),
//--TRIMMABLE-BOUNDARY-START(81604783782),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540012710,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079620262,
        "f": 83886081
      },
      "n": "Offset",
      "d": 405158,
      "h": 81604783782,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604783782),
//--TRIMMABLE-BOUNDARY-START(85899751078),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129947302,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669554854,
        "f": 83886081
      },
      "n": "Scale",
      "d": 405158,
      "h": 85899751078,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899751078),
//--TRIMMABLE-BOUNDARY-START(137439358630),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309816486,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849424038,
        "f": 83886081
      },
      "n": "Unit",
      "d": 405158,
      "h": 137439358630,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439358630)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770208934),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 405158,
      "h": 25770208934,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770208934),
//--TRIMMABLE-BOUNDARY-START(30065176230),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 405158,
      "h": 30065176230,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065176230)
  ],
  "d": 339622,
  "h": 405158,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-flash"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.DCVoltageDevice+DCVoltageWidget`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}DCVoltageDevice${separator}DCVoltageWidget`; }
                }, $cls, ($v) => $cls.$_DCVoltageWidget = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(405158)
            
            //--TRIMMABLE-BOUNDARY-START(4295306918)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295306918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register($.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget);
            }
            //--TRIMMABLE-BOUNDARY-END(4295306918)
            
            //--TRIMMABLE-BOUNDARY-START(55834914470)
            /*string? */ get Title()
            {
                return "DC Voltage";
            }
            //--TRIMMABLE-BOUNDARY-END(55834914470)
            
            //--TRIMMABLE-BOUNDARY-START(51539947174)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-flash"/*MaterialDesignIconNames.Flash*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51539947174)
            
            //--TRIMMABLE-BOUNDARY-START(12885241510)
            /*string? */ get Description()
            {
                return "DC Voltage measurement";
            }
            //--TRIMMABLE-BOUNDARY-END(12885241510)
            
            //--TRIMMABLE-BOUNDARY-START(60129881766)
            /*Type */ get WidgetType()
            {
                return $.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60129881766)
            
            //--TRIMMABLE-BOUNDARY-START(17205007761)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.IIOTDeviceWidgetFactory.WidgetType.get
            get LCIC$IIOTDeviceWidgetFactory$WidgetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25794942353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WidgetType;
            }
            //--TRIMMABLE-BOUNDARY-END(17205007761)
            
            //--TRIMMABLE-BOUNDARY-START(8590274214)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590274214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590274214)
            
            //--TRIMMABLE-BOUNDARY-START(8590274214)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590274214)
            
            static $h = 339622;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834914470),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655045286,
        "f": 50331649
      },
      "n": "Title",
      "d": 339622,
      "h": 55834914470,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834914470),
//--TRIMMABLE-BOUNDARY-START(51539947174),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065110694,
        "f": 50331649
      },
      "n": "Icon",
      "d": 339622,
      "h": 51539947174,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539947174),
//--TRIMMABLE-BOUNDARY-START(12885241510),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475176102,
        "f": 50331649
      },
      "n": "Description",
      "d": 339622,
      "h": 12885241510,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885241510),
//--TRIMMABLE-BOUNDARY-START(60129881766),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244979878,
        "f": 50331649
      },
      "n": "WidgetType",
      "d": 339622,
      "h": 60129881766,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129881766)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590274214),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 339622,
      "h": 8590274214,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590274214)
  ],
  "h": 339622
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OgAC.LCIRC.IRMSDeviceFactory, $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$OgAC.LCIRCD.DCVoltageDevice.DCVoltageWidget ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.DCVoltageDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}DCVoltageDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(339622)
        
        

        //--TRIMMABLE-BOUNDARY-START(601766)
        $asm.$cls(`$OgAC.LCIRCD.DoorOpenedDevice`, ($self) => class DoorOpenedDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(667302)
            static $_DoorOpenedWidget;
            static get DoorOpenedWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(667302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$OgAC.LCIRCD.DoorOpenedDevice;
                return $cls.$_DoorOpenedWidget ??= $asm.$ncls(`$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget`, ($self) => class DoorOpenedWidget extends $.$bMcF.LFCW.Widget
                {
                    //--TRIMMABLE-BOUNDARY-START(17180536486)
                    $ctor$3()
                    {
                        super.$ctor$2("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\DoorOpenedDevice.cs", 16);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180536486);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180536486)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475503782)
                    $ctor$4(/*string?*/ component, /*int*/ line)
                    {
                        super.$ctor$2(component, line);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475503782);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475503782)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065438374)
                    /*string?*/ Gateway = null;
                    //--TRIMMABLE-BOUNDARY-END(30065438374)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900013222)
                    /*GatewayDigitalInputs.DigitalTerminals*/ Terminal = 0;
                    //--TRIMMABLE-BOUNDARY-END(85900013222)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770471078)
                    /*Logic*/ Active = 0;
                    //--TRIMMABLE-BOUNDARY-END(25770471078)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180536486)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180536486)
                    
                    static $h = 667302;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$bMcF.LFCW.Widget; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065438374),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245307558,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015111334,
        "f": 83886081
      },
      "n": "Gateway",
      "d": 667302,
      "h": 30065438374,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 1766975,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065438374),
//--TRIMMABLE-BOUNDARY-START(85900013222),
    {
      "p": 7337535,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835242150,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605045926,
        "f": 83886081
      },
      "n": "Terminal",
      "d": 667302,
      "h": 85900013222,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900013222),
//--TRIMMABLE-BOUNDARY-START(25770471078),
    {
      "p": 43095441,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655372966,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425176742,
        "f": 83886081
      },
      "n": "Active",
      "d": 667302,
      "h": 25770471078,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770471078)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180536486),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 667302,
      "h": 17180536486,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180536486),
//--TRIMMABLE-BOUNDARY-START(21475503782),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 667302,
      "h": 21475503782,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475503782)
  ],
  "d": 601766,
  "h": 667302,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-door"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.DoorOpenedDevice+DoorOpenedWidget`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}DoorOpenedDevice${separator}DoorOpenedWidget`; }
                }, $cls, ($v) => $cls.$_DoorOpenedWidget = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(667302)
            
            //--TRIMMABLE-BOUNDARY-START(4295569062)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295569062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register($.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget);
            }
            //--TRIMMABLE-BOUNDARY-END(4295569062)
            
            //--TRIMMABLE-BOUNDARY-START(55835176614)
            /*string? */ get Title()
            {
                return "Door Open Sensor";
            }
            //--TRIMMABLE-BOUNDARY-END(55835176614)
            
            //--TRIMMABLE-BOUNDARY-START(51540209318)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-door"/*MaterialDesignIconNames.Door*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540209318)
            
            //--TRIMMABLE-BOUNDARY-START(12885503654)
            /*string? */ get Description()
            {
                return "Door opening detection";
            }
            //--TRIMMABLE-BOUNDARY-END(12885503654)
            
            //--TRIMMABLE-BOUNDARY-START(60130143910)
            /*Type */ get WidgetType()
            {
                return $.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60130143910)
            
            //--TRIMMABLE-BOUNDARY-START(17205007761)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.IIOTDeviceWidgetFactory.WidgetType.get
            get LCIC$IIOTDeviceWidgetFactory$WidgetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25794942353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WidgetType;
            }
            //--TRIMMABLE-BOUNDARY-END(17205007761)
            
            //--TRIMMABLE-BOUNDARY-START(8590536358)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590536358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590536358)
            
            //--TRIMMABLE-BOUNDARY-START(8590536358)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590536358)
            
            static $h = 601766;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835176614),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655307430,
        "f": 50331649
      },
      "n": "Title",
      "d": 601766,
      "h": 55835176614,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835176614),
//--TRIMMABLE-BOUNDARY-START(51540209318),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065372838,
        "f": 50331649
      },
      "n": "Icon",
      "d": 601766,
      "h": 51540209318,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540209318),
//--TRIMMABLE-BOUNDARY-START(12885503654),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475438246,
        "f": 50331649
      },
      "n": "Description",
      "d": 601766,
      "h": 12885503654,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885503654),
//--TRIMMABLE-BOUNDARY-START(60130143910),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245242022,
        "f": 50331649
      },
      "n": "WidgetType",
      "d": 601766,
      "h": 60130143910,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130143910)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590536358),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 601766,
      "h": 8590536358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590536358)
  ],
  "h": 601766
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OgAC.LCIRC.IRMSDeviceFactory, $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$OgAC.LCIRCD.DoorOpenedDevice.DoorOpenedWidget ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Devices.DoorOpenedDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Devices${separator}DoorOpenedDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(601766)
        
        

        //--TRIMMABLE-BOUNDARY-START(2633382)
        $asm.$cls(`$OgAC.LCIRCM.RMSReceivedStatus`, ($self) => class RMSReceivedStatus extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297600678)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297600678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297600678)
            
            //--TRIMMABLE-BOUNDARY-START(4297600678)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297600678)
            
            static $h = 2633382;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297600678),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2633382,
      "h": 4297600678,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297600678)
  ],
  "h": 2633382
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSReceivedStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSReceivedStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2633382)
        
        

        //--TRIMMABLE-BOUNDARY-START(4664998)
        $asm.$cls(`$OgAC.LCIRCS.IRMSStationRemoteService_Mocking`, ($self) => class IRMSStationRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4299632294)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299632294);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299632294)
            
            static $h = 4664998;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299632294),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4664998,
      "h": 4299632294,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4299632294)
  ],
  "h": 4664998
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OgAC.LCIRCS.IRMSStationRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Services.IRMSStationRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Services${separator}IRMSStationRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4664998)
        
        

        //--TRIMMABLE-BOUNDARY-START(2109094)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceSendDataModel`, ($self) => class RMSDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297076390)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297076390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297076390)
            
            //--TRIMMABLE-BOUNDARY-START(4297076390)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297076390)
            
            static $h = 2109094;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297076390),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2109094,
      "h": 4297076390,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297076390)
  ],
  "h": 2109094
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2109094)
        
        

        //--TRIMMABLE-BOUNDARY-START(3354278)
        $asm.$cls(`$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor`, ($self) => class RMSCameraImageModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRC.RMSCameraImageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298321574)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298321574);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRC.RMSCameraImageModel, this, factory);
                    }, $MgdTFg ??= {"r":65537,"n":"","d":3354278,"h":0,"f":17825794}), 0, "RMSCameraImageModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\RMSCameraNotification_LivingThing.Core.IOT.RMS.Common.RMSCameraImageModelTypeDescriptorBuilder.g.cs", "RMSCameraImageModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298321574)
            
            //--TRIMMABLE-BOUNDARY-START(12888256166)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888256166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OgAC.LCIRC.RMSCameraImageModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.IOT.RMS.Common.RMSCameraImageModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OgAC.LCIRC.RMSCameraImageModel)).Id);
                        }, $vOIXYi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3354278,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $wCweQd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3354278,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Base64Data"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OgAC.LCIRC.RMSCameraImageModel.$type, $.$discardRef(), "Base64Data", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Base64Data")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Base64Data";
                        $i3.DelaredOn = "LivingThing.Core.IOT.RMS.Common.RMSCameraImageModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OgAC.LCIRC.RMSCameraImageModel)).Base64Data);
                        }, $ewdkif ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3354278,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Base64Data = value.AsReference($.$$.S.String);
                        }, $lERURf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3354278,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888256166)
            
            //--TRIMMABLE-BOUNDARY-START(17183223462)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.RMSCameraImageModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183223462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _Base64Data = _target.Base64Data;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Base64Data"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Base64Data, ($v) => _Base64Data = $v, $.$$.S.String)))
                    {
                        _target.Base64Data = _Base64Data;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183223462)
            
            //--TRIMMABLE-BOUNDARY-START(8593288870)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.RMSCameraImageModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593288870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRC.RMSCameraImageModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRC.RMSCameraImageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRC.RMSCameraImageModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRC.RMSCameraImageModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRC.RMSCameraImageModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRC.RMSCameraImageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRC.RMSCameraImageModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593288870)
            
            static $h = 3354278;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRC.RMSCameraImageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888256166),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3354278,
      "h": 12888256166,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888256166),
//--TRIMMABLE-BOUNDARY-START(17183223462),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3223206,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3354278,
      "h": 17183223462,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183223462),
//--TRIMMABLE-BOUNDARY-START(8593288870),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3223206,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3354278,
      "h": 8593288870,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593288870)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298321574),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3354278,
      "h": 4298321574,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298321574)
  ],
  "h": 3354278
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRC.RMSCameraImageModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSCameraImageModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSCameraImageModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3354278)
        
        

        //--TRIMMABLE-BOUNDARY-START(4730534)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDashboardGlobalSettings`, ($self) => class RMSDashboardGlobalSettings extends $.$XBGm.LCICS$2.IOTDashboardGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299697830)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299697830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299697830)
            
            //--TRIMMABLE-BOUNDARY-START(4299697830)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299697830)
            
            static $h = 4730534;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDashboardGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299697830),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4730534,
      "h": 4299697830,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299697830)
  ],
  "h": 4730534
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDashboardGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4730534)
        
        

        //--TRIMMABLE-BOUNDARY-START(4992678)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceGlobalSettings`, ($self) => class RMSDeviceGlobalSettings extends $.$XBGm.LCICS$2.IOTDeviceGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299959974)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299959974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299959974)
            
            //--TRIMMABLE-BOUNDARY-START(4299959974)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299959974)
            
            static $h = 4992678;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDeviceGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299959974),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4992678,
      "h": 4299959974,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299959974)
  ],
  "h": 4992678
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4992678)
        
        

        //--TRIMMABLE-BOUNDARY-START(6303398)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSDeviceStates`, ($self) => class RMSDeviceStates extends $.$XBGm.LCICS$3.IOTDeviceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4301270694)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301270694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301270694)
            
            //--TRIMMABLE-BOUNDARY-START(4301270694)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4301270694)
            
            static $h = 6303398;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTDeviceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301270694),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6303398,
      "h": 4301270694,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301270694)
  ],
  "h": 6303398
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSDeviceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6303398)
        
        

        //--TRIMMABLE-BOUNDARY-START(6827686)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSStationStates`, ($self) => class RMSStationStates extends $.$XBGm.LCICS$3.IOTDeviceScopeStates
        {
            //--TRIMMABLE-BOUNDARY-START(4301794982)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301794982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301794982)
            
            //--TRIMMABLE-BOUNDARY-START(4301794982)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4301794982)
            
            static $h = 6827686;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTDeviceScopeStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301794982),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6827686,
      "h": 4301794982,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301794982)
  ],
  "h": 6827686
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSStationStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSStationStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6827686)
        
        

        //--TRIMMABLE-BOUNDARY-START(6041254)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSStationSettings`, ($self) => class RMSStationSettings extends $.$XBGm.LCICS$2.IOTDeviceScopeSettings
        {
            //--TRIMMABLE-BOUNDARY-START(30070812326)
            /*PositionedGridWidget?*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(30070812326)
            
            //--TRIMMABLE-BOUNDARY-START(8595975846)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595975846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8595975846)
            
            //--TRIMMABLE-BOUNDARY-START(8595975846)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8595975846)
            
            static $h = 6041254;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDeviceScopeSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30070812326),
    {
      "p": 7876336,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185910438,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25775845030,
        "f": 83886081
      },
      "n": "UI",
      "d": 6041254,
      "h": 30070812326,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30070812326)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595975846),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6041254,
      "h": 8595975846,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595975846)
  ],
  "h": 6041254
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICS$2.IIOTDeviceScopeSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSStationSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6041254)
        
        

        //--TRIMMABLE-BOUNDARY-START(1322662)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceCommandModel`, ($self) => class RMSDeviceCommandModel extends $.$XBGm.LCICM.IOTDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296289958)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296289958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296289958)
            
            //--TRIMMABLE-BOUNDARY-START(4296289958)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296289958)
            
            static $h = 1322662;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296289958),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1322662,
      "h": 4296289958,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296289958)
  ],
  "h": 1322662
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1322662)
        
        

        //--TRIMMABLE-BOUNDARY-START(2371238)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceStatusModel`, ($self) => class RMSDeviceStatusModel extends $.$XBGm.LCICM.IOTDeviceStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297338534)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297338534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297338534)
            
            //--TRIMMABLE-BOUNDARY-START(4297338534)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297338534)
            
            static $h = 2371238;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297338534),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2371238,
      "h": 4297338534,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297338534)
  ],
  "h": 2371238
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2371238)
        
        

        //--TRIMMABLE-BOUNDARY-START(6565542)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSServiceStates`, ($self) => class RMSServiceStates extends $.$XBGm.LCICS$3.IOTServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4301532838)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301532838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301532838)
            
            //--TRIMMABLE-BOUNDARY-START(4301532838)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4301532838)
            
            static $h = 6565542;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301532838),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6565542,
      "h": 4301532838,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301532838)
  ],
  "h": 6565542
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSServiceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6565542)
        
        

        //--TRIMMABLE-BOUNDARY-START(5779110)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSServiceSettings`, ($self) => class RMSServiceSettings extends $.$XBGm.LCICS$2.IOTServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4300746406)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300746406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300746406)
            
            //--TRIMMABLE-BOUNDARY-START(4300746406)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4300746406)
            
            static $h = 5779110;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300746406),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5779110,
      "h": 4300746406,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300746406)
  ],
  "h": 5779110
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSServiceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5779110)
        
        

        //--TRIMMABLE-BOUNDARY-START(2240166)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceSendDataModelTypeDescriptor`, ($self) => class RMSDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297207462)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297207462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCM.RMSDeviceSendDataModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRCM.RMSDeviceSendDataModel, this, factory);
                    }, $iMBWTk ??= {"r":65537,"n":"","d":2240166,"h":0,"f":17825794}), 0, "RMSDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Models_RMSDeviceSendDataModel_LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModelTypeDescriptorBuilder.g.cs", "RMSDeviceSendDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297207462)
            
            //--TRIMMABLE-BOUNDARY-START(12887142054)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887142054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887142054)
            
            //--TRIMMABLE-BOUNDARY-START(17182109350)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182109350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182109350)
            
            //--TRIMMABLE-BOUNDARY-START(8592174758)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592174758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCM.RMSDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCM.RMSDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592174758)
            
            static $h = 2240166;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887142054),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2240166,
      "h": 12887142054,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887142054),
//--TRIMMABLE-BOUNDARY-START(17182109350),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2109094,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2240166,
      "h": 17182109350,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182109350),
//--TRIMMABLE-BOUNDARY-START(8592174758),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2109094,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2240166,
      "h": 8592174758,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592174758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297207462),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2240166,
      "h": 4297207462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297207462)
  ],
  "h": 2240166
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2240166)
        
        

        //--TRIMMABLE-BOUNDARY-START(4861606)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsTypeDescriptor`, ($self) => class RMSDashboardGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299828902)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299828902);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings, this, factory);
                    }, $jsuZHd ??= {"r":65537,"n":"","d":4861606,"h":0,"f":17825794}), 0, "RMSDashboardGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Settings_RMSDashboardGlobalSettings_LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettingsTypeDescriptorBuilder.g.cs", "RMSDashboardGlobalSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299828902)
            
            //--TRIMMABLE-BOUNDARY-START(12889763494)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889763494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889763494)
            
            //--TRIMMABLE-BOUNDARY-START(17184730790)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184730790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDashboardGlobalSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDashboardGlobalSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184730790)
            
            //--TRIMMABLE-BOUNDARY-START(8594796198)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594796198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594796198)
            
            static $h = 4861606;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889763494),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4861606,
      "h": 12889763494,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889763494),
//--TRIMMABLE-BOUNDARY-START(17184730790),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4730534,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4861606,
      "h": 17184730790,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184730790),
//--TRIMMABLE-BOUNDARY-START(8594796198),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4730534,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4861606,
      "h": 8594796198,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594796198)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299828902),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4861606,
      "h": 4299828902,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299828902)
  ],
  "h": 4861606
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDashboardGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDashboardGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDashboardGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4861606)
        
        

        //--TRIMMABLE-BOUNDARY-START(5123750)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsTypeDescriptor`, ($self) => class RMSDeviceGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300091046)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300091046);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, this, factory);
                    }, $vKVhNb ??= {"r":65537,"n":"","d":5123750,"h":0,"f":17825794}), 0, "RMSDeviceGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Settings_RMSDeviceGlobalSettings_LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettingsTypeDescriptorBuilder.g.cs", "RMSDeviceGlobalSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300091046)
            
            //--TRIMMABLE-BOUNDARY-START(12890025638)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890025638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890025638)
            
            //--TRIMMABLE-BOUNDARY-START(17184992934)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184992934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDeviceGlobalSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184992934)
            
            //--TRIMMABLE-BOUNDARY-START(8595058342)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595058342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595058342)
            
            static $h = 5123750;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890025638),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5123750,
      "h": 12890025638,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890025638),
//--TRIMMABLE-BOUNDARY-START(17184992934),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4992678,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5123750,
      "h": 17184992934,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184992934),
//--TRIMMABLE-BOUNDARY-START(8595058342),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4992678,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5123750,
      "h": 8595058342,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595058342)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300091046),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5123750,
      "h": 4300091046,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300091046)
  ],
  "h": 5123750
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5123750)
        
        

        //--TRIMMABLE-BOUNDARY-START(6434470)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSDeviceStatesTypeDescriptor`, ($self) => class RMSDeviceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$2.RMSDeviceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4301401766)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301401766);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$2.RMSDeviceStatesTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$2.RMSDeviceStates, this, factory);
                    }, $HGfsfl ??= {"r":65537,"n":"","d":6434470,"h":0,"f":17825794}), 0, "RMSDeviceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\States_RMSDeviceStates_LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStatesTypeDescriptorBuilder.g.cs", "RMSDeviceStatesTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301401766)
            
            //--TRIMMABLE-BOUNDARY-START(12891336358)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891336358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891336358)
            
            //--TRIMMABLE-BOUNDARY-START(17186303654)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186303654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTDeviceStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTDeviceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186303654)
            
            //--TRIMMABLE-BOUNDARY-START(8596369062)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596369062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$2.RMSDeviceStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$2.RMSDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSDeviceStates)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$2.RMSDeviceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSDeviceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$2.RMSDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSDeviceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596369062)
            
            static $h = 6434470;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$2.RMSDeviceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891336358),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6434470,
      "h": 12891336358,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891336358),
//--TRIMMABLE-BOUNDARY-START(17186303654),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6303398,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6434470,
      "h": 17186303654,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186303654),
//--TRIMMABLE-BOUNDARY-START(8596369062),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6303398,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6434470,
      "h": 8596369062,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596369062)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301401766),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6434470,
      "h": 4301401766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301401766)
  ],
  "h": 6434470
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$2.RMSDeviceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSDeviceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6434470)
        
        

        //--TRIMMABLE-BOUNDARY-START(6958758)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSStationStatesTypeDescriptor`, ($self) => class RMSStationStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$2.RMSStationStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4301926054)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301926054);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$2.RMSStationStatesTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$2.RMSStationStates, this, factory);
                    }, $Bnjtpd ??= {"r":65537,"n":"","d":6958758,"h":0,"f":17825794}), 0, "RMSStationStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\States_RMSStationStates_LivingThing.Core.IOT.RMS.Common.States.RMSStationStatesTypeDescriptorBuilder.g.cs", "RMSStationStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301926054)
            
            //--TRIMMABLE-BOUNDARY-START(12891860646)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891860646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTDeviceScopeStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891860646)
            
            //--TRIMMABLE-BOUNDARY-START(17186827942)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.States.RMSStationStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186827942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTDeviceScopeStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTDeviceScopeStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186827942)
            
            //--TRIMMABLE-BOUNDARY-START(8596893350)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.States.RMSStationStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596893350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$2.RMSStationStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$2.RMSStationStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSStationStates)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$2.RMSStationStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSStationStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$2.RMSStationStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSStationStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596893350)
            
            static $h = 6958758;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$2.RMSStationStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891860646),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6958758,
      "h": 12891860646,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891860646),
//--TRIMMABLE-BOUNDARY-START(17186827942),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6827686,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6958758,
      "h": 17186827942,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186827942),
//--TRIMMABLE-BOUNDARY-START(8596893350),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6827686,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6958758,
      "h": 8596893350,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596893350)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301926054),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6958758,
      "h": 4301926054,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301926054)
  ],
  "h": 6958758
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$2.RMSStationStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSStationStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSStationStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6958758)
        
        

        //--TRIMMABLE-BOUNDARY-START(6172326)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptor`, ($self) => class RMSStationSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSStationSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4301139622)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301139622);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$1.RMSStationSettings, this, factory);
                    }, $nKVAmh ??= {"r":65537,"n":"","d":6172326,"h":0,"f":17825794}), 0, "RMSStationSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Settings_RMSStationSettings_LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettingsTypeDescriptorBuilder.g.cs", "RMSStationSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301139622)
            
            //--TRIMMABLE-BOUNDARY-START(12891074214)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891074214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UI"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OgAC.LCIRCS$1.RMSStationSettings.$type, $.$discardRef(), "UI", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UI")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bMcF.LFCW.PositionedGridWidget, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "UI";
                        $i1.DelaredOn = "LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$bMcF.LFCW.PositionedGridWidget, ($.$cast(target, $.$OgAC.LCIRCS$1.RMSStationSettings)).UI);
                        }, $pLndnl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6172326,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UI = value.AsReference($.$bMcF.LFCW.PositionedGridWidget);
                        }, $QBXaZa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6172326,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICS$2.IOTDeviceScopeSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891074214)
            
            //--TRIMMABLE-BOUNDARY-START(17186041510)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186041510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDeviceScopeSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDeviceScopeSettings));
                {
                    /*var*/ let _UI = _target.UI;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UI"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bMcF.LFCW.PositionedGridWidget));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _UI, ($v) => _UI = $v, $.$bMcF.LFCW.PositionedGridWidget)))
                    {
                        _target.UI = _UI;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186041510)
            
            //--TRIMMABLE-BOUNDARY-START(8596106918)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596106918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$1.RMSStationSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$1.RMSStationSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSStationSettings)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$1.RMSStationSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSStationSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$1.RMSStationSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSStationSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596106918)
            
            static $h = 6172326;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSStationSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891074214),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6172326,
      "h": 12891074214,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891074214),
//--TRIMMABLE-BOUNDARY-START(17186041510),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6041254,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6172326,
      "h": 17186041510,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186041510),
//--TRIMMABLE-BOUNDARY-START(8596106918),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6041254,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6172326,
      "h": 8596106918,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596106918)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301139622),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6172326,
      "h": 4301139622,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301139622)
  ],
  "h": 6172326
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$1.RMSStationSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSStationSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6172326)
        
        

        //--TRIMMABLE-BOUNDARY-START(1453734)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceCommandModelTypeDescriptor`, ($self) => class RMSDeviceCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296421030)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296421030);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCM.RMSDeviceCommandModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRCM.RMSDeviceCommandModel, this, factory);
                    }, $zJtYSk ??= {"r":65537,"n":"","d":1453734,"h":0,"f":17825794}), 0, "RMSDeviceCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Models_RMSDeviceCommandModel_LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModelTypeDescriptorBuilder.g.cs", "RMSDeviceCommandModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296421030)
            
            //--TRIMMABLE-BOUNDARY-START(12886355622)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886355622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886355622)
            
            //--TRIMMABLE-BOUNDARY-START(17181322918)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181322918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceCommandModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181322918)
            
            //--TRIMMABLE-BOUNDARY-START(8591388326)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591388326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCM.RMSDeviceCommandModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCM.RMSDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceCommandModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCM.RMSDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCM.RMSDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591388326)
            
            static $h = 1453734;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886355622),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1453734,
      "h": 12886355622,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886355622),
//--TRIMMABLE-BOUNDARY-START(17181322918),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1322662,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1453734,
      "h": 17181322918,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181322918),
//--TRIMMABLE-BOUNDARY-START(8591388326),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1322662,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1453734,
      "h": 8591388326,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591388326)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296421030),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1453734,
      "h": 4296421030,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296421030)
  ],
  "h": 1453734
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1453734)
        
        

        //--TRIMMABLE-BOUNDARY-START(2502310)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceStatusModelTypeDescriptor`, ($self) => class RMSDeviceStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297469606)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297469606);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCM.RMSDeviceStatusModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRCM.RMSDeviceStatusModel, this, factory);
                    }, $pMwJng ??= {"r":65537,"n":"","d":2502310,"h":0,"f":17825794}), 0, "RMSDeviceStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Models_RMSDeviceStatusModel_LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModelTypeDescriptorBuilder.g.cs", "RMSDeviceStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297469606)
            
            //--TRIMMABLE-BOUNDARY-START(12887404198)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887404198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887404198)
            
            //--TRIMMABLE-BOUNDARY-START(17182371494)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182371494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceStatusModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182371494)
            
            //--TRIMMABLE-BOUNDARY-START(8592436902)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592436902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCM.RMSDeviceStatusModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCM.RMSDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceStatusModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCM.RMSDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCM.RMSDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592436902)
            
            static $h = 2502310;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887404198),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2502310,
      "h": 12887404198,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887404198),
//--TRIMMABLE-BOUNDARY-START(17182371494),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2371238,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2502310,
      "h": 17182371494,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182371494),
//--TRIMMABLE-BOUNDARY-START(8592436902),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2371238,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2502310,
      "h": 8592436902,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592436902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297469606),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2502310,
      "h": 4297469606,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297469606)
  ],
  "h": 2502310
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2502310)
        
        

        //--TRIMMABLE-BOUNDARY-START(6696614)
        $asm.$cls(`$OgAC.LCIRCS$2.RMSServiceStatesTypeDescriptor`, ($self) => class RMSServiceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$2.RMSServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4301663910)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301663910);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$2.RMSServiceStatesTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$2.RMSServiceStates, this, factory);
                    }, $dkCrGi ??= {"r":65537,"n":"","d":6696614,"h":0,"f":17825794}), 0, "RMSServiceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\States_ForecourtServiceStates_LivingThing.Core.IOT.RMS.Common.States.RMSServiceStatesTypeDescriptorBuilder.g.cs", "RMSServiceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301663910)
            
            //--TRIMMABLE-BOUNDARY-START(12891598502)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891598502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891598502)
            
            //--TRIMMABLE-BOUNDARY-START(17186565798)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186565798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTServiceStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186565798)
            
            //--TRIMMABLE-BOUNDARY-START(8596631206)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596631206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$2.RMSServiceStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$2.RMSServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSServiceStates)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$2.RMSServiceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSServiceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$2.RMSServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$2.RMSServiceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596631206)
            
            static $h = 6696614;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$2.RMSServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891598502),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6696614,
      "h": 12891598502,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891598502),
//--TRIMMABLE-BOUNDARY-START(17186565798),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6565542,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6696614,
      "h": 17186565798,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186565798),
//--TRIMMABLE-BOUNDARY-START(8596631206),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6565542,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6696614,
      "h": 8596631206,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596631206)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301663910),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6696614,
      "h": 4301663910,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301663910)
  ],
  "h": 6696614
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$2.RMSServiceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.States.RMSServiceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}States${separator}RMSServiceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6696614)
        
        

        //--TRIMMABLE-BOUNDARY-START(5910182)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSServiceSettingsTypeDescriptor`, ($self) => class RMSServiceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSServiceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300877478)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300877478);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$1.RMSServiceSettingsTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$1.RMSServiceSettings, this, factory);
                    }, $tDRoGc ??= {"r":65537,"n":"","d":5910182,"h":0,"f":17825794}), 0, "RMSServiceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Settings_RMSServiceSettings_LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettingsTypeDescriptorBuilder.g.cs", "RMSServiceSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300877478)
            
            //--TRIMMABLE-BOUNDARY-START(12890812070)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890812070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890812070)
            
            //--TRIMMABLE-BOUNDARY-START(17185779366)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185779366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTServiceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185779366)
            
            //--TRIMMABLE-BOUNDARY-START(8595844774)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595844774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$1.RMSServiceSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$1.RMSServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSServiceSettings)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$1.RMSServiceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSServiceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$1.RMSServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSServiceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595844774)
            
            static $h = 5910182;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSServiceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890812070),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5910182,
      "h": 12890812070,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890812070),
//--TRIMMABLE-BOUNDARY-START(17185779366),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5779110,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5910182,
      "h": 17185779366,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185779366),
//--TRIMMABLE-BOUNDARY-START(8595844774),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5779110,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5910182,
      "h": 8595844774,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595844774)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300877478),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5910182,
      "h": 4300877478,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300877478)
  ],
  "h": 5910182
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$1.RMSServiceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSServiceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5910182)
        
        

        //--TRIMMABLE-BOUNDARY-START(1846950)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceReceivedDataModel`, ($self) => class RMSDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$OgAC.LCIRCM.RMSReceivedStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4296814246)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296814246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296814246)
            
            //--TRIMMABLE-BOUNDARY-START(4296814246)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296814246)
            
            static $h = 1846950;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$OgAC.LCIRCM.RMSReceivedStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296814246),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1846950,
      "h": 4296814246,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296814246)
  ],
  "h": 1846950
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1846950)
        
        

        //--TRIMMABLE-BOUNDARY-START(1978022)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceReceivedDataModelTypeDescriptor`, ($self) => class RMSDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296945318)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296945318);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCM.RMSDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, this, factory);
                    }, $xBNNRa ??= {"r":65537,"n":"","d":1978022,"h":0,"f":17825794}), 0, "RMSDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Models_RMSDeviceReceivedDataModel_LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "RMSDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296945318)
            
            //--TRIMMABLE-BOUNDARY-START(12886879910)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886879910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$OgAC.LCIRCM.RMSReceivedStatus).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886879910)
            
            //--TRIMMABLE-BOUNDARY-START(17181847206)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181847206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.RMS.Common.Models.RMSReceivedStatus>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$OgAC.LCIRCM.RMSReceivedStatus).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$OgAC.LCIRCM.RMSReceivedStatus)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181847206)
            
            //--TRIMMABLE-BOUNDARY-START(8591912614)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591912614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCM.RMSDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591912614)
            
            static $h = 1978022;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886879910),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1978022,
      "h": 12886879910,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886879910),
//--TRIMMABLE-BOUNDARY-START(17181847206),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1846950,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1978022,
      "h": 17181847206,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181847206),
//--TRIMMABLE-BOUNDARY-START(8591912614),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1846950,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1978022,
      "h": 8591912614,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591912614)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296945318),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1978022,
      "h": 4296945318,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296945318)
  ],
  "h": 1978022
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1978022)
        
        

        //--TRIMMABLE-BOUNDARY-START(3813030)
        $asm.$cls(`$OgAC.LCIRC.RMSDataConverter`, ($self) => class RMSDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298780326)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298780326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298780326)
            
            //--TRIMMABLE-BOUNDARY-START(4298780326)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298780326)
            
            static $h = 3813030;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298780326),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3813030,
      "h": 4298780326,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298780326)
  ],
  "h": 3813030
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$OgAC.LCIRCM.RMSDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3813030)
        
        

        //--TRIMMABLE-BOUNDARY-START(1126054)
        $asm.$cls(`$OgAC.LCIRCH.IRMSServiceHubClient`, ($self) => class IRMSServiceHubClient
        {
            static $h = 1126054;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1126054
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Hubs.IRMSServiceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Hubs${separator}IRMSServiceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1126054)
        
        

        $asm.$typeProxy("$OgAC.LCIRCM.RMSServiceModel", "$OgAC.LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel");
        $asm.$typeProxy("$OgAC.LCIRCM.RMSStationModel", "$OgAC.LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel");
        $asm.$typeProxy("$OgAC.LCIRCM.RMSDeviceModel", "$OgAC.LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel");
        $asm.$typeProxy("$OgAC.LCIRCS$1.RMSDeviceHardwareSettings", "$OgAC.LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings");
        $asm.$typeProxy("$OgAC.LCIRCS.IRMSDeviceStatusHandler", "$OgAC.LivingThing.Core.IOT.RMS.Common.Services.IRMSDeviceStatusHandler");
        $asm.$typeProxy("$OgAC.LCIRCS.IRMSRemoteService", "$OgAC.LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService");
        //--TRIMMABLE-BOUNDARY-START(5516966)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceSettings`, ($self) => class RMSDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $self, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4300484262)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300484262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300484262)
            
            //--TRIMMABLE-BOUNDARY-START(4300484262)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4300484262)
            
            static $h = 5516966;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300484262),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5516966,
      "h": 4300484262,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300484262)
  ],
  "h": 5516966
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5516966)
        
        

        //--TRIMMABLE-BOUNDARY-START(2961062)
        $asm.$cls(`$OgAC.LCIRCM.RMSStationModel`, ($self) => class RMSStationModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $self, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297928358)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297928358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297928358)
            
            //--TRIMMABLE-BOUNDARY-START(4297928358)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297928358)
            
            static $h = 2961062;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297928358),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2961062,
      "h": 4297928358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297928358)
  ],
  "h": 2961062,
  "a": [
    {
      "t": 983079,
      "c": 42950656039,
      "n": [
        {
          "n": "Name",
          "v": "Station",
          "t": 1310721
        }
      ]
    },
    {
      "t": $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates).$h,
      "c": Number(BigInt($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates).$h)|0x100000000n)
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSStationModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2961062)
        
        

        //--TRIMMABLE-BOUNDARY-START(4468390)
        $asm.$cls(`$OgAC.LCIRCS.IRMSRemoteService`, ($self) => class IRMSRemoteService
        {
            static $h = 4468390;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4468390,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSDeviceModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSStationModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$OgAC.LCIRCM.RMSServiceModel, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Services${separator}IRMSRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4468390)
        
        

        //--TRIMMABLE-BOUNDARY-START(1584806)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceModel`, ($self) => class RMSDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $self, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(30066355878)
            /*RMSStationModel?*/ Station = null;
            //--TRIMMABLE-BOUNDARY-END(30066355878)
            
            //--TRIMMABLE-BOUNDARY-START(8591519398)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591519398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591519398)
            
            //--TRIMMABLE-BOUNDARY-START(8591519398)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(8591519398)
            
            static $h = 1584806;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066355878),
    {
      "p": 2961062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181453990,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771388582,
        "f": 83886081
      },
      "n": "Station",
      "d": 1584806,
      "h": 30066355878,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066355878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591519398),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1584806,
      "h": 8591519398,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591519398)
  ],
  "h": 1584806
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1584806)
        
        

        //--TRIMMABLE-BOUNDARY-START(5254822)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceHardwareSettings`, ($self) => class RMSDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $self, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4300222118)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300222118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300222118)
            
            //--TRIMMABLE-BOUNDARY-START(4300222118)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300222118)
            
            static $h = 5254822;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300222118),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5254822,
      "h": 4300222118,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300222118)
  ],
  "h": 5254822
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5254822)
        
        

        //--TRIMMABLE-BOUNDARY-START(2698918)
        $asm.$cls(`$OgAC.LCIRCM.RMSServiceModel`, ($self) => class RMSServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(51542306470)
            /*IEnumerable<IOTServiceAttendantModel>?*/ LoginAttendants = null;
            //--TRIMMABLE-BOUNDARY-END(51542306470)
            
            //--TRIMMABLE-BOUNDARY-START(4297666214)
            /*IEnumerable<GatewayDeviceModel>?*/ _gateways = null;
            //--TRIMMABLE-BOUNDARY-END(4297666214)
            
            //--TRIMMABLE-BOUNDARY-START(21477535398)
            /*IEnumerable<GatewayDeviceModel>? */ get Gateways()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067469990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel>?*/ let __ca1__;
                return this._gateways ??= ((__ca1__ = this.Devices) !== null ? $.$sl.SL.Enumerable.ToList($.$NzWm.LCIDGM$1.GatewayDeviceModel, $.$sl.SL.Enumerable.Select$1($.$OgAC.LCIRCM.RMSDeviceModel, $.$NzWm.LCIDGM$1.GatewayDeviceModel, $.$sl.SL.Enumerable.Where($.$OgAC.LCIRCM.RMSDeviceModel, __ca1__, new ($.$$.S.Func$$$($.$OgAC.LCIRCM.RMSDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.FamilyName === "Gateway";
                }, $MNRDaj ??= {"r":262145,"p":[{"n":"e","p":1584806}],"n":"","d":2698918,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OgAC.LCIRCM.RMSDeviceModel, $.$NzWm.LCIDGM$1.GatewayDeviceModel))().$ctor(this,  (/*e*/ e) =>
                {
                    return (() =>
                    {
                        //new $.$NzWm.LCIDGM$1.GatewayDeviceModel()
                        const $t1 = $.$NzWm.LCIDGM$1.GatewayDeviceModel;
                        const $i1 = new $t1();
                        $i1.$ctor$8();
                        $i1.Identifier = e.Identifier;
                        $i1.DateCreated = e.DateCreated;
                        $i1.Name = e.Name;
                        $i1.UniqueId = e.UniqueId;
                        $i1.LastSeenOnline = e.LastSeenOnline;
                        $i1.Attributes = e.Attributes;
                        $i1.Family = e.Family;
                        $i1.DeviceType = e.DeviceType;
                        return $i1;
                    })();
                }, $DPAegh ??= {"r":5961279,"p":[{"n":"e","p":1584806}],"n":"","d":2698918,"h":0,"f":17825794}))) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(21477535398)
            
            //--TRIMMABLE-BOUNDARY-START(73017142950)
            /*IEnumerable<RMSStationModel>?*/ Stations = null;
            //--TRIMMABLE-BOUNDARY-END(73017142950)
            
            //--TRIMMABLE-BOUNDARY-START(17182568102)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182568102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182568102)
            
            //--TRIMMABLE-BOUNDARY-START(17182568102)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(17182568102)
            
            static $h = 2698918;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542306470),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657404582,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132241062,
        "f": 83886081
      },
      "n": "LoginAttendants",
      "d": 2698918,
      "h": 51542306470,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542306470),
//--TRIMMABLE-BOUNDARY-START(21477535398),
    {
      "p": $.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067469990,
        "f": 50331649
      },
      "n": "Gateways",
      "d": 2698918,
      "h": 21477535398,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477535398),
//--TRIMMABLE-BOUNDARY-START(73017142950),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247339174,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722175654,
        "f": 83886081
      },
      "n": "Stations",
      "d": 2698918,
      "h": 73017142950,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017142950)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297666214),
    {
      "t": $.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel).$h,
      "n": "_gateways",
      "d": 2698918,
      "h": 4297666214,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297666214)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182568102),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2698918,
      "h": 17182568102,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182568102)
  ],
  "h": 2698918
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2698918)
        
        

        //--TRIMMABLE-BOUNDARY-START(4402854)
        $asm.$cls(`$OgAC.LCIRCS.IRMSDeviceStatusHandler`, ($self) => class IRMSDeviceStatusHandler
        {
            static $h = 4402854;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4402854
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Services.IRMSDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Services${separator}IRMSDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4402854)
        
        

        //--TRIMMABLE-BOUNDARY-START(4075174)
        $asm.$cls(`$OgAC.LCIRC.RMSDeviceModelDefinition`, ($self) => class RMSDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4299042470)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299042470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299042470)
            
            //--TRIMMABLE-BOUNDARY-START(4299042470)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299042470)
            
            static $h = 4075174;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299042470),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4075174,
      "h": 4299042470,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299042470)
  ],
  "h": 4075174
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4075174)
        
        

        //--TRIMMABLE-BOUNDARY-START(4533926)
        $asm.$cls(`$OgAC.LCIRCS.IRMSRemoteService_Mocking`, ($self) => class IRMSRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4299501222)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299501222);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299501222)
            
            //--TRIMMABLE-BOUNDARY-START(38659239590)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>> */ LCICS$1$IIOTServicesRemoteService$LivingThing$Core$IOT$Common$Models$IOTServiceTierType$LivingThing$Core$IOT$RMS$Common$Models$RMSServiceModel$LivingThing$Core$IOT$RMS$Common$Settings$RMSServiceSettings$LivingThing$Core$IOT$RMS$Common$States$RMSServiceStates$LivingThing$Core$IOT$RMS$Common$Models$RMSStationModel$LivingThing$Core$IOT$RMS$Common$Settings$RMSStationSettings$LivingThing$Core$IOT$RMS$Common$States$RMSStationStates$LivingThing$Core$IOT$RMS$Common$Models$RMSDeviceModel$LivingThing$Core$IOT$RMS$Common$Settings$RMSDeviceSettings$LivingThing$Core$IOT$RMS$Common$Settings$RMSDeviceHardwareSettings$LivingThing$Core$IOT$RMS$Common$States$RMSDeviceStates$LivingThing$Core$IOT$RMS$Common$Models$RMSDeviceStatusModel$LivingThing$Core$IOT$RMS$Common$Models$RMSDeviceCommandModel$Publish(/*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel*/ dashboard)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659239590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$OgAC.LCIRCM.RMSServiceModel, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i1.MethodName = "Publish";
                    return $i1;
                })();
                return this.InvokeAsync($.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$OgAC.LCIRCM.RMSServiceModel, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel), $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OgAC.LCIRCM.RMSServiceModel.$type, dashboard) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38659239590)
            
            //--TRIMMABLE-BOUNDARY-START(8594468518)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Models.UserServiceSubscriptionModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>>> */ LCFCCR$ISubscriptionBasedRemoteService$LivingThing$Core$IOT$RMS$Common$Models$RMSServiceModel$LoadServices(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594468518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$OgAC.LCIRCM.RMSServiceModel)).$type;
                    $i2.MethodName = "LoadServices";
                    return $i2;
                })();
                return this.InvokeAsync($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$OgAC.LCIRCM.RMSServiceModel)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8594468518)
            
            //--TRIMMABLE-BOUNDARY-START(34364272294)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCR$IServiceRemoteService$LivingThing$Core$IOT$RMS$Common$Models$RMSServiceModel$LivingThing$Core$IOT$Common$Models$IOTServiceTierType$ChangeServiceTier(/*string*/ contextId, /*LivingThing.Core.IOT.Common.Models.IOTServiceTierType*/ newTier, /*System.DateTime*/ expiryDate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364272294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$uvJL.LCFCR.IServiceRemoteService$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i3.MethodName = "ChangeServiceTier";
                    return $i3;
                })();
                return this.InvokeAsync($.$uvJL.LCFCR.IServiceRemoteService$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, contextId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$XBGm.LCICM.IOTServiceTierType.$type, $.$box(newTier, $.$XBGm.LCICM.IOTServiceTierType)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, expiryDate) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34364272294)
            
            //--TRIMMABLE-BOUNDARY-START(12889435814)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>> */ LCFCD$ICreateDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSServiceModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889435814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i4.MethodName = "Create";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12889435814)
            
            //--TRIMMABLE-BOUNDARY-START(21479370406)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSServiceModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479370406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i5.MethodName = "ReadMany";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OgAC.LCIRCM.RMSServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21479370406)
            
            //--TRIMMABLE-BOUNDARY-START(25774337702)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSServiceModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774337702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i6.MethodName = "ReadSingle";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OgAC.LCIRCM.RMSServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25774337702)
            
            //--TRIMMABLE-BOUNDARY-START(30069304998)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSServiceModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069304998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i7.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i7.MethodName = "Update";
                    return $i7;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30069304998)
            
            //--TRIMMABLE-BOUNDARY-START(17184403110)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184403110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSServiceModel).$type;
                    $i8.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i8.MethodName = "Delete";
                    return $i8;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17184403110)
            
            static $h = 4533926;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299501222),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4533926,
      "h": 4299501222,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4299501222)
  ],
  "h": 4533926
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OgAC.LCIRCS.IRMSRemoteService, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$OgAC.LCIRCM.RMSServiceModel, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Services${separator}IRMSRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4533926)
        
        

        //--TRIMMABLE-BOUNDARY-START(77478)
        $asm.$cls(`$OgAC.LCFCR.ICRUDDataRemoteService_RMSDeviceModel_Mocking`, ($self) => class ICRUDDataRemoteService_RMSDeviceModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295044774)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295044774);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295044774)
            
            //--TRIMMABLE-BOUNDARY-START(8590012070)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel>> */ LCFCD$ICreateDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSDeviceModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590012070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSDeviceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590012070)
            
            //--TRIMMABLE-BOUNDARY-START(17179946662)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSDeviceModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179946662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OgAC.LCIRCM.RMSDeviceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17179946662)
            
            //--TRIMMABLE-BOUNDARY-START(21474913958)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSDeviceModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474913958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OgAC.LCIRCM.RMSDeviceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21474913958)
            
            //--TRIMMABLE-BOUNDARY-START(25769881254)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSDeviceModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769881254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSDeviceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25769881254)
            
            //--TRIMMABLE-BOUNDARY-START(12884979366)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884979366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSDeviceModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSDeviceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12884979366)
            
            static $h = 77478;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295044774),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 77478,
      "h": 4295044774,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295044774)
  ],
  "h": 77478
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.IReadDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_RMSDeviceModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_RMSDeviceModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(77478)
        
        

        //--TRIMMABLE-BOUNDARY-START(143014)
        $asm.$cls(`$OgAC.LCFCR.ICRUDDataRemoteService_RMSStationModel_Mocking`, ($self) => class ICRUDDataRemoteService_RMSStationModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295110310)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295110310);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295110310)
            
            //--TRIMMABLE-BOUNDARY-START(8590077606)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel>> */ LCFCD$ICreateDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSStationModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590077606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSStationModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSStationModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590077606)
            
            //--TRIMMABLE-BOUNDARY-START(17180012198)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSStationModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180012198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSStationModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OgAC.LCIRCM.RMSStationModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180012198)
            
            //--TRIMMABLE-BOUNDARY-START(21474979494)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSStationModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474979494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.WireTransportModel$$($.$OgAC.LCIRCM.RMSStationModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OgAC.LCIRCM.RMSStationModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21474979494)
            
            //--TRIMMABLE-BOUNDARY-START(25769946790)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$IOT$RMS$Common$Models$RMSStationModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769946790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OgAC.LCIRCM.RMSStationModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSStationModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25769946790)
            
            //--TRIMMABLE-BOUNDARY-START(12885044902)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885044902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSStationModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OgAC.LCIRCM.RMSStationModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885044902)
            
            static $h = 143014;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295110310),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 143014,
      "h": 4295110310,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295110310)
  ],
  "h": 143014
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.ICreateDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.IReadDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_RMSStationModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_RMSStationModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(143014)
        
        

        //--TRIMMABLE-BOUNDARY-START(5648038)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceSettingsTypeDescriptor`, ($self) => class RMSDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300615334)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300615334);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$1.RMSDeviceSettingsTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$1.RMSDeviceSettings, this, factory);
                    }, $zfPtae ??= {"r":65537,"n":"","d":5648038,"h":0,"f":17825794}), 0, "RMSDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Settings_RMSDeviceSettings_LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettingsTypeDescriptorBuilder.g.cs", "RMSDeviceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300615334)
            
            //--TRIMMABLE-BOUNDARY-START(12890549926)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890549926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890549926)
            
            //--TRIMMABLE-BOUNDARY-START(17185517222)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185517222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings, LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings, LivingThing.Core.IOT.RMS.Common.States.RMSStationStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings, LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel, LivingThing.Core.IOT.RMS.Common.Services.IRMSDeviceStatusHandler, LivingThing.Core.IOT.RMS.Common.Hubs.IRMSServiceHubClient, LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185517222)
            
            //--TRIMMABLE-BOUNDARY-START(8595582630)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595582630);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$1.RMSDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$1.RMSDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceSettings)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$1.RMSDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$1.RMSDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595582630)
            
            static $h = 5648038;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890549926),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5648038,
      "h": 12890549926,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890549926),
//--TRIMMABLE-BOUNDARY-START(17185517222),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5516966,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5648038,
      "h": 17185517222,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185517222),
//--TRIMMABLE-BOUNDARY-START(8595582630),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5516966,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5648038,
      "h": 8595582630,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595582630)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300615334),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5648038,
      "h": 4300615334,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300615334)
  ],
  "h": 5648038
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5648038)
        
        

        //--TRIMMABLE-BOUNDARY-START(2829990)
        $asm.$cls(`$OgAC.LCIRCM.RMSServiceModelTypeDescriptor`, ($self) => class RMSServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297797286)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297797286);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRCM.RMSServiceModel, this, factory);
                    }, $YxdOMd ??= {"r":65537,"n":"","d":2829990,"h":0,"f":17825794}), 0, "RMSServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Models_RMSServiceModel_LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModelTypeDescriptorBuilder.g.cs", "RMSServiceModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297797286)
            
            //--TRIMMABLE-BOUNDARY-START(12887731878)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887731878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LoginAttendants"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OgAC.LCIRCM.RMSServiceModel.$type, $.$discardRef(), "LoginAttendants", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LoginAttendants")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "LoginAttendants";
                        $i1.DelaredOn = "LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel), ($.$cast(target, $.$OgAC.LCIRCM.RMSServiceModel)).LoginAttendants);
                        }, $cCDuFc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2829990,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LoginAttendants = value.AsReference($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel));
                        }, $qPLTnl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2829990,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Gateways"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OgAC.LCIRCM.RMSServiceModel.$type, $.$discardRef(), "Gateways", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Gateways")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Gateways";
                        $i3.DelaredOn = "LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel), ($.$cast(target, $.$OgAC.LCIRCM.RMSServiceModel)).Gateways);
                        }, $XOKMDf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2829990,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Stations"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OgAC.LCIRCM.RMSServiceModel.$type, $.$discardRef(), "Stations", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Stations")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Stations";
                        $i5.DelaredOn = "LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel), ($.$cast(target, $.$OgAC.LCIRCM.RMSServiceModel)).Stations);
                        }, $Ozjbvh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2829990,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Stations = value.AsReference($.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel));
                        }, $hgyxZe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2829990,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887731878)
            
            //--TRIMMABLE-BOUNDARY-START(17182699174)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182699174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings, LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings, LivingThing.Core.IOT.RMS.Common.States.RMSStationStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings, LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel, LivingThing.Core.IOT.RMS.Common.Services.IRMSDeviceStatusHandler, LivingThing.Core.IOT.RMS.Common.Hubs.IRMSServiceHubClient, LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTServiceModel));
                {
                    /*var*/ let _LoginAttendants = _target.LoginAttendants;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LoginAttendants"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel), $.$XBGm.LCICM.IOTServiceAttendantModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel), $.$XBGm.LCICM.IOTServiceAttendantModel, property, $.$ref(() => _LoginAttendants, ($v) => _LoginAttendants = $v, $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel))))
                    {
                        _target.LoginAttendants = _LoginAttendants;
                        if (_LoginAttendants !== null)
                        {
                            let $en10 = _LoginAttendants.SCG$IEnumerable$$$GetEnumerator();
                            while ($en10.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en10.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$XBGm.LCICM.IOTServiceAttendantModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel), $.$XBGm.LCICM.IOTServiceAttendantModel, property, $.$ref(() => _LoginAttendants, ($v) => _LoginAttendants = $v, $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceAttendantModel)));
                    }
                }
                {
                    /*var*/ let _Gateways = _target.Gateways;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Gateways"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel), $.$NzWm.LCIDGM$1.GatewayDeviceModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel), $.$NzWm.LCIDGM$1.GatewayDeviceModel, property, $.$ref(() => _Gateways, ($v) => _Gateways = $v, $.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel))))
                    {
                        if (_Gateways !== null)
                        {
                            let $en15 = _Gateways.SCG$IEnumerable$$$GetEnumerator();
                            while ($en15.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en15.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$NzWm.LCIDGM$1.GatewayDeviceModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel), $.$NzWm.LCIDGM$1.GatewayDeviceModel, property, $.$ref(() => _Gateways, ($v) => _Gateways = $v, $.$$.SCG.IEnumerable$$($.$NzWm.LCIDGM$1.GatewayDeviceModel)));
                    }
                }
                {
                    /*var*/ let _Stations = _target.Stations;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Stations"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCIRCM.RMSStationModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCIRCM.RMSStationModel, property, $.$ref(() => _Stations, ($v) => _Stations = $v, $.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel))))
                    {
                        _target.Stations = _Stations;
                        if (_Stations !== null)
                        {
                            let $en20 = _Stations.SCG$IEnumerable$$$GetEnumerator();
                            while ($en20.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en20.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OgAC.LCIRCM.RMSStationModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel), $.$OgAC.LCIRCM.RMSStationModel, property, $.$ref(() => _Stations, ($v) => _Stations = $v, $.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSStationModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182699174)
            
            //--TRIMMABLE-BOUNDARY-START(8592764582)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592764582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCM.RMSServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCM.RMSServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSServiceModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCM.RMSServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCM.RMSServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592764582)
            
            static $h = 2829990;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887731878),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2829990,
      "h": 12887731878,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887731878),
//--TRIMMABLE-BOUNDARY-START(17182699174),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2698918,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2829990,
      "h": 17182699174,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182699174),
//--TRIMMABLE-BOUNDARY-START(8592764582),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2698918,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2829990,
      "h": 8592764582,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592764582)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297797286),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2829990,
      "h": 4297797286,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297797286)
  ],
  "h": 2829990
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCM.RMSServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2829990)
        
        

        //--TRIMMABLE-BOUNDARY-START(1715878)
        $asm.$cls(`$OgAC.LCIRCM.RMSDeviceModelTypeDescriptor`, ($self) => class RMSDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296683174)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296683174);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCM.RMSDeviceModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRCM.RMSDeviceModel, this, factory);
                    }, $SYlNkg ??= {"r":65537,"n":"","d":1715878,"h":0,"f":17825794}), 0, "RMSDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Models_RMSDeviceModel_LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModelTypeDescriptorBuilder.g.cs", "RMSDeviceModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296683174)
            
            //--TRIMMABLE-BOUNDARY-START(12886617766)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886617766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Station"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OgAC.LCIRCM.RMSDeviceModel.$type, $.$discardRef(), "Station", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Station")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OgAC.LCIRCM.RMSStationModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Station";
                        $i1.DelaredOn = "LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCM.RMSDeviceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$OgAC.LCIRCM.RMSStationModel, ($.$cast(target, $.$OgAC.LCIRCM.RMSDeviceModel)).Station);
                        }, $BQPGyi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1715878,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OgAC.LCIRCM.RMSDeviceModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Station = value.AsReference($.$OgAC.LCIRCM.RMSStationModel);
                        }, $wZhSOj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1715878,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886617766)
            
            //--TRIMMABLE-BOUNDARY-START(17181585062)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181585062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings, LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings, LivingThing.Core.IOT.RMS.Common.States.RMSStationStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings, LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel, LivingThing.Core.IOT.RMS.Common.Services.IRMSDeviceStatusHandler, LivingThing.Core.IOT.RMS.Common.Hubs.IRMSServiceHubClient, LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceModel));
                {
                    /*var*/ let _Station = _target.Station;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Station"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OgAC.LCIRCM.RMSStationModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Station, ($v) => _Station = $v, $.$OgAC.LCIRCM.RMSStationModel)))
                    {
                        _target.Station = _Station;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181585062)
            
            //--TRIMMABLE-BOUNDARY-START(8591650470)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591650470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCM.RMSDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCM.RMSDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCM.RMSDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCM.RMSDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591650470)
            
            static $h = 1715878;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886617766),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1715878,
      "h": 12886617766,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886617766),
//--TRIMMABLE-BOUNDARY-START(17181585062),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1584806,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1715878,
      "h": 17181585062,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181585062),
//--TRIMMABLE-BOUNDARY-START(8591650470),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1584806,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1715878,
      "h": 8591650470,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591650470)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296683174),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1715878,
      "h": 4296683174,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296683174)
  ],
  "h": 1715878
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCM.RMSDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1715878)
        
        

        //--TRIMMABLE-BOUNDARY-START(5385894)
        $asm.$cls(`$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsTypeDescriptor`, ($self) => class RMSDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300353190)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300353190);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, this, factory);
                    }, $RoEtCc ??= {"r":65537,"n":"","d":5385894,"h":0,"f":17825794}), 0, "RMSDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Settings_RMSDeviceHardwareSettings_LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "RMSDeviceHardwareSettingsTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300353190)
            
            //--TRIMMABLE-BOUNDARY-START(12890287782)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890287782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890287782)
            
            //--TRIMMABLE-BOUNDARY-START(17185255078)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185255078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings, LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings, LivingThing.Core.IOT.RMS.Common.States.RMSStationStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings, LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel, LivingThing.Core.IOT.RMS.Common.Services.IRMSDeviceStatusHandler, LivingThing.Core.IOT.RMS.Common.Hubs.IRMSServiceHubClient, LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185255078)
            
            //--TRIMMABLE-BOUNDARY-START(8595320486)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595320486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595320486)
            
            static $h = 5385894;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890287782),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5385894,
      "h": 12890287782,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890287782),
//--TRIMMABLE-BOUNDARY-START(17185255078),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5254822,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5385894,
      "h": 17185255078,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185255078),
//--TRIMMABLE-BOUNDARY-START(8595320486),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5254822,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5385894,
      "h": 8595320486,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595320486)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300353190),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5385894,
      "h": 4300353190,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300353190)
  ],
  "h": 5385894
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Settings${separator}RMSDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5385894)
        
        

        //--TRIMMABLE-BOUNDARY-START(3092134)
        $asm.$cls(`$OgAC.LCIRCM.RMSStationModelTypeDescriptor`, ($self) => class RMSStationModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSStationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298059430)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298059430);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OgAC.LCIRCM.RMSStationModelTypeDescriptor.GenerateProperties($.$OgAC.LCIRCM.RMSStationModel, this, factory);
                    }, $KCXfCg ??= {"r":65537,"n":"","d":3092134,"h":0,"f":17825794}), 0, "RMSStationModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.RMS.Common\\Models_RMSStationModel_LivingThing.Core.IOT.RMS.Common.Models.RMSStationModelTypeDescriptorBuilder.g.cs", "RMSStationModelTypeDescriptor", 42);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298059430)
            
            //--TRIMMABLE-BOUNDARY-START(12887994022)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887994022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887994022)
            
            //--TRIMMABLE-BOUNDARY-START(17182961318)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182961318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.RMS.Common.Models.RMSServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.RMS.Common.Settings.RMSServiceSettings, LivingThing.Core.IOT.RMS.Common.States.RMSServiceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSStationSettings, LivingThing.Core.IOT.RMS.Common.States.RMSStationStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceModel, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceSettings, LivingThing.Core.IOT.RMS.Common.Settings.RMSDeviceHardwareSettings, LivingThing.Core.IOT.RMS.Common.States.RMSDeviceStates, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceStatusModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceCommandModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceReceivedDataModel, LivingThing.Core.IOT.RMS.Common.Models.RMSDeviceSendDataModel, LivingThing.Core.IOT.RMS.Common.Services.IRMSDeviceStatusHandler, LivingThing.Core.IOT.RMS.Common.Hubs.IRMSServiceHubClient, LivingThing.Core.IOT.RMS.Common.Services.IRMSRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182961318)
            
            //--TRIMMABLE-BOUNDARY-START(8593026726)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.RMS.Common.Models.RMSStationModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593026726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OgAC.LCIRCM.RMSStationModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OgAC.LCIRCM.RMSStationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSStationModel)))
                {
                    /*var*/ let result = $.$OgAC.LCIRCM.RMSStationModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSStationModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OgAC.LCIRCM.RMSStationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OgAC.LCIRCM.RMSStationModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593026726)
            
            static $h = 3092134;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OgAC.LCIRCM.RMSStationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887994022),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3092134,
      "h": 12887994022,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887994022),
//--TRIMMABLE-BOUNDARY-START(17182961318),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2961062,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3092134,
      "h": 17182961318,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182961318),
//--TRIMMABLE-BOUNDARY-START(8593026726),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2961062,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3092134,
      "h": 8593026726,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593026726)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298059430),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3092134,
      "h": 4298059430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298059430)
  ],
  "h": 3092134
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OgAC.LCIRCM.RMSStationModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.Models.RMSStationModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}Models${separator}RMSStationModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3092134)
        
        

        //--TRIMMABLE-BOUNDARY-START(3878566)
        $asm.$cls(`$OgAC.LCIRC.RMSDevice`, ($self) => class RMSDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, $.$OgAC.LCIRCM.RMSReceivedStatus).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(8593813158)
            $ctor$3(/*RMSDashboardScope*/ scope, /*RMSDeviceModel*/ model)
            {
                super.$ctor$3($.$cast($.$sl.SL.Enumerable.First$1($.$XBGm.LCICI.IIOTDeviceFamily, scope.Factory.DeviceFamilies), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice)), scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593813158);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593813158)
            
            //--TRIMMABLE-BOUNDARY-START(4298845862)
            $ctor$2(/*IIOTDeviceFamily<RMSDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*RMSDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298845862);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298845862)
            
            //--TRIMMABLE-BOUNDARY-START(12888780454)
            /*IOTDeviceFeatures */ get Features()
            {
                return 0/*IOTDeviceFeatures.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12888780454)
            
            static $h = 3878566;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, $.$OgAC.LCIRCM.RMSReceivedStatus).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12888780454),
    {
      "p": 29922705,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478715046,
        "f": 50364417
      },
      "n": "Features",
      "d": 3878566,
      "h": 12888780454,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12888780454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593813158),
    {
      "p": [
        {
          "n": "scope",
          "p": 3681958
        },
        {
          "n": "model",
          "p": 1584806
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3878566,
      "h": 8593813158,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593813158),
//--TRIMMABLE-BOUNDARY-START(4298845862),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1584806
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3878566,
      "h": 4298845862,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298845862)
  ],
  "h": 3878566
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3878566)
        
        

        //--TRIMMABLE-BOUNDARY-START(3944102)
        $asm.$cls(`$OgAC.LCIRC.RMSDeviceDefinition`, ($self) => class RMSDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, $.$OgAC.LCIRCM.RMSReceivedStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4298911398)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298911398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298911398)
            
            //--TRIMMABLE-BOUNDARY-START(4298911398)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298911398)
            
            static $h = 3944102;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, $.$OgAC.LCIRCM.RMSReceivedStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298911398),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3944102,
      "h": 4298911398,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298911398)
  ],
  "h": 3944102
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3944102)
        
        

        //--TRIMMABLE-BOUNDARY-START(3747494)
        $asm.$cls(`$OgAC.LCIRC.RMSDashboardScopeFactory`, ($self) => class RMSDashboardScopeFactory extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).SmartGenericServerDeviceScopeFactory
        {
            //--TRIMMABLE-BOUNDARY-START(8593682086)
            $ctor$1(/*ServiceFactory*/ services, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ deviceStore, /*IIOTDeviceFamily<RMSDevice>*/ family, /*IServerRemoteService*/ serverRemoteService, /*IHubConnector<IRMSServiceHubClient>*/ hubConnector, /*RMSDataConverter*/ converter)
            {
                super.$ctor$2(services, config, scopeStore, deviceStore, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice)), [family], null, null), serverRemoteService, hubConnector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593682086);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Converter = converter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593682086)
            
            //--TRIMMABLE-BOUNDARY-START(17183616678)
            /*string */ get DashboardLink()
            {
                return "RMS";
            }
            //--TRIMMABLE-BOUNDARY-END(17183616678)
            
            //--TRIMMABLE-BOUNDARY-START(12888649382)
            /*RMSDataConverter*/ Converter = null;
            //--TRIMMABLE-BOUNDARY-END(12888649382)
            
            //--TRIMMABLE-BOUNDARY-START(38658453158)
            /*RMSDashboardScope? */ GetScope$1(/*RMSServiceModel*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658453158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$OgAC.LCIRC.RMSDashboardScope().$ctor$2(this, service);
            }
            //--TRIMMABLE-BOUNDARY-END(38658453158)
            
            //--TRIMMABLE-BOUNDARY-START(42953420454)
            /*RMSDashboardScope */ GetScope(/*RMSStationModel*/ scope, /*IEnumerable<RMSDeviceModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953420454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$OgAC.LCIRC.RMSDashboardScope().$ctor$3(this, scope, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(42953420454)
            
            static $h = 3747494;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).SmartGenericServerDeviceScopeFactory; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183616678),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363485862,
        "f": 50364417
      },
      "n": "DashboardLink",
      "d": 3747494,
      "h": 17183616678,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183616678),
//--TRIMMABLE-BOUNDARY-START(12888649382),
    {
      "p": 3813030,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773551270,
        "f": 50331649
      },
      "n": "Converter",
      "d": 3747494,
      "h": 12888649382,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12888649382)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38658453158),
    {
      "r": 3681958,
      "p": [
        {
          "n": "service",
          "p": 2698918
        }
      ],
      "n": "GetScope",
      "o": "@$1",
      "d": 3747494,
      "h": 38658453158,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38658453158),
//--TRIMMABLE-BOUNDARY-START(42953420454),
    {
      "r": 3681958,
      "p": [
        {
          "n": "scope",
          "p": 2961062
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSDeviceModel).$h
        }
      ],
      "n": "GetScope",
      "d": 3747494,
      "h": 42953420454,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42953420454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593682086),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "deviceStore",
          "p": 1283473
        },
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice).$h
        },
        {
          "n": "serverRemoteService",
          "p": 1309651
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$OgAC.LCIRCH.IRMSServiceHubClient).$h
        },
        {
          "n": "converter",
          "p": 3813030
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3747494,
      "h": 8593682086,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593682086)
  ],
  "h": 3747494
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSDashboardScopeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSDashboardScopeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3747494)
        
        

        //--TRIMMABLE-BOUNDARY-START(4009638)
        $asm.$cls(`$OgAC.LCIRC.RMSDeviceFamily`, ($self) => class RMSDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).ConfiguredServerDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298976934)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<RMSDeviceReceivedDataModel, RMSDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<RMSDeviceReceivedDataModel, RMSDeviceStatusModel>*/ converter)
            {
                super.$ctor$3(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298976934);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298976934)
            
            static $h = 4009638;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings).ConfiguredServerDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298976934),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4009638,
      "h": 4298976934,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298976934)
  ],
  "h": 4009638
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$OgAC.LCIRC.RMSDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$OgAC.LCIRC.RMSDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$XBGm.LCICI.IIOTServerDeviceFamily ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4009638)
        
        

        //--TRIMMABLE-BOUNDARY-START(3681958)
        $asm.$cls(`$OgAC.LCIRC.RMSDashboardScope`, ($self) => class RMSDashboardScope extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, $.$OgAC.LCIRCM.RMSReceivedStatus).iSmartGenericDeviceServiceAsScope
        {
            //--TRIMMABLE-BOUNDARY-START(4298649254)
            $ctor$2(/*RMSDashboardScopeFactory*/ factory, /*RMSServiceModel*/ service)
            {
                super.$ctor$5(factory, service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298649254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298649254)
            
            //--TRIMMABLE-BOUNDARY-START(8593616550)
            $ctor$3(/*RMSDashboardScopeFactory*/ factory, /*RMSStationModel*/ scope, /*IEnumerable<RMSDeviceModel>*/ _devices)
            {
                super.$ctor$4(factory, scope, _devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593616550);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593616550)
            
            //--TRIMMABLE-BOUNDARY-START(25773485734)
            /*Task<RMSDevice?> */ GetDevice(/*RMSDeviceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773485734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$OgAC.LCIRC.RMSDevice, new $.$OgAC.LCIRC.RMSDevice().$ctor$3(this, model));
            }
            //--TRIMMABLE-BOUNDARY-END(25773485734)
            
            //--TRIMMABLE-BOUNDARY-START(12888583846)
            /*string? */ get ApplicationLink()
            {
                return this.Model.Identifier.Empty ? `RMS?ServiceId=${$.$strNN($.$dspc(this.Model.ServiceId.Id, $.$$.S.Object, ($t) => $t.ToString))}` : null;
            }
            //--TRIMMABLE-BOUNDARY-END(12888583846)
            
            static $h = 3681958;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$OgAC.LCIRCS$1.RMSServiceSettings, $.$OgAC.LCIRCS$2.RMSServiceStates, $.$OgAC.LCIRCM.RMSStationModel, $.$OgAC.LCIRCS$1.RMSStationSettings, $.$OgAC.LCIRCS$2.RMSStationStates, $.$OgAC.LCIRCM.RMSDeviceModel, $.$OgAC.LCIRCS$1.RMSDeviceSettings, $.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, $.$OgAC.LCIRCS$2.RMSDeviceStates, $.$OgAC.LCIRCM.RMSDeviceStatusModel, $.$OgAC.LCIRCM.RMSDeviceCommandModel, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel, $.$OgAC.LCIRCS.IRMSDeviceStatusHandler, $.$OgAC.LCIRCH.IRMSServiceHubClient, $.$OgAC.LCIRCS.IRMSRemoteService, $.$OgAC.LCIRCS$1.RMSDeviceGlobalSettings, $.$OgAC.LCIRCM.RMSReceivedStatus).iSmartGenericDeviceServiceAsScope; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12888583846),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478518438,
        "f": 50364417
      },
      "n": "ApplicationLink",
      "d": 3681958,
      "h": 12888583846,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12888583846)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25773485734),
    {
      "r": $.$$.STT.Task$$($.$OgAC.LCIRC.RMSDevice).$h,
      "p": [
        {
          "n": "model",
          "p": 1584806
        }
      ],
      "n": "GetDevice",
      "d": 3681958,
      "h": 25773485734,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25773485734)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298649254),
    {
      "p": [
        {
          "n": "factory",
          "p": 3747494
        },
        {
          "n": "service",
          "p": 2698918
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3681958,
      "h": 4298649254,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298649254),
//--TRIMMABLE-BOUNDARY-START(8593616550),
    {
      "p": [
        {
          "n": "factory",
          "p": 3747494
        },
        {
          "n": "scope",
          "p": 2961062
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$($.$OgAC.LCIRCM.RMSDeviceModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3681958,
      "h": 8593616550,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593616550)
  ],
  "h": 3681958
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSDashboardScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSDashboardScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3681958)
        
        

        //--TRIMMABLE-BOUNDARY-START(4206246)
        $asm.$cls(`$OgAC.LCIRC.RMSProtocolDecoder`, ($self) => class RMSProtocolDecoder extends $.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299173542)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299173542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299173542)
            
            //--TRIMMABLE-BOUNDARY-START(4299173542)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299173542)
            
            static $h = 4206246;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299173542),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4206246,
      "h": 4299173542,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299173542)
  ],
  "h": 4206246
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolDecoder$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceProtocolDecoder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSProtocolDecoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSProtocolDecoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4206246)
        
        

        //--TRIMMABLE-BOUNDARY-START(4271782)
        $asm.$cls(`$OgAC.LCIRC.RMSProtocolEncoder`, ($self) => class RMSProtocolEncoder extends $.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299239078)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299239078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299239078)
            
            //--TRIMMABLE-BOUNDARY-START(4299239078)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299239078)
            
            static $h = 4271782;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299239078),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4271782,
      "h": 4299239078,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299239078)
  ],
  "h": 4271782
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolEncoder$$($.$OgAC.LCIRCM.RMSDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceProtocolEncoder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSProtocolEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSProtocolEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4271782)
        
        

        //--TRIMMABLE-BOUNDARY-START(4140710)
        $asm.$cls(`$OgAC.LCIRC.RMSProtocol`, ($self) => class RMSProtocol extends $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299108006)
            $ctor$3(/*RMSProtocolDecoder*/ _decoder, /*RMSProtocolEncoder*/ _encoder, /*RMSCommands*/ _commands)
            {
                super.$ctor$2(_decoder, _encoder, _commands);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299108006);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299108006)
            
            static $h = 4140710;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$OgAC.LCIRC.RMSDevice, $.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299108006),
    {
      "p": [
        {
          "n": "_decoder",
          "p": 4206246
        },
        {
          "n": "_encoder",
          "p": 4271782
        },
        {
          "n": "_commands",
          "p": 3550886
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4140710,
      "h": 4299108006,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299108006)
  ],
  "h": 4140710
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocol$$$($.$OgAC.LCIRCM.RMSDeviceReceivedDataModel, $.$OgAC.LCIRCM.RMSDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceProtocol ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSProtocol`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSProtocol`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4140710)
        
        

        //--TRIMMABLE-BOUNDARY-START(3550886)
        $asm.$cls(`$OgAC.LCIRC.RMSCommands`, ($self) => class RMSCommands extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$OgAC.LCIRC.RMSDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(8593485478)
            $ctor$5()
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593485478);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593485478)
            
            //--TRIMMABLE-BOUNDARY-START(12888452774)
            /*List<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12888452774)
            
            //--TRIMMABLE-BOUNDARY-START(17183420070)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183420070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$OgAC.LCIRC.RMSCommands.commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17183420070)
            
            //--TRIMMABLE-BOUNDARY-START(21478387366)
            static /*Task<RemoteHardwareSettings> */ GetRemoteHardwareSettings$1(/*IConnectionClient*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478387366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetRemoteHardwareSettings($.$OgAC.LCIRCS$1.RMSDeviceHardwareSettings, device);
            }
            //--TRIMMABLE-BOUNDARY-END(21478387366)
            
            //--TRIMMABLE-BOUNDARY-START(8593485478)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8593485478)
            
            //--TRIMMABLE-BOUNDARY-START(4298518182)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298518182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12888452774)
                    this.commands$1 = (() =>
                    {
                        //new $.$$.SCG.List$$($.$XBGm.LCIP.IOTDeviceProtocolCommand)()
                        const $t1 = $.$$.SCG.List$$($.$XBGm.LCIP.IOTDeviceProtocolCommand);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(12888452774)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298518182)
            
            static $h = 3550886;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$OgAC.LCIRC.RMSDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183420070),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": 3550886,
      "h": 17183420070,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17183420070),
//--TRIMMABLE-BOUNDARY-START(21478387366),
    {
      "r": $.$$.STT.Task$$($.$XBGm.LCICI.RemoteHardwareSettings).$h,
      "p": [
        {
          "n": "device",
          "p": 1568430
        }
      ],
      "n": "GetRemoteHardwareSettings",
      "o": "@$1",
      "d": 3550886,
      "h": 21478387366,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21478387366)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888452774),
    {
      "t": $.$$.SCG.List$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": 3550886,
      "h": 12888452774,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888452774)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593485478),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3550886,
      "h": 8593485478,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593485478)
  ],
  "h": 3550886
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.RMS.Common.RMSCommands`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}RMS${separator}Common${separator}RMSCommands`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3550886)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway"));
})();
//--TRIMMABLE-BOUNDARY-END(11942)
