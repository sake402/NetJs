
//--TRIMMABLE-BOUNDARY-START(29392)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $fXpo, $zHIt, $uvJL, $KuVO, $lOHy, $kVHt, $UrvY, $vWqU, $JRhp, $DJRY, $tUcV, $nYKj, $AvdQ, $bMcF, $XBGm, $NXre) {
    "use strict";
    let _;
    let $abBxrh;
    let $nOVDsb;
    let $nuinmk;
    let $QKoVEa;
    let $uQboqj;
    let $Uorpkd;
    let $mKSfgj;
    let $bqirzi;
    let $nPPXTg;
    let $pPfwQj;
    let $OJptcj;
    let $VVFtLc;
    let $LUqtkf;
    let $rBpHue;
    let $rWsDrb;
    let $gVyame;
    let $mCUFwb;
    let $STDQsh;
    let $xfrShf;
    let $GjGuti;
    let $pgaSse;
    let $kGsikg;
    let $UdKsVj;
    let $sphQJe;
    let $JGKKlc;
    let $melcvh;
    let $TBvWYh;
    let $rKMqsi;
    let $uJLUUd;
    let $aiNSQa;
    let $DzWKbi;
    let $wvNLJa;
    let $NGOitc;
    let $KXhNlj;
    let $REfAvg;
    let $qybqqj;
    let $idMtQh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Services.Client", 
    {
  "h": 29392,
  "f": "LivingThing.Core.IOT.Services.Client",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Services.Client",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Services.Client",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(226000)
        $asm.$cls(`$mVyz.LCISCC.ClientDisconnectedEventArgs`, ($self) => class ClientDisconnectedEventArgs extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590160592)
            $ctor$1(/*IConnectionClient*/ client)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590160592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Client = client;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590160592)
            
            //--TRIMMABLE-BOUNDARY-START(12885127888)
            /*IConnectionClient*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(12885127888)
            
            static $h = 226000;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885127888),
    {
      "p": 1568430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475062480,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30064997072,
        "f": 83886081
      },
      "n": "Client",
      "d": 226000,
      "h": 12885127888,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885127888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590160592),
    {
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 226000,
      "h": 8590160592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590160592)
  ],
  "h": 226000
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Connections.ClientDisconnectedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Connections${separator}ClientDisconnectedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(226000)
        
        

        //--TRIMMABLE-BOUNDARY-START(94928)
        $asm.$cls(`$mVyz.LCISCC.ClientConnectedEventArgs`, ($self) => class ClientConnectedEventArgs extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590029520)
            $ctor$1(/*IConnectionClient*/ client)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590029520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Client = client;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590029520)
            
            //--TRIMMABLE-BOUNDARY-START(12884996816)
            /*IConnectionClient*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(12884996816)
            
            static $h = 94928;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12884996816),
    {
      "p": 1568430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474931408,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30064866000,
        "f": 83886081
      },
      "n": "Client",
      "d": 94928,
      "h": 12884996816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12884996816)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590029520),
    {
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 94928,
      "h": 8590029520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590029520)
  ],
  "h": 94928
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Connections.ClientConnectedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Connections${separator}ClientConnectedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(94928)
        
        

        //--TRIMMABLE-BOUNDARY-START(946896)
        $asm.$cls(`$mVyz.LCISCS.ClientTheme`, ($self) => class ClientTheme extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835521744)
            /*string*/ StatusBarColor = null;
            //--TRIMMABLE-BOUNDARY-END(55835521744)
            
            //--TRIMMABLE-BOUNDARY-START(34360685264)
            /*string*/ NavigationBarColor = null;
            //--TRIMMABLE-BOUNDARY-END(34360685264)
            
            //--TRIMMABLE-BOUNDARY-START(17183366568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.INativeClientTheme.StatusBarColor.get
            get LCFCC$INativeClientTheme$StatusBarColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953170344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StatusBarColor;
            }
            //--TRIMMABLE-BOUNDARY-END(17183366568)
            
            //--TRIMMABLE-BOUNDARY-START(38658203048)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.INativeClientTheme.StatusBarColor.set
            set LCFCC$INativeClientTheme$StatusBarColor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953170344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StatusBarColor = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658203048)
            
            //--TRIMMABLE-BOUNDARY-START(8593431976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.INativeClientTheme.NavigationBarColor.get
            get LCFCC$INativeClientTheme$NavigationBarColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478333864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationBarColor;
            }
            //--TRIMMABLE-BOUNDARY-END(8593431976)
            
            //--TRIMMABLE-BOUNDARY-START(30068268456)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.INativeClientTheme.NavigationBarColor.set
            set LCFCC$INativeClientTheme$NavigationBarColor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478333864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.NavigationBarColor = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30068268456)
            
            //--TRIMMABLE-BOUNDARY-START(12885848784)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885848784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885848784)
            
            //--TRIMMABLE-BOUNDARY-START(12885848784)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885848784)
            
            static $h = 946896;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835521744),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065717968,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540554448,
        "f": 83886081
      },
      "n": "StatusBarColor",
      "d": 946896,
      "h": 55835521744,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835521744),
//--TRIMMABLE-BOUNDARY-START(34360685264),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475783376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950619856,
        "f": 83886081
      },
      "n": "NavigationBarColor",
      "d": 946896,
      "h": 34360685264,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360685264)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885848784),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 946896,
      "h": 12885848784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885848784)
  ],
  "h": 946896
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.INativeClientTheme ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.ClientTheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}ClientTheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(946896)
        
        

        //--TRIMMABLE-BOUNDARY-START(291536)
        $asm.$cls(`$mVyz.LCISCC.ConnectionContextProvider`, ($self) => class ConnectionContextProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590226128)
            /*IConfigurationParser*/ config = null;
            //--TRIMMABLE-BOUNDARY-END(8590226128)
            
            //--TRIMMABLE-BOUNDARY-START(21475128016)
            /*IPersistentStorageService*/ storage = null;
            //--TRIMMABLE-BOUNDARY-END(21475128016)
            
            //--TRIMMABLE-BOUNDARY-START(4295258832)
            $ctor$1(/*IConfigurationParser*/ config, /*IPersistentStorageService*/ storage)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295258832);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.config = config;
                    this.storage = storage;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295258832)
            
            //--TRIMMABLE-BOUNDARY-START(12885193424)
            /*IEnumerable<IConnectionContext>?*/ contexts = null;
            //--TRIMMABLE-BOUNDARY-END(12885193424)
            
            //--TRIMMABLE-BOUNDARY-START(17180160720)
            /*Task<IEnumerable<IConnectionContext>?> *//*async*/  GetContextsAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionContext)), $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionContext), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180160720);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.contexts !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, this.contexts);
                    }
                    /*var*/ let ctxs = this.config.LCFCC$1$IConfigurationParser$GetValue($.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.ConnectionContext), "Connections", null);
                    /*var*/ let appId = ($t1 = this.storage.LCFCS$5$IPersistentStorageService$GetItem($.$$.S.String, "appId"), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (appId === null)
                    {
                        let $t2, $r2;
                        appId = $.$$.S.Guid.NewGuid().ToString();
                        ($t2 = this.storage.LCFCS$5$IPersistentStorageService$SetItem($.$$.S.String, "appId", appId), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    if (ctxs !== null)
                    {
                        let $en3 = ctxs.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let c = $en3.SCG$IEnumerator$$$Current;
                            {
                                c.Id = appId;
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, this.contexts = $.$$.N.InterfaceVarianceStubHandler.Create(ctxs, $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.ConnectionContext), $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionContext)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180160720)
            
            //--TRIMMABLE-BOUNDARY-START(4296666798)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContextProvider.GetContextsAsync()
            LCFCC$IConnectionContextProvider$GetContextsAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296666798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetContextsAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296666798)
            
            static $h = 291536;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180160720),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionContext)).$h,
      "n": "GetContextsAsync",
      "d": 291536,
      "h": 17180160720,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17180160720)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590226128),
    {
      "t": 4950358,
      "n": "config",
      "d": 291536,
      "h": 8590226128,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590226128),
//--TRIMMABLE-BOUNDARY-START(21475128016),
    {
      "t": 63932758,
      "n": "storage",
      "d": 291536,
      "h": 21475128016,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475128016),
//--TRIMMABLE-BOUNDARY-START(12885193424),
    {
      "t": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionContext).$h,
      "n": "contexts",
      "d": 291536,
      "h": 12885193424,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885193424)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295258832),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "storage",
          "p": 63932758
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 291536,
      "h": 4295258832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295258832)
  ],
  "h": 291536
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionContextProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Connections.ConnectionContextProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Connections${separator}ConnectionContextProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(291536)
        
        

        //--TRIMMABLE-BOUNDARY-START(815824)
        $asm.$cls(`$mVyz.LCISCS.BluetoothAdvertiser`, ($self) => class BluetoothAdvertiser extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590750416)
            /*Task */ StartAdvertisement(/*BLEAdvertisementPacket*/ data, /*CancellationToken?*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590750416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8590750416)
            
            //--TRIMMABLE-BOUNDARY-START(12885717712)
            /*void */ StopAdvertisement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885717712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885717712)
            
            //--TRIMMABLE-BOUNDARY-START(4295155169)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconAdvertiser.StartAdvertisement(LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementPacket, System.Threading.CancellationToken?)
            LCFCBBI$IBeaconAdvertiser$StartAdvertisement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295155169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartAdvertisement(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295155169)
            
            //--TRIMMABLE-BOUNDARY-START(8590122465)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconAdvertiser.StopAdvertisement()
            LCFCBBI$IBeaconAdvertiser$StopAdvertisement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590122465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StopAdvertisement(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590122465)
            
            //--TRIMMABLE-BOUNDARY-START(4295783120)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295783120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295783120)
            
            //--TRIMMABLE-BOUNDARY-START(4295783120)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295783120)
            
            static $h = 815824;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590750416),
    {
      "r": 178454529,
      "p": [
        {
          "n": "data",
          "p": 646625
        },
        {
          "n": "token",
          "p": $.$typeNullable($.$$.ST$1.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": "StartAdvertisement",
      "d": 815824,
      "h": 8590750416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590750416),
//--TRIMMABLE-BOUNDARY-START(12885717712),
    {
      "r": 65537,
      "n": "StopAdvertisement",
      "d": 815824,
      "h": 12885717712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885717712)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295783120),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 815824,
      "h": 4295783120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295783120)
  ],
  "h": 815824
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lOHy.LCFCBBI.IBeaconAdvertiser ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.BluetoothAdvertiser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}BluetoothAdvertiser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(815824)
        
        

        //--TRIMMABLE-BOUNDARY-START(1143504)
        $asm.$cls(`$mVyz.LCISCS.EmptyBluetoothSerialPortFactory`, ($self) => class EmptyBluetoothSerialPortFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591078096)
            /*Task<IEnumerable<IBluetoothDevice>> */ GetPairedDevices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591078096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$lOHy.LCFCB.IBluetoothDevice), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$lOHy.LCFCB.IBluetoothDevice), [], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591078096)
            
            //--TRIMMABLE-BOUNDARY-START(12886045392)
            /*Task<IBluetoothDeviceSerialPort> */ Open(/*IBluetoothDevice*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886045392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$lOHy.LCFCB.IBluetoothDeviceSerialPort, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12886045392)
            
            //--TRIMMABLE-BOUNDARY-START(4297055713)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothSerialPortFactory.GetPairedDevices()
            LCFCB$IBluetoothSerialPortFactory$GetPairedDevices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297055713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPairedDevices(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297055713)
            
            //--TRIMMABLE-BOUNDARY-START(8592023009)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothSerialPortFactory.Open(LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothDevice)
            LCFCB$IBluetoothSerialPortFactory$Open()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592023009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Open(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8592023009)
            
            //--TRIMMABLE-BOUNDARY-START(4296110800)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296110800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296110800)
            
            //--TRIMMABLE-BOUNDARY-START(4296110800)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296110800)
            
            static $h = 1143504;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591078096),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$lOHy.LCFCB.IBluetoothDevice)).$h,
      "n": "GetPairedDevices",
      "d": 1143504,
      "h": 8591078096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591078096),
//--TRIMMABLE-BOUNDARY-START(12886045392),
    {
      "r": $.$$.STT.Task$$($.$lOHy.LCFCB.IBluetoothDeviceSerialPort).$h,
      "p": [
        {
          "n": "device",
          "p": 1957345
        }
      ],
      "n": "Open",
      "d": 1143504,
      "h": 12886045392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886045392)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296110800),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1143504,
      "h": 4296110800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296110800)
  ],
  "h": 1143504
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lOHy.LCFCB.IBluetoothSerialPortFactory ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.EmptyBluetoothSerialPortFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}EmptyBluetoothSerialPortFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1143504)
        
        

        //--TRIMMABLE-BOUNDARY-START(881360)
        $asm.$cls(`$mVyz.LCISCS.BluetoothPacketProvider`, ($self) => class BluetoothPacketProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770685136)
            /*EventHandler<BLEAdvertisementPacketArgs>*/ AdvertisementPacketReceived = null;
            //--TRIMMABLE-BOUNDARY-END(25770685136)
            
            //--TRIMMABLE-BOUNDARY-START(25770685136)
            //--TRIMMABLE-BOUNDARY-START(12885783248)
            add_AdvertisementPacketReceived(/*EventHandler<BLEAdvertisementPacketArgs>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885783248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AdvertisementPacketReceived = $.$$.S.Delegate.Combine$2(this.AdvertisementPacketReceived, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12885783248)
            
            //--TRIMMABLE-BOUNDARY-START(34360619728)
            remove_AdvertisementPacketReceived(/*EventHandler<BLEAdvertisementPacketArgs>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360619728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AdvertisementPacketReceived = $.$$.S.Delegate.Remove(this.AdvertisementPacketReceived, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360619728)
            
            //--TRIMMABLE-BOUNDARY-END(25770685136)
            
            //--TRIMMABLE-BOUNDARY-START(55835456208)
            /*EventHandler<BTError>*/ WatcherStopped = null;
            //--TRIMMABLE-BOUNDARY-END(55835456208)
            
            //--TRIMMABLE-BOUNDARY-START(55835456208)
            //--TRIMMABLE-BOUNDARY-START(21475717840)
            add_WatcherStopped(/*EventHandler<BTError>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475717840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WatcherStopped = $.$$.S.Delegate.Combine$2(this.WatcherStopped, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475717840)
            
            //--TRIMMABLE-BOUNDARY-START(42950554320)
            remove_WatcherStopped(/*EventHandler<BTError>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950554320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WatcherStopped = $.$$.S.Delegate.Remove(this.WatcherStopped, value);
            }
            //--TRIMMABLE-BOUNDARY-END(42950554320)
            
            //--TRIMMABLE-BOUNDARY-END(55835456208)
            
            //--TRIMMABLE-BOUNDARY-START(47245521616)
            /*Task */ StartPacketListening()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245521616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47245521616)
            
            //--TRIMMABLE-BOUNDARY-START(51540488912)
            /*void */ StopPacketListening()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540488912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51540488912)
            
            //--TRIMMABLE-BOUNDARY-START(8590253537)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.AdvertisementPacketReceived.add
            LCFCBBI$IBeaconPacketProvider$add_AdvertisementPacketReceived()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590253537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_AdvertisementPacketReceived(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590253537)
            
            //--TRIMMABLE-BOUNDARY-START(30065090017)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.AdvertisementPacketReceived.remove
            LCFCBBI$IBeaconPacketProvider$remove_AdvertisementPacketReceived()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065090017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_AdvertisementPacketReceived(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065090017)
            
            //--TRIMMABLE-BOUNDARY-START(17180188129)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.WatcherStopped.add
            LCFCBBI$IBeaconPacketProvider$add_WatcherStopped()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180188129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_WatcherStopped(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180188129)
            
            //--TRIMMABLE-BOUNDARY-START(38655024609)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.WatcherStopped.remove
            LCFCBBI$IBeaconPacketProvider$remove_WatcherStopped()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655024609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_WatcherStopped(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38655024609)
            
            //--TRIMMABLE-BOUNDARY-START(42949991905)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.StartPacketListening()
            LCFCBBI$IBeaconPacketProvider$StartPacketListening()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949991905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartPacketListening(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42949991905)
            
            //--TRIMMABLE-BOUNDARY-START(47244959201)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.StopPacketListening()
            LCFCBBI$IBeaconPacketProvider$StopPacketListening()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244959201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StopPacketListening(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47244959201)
            
            //--TRIMMABLE-BOUNDARY-START(21475155425)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.AdvertisementPacketReceived
            LivingThing$Core$Frameworks$Common$Bluetooth$Beacon$Interfaces$IBeaconPacketProvider$AdvertisementPacketReceived()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475155425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AdvertisementPacketReceived;
            }
            //--TRIMMABLE-BOUNDARY-END(21475155425)
            
            //--TRIMMABLE-BOUNDARY-START(51539926497)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider.WatcherStopped
            LivingThing$Core$Frameworks$Common$Bluetooth$Beacon$Interfaces$IBeaconPacketProvider$WatcherStopped()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539926497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WatcherStopped;
            }
            //--TRIMMABLE-BOUNDARY-END(51539926497)
            
            //--TRIMMABLE-BOUNDARY-START(4295848656)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295848656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295848656)
            
            //--TRIMMABLE-BOUNDARY-START(4295848656)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295848656)
            
            static $h = 881360;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245521616),
    {
      "r": 178454529,
      "n": "StartPacketListening",
      "d": 881360,
      "h": 47245521616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245521616),
//--TRIMMABLE-BOUNDARY-START(51540488912),
    {
      "r": 65537,
      "n": "StopPacketListening",
      "d": 881360,
      "h": 51540488912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540488912)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295848656),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 881360,
      "h": 4295848656,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295848656)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(25770685136),
    {
      "e": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BLEAdvertisementPacketArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BLEAdvertisementPacketArgs).$h
          }
        ],
        "n": "add_AdvertisementPacketReceived",
        "d": 881360,
        "h": 12885783248,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BLEAdvertisementPacketArgs).$h
          }
        ],
        "n": "remove_AdvertisementPacketReceived",
        "d": 881360,
        "h": 34360619728,
        "f": 285212673
      },
      "n": "AdvertisementPacketReceived",
      "d": 881360,
      "h": 25770685136,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(25770685136),
//--TRIMMABLE-BOUNDARY-START(55835456208),
    {
      "e": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BTError).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BTError).$h
          }
        ],
        "n": "add_WatcherStopped",
        "d": 881360,
        "h": 21475717840,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BTError).$h
          }
        ],
        "n": "remove_WatcherStopped",
        "d": 881360,
        "h": 42950554320,
        "f": 285212673
      },
      "n": "WatcherStopped",
      "d": 881360,
      "h": 55835456208,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835456208)
  ],
  "h": 881360
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lOHy.LCFCBBI.IBeaconPacketProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.BluetoothPacketProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}BluetoothPacketProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(881360)
        
        

        //--TRIMMABLE-BOUNDARY-START(1209040)
        $asm.$cls(`$mVyz.LCISCS.NopWifiClient`, ($self) => class NopWifiClient extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60130751184)
            /*string?*/ SSID = null;
            //--TRIMMABLE-BOUNDARY-END(60130751184)
            
            //--TRIMMABLE-BOUNDARY-START(21476045520)
            /*string?*/ BSSID = null;
            //--TRIMMABLE-BOUNDARY-END(21476045520)
            
            //--TRIMMABLE-BOUNDARY-START(51540816592)
            /*bool*/ IsHidden = false;
            //--TRIMMABLE-BOUNDARY-END(51540816592)
            
            //--TRIMMABLE-BOUNDARY-START(55835783888)
            /*Task<IEnumerable<WifiClientDescriptor>> */ SmartConfigure(/*string?*/ ssid, /*string?*/ password, /*int*/ timeOutSeconds, /*Action<WifiClientDescriptor>?*/ found)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835783888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$XBGm.LCICC.WifiClientDescriptor), $.$sl.SL.Enumerable.Empty($.$XBGm.LCICC.WifiClientDescriptor));
            }
            //--TRIMMABLE-BOUNDARY-END(55835783888)
            
            //--TRIMMABLE-BOUNDARY-START(30065530257)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Connections.IWifiClient.SSID.get
            get LCICC$IWifiClient$SSID()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950432145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SSID;
            }
            //--TRIMMABLE-BOUNDARY-END(30065530257)
            
            //--TRIMMABLE-BOUNDARY-START(12885661073)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Connections.IWifiClient.BSSID.get
            get LCICC$IWifiClient$BSSID()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295726481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BSSID;
            }
            //--TRIMMABLE-BOUNDARY-END(12885661073)
            
            //--TRIMMABLE-BOUNDARY-START(21475595665)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Connections.IWifiClient.IsHidden.get
            get LCICC$IWifiClient$IsHidden()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360497553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsHidden;
            }
            //--TRIMMABLE-BOUNDARY-END(21475595665)
            
            //--TRIMMABLE-BOUNDARY-START(38655464849)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Connections.IWifiClient.SmartConfigure(string?, string?, int, System.Action<LivingThing.Core.IOT.Common.Connections.WifiClientDescriptor>?)
            LCICC$IWifiClient$SmartConfigure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655464849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SmartConfigure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38655464849)
            
            //--TRIMMABLE-BOUNDARY-START(17181078224)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181078224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181078224)
            
            //--TRIMMABLE-BOUNDARY-START(17181078224)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181078224)
            
            static $h = 1209040;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130751184),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245849296,
        "f": 50331649
      },
      "n": "SSID",
      "d": 1209040,
      "h": 60130751184,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130751184),
//--TRIMMABLE-BOUNDARY-START(21476045520),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065980112,
        "f": 50331649
      },
      "n": "BSSID",
      "d": 1209040,
      "h": 21476045520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476045520),
//--TRIMMABLE-BOUNDARY-START(51540816592),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655914704,
        "f": 50331649
      },
      "n": "IsHidden",
      "d": 1209040,
      "h": 51540816592,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540816592)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835783888),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICC.WifiClientDescriptor)).$h,
      "p": [
        {
          "n": "ssid",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "timeOutSeconds",
          "p": 655361,
          "f": 65,
          "v": 60
        },
        {
          "n": "found",
          "p": $.$$.S.Action$$($.$XBGm.LCICC.WifiClientDescriptor).$h,
          "f": 65
        }
      ],
      "n": "SmartConfigure",
      "d": 1209040,
      "h": 55835783888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835783888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181078224),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1209040,
      "h": 17181078224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181078224)
  ],
  "h": 1209040
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICC.IWifiClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.NopWifiClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}NopWifiClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1209040)
        
        

        //--TRIMMABLE-BOUNDARY-START(1274576)
        $asm.$cls(`$mVyz.LCISCS.WifiPasswordProvider`, ($self) => class WifiPasswordProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591209168)
            /*ValueTask<WifiCredential?> */ GetCredential(/*WifiCredential?*/ credential)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591209168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$XBGm.LCICC.WifiCredential, credential);
            }
            //--TRIMMABLE-BOUNDARY-END(8591209168)
            
            //--TRIMMABLE-BOUNDARY-START(4295792017)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Connections.IWifiCredentialProvider.GetCredential(LivingThing.Core.IOT.Common.Connections.WifiCredential?)
            LCICC$IWifiCredentialProvider$GetCredential()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295792017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCredential(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295792017)
            
            //--TRIMMABLE-BOUNDARY-START(4296241872)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296241872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296241872)
            
            //--TRIMMABLE-BOUNDARY-START(4296241872)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296241872)
            
            static $h = 1274576;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591209168),
    {
      "r": $.$$.STT.ValueTask$$($.$XBGm.LCICC.WifiCredential).$h,
      "p": [
        {
          "n": "credential",
          "p": 1086865,
          "f": 65
        }
      ],
      "n": "GetCredential",
      "d": 1274576,
      "h": 8591209168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591209168)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296241872),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1274576,
      "h": 4296241872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296241872)
  ],
  "h": 1274576
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICC.IWifiCredentialProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.WifiPasswordProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}WifiPasswordProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1274576)
        
        

        //--TRIMMABLE-BOUNDARY-START(553680)
        $asm.$cls(`$mVyz.LCISC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590488272)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590488272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient), $.$fXpo.LCFCPC.DIPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage), $.$fXpo.LCFCPC.DIPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$KuVO.LCFCC.IClientConnectionManager, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mVyz.LCISCC.ClientConnectionManager, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$KuVO.LCFCC.IClientConnectionManager))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCC.ClientConnectionManager, x);
                }, $Uorpkd ??= {"r":1502894,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$KuVO.LCFCC.IConnectionContextProvider, $.$mVyz.LCISCC.ConnectionContextProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICC.IWifiCredentialProvider, $.$mVyz.LCISCS.WifiPasswordProvider, services);
                if (options.Runtime === 1/*RuntimeType.WebServer*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime))
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICD.IServiceStore, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICD.ISceneActionStore, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICD.ISceneTriggerStore, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICD.ISceneStore, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICD.IDeviceStatusStore, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICD.IDeviceStore, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICD.IScopeStore, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mVyz.LCISCD.iSmartDatabase, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICD.IScopeStore))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCD.iSmartDatabase, x);
                    }, $mKSfgj ??= {"r":1545617,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICD.IDeviceStore))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCD.iSmartDatabase, x);
                    }, $bqirzi ??= {"r":1283473,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICD.IDeviceStatusStore))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCD.iSmartDatabase, x);
                    }, $nPPXTg ??= {"r":1152401,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICD.ISceneStore))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCD.iSmartDatabase, x);
                    }, $pPfwQj ??= {"r":1414545,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICD.ISceneTriggerStore))().$ctor(this,  (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCD.iSmartDatabase, x);
                    }, $OJptcj ??= {"r":1480081,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICD.ISceneActionStore))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCD.iSmartDatabase, x);
                    }, $VVFtLc ??= {"r":1349009,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICD.IServiceStore))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISCD.iSmartDatabase, x);
                    }, $LUqtkf ??= {"r":1611153,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794}));
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$vWqU.LCFCC.INativeClientTheme, $.$mVyz.LCISCS.ClientTheme, services);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDiscovery, $.$mVyz.LCISCS.DeviceDiscovery, services);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$lOHy.LCFCBBI.IBeaconAdvertiser, $.$mVyz.LCISCS.BluetoothAdvertiser, services);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$lOHy.LCFCBBI.IBeaconPacketProvider, $.$mVyz.LCISCS.BluetoothPacketProvider, services);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$lOHy.LCFCB.IBluetoothSerialPortFactory, $.$mVyz.LCISCS.EmptyBluetoothSerialPortFactory, services);
                }
                if ($.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime))
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICC.IWifiClient, $.$mVyz.LCISCS.NopWifiClient, services);
                }
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTClientDeviceProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mVyz.LCISC.SmartDeviceProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISC.SmartDeviceProvider, x);
                }, $rBpHue ??= {"r":28153233,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTClientDeviceProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISC.SmartDeviceProvider, x);
                }, $rWsDrb ??= {"r":25793937,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceAuthenticator$$($.$XBGm.LCICI.IIOTDeviceModel), $.$mVyz.LCISC.SmartDeviceAuthenticator, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$KuVO.LCFCC.IConnectionEndPoint, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionClient), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mVyz.LCISC.SmartDeviceSocketConnectionEndPoint, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionClient)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISC.SmartDeviceSocketConnectionEndPoint, x);
                }, $gVyame ??= {"r":$.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionClient).$h,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISC.SmartDeviceSocketConnectionEndPoint, x);
                }, $mCUFwb ??= {"r":$.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage).$h,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$KuVO.LCFCC.IConnectionEndPoint))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mVyz.LCISC.SmartDeviceSocketConnectionEndPoint, x);
                }, $STDQsh ??= {"r":1765038,"p":[{"n":"x","p":327718}],"n":"","d":553680,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590488272)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mVyz.LCISC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295520976)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295520976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295520976)
            
            //--TRIMMABLE-BOUNDARY-START(4295520976)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295520976)
            
            static $h = 553680;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590488272),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 553680,
      "h": 8590488272,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590488272)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295520976),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 553680,
      "h": 4295520976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295520976)
  ],
  "h": 553680
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(553680)
        
        

        //--TRIMMABLE-BOUNDARY-START(684752)
        $asm.$cls(`$mVyz.LCISC.SmartDeviceProvider`, ($self) => class SmartDeviceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590619344)
            $ctor$1(/*IEnumerable<IIOTDeviceScopeFactory>*/ factories)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590619344);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Factories = factories;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590619344)
            
            //--TRIMMABLE-BOUNDARY-START(17180553936)
            /*IEnumerable<IIOTDeviceScopeFactory>*/ Factories = null;
            //--TRIMMABLE-BOUNDARY-END(17180553936)
            
            //--TRIMMABLE-BOUNDARY-START(12885586640)
            /*IEnumerable<IIOTDevice> */ get Devices()
            {
                return $.$sl.SL.Enumerable.SelectMany$2($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$XBGm.LCICI.IIOTDevice, this.Factories, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)))().$ctor(this,  (/*f*/ f) =>
                {
                    return f.LCICI$IIOTDeviceScopeFactory$Devices ?? $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDevice).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), null, [0], null));
                }, $nOVDsb ??= {"r":$.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice).$h,"p":[{"n":"f","p":28611985}],"n":"","d":684752,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885586640)
            
            //--TRIMMABLE-BOUNDARY-START(42950357712)
            /*Task<IEnumerable<IIOTDevice>> */ GetDevicesAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950357712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice), this.Devices);
            }
            //--TRIMMABLE-BOUNDARY-END(42950357712)
            
            //--TRIMMABLE-BOUNDARY-START(38655390416)
            /*Task<IEnumerable<IIOTDevice>> */ GetAsync(/*object*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655390416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let _id = null;
                let did;
                if ($.$is(id, $.$fPer.LCFCD.DataId, { set $v($v){ did = $v; } }))
                {
                    /*object?*/ let __ca1__;
                    _id = ((__ca1__ = did.Id) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                }
                else 
                {
                    /*object*/ let __ca2__;
                    _id = ((__ca2__ = id) !== null ? $.$dsp(__ca2__, $.$$.S.Object, ($t) => $t.ToString) : null);
                }
                /*var*/ let devices = $.$sl.SL.Enumerable.Where($.$XBGm.LCICI.IIOTDevice, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                {
                    return d.LCICI$IIOTDevice$Id === _id || d.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$UniqueId === _id;
                }, $nuinmk ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":684752,"h":0,"f":17825794}));
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice), devices);
            }
            //--TRIMMABLE-BOUNDARY-END(38655390416)
            
            //--TRIMMABLE-BOUNDARY-START(51540292304)
            /*Task<IEnumerable<IIOTDevice>> *//*async*/  GetFrom$1(/*IConnectionMessage*/ message)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540292304);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let devices = ($t1 = this.GetFrom(message.LCFCC$IConnectionMessage$Client), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if ($.$sl.SL.Enumerable.Any$1($.$XBGm.LCICI.IIOTDevice, devices))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, devices);
                    }
                    /*string*/ let deviceId;
                    if (!$.$$.S.String.IsNullOrEmpty(message.LCFCC$IConnectionMessage$Id))
                    {
                        /*var*/ let path = $.$$.S.String.Split$5.call(message.LCFCC$IConnectionMessage$Id, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*/*/ 47, /*\\*/ 92], [-1], null));
                        deviceId = $.$sl.SL.Enumerable.Last$1($.$$.S.String, path);
                    }
                    else 
                    {
                        /*var*/ let bytes = $.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(message.LCFCC$IConnectionMessage$Data);
                        deviceId = $.$$.ST.Encoding.ASCII.GetString(bytes, 0, bytes.length);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Where($.$XBGm.LCICI.IIOTDevice, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                    {
                        return $.$$.S.String.Contains$3.call(deviceId, d.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$UniqueId);
                    }, $QKoVEa ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":684752,"h":0,"f":17825794})));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51540292304)
            
            //--TRIMMABLE-BOUNDARY-START(47245325008)
            /*Task<IEnumerable<IIOTDevice>> */ GetFrom(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245325008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let deviceId;
                if (!$.$$.S.String.IsNullOrEmpty(client.LCFCC$IConnectionClient$Id.UniqueId))
                {
                    /*var*/ let path = $.$$.S.String.Split$5.call(client.LCFCC$IConnectionClient$Id.UniqueId, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*/*/ 47, /*\\*/ 92], [-1], null));
                    deviceId = $.$sl.SL.Enumerable.Last$1($.$$.S.String, path);
                }
                else 
                {
                    deviceId = client.LCFCC$IConnectionClient$Id.UniqueId;
                }
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice), $.$sl.SL.Enumerable.Where($.$XBGm.LCICI.IIOTDevice, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                {
                    return d.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$UniqueId === deviceId;
                }, $uQboqj ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":684752,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(47245325008)
            
            //--TRIMMABLE-BOUNDARY-START(8618087825)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceProvider.GetDevicesAsync()
            LCICI$IIOTDeviceProvider$GetDevicesAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8618087825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDevicesAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8618087825)
            
            //--TRIMMABLE-BOUNDARY-START(4323120529)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceProvider.GetAsync(object)
            LCICI$IIOTDeviceProvider$GetAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4323120529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4323120529)
            
            //--TRIMMABLE-BOUNDARY-START(17208022417)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceProvider.GetFrom(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage)
            LCICI$IIOTDeviceProvider$GetFrom$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17208022417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFrom$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17208022417)
            
            //--TRIMMABLE-BOUNDARY-START(12913055121)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceProvider.GetFrom(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCICI$IIOTDeviceProvider$GetFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12913055121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFrom(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12913055121)
            
            static $h = 684752;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180553936),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScopeFactory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360423120,
        "f": 50331650
      },
      "n": "Factories",
      "d": 684752,
      "h": 17180553936,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180553936),
//--TRIMMABLE-BOUNDARY-START(12885586640),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770488528,
        "f": 50331650
      },
      "n": "Devices",
      "d": 684752,
      "h": 12885586640,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12885586640)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950357712),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)).$h,
      "n": "GetDevicesAsync",
      "d": 684752,
      "h": 42950357712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950357712),
//--TRIMMABLE-BOUNDARY-START(38655390416),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)).$h,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "GetAsync",
      "d": 684752,
      "h": 38655390416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655390416),
//--TRIMMABLE-BOUNDARY-START(51540292304),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)).$h,
      "p": [
        {
          "n": "message",
          "p": 1961646
        }
      ],
      "n": "GetFrom",
      "o": "@$1",
      "d": 684752,
      "h": 51540292304,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(51540292304),
//--TRIMMABLE-BOUNDARY-START(47245325008),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "GetFrom",
      "d": 684752,
      "h": 47245325008,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245325008)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590619344),
    {
      "p": [
        {
          "n": "factories",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScopeFactory).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 684752,
      "h": 8590619344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590619344)
  ],
  "h": 684752
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTClientDeviceProvider, $.$XBGm.LCICI.IIOTDeviceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.SmartDeviceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}SmartDeviceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(684752)
        
        

        //--TRIMMABLE-BOUNDARY-START(160464)
        $asm.$cls(`$mVyz.LCISCC.ClientConnectionManager`, ($self) => class ClientConnectionManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885062352)
            /*IPipelineCollection<IConnectionClient>*/ connectionPipelines = null;
            //--TRIMMABLE-BOUNDARY-END(12885062352)
            
            //--TRIMMABLE-BOUNDARY-START(77309571792)
            /*IPipelineCollection<IConnectionMessage>*/ messagePipelines = null;
            //--TRIMMABLE-BOUNDARY-END(77309571792)
            
            //--TRIMMABLE-BOUNDARY-START(8590095056)
            $ctor$1(/*IServiceProvider*/ serviceProvider, /*IPipelineCollection<IConnectionClient>*/ connectionPipelines, /*IPipelineCollection<IConnectionMessage>*/ messagePipelines, /*IEnumerable<IIOTDeviceScopeFactory>*/ factories)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590095056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.serviceProvider = serviceProvider;
                    this.connectionPipelines = connectionPipelines;
                    this.messagePipelines = messagePipelines;
                    this.factories = factories;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590095056)
            
            //--TRIMMABLE-BOUNDARY-START(21474996944)
            /*Dictionary<IConnectionContext, IConnectionInterface>*/ contextInterface = null;
            //--TRIMMABLE-BOUNDARY-END(21474996944)
            
            //--TRIMMABLE-BOUNDARY-START(85899506384)
            /*IServiceProvider*/ serviceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(85899506384)
            
            //--TRIMMABLE-BOUNDARY-START(107374342864)
            /*IConnectionInterface*/ get_Item$1(/*IConnectionContext*/ context)
            {
                return this.contextInterface.get_Item(context);
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(107374342864)
            
            //--TRIMMABLE-BOUNDARY-START(68719637200)
            /*IEnumerable<IConnectionInterface> */ get Interfaces()
            {
                return this.contextInterface.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(68719637200)
            
            //--TRIMMABLE-BOUNDARY-START(73014604496)
            /*string?*/ LocalAddress = null;
            //--TRIMMABLE-BOUNDARY-END(73014604496)
            
            //--TRIMMABLE-BOUNDARY-START(38654866128)
            /*IEnumerable<IIOTDeviceScopeFactory>*/ factories = null;
            //--TRIMMABLE-BOUNDARY-END(38654866128)
            
            //--TRIMMABLE-BOUNDARY-START(25769964240)
            /*void */ DiscardInBuffer(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769964240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25769964240)
            
            //--TRIMMABLE-BOUNDARY-START(30064931536)
            /*void */ Disconnect(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064931536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30064931536)
            
            //--TRIMMABLE-BOUNDARY-START(94489440976)
            /*ValueTask<IConnectionInterface?> *//*async*/  StartServer$1(/*IConnectionContext*/ context, /*IConnectionEndPoint?*/ endpoint)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface), $.$KuVO.LCFCC.IConnectionInterface, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489440976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*IConnectionInterface?*/ let _interface = null;
                    /*string*/ let __ca1__;
                    /*var*/ let factory = $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetKeyedService$1($.$KuVO.LCFCC.ConnectionInterfaceFactory, this.serviceProvider, ((__ca1__ = context.LCFCC$IConnectionContext$Name) !== null ? $.$$.S.String.ToLower.call(__ca1__) : null));
                    if (factory !== null)
                    {
                        _interface = factory.Invoke(this, endpoint, this.connectionPipelines, this.messagePipelines);
                    }
                    if (_interface !== null)
                    {
                        let $t1, $r1;
                        ($t1 = _interface.LCFCC$IConnectionInterface$StartAsync(context), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        this.contextInterface.set_Item(context, _interface);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, _interface);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94489440976)
            
            //--TRIMMABLE-BOUNDARY-START(98784408272)
            /*ValueTask<IConnectionInterface?> */ StartServer$2(TConnectionEndPoint, /*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784408272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(98784408272)
            
            //--TRIMMABLE-BOUNDARY-START(103079375568)
            /*void */ Stop(/*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079375568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.contextInterface.get_Item(context).LCFCC$IConnectionInterface$Stop();
                this.contextInterface.get_Item(context).S$IDisposable$Dispose();
                this.contextInterface.Remove$1(context);
            }
            //--TRIMMABLE-BOUNDARY-END(103079375568)
            
            //--TRIMMABLE-BOUNDARY-START(120259244752)
            /*Task<IConnectionMessage> */ WriteRead$1(/*IConnectionClient*/ client, /*byte[]*/ data, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259244752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$KuVO.LCFCC.IConnectionMessage, null);
            }
            //--TRIMMABLE-BOUNDARY-END(120259244752)
            
            //--TRIMMABLE-BOUNDARY-START(34359898832)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359898832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en2 = this.contextInterface.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let kv = $en2.Current;
                    {
                        kv.Value.S$IDisposable$Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359898832)
            
            //--TRIMMABLE-BOUNDARY-START(90194473680)
            /*ValueTask<IConnectionInterface?> */ StartServer(/*IConnectionContext*/ context, /*ConnectionEndPointProviderFactory*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194473680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(90194473680)
            
            //--TRIMMABLE-BOUNDARY-START(17180029648)
            /*Task<IConnectionClient?> */ ConnectTo(/*IConnectionContext*/ context, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180029648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(17180029648)
            
            //--TRIMMABLE-BOUNDARY-START(111669310160)
            /*Task */ WriteAsync(/*IConnectionClient*/ client, /*OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669310160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111669310160)
            
            //--TRIMMABLE-BOUNDARY-START(81604539088)
            /*Task<OneOf<byte[], ReadOnlyMemory<byte>, Stream>> */ ReadAsync(/*IConnectionClient*/ client, /*TimeSpan*/ timeOut)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604539088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(81604539088)
            
            //--TRIMMABLE-BOUNDARY-START(115964277456)
            /*Task<OneOf<byte[], ReadOnlyMemory<byte>, Stream>> */ WriteRead(/*IConnectionClient*/ client, /*OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ data, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964277456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(115964277456)
            
            //--TRIMMABLE-BOUNDARY-START(4296863406)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.ConnectTo(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, System.Threading.CancellationToken)
            LCFCC$IConnectionManager$ConnectTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296863406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ConnectTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296863406)
            
            //--TRIMMABLE-BOUNDARY-START(38656601774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, LivingThing.Core.Frameworks.Common.Connection.IConnectionEndPoint?)
            LCFCC$IConnectionManager$StartServer$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656601774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38656601774)
            
            //--TRIMMABLE-BOUNDARY-START(34361634478)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, LivingThing.Core.Frameworks.Common.Connection.ConnectionEndPointProviderFactory?)
            LCFCC$IConnectionManager$StartServer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361634478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34361634478)
            
            //--TRIMMABLE-BOUNDARY-START(42951569070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer<TConnectionEndPoint>(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionManager$StartServer$2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951569070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42951569070)
            
            //--TRIMMABLE-BOUNDARY-START(8591830702)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Disconnect(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCFCC$IConnectionManager$Disconnect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591830702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Disconnect(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591830702)
            
            //--TRIMMABLE-BOUNDARY-START(47246536366)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Stop(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionManager$Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246536366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Stop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47246536366)
            
            //--TRIMMABLE-BOUNDARY-START(17181765294)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Interfaces.get
            get LCFCC$IConnectionManager$Interfaces()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066667182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Interfaces;
            }
            //--TRIMMABLE-BOUNDARY-END(17181765294)
            
            //--TRIMMABLE-BOUNDARY-START(25771699886)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.this[LivingThing.Core.Frameworks.Common.Connection.IConnectionContext].get
            LCFCC$IConnectionManager$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771699886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771699886)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21474996944)
                this.contextInterface = new ($.$$.SCG.Dictionary$$$($.$KuVO.LCFCC.IConnectionContext, $.$KuVO.LCFCC.IConnectionInterface))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21474996944)
                
            }
            static $h = 160464;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374342864),
    {
      "p": 1830574,
      "i": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834735312,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 160464,
      "h": 107374342864,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(107374342864),
//--TRIMMABLE-BOUNDARY-START(68719637200),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244800720,
        "f": 50331649
      },
      "n": "Interfaces",
      "d": 160464,
      "h": 68719637200,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719637200),
//--TRIMMABLE-BOUNDARY-START(73014604496),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424669904,
        "f": 50331649
      },
      "n": "LocalAddress",
      "d": 160464,
      "h": 73014604496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014604496)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769964240),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "DiscardInBuffer",
      "d": 160464,
      "h": 25769964240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769964240),
//--TRIMMABLE-BOUNDARY-START(30064931536),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Disconnect",
      "d": 160464,
      "h": 30064931536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064931536),
//--TRIMMABLE-BOUNDARY-START(94489440976),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "endpoint",
          "p": 1765038
        }
      ],
      "n": "StartServer",
      "o": "@$1",
      "d": 160464,
      "h": 94489440976,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(94489440976),
//--TRIMMABLE-BOUNDARY-START(98784408272),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": [
        "TConnectionEndPoint"
      ],
      "n": "StartServer",
      "o": "@$2",
      "d": 160464,
      "h": 98784408272,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(98784408272),
//--TRIMMABLE-BOUNDARY-START(103079375568),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "n": "Stop",
      "d": 160464,
      "h": 103079375568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079375568),
//--TRIMMABLE-BOUNDARY-START(120259244752),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "WriteRead",
      "o": "@$1",
      "d": 160464,
      "h": 120259244752,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259244752),
//--TRIMMABLE-BOUNDARY-START(34359898832),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 160464,
      "h": 34359898832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359898832),
//--TRIMMABLE-BOUNDARY-START(90194473680),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "factory",
          "p": 650926
        }
      ],
      "n": "StartServer",
      "d": 160464,
      "h": 90194473680,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194473680),
//--TRIMMABLE-BOUNDARY-START(17180029648),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ConnectTo",
      "d": 160464,
      "h": 17180029648,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180029648),
//--TRIMMABLE-BOUNDARY-START(111669310160),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "data",
          "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h
        }
      ],
      "n": "WriteAsync",
      "d": 160464,
      "h": 111669310160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669310160),
//--TRIMMABLE-BOUNDARY-START(81604539088),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream)).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "ReadAsync",
      "d": 160464,
      "h": 81604539088,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604539088),
//--TRIMMABLE-BOUNDARY-START(115964277456),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream)).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "data",
          "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "WriteRead",
      "d": 160464,
      "h": 115964277456,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964277456)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885062352),
    {
      "t": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "n": "connectionPipelines",
      "d": 160464,
      "h": 12885062352,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885062352),
//--TRIMMABLE-BOUNDARY-START(77309571792),
    {
      "t": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "n": "messagePipelines",
      "d": 160464,
      "h": 77309571792,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77309571792),
//--TRIMMABLE-BOUNDARY-START(21474996944),
    {
      "t": $.$$.SCG.Dictionary$$$($.$KuVO.LCFCC.IConnectionContext, $.$KuVO.LCFCC.IConnectionInterface).$h,
      "n": "contextInterface",
      "d": 160464,
      "h": 21474996944,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474996944),
//--TRIMMABLE-BOUNDARY-START(85899506384),
    {
      "t": 327718,
      "n": "serviceProvider",
      "d": 160464,
      "h": 85899506384,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85899506384),
//--TRIMMABLE-BOUNDARY-START(38654866128),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScopeFactory).$h,
      "n": "factories",
      "d": 160464,
      "h": 38654866128,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654866128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590095056),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "connectionPipelines",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient).$h
        },
        {
          "n": "messagePipelines",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage).$h
        },
        {
          "n": "factories",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScopeFactory).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 160464,
      "h": 8590095056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590095056)
  ],
  "h": 160464
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IClientConnectionManager, $.$KuVO.LCFCC.IConnectionManager, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Connections.ClientConnectionManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Connections${separator}ClientConnectionManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(160464)
        
        

        //--TRIMMABLE-BOUNDARY-START(750288)
        $asm.$cls(`$mVyz.LCISC.SmartDeviceSocketConnectionEndPoint`, ($self) => class SmartDeviceSocketConnectionEndPoint extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360488656)
            /*int */ get Order()
            {
                return 2147483647/*int.MaxValue*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360488656)
            
            //--TRIMMABLE-BOUNDARY-START(4295717584)
            /*ServiceFactory*/ _factory = null;
            //--TRIMMABLE-BOUNDARY-END(4295717584)
            
            //--TRIMMABLE-BOUNDARY-START(38655455952)
            /*IOTDeviceUpdateEventSubscriptionChannel*/ updateSubscriptionChannel = null;
            //--TRIMMABLE-BOUNDARY-END(38655455952)
            
            //--TRIMMABLE-BOUNDARY-START(12885652176)
            /*IEnumerable<IIOTDeviceFamily>*/ families = null;
            //--TRIMMABLE-BOUNDARY-END(12885652176)
            
            //--TRIMMABLE-BOUNDARY-START(8590684880)
            $ctor$1(/*ServiceFactory*/ factory, /*IOTDeviceUpdateEventSubscriptionChannel*/ updateSubscriptionChannel, /*IEnumerable<IIOTDeviceFamily>*/ families)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590684880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._factory = factory;
                    this.updateSubscriptionChannel = updateSubscriptionChannel;
                    this.families = families;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590684880)
            
            //--TRIMMABLE-BOUNDARY-START(25770554064)
            /*Task *//*async*/  Invoke(/*IConnectionClient*/ context, /*PipelineDelegate<IConnectionClient>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770554064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.updateSubscriptionChannel.NotifyUpdate((() =>
                    {
                        //new $.$XBGm.LCICI.IOTDeviceConnectionUpdateEventArgs()
                        const $t2 = $.$XBGm.LCICI.IOTDeviceConnectionUpdateEventArgs;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Client = context;
                        return $i2;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t3 = next.Invoke(context), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770554064)
            
            //--TRIMMABLE-BOUNDARY-START(30065521360)
            /*Task *//*async*/  Invoke$1(/*IConnectionMessage*/ context, /*PipelineDelegate<IConnectionMessage>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065521360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (context.LCFCC$IConnectionMessage$Direction === 0/*MessageDirection.In*/)
                    {
                        /*var*/ let family = $.$XBGm.LCICI.IOTDeviceFamilyExtension.GetFamily(this.families, context.LCFCC$IConnectionMessage$Client);
                        if (family !== null)
                        {
                            if (context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id.FamilyName === null)
                            {
                                throw new $.$$.S.NotImplementedException().$ctor$12("We need to set device family name");
                            }
                            /*var*/ let protocol = family.LCICI$IIOTDeviceFamily$Protocol;
                            try
                            {
                                /*var*/ let deviceMessage = $.$XBGm.LCICI.DecoderExtension.Decode(protocol.LCICI$IIOTDeviceProtocol$GetDecoder(context.LCFCC$IConnectionMessage$Client), context, null);
                                if ((deviceMessage?.LCICI$IIOTDeviceReceivedDataModel$IsValid ?? null) ?? false)
                                {
                                    let $t4, $r4;
                                    ($t4 = this.updateSubscriptionChannel.NotifyUpdate$1((() =>
                                    {
                                        //new $.$XBGm.LCICI.IOTDeviceDataUpdateEventArgs()
                                        const $t5 = $.$XBGm.LCICI.IOTDeviceDataUpdateEventArgs;
                                        const $i5 = new $t5();
                                        $i5.$ctor$2();
                                        $i5.ServiceFactory = this._factory;
                                        $i5.Data = deviceMessage;
                                        $i5.Message = context;
                                        return $i5;
                                    })()), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                }
                            }
                            catch($e)
                            {
                                if ($e instanceof $.$XBGm.LCICPE.InvalidPacketException)
                                {
                                }
                                else if ($e instanceof $.$$.S.Exception)
                                {
                                }
                                else
                                {
                                    throw $e;
                                }
                            }
                        }
                    }
                    ($t6 = next.Invoke(context), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065521360)
            
            //--TRIMMABLE-BOUNDARY-START(8590770090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>.Order.get
            get LCFCP$IPipeline$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770090)
            
            //--TRIMMABLE-BOUNDARY-START(12885737386)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>.Invoke(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>)
            LCFCP$IPipeline$$$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737386)
            
            //--TRIMMABLE-BOUNDARY-START(8590770090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>.Order.get
            get LCFCP$IPipeline$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770090)
            
            //--TRIMMABLE-BOUNDARY-START(12885737386)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>.Invoke(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>)
            LCFCP$IPipeline$$$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737386)
            
            static $h = 750288;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360488656),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475586768,
        "f": 50331649
      },
      "n": "Order",
      "d": 750288,
      "h": 34360488656,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360488656)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770554064),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1568430
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionClient).$h
        }
      ],
      "n": "Invoke",
      "d": 750288,
      "h": 25770554064,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(25770554064),
//--TRIMMABLE-BOUNDARY-START(30065521360),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1961646
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 750288,
      "h": 30065521360,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(30065521360)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295717584),
    {
      "t": 62949718,
      "n": "_factory",
      "d": 750288,
      "h": 4295717584,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295717584),
//--TRIMMABLE-BOUNDARY-START(38655455952),
    {
      "t": 30250385,
      "n": "updateSubscriptionChannel",
      "d": 750288,
      "h": 38655455952,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655455952),
//--TRIMMABLE-BOUNDARY-START(12885652176),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h,
      "n": "families",
      "d": 750288,
      "h": 12885652176,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885652176)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590684880),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "updateSubscriptionChannel",
          "p": 30250385
        },
        {
          "n": "families",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 750288,
      "h": 8590684880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590684880)
  ],
  "h": 750288
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionEndPoint, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionClient), $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.SmartDeviceSocketConnectionEndPoint`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}SmartDeviceSocketConnectionEndPoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(750288)
        
        

        //--TRIMMABLE-BOUNDARY-START(619216)
        $asm.$cls(`$mVyz.LCISC.SmartDeviceAuthenticator`, ($self) => class SmartDeviceAuthenticator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590553808)
            /*Task<bool> */ Authenticate(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590553808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(8590553808)
            
            //--TRIMMABLE-BOUNDARY-START(4320957841)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceAuthenticator<LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel>.Authenticate(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel)
            LCICI$IIOTDeviceAuthenticator$LivingThing$Core$IOT$Common$Interface$IIOTDeviceModel$Authenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4320957841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Authenticate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4320957841)
            
            //--TRIMMABLE-BOUNDARY-START(4295586512)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295586512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295586512)
            
            //--TRIMMABLE-BOUNDARY-START(4295586512)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295586512)
            
            static $h = 619216;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590553808),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337
        }
      ],
      "n": "Authenticate",
      "d": 619216,
      "h": 8590553808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590553808)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295586512),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 619216,
      "h": 4295586512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295586512)
  ],
  "h": 619216
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceAuthenticator$$($.$XBGm.LCICI.IIOTDeviceModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.SmartDeviceAuthenticator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}SmartDeviceAuthenticator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(619216)
        
        

        //--TRIMMABLE-BOUNDARY-START(1012432)
        $asm.$cls(`$mVyz.LCISCS.DeviceDiscovery`, ($self) => class DeviceDiscovery extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590947024)
            /*IEnumerable<DiscoveredIOTDevice> */ get DicoveredDevices()
            {
                return $.$sl.SL.Enumerable.Empty($.$XBGm.LCICI.DiscoveredIOTDevice);
            }
            //--TRIMMABLE-BOUNDARY-END(8590947024)
            
            //--TRIMMABLE-BOUNDARY-START(4295979728)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295979728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295979728)
            
            //--TRIMMABLE-BOUNDARY-START(1077968)
            static $_SubscriberDisposer;
            static get SubscriberDisposer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1077968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mVyz.LCISCS.DeviceDiscovery;
                return $cls.$_SubscriberDisposer ??= $asm.$ncls(`$mVyz.LCISCS.DeviceDiscovery.SubscriberDisposer`, ($self) => class SubscriberDisposer extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591012560)
                    /*Action*/ dispose = null;
                    //--TRIMMABLE-BOUNDARY-END(8591012560)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296045264)
                    $ctor$1(/*Action*/ dispose)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296045264);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.dispose = dispose;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296045264)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885979856)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885979856);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.dispose.Invoke();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885979856)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $h = 1077968;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885979856),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1077968,
      "h": 12885979856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885979856)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591012560),
    {
      "t": 43122689,
      "n": "dispose",
      "d": 1077968,
      "h": 8591012560,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591012560)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296045264),
    {
      "p": [
        {
          "n": "dispose",
          "p": 43122689
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1077968,
      "h": 4296045264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296045264)
  ],
  "d": 1012432,
  "h": 1077968
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.DeviceDiscovery+SubscriberDisposer`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}DeviceDiscovery${separator}SubscriberDisposer`; }
                }, $cls, ($v) => $cls.$_SubscriberDisposer = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1077968)
            
            //--TRIMMABLE-BOUNDARY-START(30065783504)
            /*IDisposable */ Subscribe(/*IObserver<DiscoveredIOTDevice>*/ observer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065783504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mVyz.LCISCS.DeviceDiscovery.SubscriberDisposer().$ctor$1(new $.$$.S.Action().$ctor(this,  () =>
                {
                }, $abBxrh ??= {"r":65537,"n":"","d":1012432,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(30065783504)
            
            //--TRIMMABLE-BOUNDARY-START(21475848912)
            /*void */ Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475848912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475848912)
            
            //--TRIMMABLE-BOUNDARY-START(25770816208)
            /*void */ Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770816208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770816208)
            
            //--TRIMMABLE-BOUNDARY-START(17206515089)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceDiscovery.Start()
            LCICI$IIOTDeviceDiscovery$Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17206515089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Start(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17206515089)
            
            //--TRIMMABLE-BOUNDARY-START(21501482385)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceDiscovery.Stop()
            LCICI$IIOTDeviceDiscovery$Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21501482385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Stop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21501482385)
            
            //--TRIMMABLE-BOUNDARY-START(12911547793)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceDiscovery.DicoveredDevices.get
            get LCICI$IIOTDeviceDiscovery$DicoveredDevices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4321613201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DicoveredDevices;
            }
            //--TRIMMABLE-BOUNDARY-END(12911547793)
            
            //--TRIMMABLE-BOUNDARY-START(4392091649)
            //Generated interface implemetation for System.IObservable<LivingThing.Core.IOT.Common.Interface.DiscoveredIOTDevice>.Subscribe(System.IObserver<LivingThing.Core.IOT.Common.Interface.DiscoveredIOTDevice>)
            S$IObservable$LivingThing$Core$IOT$Common$Interface$DiscoveredIOTDevice$Subscribe()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392091649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Subscribe(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392091649)
            
            //--TRIMMABLE-BOUNDARY-START(4295979728)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295979728)
            
            static $h = 1012432;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590947024),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.DiscoveredIOTDevice).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180881616,
        "f": 50331649
      },
      "n": "DicoveredDevices",
      "d": 1012432,
      "h": 8590947024,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590947024)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065783504),
    {
      "r": 91095041,
      "p": [
        {
          "n": "observer",
          "p": $.$$.S.IObserver$$($.$XBGm.LCICI.DiscoveredIOTDevice).$h
        }
      ],
      "n": "Subscribe",
      "d": 1012432,
      "h": 30065783504,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065783504),
//--TRIMMABLE-BOUNDARY-START(21475848912),
    {
      "r": 65537,
      "n": "Start",
      "d": 1012432,
      "h": 21475848912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475848912),
//--TRIMMABLE-BOUNDARY-START(25770816208),
    {
      "r": 65537,
      "n": "Stop",
      "d": 1012432,
      "h": 25770816208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770816208)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295979728),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1012432,
      "h": 4295979728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295979728)
  ],
  "h": 1012432
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDiscovery, $.$$.S.IObservable$$($.$XBGm.LCICI.DiscoveredIOTDevice) ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mVyz.LCISCS.DeviceDiscovery.SubscriberDisposer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Stubs.DeviceDiscovery`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Stubs${separator}DeviceDiscovery`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1012432)
        
        

        //--TRIMMABLE-BOUNDARY-START(357072)
        $asm.$cls(`$mVyz.LCISCC.RemoteServerConnectionClient`, ($self) => class RemoteServerConnectionClient extends $.$KuVO.LCFCC.ConnectionClient
        {
            //--TRIMMABLE-BOUNDARY-START(4295324368)
            $ctor$3(/*IConnectionInterface*/ _interface, /*IConnectionClient*/ parentClient)
            {
                super.$ctor$2(_interface, parentClient);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295324368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295324368)
            
            static $h = 357072;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$KuVO.LCFCC.ConnectionClient; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295324368),
    {
      "p": [
        {
          "n": "_interface",
          "p": 1830574
        },
        {
          "n": "parentClient",
          "p": 1568430,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 357072,
      "h": 4295324368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295324368)
  ],
  "h": 357072
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionClient, $.$fPer.LCFCD.IWorkspace ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.Connections.RemoteServerConnectionClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}Connections${separator}RemoteServerConnectionClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(357072)
        
        

        //--TRIMMABLE-BOUNDARY-START(422608)
        $asm.$cls(`$mVyz.LCISCD.iSmartDatabase`, ($self) => class iSmartDatabase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85899768528)
            /*ValueTask<IDictionary<DateTime, IDictionary<int, double>>> */ GetAllAsync(/*IIOTDeviceModel*/ device, /*DateTime?*/ startDate, /*DateTime?*/ endDate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899768528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(85899768528)
            
            //--TRIMMABLE-BOUNDARY-START(128849441488)
            /*ValueTask<IDictionary<int, double>> */ GetLastAsync(/*IIOTDeviceModel*/ device, /*out DateTime*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849441488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(128849441488)
            
            //--TRIMMABLE-BOUNDARY-START(244813558480)
            /*ValueTask */ SaveAsync(/*IIOTDeviceModel*/ device, /*IEnumerable<KeyValuePair<int, double>>*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813558480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(244813558480)
            
            //--TRIMMABLE-BOUNDARY-START(176094081744)
            /*ValueTask *//*async*/  LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTServiceModel$DeleteAsync(/*IOTServiceModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094081744);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$XBGm.LCICM.IOTServiceModel, this.Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTServiceModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176094081744)
            
            //--TRIMMABLE-BOUNDARY-START(180389049040)
            /*ValueTask<IEnumerable<IOTServiceModel>> *//*async*/  LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTServiceModel$GetAllAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel), async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389049040);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, (($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTServiceModel, this.Server, $.$fPer.LCFCD.DataFilter.Default, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).Data);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(180389049040)
            
            //--TRIMMABLE-BOUNDARY-START(206158852816)
            /*ValueTask<IOTServiceModel> *//*async*/  LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Models$IOTServiceModel$GetByIdAsync(/*object*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTServiceModel), $.$XBGm.LCICM.IOTServiceModel, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206158852816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$XBGm.LCICM.IOTServiceModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(id, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206158852816)
            
            //--TRIMMABLE-BOUNDARY-START(184684016336)
            /*ValueTask *//*async*/  LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTServiceModel$SaveAsync(/*IOTServiceModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684016336);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$XBGm.LCICM.IOTServiceModel, this.Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTServiceModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(184684016336)
            
            //--TRIMMABLE-BOUNDARY-START(150324277968)
            /*ValueTask *//*async*/  LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneActionModel$DeleteAsync(/*IOTSceneActionModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324277968);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$XBGm.LCICM.IOTSceneActionModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneActionModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.RemoveCache($.$XBGm.LCICM.IOTSceneActionModel, item);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150324277968)
            
            //--TRIMMABLE-BOUNDARY-START(154619245264)
            /*ValueTask<IEnumerable<IOTSceneActionModel>> */ LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneActionModel$GetAllAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619245264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllFromCache($.$XBGm.LCICM.IOTSceneActionModel, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneActionModel))))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneActionModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneActionModel), async ($asnycContext) => 
                    {
                        let $t6, $r6;
                        /*var*/ let t = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTSceneActionModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, t.AsEnumerable());
                    });
                }, $xfrShf ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneActionModel)).$h,"n":"","d":422608,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(154619245264)
            
            //--TRIMMABLE-BOUNDARY-START(193273950928)
            /*ValueTask<IOTSceneActionModel> *//*async*/  LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Models$IOTSceneActionModel$GetByIdAsync(/*object*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneActionModel), $.$XBGm.LCICM.IOTSceneActionModel, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193273950928);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t7 = this.GetFromCache($.$XBGm.LCICM.IOTSceneActionModel, id, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneActionModel)))().$ctor(this,  () =>
                    {
                        return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$XBGm.LCICM.IOTSceneActionModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$22($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null), null);
                    }, $GjGuti ??= {"r":$.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneActionModel).$h,"n":"","d":422608,"h":0,"f":17825794}), null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(193273950928)
            
            //--TRIMMABLE-BOUNDARY-START(257698460368)
            /*ValueTask *//*async*/  SaveAsync$3(/*IOTSceneActionModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257698460368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$XBGm.LCICM.IOTSceneActionModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneActionModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(257698460368)
            
            //--TRIMMABLE-BOUNDARY-START(201863885520)
            /*ValueTask<IOTSceneTriggerModel> *//*async*/  LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Models$IOTSceneTriggerModel$GetByIdAsync(/*object*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneTriggerModel), $.$XBGm.LCICM.IOTSceneTriggerModel, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201863885520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t9 = this.GetFromCache($.$XBGm.LCICM.IOTSceneTriggerModel, id, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneTriggerModel)))().$ctor(this,  () =>
                    {
                        return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$XBGm.LCICM.IOTSceneTriggerModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), null)), null);
                    }, $pgaSse ??= {"r":$.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneTriggerModel).$h,"n":"","d":422608,"h":0,"f":17825794}), null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201863885520)
            
            //--TRIMMABLE-BOUNDARY-START(167504147152)
            /*ValueTask *//*async*/  LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneTriggerModel$DeleteAsync(/*IOTSceneTriggerModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504147152);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t10 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$XBGm.LCICM.IOTSceneTriggerModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneTriggerModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    this.RemoveCache($.$XBGm.LCICM.IOTSceneTriggerModel, item);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504147152)
            
            //--TRIMMABLE-BOUNDARY-START(171799114448)
            /*ValueTask<IEnumerable<IOTSceneTriggerModel>> */ LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneTriggerModel$GetAllAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799114448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllFromCache($.$XBGm.LCICM.IOTSceneTriggerModel, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneTriggerModel))))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneTriggerModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneTriggerModel), async ($asnycContext) => 
                    {
                        let $t11, $r11;
                        /*var*/ let m = ($t11 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTSceneTriggerModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), null), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, m.AsEnumerable());
                    });
                }, $kGsikg ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneTriggerModel)).$h,"n":"","d":422608,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(171799114448)
            
            //--TRIMMABLE-BOUNDARY-START(266288394960)
            /*ValueTask *//*async*/  SaveAsync$5(/*IOTSceneTriggerModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266288394960);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t12 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$XBGm.LCICM.IOTSceneTriggerModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneTriggerModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(266288394960)
            
            //--TRIMMABLE-BOUNDARY-START(274878329552)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(274878329552)
            
            //--TRIMMABLE-BOUNDARY-START(38655128272)
            /*IAuthenticationService*/ authManager = null;
            //--TRIMMABLE-BOUNDARY-END(38655128272)
            
            //--TRIMMABLE-BOUNDARY-START(12885324496)
            $ctor$1(/*IServerRemoteService*/ server, /*IAuthenticationService*/ authManager)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885324496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.authManager = authManager;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885324496)
            
            //--TRIMMABLE-BOUNDARY-START(488144)
            static $_CacheOfType$$;
            static CacheOfType$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(488144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mVyz.LCISCD.iSmartDatabase;
                return ($cls.$_CacheOfType$$ ??= $asm.$ncls(`$mVyz.LCISCD.iSmartDatabase.CacheOfType<>`, (T) => $asm.$gt(`$mVyz.LCISCD.iSmartDatabase.CacheOfType<>`, [T], ($self) => class CacheOfType$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21475324624)
                    /*bool*/ CachedAll = false;
                    //--TRIMMABLE-BOUNDARY-END(21475324624)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540095696)
                    /*Task<IEnumerable<T>>?*/ GetAll = null;
                    //--TRIMMABLE-BOUNDARY-END(51540095696)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014932176)
                    /*ConcurrentDictionary<string, T>*/ Value = null;
                    //--TRIMMABLE-BOUNDARY-END(73014932176)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180357328)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180357328);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180357328)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180357328)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180357328)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(73014932176)
                        this.Value = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, T))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(73014932176)
                        
                    }
                    static $H = 488144;
                    static $h = 488144;
                    static $g = 1;
                    static $f = 0b10000000001010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475324624),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30065259216,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 60130030288,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83886081
      },
      "n": "CachedAll",
      "d": this.$h,
      "H": 21475324624,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475324624),
//--TRIMMABLE-BOUNDARY-START(51540095696),
    {
      "p": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(T)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38655193808,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 68719964880,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 83886081
      },
      "n": "GetAll",
      "d": this.$h,
      "H": 51540095696,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540095696),
//--TRIMMABLE-BOUNDARY-START(73014932176),
    {
      "p": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47245128400,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "H": 73014932176,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014932176)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180357328),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17180357328,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180357328)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [17533270
      ]
    }
  ],
  "r": 1,
  "d": 422608,
  "H": 488144,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.DataStore.iSmartDatabase+CacheOfType<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}DataStore${separator}iSmartDatabase${separator}CacheOfType$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_CacheOfType$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(488144)
            
            //--TRIMMABLE-BOUNDARY-START(42950095568)
            /*ConcurrentDictionary<Type, object>*/ caches = null;
            //--TRIMMABLE-BOUNDARY-END(42950095568)
            
            //--TRIMMABLE-BOUNDARY-START(111669572304)
            /*CacheOfType<T> */ GetCache(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669572304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*var*/ let _caches = $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$$.S.Object), this.caches, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$$.S.Object), $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                        {
                            return T.$type.IsAssignableFrom(c.Key);
                        }, $UdKsVj ??= {"r":262145,"p":[{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$$.S.Object).$h}],"n":"","d":422608,"h":0,"f":17825794}));
                        if ($.$sl.SL.Enumerable.Any$1($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$$.S.Object), _caches))
                        {
                        }
                        /*CacheOfType<T>*/ let cache;
                        if (this.caches.ContainsKey(T.$type))
                        {
                            cache = $.$cast(this.caches.get_Item$1(T.$type), $.$mVyz.LCISCD.iSmartDatabase.CacheOfType$$(T));
                        }
                        else 
                        {
                            cache = new ($.$mVyz.LCISCD.iSmartDatabase.CacheOfType$$(T))().$ctor$1();
                            this.caches.set_Item$1(T.$type, cache);
                        }
                        return cache;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669572304)
            
            //--TRIMMABLE-BOUNDARY-START(30065193680)
            /*void */ AddToCache(T, /*T*/ val)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065193680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*CacheOfType<T>*/ let cache = this.GetCache(T);
                        cache.Value.set_Item$1(val.LCFCD$IIded$Identifier.ToString(), val);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065193680)
            
            //--TRIMMABLE-BOUNDARY-START(223338722000)
            /*void */ RemoveCache(T, /*T*/ val)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338722000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*CacheOfType<T>*/ let cache = this.GetCache(T);
                        /*T*/ let v;
                        cache.Value.TryRemove$1(val.LCFCD$IIded$Identifier.ToString(), $.$ref(() => v, ($v) => v = $v, T));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338722000)
            
            //--TRIMMABLE-BOUNDARY-START(124554474192)
            /*T */ GetFromCache$1(T, /*object*/ id, /*Func<T>*/ create)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554474192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*CacheOfType<T>*/ let cache = this.GetCache(T);
                        /*T*/ let value;
                        cache.Value.TryGetValue($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, T));
                        if (value !== null)
                        {
                            return value;
                        }
                        value = create.Invoke();
                        cache.Value.set_Item$1($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), value);
                        return value;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554474192)
            
            //--TRIMMABLE-BOUNDARY-START(120259506896)
            /*ValueTask<T?> */ GetFromCache(T, /*object*/ id, /*Func<ValueTask<T?>>*/ get, /*Func<T, bool>?*/ idComparator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259506896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*CacheOfType<T>*/ let cache = this.GetCache(T);
                        /*T?*/ let value;
                        if (idComparator === null)
                        {
                            cache.Value.TryGetValue($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => value, ($v) => value = $v, T));
                        }
                        else 
                        {
                            value = $.$sl.SL.Enumerable.FirstOrDefault$1(T, cache.Value.Values, new ($.$$.S.Func$$$(T, $.$$.S.Boolean))().$ctor(this,  (/*val*/ val) =>
                            {
                                /*Guid*/ let guid;
                                /*bool*/ let isGuid = $.$$.S.Guid.TryParse$4($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), $.$ref(() => guid, ($v) => guid = $v, $.$$.S.Guid));
                                /*string?*/ let __ca1__;
                                return (((__ca1__ = val.LCFCD$IIded$Identifier.ToString()) !== null ? $.$$.S.String.Equals$5.call(__ca1__, $.$dsp(id, $.$$.S.Object, ($t) => $t.ToString)) : false)) || idComparator.Invoke(val);
                            }, $sphQJe ??= {"r":262145,"p":[{"n":"val","p":(T) => T.$h}],"n":"","d":422608,"h":0,"f":17825794}));
                        }
                        if (value !== null)
                        {
                            return $.$$.STT.ValueTask.FromResult(T, value);
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
                return new ($.$$.STT.ValueTask$$(T))().$ctor$5(get.Invoke().AsTask().ContinueWith$47(T, new ($.$$.S.Func$$$($.$$.STT.Task$$(T), T))().$ctor(this,  (/*task*/ task) =>
                {
                    //lock(this)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this)
                        {
                            /*CacheOfType<T>*/ let cache = this.GetCache(T);
                            /*T?*/ let val = task.Result;
                            if (val !== null)
                            {
                                cache.Value.set_Item$1(val.LCFCD$IIded$Identifier.ToString(), val);
                            }
                            return val;
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this)
                    }
                }, $JGKKlc ??= {"r":(T) => T.$h,"p":[{"n":"task","p":(T) => $.$$.STT.Task$$(T).$h}],"n":"","d":422608,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(120259506896)
            
            //--TRIMMABLE-BOUNDARY-START(98784670416)
            /*ValueTask<IEnumerable<T>> */ GetAllFromCache(T, /*Func<ValueTask<IEnumerable<T>>>*/ get)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784670416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*CacheOfType<T>*/ let cache = this.GetCache(T);
                        if (cache.CachedAll)
                        {
                            return $.$$.STT.ValueTask.FromResult($.$$.SCG.IEnumerable$$(T), cache.Value.Values);
                        }
                        if (cache.GetAll !== null)
                        {
                            return new ($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)))().$ctor$5(cache.GetAll);
                        }
                        cache.GetAll = get.Invoke().AsTask();
                        return new ($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)))().$ctor$5(cache.GetAll.ContinueWith$47($.$$.SCG.IEnumerable$$(T), new ($.$$.S.Func$$$($.$$.STT.Task$$($.$$.SCG.IEnumerable$$(T)), $.$$.SCG.IEnumerable$$(T)))().$ctor(this,  (/*task*/ task) =>
                        {
                            //lock(this)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this)
                                {
                                    /*var*/ let list = task.Result;
                                    /*var*/ let existingCache = $.$sl.SL.Enumerable.ToList(T, cache.Value.Values);
                                    /*var*/ let $new = $.$sl.SL.Enumerable.ToArray(T, $.$sl.SL.Enumerable.Except$1(T, list, existingCache));
                                    existingCache.AddRange($new);
                                    list = existingCache;
                                    cache = (() =>
                                    {
                                        //new $.$mVyz.LCISCD.iSmartDatabase.CacheOfType$$(T)()
                                        const $t17 = $.$mVyz.LCISCD.iSmartDatabase.CacheOfType$$(T);
                                        const $i17 = new $t17();
                                        $i17.$ctor$1();
                                        $i17.CachedAll = true;
                                        return $i17;
                                    })();
                                    let $en18 = list.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en18.SC$1$IEnumerator$MoveNext())
                                    {
                                        let l = $en18.SCG$IEnumerator$$$Current;
                                        {
                                            cache.Value.set_Item$1(l.LCFCD$IIded$Identifier.ToString(), l);
                                        }
                                    }
                                    this.caches.set_Item$1(T.$type, cache);
                                    return cache.Value.Values;
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this)
                            }
                        }, $melcvh ??= {"r":(T) => $.$$.SCG.IEnumerable$$(T).$h,"p":[{"n":"task","p":(T) => $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(T)).$h}],"n":"","d":422608,"h":0,"f":17825794})));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784670416)
            
            //--TRIMMABLE-BOUNDARY-START(163209179856)
            /*ValueTask<IEnumerable<IOTSceneModel>> */ LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneModel$GetAllAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209179856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllFromCache($.$XBGm.LCICM.IOTSceneModel, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneModel))))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneModel), async ($asnycContext) => 
                    {
                        let $t19, $r19;
                        /*var*/ let t = ($t19 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTSceneModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), null), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, t.AsEnumerable());
                    });
                }, $TBvWYh ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneModel)).$h,"n":"","d":422608,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(163209179856)
            
            //--TRIMMABLE-BOUNDARY-START(197568918224)
            /*ValueTask<IOTSceneModel> *//*async*/  LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Models$IOTSceneModel$GetByIdAsync(/*object*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneModel), $.$XBGm.LCICM.IOTSceneModel, async ($asnycContext) => 
                {
                    let $t20, $r20;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197568918224);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t20 = this.GetFromCache($.$XBGm.LCICM.IOTSceneModel, id, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneModel)))().$ctor(this,  () =>
                    {
                        return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$XBGm.LCICM.IOTSceneModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), null)), null);
                    }, $rKMqsi ??= {"r":$.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTSceneModel).$h,"n":"","d":422608,"h":0,"f":17825794}), null), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197568918224)
            
            //--TRIMMABLE-BOUNDARY-START(34360160976)
            /*ValueTask *//*async*/  AddTrigger(/*IOTSceneModel*/ scene, /*IOTSceneTriggerModel*/ trigger)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t21, $r21;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360160976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    trigger = $.$sl.SL.Enumerable.First$1($.$XBGm.LCICM.IOTSceneTriggerModel, (($t21 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$XBGm.LCICM.IOTSceneTriggerModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scene.Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneTriggerModel), [ trigger ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)))).AsEnumerable());
                    this.AddToCache($.$XBGm.LCICM.IOTSceneModel, scene);
                    this.AddToCache($.$XBGm.LCICM.IOTSceneTriggerModel, trigger);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360160976)
            
            //--TRIMMABLE-BOUNDARY-START(137439376080)
            /*ValueTask<IEnumerable<IOTSceneTriggerModel>> *//*async*/  GetTriggers(/*IOTSceneModel*/ scene)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneTriggerModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneTriggerModel), async ($asnycContext) => 
                {
                    let $t22, $r22;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439376080);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let t = ($t22 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTSceneTriggerModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$21($.$dspc(scene.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString), 1, 2147483647/*int.MaxValue*/), null), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, t.AsEnumerable());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137439376080)
            
            //--TRIMMABLE-BOUNDARY-START(81604801232)
            /*ValueTask<IEnumerable<IOTSceneActionModel>> *//*async*/  GetActions(/*IOTSceneModel*/ scene)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneActionModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneActionModel), async ($asnycContext) => 
                {
                    let $t23, $r23;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604801232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let t = ($t23 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTSceneActionModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$21($.$dspc(scene.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString), 1, 2147483647/*int.MaxValue*/), null), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, t.AsEnumerable());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81604801232)
            
            //--TRIMMABLE-BOUNDARY-START(17180291792)
            /*ValueTask *//*async*/  AddAction(/*IOTSceneModel*/ scene, /*IOTSceneActionModel*/ action)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t24, $r24;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180291792);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t24 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$XBGm.LCICM.IOTSceneActionModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scene.Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneActionModel), [ action ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180291792)
            
            //--TRIMMABLE-BOUNDARY-START(236223623888)
            /*ValueTask *//*async*/  RemoveTrigger(/*IOTSceneModel*/ scene, /*IOTSceneTriggerModel*/ trigger)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t25, $r25;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236223623888);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t25 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$XBGm.LCICM.IOTSceneTriggerModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scene.Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneTriggerModel), [ trigger ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(236223623888)
            
            //--TRIMMABLE-BOUNDARY-START(219043754704)
            /*ValueTask *//*async*/  RemoveAction(/*IOTSceneModel*/ scene, /*IOTSceneActionModel*/ action)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t26, $r26;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219043754704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t26 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$XBGm.LCICM.IOTSceneActionModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scene.Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneActionModel), [ action ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(219043754704)
            
            //--TRIMMABLE-BOUNDARY-START(158914212560)
            /*ValueTask *//*async*/  LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneModel$DeleteAsync(/*IOTSceneModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t27, $r27;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914212560);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t27 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$XBGm.LCICM.IOTSceneModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914212560)
            
            //--TRIMMABLE-BOUNDARY-START(261993427664)
            /*ValueTask *//*async*/  SaveAsync$4(/*IOTSceneModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t28, $r28;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261993427664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t28 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$XBGm.LCICM.IOTSceneModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneModel), [ item ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t28, { set $v($v) { $r28 = $v; } }) ? $r28 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t28)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(261993427664)
            
            //--TRIMMABLE-BOUNDARY-START(210453820112)
            /*ValueTask<IEnumerable<TDeviceModel>> *//*async*/  LCICD$ISmartDataStoreT$$$GetAllAsync(TDeviceModel)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceModel)), $.$$.SCG.IEnumerable$$(TDeviceModel), async ($asnycContext) => 
                {
                    let $t29, $r29;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210453820112);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let values = ($t29 = this.GetAllFromCache($.$XBGm.LCICM.IOTDeviceModel, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel))))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel), async ($asnycContext) => 
                        {
                            let $t30, $r30;
                            return $.$$.N.AsyncResolver.Result($asnycContext, (($t30 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTDeviceModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), null), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30)))).AsEnumerable() ?? $.$sl.SL.Enumerable.Empty($.$XBGm.LCICM.IOTDeviceModel));
                        });
                    }, $uJLUUd ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel)).$h,"n":"","d":422608,"h":0,"f":17829890})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t29, { set $v($v) { $r29 = $v; } }) ? $r29 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t29)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.ToArray(TDeviceModel, $.$sl.SL.Enumerable.Select$1($.$XBGm.LCICM.IOTDeviceModel, TDeviceModel, values, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTDeviceModel, TDeviceModel))().$ctor(this,  (/*v*/ v) =>
                    {
                        return $.$XBGm.LCIC.UtilityExtension.Convert$2(TDeviceModel, v);
                    }, $aiNSQa ??= {"r":(TDeviceModel) => TDeviceModel.$h,"p":[{"n":"v","p":37459345}],"n":"","d":422608,"h":0,"f":17825794}))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(210453820112)
            
            //--TRIMMABLE-BOUNDARY-START(103079637712)
            /*ValueTask<IIOTDeviceModel?> *//*async*/  GetByIdAsync(/*object*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$XBGm.LCICI.IIOTDeviceModel), $.$XBGm.LCICI.IIOTDeviceModel, async ($asnycContext) => 
                {
                    let $t31, $r31;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079637712);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*IDeviceStore*/ let dStore = this;
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t31 = dStore.LCICD$ISmartDataStoreT$$$GetByIdAsync($.$XBGm.LCICI.IIOTDeviceModel, id), ($.$$.N.AsyncResolver.IsCompleted($t31, { set $v($v) { $r31 = $v; } }) ? $r31 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t31))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103079637712)
            
            //--TRIMMABLE-BOUNDARY-START(107374605008)
            /*ValueTask<TDeviceModel?> *//*async*/  GetByIdAsync$1(TDeviceModel, /*object*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TDeviceModel), TDeviceModel, async ($asnycContext) => 
                {
                    let $t32, $r32;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374605008);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let value = ($t32 = this.GetFromCache($.$XBGm.LCICM.IOTDeviceModel, id, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTDeviceModel)))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTDeviceModel), $.$XBGm.LCICM.IOTDeviceModel, async ($asnycContext) => 
                        {
                            let $t33, $r33;
                            return $.$$.N.AsyncResolver.Result($asnycContext, ($t33 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.TryReadSingle($.$XBGm.LCICM.IOTDeviceModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), null)), null), ($.$$.N.AsyncResolver.IsCompleted($t33, { set $v($v) { $r33 = $v; } }) ? $r33 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t33))));
                        });
                    }, $DzWKbi ??= {"r":$.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTDeviceModel).$h,"n":"","d":422608,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/*device*/ device) =>
                    {
                        /*LivingThing.Core.IOT.Common.Models.IOTDeviceModel*/ let __ca1__;
                        /*string*/ let __ca2__;
                        return ((__ca1__ = device) !== null ? ((__ca2__ = __ca1__.UniqueId) !== null ? $.$$.S.String.Equals$5.call(__ca2__, $.$dsp(id, $.$$.S.Object, ($t) => $t.ToString)) : false) : false);
                    }, $wvNLJa ??= {"r":262145,"p":[{"n":"device","p":37459345}],"n":"","d":422608,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t32, { set $v($v) { $r32 = $v; } }) ? $r32 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t32)));
                    if (value !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$XBGm.LCIC.UtilityExtension.Convert$2(TDeviceModel, value));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(TDeviceModel));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107374605008)
            
            //--TRIMMABLE-BOUNDARY-START(51540030160)
            /*ValueTask *//*async*/  Delete(T, /*T*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t34, $r34;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540030160);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t34 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [ device ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t34, { set $v($v) { $r34 = $v; } }) ? $r34 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t34)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51540030160)
            
            //--TRIMMABLE-BOUNDARY-START(55834997456)
            /*ValueTask *//*async*/  DeleteAsync(/*IIOTDeviceModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t35, $r35;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834997456);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t35 = this.Delete(T, item), ($.$$.N.AsyncResolver.IsCompleted($t35, { set $v($v) { $r35 = $v; } }) ? $r35 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t35)));
                    this.RemoveCache($.$XBGm.LCICI.IIOTDeviceModel, item);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55834997456)
            
            //--TRIMMABLE-BOUNDARY-START(240518591184)
            /*ValueTask *//*async*/  Save(T, /*T*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t36, $r36;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240518591184);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let t = $.$sl.SL.Enumerable.Single$1(T, (($t36 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CreateOrUpdate(T, this.Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [ device ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t36, { set $v($v) { $r36 = $v; } }) ? $r36 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t36)))).Data);
                    (device).Identifier = t.LCFCD$IIded$Identifier;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(240518591184)
            
            //--TRIMMABLE-BOUNDARY-START(249108525776)
            /*ValueTask *//*async*/  SaveAsync$1(/*IIOTDeviceModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t37, $r37;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249108525776);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t37 = this.Save(T, item), ($.$$.N.AsyncResolver.IsCompleted($t37, { set $v($v) { $r37 = $v; } }) ? $r37 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t37)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(249108525776)
            
            //--TRIMMABLE-BOUNDARY-START(68719899344)
            /*AuthenticationClientDescriptor?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(68719899344)
            
            //--TRIMMABLE-BOUNDARY-START(47245062864)
            /*ValueTask *//*async*/  CreateDevice(T, /*IIOTDeviceScopeModel*/ scope, /*T*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t38, $r38;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245062864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    (device).ServiceId = scope.LCICM$IIOTDeviceScopeModel$ServiceId;
                    /*var*/ let t = $.$sl.SL.Enumerable.Single$1(T, (($t38 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CreateOrUpdate(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scope.LCFCD$IIded$Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [ device ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t38, { set $v($v) { $r38 = $v; } }) ? $r38 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t38)))).Data);
                    (device).Identifier = t.LCFCD$IIded$Identifier;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47245062864)
            
            //--TRIMMABLE-BOUNDARY-START(21475259088)
            /*ValueTask *//*async*/  AddDevices(/*IIOTDeviceScopeModel*/ scope, /*params IIOTDeviceModel[]*/ devices)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475259088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $i39 = 0;
                    let $arr39 = devices;
                    while ($i39 < $arr39.length)
                    {
                        let $t40, $r40;
                        let device = $arr39[$i39++];
                        ($t40 = this.CreateDevice(T, scope, device), ($.$$.N.AsyncResolver.IsCompleted($t40, { set $v($v) { $r40 = $v; } }) ? $r40 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t40)));
                        this.AddToCache($.$XBGm.LCICI.IIOTDeviceModel, device);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475259088)
            
            //--TRIMMABLE-BOUNDARY-START(25770226384)
            /*ValueTask *//*async*/  AddScene(/*IIOTDeviceScopeModel*/ scope, /*IOTSceneModel*/ scene)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770226384);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (scene.Identifier.Empty || !$.$$.S.String.IsNullOrEmpty(scene.Identifier.Type))
                    {
                        let $t41, $r41;
                        /*ISceneStore*/ let dStore = this;
                        scene.ScopeId = scope.LCFCD$IIded$Identifier;
                        ($t41 = dStore.LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneModel$SaveAsync(scene).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t41, { set $v($v) { $r41 = $v; } }) ? $r41 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t41)));
                        this.AddToCache($.$XBGm.LCICM.IOTSceneModel, scene);
                    }
                    else 
                    {
                        let $t42, $r42;
                        scene = $.$sl.SL.Enumerable.First$1($.$XBGm.LCICM.IOTSceneModel, (($t42 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$XBGm.LCICM.IOTSceneModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scope.LCFCD$IIded$Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneModel), [ scene ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t42, { set $v($v) { $r42 = $v; } }) ? $r42 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t42)))).AsEnumerable());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770226384)
            
            //--TRIMMABLE-BOUNDARY-START(64424932048)
            /*ValueTask *//*async*/  DeleteScope(T, /*T*/ t)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t43, $r43;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424932048);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t43 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [ t ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t43, { set $v($v) { $r43 = $v; } }) ? $r43 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t43)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64424932048)
            
            //--TRIMMABLE-BOUNDARY-START(60129964752)
            /*ValueTask *//*async*/  DeleteAsync$1(/*IIOTDeviceScopeModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t44, $r44;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129964752);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t44 = this.DeleteScope(T, item), ($.$$.N.AsyncResolver.IsCompleted($t44, { set $v($v) { $r44 = $v; } }) ? $r44 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t44)));
                    this.RemoveCache($.$XBGm.LCICM.IIOTDeviceScopeModel, item);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60129964752)
            
            //--TRIMMABLE-BOUNDARY-START(94489703120)
            /*ValueTask<IEnumerable<TDeviceScopeModel>> *//*async*/  GetAllAsync$2(TDeviceScopeModel, /*IIOTDeviceScopeFactory*/ factory)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceScopeModel)), $.$$.SCG.IEnumerable$$(TDeviceScopeModel), async ($asnycContext) => 
                {
                    let $t45, $r45;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489703120);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let values = ($t45 = this.GetAllFromCache($.$XBGm.LCICM.IOTDeviceScopeModel, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel))))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel), async ($asnycContext) => 
                        {
                            let $t46, $r46;
                            return $.$$.N.AsyncResolver.Result($asnycContext, (($t46 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTDeviceScopeModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), null), ($.$$.N.AsyncResolver.IsCompleted($t46, { set $v($v) { $r46 = $v; } }) ? $r46 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t46)))).AsEnumerable() ?? $.$sl.SL.Enumerable.Empty($.$XBGm.LCICM.IOTDeviceScopeModel));
                        });
                    }, $NGOitc ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel)).$h,"n":"","d":422608,"h":0,"f":17829890})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t45, { set $v($v) { $r45 = $v; } }) ? $r45 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t45)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.ToArray(TDeviceScopeModel, $.$sl.SL.Enumerable.Select$1($.$XBGm.LCICM.IOTDeviceScopeModel, TDeviceScopeModel, values, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTDeviceScopeModel, TDeviceScopeModel))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$XBGm.LCIC.UtilityExtension.Convert$3(TDeviceScopeModel, m);
                    }, $KXhNlj ??= {"r":(TDeviceScopeModel) => TDeviceScopeModel.$h,"p":[{"n":"m","p":38638993}],"n":"","d":422608,"h":0,"f":17825794}))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94489703120)
            
            //--TRIMMABLE-BOUNDARY-START(90194735824)
            /*ValueTask<IEnumerable<TConcrete>> *//*async*/  GetAllAsync$1(TConcrete)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TConcrete)), $.$$.SCG.IEnumerable$$(TConcrete), async ($asnycContext) => 
                {
                    let $t47, $r47;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194735824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let values = ($t47 = this.GetAllFromCache($.$XBGm.LCICM.IOTDeviceScopeModel, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel))))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel), async ($asnycContext) => 
                        {
                            let $t48, $r48;
                            return $.$$.N.AsyncResolver.Result($asnycContext, (($t48 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTDeviceScopeModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), null), ($.$$.N.AsyncResolver.IsCompleted($t48, { set $v($v) { $r48 = $v; } }) ? $r48 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t48)))).AsEnumerable() ?? $.$sl.SL.Enumerable.Empty($.$XBGm.LCICM.IOTDeviceScopeModel));
                        });
                    }, $REfAvg ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel)).$h,"n":"","d":422608,"h":0,"f":17829890})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t47, { set $v($v) { $r47 = $v; } }) ? $r47 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t47)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.ToArray(TConcrete, $.$sl.SL.Enumerable.Select$1($.$XBGm.LCICM.IOTDeviceScopeModel, TConcrete, values, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTDeviceScopeModel, TConcrete))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$XBGm.LCIC.UtilityExtension.Convert$3(TConcrete, m);
                    }, $qybqqj ??= {"r":(TConcrete) => TConcrete.$h,"p":[{"n":"m","p":38638993}],"n":"","d":422608,"h":0,"f":17825794}))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90194735824)
            
            //--TRIMMABLE-BOUNDARY-START(214748787408)
            /*ValueTask<TConcrete> *//*async*/  LCICD$ISmartDataStoreT$$$GetByIdAsync(TConcrete, /*object*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TConcrete), TConcrete, async ($asnycContext) => 
                {
                    let $t49, $r49;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748787408);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let m = ($t49 = this.GetFromCache($.$XBGm.LCICM.IOTDeviceScopeModel, id, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTDeviceScopeModel)))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTDeviceScopeModel), $.$XBGm.LCICM.IOTDeviceScopeModel, async ($asnycContext) => 
                        {
                            let $t50, $r50;
                            let did;
                            return $.$$.N.AsyncResolver.Result($asnycContext, ($t50 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$XBGm.LCICM.IOTDeviceScopeModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12($.$is(id, $.$fPer.LCFCD.DataId, { set $v($v){ did = $v; } }) ? did : new $.$fPer.LCFCD.DataId().$ctor$3($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), null)), null), ($.$$.N.AsyncResolver.IsCompleted($t50, { set $v($v) { $r50 = $v; } }) ? $r50 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t50))));
                        });
                    }, $idMtQh ??= {"r":$.$$.STT.ValueTask$$($.$XBGm.LCICM.IOTDeviceScopeModel).$h,"n":"","d":422608,"h":0,"f":17829890}), null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t49, { set $v($v) { $r49 = $v; } }) ? $r49 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t49)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$XBGm.LCIC.UtilityExtension.Convert$3(TConcrete, m));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(214748787408)
            
            //--TRIMMABLE-BOUNDARY-START(115964539600)
            /*ValueTask<IEnumerable<TDeviceModel>> *//*async*/  GetDevices(TDeviceModel, /*IIOTDeviceScopeModel*/ scope)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceModel)), $.$$.SCG.IEnumerable$$(TDeviceModel), async ($asnycContext) => 
                {
                    let $t51, $r51;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964539600);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let m = ($t51 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany(TDeviceModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$8(scope.LCFCD$IIded$Identifier, 1, 2147483647/*int.MaxValue*/), null), ($.$$.N.AsyncResolver.IsCompleted($t51, { set $v($v) { $r51 = $v; } }) ? $r51 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t51)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, m.AsEnumerable() ?? $.$sl.SL.Enumerable.Empty(TDeviceModel));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115964539600)
            
            //--TRIMMABLE-BOUNDARY-START(133144408784)
            /*ValueTask<IEnumerable<IOTSceneModel>> *//*async*/  GetScenes(/*IIOTDeviceScopeModel*/ scope)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneModel), async ($asnycContext) => 
                {
                    let $t52, $r52;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144408784);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let m = ($t52 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTSceneModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$8(scope.LCFCD$IIded$Identifier, 1, 2147483647/*int.MaxValue*/), null), ($.$$.N.AsyncResolver.IsCompleted($t52, { set $v($v) { $r52 = $v; } }) ? $r52 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t52)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, m.AsEnumerable() ?? $.$sl.SL.Enumerable.Empty($.$XBGm.LCICM.IOTSceneModel));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133144408784)
            
            //--TRIMMABLE-BOUNDARY-START(141734343376)
            /*ValueTask<bool> */ LCICD$IScopeStore$IsPublished(/*IIOTDeviceScopeModel*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734343376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(141734343376)
            
            //--TRIMMABLE-BOUNDARY-START(146029310672)
            /*ValueTask */ LCICD$IScopeStore$Publish(TService, /*IIOTDeviceScopeModel*/ scope, /*IOTServiceModel?*/ remoteService)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029310672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(146029310672)
            
            //--TRIMMABLE-BOUNDARY-START(4295389904)
            /*ValueTask *//*async*/  _RemoveDevice(T, /*IIOTDeviceScopeModel*/ scope, /*T*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t53, $r53;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295389904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t53 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scope.LCFCD$IIded$Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [ device ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t53, { set $v($v) { $r53 = $v; } }) ? $r53 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t53)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4295389904)
            
            //--TRIMMABLE-BOUNDARY-START(227633689296)
            /*ValueTask *//*async*/  RemoveDevices(/*IIOTDeviceScopeModel*/ scope, /*params IIOTDeviceModel[]*/ devices)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633689296);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $i54 = 0;
                    let $arr54 = devices;
                    while ($i54 < $arr54.length)
                    {
                        let $t55, $r55;
                        let device = $arr54[$i54++];
                        ($t55 = this._RemoveDevice(T, scope, device), ($.$$.N.AsyncResolver.IsCompleted($t55, { set $v($v) { $r55 = $v; } }) ? $r55 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t55)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(227633689296)
            
            //--TRIMMABLE-BOUNDARY-START(231928656592)
            /*ValueTask *//*async*/  RemoveScene(/*IIOTDeviceScopeModel*/ scope, /*IOTSceneModel*/ scene)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t56, $r56;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231928656592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t56 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$XBGm.LCICM.IOTSceneModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(scope.LCFCD$IIded$Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTSceneModel), [ scene ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t56, { set $v($v) { $r56 = $v; } }) ? $r56 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t56)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(231928656592)
            
            //--TRIMMABLE-BOUNDARY-START(270583362256)
            /*ValueTask *//*async*/  SaveScope(T, /*T*/ t)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t57, $r57;
                    let $t61, $r61;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(270583362256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let ticket = ($t57 = this.authManager.LCFCA$IAuthenticationService$AuthenticateAsync(null), ($.$$.N.AsyncResolver.IsCompleted($t57, { set $v($v) { $r57 = $v; } }) ? $r57 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t57)));
                    if (t.LCICM$IIOTDeviceScopeModel$ServiceId.Empty)
                    {
                        let $t58, $r58;
                        /*IOTServiceModel?*/ let service = null;
                        /*var*/ let services = ($t58 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTServiceModel, this.Server, $.$fPer.LCFCD.DataFilter.All, null), ($.$$.N.AsyncResolver.IsCompleted($t58, { set $v($v) { $r58 = $v; } }) ? $r58 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t58)));
                        if ($.$sl.SL.Enumerable.Count$1($.$XBGm.LCICM.IOTServiceModel, services.Data) === 0)
                        {
                            let $t60, $r60;
                            service = (() =>
                            {
                                //new $.$XBGm.LCICM.IOTServiceModel()
                                const $t59 = $.$XBGm.LCICM.IOTServiceModel;
                                const $i59 = new $t59();
                                $i59.$ctor$10();
                                $i59.Name = t.LCFC$INamed$Name;
                                return $i59;
                            })();
                            service = $.$sl.SL.Enumerable.Single$1($.$XBGm.LCICM.IOTServiceModel, (($t60 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$XBGm.LCICM.IOTServiceModel, this.Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTServiceModel), [ service ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t60, { set $v($v) { $r60 = $v; } }) ? $r60 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t60)))).Data);
                        }
                        else 
                        {
                            service = $.$sl.SL.Enumerable.First$1($.$XBGm.LCICM.IOTServiceModel, services.Data);
                        }
                        (t).ServiceId = service.Identifier;
                    }
                    /*var*/ let tt = $.$sl.SL.Enumerable.Single$1(T, (($t61 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CreateOrUpdate(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [ t ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t61, { set $v($v) { $r61 = $v; } }) ? $r61 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t61)))).Data);
                    (t).Identifier = tt.LCFCD$IIded$Identifier;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(270583362256)
            
            //--TRIMMABLE-BOUNDARY-START(253403493072)
            /*ValueTask */ SaveAsync$2(/*IIOTDeviceScopeModel*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403493072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SaveScope(T, item);
            }
            //--TRIMMABLE-BOUNDARY-END(253403493072)
            
            //--TRIMMABLE-BOUNDARY-START(188978983632)
            /*ValueTask<IIOTDeviceScopeModel> */ LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Models$IIOTDeviceScopeModel$GetByIdAsync(/*object*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978983632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ISmartDataStoreT<IIOTDeviceScopeModel>*/ let db = this;
                return db.LCICD$ISmartDataStoreT$$$GetByIdAsync($.$XBGm.LCICM.IIOTDeviceScopeModel, id);
            }
            //--TRIMMABLE-BOUNDARY-END(188978983632)
            
            //--TRIMMABLE-BOUNDARY-START(12886054289)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IDeviceStatusStore.SaveAsync(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel, System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<int, double>>)
            LCICD$IDeviceStatusStore$SaveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886054289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SaveAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886054289)
            
            //--TRIMMABLE-BOUNDARY-START(8591086993)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IDeviceStatusStore.GetLastAsync(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel, out System.DateTime)
            LCICD$IDeviceStatusStore$GetLastAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591086993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetLastAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591086993)
            
            //--TRIMMABLE-BOUNDARY-START(4296119697)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IDeviceStatusStore.GetAllAsync(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel, System.DateTime?, System.DateTime?)
            LCICD$IDeviceStatusStore$GetAllAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296119697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296119697)
            
            //--TRIMMABLE-BOUNDARY-START(12886578577)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStore<LivingThing.Core.IOT.Common.Models.IOTSceneActionModel>.SaveAsync(LivingThing.Core.IOT.Common.Models.IOTSceneActionModel)
            LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneActionModel$SaveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886578577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SaveAsync$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886578577)
            
            //--TRIMMABLE-BOUNDARY-START(12886578577)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStore<LivingThing.Core.IOT.Common.Models.IOTSceneTriggerModel>.SaveAsync(LivingThing.Core.IOT.Common.Models.IOTSceneTriggerModel)
            LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneTriggerModel$SaveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886578577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SaveAsync$5(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886578577)
            
            //--TRIMMABLE-BOUNDARY-START(17181283729)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISceneStore.GetTriggers(LivingThing.Core.IOT.Common.Models.IOTSceneModel)
            LCICD$ISceneStore$GetTriggers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181283729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetTriggers(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181283729)
            
            //--TRIMMABLE-BOUNDARY-START(8591349137)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISceneStore.AddTrigger(LivingThing.Core.IOT.Common.Models.IOTSceneModel, LivingThing.Core.IOT.Common.Models.IOTSceneTriggerModel)
            LCICD$ISceneStore$AddTrigger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591349137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddTrigger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591349137)
            
            //--TRIMMABLE-BOUNDARY-START(25771218321)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISceneStore.RemoveTrigger(LivingThing.Core.IOT.Common.Models.IOTSceneModel, LivingThing.Core.IOT.Common.Models.IOTSceneTriggerModel)
            LCICD$ISceneStore$RemoveTrigger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771218321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveTrigger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771218321)
            
            //--TRIMMABLE-BOUNDARY-START(12886316433)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISceneStore.GetActions(LivingThing.Core.IOT.Common.Models.IOTSceneModel)
            LCICD$ISceneStore$GetActions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886316433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetActions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886316433)
            
            //--TRIMMABLE-BOUNDARY-START(4296381841)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISceneStore.AddAction(LivingThing.Core.IOT.Common.Models.IOTSceneModel, LivingThing.Core.IOT.Common.Models.IOTSceneActionModel)
            LCICD$ISceneStore$AddAction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296381841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddAction(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296381841)
            
            //--TRIMMABLE-BOUNDARY-START(21476251025)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISceneStore.RemoveAction(LivingThing.Core.IOT.Common.Models.IOTSceneModel, LivingThing.Core.IOT.Common.Models.IOTSceneActionModel)
            LCICD$ISceneStore$RemoveAction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476251025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAction(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476251025)
            
            //--TRIMMABLE-BOUNDARY-START(12886578577)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStore<LivingThing.Core.IOT.Common.Models.IOTSceneModel>.SaveAsync(LivingThing.Core.IOT.Common.Models.IOTSceneModel)
            LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneModel$SaveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886578577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SaveAsync$4(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886578577)
            
            //--TRIMMABLE-BOUNDARY-START(12886709649)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStoreT<LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel>.GetByIdAsync<TConcrete>(object)
            LCICD$ISmartDataStoreT$$$GetByIdAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886709649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByIdAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886709649)
            
            //--TRIMMABLE-BOUNDARY-START(4296775057)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStoreT<LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel>.DeleteAsync(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel)
            LCICD$ISmartDataStoreT$$$DeleteAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296775057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DeleteAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296775057)
            
            //--TRIMMABLE-BOUNDARY-START(17181676945)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStoreT<LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel>.SaveAsync(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel)
            LCICD$ISmartDataStoreT$$$SaveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181676945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SaveAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181676945)
            
            //--TRIMMABLE-BOUNDARY-START(4296709521)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStoreReadSingle<LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel>.GetByIdAsync(object)
            LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Interface$IIOTDeviceModel$GetByIdAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296709521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByIdAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296709521)
            
            //--TRIMMABLE-BOUNDARY-START(12886447505)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IScopeStore.GetAllAsync<TDeviceScopeModel>(LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory)
            LCICD$IScopeStore$GetAllAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886447505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllAsync$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886447505)
            
            //--TRIMMABLE-BOUNDARY-START(17181414801)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IScopeStore.GetDevices<TDeviceModel>(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel)
            LCICD$IScopeStore$GetDevices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181414801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDevices(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181414801)
            
            //--TRIMMABLE-BOUNDARY-START(4296512913)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IScopeStore.AddDevices(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel, params LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel[])
            LCICD$IScopeStore$AddDevices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296512913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddDevices(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296512913)
            
            //--TRIMMABLE-BOUNDARY-START(34361283985)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IScopeStore.RemoveDevices(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel, params LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel[])
            LCICD$IScopeStore$RemoveDevices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361283985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveDevices(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34361283985)
            
            //--TRIMMABLE-BOUNDARY-START(21476382097)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IScopeStore.GetScenes(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel)
            LCICD$IScopeStore$GetScenes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476382097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetScenes(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476382097)
            
            //--TRIMMABLE-BOUNDARY-START(8591480209)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IScopeStore.AddScene(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel, LivingThing.Core.IOT.Common.Models.IOTSceneModel)
            LCICD$IScopeStore$AddScene()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591480209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddScene(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591480209)
            
            //--TRIMMABLE-BOUNDARY-START(38656251281)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.IScopeStore.RemoveScene(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel, LivingThing.Core.IOT.Common.Models.IOTSceneModel)
            LCICD$IScopeStore$RemoveScene()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656251281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveScene(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38656251281)
            
            //--TRIMMABLE-BOUNDARY-START(8591742353)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStoreT<LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel>.GetAllAsync<TConcrete>()
            LCICD$ISmartDataStoreT$$$GetAllAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591742353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591742353)
            
            //--TRIMMABLE-BOUNDARY-START(4296775057)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStoreT<LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel>.DeleteAsync(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel)
            LCICD$ISmartDataStoreT$$$DeleteAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296775057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DeleteAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296775057)
            
            //--TRIMMABLE-BOUNDARY-START(17181676945)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.DataStore.ISmartDataStoreT<LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel>.SaveAsync(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel)
            LCICD$ISmartDataStoreT$$$SaveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181676945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SaveAsync$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181676945)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950095568)
                this.caches = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(42950095568)
                
            }
            static $h = 422608;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719899344),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309833936,
        "f": 50331649
      },
      "n": "Descriptor",
      "d": 422608,
      "h": 68719899344,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719899344)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899768528),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IDictionary$$$($.$$.S.DateTime, $.$$.SCG.IDictionary$$$($.$$.S.Int32, $.$$.S.Double))).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337
        },
        {
          "n": "startDate",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "endDate",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": "GetAllAsync",
      "d": 422608,
      "h": 85899768528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899768528),
//--TRIMMABLE-BOUNDARY-START(128849441488),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IDictionary$$$($.$$.S.Int32, $.$$.S.Double)).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337
        },
        {
          "n": "date",
          "p": 65994753,
          "f": 2
        }
      ],
      "n": "GetLastAsync",
      "d": 422608,
      "h": 128849441488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849441488),
//--TRIMMABLE-BOUNDARY-START(244813558480),
    {
      "r": 181338113,
      "p": [
        {
          "n": "device",
          "p": 27432337
        },
        {
          "n": "values",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Double)).$h
        }
      ],
      "n": "SaveAsync",
      "d": 422608,
      "h": 244813558480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813558480),
//--TRIMMABLE-BOUNDARY-START(257698460368),
    {
      "r": 181338113,
      "p": [
        {
          "n": "item",
          "p": 40342929
        }
      ],
      "n": "SaveAsync",
      "o": "@$3",
      "d": 422608,
      "h": 257698460368,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(257698460368),
//--TRIMMABLE-BOUNDARY-START(266288394960),
    {
      "r": 181338113,
      "p": [
        {
          "n": "item",
          "p": 40867217
        }
      ],
      "n": "SaveAsync",
      "o": "@$5",
      "d": 422608,
      "h": 266288394960,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(266288394960),
//--TRIMMABLE-BOUNDARY-START(111669572304),
    {
      "r": (T) => $.$mVyz.LCISCD.iSmartDatabase.CacheOfType$$(T).$h,
      "g": [
        "T"
      ],
      "n": "GetCache",
      "d": 422608,
      "h": 111669572304,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(111669572304),
//--TRIMMABLE-BOUNDARY-START(30065193680),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddToCache",
      "d": 422608,
      "h": 30065193680,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(30065193680),
//--TRIMMABLE-BOUNDARY-START(223338722000),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "RemoveCache",
      "d": 422608,
      "h": 223338722000,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(223338722000),
//--TRIMMABLE-BOUNDARY-START(124554474192),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "id",
          "p": 131073
        },
        {
          "n": "create",
          "p": (T) => $.$$.S.Func$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetFromCache",
      "o": "@$1",
      "d": 422608,
      "h": 124554474192,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(124554474192),
//--TRIMMABLE-BOUNDARY-START(120259506896),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "id",
          "p": 131073
        },
        {
          "n": "get",
          "p": (T) => $.$$.S.Func$$($.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "idComparator",
          "p": (T) => $.$$.S.Func$$$(T, $.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetFromCache",
      "d": 422608,
      "h": 120259506896,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(120259506896),
//--TRIMMABLE-BOUNDARY-START(98784670416),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)).$h,
      "p": [
        {
          "n": "get",
          "p": (T) => $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetAllFromCache",
      "d": 422608,
      "h": 98784670416,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(98784670416),
//--TRIMMABLE-BOUNDARY-START(34360160976),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scene",
          "p": 40605073
        },
        {
          "n": "trigger",
          "p": 40867217
        }
      ],
      "n": "AddTrigger",
      "d": 422608,
      "h": 34360160976,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34360160976),
//--TRIMMABLE-BOUNDARY-START(137439376080),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneTriggerModel)).$h,
      "p": [
        {
          "n": "scene",
          "p": 40605073
        }
      ],
      "n": "GetTriggers",
      "d": 422608,
      "h": 137439376080,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(137439376080),
//--TRIMMABLE-BOUNDARY-START(81604801232),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneActionModel)).$h,
      "p": [
        {
          "n": "scene",
          "p": 40605073
        }
      ],
      "n": "GetActions",
      "d": 422608,
      "h": 81604801232,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(81604801232),
//--TRIMMABLE-BOUNDARY-START(17180291792),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scene",
          "p": 40605073
        },
        {
          "n": "action",
          "p": 40342929
        }
      ],
      "n": "AddAction",
      "d": 422608,
      "h": 17180291792,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17180291792),
//--TRIMMABLE-BOUNDARY-START(236223623888),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scene",
          "p": 40605073
        },
        {
          "n": "trigger",
          "p": 40867217
        }
      ],
      "n": "RemoveTrigger",
      "d": 422608,
      "h": 236223623888,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(236223623888),
//--TRIMMABLE-BOUNDARY-START(219043754704),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scene",
          "p": 40605073
        },
        {
          "n": "action",
          "p": 40342929
        }
      ],
      "n": "RemoveAction",
      "d": 422608,
      "h": 219043754704,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(219043754704),
//--TRIMMABLE-BOUNDARY-START(261993427664),
    {
      "r": 181338113,
      "p": [
        {
          "n": "item",
          "p": 40605073
        }
      ],
      "n": "SaveAsync",
      "o": "@$4",
      "d": 422608,
      "h": 261993427664,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(261993427664),
//--TRIMMABLE-BOUNDARY-START(103079637712),
    {
      "r": $.$$.STT.ValueTask$$($.$XBGm.LCICI.IIOTDeviceModel).$h,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "GetByIdAsync",
      "d": 422608,
      "h": 103079637712,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(103079637712),
//--TRIMMABLE-BOUNDARY-START(107374605008),
    {
      "r": (TDeviceModel) => $.$$.STT.ValueTask$$(TDeviceModel).$h,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "g": [
        "TDeviceModel"
      ],
      "n": "GetByIdAsync",
      "o": "@$1",
      "d": 422608,
      "h": 107374605008,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(107374605008),
//--TRIMMABLE-BOUNDARY-START(51540030160),
    {
      "r": 181338113,
      "p": [
        {
          "n": "device",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Delete",
      "d": 422608,
      "h": 51540030160,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(51540030160),
//--TRIMMABLE-BOUNDARY-START(55834997456),
    {
      "r": 181338113,
      "p": [
        {
          "n": "item",
          "p": 27432337
        }
      ],
      "n": "DeleteAsync",
      "d": 422608,
      "h": 55834997456,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(55834997456),
//--TRIMMABLE-BOUNDARY-START(240518591184),
    {
      "r": 181338113,
      "p": [
        {
          "n": "device",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Save",
      "d": 422608,
      "h": 240518591184,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(240518591184),
//--TRIMMABLE-BOUNDARY-START(249108525776),
    {
      "r": 181338113,
      "p": [
        {
          "n": "item",
          "p": 27432337
        }
      ],
      "n": "SaveAsync",
      "o": "@$1",
      "d": 422608,
      "h": 249108525776,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(249108525776),
//--TRIMMABLE-BOUNDARY-START(47245062864),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        },
        {
          "n": "device",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDevice",
      "d": 422608,
      "h": 47245062864,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(47245062864),
//--TRIMMABLE-BOUNDARY-START(21475259088),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        },
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceModel).$h,
          "f": 16
        }
      ],
      "n": "AddDevices",
      "d": 422608,
      "h": 21475259088,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475259088),
//--TRIMMABLE-BOUNDARY-START(25770226384),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        },
        {
          "n": "scene",
          "p": 40605073
        }
      ],
      "n": "AddScene",
      "d": 422608,
      "h": 25770226384,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25770226384),
//--TRIMMABLE-BOUNDARY-START(64424932048),
    {
      "r": 181338113,
      "p": [
        {
          "n": "t",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "DeleteScope",
      "d": 422608,
      "h": 64424932048,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(64424932048),
//--TRIMMABLE-BOUNDARY-START(60129964752),
    {
      "r": 181338113,
      "p": [
        {
          "n": "item",
          "p": 34837905
        }
      ],
      "n": "DeleteAsync",
      "o": "@$1",
      "d": 422608,
      "h": 60129964752,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(60129964752),
//--TRIMMABLE-BOUNDARY-START(94489703120),
    {
      "r": (TDeviceScopeModel) => $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceScopeModel)).$h,
      "p": [
        {
          "n": "factory",
          "p": 28611985
        }
      ],
      "g": [
        "TDeviceScopeModel"
      ],
      "n": "GetAllAsync",
      "o": "@$2",
      "d": 422608,
      "h": 94489703120,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(94489703120),
//--TRIMMABLE-BOUNDARY-START(90194735824),
    {
      "r": (TConcrete) => $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TConcrete)).$h,
      "g": [
        "TConcrete"
      ],
      "n": "GetAllAsync",
      "o": "@$1",
      "d": 422608,
      "h": 90194735824,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(90194735824),
//--TRIMMABLE-BOUNDARY-START(115964539600),
    {
      "r": (TDeviceModel) => $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceModel)).$h,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        }
      ],
      "g": [
        "TDeviceModel"
      ],
      "n": "GetDevices",
      "d": 422608,
      "h": 115964539600,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(115964539600),
//--TRIMMABLE-BOUNDARY-START(133144408784),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTSceneModel)).$h,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        }
      ],
      "n": "GetScenes",
      "d": 422608,
      "h": 133144408784,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(133144408784),
//--TRIMMABLE-BOUNDARY-START(4295389904),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        },
        {
          "n": "device",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "_RemoveDevice",
      "d": 422608,
      "h": 4295389904,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(4295389904),
//--TRIMMABLE-BOUNDARY-START(227633689296),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        },
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceModel).$h,
          "f": 16
        }
      ],
      "n": "RemoveDevices",
      "d": 422608,
      "h": 227633689296,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(227633689296),
//--TRIMMABLE-BOUNDARY-START(231928656592),
    {
      "r": 181338113,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        },
        {
          "n": "scene",
          "p": 40605073
        }
      ],
      "n": "RemoveScene",
      "d": 422608,
      "h": 231928656592,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(231928656592),
//--TRIMMABLE-BOUNDARY-START(270583362256),
    {
      "r": 181338113,
      "p": [
        {
          "n": "t",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SaveScope",
      "d": 422608,
      "h": 270583362256,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(270583362256),
//--TRIMMABLE-BOUNDARY-START(253403493072),
    {
      "r": 181338113,
      "p": [
        {
          "n": "item",
          "p": 34837905
        }
      ],
      "n": "SaveAsync",
      "o": "@$2",
      "d": 422608,
      "h": 253403493072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403493072)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(274878329552),
    {
      "t": 1309651,
      "n": "Server",
      "d": 422608,
      "h": 274878329552,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(274878329552),
//--TRIMMABLE-BOUNDARY-START(38655128272),
    {
      "t": 1655170,
      "n": "authManager",
      "d": 422608,
      "h": 38655128272,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655128272),
//--TRIMMABLE-BOUNDARY-START(42950095568),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Object).$h,
      "n": "caches",
      "d": 422608,
      "h": 42950095568,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950095568)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885324496),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "authManager",
          "p": 1655170
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 422608,
      "h": 12885324496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885324496)
  ],
  "h": 422608
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICD.IDeviceStatusStore, $.$XBGm.LCICD.IServiceStore, $.$XBGm.LCICD.ISmartDataStore$$($.$XBGm.LCICM.IOTServiceModel), $.$XBGm.LCICD.ISmartDataStoreReadSingle$$($.$XBGm.LCICM.IOTServiceModel), $.$XBGm.LCICD.ISceneActionStore, $.$XBGm.LCICD.ISmartDataStore$$($.$XBGm.LCICM.IOTSceneActionModel), $.$XBGm.LCICD.ISmartDataStoreReadSingle$$($.$XBGm.LCICM.IOTSceneActionModel), $.$XBGm.LCICD.ISceneTriggerStore, $.$XBGm.LCICD.ISmartDataStore$$($.$XBGm.LCICM.IOTSceneTriggerModel), $.$XBGm.LCICD.ISmartDataStoreReadSingle$$($.$XBGm.LCICM.IOTSceneTriggerModel), $.$XBGm.LCICD.ISceneStore, $.$XBGm.LCICD.ISmartDataStore$$($.$XBGm.LCICM.IOTSceneModel), $.$XBGm.LCICD.ISmartDataStoreReadSingle$$($.$XBGm.LCICM.IOTSceneModel), $.$XBGm.LCICD.IDeviceStore, $.$XBGm.LCICD.ISmartDataStoreT$$($.$XBGm.LCICI.IIOTDeviceModel), $.$XBGm.LCICD.ISmartDataStoreReadSingle$$($.$XBGm.LCICI.IIOTDeviceModel), $.$XBGm.LCICD.IScopeStore, $.$XBGm.LCICD.ISmartDataStoreT$$($.$XBGm.LCICM.IIOTDeviceScopeModel), $.$XBGm.LCICD.ISmartDataStoreReadSingle$$($.$XBGm.LCICM.IIOTDeviceScopeModel) ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mVyz.LCISCD.iSmartDatabase.CacheOfType$$(T) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Client.DataStore.iSmartDatabase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Client${separator}DataStore${separator}iSmartDatabase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(422608)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Devices"));
})();
//--TRIMMABLE-BOUNDARY-END(29392)
