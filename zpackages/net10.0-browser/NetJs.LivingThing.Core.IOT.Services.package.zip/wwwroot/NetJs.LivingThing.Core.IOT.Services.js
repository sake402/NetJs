
//--TRIMMABLE-BOUNDARY-START(30881)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $fXpo, $zHIt, $uvJL, $KuVO, $lOHy, $kVHt, $UrvY, $vWqU, $JRhp, $DJRY, $tUcV, $nYKj, $AvdQ, $bMcF, $XBGm, $NXre) {
    "use strict";
    let _;
    let $aPEahc;
    let $ufGGYj;
    let $tMinij;
    let $glETTj;
    let $pDlTMk;
    let $iQQwDc;
    let $bqXUCe;
    let $GORPwi;
    let $RpHadh;
    let $Xbraqc;
    let $yROOHc;
    let $rerJbj;
    let $bsGShj;
    let $bwiadg;
    let $tFjiac;
    let $DXGEgj;
    let $BSYnnh;
    let $TyGoGk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Services", 
    {
  "h": 30881,
  "f": "LivingThing.Core.IOT.Services",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Services",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Services",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(358561)
        $asm.$cls(`$cDvV.LCIS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590293153)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590293153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fXpo.LCFCP.IPipeline$$($.$XBGm.LCICS.ChallengeStatus), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICS.IDeviceSecurityProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$cDvV.LCISD.SmartDeviceSecurityProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICS.IDeviceSecurityProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISD.SmartDeviceSecurityProvider, x);
                }, $ufGGYj ??= {"r":51418513,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fXpo.LCFCP.IPipeline$$($.$XBGm.LCICS.ChallengeStatus)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISD.SmartDeviceSecurityProvider, x);
                }, $tMinij ??= {"r":$.$fXpo.LCFCP.IPipeline$$($.$XBGm.LCICS.ChallengeStatus).$h,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$cDvV.LCISS.ChallengeHandshakeAuthenticationProtocol, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISS.ChallengeHandshakeAuthenticationProtocol, x);
                }, $glETTj ??= {"r":$.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage).$h,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICS.IPacketSecurityProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$cDvV.LCISS.PacketEncryptionDecryption, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICS.IPacketSecurityProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISS.PacketEncryptionDecryption, x);
                }, $pDlTMk ??= {"r":51484049,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISS.PacketEncryptionDecryption, x);
                }, $iQQwDc ??= {"r":$.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage).$h,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fXpo.LCFCP.IPipeline$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$cDvV.LCISU.iSmartDeviceUpdater, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fXpo.LCFCP.IPipeline$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISU.iSmartDeviceUpdater, x);
                }, $bqXUCe ??= {"r":$.$fXpo.LCFCP.IPipeline$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fXpo.LCFCPC.IPipelineCollection$$($.$XBGm.LCICS.ChallengeStatus), $.$fXpo.LCFCPC.DIPipelineCollection$$($.$XBGm.LCICS.ChallengeStatus), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICO.IFirmwareUpdater, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$cDvV.LCISU.FirmwareUpdater, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICO.IFirmwareUpdater))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISU.FirmwareUpdater, x);
                }, $GORPwi ??= {"r":45782417,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cDvV.LCISU.FirmwareUpdater, x);
                }, $RpHadh ??= {"r":$.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage).$h,"p":[{"n":"x","p":327718}],"n":"","d":358561,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590293153)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cDvV.LCIS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295325857)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295325857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295325857)
            
            //--TRIMMABLE-BOUNDARY-START(4295325857)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295325857)
            
            static $h = 358561;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590293153),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 358561,
      "h": 8590293153,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590293153)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295325857),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 358561,
      "h": 4295325857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295325857)
  ],
  "h": 358561
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(358561)
        
        

        //--TRIMMABLE-BOUNDARY-START(227489)
        $asm.$cls(`$cDvV.LCISS.ChallengeHandshakeAuthenticationProtocol`, ($self) => class ChallengeHandshakeAuthenticationProtocol extends $.$fXpo.LCFCPC.BasePipeline$$($.$KuVO.LCFCC.IConnectionMessage)
        {
            //--TRIMMABLE-BOUNDARY-START(38654933153)
            /*IDeviceSecurityProvider*/ SecurityProvider = null;
            //--TRIMMABLE-BOUNDARY-END(38654933153)
            
            //--TRIMMABLE-BOUNDARY-START(34359965857)
            /*IPacketSecurityProvider*/ PacketSecurity = null;
            //--TRIMMABLE-BOUNDARY-END(34359965857)
            
            //--TRIMMABLE-BOUNDARY-START(8590162081)
            /*IPipelineCollection<ChallengeStatus>*/ ChallengeStatusPipeline = null;
            //--TRIMMABLE-BOUNDARY-END(8590162081)
            
            //--TRIMMABLE-BOUNDARY-START(12885129377)
            /*bool*/ encryptedChallenge = false;
            //--TRIMMABLE-BOUNDARY-END(12885129377)
            
            //--TRIMMABLE-BOUNDARY-START(4295194785)
            $ctor$2(/*IDeviceSecurityProvider*/ securityProvider, /*IPacketSecurityProvider*/ packetSecurity, /*IPipelineCollection<ChallengeStatus>*/ challengeStatusPipeline)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295194785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.SecurityProvider = securityProvider;
                    this.PacketSecurity = packetSecurity;
                    this.ChallengeStatusPipeline = challengeStatusPipeline;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295194785)
            
            //--TRIMMABLE-BOUNDARY-START(30064998561)
            /*int */ get Order()
            {
                return -2147483648/*int.MinValue*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30064998561)
            
            //--TRIMMABLE-BOUNDARY-START(25770031265)
            /*Task *//*async*/  Invoke(/*IConnectionMessage*/ context, /*PipelineDelegate<IConnectionMessage>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770031265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (context.LCFCC$IConnectionMessage$Direction === 0/*MessageDirection.In*/ && this.SecurityProvider.LCICS$IDeviceSecurityProvider$SupportsChallenge(context.LCFCC$IConnectionMessage$Client))
                    {
                        /*var*/ let state = $.$fPer.LCFCD.WorkSpaceExtension.Get($.$XBGm.LCICS.ChallengeStatus, context.LCFCC$IConnectionMessage$Client, this, "ChallengeStatusPipeline", new ($.$$.S.Func$$($.$XBGm.LCICS.ChallengeStatus))().$ctor(this,  () =>
                        {
                            return (() =>
                            {
                                //new $.$XBGm.LCICS.ChallengeStatus()
                                const $t1 = $.$XBGm.LCICS.ChallengeStatus;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.State = 0/*ChallengeState.None*/;
                                $i1.Client = context.LCFCC$IConnectionMessage$Client;
                                return $i1;
                            })();
                        }, $yROOHc ??= {"r":51352977,"n":"","d":227489,"h":0,"f":17825794}), false, true);
                        let $switch2 = state.State;
                        switch($switch2)
                        {
                            case 0/*ChallengeState.None*/:
                            case 2/*ChallengeState.Authenticated*/:
                            {
                                /*byte[]*/ let iv = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [16], null);
                                $.$$.S.Random.Shared.NextBytes(iv);
                                /*PacketBuilder*/ let packet = new $.$fPer.LCFCD.PacketBuilder().$ctor$1($.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(context.LCFCC$IConnectionMessage$Data));
                                if (packet.GetByte(-1) === 1)
                                {
                                    let $t3, $r3;
                                    /*int*/ let id = packet.GetByte(-1);
                                    /*int*/ let len = packet.GetWord(-1, 0);
                                    /*byte[]*/ let cipheredChallenge = packet.GetBytes(-1);
                                    /*string*/ let uid = packet.GetString();
                                    /*var*/ let split = $.$$.S.String.Split$1.call(uid, /*/*/ 47, 0);
                                    /*string?*/ let family = null;
                                    /*string?*/ let deviceId = null;
                                    if (split.length === 2)
                                    {
                                        family = $.$$.System.Array.$ReadT1.call(split, 0);
                                        deviceId = $.$$.System.Array.$ReadT1.call(split, 1);
                                    }
                                    else 
                                    {
                                        deviceId = $.$$.System.Array.$ReadT1.call(split, 0);
                                    }
                                    /*byte[]*/ let secret = ($t3 = this.SecurityProvider.LCICS$IDeviceSecurityProvider$GetSecretAsync(deviceId), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                    if (secret !== null)
                                    {
                                        let $t5, $r5;
                                        /*byte[]*/ let plainChallenge = cipheredChallenge;
                                        if (this.encryptedChallenge)
                                        {
                                            let aesAlg = null;
                                            try
                                            {
                                                aesAlg = $.$sscr.SSC.Aes.Create$2();
                                                aesAlg.Key = secret;
                                                aesAlg.IV = iv;
                                                /*ICryptoTransform*/ let decryptor = aesAlg.CreateDecryptor$1(aesAlg.Key, aesAlg.IV);
                                                let msDecrypt = null;
                                                try
                                                {
                                                    msDecrypt = new $.$$.SI.MemoryStream().$ctor$8(cipheredChallenge);
                                                    let csDecrypt = null;
                                                    try
                                                    {
                                                        csDecrypt = new $.$sscr.SSC.CryptoStream().$ctor$4(msDecrypt, decryptor, 0/*CryptoStreamMode.Read*/);
                                                        let srDecrypt = null;
                                                        try
                                                        {
                                                            srDecrypt = new $.$$.SI.BinaryReader().$ctor$3(csDecrypt);
                                                            plainChallenge = srDecrypt.ReadBytes(2147483647/*int.MaxValue*/);
                                                        }
                                                        finally
                                                        {
                                                            srDecrypt?.S$IDisposable$Dispose();
                                                        }
                                                    }
                                                    finally
                                                    {
                                                        csDecrypt?.S$IDisposable$Dispose();
                                                    }
                                                }
                                                finally
                                                {
                                                    msDecrypt?.S$IDisposable$Dispose();
                                                }
                                            }
                                            finally
                                            {
                                                aesAlg?.S$IDisposable$Dispose();
                                            }
                                        }
                                        /*SHA1*/ let sha = $.$sscr.SSC.SHA1.Create$2();
                                        /*var*/ let hashing = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((((1 + plainChallenge.length) | 0) + secret.length) | 0)], null);
                                        $.$$.System.Array.$WriteT1.call(hashing, $.$cast(id, $.$$.S.Byte), 0);
                                        $.$$.S.Array.Copy(secret, 0, hashing, 1, secret.length);
                                        $.$$.S.Array.Copy(plainChallenge, 0, hashing, ((1 + secret.length) | 0), plainChallenge.length);
                                        /*var*/ let hash = sha.ComputeHash$1(hashing);
                                        /*byte[]*/ let cipheredHash = hash;
                                        if (this.encryptedChallenge)
                                        {
                                            let aesAlg = null;
                                            try
                                            {
                                                aesAlg = $.$sscr.SSC.Aes.Create$2();
                                                aesAlg.Key = secret;
                                                aesAlg.IV = iv;
                                                /*ICryptoTransform*/ let encryptor = aesAlg.CreateEncryptor$1(aesAlg.Key, aesAlg.IV);
                                                let msEncrypt = null;
                                                try
                                                {
                                                    msEncrypt = new $.$$.SI.MemoryStream().$ctor$3();
                                                    let csEncrypt = null;
                                                    try
                                                    {
                                                        csEncrypt = new $.$sscr.SSC.CryptoStream().$ctor$4(msEncrypt, encryptor, 1/*CryptoStreamMode.Write*/);
                                                        let swEncrypt = null;
                                                        try
                                                        {
                                                            swEncrypt = new $.$$.SI.BinaryWriter().$ctor$4(csEncrypt);
                                                            swEncrypt.Write$3(hash);
                                                        }
                                                        finally
                                                        {
                                                            swEncrypt?.S$IDisposable$Dispose();
                                                        }
                                                        cipheredHash = msEncrypt.ToArray();
                                                    }
                                                    finally
                                                    {
                                                        csEncrypt?.S$IDisposable$Dispose();
                                                    }
                                                }
                                                finally
                                                {
                                                    msEncrypt?.S$IDisposable$Dispose();
                                                }
                                            }
                                            finally
                                            {
                                                aesAlg?.S$IDisposable$Dispose();
                                            }
                                        }
                                        /*PacketBuilder*/ let response = new $.$fPer.LCFCD.PacketBuilder().$ctor$2(2048);
                                        response.Push$1(2);
                                        response.Push$1($.$cast(id, $.$$.S.Byte));
                                        response.Push$11($.$cast((((hash.length + 1) | 0)), $.$$.S.UInt16), 0);
                                        response.Push$1($.$cast(cipheredHash.length, $.$$.S.Byte));
                                        let $i4 = 0;
                                        let $arr4 = cipheredHash;
                                        while ($i4 < $arr4.length)
                                        {
                                            let byt = $arr4[$i4++];
                                            response.Push$1(byt);
                                        }
                                        ($t5 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Write$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, new $.$KuVO.LCFCC.ConnectionMessage().$ctor$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(response.Packet)), false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                        state = (() =>
                                        {
                                            //new $.$XBGm.LCICS.ChallengeStatus()
                                            const $t6 = $.$XBGm.LCICS.ChallengeStatus;
                                            const $i6 = new $t6();
                                            $i6.$ctor$1();
                                            $i6.State = 1/*ChallengeState.Authenticating*/;
                                            $i6.Id = id;
                                            $i6.DeviceId = deviceId;
                                            $i6.Family = family;
                                            $i6.Client = context.LCFCC$IConnectionMessage$Client;
                                            return $i6;
                                        })();
                                        $.$fPer.LCFCD.WorkSpaceExtension.Set($.$XBGm.LCICS.ChallengeStatus, context.LCFCC$IConnectionMessage$Client, state, this, "ChallengeStatusPipeline", true);
                                        this.ChallengeStatusPipeline.LCFCPC$IPipelineCollection$LivingThing$Core$IOT$Common$Security$ChallengeStatus$Feed(state, null);
                                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                                    }
                                    else 
                                    {
                                        context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface.LCFCC$IConnectionInterface$Disconnect(context.LCFCC$IConnectionMessage$Client);
                                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                                    }
                                }
                                else 
                                {
                                    if (state.State !== 2/*ChallengeState.Authenticated*/)
                                    {
                                        context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface.LCFCC$IConnectionInterface$Disconnect(context.LCFCC$IConnectionMessage$Client);
                                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                                    }
                                }
                                break;
                            }
                            case 1/*ChallengeState.Authenticating*/:
                            {
                                /*PacketBuilder*/ let packet = new $.$fPer.LCFCD.PacketBuilder().$ctor$1($.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(context.LCFCC$IConnectionMessage$Data));
                                /*int*/ let code = packet.GetByte(-1);
                                /*int*/ let id = packet.GetByte(-1);
                                if ((code === 3 || code === 4) && id === state.Id)
                                {
                                    if (code === 4)
                                    {
                                        state.State = 3/*ChallengeState.NotAuthenticated*/;
                                        this.ChallengeStatusPipeline.LCFCPC$IPipelineCollection$LivingThing$Core$IOT$Common$Security$ChallengeStatus$Feed(state, null);
                                        context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface.LCFCC$IConnectionInterface$Disconnect(context.LCFCC$IConnectionMessage$Client);
                                    }
                                    else 
                                    {
                                        context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id = $.$with(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id, ($clone) =>
                                        {
                                            $clone.UniqueId = state.DeviceId;
                                            $clone.FamilyName = state.Family;
                                        });
                                        state.State = 2/*ChallengeState.Authenticated*/;
                                        this.ChallengeStatusPipeline.LCFCPC$IPipelineCollection$LivingThing$Core$IOT$Common$Security$ChallengeStatus$Feed(state, null);
                                    }
                                }
                                else 
                                {
                                }
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                    }
                    ($t7 = super.Invoke(context, next), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770031265)
            
            static $h = 227489;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fXpo.LCFCPC.BasePipeline$$($.$KuVO.LCFCC.IConnectionMessage); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064998561),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475063969,
        "f": 50364417
      },
      "n": "Order",
      "d": 227489,
      "h": 30064998561,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30064998561)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770031265),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1961646
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "Invoke",
      "d": 227489,
      "h": 25770031265,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(25770031265)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38654933153),
    {
      "t": 51418513,
      "n": "SecurityProvider",
      "d": 227489,
      "h": 38654933153,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654933153),
//--TRIMMABLE-BOUNDARY-START(34359965857),
    {
      "t": 51484049,
      "n": "PacketSecurity",
      "d": 227489,
      "h": 34359965857,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359965857),
//--TRIMMABLE-BOUNDARY-START(8590162081),
    {
      "t": $.$fXpo.LCFCPC.IPipelineCollection$$($.$XBGm.LCICS.ChallengeStatus).$h,
      "n": "ChallengeStatusPipeline",
      "d": 227489,
      "h": 8590162081,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590162081),
//--TRIMMABLE-BOUNDARY-START(12885129377),
    {
      "t": 262145,
      "n": "encryptedChallenge",
      "d": 227489,
      "h": 12885129377,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885129377)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295194785),
    {
      "p": [
        {
          "n": "securityProvider",
          "p": 51418513
        },
        {
          "n": "packetSecurity",
          "p": 51484049
        },
        {
          "n": "challengeStatusPipeline",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$XBGm.LCICS.ChallengeStatus).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 227489,
      "h": 4295194785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295194785)
  ],
  "h": 227489
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Security.ChallengeHandshakeAuthenticationProtocol`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Security${separator}ChallengeHandshakeAuthenticationProtocol`; }
        });
        //--TRIMMABLE-BOUNDARY-END(227489)
        
        

        //--TRIMMABLE-BOUNDARY-START(293025)
        $asm.$cls(`$cDvV.LCISS.PacketEncryptionDecryption`, ($self) => class PacketEncryptionDecryption extends $.$fXpo.LCFCPC.BasePipeline$$($.$KuVO.LCFCC.IConnectionMessage)
        {
            //--TRIMMABLE-BOUNDARY-START(42949965985)
            /*IDeviceSecurityProvider*/ SecurityProvider = null;
            //--TRIMMABLE-BOUNDARY-END(42949965985)
            
            //--TRIMMABLE-BOUNDARY-START(4295260321)
            $ctor$2(/*IDeviceSecurityProvider*/ securityProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295260321);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.SecurityProvider = securityProvider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295260321)
            
            //--TRIMMABLE-BOUNDARY-START(38654998689)
            /*int */ get Order()
            {
                return ((-2147483648/*int.MinValue*/ + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(38654998689)
            
            //--TRIMMABLE-BOUNDARY-START(8590227617)
            /*Task<byte[]> *//*async*/  Decrypt(/*string*/ deviceId, /*byte[]*/ cipher)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$typeArray($.$$.S.Byte)), $.$typeArray($.$$.S.Byte), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590227617);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*byte[]*/ let secret = ($t1 = this.SecurityProvider.LCICS$IDeviceSecurityProvider$GetSecretAsync(deviceId), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (secret !== null)
                    {
                        /*var*/ let _secret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [32], null);
                        $.$$.S.Array.Copy$2(secret, _secret, 32);
                        let aesAlg = null;
                        try
                        {
                            aesAlg = $.$sscr.SSC.Aes.Create$2();
                            aesAlg.Padding = 1/*PaddingMode.None*/;
                            aesAlg.Key = _secret;
                            /*var*/ let iv = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [16], null);
                            $.$$.S.Array.Copy$2(cipher, iv, 16);
                            aesAlg.IV = iv;
                            /*var*/ let dataBlock = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((cipher.length - 16) | 0)], null);
                            $.$$.S.Array.Copy(cipher, 16, dataBlock, 0, dataBlock.length);
                            /*ICryptoTransform*/ let decryptor = aesAlg.CreateDecryptor$1(aesAlg.Key, aesAlg.IV);
                            let msDecrypt = null;
                            try
                            {
                                msDecrypt = new $.$$.SI.MemoryStream().$ctor$8(dataBlock);
                                let csDecrypt = null;
                                try
                                {
                                    csDecrypt = new $.$sscr.SSC.CryptoStream().$ctor$4(msDecrypt, decryptor, 0/*CryptoStreamMode.Read*/);
                                    let srDecrypt = null;
                                    try
                                    {
                                        srDecrypt = new $.$$.SI.BinaryReader().$ctor$3(csDecrypt);
                                        /*var*/ let plain = srDecrypt.ReadBytes(dataBlock.length);
                                        return $.$$.N.AsyncResolver.Result($asnycContext, plain);
                                    }
                                    finally
                                    {
                                        srDecrypt?.S$IDisposable$Dispose();
                                    }
                                }
                                finally
                                {
                                    csDecrypt?.S$IDisposable$Dispose();
                                }
                            }
                            finally
                            {
                                msDecrypt?.S$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            aesAlg?.S$IDisposable$Dispose();
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, cipher);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590227617)
            
            //--TRIMMABLE-BOUNDARY-START(21475129505)
            /*Task<byte[]> *//*async*/  Encrypt(/*string*/ deviceId, /*byte[]*/ plain)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$typeArray($.$$.S.Byte)), $.$typeArray($.$$.S.Byte), async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475129505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*byte[]*/ let secret = ($t2 = this.SecurityProvider.LCICS$IDeviceSecurityProvider$GetSecretAsync(deviceId), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    if (secret !== null)
                    {
                        /*var*/ let plainLen = ((16 * ($.trunc((((plain.length + 15) | 0)) / 16))) | 0);
                        /*var*/ let pln = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [plainLen], null);
                        $.$$.S.Array.Copy$2(plain, pln, plain.length);
                        plain = pln;
                        /*var*/ let _secret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [32], null);
                        $.$$.S.Array.Copy$2(secret, _secret, 32);
                        let aesAlg = null;
                        try
                        {
                            aesAlg = $.$sscr.SSC.Aes.Create$2();
                            aesAlg.Padding = 1/*PaddingMode.None*/;
                            aesAlg.Key = _secret;
                            aesAlg.GenerateIV();
                            /*ICryptoTransform*/ let encryptor = aesAlg.CreateEncryptor$1(aesAlg.Key, aesAlg.IV);
                            let msEncrypt = null;
                            try
                            {
                                msEncrypt = new $.$$.SI.MemoryStream().$ctor$3();
                                let csEncrypt = null;
                                try
                                {
                                    csEncrypt = new $.$sscr.SSC.CryptoStream().$ctor$4(msEncrypt, encryptor, 1/*CryptoStreamMode.Write*/);
                                    let swEncrypt = null;
                                    try
                                    {
                                        swEncrypt = new $.$$.SI.BinaryWriter().$ctor$4(csEncrypt);
                                        swEncrypt.Write$3(plain);
                                    }
                                    finally
                                    {
                                        swEncrypt?.S$IDisposable$Dispose();
                                    }
                                    /*var*/ let data = msEncrypt.ToArray();
                                    /*var*/ let pack = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((aesAlg.IV.length + data.length) | 0)], null);
                                    $.$$.S.Array.Copy$2(aesAlg.IV, pack, aesAlg.IV.length);
                                    $.$$.S.Array.Copy(data, 0, pack, aesAlg.IV.length, data.length);
                                    return $.$$.N.AsyncResolver.Result($asnycContext, pack);
                                }
                                finally
                                {
                                    csEncrypt?.S$IDisposable$Dispose();
                                }
                            }
                            finally
                            {
                                msEncrypt?.S$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            aesAlg?.S$IDisposable$Dispose();
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, plain);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475129505)
            
            //--TRIMMABLE-BOUNDARY-START(34360031393)
            /*Task *//*async*/  Invoke(/*IConnectionMessage*/ context, /*PipelineDelegate<IConnectionMessage>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360031393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!(context !== null && ($.$is(context, $.$XBGm.LCICC.MutatedConnectionMessage$$($.$cDvV.LCISS.PacketEncryptionDecryption)))))
                    {
                        if (!this.disabledClients.Contains(context.LCFCC$IConnectionMessage$Client))
                        {
                            /*var*/ let id = context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id.UniqueId;
                            if (id !== null && this.SecurityProvider.LCICS$IDeviceSecurityProvider$SupportsSecuredChannel(context.LCFCC$IConnectionMessage$Client))
                            {
                                /*var*/ let bytes = $.$firstOf($.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(context.LCFCC$IConnectionMessage$Data), () => { throw new $.$$.S.InvalidOperationException().$ctor$12("No data") });
                                if (context.LCFCC$IConnectionMessage$Direction === 0/*MessageDirection.In*/)
                                {
                                    if (bytes.length % 16 === 0 && bytes.length > 16)
                                    {
                                        let $t3, $r3;
                                        /*var*/ let plain = ($t3 = this.Decrypt(id, bytes), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                        if (plain !== bytes)
                                        {
                                            context = new ($.$XBGm.LCICC.MutatedConnectionMessage$$($.$cDvV.LCISS.PacketEncryptionDecryption))().$ctor$1(context, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(plain));
                                        }
                                    }
                                }
                                else 
                                {
                                    let $t4, $r4;
                                    /*var*/ let cipher = ($t4 = this.Encrypt(id, bytes), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    if (cipher !== bytes)
                                    {
                                        context = new ($.$XBGm.LCICC.MutatedConnectionMessage$$($.$cDvV.LCISS.PacketEncryptionDecryption))().$ctor$1(context, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(cipher));
                                    }
                                }
                            }
                        }
                    }
                    ($t5 = super.Invoke(context, next), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360031393)
            
            //--TRIMMABLE-BOUNDARY-START(17180162209)
            /*List<IConnectionClient>*/ disabledClients = null;
            //--TRIMMABLE-BOUNDARY-END(17180162209)
            
            //--TRIMMABLE-BOUNDARY-START(12885194913)
            /*IDisposable */ Disable(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885194913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disabledClients.Add(client);
                return new $.$fPer.LCFC.DisposableDelegate().$ctor$3(new $.$$.S.Action().$ctor(this,  () =>
                {
                    return this.disabledClients.Remove(client);
                }, $Xbraqc ??= {"r":65537,"n":"","d":293025,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885194913)
            
            //--TRIMMABLE-BOUNDARY-START(4346451345)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IPacketSecurityProvider.Disable(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCICS$IPacketSecurityProvider$Disable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4346451345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Disable(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4346451345)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180162209)
                this.disabledClients = new ($.$$.SCG.List$$($.$KuVO.LCFCC.IConnectionClient))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180162209)
                
            }
            static $h = 293025;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fXpo.LCFCPC.BasePipeline$$($.$KuVO.LCFCC.IConnectionMessage); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654998689),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065064097,
        "f": 50364417
      },
      "n": "Order",
      "d": 293025,
      "h": 38654998689,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38654998689)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590227617),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        },
        {
          "n": "cipher",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Decrypt",
      "d": 293025,
      "h": 8590227617,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(8590227617),
//--TRIMMABLE-BOUNDARY-START(21475129505),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        },
        {
          "n": "plain",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Encrypt",
      "d": 293025,
      "h": 21475129505,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21475129505),
//--TRIMMABLE-BOUNDARY-START(34360031393),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1961646
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "Invoke",
      "d": 293025,
      "h": 34360031393,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(34360031393),
//--TRIMMABLE-BOUNDARY-START(12885194913),
    {
      "r": 91095041,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Disable",
      "d": 293025,
      "h": 12885194913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885194913)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42949965985),
    {
      "t": 51418513,
      "n": "SecurityProvider",
      "d": 293025,
      "h": 42949965985,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949965985),
//--TRIMMABLE-BOUNDARY-START(17180162209),
    {
      "t": $.$$.SCG.List$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "n": "disabledClients",
      "d": 293025,
      "h": 17180162209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180162209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295260321),
    {
      "p": [
        {
          "n": "securityProvider",
          "p": 51418513
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 293025,
      "h": 4295260321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295260321)
  ],
  "h": 293025
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage), $.$XBGm.LCICS.IPacketSecurityProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Security.PacketEncryptionDecryption`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Security${separator}PacketEncryptionDecryption`; }
        });
        //--TRIMMABLE-BOUNDARY-END(293025)
        
        

        //--TRIMMABLE-BOUNDARY-START(424097)
        $asm.$cls(`$cDvV.LCISU.FirmwareUpdater`, ($self) => class FirmwareUpdater extends $.$fXpo.LCFCPC.BasePipeline$$($.$XBGm.LCICO.IUpdatableDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(38655129761)
            /*IMemoryCache*/ memoryCache = null;
            //--TRIMMABLE-BOUNDARY-END(38655129761)
            
            //--TRIMMABLE-BOUNDARY-START(81604802721)
            /*Dictionary<IUpdatableDevice, bool>*/ updating = null;
            //--TRIMMABLE-BOUNDARY-END(81604802721)
            
            //--TRIMMABLE-BOUNDARY-START(4295391393)
            $ctor$2(/*IServerRemoteService*/ server, /*HttpClient*/ http, /*IMemoryCache*/ cache)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295391393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.otaUpdateBuilder = new $.$XBGm.LCICO.FirmwareUpdatePacketBuilder().$ctor$1(server, http);
                    this.memoryCache = cache;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295391393)
            
            //--TRIMMABLE-BOUNDARY-START(68719900833)
            /*FirmwareUpdatePacketBuilder*/ otaUpdateBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(68719900833)
            
            //--TRIMMABLE-BOUNDARY-START(73014868129)
            /*Task *//*async*/  RunOTAUpdateCommander(/*IUpdatableDevice*/ device, /*IOTDeviceFirmwareModel?*/ firmware, /*Action<IOTDeviceFirmwareUpdatingModel>?*/ progress)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014868129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!device.LCICO$IUpdatableDevice$CanUpdate)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    firmware = firmware ?? ($t1 = this.otaUpdateBuilder.CheckUpdate(device.LCICO$IUpdatableDevice$FamilyName, device.LCICO$IUpdatableDevice$UniqueId, device.LCICO$IUpdatableDevice$CurrentFirmwareVersion), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (firmware !== null)
                    {
                        /*int*/ let response;
                        /*FirmwareUpdateStatus*/ let status;
                        /*int*/ let offset;
                        /*IOTDeviceFirmwareUpdatingModel*/ let updateCommand;
                        try
                        {
                            let $t2, $r2;
                            updateCommand = ($t2 = this.otaUpdateBuilder.BeginUpdate(firmware, device.LCICO$IUpdatableDevice$UniqueId, null).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            progress?.Invoke(updateCommand);
                            if ((updateCommand?.Packet ?? null) !== null)
                            {
                                /*int*/ let _retry = 3;
                                do
                                {
                                    let $t3, $r3;
                                    response = ($t3 = device.LCICO$IUpdatableDevice$BeginUpdate(updateCommand), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                }
                                while(response === 0 && _retry-- > 0);
                                status = $.$cast((response & 255), $.$XBGm.LCICO.FirmwareUpdateStatus);
                                if (status === 3/*FirmwareUpdateStatus.Continue*/)
                                {
                                    offset = response >> 8;
                                    do
                                    {
                                        updateCommand = this.otaUpdateBuilder.ContinueUpdate(updateCommand, status, offset, 1024);
                                        progress?.Invoke(updateCommand);
                                        if (updateCommand.Packet === null)
                                        {
                                            throw new $.$$.S.Exception().$ctor$4(`Update Failed: ${$.$strNN($.$$.S.Enum.ToStringT($.$XBGm.LCICO.FirmwareUpdateStatus, $.$$.S.UInt32, status))}`);
                                        }
                                        /*int*/ let retry = 3;
                                        do
                                        {
                                            try
                                            {
                                                do
                                                {
                                                    let $t4, $r4;
                                                    response = ($t4 = device.LCICO$IUpdatableDevice$ContinueUpdate(updateCommand, $.$$.S.TimeSpan.FromSeconds$2(BigInt(updateCommand.LastPacket ? 15 : 2))).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                                    status = $.$cast((response & 255), $.$XBGm.LCICO.FirmwareUpdateStatus);
                                                    offset = response >> 8;
                                                }
                                                while((status === 0/*FirmwareUpdateStatus.None*/) && (retry-- > 0));
                                            }
                                            catch($e)
                                            {
                                                if ($e instanceof $.$XBGm.LCIC.ClientNotConnectedException)
                                                {
                                                    throw $e;
                                                }
                                                else if ($e instanceof $.$$.S.Exception)
                                                {
                                                    if (retry-- > 0)
                                                    {
                                                        continue;
                                                    }
                                                    throw $e;
                                                }
                                                else
                                                {
                                                    throw $e;
                                                }
                                            }
                                            break;
                                        }
                                        while(true);
                                    }
                                    while(status !== 2/*FirmwareUpdateStatus.Finished*/);
                                    updateCommand = this.otaUpdateBuilder.ContinueUpdate(updateCommand, status, offset, 1024);
                                    progress?.Invoke(updateCommand);
                                }
                                else 
                                {
                                    throw new $.$$.S.Exception().$ctor$4("Error starting update");
                                }
                            }
                            else 
                            {
                                throw new $.$$.S.Exception().$ctor$4("Error composing update packet");
                            }
                        }
                        catch(e)
                        {
                            _ = device.LCICO$IUpdatableDevice$CancelUpdate();
                            this.updating.Remove$1(device);
                            throw e;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014868129)
            
            //--TRIMMABLE-BOUNDARY-START(34360162465)
            /*Task */ Invoke(/*IUpdatableDevice*/ context, /*PipelineDelegate<IUpdatableDevice>*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360162465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.updating.ContainsKey(context))
                {
                    this.updating.set_Item(context, false);
                    try
                    {
                        _ = this.RunOTAUpdateCommander(context, null, null);
                    }
                    catch($e)
                    {
                    }
                }
                return super.Invoke(context, next);
            }
            //--TRIMMABLE-BOUNDARY-END(34360162465)
            
            //--TRIMMABLE-BOUNDARY-START(77309835425)
            /*Task */ Update(/*IUpdatableDevice*/ device, /*IOTDeviceFirmwareModel?*/ firmware, /*Action<IOTDeviceFirmwareUpdatingModel>?*/ progress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309835425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RunOTAUpdateCommander(device, firmware, progress);
            }
            //--TRIMMABLE-BOUNDARY-END(77309835425)
            
            //--TRIMMABLE-BOUNDARY-START(42950097057)
            /*int */ get Order()
            {
                return ((-2147483648/*int.MinValue*/ + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42950097057)
            
            //--TRIMMABLE-BOUNDARY-START(25770227873)
            /*Task */ Invoke$1(/*IConnectionClient*/ context, /*PipelineDelegate<IConnectionClient>*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770227873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return next.Invoke(context);
            }
            //--TRIMMABLE-BOUNDARY-END(25770227873)
            
            //--TRIMMABLE-BOUNDARY-START(47245064353)
            /*ushort*/ static OTA_BEGIN_REQUEST_PREFIX = 22528;
            //--TRIMMABLE-BOUNDARY-END(47245064353)
            
            //--TRIMMABLE-BOUNDARY-START(51540031649)
            /*ushort*/ static OTA_BEGIN_RESPONSE_PREFIX = 22529;
            //--TRIMMABLE-BOUNDARY-END(51540031649)
            
            //--TRIMMABLE-BOUNDARY-START(55834998945)
            /*ushort*/ static OTA_CONTINUE_REQUEST_PREFIX = 22530;
            //--TRIMMABLE-BOUNDARY-END(55834998945)
            
            //--TRIMMABLE-BOUNDARY-START(60129966241)
            /*ushort*/ static OTA_CONTINUE_RESPONSE_PREFIX = 22531;
            //--TRIMMABLE-BOUNDARY-END(60129966241)
            
            //--TRIMMABLE-BOUNDARY-START(64424933537)
            /*ushort*/ static OTA_NONE_RESPONSE_PREFIX = 22532;
            //--TRIMMABLE-BOUNDARY-END(64424933537)
            
            //--TRIMMABLE-BOUNDARY-START(555169)
            static $_iSmartOTABegin;
            static get iSmartOTABegin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(555169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$cDvV.LCISU.FirmwareUpdater;
                return $cls.$_iSmartOTABegin ??= $asm.$ncls(`$cDvV.LCISU.FirmwareUpdater.iSmartOTABegin`, ($self) => class iSmartOTABegin extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(25770358945)
                    /*string?*/ FamilyName = null;
                    //--TRIMMABLE-BOUNDARY-END(25770358945)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014999201)
                    /*string?*/ Name = null;
                    //--TRIMMABLE-BOUNDARY-END(73014999201)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065326241)
                    /*int*/ FirmwareVersion = 0;
                    //--TRIMMABLE-BOUNDARY-END(30065326241)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720031905)
                    /*int*/ HardwareVersion = 0;
                    //--TRIMMABLE-BOUNDARY-END(68720031905)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475391649)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475391649);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475391649)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475391649)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475391649)
                    
                    static $h = 555169;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770358945),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655260833,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604933793,
        "f": 83886081
      },
      "n": "FamilyName",
      "d": 555169,
      "h": 25770358945,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770358945),
//--TRIMMABLE-BOUNDARY-START(73014999201),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425064609,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374737569,
        "f": 83886081
      },
      "n": "Name",
      "d": 555169,
      "h": 73014999201,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014999201),
//--TRIMMABLE-BOUNDARY-START(30065326241),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245195425,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194868385,
        "f": 83886081
      },
      "n": "FirmwareVersion",
      "d": 555169,
      "h": 30065326241,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065326241),
//--TRIMMABLE-BOUNDARY-START(68720031905),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835130017,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784802977,
        "f": 83886081
      },
      "n": "HardwareVersion",
      "d": 555169,
      "h": 68720031905,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720031905)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475391649),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 555169,
      "h": 21475391649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475391649)
  ],
  "d": 424097,
  "h": 555169
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Updater.FirmwareUpdater+iSmartOTABegin`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Updater${separator}FirmwareUpdater${separator}iSmartOTABegin`; }
                }, $cls, ($v) => $cls.$_iSmartOTABegin = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(555169)
            
            //--TRIMMABLE-BOUNDARY-START(489633)
            static $_IOTDeviceFirmwareUpdatingModelKey;
            static get IOTDeviceFirmwareUpdatingModelKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$cDvV.LCISU.FirmwareUpdater;
                return $cls.$_IOTDeviceFirmwareUpdatingModelKey ??= $asm.$nstr(`$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey`, ($self) => class IOTDeviceFirmwareUpdatingModelKey extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(21475326113)
                    /*ClientConnectionIdentity*/ id;
                    //--TRIMMABLE-BOUNDARY-END(21475326113)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590424225)
                    $ctor$3(/*ClientConnectionIdentity*/ id)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590424225);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.id = $.$clone(id);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590424225)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180358817)
                    /*int */ GetHashCode()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180358817);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.id.GetHashCode();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180358817)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885391521)
                    /*bool */ Equals$1(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885391521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let e;
                        if ($.$is(obj, $.$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey, { set $v($v){ e = $v; } }))
                        {
                            return $.$KuVO.LCFCC.ClientConnectionIdentity.op_Equality(e.id, this.id);
                        }
                        return super.Equals$1(obj);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885391521)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295456929)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295456929);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295456929)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295456929)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295456929)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.id = this.id.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(21475326113)
                        this.id = $.$default($.$KuVO.LCFCC.ClientConnectionIdentity);
                        //--TRIMMABLE-BOUNDARY-END(21475326113)
                        
                    }
                    static $h = 489633;
                    static $z = 16;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180358817),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 489633,
      "h": 17180358817,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180358817),
//--TRIMMABLE-BOUNDARY-START(12885391521),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 489633,
      "h": 12885391521,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885391521)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475326113),
    {
      "t": 323246,
      "n": "id",
      "d": 489633,
      "h": 21475326113,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475326113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590424225),
    {
      "p": [
        {
          "n": "id",
          "p": 323246
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 489633,
      "h": 8590424225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590424225),
//--TRIMMABLE-BOUNDARY-START(4295456929),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 489633,
      "h": 4295456929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295456929)
  ],
  "d": 424097,
  "h": 489633
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Updater.FirmwareUpdater+IOTDeviceFirmwareUpdatingModelKey`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Updater${separator}FirmwareUpdater${separator}IOTDeviceFirmwareUpdatingModelKey`; }
                }, $cls, ($v) => $cls.$_IOTDeviceFirmwareUpdatingModelKey = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(489633)
            
            //--TRIMMABLE-BOUNDARY-START(85899770017)
            /*IEnumerable<IOTDeviceFirmwareUpdatingModel> */ get Updating()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475260577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let keys = $.$DJRY.LCFCD.MemoryCacheExtensions.GetKeys$1($.$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey, this.memoryCache);
                return $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel), $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel, $.$sl.SL.Enumerable.Where($.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel), $.$sl.SL.Enumerable.Select$1($.$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey, $.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel), keys, new ($.$$.S.Func$$$($.$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey, $.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel)))().$ctor(this,  (/*k*/ k) =>
                {
                    /*var*/ let value;
                    /*var*/ let got = $.$meca.MECM.CacheExtensions.TryGetValue($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel, this.memoryCache, $.$clone(k), $.$ref(() => value, ($v) => value = $v, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel));
                    return new ($.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel))().$ctor$3(got, value);
                }, $DXGEgj ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel).$h,"p":[{"n":"k","p":489633}],"n":"","d":424097,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel), $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.Item1;
                }, $BSYnnh ??= {"r":262145,"p":[{"n":"i","p":$.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel).$h}],"n":"","d":424097,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel), $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.Item2;
                }, $TyGoGk ??= {"r":46110097,"p":[{"n":"i","p":$.$$.S.ValueTuple$$$($.$$.S.Boolean, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel).$h}],"n":"","d":424097,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(85899770017)
            
            //--TRIMMABLE-BOUNDARY-START(30065195169)
            /*Task *//*async*/  Invoke$2(/*IConnectionMessage*/ context, /*PipelineDelegate<IConnectionMessage>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t16, $r16;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065195169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (context.LCFCC$IConnectionMessage$Direction === 0/*MessageDirection.In*/)
                    {
                        /*PacketBuilder*/ let packet = new $.$fPer.LCFCD.PacketBuilder().$ctor$1($.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(context.LCFCC$IConnectionMessage$Data));
                        /*int*/ let header = packet.GetWord(-1, 0);
                        if (header === 22528/*OTA_BEGIN_REQUEST_PREFIX*/)
                        {
                            /*var*/ let begin = packet.Get($.$cDvV.LCISU.FirmwareUpdater.iSmartOTABegin, null, null);
                            if (begin.FamilyName === context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id.FamilyName)
                            {
                                let $t6, $r6;
                                /*var*/ let firmware = ($t6 = this.otaUpdateBuilder.CheckUpdate(begin.FamilyName, context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id.UniqueId, begin.FirmwareVersion), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                if (firmware !== null)
                                {
                                    let $t7, $r7;
                                    let $t9, $r9;
                                    /*var*/ let updatePacket = ($t7 = this.otaUpdateBuilder.BeginUpdate(firmware, context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id.UniqueId, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                    $.$meca.MECM.CacheExtensions.Set($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel, this.memoryCache, new $.$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey().$ctor$3(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id), updatePacket, (() =>
                                    {
                                        //new $.$meca.MECM.MemoryCacheEntryOptions()
                                        const $t8 = $.$meca.MECM.MemoryCacheEntryOptions;
                                        const $i8 = new $t8();
                                        $i8.$ctor$1();
                                        $i8.SlidingExpiration = $.$$.S.TimeSpan.FromMinutes$2(5n);
                                        return $i8;
                                    })());
                                    /*PacketBuilder*/ let responsePacket = new $.$fPer.LCFCD.PacketBuilder().$ctor$2(2048);
                                    responsePacket.Push$11(22529/*OTA_BEGIN_RESPONSE_PREFIX*/, 0);
                                    responsePacket.PushT($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel, updatePacket, null);
                                    ($t9 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Write$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, (() =>
                                    {
                                        //new $.$KuVO.LCFCC.ConnectionMessage()
                                        const $t10 = $.$KuVO.LCFCC.ConnectionMessage;
                                        const $i10 = new $t10();
                                        $i10.$ctor$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(responsePacket.Packet));
                                        $i10.Id = context.LCFCC$IConnectionMessage$Id;
                                        return $i10;
                                    })(), true), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                    return $.$$.N.AsyncResolver.Result($asnycContext,);
                                }
                                else 
                                {
                                    let $t11, $r11;
                                    /*PacketBuilder*/ let responsePacket = new $.$fPer.LCFCD.PacketBuilder().$ctor$2(2048);
                                    responsePacket.Push$11(22532/*OTA_NONE_RESPONSE_PREFIX*/, 0);
                                    ($t11 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Write$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, (() =>
                                    {
                                        //new $.$KuVO.LCFCC.ConnectionMessage()
                                        const $t12 = $.$KuVO.LCFCC.ConnectionMessage;
                                        const $i12 = new $t12();
                                        $i12.$ctor$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(responsePacket.Packet));
                                        $i12.Id = context.LCFCC$IConnectionMessage$Id;
                                        return $i12;
                                    })(), true), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                }
                            }
                        }
                        else if (header === 22530/*OTA_CONTINUE_REQUEST_PREFIX*/)
                        {
                            /*IOTDeviceFirmwareUpdatingModel?*/ let updatePacket;
                            if ($.$meca.MECM.CacheExtensions.TryGetValue($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel, this.memoryCache, new $.$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey().$ctor$3(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id), $.$ref(() => updatePacket, ($v) => updatePacket = $v, $.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel)) && updatePacket !== null)
                            {
                                let $t14, $r14;
                                /*FirmwareUpdateStatus*/ let status = $.$cast(packet.GetByte(-1), $.$XBGm.LCICO.FirmwareUpdateStatus);
                                /*int*/ let offset = packet.GetSDWord(-1, 0);
                                /*int*/ let size = packet.GetWord(-1, 0);
                                updatePacket = this.otaUpdateBuilder.ContinueUpdate(updatePacket, status, offset, size);
                                /*PacketBuilder*/ let responsePacket = new $.$fPer.LCFCD.PacketBuilder().$ctor$2(((size + 128) | 0));
                                responsePacket.Push$11(22531/*OTA_CONTINUE_RESPONSE_PREFIX*/, 0);
                                responsePacket.PushT($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel, updatePacket, null);
                                ($t14 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Write$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, (() =>
                                {
                                    //new $.$KuVO.LCFCC.ConnectionMessage()
                                    const $t15 = $.$KuVO.LCFCC.ConnectionMessage;
                                    const $i15 = new $t15();
                                    $i15.$ctor$1(context.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Interface, context.LCFCC$IConnectionMessage$Client, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(responsePacket.Packet));
                                    $i15.Id = context.LCFCC$IConnectionMessage$Id;
                                    return $i15;
                                })(), true), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                        }
                    }
                    ($t16 = next.Invoke(context), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065195169)
            
            //--TRIMMABLE-BOUNDARY-START(4340749713)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IFirmwareUpdater.Update(LivingThing.Core.IOT.Common.OTA.IUpdatableDevice, LivingThing.Core.IOT.Common.OTA.IOTDeviceFirmwareModel?, System.Action<LivingThing.Core.IOT.Common.OTA.IOTDeviceFirmwareUpdatingModel>?)
            LCICO$IFirmwareUpdater$Update()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4340749713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Update(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4340749713)
            
            //--TRIMMABLE-BOUNDARY-START(8590770090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>.Order.get
            get LCFCP$IPipeline$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770090)
            
            //--TRIMMABLE-BOUNDARY-START(12885737386)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>.Invoke(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>)
            LCFCP$IPipeline$$$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737386)
            
            //--TRIMMABLE-BOUNDARY-START(8590770090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>.Order.get
            get LCFCP$IPipeline$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770090)
            
            //--TRIMMABLE-BOUNDARY-START(12885737386)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>.Invoke(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>)
            LCFCP$IPipeline$$$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737386)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81604802721)
                this.updating = new ($.$$.SCG.Dictionary$$$($.$XBGm.LCICO.IUpdatableDevice, $.$$.S.Boolean))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(81604802721)
                
            }
            static $h = 424097;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fXpo.LCFCPC.BasePipeline$$($.$XBGm.LCICO.IUpdatableDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950097057),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885325985,
        "f": 50364417
      },
      "n": "Order",
      "d": 424097,
      "h": 42950097057,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950097057),
//--TRIMMABLE-BOUNDARY-START(85899770017),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475260577,
        "f": 50331649
      },
      "n": "Updating",
      "d": 424097,
      "h": 85899770017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899770017)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73014868129),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 46372241
        },
        {
          "n": "firmware",
          "p": 45847953,
          "f": 65
        },
        {
          "n": "progress",
          "p": $.$$.S.Action$$($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel).$h,
          "f": 65
        }
      ],
      "n": "RunOTAUpdateCommander",
      "d": 424097,
      "h": 73014868129,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73014868129),
//--TRIMMABLE-BOUNDARY-START(34360162465),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 46372241
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$XBGm.LCICO.IUpdatableDevice).$h
        }
      ],
      "n": "Invoke",
      "d": 424097,
      "h": 34360162465,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360162465),
//--TRIMMABLE-BOUNDARY-START(77309835425),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 46372241
        },
        {
          "n": "firmware",
          "p": 45847953,
          "f": 65
        },
        {
          "n": "progress",
          "p": $.$$.S.Action$$($.$XBGm.LCICO.IOTDeviceFirmwareUpdatingModel).$h,
          "f": 65
        }
      ],
      "n": "Update",
      "d": 424097,
      "h": 77309835425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309835425),
//--TRIMMABLE-BOUNDARY-START(25770227873),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1568430
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionClient).$h
        }
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 424097,
      "h": 25770227873,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770227873),
//--TRIMMABLE-BOUNDARY-START(30065195169),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1961646
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "Invoke",
      "o": "@$2",
      "d": 424097,
      "h": 30065195169,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30065195169)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655129761),
    {
      "t": 1114214,
      "n": "memoryCache",
      "d": 424097,
      "h": 38655129761,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655129761),
//--TRIMMABLE-BOUNDARY-START(81604802721),
    {
      "t": $.$$.SCG.Dictionary$$$($.$XBGm.LCICO.IUpdatableDevice, $.$$.S.Boolean).$h,
      "n": "updating",
      "d": 424097,
      "h": 81604802721,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81604802721),
//--TRIMMABLE-BOUNDARY-START(68719900833),
    {
      "t": 45585809,
      "n": "otaUpdateBuilder",
      "d": 424097,
      "h": 68719900833,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68719900833),
//--TRIMMABLE-BOUNDARY-START(47245064353),
    {
      "t": 589825,
      "n": "OTA_BEGIN_REQUEST_PREFIX",
      "d": 424097,
      "h": 47245064353,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245064353),
//--TRIMMABLE-BOUNDARY-START(51540031649),
    {
      "t": 589825,
      "n": "OTA_BEGIN_RESPONSE_PREFIX",
      "d": 424097,
      "h": 51540031649,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540031649),
//--TRIMMABLE-BOUNDARY-START(55834998945),
    {
      "t": 589825,
      "n": "OTA_CONTINUE_REQUEST_PREFIX",
      "d": 424097,
      "h": 55834998945,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834998945),
//--TRIMMABLE-BOUNDARY-START(60129966241),
    {
      "t": 589825,
      "n": "OTA_CONTINUE_RESPONSE_PREFIX",
      "d": 424097,
      "h": 60129966241,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129966241),
//--TRIMMABLE-BOUNDARY-START(64424933537),
    {
      "t": 589825,
      "n": "OTA_NONE_RESPONSE_PREFIX",
      "d": 424097,
      "h": 64424933537,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64424933537)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295391393),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "http",
          "p": 6488117
        },
        {
          "n": "cache",
          "p": 1114214
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 424097,
      "h": 4295391393,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295391393)
  ],
  "h": 424097
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipeline$$($.$XBGm.LCICO.IUpdatableDevice), $.$XBGm.LCICO.IFirmwareUpdater, $.$KuVO.LCFCC.IConnectionEndPoint, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionClient), $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage) ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$cDvV.LCISU.FirmwareUpdater.iSmartOTABegin, $.$cDvV.LCISU.FirmwareUpdater.IOTDeviceFirmwareUpdatingModelKey ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Updater.FirmwareUpdater`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Updater${separator}FirmwareUpdater`; }
        });
        //--TRIMMABLE-BOUNDARY-END(424097)
        
        

        //--TRIMMABLE-BOUNDARY-START(620705)
        $asm.$cls(`$cDvV.LCISU.iSmartDeviceUpdater`, ($self) => class iSmartDeviceUpdater extends $.$fXpo.LCFCPC.BasePipeline$$($.$NXre.LCID.SmartDeviceBase)
        {
            //--TRIMMABLE-BOUNDARY-START(4295588001)
            $ctor$2(/*IServerRemoteService*/ server, /*HttpClient*/ http, /*IMemoryCache*/ cache)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295588001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.updater = new $.$cDvV.LCISU.FirmwareUpdater().$ctor$2(server, http, cache);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295588001)
            
            //--TRIMMABLE-BOUNDARY-START(12885522593)
            /*FirmwareUpdater*/ updater = null;
            //--TRIMMABLE-BOUNDARY-END(12885522593)
            
            //--TRIMMABLE-BOUNDARY-START(8590555297)
            /*Task */ Invoke(/*SmartDeviceBase*/ context, /*PipelineDelegate<SmartDeviceBase>*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590555297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sDevice;
                if ($.$is(context, $.$XBGm.LCICDi.IiSmartIOTDevice, { set $v($v){ sDevice = $v; } }) && sDevice.LCICI$IIOTDevice$Settings.LCICI$IIOTDeviceSettings$AutoFirmwareUpdate)
                {
                    this.updater.Invoke($.$cast(sDevice, $.$XBGm.LCICO.IUpdatableDevice), new ($.$fXpo.LCFCP.PipelineDelegate$$($.$XBGm.LCICO.IUpdatableDevice))().$ctor(this,  (/*n*/ n) =>
                    {
                        return $.$$.STT.Task.CompletedTask;
                    }, $aPEahc ??= {"r":178454529,"p":[{"n":"n","p":46372241}],"n":"","d":620705,"h":0,"f":17825794}));
                }
                return super.Invoke(context, next);
            }
            //--TRIMMABLE-BOUNDARY-END(8590555297)
            
            static $h = 620705;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fXpo.LCFCPC.BasePipeline$$($.$NXre.LCID.SmartDeviceBase); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590555297),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1501085
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$NXre.LCID.SmartDeviceBase).$h
        }
      ],
      "n": "Invoke",
      "d": 620705,
      "h": 8590555297,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590555297)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885522593),
    {
      "t": 424097,
      "n": "updater",
      "d": 620705,
      "h": 12885522593,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885522593)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295588001),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "http",
          "p": 6488117
        },
        {
          "n": "cache",
          "p": 1114214
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 620705,
      "h": 4295588001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295588001)
  ],
  "h": 620705
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipeline$$($.$NXre.LCID.SmartDeviceBase) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Updater.iSmartDeviceUpdater`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Updater${separator}iSmartDeviceUpdater`; }
        });
        //--TRIMMABLE-BOUNDARY-END(620705)
        
        

        //--TRIMMABLE-BOUNDARY-START(96417)
        $asm.$cls(`$cDvV.LCISD.SmartDeviceSecurityProvider`, ($self) => class SmartDeviceSecurityProvider extends $.$fXpo.LCFCPC.BasePipeline$$($.$XBGm.LCICS.ChallengeStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295063713)
            /*IMemoryCache*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4295063713)
            
            //--TRIMMABLE-BOUNDARY-START(30064867489)
            /*IDeviceStore*/ DeviceStore = null;
            //--TRIMMABLE-BOUNDARY-END(30064867489)
            
            //--TRIMMABLE-BOUNDARY-START(34359834785)
            /*IEnumerable<IIOTDeviceFamily>*/ Families = null;
            //--TRIMMABLE-BOUNDARY-END(34359834785)
            
            //--TRIMMABLE-BOUNDARY-START(21474932897)
            /*byte[]*/ static DefaultSecret = null;
            //--TRIMMABLE-BOUNDARY-END(21474932897)
            
            //--TRIMMABLE-BOUNDARY-START(12884998305)
            $ctor$2(/*IMemoryCache*/ cache, /*IDeviceStore*/ deviceStore, /*IEnumerable<IIOTDeviceFamily>*/ families, /*IEnumerable<IIOTDeviceFamilyProvider>*/ familyProviders)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884998305);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._cache = cache;
                    this.DeviceStore = deviceStore;
                    this.Families = $.$sl.SL.Enumerable.Concat($.$XBGm.LCICI.IIOTDeviceFamily, families, $.$sl.SL.Enumerable.SelectMany$2($.$XBGm.LCICI.IIOTDeviceFamilyProvider, $.$XBGm.LCICI.IIOTDeviceFamily, familyProviders, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceFamilyProvider, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily)))().$ctor(this,  (/*f*/ f) =>
                    {
                        return f;
                    }, $rerJbj ??= {"r":$.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h,"p":[{"n":"f","p":26973585}],"n":"","d":96417,"h":0,"f":17825794})));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884998305)
            
            //--TRIMMABLE-BOUNDARY-START(68719573153)
            /*bool */ SupportsSecuredChannel(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719573153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (client.LCFCC$IConnectionClient$Parent !== null)
                {
                    return false;
                }
                /*LivingThing.Core.Frameworks.Common.Connection.IConnectionContext?*/ let __ca1__;
                if ((__ca1__ = client.LCFCC$IConnectionClient$Interface.LCFCC$IConnectionInterface$Context) !== null ? ((__ca1__.LCFCC$IConnectionContext$Flags & (2/*ConnectionFlags.SymmetricEncryption*/)) == (2/*ConnectionFlags.SymmetricEncryption*/)) : false)
                {
                    /*var*/ let family = $.$sl.SL.Enumerable.SingleOrDefault$1($.$XBGm.LCICI.IIOTDeviceFamily, this.Families, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceFamily, $.$$.S.Boolean))().$ctor(this,  (/*f*/ f) =>
                    {
                        return f.LCFC$INamed$Name === client.LCFCC$IConnectionClient$Id.FamilyName;
                    }, $bsGShj ??= {"r":262145,"p":[{"n":"f","p":26711441}],"n":"","d":96417,"h":0,"f":17825794}));
                    if ((family?.LCICI$IIOTDeviceFamily$DeviceDescriptor ?? null) !== null)
                    {
                        return ((family.LCICI$IIOTDeviceFamily$DeviceDescriptor.Securities & (2/*IOTDeviceSecurities.AdvancedEncryptionStandard*/)) == (2/*IOTDeviceSecurities.AdvancedEncryptionStandard*/));
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(68719573153)
            
            //--TRIMMABLE-BOUNDARY-START(64424605857)
            /*bool */ SupportsChallenge(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424605857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (client.LCFCC$IConnectionClient$Parent !== null)
                {
                    return false;
                }
                if (((client.LCFCC$IConnectionClient$Interface.LCFCC$IConnectionInterface$Context.LCFCC$IConnectionContext$Flags & (1/*ConnectionFlags.Challenge*/)) == (1/*ConnectionFlags.Challenge*/)))
                {
                    /*var*/ let family = $.$sl.SL.Enumerable.SingleOrDefault$1($.$XBGm.LCICI.IIOTDeviceFamily, this.Families, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceFamily, $.$$.S.Boolean))().$ctor(this,  (/*f*/ f) =>
                    {
                        return f.LCFC$INamed$Name === client.LCFCC$IConnectionClient$Id.FamilyName;
                    }, $bwiadg ??= {"r":262145,"p":[{"n":"f","p":26711441}],"n":"","d":96417,"h":0,"f":17825794}));
                    if (family !== null)
                    {
                        return ((family.LCICI$IIOTDeviceFamily$DeviceDescriptor.Securities & (1/*IOTDeviceSecurities.ChallengeHandShakeAuthenticationProtocol*/)) == (1/*IOTDeviceSecurities.ChallengeHandShakeAuthenticationProtocol*/));
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(64424605857)
            
            //--TRIMMABLE-BOUNDARY-START(51539703969)
            /*Task<bool?> *//*async*/  HasOwnSecretAsync(/*string*/ deviceId)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Nullable$$($.$$.S.Boolean)), $.$typeNullable($.$$.S.Boolean), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539703969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*IIOTDeviceModel*/ let device = null;
                    try
                    {
                        let $t1, $r1;
                        device = ($t1 = this.DeviceStore.LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Interface$IIOTDeviceModel$GetByIdAsync(deviceId), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    catch($e)
                    {
                    }
                    if (device === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    if (!$.$$.S.String.IsNullOrEmpty((device.LCICI$IIOTDeviceModel$Settings?.LCICI$IIOTDeviceSettings$Secret ?? null)))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, true);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51539703969)
            
            //--TRIMMABLE-BOUNDARY-START(47244736673)
            /*Task<byte[]> *//*async*/  GetSecretAsync(/*string*/ deviceId)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$typeArray($.$$.S.Byte)), $.$typeArray($.$$.S.Byte), async ($asnycContext) => 
                {
                    /*var*/ let secret;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244736673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.trySecret.TryGetValue(deviceId, $.$ref(() => secret, ($v) => secret = $v, $.$cDvV.LCISD.SmartDeviceSecurityProvider.AuthContext)))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, secret.Secret);
                    }
                    /*var*/ let result = ($t3 = $.$meca.MECM.CacheExtensions.GetOrCreateAsync$1($.$typeArray($.$$.S.Byte), this._cache, `${$.$strNN("SmartDeviceSecurityProvider")}.${$.$strNN("GetSecretAsync")}.${$.$strNN(deviceId)}`, new ($.$$.S.Func$$$($.$meca.MECM.ICacheEntry, $.$$.STT.Task$$($.$typeArray($.$$.S.Byte))))().$ctor(this, /*async*/  (/**/ entry) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$typeArray($.$$.S.Byte)), $.$typeArray($.$$.S.Byte), async ($asnycContext) => 
                        {
                            entry.MECM$ICacheEntry$SlidingExpiration = $.$$.S.TimeSpan.FromMinutes$2(5n);
                            try
                            {
                                let $t4, $r4;
                                /*var*/ let device = ($t4 = this.DeviceStore.LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Interface$IIOTDeviceModel$GetByIdAsync(deviceId), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                if (device !== null)
                                {
                                    if (!$.$$.S.String.IsNullOrEmpty((device.LCICI$IIOTDeviceModel$Settings?.LCICI$IIOTDeviceSettings$Secret ?? null)))
                                    {
                                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.S.Convert.FromBase64String(device.LCICI$IIOTDeviceModel$Settings.LCICI$IIOTDeviceSettings$Secret));
                                    }
                                }
                            }
                            catch($e)
                            {
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$cDvV.LCISD.SmartDeviceSecurityProvider.DefaultSecret);
                        });
                    }, $tFjiac ??= {"r":$.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,"p":[{"n":"entry","p":1048678}],"n":"","d":96417,"h":0,"f":17829890})), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47244736673)
            
            //--TRIMMABLE-BOUNDARY-START(42949769377)
            /*byte[] */ GetHash(/*string*/ deviceId, /*string*/ password)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949769377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                password = $.$$.S.String.Trim.call(password);
                /*SHA256*/ let sha1 = $.$sscr.SSC.SHA256.Create$2();
                /*var*/ let hashing = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((password.length + deviceId.length) | 0)], null);
                $.$$.S.Array.Copy($.$$.ST.Encoding.ASCII.GetBytes$8(password), 0, hashing, 0, password.length);
                $.$$.S.Array.Copy($.$$.ST.Encoding.ASCII.GetBytes$8(deviceId), 0, hashing, password.length, deviceId.length);
                return sha1.ComputeHash$1(hashing);
            }
            //--TRIMMABLE-BOUNDARY-END(42949769377)
            
            //--TRIMMABLE-BOUNDARY-START(161953)
            static $_AuthContext;
            static get AuthContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(161953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$cDvV.LCISD.SmartDeviceSecurityProvider;
                return $cls.$_AuthContext ??= $asm.$ncls(`$cDvV.LCISD.SmartDeviceSecurityProvider.AuthContext`, ($self) => class AuthContext extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(34359900321)
                    /*byte[]*/ Secret = null;
                    //--TRIMMABLE-BOUNDARY-END(34359900321)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834736801)
                    /*TaskCompletionSource<bool>*/ Task = null;
                    //--TRIMMABLE-BOUNDARY-END(55834736801)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885063841)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885063841);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885063841)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885063841)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885063841)
                    
                    static $h = 161953;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359900321),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474998433,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42949834913,
        "f": 83886081
      },
      "n": "Secret",
      "d": 161953,
      "h": 34359900321,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359900321),
//--TRIMMABLE-BOUNDARY-START(55834736801),
    {
      "p": $.$$.STT.TaskCompletionSource$$($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064933025,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539769505,
        "f": 83886081
      },
      "n": "Task",
      "d": 161953,
      "h": 55834736801,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834736801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885063841),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 161953,
      "h": 12885063841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885063841)
  ],
  "d": 96417,
  "h": 161953
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Device.SmartDeviceSecurityProvider+AuthContext`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Device${separator}SmartDeviceSecurityProvider${separator}AuthContext`; }
                }, $cls, ($v) => $cls.$_AuthContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(161953)
            
            //--TRIMMABLE-BOUNDARY-START(73014540449)
            /*Dictionary<string, AuthContext>*/ trySecret = null;
            //--TRIMMABLE-BOUNDARY-END(73014540449)
            
            //--TRIMMABLE-BOUNDARY-START(17179965601)
            /*Task<bool> */ Authenticate(/*string*/ deviceId, /*string*/ password)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179965601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TaskCompletionSource<bool>*/ let tcs = new ($.$$.STT.TaskCompletionSource$$($.$$.S.Boolean))().$ctor$1();
                this.trySecret.set_Item(deviceId, (() =>
                {
                    //new $.$cDvV.LCISD.SmartDeviceSecurityProvider.AuthContext()
                    const $t5 = $.$cDvV.LCISD.SmartDeviceSecurityProvider.AuthContext;
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.Secret = this.GetHash(deviceId, password);
                    $i5.Task = tcs;
                    return $i5;
                })());
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(17179965601)
            
            //--TRIMMABLE-BOUNDARY-START(60129638561)
            /*Task *//*async*/  SetSecretAsync(/*string*/ deviceId, /*string?*/ password)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129638561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let device = ($t6 = this.DeviceStore.LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Interface$IIOTDeviceModel$GetByIdAsync(deviceId), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    if (!$.$$.S.String.IsNullOrEmpty(password))
                    {
                        /*var*/ let hash = this.GetHash(deviceId, password);
                        $.$fPer.LCFCP$1.PropertyExtension.SetValue(device.LCICI$IIOTDeviceModel$Settings, "Secret", $.$$.S.Convert.ToBase64String$3(hash));
                    }
                    else 
                    {
                        $.$fPer.LCFCP$1.PropertyExtension.SetValue(device.LCICI$IIOTDeviceModel$Settings, "Secret", null);
                    }
                    ($t7 = this.DeviceStore.LCICD$ISmartDataStoreT$$$SaveAsync(device), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60129638561)
            
            //--TRIMMABLE-BOUNDARY-START(38654802081)
            /*ChallengeState */ GetAuthenticationState(/*string*/ deviceId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654802081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.deviceAuthetication.ContainsKey(deviceId))
                {
                    return this.deviceAuthetication.get_Item(deviceId);
                }
                return 0/*ChallengeState.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38654802081)
            
            //--TRIMMABLE-BOUNDARY-START(25769900193)
            /*Dictionary<string, ChallengeState>*/ deviceAuthetication = null;
            //--TRIMMABLE-BOUNDARY-END(25769900193)
            
            //--TRIMMABLE-BOUNDARY-START(55834671265)
            /*Task *//*async*/  Invoke(/*ChallengeStatus*/ context, /*PipelineDelegate<ChallengeStatus>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834671265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.deviceAuthetication.set_Item(context.DeviceId, context.State);
                    if (this.trySecret.ContainsKey(context.DeviceId) && (context.State === 2/*ChallengeState.Authenticated*/ || context.State === 3/*ChallengeState.NotAuthenticated*/))
                    {
                        /*var*/ let auth = this.trySecret.get_Item(context.DeviceId);
                        auth.Task.SetResult(context.State === 2/*ChallengeState.Authenticated*/);
                        this.trySecret.Remove$1(context.DeviceId);
                    }
                    ($t8 = next.Invoke(context), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55834671265)
            
            //--TRIMMABLE-BOUNDARY-START(30116189585)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IDeviceSecurityProvider.SupportsSecuredChannel(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCICS$IDeviceSecurityProvider$SupportsSecuredChannel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30116189585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SupportsSecuredChannel(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30116189585)
            
            //--TRIMMABLE-BOUNDARY-START(25821222289)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IDeviceSecurityProvider.SupportsChallenge(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCICS$IDeviceSecurityProvider$SupportsChallenge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25821222289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SupportsChallenge(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25821222289)
            
            //--TRIMMABLE-BOUNDARY-START(8641353105)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IDeviceSecurityProvider.GetAuthenticationState(string)
            LCICS$IDeviceSecurityProvider$GetAuthenticationState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8641353105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAuthenticationState(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8641353105)
            
            //--TRIMMABLE-BOUNDARY-START(17231287697)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IDeviceSecurityProvider.HasOwnSecretAsync(string)
            LCICS$IDeviceSecurityProvider$HasOwnSecretAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17231287697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasOwnSecretAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17231287697)
            
            //--TRIMMABLE-BOUNDARY-START(12936320401)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IDeviceSecurityProvider.GetSecretAsync(string)
            LCICS$IDeviceSecurityProvider$GetSecretAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12936320401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSecretAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12936320401)
            
            //--TRIMMABLE-BOUNDARY-START(21526254993)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IDeviceSecurityProvider.SetSecretAsync(string, string?)
            LCICS$IDeviceSecurityProvider$SetSecretAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21526254993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetSecretAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21526254993)
            
            //--TRIMMABLE-BOUNDARY-START(4346385809)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Security.IDeviceSecurityProvider.Authenticate(string, string)
            LCICS$IDeviceSecurityProvider$Authenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4346385809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Authenticate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4346385809)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73014540449)
                this.trySecret = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$cDvV.LCISD.SmartDeviceSecurityProvider.AuthContext))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(73014540449)
                
                //--TRIMMABLE-BOUNDARY-START(25769900193)
                this.deviceAuthetication = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$XBGm.LCICS.ChallengeState))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25769900193)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8590031009)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590031009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(21474932897)
                    this.DefaultSecret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [116, 54, 119, 57, 122, 36, 67, 38, 69, 41, 72, 64, 77, 99, 81, 102, 84, 106, 87, 110, 90, 114, 52, 117, 55, 120, 33, 65, 37, 68, 42, 71], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(21474932897)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590031009)
            
            static $h = 96417;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fXpo.LCFCPC.BasePipeline$$($.$XBGm.LCICS.ChallengeStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719573153),
    {
      "r": 262145,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "SupportsSecuredChannel",
      "d": 96417,
      "h": 68719573153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719573153),
//--TRIMMABLE-BOUNDARY-START(64424605857),
    {
      "r": 262145,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "SupportsChallenge",
      "d": 96417,
      "h": 64424605857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424605857),
//--TRIMMABLE-BOUNDARY-START(51539703969),
    {
      "r": $.$$.STT.Task$$($.$$.S.Nullable$$($.$$.S.Boolean)).$h,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        }
      ],
      "n": "HasOwnSecretAsync",
      "d": 96417,
      "h": 51539703969,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(51539703969),
//--TRIMMABLE-BOUNDARY-START(47244736673),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        }
      ],
      "n": "GetSecretAsync",
      "d": 96417,
      "h": 47244736673,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(47244736673),
//--TRIMMABLE-BOUNDARY-START(42949769377),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        }
      ],
      "n": "GetHash",
      "d": 96417,
      "h": 42949769377,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949769377),
//--TRIMMABLE-BOUNDARY-START(17179965601),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        }
      ],
      "n": "Authenticate",
      "d": 96417,
      "h": 17179965601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179965601),
//--TRIMMABLE-BOUNDARY-START(60129638561),
    {
      "r": 178454529,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        }
      ],
      "n": "SetSecretAsync",
      "d": 96417,
      "h": 60129638561,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(60129638561),
//--TRIMMABLE-BOUNDARY-START(38654802081),
    {
      "r": 51221905,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        }
      ],
      "n": "GetAuthenticationState",
      "d": 96417,
      "h": 38654802081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654802081),
//--TRIMMABLE-BOUNDARY-START(55834671265),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 51352977
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$XBGm.LCICS.ChallengeStatus).$h
        }
      ],
      "n": "Invoke",
      "d": 96417,
      "h": 55834671265,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(55834671265)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295063713),
    {
      "t": 1114214,
      "n": "_cache",
      "d": 96417,
      "h": 4295063713,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295063713),
//--TRIMMABLE-BOUNDARY-START(30064867489),
    {
      "t": 1283473,
      "n": "DeviceStore",
      "d": 96417,
      "h": 30064867489,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064867489),
//--TRIMMABLE-BOUNDARY-START(34359834785),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h,
      "n": "Families",
      "d": 96417,
      "h": 34359834785,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359834785),
//--TRIMMABLE-BOUNDARY-START(21474932897),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "DefaultSecret",
      "d": 96417,
      "h": 21474932897,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21474932897),
//--TRIMMABLE-BOUNDARY-START(73014540449),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$cDvV.LCISD.SmartDeviceSecurityProvider.AuthContext).$h,
      "n": "trySecret",
      "d": 96417,
      "h": 73014540449,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73014540449),
//--TRIMMABLE-BOUNDARY-START(25769900193),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$XBGm.LCICS.ChallengeState).$h,
      "n": "deviceAuthetication",
      "d": 96417,
      "h": 25769900193,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769900193)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884998305),
    {
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "deviceStore",
          "p": 1283473
        },
        {
          "n": "families",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h
        },
        {
          "n": "familyProviders",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamilyProvider).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 96417,
      "h": 12884998305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884998305)
  ],
  "h": 96417
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipeline$$($.$XBGm.LCICS.ChallengeStatus), $.$XBGm.LCICS.IDeviceSecurityProvider ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$cDvV.LCISD.SmartDeviceSecurityProvider.AuthContext ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Services.Device.SmartDeviceSecurityProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Services${separator}Device${separator}SmartDeviceSecurityProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(96417)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Devices"));
})();
//--TRIMMABLE-BOUNDARY-END(30881)
