import * as THREE from 'https://unpkg.com';

let scene, camera, renderer;
const tanks = {};

export function init3DCanvas(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    // 1. Setup Scene & Renderer
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf3f4f6); // Light grey matching app background

    camera = new THREE.PerspectiveCamera(45, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
    camera.position.set(0, 2, 8);
    camera.lookAt(0, 0, 0);

    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);

    // 2. Realistic Studio Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight1.position.set(5, 10, 7);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.3);
    dirLight2.position.set(-5, 5, -5);
    scene.add(dirLight2);

    // 3. Create Three Tanks Side-by-Side
    // Positions: Tank 1 (-2.5), Tank 2 (0), Tank 3 (2.5)
    createTank("tank1", -2.5, 0xdbc82c); // Yellow
    createTank("tank2", 0.0, 0xc92a2a);  // Red
    createTank("tank3", 2.5, 0xd97706);  // Orange/Brown

    // 4. Animation Loop
    function animate() {
        requestAnimationFrame(animate);

        // Subtle rotation for a dynamic 3D look
        Object.values(tanks).forEach(t => {
            t.group.rotation.y = 0.2;
        });

        renderer.render(scene, camera);
    }
    animate();

    // Handle Window Resize
    window.addEventListener('resize', () => {
        if (!canvas) return;
        camera.aspect = canvas.clientWidth / canvas.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    });
}

function createTank(id, xOffset, liquidColor) {
    const group = new THREE.Group();
    group.position.x = xOffset;

    const tankHeight = 3.5;
    const tankRadius = 1.0;

    // Outer Metallic Shell Material
    const metalMaterial = new THREE.MeshStandardMaterial({
        color: 0xdddddd,
        metalness: 0.9,
        roughness: 0.2,
        side: THREE.DoubleSide
    });

    // Outer Glass/Cutout Body (Allows viewing the inside)
    const glassMaterial = new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.15,
        roughness: 0.1,
        transmission: 0.9,
        thickness: 0.1
    });

    // Top Cap Assembly
    const capGeo = new THREE.CylinderGeometry(tankRadius * 0.6, tankRadius, 0.4, 32);
    const cap = new THREE.Mesh(capGeo, metalMaterial);
    cap.position.y = tankHeight / 2 + 0.2;
    group.add(cap);

    // Tank Wall (Cylinder)
    const wallGeo = new THREE.CylinderGeometry(tankRadius, tankRadius, tankHeight, 32, 1, true);
    const wall = new THREE.Mesh(wallGeo, glassMaterial);
    group.add(wall);

    // Tank Base / Floor Rings
    const baseGeo = new THREE.CylinderGeometry(tankRadius, tankRadius, 0.1, 32);
    const base = new THREE.Mesh(baseGeo, metalMaterial);
    base.position.y = -tankHeight / 2;
    group.add(base);

    // Inner Liquid Cargo
    const liquidGeo = new THREE.CylinderGeometry(tankRadius * 0.98, tankRadius * 0.98, tankHeight, 32);
    const liquidMat = new THREE.MeshStandardMaterial({
        color: liquidColor,
        roughness: 0.1,
        metalness: 0.1,
        transparent: true,
        opacity: 0.85
    });
    const liquidMesh = new THREE.Mesh(liquidGeo, liquidMat);

    // Shift pivot point to the bottom of the fluid cylinder for intuitive scaling
    liquidMesh.geometry.translate(0, tankHeight / 2, 0);
    liquidMesh.position.y = -tankHeight / 2;
    liquidMesh.scale.y = 0.01; // Start empty

    group.add(liquidMesh);
    scene.add(group);

    // Store reference for runtime Blazor updates
    tanks[id] = {
        group: group,
        liquid: liquidMesh
    };
}

// Blazor call target to push live percentage metrics down to WebGL context
export function updateTankLevel(id, percentage) {
    if (tanks[id]) {
        // Clamp scale value between 0.01 and 1.0
        const targetScale = Math.max(0.01, Math.min(percentage / 100, 1.0));
        tanks[id].liquid.scale.y = targetScale;
    }
}
