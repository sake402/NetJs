
//--TRIMMABLE-BOUNDARY-START(55554)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Localizer.Common", 
    {
  "h": 55554,
  "f": "LivingThing.Core.Localizer.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Localizer.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Localizer.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(186626)
        $asm.$cls(`$UqSD.LCLS.LocalizerStates`, ($self) => class LocalizerStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4295153922)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295153922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295153922)
            
            //--TRIMMABLE-BOUNDARY-START(4295153922)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295153922)
            
            static $h = 186626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295153922),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 186626,
      "h": 4295153922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295153922)
  ],
  "h": 186626
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Localizer.States.LocalizerStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Localizer${separator}States${separator}LocalizerStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(186626)
        
        

        //--TRIMMABLE-BOUNDARY-START(252162)
        $asm.$cls(`$UqSD.LWLS.LocalizerSettings`, ($self) => class LocalizerSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(21475088642)
            /*int*/ CultureCookieDays = 0;
            //--TRIMMABLE-BOUNDARY-END(21475088642)
            
            //--TRIMMABLE-BOUNDARY-START(17180121346)
            /*int*/ CacheMinutes = 0;
            //--TRIMMABLE-BOUNDARY-END(17180121346)
            
            //--TRIMMABLE-BOUNDARY-START(12885154050)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885154050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885154050)
            
            //--TRIMMABLE-BOUNDARY-START(12885154050)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885154050)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475088642)
                this.CultureCookieDays = 30;
                //--TRIMMABLE-BOUNDARY-END(21475088642)
                
                //--TRIMMABLE-BOUNDARY-START(17180121346)
                this.CacheMinutes = 30;
                //--TRIMMABLE-BOUNDARY-END(17180121346)
                
            }
            static $h = 252162;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475088642),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654957826,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834827010,
        "f": 83886081
      },
      "n": "CultureCookieDays",
      "d": 252162,
      "h": 21475088642,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475088642),
//--TRIMMABLE-BOUNDARY-START(17180121346),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065023234,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244892418,
        "f": 83886081
      },
      "n": "CacheMinutes",
      "d": 252162,
      "h": 17180121346,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180121346)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885154050),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 252162,
      "h": 12885154050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885154050)
  ],
  "h": 252162
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Localizer.Settings.LocalizerSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Localizer${separator}Settings${separator}LocalizerSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(252162)
        
        

        //--TRIMMABLE-BOUNDARY-START(121090)
        $asm.$cls(`$UqSD.LCLM.LocalizerModel`, ($self) => class LocalizerModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$UqSD.LWLS.LocalizerSettings, $.$UqSD.LCLS.LocalizerStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295088386)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295088386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295088386)
            
            //--TRIMMABLE-BOUNDARY-START(4295088386)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295088386)
            
            static $h = 121090;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$UqSD.LWLS.LocalizerSettings, $.$UqSD.LCLS.LocalizerStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295088386),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 121090,
      "h": 4295088386,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295088386)
  ],
  "h": 121090
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Localizer.Models.LocalizerModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Localizer${separator}Models${separator}LocalizerModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(121090)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models"));
})();
//--TRIMMABLE-BOUNDARY-END(55554)
