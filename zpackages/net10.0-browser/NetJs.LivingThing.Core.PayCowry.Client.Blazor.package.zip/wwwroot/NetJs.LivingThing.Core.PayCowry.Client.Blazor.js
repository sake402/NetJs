
//--TRIMMABLE-BOUNDARY-START(50924)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mbc, $mefa, $mef, $mefp, $mecf, $mecj, $mia, $mil, $mexl, $mit, $mij, $sih, $wZnq, $hqRR, $sitj, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $kVHt, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $uVBI, $yleQ, $nYKj, $AvdQ, $xPgy, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $fXpo, $KuVO, $OJJQ, $UlXD, $SeJP, $mskq, $ySWu) {
    "use strict";
    let _;
    let $JDHWjb;
    let $ihgwXd;
    let $jKilCh;
    let $GxZYuc;
    let $NgXIOc;
    let $xgNakk;
    let $KiMBmc;
    let $NOVoVh;
    let $QygbIb;
    let $DtyWHd;
    let $GIdVXh;
    let $keDxqi;
    let $ZoTKgi;
    let $hmRgij;
    let $lCAJLh;
    let $DaUTUd;
    let $NMRyBa;
    let $stHMUc;
    let $EQcZIf;
    let $ulfMsk;
    let $XQwVua;
    let $XwxFNi;
    let $oMYwKb;
    let $MKTAug;
    let $oaEWNc;
    let $noSijb;
    let $mLpyld;
    let $PhPswk;
    let $YUpDEc;
    let $DULVLd;
    let $lEOvjc;
    let $QfNIdh;
    let $kKwwzk;
    let $OdpNAe;
    let $KvwJai;
    let $Bzttqb;
    let $RAkSMi;
    let $klBODh;
    let $fnpYob;
    let $FhwSma;
    let $pUzcQa;
    let $QZNsjj;
    let $LYnAff;
    let $eYdEVk;
    let $zVYRra;
    let $kPPZok;
    let $lEPURk;
    let $lVKWhd;
    let $ESeoGd;
    let $UzBvnk;
    let $LbpeLk;
    let $wqHMse;
    let $twguIc;
    let $CWaqxf;
    let $jLQnyc;
    let $SKtMUf;
    let $DynlYe;
    let $qwJqxk;
    let $rjTdGf;
    let $zKNkDa;
    let $VknqEe;
    let $okwCsb;
    let $hJKLHc;
    let $eIGEoc;
    let $vKDnbc;
    let $yTAnSj;
    let $cIOTTh;
    let $qRTsse;
    let $ORiigl;
    let $NgjvRh;
    let $PeZcXg;
    let $Ufbazc;
    let $Vwwnag;
    let $HQadOk;
    let $TPvrDj;
    let $dvnymh;
    let $DiaIYe;
    let $gaNbQj;
    let $ugzbRf;
    let $GXjRoi;
    let $bOjVoa;
    let $qxerlj;
    let $PrrnMj;
    let $aVuqQb;
    let $WTqjta;
    let $EdJmYi;
    let $NiIovc;
    let $SuQNaj;
    let $biDZVd;
    let $pgVCQd;
    let $XKZZkf;
    let $FcPWwi;
    let $oGHhsa;
    let $FOBlsg;
    let $HwXKeg;
    let $eGaDih;
    let $FhiKJg;
    let $tAlDtd;
    let $ycjmJh;
    let $AvRgcf;
    let $TmhCjc;
    let $bxxhGf;
    let $euVvMd;
    let $qiulrk;
    let $jBeNlk;
    let $VOOLXh;
    let $vXQqnd;
    let $ZQyQgb;
    let $BzDWFf;
    let $BGqVkh;
    let $ebMnta;
    let $ghgBlj;
    let $TeHbtk;
    let $zveDNd;
    let $fDTlUi;
    let $woVmxh;
    let $Qtxozk;
    let $HockYa;
    let $TfUYNe;
    let $ZajZSk;
    let $rWLqii;
    let $iouwxi;
    let $TBEIVe;
    let $DuuGGc;
    let $zxmVba;
    let $ZXvfod;
    let $WSCJRg;
    let $QeSQWd;
    let $JWqIVi;
    let $jqCSGg;
    let $DGGjwi;
    let $idMgHj;
    let $qAkwFa;
    let $yoBFPc;
    let $sbJrGb;
    let $NzkjNf;
    let $Qrkozc;
    let $aCyEOk;
    let $XSJOKc;
    let $lwCRGg;
    let $DesZQf;
    let $mtRihg;
    let $istPye;
    let $TmBnrd;
    let $EgQLYj;
    let $qRdPGd;
    let $UMoDgb;
    let $sUpAYj;
    let $oOoOmc;
    let $DpHYya;
    let $uGZaCb;
    let $kboVic;
    let $QbiNDk;
    let $YZjkWe;
    let $ehuaWg;
    let $jfzUgb;
    let $BFsLIb;
    let $clPeVd;
    let $fVzKkj;
    let $muskRd;
    let $FtIJjj;
    let $UsUJeb;
    let $HzHhGk;
    let $RqTEQk;
    let $Itthuc;
    let $MLsFtj;
    let $XNAwgl;
    let $CXbXcb;
    let $gTrkEg;
    let $ilzecc;
    let $HdRyee;
    let $BLNzll;
    let $zICzEi;
    let $Bqpzvi;
    let $ubvXdk;
    let $scybbe;
    let $TBpdlk;
    let $BWtzwh;
    let $LtiAki;
    let $ciLmKk;
    let $XzaMYf;
    let $Kpktfi;
    let $wkUmAa;
    let $roFswa;
    let $zORnrh;
    let $hMvIBh;
    let $zuOmUb;
    let $vmqlob;
    let $PRBGRk;
    let $vamzRg;
    let $wQSWrd;
    let $UPwclc;
    let $kystfa;
    let $Dlagvf;
    let $uvYIrf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.PayCowry.Client.Blazor", 
    {
  "h": 50924,
  "f": "LivingThing.Core.PayCowry.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.PayCowry.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.PayCowry.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(444140)
        $asm.$cls(`$HSAN.LCPC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295411436)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295411436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295411436)
            
            static $h = 444140;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295411436),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 444140,
      "h": 4295411436,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295411436)
  ],
  "h": 444140
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(444140)
        
        

        //--TRIMMABLE-BOUNDARY-START(378604)
        $asm.$cls(`$HSAN.LCPC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295345900)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295345900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HSAN.LCPCS.ConnectionPacketType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HSAN.LCPCS.ConnectionPacketTypeCustomAttributesProvider, $.$HSAN.LCPCS.ConnectionPacketTypeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295345900)
            
            static $h = 378604;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295345900),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 378604,
      "h": 4295345900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295345900)
  ],
  "h": 378604
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(378604)
        
        

        //--TRIMMABLE-BOUNDARY-START(902892)
        $asm.$cls(`$HSAN.LCPCS.ConnectionPacketTypeCustomAttributesProvider`, ($self) => class ConnectionPacketTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295870188)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295870188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295870188)
            
            static $h = 902892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295870188),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 902892,
      "h": 4295870188,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295870188)
  ],
  "h": 902892
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.ConnectionPacketTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}ConnectionPacketTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(902892)
        
        

        //--TRIMMABLE-BOUNDARY-START(313068)
        $asm.$cls(`$HSAN.LCPC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295280364)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295280364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$HSAN.LCPC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295280364)
            
            static $h = 313068;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295280364),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 313068,
      "h": 4295280364,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295280364)
  ],
  "h": 313068
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(313068)
        
        

        //--TRIMMABLE-BOUNDARY-START(247532)
        $asm.$cls(`$HSAN.LCPC._Imports`, ($self) => class _Imports extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590182124)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590182124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590182124)
            
            //--TRIMMABLE-BOUNDARY-START(4295214828)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295214828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295214828)
            
            //--TRIMMABLE-BOUNDARY-START(4295214828)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295214828)
            
            static $h = 247532;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590182124),
    {
      "r": 65537,
      "n": "Execute",
      "d": 247532,
      "h": 8590182124,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590182124)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295214828),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 247532,
      "h": 4295214828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295214828)
  ],
  "h": 247532
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(247532)
        
        

        //--TRIMMABLE-BOUNDARY-START(575212)
        $asm.$cls(`$HSAN.LCPC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590509804)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590509804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$HSAN.LCPCP.LoyaltyRewardSpinWheel, "LivingThing.Core.PayCowry.Client", "Pages\\LoyaltyRewardSpinWheel", "Loyalty Reward Spin Wheel", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/PayCowry/LoyaltyRewardSpinWheel" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$HSAN.LCPCP.PayCowryApp, "LivingThing.Core.PayCowry.Client", "Pages\\PayCowryApp", "Pay Cowry App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/PayCowry/{*Path}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590509804)
            
            //--TRIMMABLE-BOUNDARY-START(4295542508)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295542508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295542508)
            
            //--TRIMMABLE-BOUNDARY-START(4295542508)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295542508)
            
            static $h = 575212;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590509804),
    {
      "r": 65537,
      "n": "Build",
      "d": 575212,
      "h": 8590509804,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590509804)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295542508),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 575212,
      "h": 4295542508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295542508)
  ],
  "h": 575212
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(575212)
        
        

        //--TRIMMABLE-BOUNDARY-START(116460)
        $asm.$cls(`$HSAN._LCPCSL.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295083756)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295083756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295083756)
            
            //--TRIMMABLE-BOUNDARY-START(8590051052)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590051052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590051052)
            
            static $h = 116460;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295083756),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 116460,
      "h": 4295083756,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295083756),
//--TRIMMABLE-BOUNDARY-START(8590051052),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 116460,
      "h": 8590051052,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590051052)
  ],
  "h": 116460
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.PayCowry.Client.Shared.Login.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Login${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(116460)
        
        

        //--TRIMMABLE-BOUNDARY-START(181996)
        $asm.$cls(`$HSAN._LCPCSO.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295149292)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295149292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295149292)
            
            //--TRIMMABLE-BOUNDARY-START(8590116588)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590116588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590116588)
            
            //--TRIMMABLE-BOUNDARY-START(12885083884)
            static /*void */ CreateInputEditor_2(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885083884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885083884)
            
            //--TRIMMABLE-BOUNDARY-START(17180051180)
            static /*void */ CreateInputEditor_3(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180051180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180051180)
            
            //--TRIMMABLE-BOUNDARY-START(21475018476)
            static /*void */ CreateInputEditor_4(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475018476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475018476)
            
            //--TRIMMABLE-BOUNDARY-START(25769985772)
            static /*void */ CreateInputEditor_5(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769985772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25769985772)
            
            //--TRIMMABLE-BOUNDARY-START(30064953068)
            static /*void */ CreateInputEditor_6(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064953068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(30064953068)
            
            static $h = 181996;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295149292),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 181996,
      "h": 4295149292,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295149292),
//--TRIMMABLE-BOUNDARY-START(8590116588),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 181996,
      "h": 8590116588,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590116588),
//--TRIMMABLE-BOUNDARY-START(12885083884),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_2",
      "d": 181996,
      "h": 12885083884,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885083884),
//--TRIMMABLE-BOUNDARY-START(17180051180),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_3",
      "d": 181996,
      "h": 17180051180,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180051180),
//--TRIMMABLE-BOUNDARY-START(21475018476),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_4",
      "d": 181996,
      "h": 21475018476,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475018476),
//--TRIMMABLE-BOUNDARY-START(25769985772),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_5",
      "d": 181996,
      "h": 25769985772,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25769985772),
//--TRIMMABLE-BOUNDARY-START(30064953068),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_6",
      "d": 181996,
      "h": 30064953068,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30064953068)
  ],
  "h": 181996
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.PayCowry.Client.Shared.Onboarding.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Onboarding${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(181996)
        
        

        //--TRIMMABLE-BOUNDARY-START(1427180)
        $asm.$cls(`$HSAN.LCPCSS.FakeConnectionManager`, ($self) => class FakeConnectionManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55836002028)
            /*IConnectionInterface*/ get_Item$1(/*IConnectionContext*/ context)
            {
                return null;
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(55836002028)
            
            //--TRIMMABLE-BOUNDARY-START(34361165548)
            /*IEnumerable<IConnectionInterface> */ get Interfaces()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$KuVO.LCFCC.IConnectionInterface.$type, [  ], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(34361165548)
            
            //--TRIMMABLE-BOUNDARY-START(8591361772)
            /*Task<IConnectionClient?> */ ConnectTo(/*IConnectionContext*/ context, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591361772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$KuVO.LCFCC.IConnectionClient, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591361772)
            
            //--TRIMMABLE-BOUNDARY-START(12886329068)
            /*void */ Disconnect(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886329068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886329068)
            
            //--TRIMMABLE-BOUNDARY-START(42951100140)
            /*ValueTask<IConnectionInterface?> */ StartServer$1(/*IConnectionContext*/ context, /*IConnectionEndPoint*/ endpoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951100140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$KuVO.LCFCC.IConnectionInterface, null);
            }
            //--TRIMMABLE-BOUNDARY-END(42951100140)
            
            //--TRIMMABLE-BOUNDARY-START(38656132844)
            /*ValueTask<IConnectionInterface?> */ StartServer(/*IConnectionContext*/ context, /*ConnectionEndPointProviderFactory*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656132844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$KuVO.LCFCC.IConnectionInterface, null);
            }
            //--TRIMMABLE-BOUNDARY-END(38656132844)
            
            //--TRIMMABLE-BOUNDARY-START(47246067436)
            /*ValueTask<IConnectionInterface?> */ StartServer$2(TConnectionEndPoint, /*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246067436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$KuVO.LCFCC.IConnectionInterface, null);
            }
            //--TRIMMABLE-BOUNDARY-END(47246067436)
            
            //--TRIMMABLE-BOUNDARY-START(51541034732)
            /*void */ Stop(/*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541034732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51541034732)
            
            //--TRIMMABLE-BOUNDARY-START(4296863406)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.ConnectTo(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, System.Threading.CancellationToken)
            LCFCC$IConnectionManager$ConnectTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296863406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ConnectTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296863406)
            
            //--TRIMMABLE-BOUNDARY-START(38656601774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, LivingThing.Core.Frameworks.Common.Connection.IConnectionEndPoint?)
            LCFCC$IConnectionManager$StartServer$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656601774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38656601774)
            
            //--TRIMMABLE-BOUNDARY-START(34361634478)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, LivingThing.Core.Frameworks.Common.Connection.ConnectionEndPointProviderFactory?)
            LCFCC$IConnectionManager$StartServer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361634478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34361634478)
            
            //--TRIMMABLE-BOUNDARY-START(42951569070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer<TConnectionEndPoint>(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionManager$StartServer$2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951569070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42951569070)
            
            //--TRIMMABLE-BOUNDARY-START(8591830702)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Disconnect(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCFCC$IConnectionManager$Disconnect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591830702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Disconnect(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591830702)
            
            //--TRIMMABLE-BOUNDARY-START(47246536366)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Stop(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionManager$Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246536366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Stop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47246536366)
            
            //--TRIMMABLE-BOUNDARY-START(17181765294)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Interfaces.get
            get LCFCC$IConnectionManager$Interfaces()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066667182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Interfaces;
            }
            //--TRIMMABLE-BOUNDARY-END(17181765294)
            
            //--TRIMMABLE-BOUNDARY-START(25771699886)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.this[LivingThing.Core.Frameworks.Common.Connection.IConnectionContext].get
            LCFCC$IConnectionManager$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771699886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771699886)
            
            //--TRIMMABLE-BOUNDARY-START(4296394476)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296394476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296394476)
            
            //--TRIMMABLE-BOUNDARY-START(4296394476)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296394476)
            
            static $h = 1427180;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836002028),
    {
      "p": 1830574,
      "i": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066198252,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1427180,
      "h": 55836002028,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(55836002028),
//--TRIMMABLE-BOUNDARY-START(34361165548),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476263660,
        "f": 50331649
      },
      "n": "Interfaces",
      "d": 1427180,
      "h": 34361165548,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361165548)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591361772),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ConnectTo",
      "d": 1427180,
      "h": 8591361772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591361772),
//--TRIMMABLE-BOUNDARY-START(12886329068),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Disconnect",
      "d": 1427180,
      "h": 12886329068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886329068),
//--TRIMMABLE-BOUNDARY-START(42951100140),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "endpoint",
          "p": 1765038
        }
      ],
      "n": "StartServer",
      "o": "@$1",
      "d": 1427180,
      "h": 42951100140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951100140),
//--TRIMMABLE-BOUNDARY-START(38656132844),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "factory",
          "p": 650926
        }
      ],
      "n": "StartServer",
      "d": 1427180,
      "h": 38656132844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656132844),
//--TRIMMABLE-BOUNDARY-START(47246067436),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": [
        "TConnectionEndPoint"
      ],
      "n": "StartServer",
      "o": "@$2",
      "d": 1427180,
      "h": 47246067436,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(47246067436),
//--TRIMMABLE-BOUNDARY-START(51541034732),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "n": "Stop",
      "d": 1427180,
      "h": 51541034732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541034732)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296394476),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1427180,
      "h": 4296394476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296394476)
  ],
  "h": 1427180
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionManager ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.Stubs.FakeConnectionManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}Stubs${separator}FakeConnectionManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1427180)
        
        

        //--TRIMMABLE-BOUNDARY-START(1492716)
        $asm.$cls(`$HSAN.LCPCSS.FakeWalletQRPaymentScannerProvider`, ($self) => class FakeWalletQRPaymentScannerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591427308)
            /*ValueTask<IWalletHolder> */ ScanPeer(/*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591427308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$OJJQ.LCFCW.IWalletHolder, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591427308)
            
            //--TRIMMABLE-BOUNDARY-START(4295931085)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletQRPaymentScannerProvider.ScanPeer(System.Threading.CancellationToken)
            LCFCW$IWalletQRPaymentScannerProvider$ScanPeer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295931085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ScanPeer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295931085)
            
            //--TRIMMABLE-BOUNDARY-START(4296460012)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296460012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296460012)
            
            //--TRIMMABLE-BOUNDARY-START(4296460012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296460012)
            
            static $h = 1492716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591427308),
    {
      "r": $.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ScanPeer",
      "d": 1492716,
      "h": 8591427308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591427308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296460012),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1492716,
      "h": 4296460012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296460012)
  ],
  "h": 1492716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletQRPaymentScannerProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.Stubs.FakeWalletQRPaymentScannerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}Stubs${separator}FakeWalletQRPaymentScannerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1492716)
        
        

        //--TRIMMABLE-BOUNDARY-START(509676)
        $asm.$cls(`$HSAN.LCPC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180378860)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCP.LoyaltyRewardSpinWheel.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCP.LoyaltyRewardSpinWheel().$ctor$3();
                    }, $ihgwXd ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCP.PayCowryApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCP.PayCowryApp().$ctor$3();
                    }, $jKilCh ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.Error.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.Error().$ctor$3();
                    }, $GxZYuc ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.Home.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.Home().$ctor$5();
                    }, $NgXIOc ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.Login.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.Login().$ctor$3();
                    }, $xgNakk ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.Onboarding.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.Onboarding().$ctor$3();
                    }, $KiMBmc ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.PayCowryHeader.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.PayCowryHeader().$ctor$5();
                    }, $NOVoVh ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.PayCowryWalletReceive.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.PayCowryWalletReceive().$ctor$3();
                    }, $QygbIb ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.PayCowryWalletSend.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.PayCowryWalletSend().$ctor$3();
                    }, $DtyWHd ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.PinLogin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.PinLogin().$ctor$3();
                    }, $GIdVXh ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.Profile.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.Profile().$ctor$3();
                    }, $keDxqi ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.Swap.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.Swap().$ctor$5();
                    }, $ZoTKgi ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HSAN.LCPCS$1.Wallet.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HSAN.LCPCS$1.Wallet().$ctor$5();
                    }, $hmRgij ??= {"r":2752627,"n":"","d":509676,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180378860)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295476972)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295476972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295476972)
            
            //--TRIMMABLE-BOUNDARY-START(4295476972)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295476972)
            
            static $h = 509676;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180378860),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885411564,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 509676,
      "h": 17180378860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180378860)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295476972),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 509676,
      "h": 4295476972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295476972)
  ],
  "h": 509676
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(509676)
        
        

        //--TRIMMABLE-BOUNDARY-START(771820)
        $asm.$cls(`$HSAN.LCPC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590706412)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590706412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$HSAN.LCPCS.PayCowryService, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$HSAN.LCPCS.PayCowryApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryApplication, x);
                }, $XwxFNi ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":771820,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$OJJQ.LCFCW.IWalletIssuer, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$HSAN.LCPCS.PayCowryOfflineCoinIssuer, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$OJJQ.LCFCW.IWalletIssuer))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryOfflineCoinIssuer, x);
                }, $oMYwKb ??= {"r":636109,"p":[{"n":"x","p":327718}],"n":"","d":771820,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$OJJQ.LCFCW.IWalletIssuer, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$HSAN.LCPCS.PayCowryOnlineCoinIssuer, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$OJJQ.LCFCW.IWalletIssuer))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryOnlineCoinIssuer, x);
                }, $MKTAug ??= {"r":636109,"p":[{"n":"x","p":327718}],"n":"","d":771820,"h":0,"f":17825794}));
                if (options.Runtime === 1/*RuntimeType.WebServer*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$OJJQ.LCFCW.IWalletQRPaymentScannerProvider, $.$UlXD.LCPCS.FakeOCRScannerProvider, services);
                }
                if (options.Runtime === 3/*RuntimeType.Wasm*/ || options.Runtime === 4/*RuntimeType.WasmMobileApp*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$KuVO.LCFCC.IConnectionManager, $.$HSAN.LCPCSS.FakeConnectionManager, services);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$OJJQ.LCFCW.IWalletQRPaymentScannerProvider, $.$HSAN.LCPCSS.FakeWalletQRPaymentScannerProvider, services);
                }
                $.$HSAN.LCPC._Startup.AddGeneratedComponentOptimizers(services);
                $.$HSAN.LCPC._Startup.AddGeneratedComponentOptimizers(services);
                $.$HSAN.LCPC.FastEnumStartupExtension.AddGeneratedFastEnums(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590706412)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HSAN.LCPC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295739116)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295739116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295739116)
            
            //--TRIMMABLE-BOUNDARY-START(4295739116)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295739116)
            
            static $h = 771820;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590706412),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 771820,
      "h": 8590706412,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590706412)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295739116),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 771820,
      "h": 4295739116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295739116)
  ],
  "h": 771820
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(771820)
        
        

        //--TRIMMABLE-BOUNDARY-START(1230572)
        $asm.$cls(`$HSAN.LCPCS.PayCowrySendToBankWalletProvider`, ($self) => class PayCowrySendToBankWalletProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476067052)
            /*PayCowryService*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(21476067052)
            
            //--TRIMMABLE-BOUNDARY-START(4296197868)
            $ctor$1(/*PayCowryService*/ service)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296197868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296197868)
            
            //--TRIMMABLE-BOUNDARY-START(12886132460)
            /*Dictionary<string, double>? */ GetTransactionFee(/*double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886132460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (amount === 0)
                {
                    return null;
                }
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Transaction Fee", $.$UlXD.LCPC.Utility._GetTransactionFee(amount));
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(12886132460)
            
            //--TRIMMABLE-BOUNDARY-START(8591165164)
            /*Task<IWalletHolder> *//*async*/  GetPeer(/*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder), $.$OJJQ.LCFCW.IWalletHolder, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591165164);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.ViewForResult($.$hDPm.LCFCI.ViewConfiguration, $.$OJJQ.LCFCW.IWalletHolder, $.$SeJP.LCWCS$1.BankGetBeneficiary, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, null, token, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8591165164)
            
            //--TRIMMABLE-BOUNDARY-START(17181099756)
            /*ValueTask<object> *//*async*/  Pay(/*IWalletHolder*/ sender, /*IWalletHolder*/ recipient, /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ denominations, /*string*/ pinCode, /*string?*/ transactionDescription, /*IWalletPaymentSendProgressReportIndicator*/ progressIndicator, /*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181099756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$UlXD.LCPC.Utility.ThrowIfNotValid(this.service.Protector, pinCode, this.service.OfflineAccount.Pin);
                    /*var*/ let stub = $.$cast(recipient, $.$SeJP.LCWCS$1.BankGetBeneficiary.WalletHolder);
                    /*var*/ let amount = $.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), denominations, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/**/ d) =>
                    {
                        return d.Value;
                    }, $fDTlUi ??= {"r":1179649,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":1230572,"h":0,"f":17825794}));
                    /*var*/ let result = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.BankTransferResult, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCPCS$IPayCowryRemoteService$BankTransfer(this.service.OfflineAccount, amount, stub.Account, pinCode, transactionDescription);
                    }, $woVmxh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)).$h,"p":[{"n":"server","p":3561107}],"n":"","d":1230572,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181099756)
            
            //--TRIMMABLE-BOUNDARY-START(4295935751)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.GetPeer(System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$GetPeer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295935751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPeer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295935751)
            
            //--TRIMMABLE-BOUNDARY-START(8590903047)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.GetTransactionFee(double)
            LCWCS$IWalletSendProvider$GetTransactionFee()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590903047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetTransactionFee(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590903047)
            
            //--TRIMMABLE-BOUNDARY-START(12885870343)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.Pay(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, System.Collections.Generic.Dictionary<(LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer, LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor), double>, string, string?, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator, System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$Pay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885870343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pay(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885870343)
            
            static $h = 1230572;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886132460),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double).$h,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "GetTransactionFee",
      "d": 1230572,
      "h": 12886132460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886132460),
//--TRIMMABLE-BOUNDARY-START(8591165164),
    {
      "r": $.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "GetPeer",
      "d": 1230572,
      "h": 8591165164,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(8591165164),
//--TRIMMABLE-BOUNDARY-START(17181099756),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "sender",
          "p": 570573
        },
        {
          "n": "recipient",
          "p": 570573
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        },
        {
          "n": "progressIndicator",
          "p": 898253
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "Pay",
      "d": 1230572,
      "h": 17181099756,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17181099756)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476067052),
    {
      "t": 1296108,
      "n": "service",
      "d": 1230572,
      "h": 21476067052,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476067052)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296197868),
    {
      "p": [
        {
          "n": "service",
          "p": 1296108
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1230572,
      "h": 4296197868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296197868)
  ],
  "h": 1230572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$SeJP.LCWCS.IWalletSendProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.PayCowrySendToBankWalletProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}PayCowrySendToBankWalletProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1230572)
        
        

        //--TRIMMABLE-BOUNDARY-START(1099500)
        $asm.$cls(`$HSAN.LCPCS.PayCowryOfflinePaymentProvider`, ($self) => class PayCowryOfflinePaymentProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(304943777516)
            /*PayCowryService*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(304943777516)
            
            //--TRIMMABLE-BOUNDARY-START(266289071852)
            /*IWalletQRPaymentScannerProvider*/ qrScanner = null;
            //--TRIMMABLE-BOUNDARY-END(266289071852)
            
            //--TRIMMABLE-BOUNDARY-START(42950772460)
            /*ILocalDatabase*/ database = null;
            //--TRIMMABLE-BOUNDARY-END(42950772460)
            
            //--TRIMMABLE-BOUNDARY-START(38655805164)
            /*IConnectionManager*/ connection = null;
            //--TRIMMABLE-BOUNDARY-END(38655805164)
            
            //--TRIMMABLE-BOUNDARY-START(261994104556)
            /*IDataProtector*/ protector = null;
            //--TRIMMABLE-BOUNDARY-END(261994104556)
            
            //--TRIMMABLE-BOUNDARY-START(30065870572)
            $ctor$1(/*PayCowryService*/ service, /*ILocalDatabase*/ database, /*IWalletQRPaymentScannerProvider*/ qrScanner, /*IConnectionManager*/ connection, /*IDataProtector*/ protector, /*PayCowryOfflineCoinIssuer*/ issuer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065870572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = service;
                    this.database = database;
                    this.qrScanner = qrScanner;
                    this.connection = connection;
                    this.protector = protector;
                    this.Issuers = $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HSAN.LCPCS.PayCowryOfflineCoinIssuer), [issuer], null, null), $.$$.SCG.IEnumerable$$($.$HSAN.LCPCS.PayCowryOfflineCoinIssuer), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065870572)
            
            //--TRIMMABLE-BOUNDARY-START(249109202668)
            /*int*/ Order = 0;
            //--TRIMMABLE-BOUNDARY-END(249109202668)
            
            //--TRIMMABLE-BOUNDARY-START(223339398892)
            /*string */ get Name()
            {
                return "PayCowry";
            }
            //--TRIMMABLE-BOUNDARY-END(223339398892)
            
            //--TRIMMABLE-BOUNDARY-START(347893450476)
            /*string */ get Title()
            {
                return "Offline Cowries";
            }
            //--TRIMMABLE-BOUNDARY-END(347893450476)
            
            //--TRIMMABLE-BOUNDARY-START(201864562412)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png");
            }
            //--TRIMMABLE-BOUNDARY-END(201864562412)
            
            //--TRIMMABLE-BOUNDARY-START(339303515884)
            /*Theme */ get Theme()
            {
                return new $.$fPer.LCFC.Theme().$ctor$4("linear-gradient(180deg, rgb(var(--primary-background-color)), rgb(var(--secondary-background-color)))", "white", 1);
            }
            //--TRIMMABLE-BOUNDARY-END(339303515884)
            
            //--TRIMMABLE-BOUNDARY-START(197569595116)
            /*IWalletHolder*/ Holder = null;
            //--TRIMMABLE-BOUNDARY-END(197569595116)
            
            //--TRIMMABLE-BOUNDARY-START(214749464300)
            /*IEnumerable<IWalletIssuer>*/ Issuers = null;
            //--TRIMMABLE-BOUNDARY-END(214749464300)
            
            //--TRIMMABLE-BOUNDARY-START(352188417772)
            /*IEnumerable<IGrouping<string, IWalletToken>> */ get Tokens()
            {
                return $.$sl.SL.Enumerable.GroupBy$7($.$OJJQ.LCFCW.IWalletToken, $.$$.S.String, $.$sl.SL.Enumerable.Cast($.$OJJQ.LCFCW.IWalletToken, this.OfflineTokens), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.String))().$ctor(this,  (/*g*/ g) =>
                {
                    return "PayCowry"/*PayCowryTokenModel.IssuerName*/;
                }, $Qtxozk ??= {"r":1310721,"p":[{"n":"g","p":1357005}],"n":"","d":1099500,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(352188417772)
            
            //--TRIMMABLE-BOUNDARY-START(296353842924)
            /*Pager<IWalletTransaction> */ get RecentTransactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440052972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$fPer.LCFCD.Pager$$($.$OJJQ.LCFCW.IWalletTransaction))().$ctor(this, /*async*/  (/*filter*/ filter) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)), $.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction), async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        /*var*/ let data = ($t1 = this.database.LCPCS$ILocalDatabase$GetTransactionsAsync(filter), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCD.Paging.AsPagingDataResult$2($.$OJJQ.LCFCW.IWalletTransaction, $.$sl.SL.Enumerable.Cast($.$OJJQ.LCFCW.IWalletTransaction, data.Data), data.TotalCount));
                    });
                }, $HockYa ??= {"r":$.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)).$h,"p":[{"n":"filter","p":9734486}],"n":"","d":1099500,"h":0,"f":17829890});
            }
            //--TRIMMABLE-BOUNDARY-END(296353842924)
            
            //--TRIMMABLE-BOUNDARY-START(309238744812)
            /*IWalletServices */ get Services()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(309238744812)
            
            //--TRIMMABLE-BOUNDARY-START(240519268076)
            /*IEnumerable<PayCowryTokenModel>*/ OfflineTokens = null;
            //--TRIMMABLE-BOUNDARY-END(240519268076)
            
            //--TRIMMABLE-BOUNDARY-START(236224300780)
            /*IWalletOfflinePaymentProvider? */ get OfflinePayment()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(236224300780)
            
            //--TRIMMABLE-BOUNDARY-START(244814235372)
            /*IWalletOnlinePaymentProvider?*/ OnlinePayment = null;
            //--TRIMMABLE-BOUNDARY-END(244814235372)
            
            //--TRIMMABLE-BOUNDARY-START(51540707052)
            /*IWalletFundPaymentProvider?*/ FundPayment = null;
            //--TRIMMABLE-BOUNDARY-END(51540707052)
            
            //--TRIMMABLE-BOUNDARY-START(300648810220)
            /*SelfAddress */ get SelfAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029987564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let holderData = $.$fPer.LCFC.EncryptUtility.QuickEncrypt$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$OJJQ.LCFCW.IWalletHolder, this.Holder, true, false, true, false, false, false, false, "SelfAddress", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "SelfAddress", 92).Json, null);
                /*var*/ let qr = $.$wZnq.NCQ.QrCode.EncodeText(holderData, 0/*QrCode.Ecc.Low*/);
                /*string*/ let svg = qr.ToSvgString(4, "#000000", "#ffffff");
                return (() =>
                {
                    //new $.$SeJP.LCWCS.SelfAddress()
                    const $t2 = $.$SeJP.LCWCS.SelfAddress;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Address = $.$OJJQ.LCFCW.WalletAddress.op_Implicit(this.Holder.LCFCW$IWalletHolder$NetworkAddress);
                    $i2.SVG = new $.$mac.MAC.MarkupString().$ctor$3(svg);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(300648810220)
            
            //--TRIMMABLE-BOUNDARY-START(231929333484)
            /*void */ NotifyTokensSent(/*IEnumerable<PayCowryTokenModel>*/ tokens)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929333484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OfflineTokens = $.$sl.SL.Enumerable.ToList($.$UlXD.LCPCM.PayCowryTokenModel, $.$sl.SL.Enumerable.Where($.$UlXD.LCPCM.PayCowryTokenModel, this.OfflineTokens, new ($.$$.S.Func$$$($.$UlXD.LCPCM.PayCowryTokenModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return !$.$sl.SL.Enumerable.Any($.$UlXD.LCPCM.PayCowryTokenModel, tokens, new ($.$$.S.Func$$$($.$UlXD.LCPCM.PayCowryTokenModel, $.$$.S.Boolean))().$ctor(this,  (/*tt*/ tt) =>
                    {
                        return t.SerialNumber === tt.SerialNumber;
                    }, $TfUYNe ??= {"r":262145,"p":[{"n":"tt","p":2184851}],"n":"","d":1099500,"h":0,"f":17825794}));
                }, $ZajZSk ??= {"r":262145,"p":[{"n":"t","p":2184851}],"n":"","d":1099500,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(231929333484)
            
            //--TRIMMABLE-BOUNDARY-START(227634366188)
            /*void */ NotifyNewTokensReceived(/*IEnumerable<PayCowryTokenModel>*/ tokens)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634366188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OfflineTokens = $.$sl.SL.Enumerable.ToList($.$UlXD.LCPCM.PayCowryTokenModel, $.$sl.SL.Enumerable.Concat($.$UlXD.LCPCM.PayCowryTokenModel, this.OfflineTokens, tokens));
            }
            //--TRIMMABLE-BOUNDARY-END(227634366188)
            
            //--TRIMMABLE-BOUNDARY-START(219044431596)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219044431596);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.OfflineTokens = ($t3 = this.database.LCPCS$ILocalDatabase$GetTokensAsync($.$fPer.LCFCD.DataFilter.Default), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(219044431596)
            
            //--TRIMMABLE-BOUNDARY-START(343598483180)
            /*int*/ static timeOut = 30;
            //--TRIMMABLE-BOUNDARY-END(343598483180)
            
            //--TRIMMABLE-BOUNDARY-START(34360837868)
            /*int*/ static bufferSize = 1024;
            //--TRIMMABLE-BOUNDARY-END(34360837868)
            
            //--TRIMMABLE-BOUNDARY-START(356483385068)
            /*Task *//*async*/  Write(/*IConnectionClient*/ client, /*ConnectionPacketType*/ command, /*byte[]*/ data, /*bool*/ addDataLen, /*Action<float>?*/ reportProgress)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(356483385068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    //if (true)
                    {
                        let $t4, $r4;
                        /*var*/ let nb = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((((data.length + 1) | 0) + (addDataLen ? 4 : 0)) | 0)], null);
                        /*int*/ let where = 0;
                        if (addDataLen)
                        {
                            /*var*/ let frameSize = ((data.length + 1) | 0);
                            $.$$.System.Array.$WriteT1.call(nb, $.$cast((frameSize >> 0), $.$$.S.Byte), where++);
                            $.$$.System.Array.$WriteT1.call(nb, $.$cast((frameSize >> 8), $.$$.S.Byte), where++);
                            $.$$.System.Array.$WriteT1.call(nb, $.$cast((frameSize >> 16), $.$$.S.Byte), where++);
                            $.$$.System.Array.$WriteT1.call(nb, $.$cast((frameSize >> 24), $.$$.S.Byte), where++);
                        }
                        $.$$.System.Array.$WriteT1.call(nb, command, where++);
                        $.$$.S.Array.Copy(data, 0, nb, ((1 + (addDataLen ? 4 : 0)) | 0), data.length);
                        ($t4 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Write$1(client.LCFCC$IConnectionClient$Interface, client, new $.$KuVO.LCFCC.ConnectionMessage().$ctor$1(client.LCFCC$IConnectionClient$Interface, client, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit($.$fPer.LCFC.EncryptUtility.QuickEncrypt(nb, null))), true), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    //else { ... }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(356483385068)
            
            //--TRIMMABLE-BOUNDARY-START(270584039148)
            /*Task<byte[]> *//*async*/  Read(/*IConnectionClient*/ client, /*Action<ConnectionPacketType>*/ rxCommand, /*bool*/ hasDataLen, /*Action<float>?*/ reportProgress)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$typeArray($.$$.S.Byte)), $.$typeArray($.$$.S.Byte), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(270584039148);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    //if (true)
                    {
                        let $t5, $r5;
                        /*var*/ let bytes = ($t5 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Read$1(client.LCFCC$IConnectionClient$Interface, client, $.$$.S.TimeSpan.FromSeconds$2(BigInt(30/*timeOut*/))), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        /*var*/ let message = $.$fPer.LCFC.EncryptUtility.QuickDecrypt($.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(bytes.LCFCC$IConnectionMessage$Data), null);
                        /*byte[]?*/ let buffer = null;
                        if (hasDataLen)
                        {
                            try
                            {
                                /*var*/ let frameSize = $.$$.System.Array.$ReadT1.call(message, 0) | (($.$cast($.$$.System.Array.$ReadT1.call(message, 1), $.$$.S.Int32)) << 8) | (($.$cast($.$$.System.Array.$ReadT1.call(message, 2), $.$$.S.Int32)) << 16) | (($.$cast($.$$.System.Array.$ReadT1.call(message, 3), $.$$.S.Int32)) << 24);
                                buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(frameSize);
                                $.$$.S.Array.Copy(message, 4, buffer, 0, ((message.length - 4) | 0));
                                /*int*/ let where = ((message.length - 4) | 0);
                                /*int*/ let remaining = ((frameSize - (((message.length - 4) | 0))) | 0);
                                while(remaining > 0)
                                {
                                    let $t6, $r6;
                                    bytes = ($t6 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Read$1(client.LCFCC$IConnectionClient$Interface, client, $.$$.S.TimeSpan.FromSeconds$2(BigInt(30/*timeOut*/))), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                    message = bytes.LCFCC$IConnectionMessage$Data.Match($.$typeArray($.$$.S.Byte), new ($.$$.S.Func$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*bytes*/ bytes) =>
                                    {
                                        return bytes;
                                    }, $rWLqii ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":1099500,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/**/ mem) =>
                                    {
                                        return mem.ToArray();
                                    }, $iouwxi ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"mem","p":$.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h}],"n":"","d":1099500,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SI.Stream, $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*stream*/ stream) =>
                                    {
                                        /*byte[]*/ let bb = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((1024 * 1024) | 0)], null);
                                        /*int*/ let l = stream.Read(bb, 0, bb.length);
                                        return $.$sl.SL.Enumerable.ToArray($.$$.S.Byte, $.$sl.SL.Enumerable.Take($.$$.S.Byte, bb, l));
                                    }, $TBEIVe ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"stream","p":95748097}],"n":"","d":1099500,"h":0,"f":17825794}));
                                    $.$$.S.Array.Copy(message, 0, buffer, where, message.length);
                                    remaining -= message.length;
                                    where += message.length;
                                }
                                rxCommand.Invoke($.$cast($.$$.System.Array.$ReadT1.call(buffer, 0), $.$HSAN.LCPCS.ConnectionPacketType));
                                return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.ToArray($.$$.S.Byte, $.$sl.SL.Enumerable.Take($.$$.S.Byte, $.$sl.SL.Enumerable.Skip($.$$.S.Byte, buffer, 1), ((frameSize - 1) | 0))));
                            }
                            finally
                            {
                                {
                                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(buffer, false);
                                }
                            }
                        }
                        else 
                        {
                            buffer = message;
                        }
                        if (message !== null)
                        {
                            rxCommand.Invoke($.$cast($.$$.System.Array.$ReadT1.call(buffer, 0), $.$HSAN.LCPCS.ConnectionPacketType));
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.ToArray($.$$.S.Byte, $.$sl.SL.Enumerable.Skip($.$$.S.Byte, buffer, 1)));
                        }
                    }
                    //else { ... }
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Packet Error");
                });
            }
            //--TRIMMABLE-BOUNDARY-END(270584039148)
            
            //--TRIMMABLE-BOUNDARY-START(257699137260)
            /*ValueTask<object?> *//*async*/  PayOffline(/*IWalletHolder*/ _sender, /*IWalletHolder*/ _receiver, /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ denomination, /*string*/ pinCode, /*string?*/ transactionDescription, /*IWalletPaymentSendProgressReportIndicator*/ progressIndicator, /*CancellationToken*/ ctoken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257699137260);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let sender = $.$cast(_sender, $.$UlXD.LCPCM.PayCowryOfflineAccountModel);
                    $.$UlXD.LCPC.Utility.ThrowIfNotValid$1($.$UlXD.LCPCM.PayCowryOfflineAccountModel, sender, this.protector, true);
                    /*var*/ let receiver = $.$cast(_receiver, $.$UlXD.LCPCM.PayCowryOfflineAccountModel);
                    progressIndicator.LCFCW$IWalletPaymentSendProgressReportIndicator$ReportMessage("Connecting to Peer...");
                    /*CancellationTokenSource*/ let cancelConnection = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    /*IConnectionClient?*/ let remoteClient = null;
                    try
                    {
                        let $t7, $r7;
                        let $t9, $r9;
                        let $t11, $r11;
                        let $t12, $r12;
                        remoteClient = ($t7 = this.connection.LCFCC$IConnectionManager$ConnectTo((() =>
                        {
                            //new $.$KuVO.LCFCC.ConnectionContext()
                            const $t8 = $.$KuVO.LCFCC.ConnectionContext;
                            const $i8 = new $t8();
                            $i8.$ctor$1();
                            $i8.Name = receiver.NetworkAddress.Address;
                            $i8.IP = receiver.InterfaceAddress;
                            return $i8;
                        })(), $.$$.ST$1.CancellationTokenSource.CreateLinkedTokenSource$1(ctoken, cancelConnection.Token).Token), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        if (remoteClient === null)
                        {
                            throw new $.$$.SI.IOException().$ctor$13(`Cant connect to ${$.$strNN(_receiver.LCFCW$IWalletHolder$NetworkAddress.ToString())}`);
                        }
                        progressIndicator.LCFCW$IWalletPaymentSendProgressReportIndicator$ReportMessage("Exchanging Payment Information...");
                        /*bool*/ let batchTransfer = true;
                        ($t9 = this.Write(remoteClient, 1/*ConnectionPacketType.SenderInfo*/, $.$$.ST.Encoding.UTF8.GetBytes$8($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$UlXD.LCPCM.PayCowryOfflineAccountModel, $.$UlXD.LCPC.Utility.Protect($.$UlXD.LCPCM.PayCowryOfflineAccountModel, (() =>
                        {
                            //new $.$UlXD.LCPCM.PayCowryOfflineAccountModel()
                            const $t10 = $.$UlXD.LCPCM.PayCowryOfflineAccountModel;
                            const $i10 = new $t10();
                            $i10.$ctor$1();
                            $i10.Identity = sender.Identity;
                            $i10.UserName = sender.UserName;
                            $i10.FirstName = sender.FirstName;
                            $i10.LastName = sender.LastName;
                            $i10.PhoneNumber = sender.PhoneNumber;
                            $i10.Version = sender.Version;
                            $i10.Email = sender.Email;
                            $i10.BatchTransfer = batchTransfer;
                            $i10.Amount = $.$cast($.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), denomination, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/*a*/ a) =>
                            {
                                return a.Key.Item2.Amount * a.Value;
                            }, $DuuGGc ??= {"r":1179649,"p":[{"n":"a","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":1099500,"h":0,"f":17825794})), $.$$.S.Int32);
                            $i10.TransactionDescription = transactionDescription;
                            return $i10;
                        })(), this.protector), true, false, true, false, false, false, false, "PayOffline", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "PayOffline", 335).Json), false, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        /*ConnectionPacketType*/ let command = 0/*ConnectionPacketType.None*/;
                        /*var*/ let rcv = ($t11 = this.Read(remoteClient, new ($.$$.S.Action$$($.$HSAN.LCPCS.ConnectionPacketType))().$ctor(this,  (/*c*/ c) =>
                        {
                            return command = c;
                        }, $zxmVba ??= {"r":65537,"p":[{"n":"c","p":837356}],"n":"","d":1099500,"h":0,"f":17825794}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        if (command !== 2/*ConnectionPacketType.ReceiverInfo*/)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Packet Error");
                        }
                        /*var*/ let receiverInfo = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$UlXD.LCPCM.PayCowryOfflineAccountModel, $.$$.ST.Encoding.UTF8.GetString$3($.$fPer.LCFC.EncryptUtility.TrimEndForString(rcv)), false, "PayOffline", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "PayOffline", 356);
                        $.$UlXD.LCPC.Utility.ThrowIfNotValid$1($.$UlXD.LCPCM.PayCowryOfflineAccountModel, receiverInfo, this.protector, true);
                        /*int*/ let i = 0;
                        /*var*/ let tokenExchange = ($t12 = this.database.LCPCS$ILocalDatabase$BeginTokenTransfer($.$cast($.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), denomination, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/**/ a) =>
                        {
                            return a.Key.Item2.Amount * a.Value;
                        }, $ZXvfod ??= {"r":1179649,"p":[{"n":"a","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":1099500,"h":0,"f":17825794})), $.$$.S.Int32), $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Int32, $.$$.S.Int32, denomination, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Int32))().$ctor(this,  (/*a*/ a) =>
                        {
                            return $.$cast(a.Key.Item2.Amount, $.$$.S.Int32);
                        }, $WSCJRg ??= {"r":655361,"p":[{"n":"a","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":1099500,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Int32))().$ctor(this,  (/*a*/ a) =>
                        {
                            return $.$cast(a.Value, $.$$.S.Int32);
                        }, $QeSQWd ??= {"r":655361,"p":[{"n":"a","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":1099500,"h":0,"f":17825794})), receiverInfo.NetworkAddress, transactionDescription), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        try
                        {
                            //if (batchTransfer)
                            {
                                let $t13, $r13;
                                let $t14, $r14;
                                $.$sl.SL.Enumerable.All($.$UlXD.LCPCM.PayCowryTokenModel, tokenExchange.Tokens, new ($.$$.S.Func$$$($.$UlXD.LCPCM.PayCowryTokenModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                                {
                                    $.$UlXD.LCPC.Utility.ThrowIfNotValid$1($.$UlXD.LCPCM.PayCowryTokenModel, t, this.protector, true);
                                    return true;
                                }, $JWqIVi ??= {"r":262145,"p":[{"n":"t","p":2184851}],"n":"","d":1099500,"h":0,"f":17825794}));
                                /*var*/ let tokenBytes = $.$$.ST.Encoding.UTF8.GetBytes$8($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), tokenExchange.Tokens, true, false, true, false, false, false, false, "PayOffline", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "PayOffline", 384).Json);
                                ($t13 = this.Write(remoteClient, 3/*ConnectionPacketType.Token*/, tokenBytes, true, new ($.$$.S.Action$$($.$$.S.Single))().$ctor(this,  (/*p*/ p) =>
                                {
                                    return progressIndicator.LCFCW$IWalletPaymentSendProgressReportIndicator$ReportProgress(p);
                                }, $jqCSGg ??= {"r":65537,"p":[{"n":"p","p":1114113}],"n":"","d":1099500,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                                /*var*/ let d = ($t14 = this.Read(remoteClient, new ($.$$.S.Action$$($.$HSAN.LCPCS.ConnectionPacketType))().$ctor(this,  (/*c*/ c) =>
                                {
                                    return command = c;
                                }, $DGGjwi ??= {"r":65537,"p":[{"n":"c","p":837356}],"n":"","d":1099500,"h":0,"f":17825794}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                                if (command !== 4/*ConnectionPacketType.Ack*/ && command !== 6/*ConnectionPacketType.PacketEnd*/)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12("Packet Error");
                                }
                            }
                            //else { ... }
                            try
                            {
                                let $t15, $r15;
                                /*var*/ let transaction = ($t15 = tokenExchange.CompleteTransaction.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                            }
                            catch(e)
                            {
                            }
                        }
                        catch($e)
                        {
                            let $t16, $r16;
                            ($t16 = tokenExchange.ReverseTransaction.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                            throw $e;
                        }
                    }
                    finally
                    {
                        {
                            cancelConnection.Cancel();
                            if (remoteClient !== null)
                            {
                                this.connection.LCFCC$IConnectionManager$Disconnect(remoteClient);
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(257699137260)
            
            //--TRIMMABLE-BOUNDARY-START(283468941036)
            /*IWalletPaymentReceiveProgressReportIndicator?*/ receiverProgressIndicator = null;
            //--TRIMMABLE-BOUNDARY-END(283468941036)
            
            //--TRIMMABLE-BOUNDARY-START(287763908332)
            /*PayCowryOfflineAccountModel?*/ receiveSelf = null;
            //--TRIMMABLE-BOUNDARY-END(287763908332)
            
            //--TRIMMABLE-BOUNDARY-START(279173973740)
            /*Task<IDisposable?> *//*async*/  ReceiveOffline(/*IWalletHolder*/ self, /*IWalletPaymentReceiveProgressReportIndicator*/ receiverProgressIndicator)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.IDisposable), $.$$.S.IDisposable, async ($asnycContext) => 
                {
                    let $t17, $r17;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(279173973740);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.receiveSelf = $.$cast(self, $.$UlXD.LCPCM.PayCowryOfflineAccountModel);
                    this.receiverProgressIndicator = receiverProgressIndicator;
                    /*var*/ let _interface = ($t17 = this.connection.LCFCC$IConnectionManager$StartServer$1((() =>
                    {
                        //new $.$KuVO.LCFCC.ConnectionContext()
                        const $t18 = $.$KuVO.LCFCC.ConnectionContext;
                        const $i18 = new $t18();
                        $i18.$ctor$1();
                        $i18.Name = self.LCFCW$IWalletHolder$NetworkAddress.Address;
                        return $i18;
                    })(), this), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                    if (_interface !== null)
                    {
                        this.receiveSelf.InterfaceAddress = _interface.LCFCC$IConnectionInterface$LocalAddress;
                        return $.$$.N.AsyncResolver.Result($asnycContext, new $.$fPer.LCFC.DisposableDelegate().$ctor$3(new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return _interface.LCFCC$IConnectionInterface$Stop();
                        }, $idMgHj ??= {"r":65537,"n":"","d":1099500,"h":0,"f":17825794})));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(279173973740)
            
            //--TRIMMABLE-BOUNDARY-START(274879006444)
            /*Task<IDisposable?> */ Receive(/*IWalletHolder*/ self, /*IWalletPaymentReceiveProgressReportIndicator*/ receiverProgressIndicator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879006444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReceiveOffline(self, receiverProgressIndicator);
            }
            //--TRIMMABLE-BOUNDARY-END(274879006444)
            
            //--TRIMMABLE-BOUNDARY-START(292058875628)
            /*Task *//*async*/  ReceiveTask(/*IConnectionClient*/ remoteClient)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(292058875628);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t19, $r19;
                        let $t20, $r20;
                        let $t22, $r22;
                        let $t27, $r27;
                        let $t28, $r28;
                        let $t29, $r29;
                        /*ConnectionPacketType*/ let command = 0/*ConnectionPacketType.None*/;
                        /*var*/ let sdr = ($t19 = this.Read(remoteClient, new ($.$$.S.Action$$($.$HSAN.LCPCS.ConnectionPacketType))().$ctor(this,  (/*c*/ c) =>
                        {
                            return command = c;
                        }, $qAkwFa ??= {"r":65537,"p":[{"n":"c","p":837356}],"n":"","d":1099500,"h":0,"f":17825794}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                        if (command !== 1/*ConnectionPacketType.SenderInfo*/)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Packet Error");
                        }
                        /*var*/ let senderPaymentInfo = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$UlXD.LCPCM.PayCowryOfflineAccountModel, $.$$.ST.Encoding.UTF8.GetString$3($.$fPer.LCFC.EncryptUtility.TrimEndForString(sdr)), false, "ReceiveTask", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "ReceiveTask", 491);
                        $.$UlXD.LCPC.Utility.ThrowIfNotValid$1($.$UlXD.LCPCM.PayCowryOfflineAccountModel, senderPaymentInfo, this.protector, true);
                        ($t20 = this.Write(remoteClient, 2/*ConnectionPacketType.ReceiverInfo*/, $.$$.ST.Encoding.UTF8.GetBytes$8($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$UlXD.LCPCM.PayCowryOfflineAccountModel, $.$UlXD.LCPC.Utility.Protect($.$UlXD.LCPCM.PayCowryOfflineAccountModel, (() =>
                        {
                            //new $.$UlXD.LCPCM.PayCowryOfflineAccountModel()
                            const $t21 = $.$UlXD.LCPCM.PayCowryOfflineAccountModel;
                            const $i21 = new $t21();
                            $i21.$ctor$1();
                            $i21.Identity = this.receiveSelf.Identity;
                            $i21.UserName = this.receiveSelf.UserName;
                            $i21.FirstName = this.receiveSelf.FirstName;
                            $i21.LastName = this.receiveSelf.LastName;
                            $i21.PhoneNumber = this.receiveSelf.PhoneNumber;
                            $i21.Version = this.receiveSelf.Version;
                            $i21.Email = this.receiveSelf.Email;
                            $i21.Amount = senderPaymentInfo.Amount;
                            return $i21;
                        })(), this.protector), true, false, true, false, false, false, false, "ReceiveTask", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "ReceiveTask", 493).Json), false, null), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                        ($t22 = this.receiverProgressIndicator.LCFCW$IWalletPaymentReceiveProgressReportIndicator$OnSenderPaired(senderPaymentInfo), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                        /*List<PayCowryTokenModel>*/ let receivedTokens = new ($.$$.SCG.List$$($.$UlXD.LCPCM.PayCowryTokenModel))().$ctor$1();
                        if (senderPaymentInfo.BatchTransfer)
                        {
                            let $t23, $r23;
                            let $t24, $r24;
                            /*var*/ let token = ($t23 = this.Read(remoteClient, new ($.$$.S.Action$$($.$HSAN.LCPCS.ConnectionPacketType))().$ctor(this,  (/*c*/ c) =>
                            {
                                return command = c;
                            }, $yoBFPc ??= {"r":65537,"p":[{"n":"c","p":837356}],"n":"","d":1099500,"h":0,"f":17825794}), true, new ($.$$.S.Action$$($.$$.S.Single))().$ctor(this,  (/*p*/ p) =>
                            {
                                return this.receiverProgressIndicator.LCFCW$IWalletPaymentReceiveProgressReportIndicator$ReportProgress(p);
                            }, $sbJrGb ??= {"r":65537,"p":[{"n":"p","p":1114113}],"n":"","d":1099500,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                            if (command !== 3/*ConnectionPacketType.Token*/)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("Packet Error");
                            }
                            /*var*/ let json = $.$$.ST.Encoding.UTF8.GetString$3($.$fPer.LCFC.EncryptUtility.TrimEndForString(token));
                            /*var*/ let _receiveTokens = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), json, false, "ReceiveTask", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "ReceiveTask", 523);
                            $.$sl.SL.Enumerable.All($.$UlXD.LCPCM.PayCowryTokenModel, _receiveTokens, new ($.$$.S.Func$$$($.$UlXD.LCPCM.PayCowryTokenModel, $.$$.S.Boolean))().$ctor(this,  (/**/ token) =>
                            {
                                $.$UlXD.LCPC.Utility.ThrowIfNotValid$1($.$UlXD.LCPCM.PayCowryTokenModel, token, this.protector, true);
                                return true;
                            }, $NzkjNf ??= {"r":262145,"p":[{"n":"token","p":2184851}],"n":"","d":1099500,"h":0,"f":17825794}));
                            ($t24 = this.Write(remoteClient, 4/*ConnectionPacketType.Ack*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [], [-1], null), false, null), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                            receivedTokens.AddRange(_receiveTokens);
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; $.$$.S.Int32.op_LessThan$1(i, senderPaymentInfo.Amount); i++)
                            {
                                let $t25, $r25;
                                let $t26, $r26;
                                /*var*/ let token = ($t25 = this.Read(remoteClient, new ($.$$.S.Action$$($.$HSAN.LCPCS.ConnectionPacketType))().$ctor(this,  (/*c*/ c) =>
                                {
                                    return command = c;
                                }, $Qrkozc ??= {"r":65537,"p":[{"n":"c","p":837356}],"n":"","d":1099500,"h":0,"f":17825794}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                                if (command !== 3/*ConnectionPacketType.Token*/)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12("Packet Error");
                                }
                                /*var*/ let json = $.$$.ST.Encoding.UTF8.GetString$3($.$fPer.LCFC.EncryptUtility.TrimEndForString(token));
                                /*var*/ let receiveToken = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$UlXD.LCPCM.PayCowryTokenModel, json, false, "ReceiveTask", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryOfflinePaymentProvider.cs", "ReceiveTask", 544);
                                $.$UlXD.LCPC.Utility.ThrowIfNotValid$1($.$UlXD.LCPCM.PayCowryTokenModel, receiveToken, this.protector, true);
                                ($t26 = this.Write(remoteClient, 4/*ConnectionPacketType.Ack*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [], [-1], null), false, null), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                                receivedTokens.Add(receiveToken);
                                this.receiverProgressIndicator.LCFCW$IWalletPaymentReceiveProgressReportIndicator$ReportMessage(`Received ${$.$strNN((((i + 1) | 0)))} of ${$.$strNN(senderPaymentInfo.Amount)}...`);
                            }
                        }
                        /*var*/ let transaction = ($t27 = this.database.LCPCS$ILocalDatabase$ReceiveTokens(senderPaymentInfo.NetworkAddress, receivedTokens, senderPaymentInfo.TransactionDescription), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                        this.NotifyNewTokensReceived(receivedTokens);
                        this.service.NotifyNewTransaction(transaction);
                        ($t28 = this.service.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t28, { set $v($v) { $r28 = $v; } }) ? $r28 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t28)));
                        ($t29 = this.receiverProgressIndicator.LCFCW$IWalletPaymentReceiveProgressReportIndicator$OnTokenReceived(senderPaymentInfo, $.$$.N.InterfaceVarianceStubHandler.Create(receivedTokens, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken))), ($.$$.N.AsyncResolver.IsCompleted($t29, { set $v($v) { $r29 = $v; } }) ? $r29 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t29)));
                    }
                    catch(e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(292058875628)
            
            //--TRIMMABLE-BOUNDARY-START(206159529708)
            /*Task */ Invoke(/*IConnectionClient*/ context, /*PipelineDelegate<IConnectionClient>*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159529708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.ReceiveTask(context);
                return next.Invoke(context);
            }
            //--TRIMMABLE-BOUNDARY-END(206159529708)
            
            //--TRIMMABLE-BOUNDARY-START(210454497004)
            /*Task */ Invoke$1(/*IConnectionMessage*/ context, /*PipelineDelegate<IConnectionMessage>*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454497004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return next.Invoke(context);
            }
            //--TRIMMABLE-BOUNDARY-END(210454497004)
            
            //--TRIMMABLE-BOUNDARY-START(193274627820)
            /*ValueTask<PagingDataResult<IWalletTransaction>> *//*async*/  GetTransactions(/*DataFilter*/ filter)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)), $.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction), async ($asnycContext) => 
                {
                    let $t30, $r30;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274627820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let data = ($t30 = this.database.LCPCS$ILocalDatabase$GetTransactionsAsync(filter), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)()
                        const $t31 = $.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction);
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Data = $.$$.N.InterfaceVarianceStubHandler.Create(data.Data, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletTransaction));
                        $i31.TotalCount = data.TotalCount;
                        return $i31;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(193274627820)
            
            //--TRIMMABLE-BOUNDARY-START(184684693228)
            /*ValueTask<IWalletHolder> */ GetHolder(/*string*/ networkAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684693228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(184684693228)
            
            //--TRIMMABLE-BOUNDARY-START(47245739756)
            /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double> */ Denominate(/*double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245739756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let den = $.$UlXD.LCPC.Utility.Denominate(($.$cast(amount, $.$$.S.Int32)), null);
                return $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double, den, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)))().$ctor(this,  (/*e*/ e) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3($.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers), $.$sl.SL.Enumerable.Single($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$UlXD.LCPCM.PayCowryTokenModel.CoinDescriptors, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*ee*/ ee) =>
                    {
                        return ee.Amount === e.Key;
                    }, $aCyEOk ??= {"r":262145,"p":[{"n":"ee","p":3257549}],"n":"","d":1099500,"h":0,"f":17825794})));
                }, $XSJOKc ??= {"r":$.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32).$h}],"n":"","d":1099500,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.S.Double))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$cast(e.Value, $.$$.S.Double);
                }, $lwCRGg ??= {"r":1179649,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.S.Int32).$h}],"n":"","d":1099500,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(47245739756)
            
            //--TRIMMABLE-BOUNDARY-START(188979660524)
            /*Task<IWalletHolder> *//*async*/  GetPeer(/*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder), $.$OJJQ.LCFCW.IWalletHolder, async ($asnycContext) => 
                {
                    let $t32, $r32;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979660524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t32 = this.qrScanner.LCFCW$IWalletQRPaymentScannerProvider$ScanPeer(token), ($.$$.N.AsyncResolver.IsCompleted($t32, { set $v($v) { $r32 = $v; } }) ? $r32 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t32))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(188979660524)
            
            //--TRIMMABLE-BOUNDARY-START(253404169964)
            /*ValueTask<object> *//*async*/  Pay(/*IWalletHolder*/ sender, /*IWalletHolder*/ recipient, /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ denominations, /*string*/ pinCode, /*string?*/ transactionDescription, /*IWalletPaymentSendProgressReportIndicator*/ progressIndicator, /*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                {
                    let $t33, $r33;
                    let $t34, $r34;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253404169964);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let o = ($t33 = this.PayOffline(sender, recipient, denominations, pinCode, transactionDescription, progressIndicator, token), ($.$$.N.AsyncResolver.IsCompleted($t33, { set $v($v) { $r33 = $v; } }) ? $r33 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t33)));
                    ($t34 = this.service.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t34, { set $v($v) { $r34 = $v; } }) ? $r34 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t34)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, o);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(253404169964)
            
            //--TRIMMABLE-BOUNDARY-START(8590636237)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletOfflinePaymentProvider.ReceiveOffline(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator)
            LCFCW$IWalletOfflinePaymentProvider$ReceiveOffline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590636237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReceiveOffline(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590636237)
            
            //--TRIMMABLE-BOUNDARY-START(4295668941)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletOfflinePaymentProvider.PayOffline(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, System.Collections.Generic.Dictionary<(LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer, LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor), double>, string, string?, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator, System.Threading.CancellationToken)
            LCFCW$IWalletOfflinePaymentProvider$PayOffline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295668941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PayOffline(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295668941)
            
            //--TRIMMABLE-BOUNDARY-START(4295406797)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IDenominatedWalletSystem.Denominate(double)
            LCFCW$IDenominatedWalletSystem$Denominate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295406797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Denominate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295406797)
            
            //--TRIMMABLE-BOUNDARY-START(8590770090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>.Order.get
            get LCFCP$IPipeline$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770090)
            
            //--TRIMMABLE-BOUNDARY-START(12885737386)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>.Invoke(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient>)
            LCFCP$IPipeline$$$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737386)
            
            //--TRIMMABLE-BOUNDARY-START(8590770090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>.Order.get
            get LCFCP$IPipeline$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770090)
            
            //--TRIMMABLE-BOUNDARY-START(12885737386)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>.Invoke(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>)
            LCFCP$IPipeline$$$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737386)
            
            //--TRIMMABLE-BOUNDARY-START(34361029837)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Name.get
            get LCFCW$IWalletSystem$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080506573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(34361029837)
            
            //--TRIMMABLE-BOUNDARY-START(68720768205)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Title.get
            get LCFCW$IWalletSystem$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260375757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(68720768205)
            
            //--TRIMMABLE-BOUNDARY-START(17181160653)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Icon.get
            get LCFCW$IWalletSystem$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490571981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(17181160653)
            
            //--TRIMMABLE-BOUNDARY-START(60130833613)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Theme.get
            get LCFCW$IWalletSystem$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965408461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(60130833613)
            
            //--TRIMMABLE-BOUNDARY-START(8591226061)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Holder.get
            get LCFCW$IWalletSystem$Holder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195604685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Holder;
            }
            //--TRIMMABLE-BOUNDARY-END(8591226061)
            
            //--TRIMMABLE-BOUNDARY-START(25771095245)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Issuers.get
            get LCFCW$IWalletSystem$Issuers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785539277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Issuers;
            }
            //--TRIMMABLE-BOUNDARY-END(25771095245)
            
            //--TRIMMABLE-BOUNDARY-START(77310702797)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Tokens.get
            get LCFCW$IWalletSystem$Tokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555343053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Tokens;
            }
            //--TRIMMABLE-BOUNDARY-END(77310702797)
            
            //--TRIMMABLE-BOUNDARY-START(42950964429)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.RecentTransactions.get
            get LCFCW$IWalletSystem$RecentTransactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375473869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RecentTransactions;
            }
            //--TRIMMABLE-BOUNDARY-END(42950964429)
            
            //--TRIMMABLE-BOUNDARY-START(51540899021)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Services.get
            get LCFCW$IWalletSystem$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670441165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(51540899021)
            
            //--TRIMMABLE-BOUNDARY-START(85900637389)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.GetTransactions(LivingThing.Core.Frameworks.Common.Data.DataFilter)
            LCFCW$IWalletSystem$GetTransactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900637389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetTransactions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(85900637389)
            
            //--TRIMMABLE-BOUNDARY-START(21476062413)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.Issuers.get
            get LCFCW$IWalletServices$Issuers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245866189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Issuers;
            }
            //--TRIMMABLE-BOUNDARY-END(21476062413)
            
            //--TRIMMABLE-BOUNDARY-START(30065997005)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.OfflinePayment.get
            get LCFCW$IWalletServices$OfflinePayment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540833485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OfflinePayment;
            }
            //--TRIMMABLE-BOUNDARY-END(30065997005)
            
            //--TRIMMABLE-BOUNDARY-START(38655931597)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.OnlinePayment.get
            get LCFCW$IWalletServices$OnlinePayment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835800781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnlinePayment;
            }
            //--TRIMMABLE-BOUNDARY-END(38655931597)
            
            //--TRIMMABLE-BOUNDARY-START(12886127821)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.FundPayment.get
            get LCFCW$IWalletServices$FundPayment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296193229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FundPayment;
            }
            //--TRIMMABLE-BOUNDARY-END(12886127821)
            
            //--TRIMMABLE-BOUNDARY-START(42950898893)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.GetHolder(string)
            LCFCW$IWalletServices$GetHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950898893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHolder(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42950898893)
            
            //--TRIMMABLE-BOUNDARY-START(4295935751)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.GetPeer(System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$GetPeer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295935751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPeer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295935751)
            
            //--TRIMMABLE-BOUNDARY-START(12885870343)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.Pay(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, System.Collections.Generic.Dictionary<(LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer, LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor), double>, string, string?, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator, System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$Pay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885870343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pay(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885870343)
            
            //--TRIMMABLE-BOUNDARY-START(8590837511)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletReceiveProvider.SelfAddress.get
            get LCWCS$IWalletReceiveProvider$SelfAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180772103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SelfAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(8590837511)
            
            //--TRIMMABLE-BOUNDARY-START(12885804807)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletReceiveProvider.Receive(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator)
            LCWCS$IWalletReceiveProvider$Receive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885804807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Receive(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885804807)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(197569595116)
                this.Holder = null;
                //--TRIMMABLE-BOUNDARY-END(197569595116)
                
                //--TRIMMABLE-BOUNDARY-START(240519268076)
                this.OfflineTokens = $.$sl.SL.Enumerable.Empty($.$UlXD.LCPCM.PayCowryTokenModel);
                //--TRIMMABLE-BOUNDARY-END(240519268076)
                
            }
            static $h = 1099500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(249109202668),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850118380,
        "f": 50331649
      },
      "n": "Order",
      "d": 1099500,
      "h": 249109202668,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249109202668),
//--TRIMMABLE-BOUNDARY-START(223339398892),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490380012,
        "f": 50331649
      },
      "n": "Name",
      "d": 1099500,
      "h": 223339398892,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339398892),
//--TRIMMABLE-BOUNDARY-START(347893450476),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799791340,
        "f": 50331649
      },
      "n": "Title",
      "d": 1099500,
      "h": 347893450476,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(347893450476),
//--TRIMMABLE-BOUNDARY-START(201864562412),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310510828,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1099500,
      "h": 201864562412,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864562412),
//--TRIMMABLE-BOUNDARY-START(339303515884),
    {
      "p": 65309014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209856748,
        "f": 50331649
      },
      "n": "Theme",
      "d": 1099500,
      "h": 339303515884,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339303515884),
//--TRIMMABLE-BOUNDARY-START(197569595116),
    {
      "p": 570573,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720576236,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828679404,
        "f": 83886088
      },
      "n": "Holder",
      "d": 1099500,
      "h": 197569595116,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569595116),
//--TRIMMABLE-BOUNDARY-START(214749464300),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900445420,
        "f": 50331649
      },
      "n": "Issuers",
      "d": 1099500,
      "h": 214749464300,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749464300),
//--TRIMMABLE-BOUNDARY-START(352188417772),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389725932,
        "f": 50331649
      },
      "n": "Tokens",
      "d": 1099500,
      "h": 352188417772,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(352188417772),
//--TRIMMABLE-BOUNDARY-START(296353842924),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$OJJQ.LCFCW.IWalletTransaction).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440052972,
        "f": 50331649
      },
      "n": "RecentTransactions",
      "d": 1099500,
      "h": 296353842924,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296353842924),
//--TRIMMABLE-BOUNDARY-START(309238744812),
    {
      "p": 1225933,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619922156,
        "f": 50331649
      },
      "n": "Services",
      "d": 1099500,
      "h": 309238744812,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238744812),
//--TRIMMABLE-BOUNDARY-START(240519268076),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670249196,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418613996,
        "f": 83886082
      },
      "n": "OfflineTokens",
      "d": 1099500,
      "h": 240519268076,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519268076),
//--TRIMMABLE-BOUNDARY-START(236224300780),
    {
      "p": 701645,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080314604,
        "f": 50331649
      },
      "n": "OfflinePayment",
      "d": 1099500,
      "h": 236224300780,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224300780),
//--TRIMMABLE-BOUNDARY-START(244814235372),
    {
      "p": 767181,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260183788,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335008548588,
        "f": 83886088
      },
      "n": "OnlinePayment",
      "d": 1099500,
      "h": 244814235372,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244814235372),
//--TRIMMABLE-BOUNDARY-START(51540707052),
    {
      "p": 505037,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130641644,
        "f": 50331649
      },
      "n": "FundPayment",
      "d": 1099500,
      "h": 51540707052,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540707052),
//--TRIMMABLE-BOUNDARY-START(300648810220),
    {
      "p": 1033991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029987564,
        "f": 50331649
      },
      "n": "SelfAddress",
      "d": 1099500,
      "h": 300648810220,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300648810220)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(231929333484),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h
        }
      ],
      "n": "NotifyTokensSent",
      "d": 1099500,
      "h": 231929333484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929333484),
//--TRIMMABLE-BOUNDARY-START(227634366188),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h
        }
      ],
      "n": "NotifyNewTokensReceived",
      "d": 1099500,
      "h": 227634366188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227634366188),
//--TRIMMABLE-BOUNDARY-START(219044431596),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1099500,
      "h": 219044431596,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(219044431596),
//--TRIMMABLE-BOUNDARY-START(356483385068),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "command",
          "p": 837356
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "addDataLen",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "reportProgress",
          "p": $.$$.S.Action$$($.$$.S.Single).$h,
          "f": 65
        }
      ],
      "n": "Write",
      "d": 1099500,
      "h": 356483385068,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(356483385068),
//--TRIMMABLE-BOUNDARY-START(270584039148),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "rxCommand",
          "p": $.$$.S.Action$$($.$HSAN.LCPCS.ConnectionPacketType).$h
        },
        {
          "n": "hasDataLen",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "reportProgress",
          "p": $.$$.S.Action$$($.$$.S.Single).$h,
          "f": 65
        }
      ],
      "n": "Read",
      "d": 1099500,
      "h": 270584039148,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(270584039148),
//--TRIMMABLE-BOUNDARY-START(257699137260),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "_sender",
          "p": 570573
        },
        {
          "n": "_receiver",
          "p": 570573
        },
        {
          "n": "denomination",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        },
        {
          "n": "progressIndicator",
          "p": 898253
        },
        {
          "n": "ctoken",
          "p": 170852353
        }
      ],
      "n": "PayOffline",
      "d": 1099500,
      "h": 257699137260,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(257699137260),
//--TRIMMABLE-BOUNDARY-START(279173973740),
    {
      "r": $.$$.STT.Task$$($.$$.S.IDisposable).$h,
      "p": [
        {
          "n": "self",
          "p": 570573
        },
        {
          "n": "receiverProgressIndicator",
          "p": 832717
        }
      ],
      "n": "ReceiveOffline",
      "d": 1099500,
      "h": 279173973740,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(279173973740),
//--TRIMMABLE-BOUNDARY-START(274879006444),
    {
      "r": $.$$.STT.Task$$($.$$.S.IDisposable).$h,
      "p": [
        {
          "n": "self",
          "p": 570573
        },
        {
          "n": "receiverProgressIndicator",
          "p": 832717
        }
      ],
      "n": "Receive",
      "d": 1099500,
      "h": 274879006444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274879006444),
//--TRIMMABLE-BOUNDARY-START(292058875628),
    {
      "r": 178454529,
      "p": [
        {
          "n": "remoteClient",
          "p": 1568430
        }
      ],
      "n": "ReceiveTask",
      "d": 1099500,
      "h": 292058875628,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(292058875628),
//--TRIMMABLE-BOUNDARY-START(206159529708),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1568430
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionClient).$h
        }
      ],
      "n": "Invoke",
      "d": 1099500,
      "h": 206159529708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159529708),
//--TRIMMABLE-BOUNDARY-START(210454497004),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1961646
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 1099500,
      "h": 210454497004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454497004),
//--TRIMMABLE-BOUNDARY-START(193274627820),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetTransactions",
      "d": 1099500,
      "h": 193274627820,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(193274627820),
//--TRIMMABLE-BOUNDARY-START(184684693228),
    {
      "r": $.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "networkAddress",
          "p": 1310721
        }
      ],
      "n": "GetHolder",
      "d": 1099500,
      "h": 184684693228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684693228),
//--TRIMMABLE-BOUNDARY-START(47245739756),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "Denominate",
      "d": 1099500,
      "h": 47245739756,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245739756),
//--TRIMMABLE-BOUNDARY-START(188979660524),
    {
      "r": $.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "GetPeer",
      "d": 1099500,
      "h": 188979660524,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(188979660524),
//--TRIMMABLE-BOUNDARY-START(253404169964),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "sender",
          "p": 570573
        },
        {
          "n": "recipient",
          "p": 570573
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        },
        {
          "n": "progressIndicator",
          "p": 898253
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "Pay",
      "d": 1099500,
      "h": 253404169964,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(253404169964)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(304943777516),
    {
      "t": 1296108,
      "n": "service",
      "d": 1099500,
      "h": 304943777516,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(304943777516),
//--TRIMMABLE-BOUNDARY-START(266289071852),
    {
      "t": 963789,
      "n": "qrScanner",
      "d": 1099500,
      "h": 266289071852,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(266289071852),
//--TRIMMABLE-BOUNDARY-START(42950772460),
    {
      "t": 3364499,
      "n": "database",
      "d": 1099500,
      "h": 42950772460,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950772460),
//--TRIMMABLE-BOUNDARY-START(38655805164),
    {
      "t": 1896110,
      "n": "connection",
      "d": 1099500,
      "h": 38655805164,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655805164),
//--TRIMMABLE-BOUNDARY-START(261994104556),
    {
      "t": 3298963,
      "n": "protector",
      "d": 1099500,
      "h": 261994104556,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(261994104556),
//--TRIMMABLE-BOUNDARY-START(343598483180),
    {
      "t": 655361,
      "n": "timeOut",
      "d": 1099500,
      "h": 343598483180,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(343598483180),
//--TRIMMABLE-BOUNDARY-START(34360837868),
    {
      "t": 655361,
      "n": "bufferSize",
      "d": 1099500,
      "h": 34360837868,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34360837868),
//--TRIMMABLE-BOUNDARY-START(283468941036),
    {
      "t": 832717,
      "n": "receiverProgressIndicator",
      "d": 1099500,
      "h": 283468941036,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(283468941036),
//--TRIMMABLE-BOUNDARY-START(287763908332),
    {
      "t": 1595027,
      "n": "receiveSelf",
      "d": 1099500,
      "h": 287763908332,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(287763908332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065870572),
    {
      "p": [
        {
          "n": "service",
          "p": 1296108
        },
        {
          "n": "database",
          "p": 3364499
        },
        {
          "n": "qrScanner",
          "p": 963789
        },
        {
          "n": "connection",
          "p": 1896110
        },
        {
          "n": "protector",
          "p": 3298963
        },
        {
          "n": "issuer",
          "p": 1033964
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1099500,
      "h": 30065870572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065870572)
  ],
  "h": 1099500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletOfflinePaymentProvider, $.$OJJQ.LCFCW.IDenominatedWalletSystem, $.$KuVO.LCFCC.IConnectionEndPoint, $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionClient), $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage), $.$OJJQ.LCFCW.IWalletSystem, $.$OJJQ.LCFCW.IWalletServices, $.$SeJP.LCWCS.IWalletSendProvider, $.$SeJP.LCWCS.IWalletReceiveProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.PayCowryOfflinePaymentProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}PayCowryOfflinePaymentProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1099500)
        
        

        //--TRIMMABLE-BOUNDARY-START(2606828)
        $asm.$cls(`$HSAN.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297574124)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297574124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297574124)
            
            //--TRIMMABLE-BOUNDARY-START(4297574124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297574124)
            
            static $h = 2606828;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297574124),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2606828,
      "h": 4297574124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297574124)
  ],
  "h": 2606828,
  "a": [
    {
      "t": 2541292,
      "c": 4297508588
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2606828)
        
        

        //--TRIMMABLE-BOUNDARY-START(2541292)
        $asm.$cls(`$HSAN.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297508588)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297508588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297508588)
            
            //--TRIMMABLE-BOUNDARY-START(4297508588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297508588)
            
            static $h = 2541292;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297508588),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2541292,
      "h": 4297508588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297508588)
  ],
  "h": 2541292
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2541292)
        
        

        //--TRIMMABLE-BOUNDARY-START(2279148)
        $asm.$cls(`$HSAN.LCPCS$1.Send`, ($self) => class Send extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8592213740)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592213740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592213740)
            
            //--TRIMMABLE-BOUNDARY-START(4297246444)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297246444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297246444)
            
            //--TRIMMABLE-BOUNDARY-START(4297246444)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297246444)
            
            static $h = 2279148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592213740),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2279148,
      "h": 8592213740,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592213740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297246444),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2279148,
      "h": 4297246444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297246444)
  ],
  "h": 2279148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Send`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Send`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2279148)
        
        

        //--TRIMMABLE-BOUNDARY-START(2213612)
        $asm.$cls(`$HSAN.LCPCS$1.Receive`, ($self) => class Receive extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8592148204)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592148204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592148204)
            
            //--TRIMMABLE-BOUNDARY-START(4297180908)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297180908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297180908)
            
            //--TRIMMABLE-BOUNDARY-START(4297180908)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297180908)
            
            static $h = 2213612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592148204),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2213612,
      "h": 8592148204,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592148204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297180908),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2213612,
      "h": 4297180908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297180908)
  ],
  "h": 2213612
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Receive`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Receive`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2213612)
        
        

        //--TRIMMABLE-BOUNDARY-START(2410220)
        $asm.$cls(`$HSAN.LCPCS$1.TransactionListItem`, ($self) => class TransactionListItem extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8592344812)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592344812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592344812)
            
            //--TRIMMABLE-BOUNDARY-START(4297377516)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297377516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297377516)
            
            //--TRIMMABLE-BOUNDARY-START(4297377516)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297377516)
            
            static $h = 2410220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592344812),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2410220,
      "h": 8592344812,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592344812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297377516),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2410220,
      "h": 4297377516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297377516)
  ],
  "h": 2410220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.TransactionListItem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}TransactionListItem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2410220)
        
        

        //--TRIMMABLE-BOUNDARY-START(1558252)
        $asm.$cls(`$HSAN.LCPCS$1._PinEntry`, ($self) => class _PinEntry extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8591492844)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591492844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591492844)
            
            //--TRIMMABLE-BOUNDARY-START(4296525548)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296525548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296525548)
            
            //--TRIMMABLE-BOUNDARY-START(4296525548)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296525548)
            
            static $h = 1558252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591492844),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1558252,
      "h": 8591492844,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591492844)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296525548),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1558252,
      "h": 4296525548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296525548)
  ],
  "h": 1558252
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared._PinEntry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}_PinEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1558252)
        
        

        //--TRIMMABLE-BOUNDARY-START(837356)
        $asm.$str(`$HSAN.LCPCS.ConnectionPacketType`, ($self) => class ConnectionPacketType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static SenderInfo = 1;
            static ReceiverInfo = 2;
            static Token = 3;
            static Ack = 4;
            static PacketContinuation = 5;
            static PacketEnd = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(837356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SenderInfo": 1n,
                    "ReceiverInfo": 2n,
                    "Token": 3n,
                    "Ack": 4n,
                    "PacketContinuation": 5n,
                    "PacketEnd": 6n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295804652)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295804652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295804652)
            
            //--TRIMMABLE-BOUNDARY-START(4295804652)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295804652)
            
            static $h = 837356;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885739244),
    {
      "t": 837356,
      "n": "None",
      "d": 837356,
      "h": 12885739244,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885739244),
//--TRIMMABLE-BOUNDARY-START(30065608428),
    {
      "t": 837356,
      "n": "SenderInfo",
      "d": 837356,
      "h": 30065608428,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065608428),
//--TRIMMABLE-BOUNDARY-START(25770641132),
    {
      "t": 837356,
      "n": "ReceiverInfo",
      "d": 837356,
      "h": 25770641132,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770641132),
//--TRIMMABLE-BOUNDARY-START(34360575724),
    {
      "t": 837356,
      "n": "Token",
      "d": 837356,
      "h": 34360575724,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360575724),
//--TRIMMABLE-BOUNDARY-START(8590771948),
    {
      "t": 837356,
      "n": "Ack",
      "d": 837356,
      "h": 8590771948,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590771948),
//--TRIMMABLE-BOUNDARY-START(17180706540),
    {
      "t": 837356,
      "n": "PacketContinuation",
      "d": 837356,
      "h": 17180706540,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180706540),
//--TRIMMABLE-BOUNDARY-START(21475673836),
    {
      "t": 837356,
      "n": "PacketEnd",
      "d": 837356,
      "h": 21475673836,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475673836)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295804652),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 837356,
      "h": 4295804652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295804652)
  ],
  "h": 837356
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.ConnectionPacketType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}ConnectionPacketType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(837356)
        
        

        //--TRIMMABLE-BOUNDARY-START(1623788)
        $asm.$cls(`$HSAN.LCPCS$1.Error`, ($self) => class Error extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(51541231340)
            /*string?*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(51541231340)
            
            //--TRIMMABLE-BOUNDARY-START(21476460268)
            /*string?*/ Details = null;
            //--TRIMMABLE-BOUNDARY-END(21476460268)
            
            //--TRIMMABLE-BOUNDARY-START(55836198636)
            /*string */ get OptimizedComponentName()
            {
                return "error";
            }
            //--TRIMMABLE-BOUNDARY-END(55836198636)
            
            //--TRIMMABLE-BOUNDARY-START(77311035116)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311035116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Message":
                    this.Message = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Details":
                    this.Details = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(77311035116)
            
            //--TRIMMABLE-BOUNDARY-START(17181492972)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181492972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf stack pd-10");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "mg-a text-center");
                __builder.AddMarkupContent(4, "<i class=\"d-block mgx-a mdi mdi-alert cl-error fsz-40\"></i>\r\n        ");
                __builder.OpenElement(5, "h3");
                __builder.AddAttribute$5(6, "class", "cl-primary");
                __builder.AddContent$4(7, this.Message);
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n        ");
                __builder.OpenElement(9, "p");
                __builder.AddContent$4(10, this.Details);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17181492972)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886525676)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886525676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886525676)
            
            //--TRIMMABLE-BOUNDARY-START(12886525676)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886525676)
            
            static $h = 1623788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541231340),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656329452,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016067820,
        "f": 83886081
      },
      "n": "Message",
      "d": 1623788,
      "h": 51541231340,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541231340),
//--TRIMMABLE-BOUNDARY-START(21476460268),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066394860,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426133228,
        "f": 83886081
      },
      "n": "Details",
      "d": 1623788,
      "h": 21476460268,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476460268),
//--TRIMMABLE-BOUNDARY-START(55836198636),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246264044,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1623788,
      "h": 55836198636,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836198636)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77311035116),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1623788,
      "h": 77311035116,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311035116),
//--TRIMMABLE-BOUNDARY-START(17181492972),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1623788,
      "h": 17181492972,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181492972)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886525676),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1623788,
      "h": 12886525676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886525676)
  ],
  "h": 1623788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Error`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Error`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1623788)
        
        

        //--TRIMMABLE-BOUNDARY-START(2082540)
        $asm.$cls(`$HSAN.LCPCS$1.PinLogin`, ($self) => class PinLogin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(73016526572)
            /*string */ get OptimizedComponentName()
            {
                return "pinlogin";
            }
            //--TRIMMABLE-BOUNDARY-END(73016526572)
            
            //--TRIMMABLE-BOUNDARY-START(103081297644)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081297644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "OnLoggedIn":
                    this.OnLoggedIn = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(103081297644)
            
            //--TRIMMABLE-BOUNDARY-START(60131624684)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131624684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60131624684)
            
            //--TRIMMABLE-BOUNDARY-START(77311493868)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(77311493868)
            
            //--TRIMMABLE-BOUNDARY-START(68721559276)
            /*EventCallback*/ OnLoggedIn;
            //--TRIMMABLE-BOUNDARY-END(68721559276)
            
            //--TRIMMABLE-BOUNDARY-START(98786330348)
            /*string?*/ transactionPin = null;
            //--TRIMMABLE-BOUNDARY-END(98786330348)
            
            //--TRIMMABLE-BOUNDARY-START(17181951724)
            /*PayCowryOfflineAccountModel*/ account = null;
            //--TRIMMABLE-BOUNDARY-END(17181951724)
            
            //--TRIMMABLE-BOUNDARY-START(64426591980)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426591980);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.account = ($t2 = this.Service.LocalDatabase.LCPCS$ILocalDatabase$Load(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64426591980)
            
            //--TRIMMABLE-BOUNDARY-START(25771886316)
            /*Task */ Check()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771886316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                const $t4 = this.transactionPin;
                if ($.$ifnn($t4, ($t) => $t.length) === 4)
                {
                    return this.Verify();
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(25771886316)
            
            //--TRIMMABLE-BOUNDARY-START(30066853612)
            /*string?*/ err = null;
            //--TRIMMABLE-BOUNDARY-END(30066853612)
            
            //--TRIMMABLE-BOUNDARY-START(107376264940)
            /*Task *//*async*/  Verify()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376264940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.transactionPin !== null)
                    {
                        /*var*/ let verified = this.Service.Protector.LCPCS$IDataProtector$ValidatePin(this.transactionPin, this.account.Pin);
                        if (verified)
                        {
                            let $t5, $r5;
                            ($t5 = this.OnLoggedIn.InvokeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                        else 
                        {
                            this.transactionPin = null;
                            this.err = "Invalid Pin";
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107376264940)
            
            //--TRIMMABLE-BOUNDARY-START(21476919020)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476919020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACF.EditForm, 0);
                __builder.AddComponentParameter(1, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                __builder.AddComponentParameter(2, "class", "hf stack pd");
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(4, "<h1 class=\"text-center fsz-40 mgb-0\">\r\n        Enter your PIN Code\r\n    </h1>\r\n    ");
                        __builder2.AddMarkupContent(5, "<p class=\"text-center\">\r\n        PayCowry protects your account with a PIN code you created earlier, so nobody with access to your device can access your funds\r\n    </p>\r\n\r\n    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 6);
                        __builder2.AddComponentParameter(7, "Class", "fsz-30");
                        __builder2.AddComponentParameter(8, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(9, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, 78n), $.$fPer.LCFC.InputType));
                        __builder2.AddComponentParameter(10, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.transactionPin));
                        __builder2.AddComponentParameter(11, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this.transactionPin = __value;
                            return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Check));
                        }, $lCAJLh ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":2082540,"h":0,"f":17825794}), this.transactionPin), this.transactionPin))));
                        __builder2.AddComponentParameter(12, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "transactionPin"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $DaUTUd ??= {"r":38797349,"n":"","d":2082540,"h":0,"f":17825794})).Invoke())));
                        /*var*/ let  [ _6, _7 ] = $.$destructure(new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3("Value", 0), 2);
                        __builder2.CloseComponent();
                        if (this.err !== null)
                        {
                            __builder2.OpenElement(13, "p");
                            __builder2.AddAttribute$5(14, "class", "text-center cl-error");
                            __builder2.AddContent$4(15, this.err);
                            __builder2.CloseElement();
                        }
                        __builder2.AddMarkupContent(16, "<div class=\"fill\"></div>\r\n    ");
                        __builder2.OpenElement(17, "div");
                        __builder2.AddAttribute$5(18, "class", "flex");
                        __builder2.AddMarkupContent(19, "<div class=\"fill\"></div>\r\n        ");
                        __builder2.OpenElement(20, "div");
                        __builder2.AddAttribute$5(21, "class", "flex");
                        __builder2.AddMarkupContent(22, "<span class=\"mgy-a bg-primary pdx pdy-2 corner-l-5 hx-03 mgr--2\">Continue</span>\r\n            ");
                        __builder2.OpenElement(23, "button");
                        __builder2.AddAttribute$5(24, "class", "mdi mdi-chevron-right fsz-25 bg-primary wx-05 hx-05 round");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 25, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Verify)));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $NMRyBa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2082540,"h":0,"f":17825794});
                }), $stHMUc ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":2082540,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21476919020)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886984428)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886984428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886984428)
            
            //--TRIMMABLE-BOUNDARY-START(12886984428)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886984428)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77311493868)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(77311493868)
                
                //--TRIMMABLE-BOUNDARY-START(68721559276)
                this.OnLoggedIn = $.$default($.$mac.MAC.EventCallback);
                //--TRIMMABLE-BOUNDARY-END(68721559276)
                
                //--TRIMMABLE-BOUNDARY-START(17181951724)
                this.account = null;
                //--TRIMMABLE-BOUNDARY-END(17181951724)
                
            }
            static $h = 2082540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016526572),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246722796,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2082540,
      "h": 73016526572,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73016526572),
//--TRIMMABLE-BOUNDARY-START(77311493868),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836657388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491363052,
        "f": 83886081
      },
      "n": "Service",
      "d": 2082540,
      "h": 77311493868,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311493868),
//--TRIMMABLE-BOUNDARY-START(68721559276),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656788204,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901428460,
        "f": 83886081
      },
      "n": "OnLoggedIn",
      "d": 2082540,
      "h": 68721559276,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68721559276)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103081297644),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2082540,
      "h": 103081297644,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103081297644),
//--TRIMMABLE-BOUNDARY-START(60131624684),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2082540,
      "h": 60131624684,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131624684),
//--TRIMMABLE-BOUNDARY-START(64426591980),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2082540,
      "h": 64426591980,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(64426591980),
//--TRIMMABLE-BOUNDARY-START(25771886316),
    {
      "r": 178454529,
      "n": "Check",
      "d": 2082540,
      "h": 25771886316,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25771886316),
//--TRIMMABLE-BOUNDARY-START(107376264940),
    {
      "r": 178454529,
      "n": "Verify",
      "d": 2082540,
      "h": 107376264940,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(107376264940),
//--TRIMMABLE-BOUNDARY-START(21476919020),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2082540,
      "h": 21476919020,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476919020)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98786330348),
    {
      "t": 1310721,
      "n": "transactionPin",
      "d": 2082540,
      "h": 98786330348,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98786330348),
//--TRIMMABLE-BOUNDARY-START(17181951724),
    {
      "t": 1595027,
      "n": "account",
      "d": 2082540,
      "h": 17181951724,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181951724),
//--TRIMMABLE-BOUNDARY-START(30066853612),
    {
      "t": 1310721,
      "n": "err",
      "d": 2082540,
      "h": 30066853612,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066853612)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886984428),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2082540,
      "h": 12886984428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886984428)
  ],
  "h": 2082540
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.PinLogin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}PinLogin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2082540)
        
        

        //--TRIMMABLE-BOUNDARY-START(1951468)
        $asm.$cls(`$HSAN.LCPCS$1.PayCowryWalletReceive`, ($self) => class PayCowryWalletReceive extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(68721428204)
            /*string */ get OptimizedComponentName()
            {
                return "paycowrywalletreceive";
            }
            //--TRIMMABLE-BOUNDARY-END(68721428204)
            
            //--TRIMMABLE-BOUNDARY-START(103081166572)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081166572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "TransactionType":
                    this.TransactionType = $.$cast(parameter.Value, $.$$.S.Nullable$$($.$UlXD.LCPCM.PayCowryTransactionType));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(103081166572)
            
            //--TRIMMABLE-BOUNDARY-START(60131493612)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131493612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60131493612)
            
            //--TRIMMABLE-BOUNDARY-START(98786199276)
            /*PayCowryTransactionType?*/ TransactionType = null;
            //--TRIMMABLE-BOUNDARY-END(98786199276)
            
            //--TRIMMABLE-BOUNDARY-START(73016395500)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(73016395500)
            
            //--TRIMMABLE-BOUNDARY-START(94491231980)
            /*PayCowryTransactionType*/ transactionType = 0;
            //--TRIMMABLE-BOUNDARY-END(94491231980)
            
            //--TRIMMABLE-BOUNDARY-START(51541559020)
            /*void */ GoOffline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541559020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.transactionType = 0/*PayCowryTransactionType.Offline*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51541559020)
            
            //--TRIMMABLE-BOUNDARY-START(55836526316)
            /*void */ GoOnline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836526316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.transactionType = 1/*PayCowryTransactionType.Online*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55836526316)
            
            //--TRIMMABLE-BOUNDARY-START(64426460908)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426460908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.TransactionType !== null)
                    {
                        let $t2, $r2;
                        this.transactionType = $.$$.S.Nullable$$($.$UlXD.LCPCM.PayCowryTransactionType).Value$get.call(this.TransactionType);
                        ($t2 = this.Forward(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64426460908)
            
            //--TRIMMABLE-BOUNDARY-START(21476787948)
            /*ValueTask *//*async*/  Forward()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476787948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = $.$hDPm.LCFCI.ViewPresenterExtensions.CancelAll($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    if (this.transactionType === 0/*PayCowryTransactionType.Offline*/ && this.Service.OfflinePaymentProvider === null)
                    {
                        let $t5, $r5;
                        ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$HSAN.LCPCS$1.Error, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                        {
                            builder.AddAttribute$5(1, "Message", "Offline Cowry receive is disabled");
                            builder.AddAttribute$5(2, "Details", "This can happen if you are using PayCorwy in a browser. Use the mobile app instead!");
                        }, $EQcZIf ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":1951468,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*CancellationTokenSource*/ let cts = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    ($t6 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletReceive, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                    {
                        builder.AddAttribute$4(1, "Wallet", this.transactionType === 1/*PayCowryTransactionType.Online*/ ? this.Service.OnlineWalletProvider : this.Service.OfflinePaymentProvider);
                        builder.AddAttribute$4(2, "WalletReceiveProvider", this.transactionType === 1/*PayCowryTransactionType.Online*/ ? this.Service.OnlineWalletProvider : this.Service.OfflinePaymentProvider);
                        builder.AddAttribute$1(3, "OnFinished", $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t7, $r7;
                                cts.Cancel();
                                ($t7 = this.Service.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            });
                        }, $ulfMsk ??= {"r":178454529,"n":"","d":1951468,"h":0,"f":17829890})));
                    }, $XQwVua ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":1951468,"h":0,"f":17825794}), cts.Token, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476787948)
            
            //--TRIMMABLE-BOUNDARY-START(17181820652)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181820652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd");
                __builder.AddMarkupContent(2, "<h1 class=\"text-center mgt-0\">Select the type of transaction</h1>\r\n    ");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "flex");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.GoOffline)));
                __builder.OpenElement(6, "i");
                __builder.AddAttribute$5(7, "class", $.$strNN($.$strNN("mdi" + " ") + $.$strNN((this.transactionType === 0/*PayCowryTransactionType.Offline*/ ? "mdi-checkbox-outline cl-primary" : "mdi-checkbox-blank-outline"))) + " fsz-30");
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n        ");
                __builder.AddMarkupContent(9, "<div class=\"mgl stack\"><h3 class=\"mg-0\">Offline</h3>\r\n            <p class=\"mg-0\">\r\n                Fund is taken from your Offline PayCowry tokens. No internet is required by both parties to transact.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n    ");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "flex mgt");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 13, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.GoOnline)));
                __builder.OpenElement(14, "i");
                __builder.AddAttribute$5(15, "class", $.$strNN($.$strNN("mdi" + " ") + $.$strNN((this.transactionType === 1/*PayCowryTransactionType.Online*/ ? "mdi-checkbox-outline cl-primary" : "mdi-checkbox-blank-outline"))) + " fsz-30");
                __builder.CloseElement();
                __builder.AddMarkupContent(16, "\r\n        ");
                __builder.AddMarkupContent(17, "<div class=\"mgl stack\"><h3 class=\"mg-0\">Online</h3>\r\n            <p class=\"mg-0\">\r\n                Fund is taken from your Online Wallet. Requires internet connection on this end.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(18, "\r\n    ");
                __builder.OpenElement(19, "div");
                __builder.AddAttribute$5(20, "class", "flex mgt");
                __builder.AddMarkupContent(21, "<div class=\"fill\"></div>\r\n        ");
                __builder.OpenElement(22, "div");
                __builder.AddAttribute$5(23, "class", "flex");
                __builder.AddMarkupContent(24, "<span class=\"mgy-a bg-primary pdx pdy-2 corner-l-5 hx-03 mgr--2\">Continue</span>\r\n            ");
                __builder.OpenElement(25, "button");
                __builder.AddAttribute$5(26, "class", "mdi mdi-chevron-right fsz-25 bg-primary wx-05 hx-05 round");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 27, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forward)));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17181820652)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886853356)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886853356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886853356)
            
            //--TRIMMABLE-BOUNDARY-START(12886853356)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886853356)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98786199276)
                this.TransactionType = null;
                //--TRIMMABLE-BOUNDARY-END(98786199276)
                
                //--TRIMMABLE-BOUNDARY-START(73016395500)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(73016395500)
                
            }
            static $h = 1951468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721428204),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066722540,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1951468,
      "h": 68721428204,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68721428204),
//--TRIMMABLE-BOUNDARY-START(98786199276),
    {
      "p": $.$typeNullable($.$UlXD.LCPCM.PayCowryTransactionType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246591724,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196264684,
        "f": 83886081
      },
      "n": "TransactionType",
      "d": 1951468,
      "h": 98786199276,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98786199276),
//--TRIMMABLE-BOUNDARY-START(73016395500),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656657132,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606330092,
        "f": 83886081
      },
      "n": "Service",
      "d": 1951468,
      "h": 73016395500,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016395500)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103081166572),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1951468,
      "h": 103081166572,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103081166572),
//--TRIMMABLE-BOUNDARY-START(60131493612),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1951468,
      "h": 60131493612,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131493612),
//--TRIMMABLE-BOUNDARY-START(51541559020),
    {
      "r": 65537,
      "n": "GoOffline",
      "d": 1951468,
      "h": 51541559020,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541559020),
//--TRIMMABLE-BOUNDARY-START(55836526316),
    {
      "r": 65537,
      "n": "GoOnline",
      "d": 1951468,
      "h": 55836526316,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836526316),
//--TRIMMABLE-BOUNDARY-START(64426460908),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1951468,
      "h": 64426460908,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(64426460908),
//--TRIMMABLE-BOUNDARY-START(21476787948),
    {
      "r": 181338113,
      "n": "Forward",
      "d": 1951468,
      "h": 21476787948,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476787948),
//--TRIMMABLE-BOUNDARY-START(17181820652),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1951468,
      "h": 17181820652,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181820652)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94491231980),
    {
      "t": 2840211,
      "n": "transactionType",
      "d": 1951468,
      "h": 94491231980,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94491231980)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886853356),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1951468,
      "h": 12886853356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886853356)
  ],
  "h": 1951468
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.PayCowryWalletReceive`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}PayCowryWalletReceive`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1951468)
        
        

        //--TRIMMABLE-BOUNDARY-START(640748)
        $asm.$cls(`$HSAN.LCPCP.LoyaltyRewardSpinWheel`, ($self) => class LoyaltyRewardSpinWheel extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(90194953964)
            /*string */ get OptimizedComponentName()
            {
                return "loyaltyrewardspinwheel";
            }
            //--TRIMMABLE-BOUNDARY-END(90194953964)
            
            //--TRIMMABLE-BOUNDARY-START(73015084780)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015084780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ThemeAccessor = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IThemeAccessor, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73015084780)
            
            //--TRIMMABLE-BOUNDARY-START(120259725036)
            /*SpinWheel?*/ spinWheel = null;
            //--TRIMMABLE-BOUNDARY-END(120259725036)
            
            //--TRIMMABLE-BOUNDARY-START(94489921260)
            /*ElementReference*/ overlayImage;
            //--TRIMMABLE-BOUNDARY-END(94489921260)
            
            //--TRIMMABLE-BOUNDARY-START(98784888556)
            /*IEnumerable<SpinWheelParticipant>?*/ participants = null;
            //--TRIMMABLE-BOUNDARY-END(98784888556)
            
            //--TRIMMABLE-BOUNDARY-START(103079855852)
            /*IEnumerable<PaymentModel>?*/ payments = null;
            //--TRIMMABLE-BOUNDARY-END(103079855852)
            
            //--TRIMMABLE-BOUNDARY-START(128849659628)
            /*IThemeAccessor*/ ThemeAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(128849659628)
            
            //--TRIMMABLE-BOUNDARY-START(68720117484)
            /*bool */ get HasAWinner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360379116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.PaymentModel>?*/ let __ca1__;
                return ((__ca1__ = this.payments) !== null ? $.$sl.SL.Enumerable.Any($.$Iaui.LCFCM.PaymentModel, __ca1__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.DataPropertyModel>?*/ let __ca2__;
                    return ((__ca2__ = p.Properties) !== null ? $.$sl.SL.Enumerable.Any($.$Iaui.LCFCM.DataPropertyModel, __ca2__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.DataPropertyModel, $.$$.S.Boolean))().$ctor(this,  (/*pp*/ pp) =>
                    {
                        return $.$$.S.String.StartsWith$3.call(pp.Type, "PayCowry/Wallet/SpinWheel"/*PayCowryConstants.SpinWheelWinnerPropertyPrefix*/);
                    }, $okwCsb ??= {"r":262145,"p":[{"n":"pp","p":6497622}],"n":"","d":640748,"h":0,"f":17825794})) : false);
                }, $hJKLHc ??= {"r":262145,"p":[{"n":"p","p":12592470}],"n":"","d":640748,"h":0,"f":17825794})) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(68720117484)
            
            //--TRIMMABLE-BOUNDARY-START(133144626924)
            /*IEnumerable<PaymentModel>? */ get Winners()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130182892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.PaymentModel>?*/ let __ca3__;
                return _ = ((__ca3__ = this.payments) !== null ? $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.PaymentModel, __ca3__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.DataPropertyModel>?*/ let __ca4__;
                    return ((__ca4__ = p.Properties) !== null ? $.$sl.SL.Enumerable.Any($.$Iaui.LCFCM.DataPropertyModel, __ca4__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.DataPropertyModel, $.$$.S.Boolean))().$ctor(this,  (/*pp*/ pp) =>
                    {
                        return $.$$.S.String.StartsWith$3.call(pp.Type, "PayCowry/Wallet/SpinWheel"/*PayCowryConstants.SpinWheelWinnerPropertyPrefix*/);
                    }, $eIGEoc ??= {"r":262145,"p":[{"n":"pp","p":6497622}],"n":"","d":640748,"h":0,"f":17825794})) : false);
                }, $vKDnbc ??= {"r":262145,"p":[{"n":"p","p":12592470}],"n":"","d":640748,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(133144626924)
            
            //--TRIMMABLE-BOUNDARY-START(64425150188)
            /*string? */ GetIcon(/*PaymentModel*/ payment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425150188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca5__;
                if ((__ca5__ = payment.Summary) !== null ? $.$$.S.String.Contains$2.call(__ca5__, "airtime", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)
                {
                    return "mdi mdi-phone";
                }
                /*string?*/ let __ca6__;
                if ((__ca6__ = payment.Summary) !== null ? $.$$.S.String.Contains$2.call(__ca6__, "internet", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)
                {
                    return "mdi mdi-connection";
                }
                /*string?*/ let __ca7__;
                /*string?*/ let __ca8__;
                if ((((__ca7__ = payment.Summary) !== null ? $.$$.S.String.Contains$2.call(__ca7__, "power", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)) || (((__ca8__ = payment.Summary) !== null ? $.$$.S.String.Contains$2.call(__ca8__, "energy", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)))
                {
                    return "mdi mdi-lightbulb-on";
                }
                /*string?*/ let __ca9__;
                if ((__ca9__ = payment.Summary) !== null ? $.$$.S.String.Contains$2.call(__ca9__, "tv", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)
                {
                    return "mdi mdi-youtube-tv";
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(64425150188)
            
            //--TRIMMABLE-BOUNDARY-START(124554692332)
            /*ThemeColors?*/ theme = null;
            //--TRIMMABLE-BOUNDARY-END(124554692332)
            
            //--TRIMMABLE-BOUNDARY-START(21475477228)
            /*DateTime*/ date;
            //--TRIMMABLE-BOUNDARY-END(21475477228)
            
            //--TRIMMABLE-BOUNDARY-START(17180509932)
            /*CancellationTokenSource?*/ cancelSpin = null;
            //--TRIMMABLE-BOUNDARY-END(17180509932)
            
            //--TRIMMABLE-BOUNDARY-START(77310052076)
            /*Task *//*async*/  Load(/*DateTime?*/ date)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310052076);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.theme ??= ($t1 = this.ThemeAccessor.LCFCC$IThemeAccessor$GetTheme(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.payments = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute($.$UlXD.LCPCS.IPayCowryRemoteService, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, /*async*/  (/**/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))), $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)), async ($asnycContext) => 
                        {
                            let $t3, $r3;
                            return ($t3 = server.LCPCS$IPayCowryRemoteService$GetSpinWheelParticipants($.$clone(date)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        });
                    }, $yTAnSj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))).$h,"p":[{"n":"server","p":3561107}],"n":"","d":640748,"h":0,"f":17829890}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.participants = $.$sl.SL.Enumerable.ToList($.$hDPm.LCFCCS$10.SpinWheelParticipant, $.$sl.SL.Enumerable.Select($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCS$10.SpinWheelParticipant, this.payments, new ($.$$.S.Func$$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Int32, $.$hDPm.LCFCCS$10.SpinWheelParticipant))().$ctor(this,  (/**/ e, /*i*/ i) =>
                    {
                        return (() =>
                        {
                            //new $.$hDPm.LCFCCS$10.SpinWheelParticipant()
                            const $t4 = $.$hDPm.LCFCCS$10.SpinWheelParticipant;
                            const $i4 = new $t4();
                            $i4.$ctor$1();
                            $i4.Label = e.User.Name;
                            return $i4;
                        })();
                    }, $cIOTTh ??= {"r":46159530,"p":[{"n":"e","p":12592470},{"n":"i","p":655361}],"n":"","d":640748,"h":0,"f":17825794})));
                    if (date === null)
                    {
                        /*var*/ let mdate = $.$$.S.DateTime.UtcNow;
                        this.date = new $.$$.S.DateTime().$ctor$6(mdate.Year, mdate.Month, mdate.Day, 18/*PayCowryConstants.SpinWheelHour*/, 0, 0, 1/*DateTimeKind.Utc*/);
                    }
                    else 
                    {
                        this.date = new $.$$.S.DateTime().$ctor$6($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(date).Year, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(date).Month, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(date).Day, 18/*PayCowryConstants.SpinWheelHour*/, 0, 0, 1/*DateTimeKind.Utc*/);
                    }
                    this.cancelSpin?.Cancel();
                    if (!this.HasAWinner && $.$$.S.DateTime.op_GreaterThan(this.date, $.$$.S.DateTime.UtcNow))
                    {
                        this.cancelSpin = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                        _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                            {
                                while(true)
                                {
                                    let $t5, $r5;
                                    ($t5 = $.$$.STT.Task.Delay(60000, this.cancelSpin.Token), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                    this.StateHasChanged();
                                }
                            });
                        }, $qRTsse ??= {"r":178454529,"n":"","d":640748,"h":0,"f":17829890}));
                        /*int*/ let milliSecondsLeft = $.$cast(($.$$.S.DateTime.op_Subtraction$1(this.date, $.$$.S.DateTime.UtcNow)).TotalMicroseconds, $.$$.S.Int32);
                        _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t6, $r6;
                                ($t6 = $.$$.STT.Task.Delay(milliSecondsLeft, this.cancelSpin.Token), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                /*IEnumerable<PaymentModel>?*/ let winners = null;
                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.PaymentModel>?*/ let __ca13__;
                                do
                                {
                                    let $t7, $r7;
                                    /*var*/ let payments = ($t7 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute($.$UlXD.LCPCS.IPayCowryRemoteService, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, /*async*/  (/*server*/ server) =>
                                    {
                                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))), $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)), async ($asnycContext) => 
                                        {
                                            let $t8, $r8;
                                            return ($t8 = server.LCPCS$IPayCowryRemoteService$GetSpinWheelParticipants($.$clone(date)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                        });
                                    }, $ORiigl ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))).$h,"p":[{"n":"server","p":3561107}],"n":"","d":640748,"h":0,"f":17829890}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.PaymentModel>?*/ let __ca10__;
                                    winners = ((__ca10__ = payments) !== null ? $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.PaymentModel, __ca10__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                                    {
                                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.DataPropertyModel>?*/ let __ca11__;
                                        return ((__ca11__ = p.Properties) !== null ? $.$sl.SL.Enumerable.Any($.$Iaui.LCFCM.DataPropertyModel, __ca11__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.DataPropertyModel, $.$$.S.Boolean))().$ctor(this,  (/*pp*/ pp) =>
                                        {
                                            return $.$$.S.String.StartsWith$3.call(pp.Type, "PayCowry/Wallet/SpinWheel"/*PayCowryConstants.SpinWheelWinnerPropertyPrefix*/);
                                        }, $NgjvRh ??= {"r":262145,"p":[{"n":"pp","p":6497622}],"n":"","d":640748,"h":0,"f":17825794})) : false);
                                    }, $PeZcXg ??= {"r":262145,"p":[{"n":"p","p":12592470}],"n":"","d":640748,"h":0,"f":17825794})) : null);
                                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.PaymentModel>?*/ let __ca12__;
                                    if ((__ca12__ = winners) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.PaymentModel, __ca12__) : false)
                                    {
                                        let $en9 = winners.SCG$IEnumerable$$$GetEnumerator();
                                        while ($en9.SC$1$IEnumerator$MoveNext())
                                        {
                                            let winner = $en9.SCG$IEnumerator$$$Current;
                                            {
                                                let $t10, $r10;
                                                /*var*/ let winnerParticipant = $.$sl.SL.Enumerable.Single($.$Iaui.LCFCM.PaymentModel, payments, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/**/ p) =>
                                                {
                                                    return (p.User?.Name ?? null) === winner.Name;
                                                }, $Ufbazc ??= {"r":262145,"p":[{"n":"p","p":12592470}],"n":"","d":640748,"h":0,"f":17825794}));
                                                /*int*/ let winnerIndex = $.$$.S.Array.IndexOf$5($.$Iaui.LCFCM.PaymentModel, $.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.PaymentModel, payments), winner);
                                                this.spinWheel.Wheel.LCFCCS$10$ISpinWheel$spinToItem(winnerIndex, 0, true, 1, 1);
                                                ($t10 = $.$$.STT.Task.Delay$1(5000), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                                            }
                                        }
                                        this.payments = payments;
                                        this.StateHasChanged();
                                    }
                                    else 
                                    {
                                        let $t11, $r11;
                                        ($t11 = $.$$.STT.Task.Delay(5000, this.cancelSpin.Token), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                    }
                                }
                                while(!(((__ca13__ = winners) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.PaymentModel, __ca13__) : false)));
                            });
                        }, $Vwwnag ??= {"r":178454529,"n":"","d":640748,"h":0,"f":17829890}));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310052076)
            
            //--TRIMMABLE-BOUNDARY-START(81605019372)
            /*Task */ Next()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605019372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.DateTime.op_LessThan(this.date.Date, $.$$.S.DateTime.UtcNow.Date))
                {
                    return this.Load(this.date.AddDays(1));
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(81605019372)
            
            //--TRIMMABLE-BOUNDARY-START(107374823148)
            /*Task */ Previous()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374823148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(this.date.AddDays(-1));
            }
            //--TRIMMABLE-BOUNDARY-END(107374823148)
            
            //--TRIMMABLE-BOUNDARY-START(85899986668)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    let $t13, $r13;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899986668);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t12 = this.Load(null), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    ($t13 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899986668)
            
            //--TRIMMABLE-BOUNDARY-START(25770444524)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770444524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.cancelSpin !== null)
                {
                    this.cancelSpin.Cancel();
                }
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(25770444524)
            
            //--TRIMMABLE-BOUNDARY-START(12885542636)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885542636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "img");
                __builder.AddAttribute$5(1, "src", this.ResolvePath("spinWheelOverlay.svg", true, false, false));
                __builder.AddAttribute$5(2, "class", "op-0 wx-0 hx-0 d-hide");
                __builder.AddElementReferenceCapture(3, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.overlayImage = __value;
                }, $HQadOk ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":640748,"h":0,"f":17825794}));
                __builder.CloseElement();
                __builder.AddMarkupContent(4, "\r\n\r\n");
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "hv-10 stack");
                __builder.SetKey(this.date);
                __builder.OpenElement(7, "div");
                __builder.AddAttribute$5(8, "class", "bg-success stack clip hx-4 pos-rel");
                if (this.participants !== null)
                {
                    if (this.HasAWinner)
                    {
                        __builder.OpenElement(9, "div");
                        __builder.AddAttribute$5(10, "class", "flex pos-abs t-0 l-0 r-0 b-0 bg-success-09");
                        __builder.OpenElement(11, "div");
                        __builder.AddAttribute$5(12, "class", "mg-a stack");
                        __builder.AddMarkupContent(13, "<h2 class=\"mgx-a\">We have a WINNER!</h2>\r\n                        ");
                        __builder.OpenElement(14, "button");
                        __builder.AddAttribute$5(15, "class", "mgx-a fsz-80 corner-5 bg-warning-09 bd bdw-10 bd-warning cl-white pd");
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.PaymentModel>?*/ let __ca1__;
                        __builder.AddContent$4(16, $.$$.S.String.Join$5(",", ((__ca1__ = this.Winners) !== null ? ($.$sl.SL.Enumerable.Select$1($.$Iaui.LCFCM.PaymentModel, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.String))().$ctor(this,  (/**/ w) =>
                        {
                            return (w.User?.Name ?? null);
                        }, $TPvrDj ??= {"r":1310721,"p":[{"n":"w","p":12592470}],"n":"","d":640748,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String))));
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    if ($.$sl.SL.Enumerable.Any$1($.$hDPm.LCFCCS$10.SpinWheelParticipant, this.participants))
                    {
                        if (this.overlayImage.Id !== null)
                        {
                            __builder.OpenComponent$1($.$hDPm.LCFCCS$10.SpinWheel, 17);
                            __builder.AddComponentParameter(18, "Radius", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, 0.88), $.$$.S.Double));
                            __builder.AddComponentParameter(19, "ItemLabelAlign", "left");
                            __builder.AddComponentParameter(20, "ItemLabelRadius", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, 0.93), $.$$.S.Double));
                            __builder.AddComponentParameter(21, "ItemLabelRotation", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 180), $.$$.S.Int32));
                            __builder.AddComponentParameter(22, "ItemLabelColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "#000" ], null, null)));
                            __builder.AddComponentParameter(23, "ItemLabelBaselineOffset", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, -0.06), $.$$.S.Double));
                            __builder.AddComponentParameter(24, "ItemLabelFont", "Arial");
                            __builder.AddComponentParameter(25, "ItemLabelFontSizeMax", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 22), $.$$.S.Int32));
                            __builder.AddComponentParameter(26, "LineWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 1), $.$$.S.Int32));
                            __builder.AddComponentParameter(27, "LineColor", "#000");
                            __builder.AddComponentParameter(28, "OverlayImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.ElementReference, this.overlayImage));
                            __builder.AddComponentParameter(29, "Participants", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$hDPm.LCFCCS$10.SpinWheelParticipant), this.participants));
                            __builder.AddComponentParameter(30, "Style", "height:400px");
                            __builder.AddComponentReferenceCapture(31, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.spinWheel = $.$cast(__value, $.$hDPm.LCFCCS$10.SpinWheel);
                            }, $dvnymh ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":640748,"h":0,"f":17825794}));
                            __builder.CloseComponent();
                        }
                    }
                    else 
                    {
                        __builder.OpenElement(32, "div");
                        __builder.AddAttribute$5(33, "class", "text-center mawx-5 mg-a");
                        __builder.AddMarkupContent(34, "<h3>There are no entry for this contest</h3>");
                        if ($.$$.S.DateTime.op_Equality(this.date.Date, $.$$.S.DateTime.UtcNow.Date))
                        {
                            __builder.AddMarkupContent(35, "<p>\r\n                            Be the first to enter by purchasing a service\r\n                            <b>\r\n                                (Airtime / Internet data / Energy Tariff / TV Subscription)\r\n                            </b>\r\n                            using PayCowry\r\n                        </p>\r\n                        ");
                            __builder.AddMarkupContent(36, "<div class=\"flex flex-center-x\"><a class=\"bg-primary fsz-30 pdx-10 pdy-3 corner-5 d-block mdi mdi-telegram\" href=\"https://t.me/PayCowryBot\" target=\"_blank\">Buy on Telegram</a></div>");
                        }
                        __builder.CloseElement();
                    }
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 37);
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(38, "\r\n    ");
                __builder.OpenElement(39, "div");
                __builder.AddAttribute$5(40, "class", "pd bg-success-01 fill scroll");
                __builder.OpenElement(41, "div");
                __builder.AddAttribute$5(42, "class", "flex");
                __builder.OpenElement(43, "button");
                __builder.AddAttribute$5(44, "title", "Previous day");
                __builder.AddAttribute$5(45, "class", "mdi mdi-chevron-double-left fsz-35 wx-05 hx-05 bd round bg-warning flex mgc-a sd");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 46, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Previous)));
                __builder.CloseElement();
                __builder.AddMarkupContent(47, "\r\n            ");
                __builder.OpenElement(48, "h2");
                __builder.AddAttribute$5(49, "class", "mgx mgy-a text-center fill");
                if (this.participants !== null)
                {
                    if ($.$$.S.DateTime.op_LessThan($.$$.S.DateTime.UtcNow.Date, this.date))
                    {
                        __builder.AddContent$4(50, "Event starting in ");
                        __builder.OpenElement(51, "span");
                        __builder.AddAttribute$5(52, "class", "nowrap");
                        __builder.AddContent$4(53, $.$fPer.LCFCDC.DateTimeExtension.DHMS(($.$$.S.DateTime.op_Subtraction$1(this.date, $.$$.S.DateTime.UtcNow)), 2147483647));
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.AddContent$4(54, "Event held on ");
                        __builder.AddContent$3(55, this.ToLocalTime(this.date));
                    }
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(56, "\r\n            ");
                __builder.OpenElement(57, "button");
                __builder.AddAttribute$5(58, "title", "Next day");
                __builder.AddAttribute$5(59, "class", "mdi mdi-chevron-double-right fsz-35 wx-05 hx-05 bd round bg-warning flex mgc-a sd");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 60, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Next)));
                __builder.CloseElement();
                __builder.CloseElement();
                if (this.payments !== null && $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.PaymentModel, this.payments))
                {
                    __builder.OpenElement(61, "h3");
                    __builder.AddContent$4(62, "Participants (");
                    __builder.AddContent$3(63, $.$box($.$sl.SL.Enumerable.Count$1($.$Iaui.LCFCM.PaymentModel, this.payments), $.$$.S.Int32));
                    __builder.AddContent$4(64, ")");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(65, "\r\n            ");
                    __builder.OpenElement(66, "div");
                    __builder.AddAttribute$5(67, "class", "flex flow");
                    let $en14 = this.payments.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let payment = $en14.SCG$IEnumerator$$$Current;
                        {
                            __builder.OpenElement(68, "div");
                            __builder.AddAttribute$5(69, "class", "mg-2 pd bd corner-5 bg-primary");
                            __builder.OpenElement(70, "span");
                            __builder.AddAttribute$5(71, "class", "nowrap");
                            __builder.AddContent$4(72, (payment.User?.Name ?? null));
                            __builder.AddMarkupContent(73, "\r\n                            ");
                            __builder.OpenElement(74, "i");
                            __builder.AddAttribute$5(75, "title", payment.Summary);
                            __builder.AddAttribute$5(76, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN((this.GetIcon(payment))) + " cl-warning") + " bg-card") + " round") + " pd-1") + " wx-02") + " hx-02") + " iflex") + " fsz-12") + " mgc-a");
                            __builder.CloseElement();
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                    __builder.CloseElement();
                }
                __builder.AddMarkupContent(77, "<h3>Gifts to be won</h3>\r\n        ");
                __builder.OpenElement(78, "div");
                __builder.AddAttribute$5(79, "class", "flex flow");
                __builder.OpenElement(80, "div");
                __builder.AddAttribute$5(81, "class", "wx-1 hx-1 stack text-center");
                __builder.AddMarkupContent(82, "<div class=\"wx-07 hx-07 bd round mgx-a bg-warning-01 flex mgb-2\"><i class=\"mdi mdi-phone cl-success fsz-40 mg-a\"></i></div>\r\n                ");
                __builder.OpenElement(83, "b");
                __builder.AddContent$4(84, $.$strNN("\u20A6"/*Money.NairaSymbol*/) + "100");
                __builder.AddContent$4(85, " airtime");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885542636)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590575340)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590575340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590575340)
            
            //--TRIMMABLE-BOUNDARY-START(8590575340)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590575340)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94489921260)
                this.overlayImage = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(94489921260)
                
                //--TRIMMABLE-BOUNDARY-START(128849659628)
                this.ThemeAccessor = null;
                //--TRIMMABLE-BOUNDARY-END(128849659628)
                
                //--TRIMMABLE-BOUNDARY-START(21475477228)
                this.date = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(21475477228)
                
            }
            static $h = 640748;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194953964),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950313708,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 640748,
      "h": 90194953964,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90194953964),
//--TRIMMABLE-BOUNDARY-START(128849659628),
    {
      "p": 4873640,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540248300,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964757740,
        "f": 83886081
      },
      "n": "ThemeAccessor",
      "d": 640748,
      "h": 128849659628,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849659628),
//--TRIMMABLE-BOUNDARY-START(68720117484),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360379116,
        "f": 50331650
      },
      "n": "HasAWinner",
      "d": 640748,
      "h": 68720117484,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68720117484),
//--TRIMMABLE-BOUNDARY-START(133144626924),
    {
      "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130182892,
        "f": 50331650
      },
      "n": "Winners",
      "d": 640748,
      "h": 133144626924,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133144626924)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015084780),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 640748,
      "h": 73015084780,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015084780),
//--TRIMMABLE-BOUNDARY-START(64425150188),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payment",
          "p": 12592470
        }
      ],
      "n": "GetIcon",
      "d": 640748,
      "h": 64425150188,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425150188),
//--TRIMMABLE-BOUNDARY-START(77310052076),
    {
      "r": 178454529,
      "p": [
        {
          "n": "date",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": "Load",
      "d": 640748,
      "h": 77310052076,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(77310052076),
//--TRIMMABLE-BOUNDARY-START(81605019372),
    {
      "r": 178454529,
      "n": "Next",
      "d": 640748,
      "h": 81605019372,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605019372),
//--TRIMMABLE-BOUNDARY-START(107374823148),
    {
      "r": 178454529,
      "n": "Previous",
      "d": 640748,
      "h": 107374823148,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374823148),
//--TRIMMABLE-BOUNDARY-START(85899986668),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 640748,
      "h": 85899986668,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(85899986668),
//--TRIMMABLE-BOUNDARY-START(25770444524),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 640748,
      "h": 25770444524,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770444524),
//--TRIMMABLE-BOUNDARY-START(12885542636),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 640748,
      "h": 12885542636,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885542636)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(120259725036),
    {
      "t": 46093994,
      "n": "spinWheel",
      "d": 640748,
      "h": 120259725036,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120259725036),
//--TRIMMABLE-BOUNDARY-START(94489921260),
    {
      "t": 1900659,
      "n": "overlayImage",
      "d": 640748,
      "h": 94489921260,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94489921260),
//--TRIMMABLE-BOUNDARY-START(98784888556),
    {
      "t": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCS$10.SpinWheelParticipant).$h,
      "n": "participants",
      "d": 640748,
      "h": 98784888556,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98784888556),
//--TRIMMABLE-BOUNDARY-START(103079855852),
    {
      "t": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel).$h,
      "n": "payments",
      "d": 640748,
      "h": 103079855852,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103079855852),
//--TRIMMABLE-BOUNDARY-START(124554692332),
    {
      "t": 9723304,
      "n": "theme",
      "d": 640748,
      "h": 124554692332,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124554692332),
//--TRIMMABLE-BOUNDARY-START(21475477228),
    {
      "t": 65994753,
      "n": "date",
      "d": 640748,
      "h": 21475477228,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475477228),
//--TRIMMABLE-BOUNDARY-START(17180509932),
    {
      "t": 170983425,
      "n": "cancelSpin",
      "d": 640748,
      "h": 17180509932,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180509932)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590575340),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 640748,
      "h": 8590575340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590575340)
  ],
  "h": 640748,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PayCowry/LoyaltyRewardSpinWheel",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Pages.LoyaltyRewardSpinWheel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Pages${separator}LoyaltyRewardSpinWheel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(640748)
        
        

        //--TRIMMABLE-BOUNDARY-START(2017004)
        $asm.$cls(`$HSAN.LCPCS$1.PayCowryWalletSend`, ($self) => class PayCowryWalletSend extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(68721493740)
            /*string */ get OptimizedComponentName()
            {
                return "paycowrywalletsend";
            }
            //--TRIMMABLE-BOUNDARY-END(68721493740)
            
            //--TRIMMABLE-BOUNDARY-START(103081232108)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081232108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "TransactionType":
                    this.TransactionType = $.$cast(parameter.Value, $.$$.S.Nullable$$($.$UlXD.LCPCM.PayCowryTransactionType));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(103081232108)
            
            //--TRIMMABLE-BOUNDARY-START(60131559148)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131559148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60131559148)
            
            //--TRIMMABLE-BOUNDARY-START(98786264812)
            /*PayCowryTransactionType?*/ TransactionType = null;
            //--TRIMMABLE-BOUNDARY-END(98786264812)
            
            //--TRIMMABLE-BOUNDARY-START(73016461036)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(73016461036)
            
            //--TRIMMABLE-BOUNDARY-START(94491297516)
            /*PayCowryTransactionType*/ transactionType = 0;
            //--TRIMMABLE-BOUNDARY-END(94491297516)
            
            //--TRIMMABLE-BOUNDARY-START(51541624556)
            /*void */ GoOffline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541624556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.transactionType = 0/*PayCowryTransactionType.Offline*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51541624556)
            
            //--TRIMMABLE-BOUNDARY-START(55836591852)
            /*void */ GoOnline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836591852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.transactionType = 1/*PayCowryTransactionType.Online*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55836591852)
            
            //--TRIMMABLE-BOUNDARY-START(64426526444)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426526444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.TransactionType !== null)
                    {
                        let $t2, $r2;
                        this.transactionType = $.$$.S.Nullable$$($.$UlXD.LCPCM.PayCowryTransactionType).Value$get.call(this.TransactionType);
                        ($t2 = this.Forward(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64426526444)
            
            //--TRIMMABLE-BOUNDARY-START(21476853484)
            /*ValueTask *//*async*/  Forward()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476853484);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = $.$hDPm.LCFCI.ViewPresenterExtensions.CancelAll($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    if (this.transactionType === 0/*PayCowryTransactionType.Offline*/ && this.Service.OfflinePaymentProvider === null)
                    {
                        let $t5, $r5;
                        ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$HSAN.LCPCS$1.Error, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                        {
                            builder.AddAttribute$5(1, "Message", "Offline Cowry sending is disabled");
                            builder.AddAttribute$5(2, "Details", "This can happen if you are using PayCorwy in a browser. Use the mobile app instead!");
                        }, $zVYRra ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":2017004,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*CancellationTokenSource*/ let cts = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    ($t6 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletSend, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ builder, /*i*/ i) =>
                    {
                        builder.AddAttribute$4(1, "Wallet", this.transactionType === 1/*PayCowryTransactionType.Online*/ ? this.Service.OnlineWalletProvider : this.Service.OfflinePaymentProvider);
                        builder.AddAttribute$4(2, "WalletSendProvider", this.transactionType === 1/*PayCowryTransactionType.Online*/ ? this.Service.OnlineWalletProvider : this.Service.OfflinePaymentProvider);
                        builder.AddAttribute$1(3, "OnFinished", $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t7, $r7;
                                cts.Cancel();
                                ($t7 = this.Service.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            });
                        }, $kPPZok ??= {"r":178454529,"n":"","d":2017004,"h":0,"f":17829890})));
                    }, $lEPURk ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":2017004,"h":0,"f":17825794}), cts.Token, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476853484)
            
            //--TRIMMABLE-BOUNDARY-START(17181886188)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181886188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd");
                __builder.AddMarkupContent(2, "<h1 class=\"text-center mgt-0\">Select the type of transaction</h1>\r\n    ");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "flex");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.GoOffline)));
                __builder.OpenElement(6, "i");
                __builder.AddAttribute$5(7, "class", $.$strNN($.$strNN("mdi" + " ") + $.$strNN((this.transactionType === 0/*PayCowryTransactionType.Offline*/ ? "mdi-checkbox-outline cl-primary" : "mdi-checkbox-blank-outline"))) + " fsz-30");
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n        ");
                __builder.AddMarkupContent(9, "<div class=\"mgl stack\"><h3 class=\"mg-0\">Offline</h3>\r\n            <p class=\"mg-0\">\r\n                Fund is taken from your Offline PayCowry tokens. No internet is required by both parties to transact.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n    ");
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "flex mgt");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 13, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.GoOnline)));
                __builder.OpenElement(14, "i");
                __builder.AddAttribute$5(15, "class", $.$strNN($.$strNN("mdi" + " ") + $.$strNN((this.transactionType === 1/*PayCowryTransactionType.Online*/ ? "mdi-checkbox-outline cl-primary" : "mdi-checkbox-blank-outline"))) + " fsz-30");
                __builder.CloseElement();
                __builder.AddMarkupContent(16, "\r\n        ");
                __builder.AddMarkupContent(17, "<div class=\"mgl stack\"><h3 class=\"mg-0\">Online</h3>\r\n            <p class=\"mg-0\">\r\n                Fund is taken from your Online Wallet. Requires internet connection on this end.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(18, "\r\n    ");
                __builder.OpenElement(19, "div");
                __builder.AddAttribute$5(20, "class", "flex mgt");
                __builder.AddMarkupContent(21, "<div class=\"fill\"></div>\r\n        ");
                __builder.OpenElement(22, "div");
                __builder.AddAttribute$5(23, "class", "flex");
                __builder.AddMarkupContent(24, "<span class=\"mgy-a bg-primary pdx pdy-2 corner-l-5 hx-03 mgr--2\">Continue</span>\r\n            ");
                __builder.OpenElement(25, "button");
                __builder.AddAttribute$5(26, "class", "mdi mdi-chevron-right fsz-25 bg-primary wx-05 hx-05 round");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 27, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forward)));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17181886188)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886918892)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886918892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886918892)
            
            //--TRIMMABLE-BOUNDARY-START(12886918892)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886918892)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98786264812)
                this.TransactionType = null;
                //--TRIMMABLE-BOUNDARY-END(98786264812)
                
                //--TRIMMABLE-BOUNDARY-START(73016461036)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(73016461036)
                
            }
            static $h = 2017004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721493740),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066788076,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2017004,
      "h": 68721493740,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68721493740),
//--TRIMMABLE-BOUNDARY-START(98786264812),
    {
      "p": $.$typeNullable($.$UlXD.LCPCM.PayCowryTransactionType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246657260,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196330220,
        "f": 83886081
      },
      "n": "TransactionType",
      "d": 2017004,
      "h": 98786264812,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98786264812),
//--TRIMMABLE-BOUNDARY-START(73016461036),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656722668,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606395628,
        "f": 83886081
      },
      "n": "Service",
      "d": 2017004,
      "h": 73016461036,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016461036)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103081232108),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2017004,
      "h": 103081232108,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103081232108),
//--TRIMMABLE-BOUNDARY-START(60131559148),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2017004,
      "h": 60131559148,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131559148),
//--TRIMMABLE-BOUNDARY-START(51541624556),
    {
      "r": 65537,
      "n": "GoOffline",
      "d": 2017004,
      "h": 51541624556,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541624556),
//--TRIMMABLE-BOUNDARY-START(55836591852),
    {
      "r": 65537,
      "n": "GoOnline",
      "d": 2017004,
      "h": 55836591852,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836591852),
//--TRIMMABLE-BOUNDARY-START(64426526444),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2017004,
      "h": 64426526444,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(64426526444),
//--TRIMMABLE-BOUNDARY-START(21476853484),
    {
      "r": 181338113,
      "n": "Forward",
      "d": 2017004,
      "h": 21476853484,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476853484),
//--TRIMMABLE-BOUNDARY-START(17181886188),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2017004,
      "h": 17181886188,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181886188)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94491297516),
    {
      "t": 2840211,
      "n": "transactionType",
      "d": 2017004,
      "h": 94491297516,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94491297516)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886918892),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2017004,
      "h": 12886918892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886918892)
  ],
  "h": 2017004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.PayCowryWalletSend`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}PayCowryWalletSend`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2017004)
        
        

        //--TRIMMABLE-BOUNDARY-START(706284)
        $asm.$cls(`$HSAN.LCPCP.PayCowryApp`, ($self) => class PayCowryApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(150324561644)
            /*PayCowryService*/ PayCowryService = null;
            //--TRIMMABLE-BOUNDARY-END(150324561644)
            
            //--TRIMMABLE-BOUNDARY-START(146029594348)
            /*PayCowryApplication*/ PayCowryApplication = null;
            //--TRIMMABLE-BOUNDARY-END(146029594348)
            
            //--TRIMMABLE-BOUNDARY-START(167504430828)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(167504430828)
            
            //--TRIMMABLE-BOUNDARY-START(128849725164)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(128849725164)
            
            //--TRIMMABLE-BOUNDARY-START(38655411948)
            /*IApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(38655411948)
            
            //--TRIMMABLE-BOUNDARY-START(115964823276)
            /*bool*/ loaded = false;
            //--TRIMMABLE-BOUNDARY-END(115964823276)
            
            //--TRIMMABLE-BOUNDARY-START(111669855980)
            /*bool*/ isonBoarded = false;
            //--TRIMMABLE-BOUNDARY-END(111669855980)
            
            //--TRIMMABLE-BOUNDARY-START(137439659756)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439659756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        let $t1, $r1;
                        if (this.PayCowryService.LocalDatabase !== null && !this.PayCowryService.LocalDatabase.LCPCS$ILocalDatabase$IsInitialized)
                        {
                            this.isonBoarded = true;
                        }
                        ($t1 = this.PayCowryService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (this.PayCowryService.User !== null)
                        {
                            if ($.$Iaui.LCFCM.DataPropertiesExtensions.HasFeatures($.$UlXD.LCPCM.PayCowryAccountFeatureModel, this.PayCowryService.User, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.GetFeatureKey(this.PayCowryService.User)))
                            {
                                this.isonBoarded = true;
                            }
                        }
                        this.loaded = true;
                    }
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137439659756)
            
            //--TRIMMABLE-BOUNDARY-START(120259790572)
            /*bool*/ loggedIn = false;
            //--TRIMMABLE-BOUNDARY-END(120259790572)
            
            //--TRIMMABLE-BOUNDARY-START(42950379244)
            /*EventHandler?*/ ApplicationRendered = null;
            //--TRIMMABLE-BOUNDARY-END(42950379244)
            
            //--TRIMMABLE-BOUNDARY-START(42950379244)
            //--TRIMMABLE-BOUNDARY-START(34360444652)
            add_ApplicationRendered(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360444652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Combine$2(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360444652)
            
            //--TRIMMABLE-BOUNDARY-START(163209463532)
            remove_ApplicationRendered(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209463532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Remove(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(163209463532)
            
            //--TRIMMABLE-BOUNDARY-END(42950379244)
            
            //--TRIMMABLE-BOUNDARY-START(51540313836)
            /*bool*/ eventSent = false;
            //--TRIMMABLE-BOUNDARY-END(51540313836)
            
            //--TRIMMABLE-BOUNDARY-START(133144692460)
            /*void */ OnAfterRender(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144692460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.eventSent && this.Application !== null)
                {
                    this.ApplicationRendered?.Invoke(this, $.$$.S.EventArgs.Empty);
                    this.eventSent = true;
                }
                super.OnAfterRender(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(133144692460)
            
            //--TRIMMABLE-BOUNDARY-START(124554757868)
            /*void */ LoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554757868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.loggedIn = true;
            }
            //--TRIMMABLE-BOUNDARY-END(124554757868)
            
            //--TRIMMABLE-BOUNDARY-START(154619528940)
            /*void */ Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619528940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Navigation.NavigateTo$2("PayCowry", true);
            }
            //--TRIMMABLE-BOUNDARY-END(154619528940)
            
            //--TRIMMABLE-BOUNDARY-START(141734627052)
            /*string */ get OptimizedComponentName()
            {
                return "paycowryapp";
            }
            //--TRIMMABLE-BOUNDARY-END(141734627052)
            
            //--TRIMMABLE-BOUNDARY-START(107374888684)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374888684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.PayCowryService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
                this.PayCowryApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryApplication, serviceProvider);
                this.Rendering = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIRenderingProvider, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(107374888684)
            
            //--TRIMMABLE-BOUNDARY-START(47245346540)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245346540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.loaded)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "hv-10 stack");
                    __builder.OpenElement(2, "div");
                    __builder.AddAttribute$5(3, "class", "mg-a pd-10 bg-card corner stack");
                    __builder.OpenElement(4, "img");
                    __builder.AddAttribute$5(5, "src", this.ResolvePath("cowry.png", true, false, false));
                    __builder.AddAttribute$5(6, "class", "mgx-a d-block wx-1 mgb");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(7, "\r\n            ");
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 8);
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                else if (!this.isonBoarded)
                {
                    __builder.OpenComponent$1($.$HSAN.LCPCS$1.Onboarding, 9);
                    __builder.AddComponentParameter(10, "Onboarded", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this, this.Reload))));
                    __builder.CloseComponent();
                }
                else 
                {
                    if (!this.loggedIn && this.PayCowryService.LocalDatabase !== null)
                    {
                        __builder.OpenComponent$1($.$HSAN.LCPCS$1.PinLogin, 11);
                        __builder.AddComponentParameter(12, "OnLoggedIn", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this, this.LoggedIn))));
                        __builder.CloseComponent();
                    }
                    else 
                    {
                        __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 13);
                        __builder.AddComponentParameter(14, "Name", "PayCowry");
                        __builder.AddComponentParameter(15, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("PayCowry")));
                        __builder.AddComponentParameter(16, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.PayCowryService));
                        __builder.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                        __builder.AddComponentParameter(18, "tabshead-class", "bg-card bdt");
                        __builder.AddComponentParameter(19, "Style", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `background:${$.$strNN($.$fPer.LCFC.Theme.Gradient$1(0/*ThemeGradientType.Linear*/, "#00678020", "#00878020", 180, 100))}`));
                        __builder.AddAttribute$3(20, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                            {
                                __builder2.AddContent$4(21, "PayCowry");
                            }, $DiaIYe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                        }), $gaNbQj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                        __builder.AddAttribute$3(22, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                            {
                                __builder2.AddMarkupContent(23, "<img class=\"mawf mahf\" src=\"_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png\">");
                            }, $ugzbRf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                        }), $GXjRoi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                        __builder.AddAttribute$3(24, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 25);
                            __builder2.AddComponentParameter(26, "Name", "PayCowry");
                            __builder2.AddComponentParameter(27, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                            __builder2.AddComponentParameter(28, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder2.AddComponentParameter(29, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 4/*ApplicationPageAccessibility.Tab*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                            __builder2.AddComponentParameter(30, "Class", "pdb-15");
                            __builder2.AddAttribute$3(31, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                {
                                    __builder3.OpenElement(32, "span");
                                    __builder3.AddAttribute$5(33, "class", i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $bOjVoa ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "cl-primary" : "");
                                    __builder3.AddContent$4(34, "PayCowry");
                                    __builder3.CloseElement();
                                }, $qxerlj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $PrrnMj ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(35, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(36, "i");
                                    __builder3.AddAttribute$5(37, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-home") + " fsz-20") + " wx-03") + " hx-03") + " flex") + " mgc-a") + " ") + $.$strNN((i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $aVuqQb ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "bg-primary round" : "")));
                                    __builder3.CloseElement();
                                }, $WTqjta ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $EdJmYi ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(38, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$HSAN.LCPCS$1.Home, 39);
                                    __builder3.CloseComponent();
                                }, $NiIovc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $SuQNaj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(40, "\r\n                ");
                            __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 41);
                            __builder2.AddComponentParameter(42, "Name", "Wallet");
                            __builder2.AddComponentParameter(43, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Wallet")));
                            __builder2.AddComponentParameter(44, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder2.AddComponentParameter(45, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 4/*ApplicationPageAccessibility.Tab*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                            __builder2.AddComponentParameter(46, "Class", "pdb-15");
                            __builder2.AddAttribute$3(47, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(48, "span");
                                    __builder3.AddAttribute$5(49, "class", i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $biDZVd ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "cl-primary" : "");
                                    __builder3.AddContent$4(50, "Wallet");
                                    __builder3.CloseElement();
                                }, $pgVCQd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $XKZZkf ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(51, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(52, "i");
                                    __builder3.AddAttribute$5(53, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-wallet") + " fsz-20") + " wx-03") + " hx-03") + " flex") + " mgc-a") + " ") + $.$strNN((i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $FcPWwi ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "bg-primary round" : "")));
                                    __builder3.CloseElement();
                                }, $oGHhsa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $FOBlsg ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(54, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$HSAN.LCPCS$1.Wallet, 55);
                                    __builder3.CloseComponent();
                                }, $HwXKeg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $eGaDih ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(56, "\r\n                ");
                            __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 57);
                            __builder2.AddComponentParameter(58, "Name", "Swap");
                            __builder2.AddComponentParameter(59, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Swap")));
                            __builder2.AddComponentParameter(60, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder2.AddComponentParameter(61, "Class", "pdb-15");
                            __builder2.AddAttribute$3(62, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(63, "span");
                                    __builder3.AddAttribute$5(64, "class", i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $FhiKJg ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "cl-primary" : "");
                                    __builder3.AddContent$4(65, "Swap");
                                    __builder3.CloseElement();
                                }, $tAlDtd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $ycjmJh ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(66, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(67, "i");
                                    __builder3.AddAttribute$5(68, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-swap-horizontual") + " fsz-20") + " wx-03") + " hx-03") + " flex") + " mgc-a") + " ") + $.$strNN((i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $AvRgcf ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "bg-primary round" : "")));
                                    __builder3.CloseElement();
                                }, $TmhCjc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $bxxhGf ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(69, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$HSAN.LCPCS$1.Swap, 70);
                                    __builder3.CloseComponent();
                                }, $euVvMd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $qiulrk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(71, "\r\n                ");
                            __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 72);
                            __builder2.AddComponentParameter(73, "Name", "Profile");
                            __builder2.AddComponentParameter(74, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Profile")));
                            __builder2.AddComponentParameter(75, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder2.AddComponentParameter(76, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 4/*ApplicationPageAccessibility.Tab*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                            __builder2.AddAttribute$3(77, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                {
                                    __builder3.OpenElement(78, "span");
                                    __builder3.AddAttribute$5(79, "class", i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $jBeNlk ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "cl-primary" : "");
                                    __builder3.AddContent$4(80, "Profile");
                                    __builder3.CloseElement();
                                }, $VOOLXh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $vXQqnd ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(81, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*i*/ i) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(82, "i");
                                    __builder3.AddAttribute$5(83, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-account") + " fsz-20") + " wx-03") + " hx-03") + " flex") + " mgc-a") + " ") + $.$strNN((i.HasAttribute($.$$.S.Boolean, new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                                    {
                                        return b === true;
                                    }, $ZQyQgb ??= {"r":262145,"p":[{"n":"b","p":262145}],"n":"","d":706284,"h":0,"f":17825794})) ? "bg-primary round" : "")));
                                    __builder3.CloseElement();
                                }, $BzDWFf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $BGqVkh ??= {"r":6881395,"p":[{"n":"i","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(84, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$HSAN.LCPCS$1.Profile, 85);
                                    __builder3.CloseComponent();
                                }, $ebMnta ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706284,"h":0,"f":17825794});
                            }), $ghgBlj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706284,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }), $TeHbtk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":706284,"h":0,"f":17825794}));
                        __builder.AddComponentReferenceCapture(86, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/**/ __value) =>
                        {
                            this.Application = $.$cast(__value, $.$lJUR.LCFCS.Application);
                        }, $zveDNd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":706284,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245346540)
            
            //--TRIMMABLE-BOUNDARY-START(25774862409)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.Application.get
            get LCFCS$IApplicationShell$Application()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889960521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Application;
            }
            //--TRIMMABLE-BOUNDARY-END(25774862409)
            
            //--TRIMMABLE-BOUNDARY-START(8594993225)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered.add
            LCFCS$IApplicationShell$add_ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594993225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_ApplicationRendered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8594993225)
            
            //--TRIMMABLE-BOUNDARY-START(34364797001)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered.remove
            LCFCS$IApplicationShell$remove_ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364797001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_ApplicationRendered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34364797001)
            
            //--TRIMMABLE-BOUNDARY-START(17184927817)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered
            LivingThing$Core$Frameworks$Client$SPA$IApplicationShell$ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184927817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered;
            }
            //--TRIMMABLE-BOUNDARY-END(17184927817)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25770510060)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770510060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770510060)
            
            //--TRIMMABLE-BOUNDARY-START(25770510060)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770510060)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(150324561644)
                this.PayCowryService = null;
                //--TRIMMABLE-BOUNDARY-END(150324561644)
                
                //--TRIMMABLE-BOUNDARY-START(146029594348)
                this.PayCowryApplication = null;
                //--TRIMMABLE-BOUNDARY-END(146029594348)
                
                //--TRIMMABLE-BOUNDARY-START(167504430828)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(167504430828)
                
                //--TRIMMABLE-BOUNDARY-START(128849725164)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(128849725164)
                
                //--TRIMMABLE-BOUNDARY-START(38655411948)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(38655411948)
                
            }
            static $h = 706284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150324561644),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489986796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864169196,
        "f": 83886081
      },
      "n": "PayCowryService",
      "d": 706284,
      "h": 150324561644,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324561644),
//--TRIMMABLE-BOUNDARY-START(146029594348),
    {
      "p": 968428,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900052204,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274234604,
        "f": 83886081
      },
      "n": "PayCowryApplication",
      "d": 706284,
      "h": 146029594348,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029594348),
//--TRIMMABLE-BOUNDARY-START(167504430828),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079921388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454103788,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 706284,
      "h": 167504430828,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504430828),
//--TRIMMABLE-BOUNDARY-START(128849725164),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720183020,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684300012,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 706284,
      "h": 128849725164,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849725164),
//--TRIMMABLE-BOUNDARY-START(38655411948),
    {
      "p": 4337737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130248428,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094365420,
        "f": 83886081
      },
      "n": "Application",
      "d": 706284,
      "h": 38655411948,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655411948),
//--TRIMMABLE-BOUNDARY-START(141734627052),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310117612,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 706284,
      "h": 141734627052,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734627052)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439659756),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 706284,
      "h": 137439659756,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(137439659756),
//--TRIMMABLE-BOUNDARY-START(133144692460),
    {
      "r": 65537,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRender",
      "d": 706284,
      "h": 133144692460,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(133144692460),
//--TRIMMABLE-BOUNDARY-START(124554757868),
    {
      "r": 65537,
      "n": "LoggedIn",
      "d": 706284,
      "h": 124554757868,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554757868),
//--TRIMMABLE-BOUNDARY-START(154619528940),
    {
      "r": 65537,
      "n": "Reload",
      "d": 706284,
      "h": 154619528940,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154619528940),
//--TRIMMABLE-BOUNDARY-START(107374888684),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 706284,
      "h": 107374888684,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374888684),
//--TRIMMABLE-BOUNDARY-START(47245346540),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 706284,
      "h": 47245346540,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245346540)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115964823276),
    {
      "t": 262145,
      "n": "loaded",
      "d": 706284,
      "h": 115964823276,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115964823276),
//--TRIMMABLE-BOUNDARY-START(111669855980),
    {
      "t": 262145,
      "n": "isonBoarded",
      "d": 706284,
      "h": 111669855980,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(111669855980),
//--TRIMMABLE-BOUNDARY-START(120259790572),
    {
      "t": 262145,
      "n": "loggedIn",
      "d": 706284,
      "h": 120259790572,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120259790572),
//--TRIMMABLE-BOUNDARY-START(51540313836),
    {
      "t": 262145,
      "n": "eventSent",
      "d": 706284,
      "h": 51540313836,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540313836)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770510060),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 706284,
      "h": 25770510060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770510060)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(42950379244),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_ApplicationRendered",
        "d": 706284,
        "h": 34360444652,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_ApplicationRendered",
        "d": 706284,
        "h": 163209463532,
        "f": 285212673
      },
      "n": "ApplicationRendered",
      "d": 706284,
      "h": 42950379244,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(42950379244)
  ],
  "h": 706284,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PayCowry/{*Path}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationShell, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Pages.PayCowryApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Pages${separator}PayCowryApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(706284)
        
        

        //--TRIMMABLE-BOUNDARY-START(2148076)
        $asm.$cls(`$HSAN.LCPCS$1.Profile`, ($self) => class Profile extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(128851166956)
            /*string */ get OptimizedComponentName()
            {
                return "profile";
            }
            //--TRIMMABLE-BOUNDARY-END(128851166956)
            
            //--TRIMMABLE-BOUNDARY-START(98786395884)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786395884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Services = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(98786395884)
            
            //--TRIMMABLE-BOUNDARY-START(120261232364)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(120261232364)
            
            //--TRIMMABLE-BOUNDARY-START(146031036140)
            /*PayCowryService*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(146031036140)
            
            //--TRIMMABLE-BOUNDARY-START(111671297772)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(111671297772)
            
            //--TRIMMABLE-BOUNDARY-START(107376330476)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(107376330476)
            
            //--TRIMMABLE-BOUNDARY-START(184685741804)
            /*IEnumerable<SettingsHierachyLevel?>?*/ settingsHierachy = null;
            //--TRIMMABLE-BOUNDARY-END(184685741804)
            
            //--TRIMMABLE-BOUNDARY-START(133146134252)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(133146134252)
            
            //--TRIMMABLE-BOUNDARY-START(133146134252)
            //--TRIMMABLE-BOUNDARY-START(30066919148)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066919148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066919148)
            
            //--TRIMMABLE-BOUNDARY-START(141736068844)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736068844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(141736068844)
            
            //--TRIMMABLE-BOUNDARY-END(133146134252)
            
            //--TRIMMABLE-BOUNDARY-START(34361886444)
            /*Task *//*async*/  Backup()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361886444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t2, $r2;
                            return ($t2 = this.Services.LocalDatabase.LCPCS$ILocalDatabase$BackupToServer(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        });
                    }, $OdpNAe ??= {"r":181338113,"n":"","d":2148076,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $KvwJai ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":2148076,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361886444)
            
            //--TRIMMABLE-BOUNDARY-START(38656853740)
            /*IEnumerable<string>?*/ backups = null;
            //--TRIMMABLE-BOUNDARY-END(38656853740)
            
            //--TRIMMABLE-BOUNDARY-START(51541755628)
            /*void */ BuildSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541755628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.settingsHierachy = $.$sl.SL.Enumerable.Where($.$hDPm.LCFCCS$4.SettingsHierachyLevel, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCS$4.SettingsHierachyLevel), [this.Services.LocalDatabase !== null && this.Services.OfflinePaymentProvider !== null ? (() =>
                {
                    //new $.$hDPm.LCFCCS$4.SettingsHierachyLevel()
                    const $t3 = $.$hDPm.LCFCCS$4.SettingsHierachyLevel;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Icon = "mdi mdi-cloud"/*MaterialDesignIconNames.Cloud*/;
                    $i3.Name = "Wallet Backup";
                    $i3.Description = new ($.$$.S.Func$$($.$$.S.Object))().$ctor(this,  () =>
                    {
                        return this.BackupView();
                    }, $Bzttqb ??= {"r":131073,"n":"","d":2148076,"h":0,"f":17825794});
                    $i3.Handler = $.$fPer.LCFCO.OneOf$$$$($.$$.SCG.IEnumerable$$($.$hDPm.LCFCCS$4.SettingsHierachyLevel), $.$$.S.String, $.$$.S.Func$$($.$$.STT.Task)).FromT0(new ($.$fPer.LCFC.LiveEnumerable$$($.$hDPm.LCFCCS$4.SettingsHierachyLevel))().$ctor$1(new ($.$$.S.Func$$($.$$.SCG.IEnumerable$$($.$hDPm.LCFCCS$4.SettingsHierachyLevel)))().$ctor(this,  () =>
                    {
                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                        return ((__ca1__ = this.backups) !== null ? ($.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$hDPm.LCFCCS$4.SettingsHierachyLevel, __ca1__, new ($.$$.S.Func$$$($.$$.S.String, $.$hDPm.LCFCCS$4.SettingsHierachyLevel))().$ctor(this,  (/*b*/ b) =>
                        {
                            return (() =>
                            {
                                //new $.$hDPm.LCFCCS$4.SettingsHierachyLevel()
                                const $t4 = $.$hDPm.LCFCCS$4.SettingsHierachyLevel;
                                const $i4 = new $t4();
                                $i4.$ctor$1();
                                $i4.Name = b;
                                return $i4;
                            })();
                        }, $RAkSMi ??= {"r":44652202,"p":[{"n":"b","p":1310721}],"n":"","d":2148076,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$hDPm.LCFCCS$4.SettingsHierachyLevel)) : $.$sl.SL.Enumerable.Empty($.$hDPm.LCFCCS$4.SettingsHierachyLevel));
                    }, $klBODh ??= {"r":$.$$.SCG.IEnumerable$$($.$hDPm.LCFCCS$4.SettingsHierachyLevel).$h,"n":"","d":2148076,"h":0,"f":17825794})));
                    return $i3;
                })() : null], [-1], null), new ($.$$.S.Func$$$($.$hDPm.LCFCCS$4.SettingsHierachyLevel, $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                {
                    return t !== null;
                }, $fnpYob ??= {"r":262145,"p":[{"n":"t","p":44652202}],"n":"","d":2148076,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(51541755628)
            
            //--TRIMMABLE-BOUNDARY-START(124556199660)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556199660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.BuildSettings();
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(124556199660)
            
            //--TRIMMABLE-BOUNDARY-START(115966265068)
            /*Task *//*async*/  Logout()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115966265068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t5 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$LogOut(null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.Navigation.NavigateTo$2("PayCowry", true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115966265068)
            
            //--TRIMMABLE-BOUNDARY-START(103081363180)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081363180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(103081363180)
            
            //--TRIMMABLE-BOUNDARY-START(47246788332)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246788332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hv-10 scroll pos-rel pdb-20");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "cl-white pd-10");
                __builder.AddAttribute$5(4, "style", "background: linear-gradient(130deg, rgb(var(--primary-background-color)), rgb(var(--success-background-color)));");
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "flex");
                __builder.AddMarkupContent(7, "<div><div class=\"flex hx-06 wx-06 round bg-card-08\"><i class=\"fsz-45 mg-a cl-success mdi mdi-account\"></i></div></div>\r\n            ");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "mgy-a mgl stack");
                __builder.OpenElement(10, "h3");
                __builder.AddAttribute$5(11, "class", "mg-0");
                __builder.AddContent$4(12, (this.Services.OfflineAccount?.Name ?? null) ?? (this.Services.User?.Name ?? null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n    ");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$5(15, "class", "pd pos-rel");
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 16);
                __builder.AddComponentParameter(17, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(18, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(19, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(20, "<h2 class=\"mg-0\">Settings</h2>\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCS$4.SettingsHierachy, 21);
                    __builder2.AddComponentParameter(22, "Settings", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$hDPm.LCFCCS$4.SettingsHierachyLevel), this.settingsHierachy));
                    __builder2.AddComponentParameter(23, "Class", "mgt");
                    __builder2.AddComponentParameter(24, "list-li-class", "mgb-5");
                    __builder2.CloseComponent();
                }), $FhwSma ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2148076,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(47246788332)
            
            //--TRIMMABLE-BOUNDARY-START(42951821036)
            /*RenderFragment */ BackupView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951821036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(25, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteServiceCall$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$$.SCG.IEnumerable$$($.$$.S.String)), 26);
                    __builder2.AddComponentParameter(27, "IServiceMethod", new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$$.S.String))))().$ctor(this, (/*async*/  (/**/ s) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$$.S.String))), $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$$.S.String)), async ($asnycContext) => 
                        {
                            let $t6, $r6;
                            return ($t6 = s.LCPCS$IPayCowryRemoteService$GetBackups(this.Services.OfflineAccount.NetworkAddress.Address), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        });
                    }), $pUzcQa ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$$.S.String))).$h,"p":[{"n":"s","p":3561107}],"n":"","d":2148076,"h":0,"f":17829890}));
                    __builder2.AddAttribute$3(28, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$$.S.String))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(29, "div");
                            __builder3.AddAttribute$5(30, "class", "stack");
                            __builder3.AddMarkupContent(31, "<span>Backup your Offline PayCowry wallet regularly to cloud to avoid complete loss of your fund if you loose your device.</span>");
                            if (context.Data !== null)
                            {
                                let $en7 = context.Data.SCG$IEnumerable$$$GetEnumerator();
                                while ($en7.SC$1$IEnumerator$MoveNext())
                                {
                                    let back = $en7.SCG$IEnumerator$$$Current;
                                    {
                                        __builder3.OpenElement(32, "div");
                                        __builder3.AddContent$4(33, back);
                                        __builder3.CloseElement();
                                    }
                                }
                            }
                            __builder3.CloseElement();
                        }, $QZNsjj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2148076,"h":0,"f":17825794});
                    }), $LYnAff ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$$.S.String)).$h}],"n":"","d":2148076,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(34, "\r\n        ");
                    __builder2.OpenElement(35, "button");
                    __builder2.AddAttribute$5(36, "class", "cl-primary bg-transparent pd-0 text-left");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 37, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Backup)));
                    __builder2.AddContent$4(38, "Create Backup");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(39, "\r\n    ");
                }, $eYdEVk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2148076,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(42951821036)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(21476984556)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476984556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476984556)
            
            //--TRIMMABLE-BOUNDARY-START(21476984556)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476984556)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(120261232364)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(120261232364)
                
                //--TRIMMABLE-BOUNDARY-START(146031036140)
                this.Services = null;
                //--TRIMMABLE-BOUNDARY-END(146031036140)
                
                //--TRIMMABLE-BOUNDARY-START(111671297772)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(111671297772)
                
            }
            static $h = 2148076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128851166956),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901493996,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2148076,
      "h": 128851166956,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128851166956),
//--TRIMMABLE-BOUNDARY-START(120261232364),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311559404,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800839916,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 2148076,
      "h": 120261232364,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261232364),
//--TRIMMABLE-BOUNDARY-START(146031036140),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491428588,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390774508,
        "f": 83886081
      },
      "n": "Services",
      "d": 2148076,
      "h": 146031036140,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146031036140),
//--TRIMMABLE-BOUNDARY-START(111671297772),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721624812,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210905324,
        "f": 83886081
      },
      "n": "Loading",
      "d": 2148076,
      "h": 111671297772,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671297772),
//--TRIMMABLE-BOUNDARY-START(107376330476),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131690220,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620970732,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 2148076,
      "h": 107376330476,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376330476)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98786395884),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2148076,
      "h": 98786395884,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98786395884),
//--TRIMMABLE-BOUNDARY-START(34361886444),
    {
      "r": 178454529,
      "n": "Backup",
      "d": 2148076,
      "h": 34361886444,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34361886444),
//--TRIMMABLE-BOUNDARY-START(51541755628),
    {
      "r": 65537,
      "n": "BuildSettings",
      "d": 2148076,
      "h": 51541755628,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541755628),
//--TRIMMABLE-BOUNDARY-START(124556199660),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 2148076,
      "h": 124556199660,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(124556199660),
//--TRIMMABLE-BOUNDARY-START(115966265068),
    {
      "r": 178454529,
      "n": "Logout",
      "d": 2148076,
      "h": 115966265068,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(115966265068),
//--TRIMMABLE-BOUNDARY-START(103081363180),
    {
      "r": 181338113,
      "n": "Load",
      "d": 2148076,
      "h": 103081363180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103081363180),
//--TRIMMABLE-BOUNDARY-START(47246788332),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2148076,
      "h": 47246788332,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246788332),
//--TRIMMABLE-BOUNDARY-START(42951821036),
    {
      "r": 6881395,
      "n": "BackupView",
      "d": 2148076,
      "h": 42951821036,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951821036)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(184685741804),
    {
      "t": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCS$4.SettingsHierachyLevel).$h,
      "n": "settingsHierachy",
      "d": 2148076,
      "h": 184685741804,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(184685741804),
//--TRIMMABLE-BOUNDARY-START(38656853740),
    {
      "t": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "n": "backups",
      "d": 2148076,
      "h": 38656853740,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656853740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476984556),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2148076,
      "h": 21476984556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476984556)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(133146134252),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2148076,
        "h": 30066919148,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2148076,
        "h": 141736068844,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2148076,
      "h": 133146134252,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(133146134252)
  ],
  "h": 2148076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Profile`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Profile`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2148076)
        
        

        //--TRIMMABLE-BOUNDARY-START(1754860)
        $asm.$cls(`$HSAN.LCPCS$1.Login`, ($self) => class Login extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(111670904556)
            /*string */ get OptimizedComponentName()
            {
                return "login";
            }
            //--TRIMMABLE-BOUNDARY-END(111670904556)
            
            //--TRIMMABLE-BOUNDARY-START(171800446700)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800446700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "OnLogin":
                    this.OnLogin = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(171800446700)
            
            //--TRIMMABLE-BOUNDARY-START(90196068076)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196068076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90196068076)
            
            //--TRIMMABLE-BOUNDARY-START(133145741036)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(133145741036)
            
            //--TRIMMABLE-BOUNDARY-START(107375937260)
            /*EventCallback<CommunityPayCowryRegisterResponseModel>*/ OnLogin;
            //--TRIMMABLE-BOUNDARY-END(107375937260)
            
            //--TRIMMABLE-BOUNDARY-START(103080969964)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(103080969964)
            
            //--TRIMMABLE-BOUNDARY-START(98786002668)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(98786002668)
            
            //--TRIMMABLE-BOUNDARY-START(38656460524)
            /*string?*/ email = null;
            //--TRIMMABLE-BOUNDARY-END(38656460524)
            
            //--TRIMMABLE-BOUNDARY-START(115965871852)
            /*string?*/ password = null;
            //--TRIMMABLE-BOUNDARY-END(115965871852)
            
            //--TRIMMABLE-BOUNDARY-START(120260839148)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(120260839148)
            
            //--TRIMMABLE-BOUNDARY-START(120260839148)
            //--TRIMMABLE-BOUNDARY-START(30066525932)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066525932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066525932)
            
            //--TRIMMABLE-BOUNDARY-START(128850773740)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850773740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(128850773740)
            
            //--TRIMMABLE-BOUNDARY-END(120260839148)
            
            //--TRIMMABLE-BOUNDARY-START(42951427820)
            /*Task *//*async*/  Finish()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951427820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t3, $r3;
                            let $t4, $r4;
                            /*var*/ let result = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)))().$ctor(this,  (/*s*/ s) =>
                            {
                                return s.LCPCS$IPayCowryAccountRemoteService$Login(this.email, $.$firstOf(this.password, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Password required") }));
                            }, $oaEWNc ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)).$h,"p":[{"n":"s","p":3430035}],"n":"","d":1754860,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            ($t4 = this.OnLogin.InvokeAsync$1($.$clone(result)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        });
                    }, $noSijb ??= {"r":181338113,"n":"","d":1754860,"h":0,"f":17829890}), true, null, null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42951427820)
            
            //--TRIMMABLE-BOUNDARY-START(94491035372)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491035372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(94491035372)
            
            //--TRIMMABLE-BOUNDARY-START(34361493228)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361493228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, (336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/) & ~32/*LoadingFeatures.Retry*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 4);
                    __builder2.AddComponentParameter(5, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                    __builder2.AddComponentParameter(6, "class", "hf stack pd scroll-y");
                    __builder2.AddComponentParameter(7, "OnValidSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macf.MACF.EditContext), $.$mac.MAC.EventCallback.Factory.Create$9($.$macf.MACF.EditContext, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Finish))));
                    __builder2.AddAttribute$3(8, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*_*/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(9, "<h1 class=\"text-center fsz-40 mgb-0\">Welcome to</h1>\r\n        ");
                            __builder3.AddMarkupContent(10, "<h1 class=\"text-center fsz-40 mg-0\">PayCowry</h1>\r\n        <img class=\"hx-2 mgy mgx-a d-block\" src=\"_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png\">\r\n\r\n        ");
                            __builder3.AddMarkupContent(11, "<p class=\"text-center\">Please enter your credentials to continue</p>\r\n\r\n        ");
                            $.$HSAN._LCPCSL.TypeInference.CreateInputEditor_0($.$$.S.String, __builder3, 12, 13, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 mgt corner-5", 14, "Username or Email", 15, this.email, 16, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return this.email = __value;
                            }, $mLpyld ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1754860,"h":0,"f":17825794}), this.email)), 17, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "email"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $PhPswk ??= {"r":38797349,"n":"","d":1754860,"h":0,"f":17825794})).Invoke()));
                            __builder3.AddMarkupContent(18, "\r\n        <div class=\"mgt\"></div>\r\n        ");
                            $.$HSAN._LCPCSL.TypeInference.CreateInputEditor_1($.$$.S.String, __builder3, 19, 20, 13n, 21, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 corner-5", 22, "Password", 23, this.password, 24, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return this.password = __value;
                            }, $YUpDEc ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1754860,"h":0,"f":17825794}), this.password)), 25, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "password"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $DULVLd ??= {"r":38797349,"n":"","d":1754860,"h":0,"f":17825794})).Invoke()));
                            __builder3.AddMarkupContent(26, "\r\n        <div class=\"mgt-5\"></div>\r\n        ");
                            __builder3.OpenElement(27, "button");
                            __builder3.AddAttribute$5(28, "class", "bg-primary corner-5 pd mgt-a fsz-18");
                            __builder3.AddAttribute$5(29, "type", "submit");
                            __builder3.AddAttribute$2(30, "disabled", $.$$.S.String.IsNullOrEmpty(this.email) || $.$$.S.String.IsNullOrEmpty(this.password));
                            __builder3.AddContent$4(31, "Continue");
                            __builder3.CloseElement();
                        }, $lEOvjc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1754860,"h":0,"f":17825794});
                    }), $QfNIdh ??= {"r":6881395,"p":[{"n":"_","p":131188}],"n":"","d":1754860,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $kKwwzk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1754860,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(34361493228)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(21476591340)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476591340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476591340)
            
            //--TRIMMABLE-BOUNDARY-START(21476591340)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476591340)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133145741036)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(133145741036)
                
                //--TRIMMABLE-BOUNDARY-START(107375937260)
                this.OnLogin = $.$default($.$mac.MAC.EventCallback$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel));
                //--TRIMMABLE-BOUNDARY-END(107375937260)
                
                //--TRIMMABLE-BOUNDARY-START(103080969964)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(103080969964)
                
            }
            static $h = 1754860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670904556),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311166188,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1754860,
      "h": 111670904556,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111670904556),
//--TRIMMABLE-BOUNDARY-START(133145741036),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901100780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505479404,
        "f": 83886081
      },
      "n": "Service",
      "d": 1754860,
      "h": 133145741036,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145741036),
//--TRIMMABLE-BOUNDARY-START(107375937260),
    {
      "p": $.$mac.MAC.EventCallback$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721231596,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915544812,
        "f": 83886081
      },
      "n": "OnLogin",
      "d": 1754860,
      "h": 107375937260,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375937260),
//--TRIMMABLE-BOUNDARY-START(103080969964),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131297004,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325610220,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1754860,
      "h": 103080969964,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080969964),
//--TRIMMABLE-BOUNDARY-START(98786002668),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541362412,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735675628,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1754860,
      "h": 98786002668,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786002668)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171800446700),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1754860,
      "h": 171800446700,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171800446700),
//--TRIMMABLE-BOUNDARY-START(90196068076),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1754860,
      "h": 90196068076,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196068076),
//--TRIMMABLE-BOUNDARY-START(42951427820),
    {
      "r": 178454529,
      "n": "Finish",
      "d": 1754860,
      "h": 42951427820,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42951427820),
//--TRIMMABLE-BOUNDARY-START(94491035372),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1754860,
      "h": 94491035372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94491035372),
//--TRIMMABLE-BOUNDARY-START(34361493228),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1754860,
      "h": 34361493228,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361493228)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656460524),
    {
      "t": 1310721,
      "n": "email",
      "d": 1754860,
      "h": 38656460524,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656460524),
//--TRIMMABLE-BOUNDARY-START(115965871852),
    {
      "t": 1310721,
      "n": "password",
      "d": 1754860,
      "h": 115965871852,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115965871852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476591340),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1754860,
      "h": 21476591340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476591340)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(120260839148),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1754860,
        "h": 30066525932,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1754860,
        "h": 128850773740,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1754860,
      "h": 120260839148,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(120260839148)
  ],
  "h": 1754860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Login`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Login`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1754860)
        
        

        //--TRIMMABLE-BOUNDARY-START(1820396)
        $asm.$cls(`$HSAN.LCPCS$1.Onboarding`, ($self) => class Onboarding extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(188980381420)
            /*string */ get OptimizedComponentName()
            {
                return "onboarding";
            }
            //--TRIMMABLE-BOUNDARY-END(188980381420)
            
            //--TRIMMABLE-BOUNDARY-START(287764629228)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764629228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Onboarded":
                    this.Onboarded = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(287764629228)
            
            //--TRIMMABLE-BOUNDARY-START(158915610348)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915610348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(158915610348)
            
            //--TRIMMABLE-BOUNDARY-START(236225021676)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(236225021676)
            
            //--TRIMMABLE-BOUNDARY-START(184685414124)
            /*EventCallback*/ Onboarded;
            //--TRIMMABLE-BOUNDARY-END(184685414124)
            
            //--TRIMMABLE-BOUNDARY-START(180390446828)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(180390446828)
            
            //--TRIMMABLE-BOUNDARY-START(176095479532)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(176095479532)
            
            //--TRIMMABLE-BOUNDARY-START(163210577644)
            /*bool*/ isLoginIn = true;
            //--TRIMMABLE-BOUNDARY-END(163210577644)
            
            //--TRIMMABLE-BOUNDARY-START(279174694636)
            /*void */ ToggleLogin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174694636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.isLoginIn = !this.isLoginIn;
            }
            //--TRIMMABLE-BOUNDARY-END(279174694636)
            
            //--TRIMMABLE-BOUNDARY-START(274879727340)
            /*int*/ step = 0;
            //--TRIMMABLE-BOUNDARY-END(274879727340)
            
            //--TRIMMABLE-BOUNDARY-START(154620643052)
            /*string?*/ identity = null;
            //--TRIMMABLE-BOUNDARY-END(154620643052)
            
            //--TRIMMABLE-BOUNDARY-START(68721297132)
            /*string?*/ firstName = null;
            //--TRIMMABLE-BOUNDARY-END(68721297132)
            
            //--TRIMMABLE-BOUNDARY-START(167505544940)
            /*string?*/ lastName = null;
            //--TRIMMABLE-BOUNDARY-END(167505544940)
            
            //--TRIMMABLE-BOUNDARY-START(206160250604)
            /*string?*/ phoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(206160250604)
            
            //--TRIMMABLE-BOUNDARY-START(55836395244)
            /*string?*/ email = null;
            //--TRIMMABLE-BOUNDARY-END(55836395244)
            
            //--TRIMMABLE-BOUNDARY-START(201865283308)
            /*string?*/ password = null;
            //--TRIMMABLE-BOUNDARY-END(201865283308)
            
            //--TRIMMABLE-BOUNDARY-START(51541427948)
            /*string?*/ cpassword = null;
            //--TRIMMABLE-BOUNDARY-END(51541427948)
            
            //--TRIMMABLE-BOUNDARY-START(193275348716)
            /*string?*/ otp = null;
            //--TRIMMABLE-BOUNDARY-END(193275348716)
            
            //--TRIMMABLE-BOUNDARY-START(197570316012)
            /*int*/ otpResend = 0;
            //--TRIMMABLE-BOUNDARY-END(197570316012)
            
            //--TRIMMABLE-BOUNDARY-START(283469661932)
            /*string?*/ transactionPin = null;
            //--TRIMMABLE-BOUNDARY-END(283469661932)
            
            //--TRIMMABLE-BOUNDARY-START(292059596524)
            /*bool */ get Valid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555871980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(this.identity) || $.$$.S.String.IsNullOrEmpty(this.firstName) || $.$$.S.String.IsNullOrEmpty(this.lastName) || $.$$.S.String.IsNullOrEmpty(this.phoneNumber))
                {
                    return false;
                }
                if ($.$GfYa.LCFCA.DecodedAuthenticationTicket.op_Equality(this._loginTicket, null))
                {
                    if ($.$$.S.String.IsNullOrEmpty(this.password) || $.$$.S.String.IsNullOrEmpty(this.cpassword) || (this.password !== this.cpassword))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(292059596524)
            
            //--TRIMMABLE-BOUNDARY-START(210455217900)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(210455217900)
            
            //--TRIMMABLE-BOUNDARY-START(210455217900)
            //--TRIMMABLE-BOUNDARY-START(38656526060)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656526060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38656526060)
            
            //--TRIMMABLE-BOUNDARY-START(219045152492)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045152492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(219045152492)
            
            //--TRIMMABLE-BOUNDARY-END(210455217900)
            
            //--TRIMMABLE-BOUNDARY-START(73016264428)
            /*ValueTask *//*async*/  Forward()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016264428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.step === 1)
                    {
                        if (!this.hasPhoneNumber)
                        {
                            let $t2, $r2;
                            if (!($t2 = this.SendOTP(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))))
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                        }
                        else 
                        {
                            this.step += 1;
                        }
                    }
                    this.step++;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73016264428)
            
            //--TRIMMABLE-BOUNDARY-START(42951493356)
            /*void */ Backward()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951493356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.step--;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951493356)
            
            //--TRIMMABLE-BOUNDARY-START(227635087084)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635087084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(227635087084)
            
            //--TRIMMABLE-BOUNDARY-START(231930054380)
            /*Task<bool> *//*async*/  SendOTP()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231930054380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = $.$vWqU.LCFCC.LoadingExtension.Load$1($.$$.S.Boolean, this, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.S.Boolean)))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                        {
                            if (this.phoneNumber !== null)
                            {
                                let $t4, $r4;
                                ($t4 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendOTPSMS(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, this.phoneNumber, 4, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                this.otpResend = 600;
                                _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                                {
                                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                                    {
                                        while(this.otpResend > 0)
                                        {
                                            let $t5, $r5;
                                            ($t5 = $.$$.STT.Task.Delay$1(1000), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                            this.otpResend--;
                                            _ = this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged));
                                        }
                                    });
                                }, $RqTEQk ??= {"r":178454529,"n":"","d":1820396,"h":0,"f":17829890}));
                                return $.$$.N.AsyncResolver.Result($asnycContext, true);
                            }
                            else 
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("No phone number");
                            }
                        });
                    }, $Itthuc ??= {"r":$.$$.STT.ValueTask$$($.$$.S.Boolean).$h,"n":"","d":1820396,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $MLsFtj ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1820396,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(231930054380)
            
            //--TRIMMABLE-BOUNDARY-START(223340119788)
            /*Task */ ResendOTP()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340119788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.otpResend <= 0)
                {
                    return this.SendOTP();
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(223340119788)
            
            //--TRIMMABLE-BOUNDARY-START(296354563820)
            /*Task *//*async*/  ValidateOTP()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(296354563820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            if (this.otp !== null)
                            {
                                let $t7, $r7;
                                let $t8, $r8;
                                /*var*/ let ok = ($t7 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.VerifyOTPSMS(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, this.phoneNumber, this.otp), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                if (!ok)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12("Invalid OTP");
                                }
                                ($t8 = this.Forward(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                            }
                        });
                    }, $XNAwgl ??= {"r":181338113,"n":"","d":1820396,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $CXbXcb ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1820396,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(296354563820)
            
            //--TRIMMABLE-BOUNDARY-START(60131362540)
            /*Task *//*async*/  Finish()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131362540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t9 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t11, $r11;
                            let $t12, $r12;
                            let $t13, $r13;
                            let $t14, $r14;
                            let $t15, $r15;
                            this.step = 4;
                            /*string?*/ let __ca1__;
                            /*var*/ let user = this._user ?? (() =>
                            {
                                //new $.$Iaui.LCFCM.UserModel()
                                const $t10 = $.$Iaui.LCFCM.UserModel;
                                const $i10 = new $t10();
                                $i10.$ctor$7();
                                $i10.Name = (this._loginTicket?.UserName ?? null) ?? (((__ca1__ = this.email) !== null ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$10.call(__ca1__, "@", 0), 0) : null));
                                return $i10;
                            })();
                            /*var*/ let feature = $.$UlXD.LCPCM.PayCowryAccountFeatureModel.From(user, null, true);
                            feature.Identity = $.$firstOf(this.identity, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("BVN required") });
                            feature.FirstName = $.$firstOf(this.firstName, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("First Name required") });
                            feature.LastName = $.$firstOf(this.lastName, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Last Name required") });
                            feature.PhoneNumber = $.$firstOf(this.phoneNumber, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Phone Number required") });
                            feature.Email = $.$firstOf(this.email, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Email required") });
                            if (feature.Pin.Hash === null)
                            {
                                feature.Pin = this.Service.Protector.LCPCS$IDataProtector$ProtectPin($.$firstOf(this.transactionPin, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Pin required") }));
                            }
                            feature.DeviceId = $.$firstOf((($t11 = this.Service.Platform.LCFCP$IPlatformPropertyProvider$GetDeviceIdAsync(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)))), () => { throw new $.$$.S.InvalidOperationException().$ctor$12("DeviceId required") });
                            this.Service.Protector.LCPCS$IDataProtector$Protect(feature);
                            /*var*/ let result = ($t12 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)))().$ctor(this,  (/*s*/ s) =>
                            {
                                return s.LCPCS$IPayCowryAccountRemoteService$Register(this.email, this.email, this.password, user);
                            }, $gTrkEg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)).$h,"p":[{"n":"s","p":3430035}],"n":"","d":1820396,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                            ($t13 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$SetTicket(result.Ticket ?? $.$firstOf(this._loginTicket, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("No ticket") })), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                            user.Identifier = result.User.Identifier;
                            this.Service.Protector.LCPCS$IDataProtector$Protect(feature);
                            ($t14 = this.Service.PrepareDevice(feature, result.User), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                            ($t15 = this.Onboarded.InvokeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                        });
                    }, $ilzecc ??= {"r":181338113,"n":"","d":1820396,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $HdRyee ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1820396,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60131362540)
            
            //--TRIMMABLE-BOUNDARY-START(8591754988)
            /*UserModel?*/ _user = null;
            //--TRIMMABLE-BOUNDARY-END(8591754988)
            
            //--TRIMMABLE-BOUNDARY-START(4296787692)
            /*DecodedAuthenticationTicket?*/ _loginTicket = null;
            //--TRIMMABLE-BOUNDARY-END(4296787692)
            
            //--TRIMMABLE-BOUNDARY-START(137440773868)
            /*bool*/ hasIdentity = false;
            //--TRIMMABLE-BOUNDARY-END(137440773868)
            
            //--TRIMMABLE-BOUNDARY-START(146030708460)
            /*bool*/ hasPhoneNumber = false;
            //--TRIMMABLE-BOUNDARY-END(146030708460)
            
            //--TRIMMABLE-BOUNDARY-START(128850839276)
            /*bool*/ hasEmail = false;
            //--TRIMMABLE-BOUNDARY-END(128850839276)
            
            //--TRIMMABLE-BOUNDARY-START(133145806572)
            /*bool*/ hasFirstName = false;
            //--TRIMMABLE-BOUNDARY-END(133145806572)
            
            //--TRIMMABLE-BOUNDARY-START(141735741164)
            /*bool*/ hasLastName = false;
            //--TRIMMABLE-BOUNDARY-END(141735741164)
            
            //--TRIMMABLE-BOUNDARY-START(150325675756)
            /*bool*/ hasPin = false;
            //--TRIMMABLE-BOUNDARY-END(150325675756)
            
            //--TRIMMABLE-BOUNDARY-START(64426329836)
            /*void *//*async*/  FinishLogin(/*CommunityPayCowryRegisterResponseModel*/ user)
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426329836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let feature = $.$UlXD.LCPCM.PayCowryAccountFeatureModel.From(user.User, null, null);
                    this.identity = (feature?.Identity ?? null);
                    this.hasIdentity = this.identity !== null;
                    this.phoneNumber = (feature?.PhoneNumber ?? null) ?? user.User.PhoneNumber;
                    this.hasPhoneNumber = !$.$$.S.String.IsNullOrEmpty(this.phoneNumber);
                    this.email = (feature?.Email ?? null) ?? user.User.Email;
                    this.hasEmail = this.email !== null;
                    this.firstName = (feature?.FirstName ?? null) ?? user.User.FirstName;
                    this.hasFirstName = this.firstName !== null;
                    this.lastName = (feature?.LastName ?? null) ?? user.User.LastName;
                    this.hasLastName = this.lastName !== null;
                    this.hasPin = (feature?.Pin ?? null) !== null;
                    this.isLoginIn = false;
                    this._user = user.User;
                    this._loginTicket = user.Ticket;
                    if (this.hasIdentity && this.hasPhoneNumber && this.hasEmail && this.hasFirstName && this.hasLastName)
                    {
                        if (this.hasPin)
                        {
                            let $t16, $r16;
                            ($t16 = this.Finish(), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                        }
                        else 
                        {
                            this.step = 3;
                        }
                    }
                    else 
                    {
                        this.step = 1;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64426329836)
            
            //--TRIMMABLE-BOUNDARY-START(171800512236)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800512236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(171800512236)
            
            //--TRIMMABLE-BOUNDARY-START(47246460652)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246460652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, (336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/) & ~32/*LoadingFeatures.Retry*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", "hv-10 stack");
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 6);
                    __builder2.AddComponentParameter(7, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                    __builder2.AddComponentParameter(8, "class", "fill stack pd scroll-y pos-rel");
                    __builder2.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*_*/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            switch(this.step)
                            {
                                case 0:
                                __builder3.AddMarkupContent(10, "<h1 class=\"text-center fsz-40 mgb-0\">Welcome to</h1>\r\n                        ");
                                __builder3.AddMarkupContent(11, "<h1 class=\"text-center fsz-40 mg-0\">PayCowry</h1>\r\n                        <img class=\"hx-2 mgy mgx-a d-block\" src=\"_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png\">\r\n                        ");
                                __builder3.AddMarkupContent(12, "<p class=\"text-center fw-bold\">\r\n                            PayCowry is the offline way to make and receive instant payments\r\n                            for goods and services, cashless, no internet.\r\n                        </p>\r\n                        ");
                                __builder3.AddMarkupContent(13, "<p class=\"text-center fw-bold\">\r\n                            And did we say it works offline? Yes\r\n                            <a href=\"#\" class=\"f-right cl-primary\">Learn more</a></p>\r\n                        ");
                                __builder3.AddMarkupContent(14, "<p class=\"text-center\">This wizard will help you to setup your PayCowry account for usage</p>\r\n                        <div class=\"fill\"></div>\r\n                        ");
                                __builder3.OpenElement(15, "div");
                                __builder3.AddAttribute$5(16, "class", "flex");
                                __builder3.AddMarkupContent(17, "<div class=\"fill\"></div>\r\n                            ");
                                __builder3.OpenElement(18, "div");
                                __builder3.AddAttribute$5(19, "class", "flex");
                                __builder3.AddMarkupContent(20, "<span class=\"mgy-a bg-primary pdx pdy-2 corner-l-5 hx-03 mgr--2\">Continue</span>\r\n                                ");
                                __builder3.OpenElement(21, "button");
                                __builder3.AddAttribute$5(22, "class", "mdi mdi-chevron-right fsz-25 bg-primary wx-05 hx-05 round");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 23, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forward)));
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                break;
                                case 1:
                                if (this.isLoginIn)
                                {
                                    __builder3.OpenComponent$1($.$HSAN.LCPCS$1.Login, 24);
                                    __builder3.AddComponentParameter(25, "OnLogin", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel), $.$mac.MAC.EventCallback.Factory.Create$8($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, this, new ($.$$.S.Action$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel))().$ctor(this, this.FinishLogin))));
                                    __builder3.CloseComponent();
                                }
                                else 
                                {
                                    __builder3.AddMarkupContent(26, "<h1 class=\"text-center fsz-25 mgb-0\">\r\n                                Please provide your PayCowry Account Information\r\n                            </h1>\r\n                            ");
                                    __builder3.AddMarkupContent(27, "<p class=\"text-center\">\r\n                                Please note that providing your BVN is safe,\r\n                                it deosnt give us access to your bank account and\r\n                                is only meant for us to identify you and no other purpose.\r\n                            </p>");
                                    __builder3.OpenComponent$1($.$macw.MACF.EditForm, 28);
                                    __builder3.AddComponentParameter(29, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                    __builder3.AddComponentParameter(30, "class", "stack mgt fill");
                                    __builder3.AddComponentParameter(31, "OnValidSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macf.MACF.EditContext), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macf.MACF.EditContext, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forward))));
                                    __builder3.AddAttribute$3(32, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            if (!this.hasIdentity)
                                            {
                                                $.$HSAN._LCPCSO.TypeInference.CreateInputEditor_0($.$$.S.String, __builder4, 33, 34, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 mgt corner-5", 35, "BVN", 36, this.identity, 37, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.identity = __value;
                                                }, $BLNzll ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.identity)), 38, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "identity"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $zICzEi ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke()));
                                            }
                                            if (!this.hasFirstName)
                                            {
                                                $.$HSAN._LCPCSO.TypeInference.CreateInputEditor_1($.$$.S.String, __builder4, 39, 40, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 mgt corner-5", 41, "First Name", 42, this.firstName, 43, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.firstName = __value;
                                                }, $Bqpzvi ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.firstName)), 44, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "firstName"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $ubvXdk ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke()));
                                            }
                                            if (!this.hasLastName)
                                            {
                                                $.$HSAN._LCPCSO.TypeInference.CreateInputEditor_2($.$$.S.String, __builder4, 45, 46, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 mgt corner-5", 47, "Last Name", 48, this.lastName, 49, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                                                {
                                                    return this.lastName = __value;
                                                }, $scybbe ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.lastName)), 50, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "lastName"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $TBpdlk ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke()));
                                            }
                                            if (!this.hasPhoneNumber)
                                            {
                                                $.$HSAN._LCPCSO.TypeInference.CreateInputEditor_3($.$$.S.String, __builder4, 51, 52, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 mgt corner-5", 53, "Phone Number", 54, this.phoneNumber, 55, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.phoneNumber = __value;
                                                }, $BWtzwh ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.phoneNumber)), 56, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "phoneNumber"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $LtiAki ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke()));
                                            }
                                            if (!this.hasEmail)
                                            {
                                                $.$HSAN._LCPCSO.TypeInference.CreateInputEditor_4($.$$.S.String, __builder4, 57, 58, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 mgt corner-5", 59, "Email", 60, this.email, 61, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.email = __value;
                                                }, $ciLmKk ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.email)), 62, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "email"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $XzaMYf ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke()));
                                            }
                                            if ($.$GfYa.LCFCA.DecodedAuthenticationTicket.op_Equality(this._loginTicket, null))
                                            {
                                                __builder4.AddMarkupContent(63, "<div class=\"mgt\"></div>\r\n                                    ");
                                                $.$HSAN._LCPCSO.TypeInference.CreateInputEditor_5($.$$.S.String, __builder4, 64, 65, 13n, 66, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 corner-5", 67, "Password", 68, this.password, 69, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.password = __value;
                                                }, $Kpktfi ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.password)), 70, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "password"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $wkUmAa ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke()));
                                                __builder4.AddMarkupContent(71, "\r\n                                    <div class=\"mgt\"></div>\r\n                                    ");
                                                $.$HSAN._LCPCSO.TypeInference.CreateInputEditor_6($.$$.S.String, __builder4, 72, 73, 13n, 74, "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 corner-5", 75, "Confirm Password", 76, this.cpassword, 77, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.cpassword = __value;
                                                }, $roFswa ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.cpassword)), 78, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "cpassword"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $zORnrh ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke()));
                                            }
                                            __builder4.AddMarkupContent(79, "<div class=\"mgt-5\"></div>\r\n                                ");
                                            __builder4.OpenElement(80, "button");
                                            __builder4.AddAttribute$5(81, "class", "bg-primary corner-5 pd mgt-a fsz-18");
                                            __builder4.AddAttribute$5(82, "type", "submit");
                                            __builder4.AddAttribute$2(83, "disabled", !this.Valid);
                                            __builder4.AddContent$4(84, "Continue");
                                            __builder4.CloseElement();
                                        }, $hMvIBh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1820396,"h":0,"f":17825794});
                                    }), $zuOmUb ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1820396,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }
                                break;
                                case 2:
                                __builder3.OpenElement(85, "h1");
                                __builder3.AddAttribute$5(86, "class", "text-center fsz-25 mgb-0");
                                __builder3.AddMarkupContent(87, "\r\n                            We sent an OTP to your phone number ");
                                __builder3.AddContent$4(88, this.phoneNumber);
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(89, "\r\n                        ");
                                __builder3.AddMarkupContent(90, "<p class=\"text-center\">Please provide the OTP to continue</p>");
                                __builder3.OpenComponent$1($.$macw.MACF.EditForm, 91);
                                __builder3.AddComponentParameter(92, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                __builder3.AddComponentParameter(93, "class", "stack fill");
                                __builder3.AddComponentParameter(94, "OnValidSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macf.MACF.EditContext), $.$mac.MAC.EventCallback.Factory.Create$9($.$macf.MACF.EditContext, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ValidateOTP))));
                                __builder3.AddAttribute$3(95, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenElement(96, "input");
                                        __builder4.AddAttribute$5(97, "type", "text");
                                        __builder4.AddAttribute$5(98, "class", "pdy-5 pdx-10 bg-primary-01 bd-0 fsz-20 mgt corner-5");
                                        __builder4.AddAttribute$5(99, "placeholder", "Enter OTP");
                                        __builder4.AddAttribute$5(100, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.otp, null));
                                        __builder4.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 101, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            return this.otp = __value;
                                        }, $vmqlob ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.otp, null));
                                        __builder4.SetUpdatesAttributeName("value");
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(102, "\r\n                            ");
                                        __builder4.OpenElement(103, "div");
                                        __builder4.AddAttribute$5(104, "class", "flex mgt");
                                        __builder4.AddMarkupContent(105, "<div class=\"fill\"></div>\r\n                                ");
                                        __builder4.OpenElement(106, "a");
                                        __builder4.AddAttribute$5(107, "class", "cl-primary");
                                        __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 108, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ResendOTP)));
                                        __builder4.AddMarkupContent(109, "\r\n                                    Resend OTP\r\n");
                                        if (this.otpResend !== 0)
                                        {
                                            __builder4.AddMarkupContent(110, "\r\n                                            : ");
                                            __builder4.AddContent$3(111, $.$box(this.otpResend, $.$$.S.Int32));
                                            __builder4.AddMarkupContent(112, " s\r\n                                        ");
                                        }
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(113, "\r\n                            ");
                                        __builder4.OpenElement(114, "button");
                                        __builder4.AddAttribute$5(115, "class", "bg-primary corner-5 pd mgt-a fsz-18");
                                        __builder4.AddAttribute$5(116, "type", "submit");
                                        __builder4.AddAttribute$2(117, "disabled", $.$$.S.String.IsNullOrEmpty(this.otp));
                                        __builder4.AddContent$4(118, "Validate OTP");
                                        __builder4.CloseElement();
                                    }, $PRBGRk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1820396,"h":0,"f":17825794});
                                }), $vamzRg ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1820396,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                                break;
                                case 3:
                                __builder3.AddMarkupContent(119, "<h1 class=\"text-center fsz-25 mgb-0\">\r\n                            Create your transaction PIN\r\n                        </h1>\r\n                        ");
                                __builder3.AddMarkupContent(120, "<p class=\"text-center\">\r\n                            PayCowry protects your tokens with PIN code, so nobody with access to your device can access your funds\r\n                        </p>");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 121);
                                __builder3.AddComponentParameter(122, "Class", "fsz-30");
                                __builder3.AddComponentParameter(123, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(124, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, 78n), $.$fPer.LCFC.InputType));
                                __builder3.AddComponentParameter(125, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.transactionPin));
                                __builder3.AddComponentParameter(126, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.transactionPin = __value;
                                }, $wQSWrd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1820396,"h":0,"f":17825794}), this.transactionPin))));
                                __builder3.AddComponentParameter(127, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "transactionPin"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $UPwclc ??= {"r":38797349,"n":"","d":1820396,"h":0,"f":17825794})).Invoke())));
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(128, "<div class=\"fill\"></div>\r\n                        ");
                                __builder3.OpenElement(129, "div");
                                __builder3.AddAttribute$5(130, "class", "flex");
                                __builder3.AddMarkupContent(131, "<div class=\"fill\"></div>\r\n                            ");
                                __builder3.OpenElement(132, "div");
                                __builder3.AddAttribute$5(133, "class", "flex");
                                __builder3.AddMarkupContent(134, "<span class=\"mgy-a bg-primary pdx pdy-2 corner-l-5 hx-03 mgr--2\">Finish</span>\r\n                                ");
                                __builder3.OpenElement(135, "button");
                                __builder3.AddAttribute$5(136, "class", "mdi mdi-chevron-right fsz-25 bg-primary wx-05 hx-05 round");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 137, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Finish)));
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                break;
                                case 4:
                                __builder3.AddMarkupContent(138, "<h1 class=\"text-center fsz-25 mgb-0\">\r\n                            Setting up...\r\n                        </h1>\r\n                        ");
                                __builder3.AddMarkupContent(139, "<p class=\"text-center f-bold\">This is the beginning of something great!</p>\r\n                        ");
                                __builder3.AddMarkupContent(140, "<p class=\"text-center\">Please wait...</p>");
                                break;
                            }
                        }, $kystfa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1820396,"h":0,"f":17825794});
                    }), $Dlagvf ??= {"r":6881395,"p":[{"n":"_","p":131188}],"n":"","d":1820396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    if (this.step === 1)
                    {
                        __builder2.OpenElement(141, "button");
                        __builder2.AddAttribute$5(142, "class", "bg-primary-02 pd text-center cl-primary fw-bold");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 143, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleLogin)));
                        __builder2.AddContent$4(144, this.isLoginIn ? "Register" : "Login");
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                }), $uvYIrf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1820396,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(47246460652)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(30066591468)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066591468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066591468)
            
            //--TRIMMABLE-BOUNDARY-START(30066591468)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30066591468)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(236225021676)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(236225021676)
                
                //--TRIMMABLE-BOUNDARY-START(184685414124)
                this.Onboarded = $.$default($.$mac.MAC.EventCallback);
                //--TRIMMABLE-BOUNDARY-END(184685414124)
                
                //--TRIMMABLE-BOUNDARY-START(180390446828)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(180390446828)
                
            }
            static $h = 1820396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(188980381420),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376002796,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1820396,
      "h": 188980381420,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188980381420),
//--TRIMMABLE-BOUNDARY-START(236225021676),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965937388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270584760044,
        "f": 83886081
      },
      "n": "Service",
      "d": 1820396,
      "h": 236225021676,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236225021676),
//--TRIMMABLE-BOUNDARY-START(184685414124),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786068204,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994825452,
        "f": 83886081
      },
      "n": "Onboarded",
      "d": 1820396,
      "h": 184685414124,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685414124),
//--TRIMMABLE-BOUNDARY-START(180390446828),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196133612,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404890860,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1820396,
      "h": 180390446828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390446828),
//--TRIMMABLE-BOUNDARY-START(176095479532),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606199020,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814956268,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1820396,
      "h": 176095479532,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176095479532),
//--TRIMMABLE-BOUNDARY-START(292059596524),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555871980,
        "f": 50331650
      },
      "n": "Valid",
      "d": 1820396,
      "h": 292059596524,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(292059596524)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(287764629228),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1820396,
      "h": 287764629228,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(287764629228),
//--TRIMMABLE-BOUNDARY-START(158915610348),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1820396,
      "h": 158915610348,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158915610348),
//--TRIMMABLE-BOUNDARY-START(279174694636),
    {
      "r": 65537,
      "n": "ToggleLogin",
      "d": 1820396,
      "h": 279174694636,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279174694636),
//--TRIMMABLE-BOUNDARY-START(73016264428),
    {
      "r": 181338113,
      "n": "Forward",
      "d": 1820396,
      "h": 73016264428,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73016264428),
//--TRIMMABLE-BOUNDARY-START(42951493356),
    {
      "r": 65537,
      "n": "Backward",
      "d": 1820396,
      "h": 42951493356,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951493356),
//--TRIMMABLE-BOUNDARY-START(227635087084),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1820396,
      "h": 227635087084,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227635087084),
//--TRIMMABLE-BOUNDARY-START(231930054380),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "n": "SendOTP",
      "d": 1820396,
      "h": 231930054380,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(231930054380),
//--TRIMMABLE-BOUNDARY-START(223340119788),
    {
      "r": 178454529,
      "n": "ResendOTP",
      "d": 1820396,
      "h": 223340119788,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223340119788),
//--TRIMMABLE-BOUNDARY-START(296354563820),
    {
      "r": 178454529,
      "n": "ValidateOTP",
      "d": 1820396,
      "h": 296354563820,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(296354563820),
//--TRIMMABLE-BOUNDARY-START(60131362540),
    {
      "r": 178454529,
      "n": "Finish",
      "d": 1820396,
      "h": 60131362540,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(60131362540),
//--TRIMMABLE-BOUNDARY-START(64426329836),
    {
      "r": 65537,
      "p": [
        {
          "n": "user",
          "p": 284307
        }
      ],
      "n": "FinishLogin",
      "d": 1820396,
      "h": 64426329836,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(64426329836),
//--TRIMMABLE-BOUNDARY-START(171800512236),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1820396,
      "h": 171800512236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171800512236),
//--TRIMMABLE-BOUNDARY-START(47246460652),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1820396,
      "h": 47246460652,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246460652)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(163210577644),
    {
      "t": 262145,
      "n": "isLoginIn",
      "d": 1820396,
      "h": 163210577644,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(163210577644),
//--TRIMMABLE-BOUNDARY-START(274879727340),
    {
      "t": 655361,
      "n": "step",
      "d": 1820396,
      "h": 274879727340,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(274879727340),
//--TRIMMABLE-BOUNDARY-START(154620643052),
    {
      "t": 1310721,
      "n": "identity",
      "d": 1820396,
      "h": 154620643052,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154620643052),
//--TRIMMABLE-BOUNDARY-START(68721297132),
    {
      "t": 1310721,
      "n": "firstName",
      "d": 1820396,
      "h": 68721297132,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68721297132),
//--TRIMMABLE-BOUNDARY-START(167505544940),
    {
      "t": 1310721,
      "n": "lastName",
      "d": 1820396,
      "h": 167505544940,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(167505544940),
//--TRIMMABLE-BOUNDARY-START(206160250604),
    {
      "t": 1310721,
      "n": "phoneNumber",
      "d": 1820396,
      "h": 206160250604,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(206160250604),
//--TRIMMABLE-BOUNDARY-START(55836395244),
    {
      "t": 1310721,
      "n": "email",
      "d": 1820396,
      "h": 55836395244,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55836395244),
//--TRIMMABLE-BOUNDARY-START(201865283308),
    {
      "t": 1310721,
      "n": "password",
      "d": 1820396,
      "h": 201865283308,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(201865283308),
//--TRIMMABLE-BOUNDARY-START(51541427948),
    {
      "t": 1310721,
      "n": "cpassword",
      "d": 1820396,
      "h": 51541427948,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51541427948),
//--TRIMMABLE-BOUNDARY-START(193275348716),
    {
      "t": 1310721,
      "n": "otp",
      "d": 1820396,
      "h": 193275348716,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(193275348716),
//--TRIMMABLE-BOUNDARY-START(197570316012),
    {
      "t": 655361,
      "n": "otpResend",
      "d": 1820396,
      "h": 197570316012,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(197570316012),
//--TRIMMABLE-BOUNDARY-START(283469661932),
    {
      "t": 1310721,
      "n": "transactionPin",
      "d": 1820396,
      "h": 283469661932,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(283469661932),
//--TRIMMABLE-BOUNDARY-START(8591754988),
    {
      "t": 23799126,
      "n": "_user",
      "d": 1820396,
      "h": 8591754988,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591754988),
//--TRIMMABLE-BOUNDARY-START(4296787692),
    {
      "t": 1130882,
      "n": "_loginTicket",
      "d": 1820396,
      "h": 4296787692,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296787692),
//--TRIMMABLE-BOUNDARY-START(137440773868),
    {
      "t": 262145,
      "n": "hasIdentity",
      "d": 1820396,
      "h": 137440773868,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137440773868),
//--TRIMMABLE-BOUNDARY-START(146030708460),
    {
      "t": 262145,
      "n": "hasPhoneNumber",
      "d": 1820396,
      "h": 146030708460,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(146030708460),
//--TRIMMABLE-BOUNDARY-START(128850839276),
    {
      "t": 262145,
      "n": "hasEmail",
      "d": 1820396,
      "h": 128850839276,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128850839276),
//--TRIMMABLE-BOUNDARY-START(133145806572),
    {
      "t": 262145,
      "n": "hasFirstName",
      "d": 1820396,
      "h": 133145806572,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133145806572),
//--TRIMMABLE-BOUNDARY-START(141735741164),
    {
      "t": 262145,
      "n": "hasLastName",
      "d": 1820396,
      "h": 141735741164,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(141735741164),
//--TRIMMABLE-BOUNDARY-START(150325675756),
    {
      "t": 262145,
      "n": "hasPin",
      "d": 1820396,
      "h": 150325675756,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(150325675756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066591468),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1820396,
      "h": 30066591468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066591468)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(210455217900),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1820396,
        "h": 38656526060,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1820396,
        "h": 219045152492,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1820396,
      "h": 210455217900,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(210455217900)
  ],
  "h": 1820396
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Onboarding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Onboarding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1820396)
        
        

        //--TRIMMABLE-BOUNDARY-START(968428)
        $asm.$cls(`$HSAN.LCPCS.PayCowryApplication`, ($self) => class PayCowryApplication extends $.$sZVd.LCFCA.BaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885870316)
            $ctor$3(/*PayCowryService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885870316);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885870316)
            
            //--TRIMMABLE-BOUNDARY-START(137439921900)
            /*string */ get Name()
            {
                return "PayCowry";
            }
            //--TRIMMABLE-BOUNDARY-END(137439921900)
            
            //--TRIMMABLE-BOUNDARY-START(158914758380)
            /*string */ get Title()
            {
                return "PayCowry";
            }
            //--TRIMMABLE-BOUNDARY-END(158914758380)
            
            //--TRIMMABLE-BOUNDARY-START(25770772204)
            /*string */ get Description()
            {
                return "Pay for goods and services, even offline";
            }
            //--TRIMMABLE-BOUNDARY-END(25770772204)
            
            //--TRIMMABLE-BOUNDARY-START(133144954604)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png");
            }
            //--TRIMMABLE-BOUNDARY-END(133144954604)
            
            //--TRIMMABLE-BOUNDARY-START(154619791084)
            /*ThemePack */ get Theme()
            {
                return (() =>
                {
                    //new $.$vWqU.LCFCC.ThemePack()
                    const $t1 = $.$vWqU.LCFCC.ThemePack;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Primary = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#00CF9E";
                        $i2.ForegroundColor = "#FFF";
                        return $i2;
                    })();
                    $i1.Secondary = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t3 = $.$fPer.LCFC.Theme;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.BackgroundColor = "#00DEAF";
                        $i3.ForegroundColor = "#FFF";
                        return $i3;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(154619791084)
            
            //--TRIMMABLE-BOUNDARY-START(34360706796)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360706796)
            
            //--TRIMMABLE-BOUNDARY-START(21475804908)
            /*IEnumerable<string>? */ get Categories()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "Payment" ], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475804908)
            
            //--TRIMMABLE-BOUNDARY-START(17180837612)
            /*Type? */ get ApplicationViewType()
            {
                return $.$HSAN.LCPCP.PayCowryApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180837612)
            
            //--TRIMMABLE-BOUNDARY-START(30065739500)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065739500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(30065739500)
            
            //--TRIMMABLE-BOUNDARY-START(146029856492)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029856492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029856492)
            
            //--TRIMMABLE-BOUNDARY-START(141734889196)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734889196)
            
            //--TRIMMABLE-BOUNDARY-START(4295935724)
            /*PayCowryService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295935724)
            
            //--TRIMMABLE-BOUNDARY-START(150324823788)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324823788)
            
            static $h = 968428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.BaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439921900),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490248940,
        "f": 50364417
      },
      "n": "Name",
      "d": 968428,
      "h": 137439921900,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439921900),
//--TRIMMABLE-BOUNDARY-START(158914758380),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849987308,
        "f": 50364417
      },
      "n": "Title",
      "d": 968428,
      "h": 158914758380,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914758380),
//--TRIMMABLE-BOUNDARY-START(25770772204),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720445164,
        "f": 50364417
      },
      "n": "Description",
      "d": 968428,
      "h": 25770772204,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770772204),
//--TRIMMABLE-BOUNDARY-START(133144954604),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900314348,
        "f": 50364417
      },
      "n": "Icon",
      "d": 968428,
      "h": 133144954604,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144954604),
//--TRIMMABLE-BOUNDARY-START(154619791084),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260052716,
        "f": 50364417
      },
      "n": "Theme",
      "d": 968428,
      "h": 154619791084,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619791084),
//--TRIMMABLE-BOUNDARY-START(34360706796),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310379756,
        "f": 50364417
      },
      "n": "Features",
      "d": 968428,
      "h": 34360706796,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360706796),
//--TRIMMABLE-BOUNDARY-START(21475804908),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130510572,
        "f": 50364417
      },
      "n": "Categories",
      "d": 968428,
      "h": 21475804908,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475804908),
//--TRIMMABLE-BOUNDARY-START(17180837612),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540575980,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 968428,
      "h": 17180837612,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180837612),
//--TRIMMABLE-BOUNDARY-START(141734889196),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080183532,
        "f": 50364417
      },
      "n": "Order",
      "d": 968428,
      "h": 141734889196,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734889196),
//--TRIMMABLE-BOUNDARY-START(4295935724),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950641388,
        "f": 50331650
      },
      "n": "_Service",
      "d": 968428,
      "h": 4295935724,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295935724),
//--TRIMMABLE-BOUNDARY-START(150324823788),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670118124,
        "f": 50364417
      },
      "n": "Service",
      "d": 968428,
      "h": 150324823788,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324823788)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065739500),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 968428,
      "h": 30065739500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065739500),
//--TRIMMABLE-BOUNDARY-START(146029856492),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 968428,
      "h": 146029856492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029856492)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885870316),
    {
      "p": [
        {
          "n": "service",
          "p": 1296108
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 968428,
      "h": 12885870316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885870316)
  ],
  "h": 968428,
  "a": [
    {
      "t": 564704,
      "c": 8590499296,
      "a": [
        {
          "v": [
            "LivingThing.Core.Community.Market.StorePaymentTier.Blazor",
            "LivingThing.Core.Community.Dispatch.Client.Blazor"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$GfYa.LCFCA.IAuthenticationClient, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.PayCowryApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}PayCowryApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(968428)
        
        

        //--TRIMMABLE-BOUNDARY-START(1296108)
        $asm.$cls(`$HSAN.LCPCS.PayCowryService`, ($self) => class PayCowryService extends $.$sZVd.LCFCA.ApplicationBaseService
        {
            //--TRIMMABLE-BOUNDARY-START(60130838252)
            /*WalletService*/ coinService = null;
            //--TRIMMABLE-BOUNDARY-END(60130838252)
            
            //--TRIMMABLE-BOUNDARY-START(214749660908)
            /*PayCowryOnlineCoinIssuer*/ onlineIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(214749660908)
            
            //--TRIMMABLE-BOUNDARY-START(55835870956)
            $ctor$5(/*IClientUnitOfWork*/ unitOfWork, /*IDataProtector*/ protector, /*IConnectionManager*/ connection, /*IMessagePipeFactory*/ messagePipeFactory, /*IWalletQRPaymentScannerProvider*/ qrScanner, /*IPlatformPropertyProvider*/ platform, /*WalletService*/ coinService, /*PayCowryOnlineCoinIssuer*/ onlineIssuer, /*PayCowryOfflineCoinIssuer*/ offlineIssuer)
            {
                super.$ctor$4(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835870956);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let database = $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$UlXD.LCPCS.ILocalDatabase, unitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider);
                    this.LocalDatabase = database;
                    this.Protector = protector;
                    this.MessagePipeFactory = messagePipeFactory;
                    this.Platform = platform;
                    this.coinService = coinService;
                    this.onlineIssuer = onlineIssuer;
                    if (database !== null)
                    {
                        this.OfflinePaymentProvider = new $.$HSAN.LCPCS.PayCowryOfflinePaymentProvider().$ctor$1(this, database, qrScanner, connection, protector, offlineIssuer);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835870956)
            
            //--TRIMMABLE-BOUNDARY-START(184684889836)
            /*IMessagePipeFactory*/ MessagePipeFactory = null;
            //--TRIMMABLE-BOUNDARY-END(184684889836)
            
            //--TRIMMABLE-BOUNDARY-START(339303712492)
            /*UserModel?*/ User = null;
            //--TRIMMABLE-BOUNDARY-END(339303712492)
            
            //--TRIMMABLE-BOUNDARY-START(180389922540)
            /*ILocalDatabase?*/ LocalDatabase = null;
            //--TRIMMABLE-BOUNDARY-END(180389922540)
            
            //--TRIMMABLE-BOUNDARY-START(240519464684)
            /*IDataProtector*/ Protector = null;
            //--TRIMMABLE-BOUNDARY-END(240519464684)
            
            //--TRIMMABLE-BOUNDARY-START(227634562796)
            /*WalletSystem*/ OnlineWalletProvider = null;
            //--TRIMMABLE-BOUNDARY-END(227634562796)
            
            //--TRIMMABLE-BOUNDARY-START(206159726316)
            /*PayCowryOfflinePaymentProvider?*/ OfflinePaymentProvider = null;
            //--TRIMMABLE-BOUNDARY-END(206159726316)
            
            //--TRIMMABLE-BOUNDARY-START(231929530092)
            /*IPlatformPropertyProvider*/ Platform = null;
            //--TRIMMABLE-BOUNDARY-END(231929530092)
            
            //--TRIMMABLE-BOUNDARY-START(219044628204)
            /*PayCowryWalletInfo?*/ OnlineWalletInfo = null;
            //--TRIMMABLE-BOUNDARY-END(219044628204)
            
            //--TRIMMABLE-BOUNDARY-START(210454693612)
            /*PayCowryWalletInfo?*/ OfflineWalletInfo = null;
            //--TRIMMABLE-BOUNDARY-END(210454693612)
            
            //--TRIMMABLE-BOUNDARY-START(201864759020)
            /*PayCowryOfflineAccountModel?*/ OfflineAccount = null;
            //--TRIMMABLE-BOUNDARY-END(201864759020)
            
            //--TRIMMABLE-BOUNDARY-START(223339595500)
            /*IMessagePipe?*/ OnlineWalletPipe = null;
            //--TRIMMABLE-BOUNDARY-END(223339595500)
            
            //--TRIMMABLE-BOUNDARY-START(335008745196)
            /*int*/ UIKey = 0;
            //--TRIMMABLE-BOUNDARY-END(335008745196)
            
            //--TRIMMABLE-BOUNDARY-START(249109399276)
            /*ValueTask *//*async*/  RefreshProviders()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249109399276);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        ($t1 = this.OnlineWalletProvider.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        this.OnlineWalletInfo = this.OnlineWalletProvider.Coins !== null ? (() =>
                        {
                            //new $.$UlXD.LCPCM.PayCowryWalletInfo()
                            const $t2 = $.$UlXD.LCPCM.PayCowryWalletInfo;
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.Balance = $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletDataModel, this.OnlineWalletProvider.Coins, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Double))().$ctor(this,  (/**/ c) =>
                            {
                                return c.Amount;
                            }, $DesZQf ??= {"r":1179649,"p":[{"n":"c","p":1881293}],"n":"","d":1296108,"h":0,"f":17825794}));
                            return $i2;
                        })() : null;
                    }
                    catch($e)
                    {
                    }
                    if (this.OfflinePaymentProvider !== null)
                    {
                        let $t3, $r3;
                        ($t3 = this.OfflinePaymentProvider.Load(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel>*/ let __ca1__;
                        this.OfflineWalletInfo = (() =>
                        {
                            //new $.$UlXD.LCPCM.PayCowryWalletInfo()
                            const $t4 = $.$UlXD.LCPCM.PayCowryWalletInfo;
                            const $i4 = new $t4();
                            $i4.$ctor$1();
                            $i4.Balance = ((__ca1__ = this.OfflinePaymentProvider.OfflineTokens) !== null ? $.$sl.SL.Enumerable.Sum$17($.$UlXD.LCPCM.PayCowryTokenModel, __ca1__, new ($.$$.S.Func$$$($.$UlXD.LCPCM.PayCowryTokenModel, $.$$.S.Int32))().$ctor(this,  (/**/ c) =>
                            {
                                return c.Amount;
                            }, $mtRihg ??= {"r":655361,"p":[{"n":"c","p":2184851}],"n":"","d":1296108,"h":0,"f":17825794})) : 0);
                            return $i4;
                        })();
                    }
                    this.UIKey++;
                    this.RaisePropertyChanged$1("");
                });
            }
            //--TRIMMABLE-BOUNDARY-END(249109399276)
            
            //--TRIMMABLE-BOUNDARY-START(193274824428)
            /*void */ NotifyNewTransaction(/*PayCowryTransactionModel*/ transaction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274824428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UIKey++;
                this.RaisePropertyChanged$1("");
            }
            //--TRIMMABLE-BOUNDARY-END(193274824428)
            
            //--TRIMMABLE-BOUNDARY-START(197569791724)
            /*void */ NotifyTokensSent(/*IEnumerable<PayCowryTokenModel>*/ tokens)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569791724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UIKey++;
                this.OfflinePaymentProvider?.NotifyTokensSent(tokens);
                this.RaisePropertyChanged$1("");
            }
            //--TRIMMABLE-BOUNDARY-END(197569791724)
            
            //--TRIMMABLE-BOUNDARY-START(188979857132)
            /*void */ NotifyNewTokensReceived(/*IEnumerable<PayCowryTokenModel>*/ tokens)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979857132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UIKey++;
                this.OfflinePaymentProvider?.NotifyNewTokensReceived(tokens);
                this.RaisePropertyChanged$1("");
            }
            //--TRIMMABLE-BOUNDARY-END(188979857132)
            
            //--TRIMMABLE-BOUNDARY-START(1361644)
            static $_RemoteHolder;
            static get RemoteHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1361644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$HSAN.LCPCS.PayCowryService;
                return $cls.$_RemoteHolder ??= $asm.$ncls(`$HSAN.LCPCS.PayCowryService.RemoteHolder`, ($self) => class RemoteHolder extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(124555413228)
                    /*PayCowryOfflineAccountModel*/ offlineAccount = null;
                    //--TRIMMABLE-BOUNDARY-END(124555413228)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886263532)
                    $ctor$1(/*PayCowryOfflineAccountModel*/ offlineAccount)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886263532);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.offlineAccount = offlineAccount;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886263532)
                    
                    //--TRIMMABLE-BOUNDARY-START(120260445932)
                    /*WalletAddress */ get NetworkAddress()
                    {
                        return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1(this.offlineAccount.UserName);
                    }
                    //--TRIMMABLE-BOUNDARY-END(120260445932)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375544044)
                    /*DataId */ get Identifier()
                    {
                        return this.offlineAccount.Identifier;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107375544044)
                    
                    //--TRIMMABLE-BOUNDARY-START(128850380524)
                    /*string? */ get PhoneNumber()
                    {
                        return this.offlineAccount.PhoneNumber;
                    }
                    //--TRIMMABLE-BOUNDARY-END(128850380524)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476198124)
                    /*string? */ get Email()
                    {
                        return this.offlineAccount.Email;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476198124)
                    
                    //--TRIMMABLE-BOUNDARY-START(111670511340)
                    /*GeoLocation?*/ Location = null;
                    //--TRIMMABLE-BOUNDARY-END(111670511340)
                    
                    //--TRIMMABLE-BOUNDARY-START(133145347820)
                    /*string? */ get Title()
                    {
                        return this.offlineAccount.Title;
                    }
                    //--TRIMMABLE-BOUNDARY-END(133145347820)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181230828)
                    /*string? */ get Description()
                    {
                        return this.offlineAccount.Description;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181230828)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080576748)
                    /*IconDescriptor*/ Icon;
                    //--TRIMMABLE-BOUNDARY-END(103080576748)
                    
                    //--TRIMMABLE-BOUNDARY-START(115965478636)
                    /*string? */ get Name()
                    {
                        return this.offlineAccount.UserName;
                    }
                    //--TRIMMABLE-BOUNDARY-END(115965478636)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590505165)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder.NetworkAddress.get
                    get LCFCW$IWalletHolder$NetworkAddress()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885472461);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.NetworkAddress;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590505165)
                    
                    //--TRIMMABLE-BOUNDARY-START(21479917910)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Identifier.get
                    get LCFCC$2$IContact$Identifier()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51544688982);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Identifier;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21479917910)
                    
                    //--TRIMMABLE-BOUNDARY-START(47249721686)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.PhoneNumber.get
                    get LCFCC$2$IContact$PhoneNumber()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64429590870);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.PhoneNumber;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47249721686)
                    
                    //--TRIMMABLE-BOUNDARY-START(12889983318)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Email.get
                    get LCFCC$2$IContact$Email()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300048726);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Email;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12889983318)
                    
                    //--TRIMMABLE-BOUNDARY-START(38659787094)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Location.get
                    get LCFCC$2$IContact$Location()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60134623574);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Location;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38659787094)
                    
                    //--TRIMMABLE-BOUNDARY-START(17226762582)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
                    get LCFC$IDisplayable$Title()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25816697174);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Title;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17226762582)
                    
                    //--TRIMMABLE-BOUNDARY-START(8636827990)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
                    get LCFC$IDisplayable$Icon()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21521729878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Icon;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8636827990)
                    
                    //--TRIMMABLE-BOUNDARY-START(12931729750)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
                    get LCFC$IDescribable$Description()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4341795158);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Description;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12931729750)
                    
                    //--TRIMMABLE-BOUNDARY-START(8637417814)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
                    get LCFC$INamed$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12932385110);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8637417814)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(103080576748)
                        this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                        //--TRIMMABLE-BOUNDARY-END(103080576748)
                        
                    }
                    static $h = 1361644;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260445932),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605740268,
        "f": 50331649
      },
      "n": "NetworkAddress",
      "d": 1361644,
      "h": 120260445932,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260445932),
//--TRIMMABLE-BOUNDARY-START(107375544044),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835936492,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 1361644,
      "h": 107375544044,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375544044),
//--TRIMMABLE-BOUNDARY-START(128850380524),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195674860,
        "f": 50331649
      },
      "n": "PhoneNumber",
      "d": 1361644,
      "h": 128850380524,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850380524),
//--TRIMMABLE-BOUNDARY-START(21476198124),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656067308,
        "f": 50331649
      },
      "n": "Email",
      "d": 1361644,
      "h": 21476198124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476198124),
//--TRIMMABLE-BOUNDARY-START(111670511340),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425871084,
        "f": 50331649
      },
      "n": "Location",
      "d": 1361644,
      "h": 111670511340,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670511340),
//--TRIMMABLE-BOUNDARY-START(133145347820),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785609452,
        "f": 50331649
      },
      "n": "Title",
      "d": 1361644,
      "h": 133145347820,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145347820),
//--TRIMMABLE-BOUNDARY-START(17181230828),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066132716,
        "f": 50331649
      },
      "n": "Description",
      "d": 1361644,
      "h": 17181230828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181230828),
//--TRIMMABLE-BOUNDARY-START(103080576748),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246001900,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1361644,
      "h": 103080576748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080576748),
//--TRIMMABLE-BOUNDARY-START(115965478636),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015805676,
        "f": 50331649
      },
      "n": "Name",
      "d": 1361644,
      "h": 115965478636,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965478636)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124555413228),
    {
      "t": 1595027,
      "n": "offlineAccount",
      "d": 1361644,
      "h": 124555413228,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555413228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886263532),
    {
      "p": [
        {
          "n": "offlineAccount",
          "p": 1595027
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1361644,
      "h": 12886263532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886263532)
  ],
  "d": 1296108,
  "h": 1361644
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletHolder, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.PayCowryService+RemoteHolder`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}PayCowryService${separator}RemoteHolder`; }
                }, $cls, ($v) => $cls.$_RemoteHolder = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1361644)
            
            //--TRIMMABLE-BOUNDARY-START(171799987948)
            /*Task *//*async*/  InitializeProviders()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799987948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.User === null && this.OfflineAccount === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    this.OnlineWalletProvider = (() =>
                    {
                        //new $.$SeJP.LCWCS.WalletSystem()
                        const $t5 = $.$SeJP.LCWCS.WalletSystem;
                        const $i5 = new $t5();
                        $i5.$ctor$2(this.coinService, this.OfflineAccount !== null ? new $.$HSAN.LCPCS.PayCowryService.RemoteHolder().$ctor$1(this.OfflineAccount) : new $.$OJJQ.LCFCW.UserWallerHolder().$ctor$1($.$firstOf(this.User, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Either offline account or user account is required!") }), "PayCowry"), this.onlineIssuer);
                        $i5.Theme = new $.$fPer.LCFC.Theme().$ctor$4("linear-gradient(180deg, rgb(var(--primary-background-color)), rgb(var(--secondary-background-color)))", "white", 1);
                        return $i5;
                    })();
                    if (this.OfflinePaymentProvider !== null && this.OfflineAccount !== null)
                    {
                        this.OfflinePaymentProvider.Holder = this.OfflineAccount;
                    }
                    this.OnlineWalletInfo = this.OnlineWalletProvider.Coins !== null ? (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryWalletInfo()
                        const $t6 = $.$UlXD.LCPCM.PayCowryWalletInfo;
                        const $i6 = new $t6();
                        $i6.$ctor$1();
                        $i6.Balance = $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletDataModel, this.OnlineWalletProvider.Coins, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                        {
                            return c.Amount;
                        }, $istPye ??= {"r":1179649,"p":[{"n":"c","p":1881293}],"n":"","d":1296108,"h":0,"f":17825794}));
                        return $i6;
                    })() : null;
                    if (this.OfflinePaymentProvider !== null)
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel>*/ let __ca2__;
                        this.OfflineWalletInfo = (() =>
                        {
                            //new $.$UlXD.LCPCM.PayCowryWalletInfo()
                            const $t7 = $.$UlXD.LCPCM.PayCowryWalletInfo;
                            const $i7 = new $t7();
                            $i7.$ctor$1();
                            $i7.Balance = ((__ca2__ = this.OfflinePaymentProvider.OfflineTokens) !== null ? $.$sl.SL.Enumerable.Sum$17($.$UlXD.LCPCM.PayCowryTokenModel, __ca2__, new ($.$$.S.Func$$$($.$UlXD.LCPCM.PayCowryTokenModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                            {
                                return c.Amount;
                            }, $TmBnrd ??= {"r":655361,"p":[{"n":"c","p":2184851}],"n":"","d":1296108,"h":0,"f":17825794})) : 0);
                            return $i7;
                        })();
                        this.OfflinePaymentProvider.OnlinePayment = this.OnlineWalletProvider;
                    }
                    this.OnlineWalletProvider.OfflinePayment = this.OfflinePaymentProvider;
                    try
                    {
                        let $t8, $r8;
                        this.OnlineWalletPipe = ($t8 = this.MessagePipeFactory.LCFCM$IMessagePipeFactory$Join($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCR$3.RoutePath), [$.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`PayCowry/Wallet/${$.$strNN($.$dspc((this.OfflineAccount?.RemoteId ?? null) ?? (this.User?.Identifier.Id ?? null), $.$$.S.Object, ($t) => $t.ToString))}`)], [-1], null), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        this.OnlineWalletPipe.LCFCM$IMessagePipe$Subscribe($.$OJJQ.LCFCW.UserWalletTransactionModel, new ($.$$.S.Action$$($.$OJJQ.LCFCW.UserWalletTransactionModel))().$ctor(this, /*async*/  (/**/ t) =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t12, $r12;
                                _ = $.$hDPm.LCFCI.ViewPresenterExtensions.SnackBar($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Wallet Funded", false), $.$hDPm.LCFC.FragmentView.Paragraph$3($.$$.S.Object, `Your Wallet has been funded with ${$.$strNN("\u20A6"/*Money.NairaSymbol*/)}${$.$strNN(t.Amount)}`, (() =>
                                {
                                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                                    const $t9 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                                    const $i9 = new $t9();
                                    $i9.$ctor$1();
                                    $i9.set_Item("class", "mgb-0");
                                    return $i9;
                                })(), false), null, (() =>
                                {
                                    //new $.$hDPm.LCFCI.ViewConfiguration()
                                    const $t10 = $.$hDPm.LCFCI.ViewConfiguration;
                                    const $i10 = new $t10();
                                    $i10.$ctor$2();
                                    $i10.PageBackgroundTheme = $.$fPer.LCFC.Theme.Primary;
                                    $i10.BodyAttributes = (() =>
                                    {
                                        //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                                        const $t11 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                                        const $i11 = new $t11();
                                        $i11.$ctor$1();
                                        $i11.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "pd");
                                        return $i11;
                                    })();
                                    return $i10;
                                })());
                                ($t12 = this.OnlineWalletProvider.Load(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                                this.OnlineWalletInfo = this.OnlineWalletProvider.Coins !== null ? (() =>
                                {
                                    //new $.$UlXD.LCPCM.PayCowryWalletInfo()
                                    const $t13 = $.$UlXD.LCPCM.PayCowryWalletInfo;
                                    const $i13 = new $t13();
                                    $i13.$ctor$1();
                                    $i13.Balance = $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletDataModel, this.OnlineWalletProvider.Coins, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                                    {
                                        return c.Amount;
                                    }, $EgQLYj ??= {"r":1179649,"p":[{"n":"c","p":1881293}],"n":"","d":1296108,"h":0,"f":17825794}));
                                    return $i13;
                                })() : null;
                                this.RaisePropertyChanged$1("");
                            });
                        }, $qRdPGd ??= {"r":65537,"p":[{"n":"t","p":2208973}],"n":"","d":1296108,"h":0,"f":17829890}));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171799987948)
            
            //--TRIMMABLE-BOUNDARY-START(176094955244)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094955244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t14, $r14;
                        let $t20, $r20;
                        let $t21, $r21;
                        this.User = ($t14 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.TryReadSingle($.$Iaui.LCFCM.UserModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, null), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                        if (this.LocalDatabase !== null && this.LocalDatabase.LCPCS$ILocalDatabase$IsInitialized)
                        {
                            let $t15, $r15;
                            this.OfflineAccount = ($t15 = this.LocalDatabase.LCPCS$ILocalDatabase$Load(), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                            _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    try
                                    {
                                        let $t18, $r18;
                                        /*int*/ let page = 1;
                                        /*List<PayCowryTokenModel>*/ let tokens = new ($.$$.SCG.List$$($.$UlXD.LCPCM.PayCowryTokenModel))().$ctor$1();
                                        while(true)
                                        {
                                            let $t16, $r16;
                                            /*var*/ let _tokens = ($t16 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$UlXD.LCPCS.IPayCowryRemoteService, $.$UlXD.LCPCM.PayCowryTokenModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel)))().$ctor(this,  (/*server*/ server) =>
                                            {
                                                return server.LCPCS$IPayCowryRemoteService$GetTokens(this.OfflineAccount, new $.$fPer.LCFCD.DataFilter().$ctor$18(page, 1000));
                                            }, $UMoDgb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel)).$h,"p":[{"n":"server","p":3561107}],"n":"","d":1296108,"h":0,"f":17825794}), null, (() =>
                                            {
                                                //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                                                const $t17 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                                                const $i17 = new $t17();
                                                $i17.$ctor$1();
                                                $i17.TimeOut = ((5 * 60000) | 0);
                                                return $i17;
                                            })()), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel>?*/ let __ca3__;
                                            if (!(((__ca3__ = _tokens.Data) !== null ? $.$sl.SL.Enumerable.Any$1($.$UlXD.LCPCM.PayCowryTokenModel, __ca3__) : false)))
                                            {
                                                break;
                                            }
                                            tokens.AddRange(_tokens.Data);
                                            page++;
                                        }
                                        ($t18 = this.LocalDatabase.LCPCS$ILocalDatabase$SynchTokensFromServer(tokens), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                                        if (this.OfflinePaymentProvider !== null)
                                        {
                                            let $t19, $r19;
                                            ($t19 = this.OfflinePaymentProvider.Load(), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                                        }
                                    }
                                    catch(e)
                                    {
                                        $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Client.Blazor\\PayCowryService.cs", "Load", 251);
                                    }
                                });
                            }, $sUpAYj ??= {"r":178454529,"n":"","d":1296108,"h":0,"f":17829890}));
                        }
                        ($t20 = this.InitializeProviders(), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                        ($t21 = this.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                    });
                }, $oOoOmc ??= {"r":181338113,"n":"","d":1296108,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(176094955244)
            
            //--TRIMMABLE-BOUNDARY-START(236224497388)
            /*Task *//*async*/  PrepareDevice(/*PayCowryAccountFeatureModel*/ accountFeature, /*UserModel*/ user)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t24, $r24;
                    let $t25, $r25;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236224497388);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.LocalDatabase !== null)
                    {
                        let $t22, $r22;
                        let $t23, $r23;
                        ($t22 = this.LocalDatabase.LCPCS$ILocalDatabase$Initialize(accountFeature, user), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                        this.OfflineAccount = ($t23 = this.LocalDatabase.LCPCS$ILocalDatabase$Load(), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                    }
                    ($t24 = this.InitializeProviders(), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                    ($t25 = this.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(236224497388)
            
            //--TRIMMABLE-BOUNDARY-START(64425805548)
            /*Task *//*async*/  DoSwap(/*WalletSwapRequest*/ request)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425805548);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.LocalDatabase !== null && this.OfflineAccount !== null)
                    {
                        /*var*/ let transactionReference = $.$$.S.Guid.NewGuid().ToString();
                        /*System.Collections.Generic.Dictionary<(LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer, LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor), double>?*/ let __ca4__;
                        /*var*/ let denominations = ((__ca4__ = request.DestinationDenomination) !== null ? $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Int32, $.$$.S.Int32, __ca4__, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Int32))().$ctor(this,  (/*e*/ e) =>
                        {
                            return $.$cast(e.Key.Item2.Amount, $.$$.S.Int32);
                        }, $DpHYya ??= {"r":655361,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":1296108,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Int32))().$ctor(this,  (/*e*/ e) =>
                        {
                            return $.$cast(e.Value, $.$$.S.Int32);
                        }, $uGZaCb ??= {"r":655361,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":1296108,"h":0,"f":17825794})) : null);
                        if (request.Source === this.OnlineWalletProvider && request.Destination === this.OfflinePaymentProvider)
                        {
                            let $t26, $r26;
                            let $t27, $r27;
                            /*var*/ let pin = ($t26 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$$.S.String, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Wallet Pin", false), null, null, 78n, null, 0, 4, 4131, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                            ($t27 = $.$vWqU.LCFCC.IUIPromptExtension.Loading(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, new ($.$$.S.Func$$$($.$vWqU.LCFCC.IUILoadingControl, $.$$.STT.Task))().$ctor(this, /*async*/  (/*control*/ control) =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    let $t28, $r28;
                                    let $t29, $r29;
                                    let $t30, $r30;
                                    let $t31, $r31;
                                    control.LCFCC$IUILoadingControl$Info = "Performing Exchange...";
                                    /*var*/ let tokens = ($t28 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$UlXD.LCPCS.IPayCowryRemoteService, $.$UlXD.LCPCM.PayCowryTokenModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel)))().$ctor(this,  (/*server*/ server) =>
                                    {
                                        return server.LCPCS$IPayCowryRemoteService$BuyTokens(transactionReference, this.OfflineAccount, request.SourceAmount, denominations, pin);
                                    }, $kboVic ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel)).$h,"p":[{"n":"server","p":3561107}],"n":"","d":1296108,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t28, { set $v($v) { $r28 = $v; } }) ? $r28 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t28)));
                                    control.LCFCC$IUILoadingControl$Info = "Saving Tokens...";
                                    /*var*/ let transaction = ($t29 = this.LocalDatabase.LCPCS$ILocalDatabase$ReceiveTokens($.$OJJQ.LCFCW.WalletAddress.op_Implicit$1("PayCowry/Wallet"/*PayCowryTokenModel.WalletName*/), tokens.Data, "Buy Cowries"), ($.$$.N.AsyncResolver.IsCompleted($t29, { set $v($v) { $r29 = $v; } }) ? $r29 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t29)));
                                    this.NotifyNewTokensReceived(tokens.Data);
                                    this.NotifyNewTransaction(transaction);
                                    ($t30 = this.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30)));
                                    control.LCFCC$IUILoadingControl$Icon = $.$vWqU.LCFCC.LoadingIcon.Success;
                                    control.LCFCC$IUILoadingControl$Info = "Successful!";
                                    ($t31 = $.$$.STT.Task.Delay$1(3000), ($.$$.N.AsyncResolver.IsCompleted($t31, { set $v($v) { $r31 = $v; } }) ? $r31 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t31)));
                                });
                            }, $QbiNDk ??= {"r":178454529,"p":[{"n":"control","p":4939176}],"n":"","d":1296108,"h":0,"f":17829890}), null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                        }
                        else if (request.Source === this.OfflinePaymentProvider && request.Destination === this.OnlineWalletProvider)
                        {
                            let $t32, $r32;
                            ($t32 = $.$vWqU.LCFCC.IUIPromptExtension.Loading(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, new ($.$$.S.Func$$$($.$vWqU.LCFCC.IUILoadingControl, $.$$.STT.Task))().$ctor(this, /*async*/  (/*control*/ control) =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    let $t33, $r33;
                                    let $t38, $r38;
                                    let $t39, $r39;
                                    control.LCFCC$IUILoadingControl$Info = "Performing Exchange...";
                                    /*var*/ let context = ($t33 = this.LocalDatabase.LCPCS$ILocalDatabase$BeginTokenTransfer($.$cast(request.SourceAmount, $.$$.S.Int32), denominations, $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1("PayCowry/Wallet"/*PayCowryTokenModel.WalletName*/), "Sell Cowries"), ($.$$.N.AsyncResolver.IsCompleted($t33, { set $v($v) { $r33 = $v; } }) ? $r33 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t33)));
                                    /*PayCowryTransactionModel?*/ let transaction = null;
                                    do
                                    {
                                        try
                                        {
                                            let $t34, $r34;
                                            let $t35, $r35;
                                            /*var*/ let serverTransaction = ($t34 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$UlXD.LCPCS.IPayCowryRemoteService, $.$OJJQ.LCFCW.UserWalletTransactionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)))().$ctor(this,  (/**/ server) =>
                                            {
                                                return server.LCPCS$IPayCowryRemoteService$SellTokens(transactionReference, this.OfflineAccount, request.SourceAmount, context.Tokens);
                                            }, $YZjkWe ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,"p":[{"n":"server","p":3561107}],"n":"","d":1296108,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t34, { set $v($v) { $r34 = $v; } }) ? $r34 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t34)));
                                            transaction = ($t35 = context.CompleteTransaction.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t35, { set $v($v) { $r35 = $v; } }) ? $r35 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t35)));
                                        }
                                        catch($e)
                                        {
                                            if ($e instanceof $.$snh.SNH.HttpRequestException)
                                            {
                                                continue;
                                            }
                                            else if ($e instanceof $.$$.S.Exception)
                                            {
                                                let $t36, $r36;
                                                let $t37, $r37;
                                                let e = $e;
                                                ($t36 = context.ReverseTransaction.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t36, { set $v($v) { $r36 = $v; } }) ? $r36 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t36)));
                                                control.LCFCC$IUILoadingControl$Icon = $.$vWqU.LCFCC.LoadingIcon.Fail;
                                                control.LCFCC$IUILoadingControl$Info = e.Message;
                                                ($t37 = $.$$.STT.Task.Delay$1(3000), ($.$$.N.AsyncResolver.IsCompleted($t37, { set $v($v) { $r37 = $v; } }) ? $r37 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t37)));
                                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                                            }
                                            else
                                            {
                                                throw $e;
                                            }
                                        }
                                        break;
                                    }
                                    while(true);
                                    ($t38 = this.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t38, { set $v($v) { $r38 = $v; } }) ? $r38 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t38)));
                                    if (transaction !== null)
                                    {
                                        this.NotifyNewTransaction(transaction);
                                    }
                                    control.LCFCC$IUILoadingControl$Icon = $.$vWqU.LCFCC.LoadingIcon.Success;
                                    control.LCFCC$IUILoadingControl$Info = "Successful!";
                                    ($t39 = $.$$.STT.Task.Delay$1(3000), ($.$$.N.AsyncResolver.IsCompleted($t39, { set $v($v) { $r39 = $v; } }) ? $r39 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t39)));
                                });
                            }, $ehuaWg ??= {"r":178454529,"p":[{"n":"control","p":4939176}],"n":"","d":1296108,"h":0,"f":17829890}), null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t32, { set $v($v) { $r32 = $v; } }) ? $r32 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t32)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425805548)
            
            //--TRIMMABLE-BOUNDARY-START(253404366572)
            /*ValueTask */ Send()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404366572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$HSAN.LCPCS$1.PayCowryWalletSend, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(253404366572)
            
            //--TRIMMABLE-BOUNDARY-START(261994301164)
            /*ValueTask */ SendOnline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994301164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$HSAN.LCPCS$1.PayCowryWalletSend, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                {
                    b.AddAttribute$4(1, "TransactionType", $.$box(1/*PayCowryTransactionType.Online*/, $.$UlXD.LCPCM.PayCowryTransactionType));
                }, $jfzUgb ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":1296108,"h":0,"f":17825794}), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(261994301164)
            
            //--TRIMMABLE-BOUNDARY-START(257699333868)
            /*ValueTask */ SendOffline()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699333868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$HSAN.LCPCS$1.PayCowryWalletSend, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                {
                    b.AddAttribute$4(1, "TransactionType", $.$box(0/*PayCowryTransactionType.Offline*/, $.$UlXD.LCPCM.PayCowryTransactionType));
                }, $BFsLIb ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":1296108,"h":0,"f":17825794}), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(257699333868)
            
            //--TRIMMABLE-BOUNDARY-START(266289268460)
            /*ValueTask */ SendToBank()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289268460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletSend, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                {
                    builder.AddAttribute$4(1, "Wallet", this.OnlineWalletProvider);
                    builder.AddAttribute$4(2, "WalletSendProvider", new $.$HSAN.LCPCS.PayCowrySendToBankWalletProvider().$ctor$1(this));
                    builder.AddAttribute$1(3, "OnFinished", $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t40, $r40;
                            let $t41, $r41;
                            ($t40 = $.$hDPm.LCFCI.ViewPresenterExtensions.CancelAll($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay), ($.$$.N.AsyncResolver.IsCompleted($t40, { set $v($v) { $r40 = $v; } }) ? $r40 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t40)));
                            ($t41 = this.RefreshProviders(), ($.$$.N.AsyncResolver.IsCompleted($t41, { set $v($v) { $r41 = $v; } }) ? $r41 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t41)));
                        });
                    }, $clPeVd ??= {"r":178454529,"n":"","d":1296108,"h":0,"f":17829890})));
                }, $fVzKkj ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":1296108,"h":0,"f":17825794}), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(266289268460)
            
            //--TRIMMABLE-BOUNDARY-START(244814431980)
            /*ValueTask */ Receive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814431980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$HSAN.LCPCS$1.PayCowryWalletReceive, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(244814431980)
            
            //--TRIMMABLE-BOUNDARY-START(330713777900)
            /*ValueTask */ Swap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713777900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.OfflinePaymentProvider === null)
                {
                    return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$HSAN.LCPCS$1.Error, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                    {
                        builder.AddAttribute$5(1, "Message", "Swap is disabled");
                        builder.AddAttribute$5(2, "Details", "This can happen if you are using PayCorwy in a browser. Use the mobile app instead!");
                    }, $muskRd ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":1296108,"h":0,"f":17825794}), null, null);
                }
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletSwap, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ b, /*i*/ i) =>
                {
                    b.AddAttribute$4(1, "Wallet1", this.OnlineWalletProvider);
                    b.AddAttribute$4(2, "Wallet2", this.OfflinePaymentProvider);
                    b.AddAttribute$7($.$SeJP.LCWCS$1.WalletSwapRequest, 3, "OnFinish", $.$mac.MAC.EventCallback.Factory.Create$10($.$SeJP.LCWCS$1.WalletSwapRequest, this, new ($.$$.S.Func$$$($.$SeJP.LCWCS$1.WalletSwapRequest, $.$$.STT.Task))().$ctor(this, /*async*/  (/*p*/ p) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t42, $r42;
                            let $t43, $r43;
                            ($t42 = this.DoSwap(p), ($.$$.N.AsyncResolver.IsCompleted($t42, { set $v($v) { $r42 = $v; } }) ? $r42 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t42)));
                            ($t43 = $.$hDPm.LCFCI.ViewPresenterExtensions.CancelAll($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay), ($.$$.N.AsyncResolver.IsCompleted($t43, { set $v($v) { $r43 = $v; } }) ? $r43 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t43)));
                        });
                    }, $FtIJjj ??= {"r":178454529,"p":[{"n":"p","p":2803463}],"n":"","d":1296108,"h":0,"f":17829890})));
                    b.AddAttribute$3(4, "Header", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*b*/ b) =>
                    {
                    }), $UsUJeb ??= {"r":65537,"p":[{"n":"b","p":7536755}],"n":"","d":1296108,"h":0,"f":17825794}));
                }, $HzHhGk ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":1296108,"h":0,"f":17825794}), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(330713777900)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(227634562796)
                this.OnlineWalletProvider = null;
                //--TRIMMABLE-BOUNDARY-END(227634562796)
                
            }
            static $h = 1296108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.ApplicationBaseService; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(184684889836),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605674732,
        "f": 50331649
      },
      "n": "MessagePipeFactory",
      "d": 1296108,
      "h": 184684889836,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684889836),
//--TRIMMABLE-BOUNDARY-START(339303712492),
    {
      "p": 23799126,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505020652,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418810604,
        "f": 83886082
      },
      "n": "User",
      "d": 1296108,
      "h": 339303712492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339303712492),
//--TRIMMABLE-BOUNDARY-START(180389922540),
    {
      "p": 3364499,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015740140,
        "f": 50331649
      },
      "n": "LocalDatabase",
      "d": 1296108,
      "h": 180389922540,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389922540),
//--TRIMMABLE-BOUNDARY-START(240519464684),
    {
      "p": 3298963,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325151468,
        "f": 50331649
      },
      "n": "Protector",
      "d": 1296108,
      "h": 240519464684,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519464684),
//--TRIMMABLE-BOUNDARY-START(227634562796),
    {
      "p": 1623815,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145282284,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238941420,
        "f": 83886082
      },
      "n": "OnlineWalletProvider",
      "d": 1296108,
      "h": 227634562796,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227634562796),
//--TRIMMABLE-BOUNDARY-START(206159726316),
    {
      "p": 1099500,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785543916,
        "f": 50331649
      },
      "n": "OfflinePaymentProvider",
      "d": 1296108,
      "h": 206159726316,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159726316),
//--TRIMMABLE-BOUNDARY-START(231929530092),
    {
      "p": 53578070,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735216876,
        "f": 50331649
      },
      "n": "Platform",
      "d": 1296108,
      "h": 231929530092,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231929530092),
//--TRIMMABLE-BOUNDARY-START(219044628204),
    {
      "p": 2971283,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965413100,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059072236,
        "f": 83886082
      },
      "n": "OnlineWalletInfo",
      "d": 1296108,
      "h": 219044628204,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044628204),
//--TRIMMABLE-BOUNDARY-START(210454693612),
    {
      "p": 2971283,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375478508,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283469137644,
        "f": 83886082
      },
      "n": "OfflineWalletInfo",
      "d": 1296108,
      "h": 210454693612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454693612),
//--TRIMMABLE-BOUNDARY-START(201864759020),
    {
      "p": 1595027,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195609324,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879203052,
        "f": 83886082
      },
      "n": "OfflineAccount",
      "d": 1296108,
      "h": 201864759020,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864759020),
//--TRIMMABLE-BOUNDARY-START(223339595500),
    {
      "p": 341468,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555347692,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649006828,
        "f": 83886082
      },
      "n": "OnlineWalletPipe",
      "d": 1296108,
      "h": 223339595500,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339595500),
//--TRIMMABLE-BOUNDARY-START(335008745196),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915086060,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828876012,
        "f": 83886081
      },
      "n": "UIKey",
      "d": 1296108,
      "h": 335008745196,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335008745196)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(249109399276),
    {
      "r": 181338113,
      "n": "RefreshProviders",
      "d": 1296108,
      "h": 249109399276,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(249109399276),
//--TRIMMABLE-BOUNDARY-START(193274824428),
    {
      "r": 65537,
      "p": [
        {
          "n": "transaction",
          "p": 2578067
        }
      ],
      "n": "NotifyNewTransaction",
      "d": 1296108,
      "h": 193274824428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274824428),
//--TRIMMABLE-BOUNDARY-START(197569791724),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h
        }
      ],
      "n": "NotifyTokensSent",
      "d": 1296108,
      "h": 197569791724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569791724),
//--TRIMMABLE-BOUNDARY-START(188979857132),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h
        }
      ],
      "n": "NotifyNewTokensReceived",
      "d": 1296108,
      "h": 188979857132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979857132),
//--TRIMMABLE-BOUNDARY-START(171799987948),
    {
      "r": 178454529,
      "n": "InitializeProviders",
      "d": 1296108,
      "h": 171799987948,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(171799987948),
//--TRIMMABLE-BOUNDARY-START(176094955244),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1296108,
      "h": 176094955244,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094955244),
//--TRIMMABLE-BOUNDARY-START(236224497388),
    {
      "r": 178454529,
      "p": [
        {
          "n": "accountFeature",
          "p": 677523
        },
        {
          "n": "user",
          "p": 23799126
        }
      ],
      "n": "PrepareDevice",
      "d": 1296108,
      "h": 236224497388,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(236224497388),
//--TRIMMABLE-BOUNDARY-START(64425805548),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": 2803463
        }
      ],
      "n": "DoSwap",
      "d": 1296108,
      "h": 64425805548,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(64425805548),
//--TRIMMABLE-BOUNDARY-START(253404366572),
    {
      "r": 181338113,
      "n": "Send",
      "d": 1296108,
      "h": 253404366572,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(253404366572),
//--TRIMMABLE-BOUNDARY-START(261994301164),
    {
      "r": 181338113,
      "n": "SendOnline",
      "d": 1296108,
      "h": 261994301164,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(261994301164),
//--TRIMMABLE-BOUNDARY-START(257699333868),
    {
      "r": 181338113,
      "n": "SendOffline",
      "d": 1296108,
      "h": 257699333868,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(257699333868),
//--TRIMMABLE-BOUNDARY-START(266289268460),
    {
      "r": 181338113,
      "n": "SendToBank",
      "d": 1296108,
      "h": 266289268460,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(266289268460),
//--TRIMMABLE-BOUNDARY-START(244814431980),
    {
      "r": 181338113,
      "n": "Receive",
      "d": 1296108,
      "h": 244814431980,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(244814431980),
//--TRIMMABLE-BOUNDARY-START(330713777900),
    {
      "r": 181338113,
      "n": "Swap",
      "d": 1296108,
      "h": 330713777900,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(330713777900)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130838252),
    {
      "t": 1558279,
      "n": "coinService",
      "d": 1296108,
      "h": 60130838252,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130838252),
//--TRIMMABLE-BOUNDARY-START(214749660908),
    {
      "t": 1165036,
      "n": "onlineIssuer",
      "d": 1296108,
      "h": 214749660908,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(214749660908)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835870956),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "protector",
          "p": 3298963
        },
        {
          "n": "connection",
          "p": 1896110
        },
        {
          "n": "messagePipeFactory",
          "p": 407004
        },
        {
          "n": "qrScanner",
          "p": 963789
        },
        {
          "n": "platform",
          "p": 53578070
        },
        {
          "n": "coinService",
          "p": 1558279
        },
        {
          "n": "onlineIssuer",
          "p": 1165036
        },
        {
          "n": "offlineIssuer",
          "p": 1033964
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1296108,
      "h": 55835870956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835870956)
  ],
  "h": 1296108
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$HSAN.LCPCS.PayCowryService.RemoteHolder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.PayCowryService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}PayCowryService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1296108)
        
        

        //--TRIMMABLE-BOUNDARY-START(1165036)
        $asm.$cls(`$HSAN.LCPCS.PayCowryOnlineCoinIssuer`, ($self) => class PayCowryOnlineCoinIssuer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42950837996)
            /*WalletFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(42950837996)
            
            //--TRIMMABLE-BOUNDARY-START(34360903404)
            /*string */ get CurrencyUnit()
            {
                return $.$$.S.String.ToString.call("\u20A6"/*Money.NairaSymbol*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34360903404)
            
            //--TRIMMABLE-BOUNDARY-START(21476001516)
            /*WalletTokenDescriptor[]?*/ coins = null;
            //--TRIMMABLE-BOUNDARY-END(21476001516)
            
            //--TRIMMABLE-BOUNDARY-START(17181034220)
            /*IEnumerable<WalletTokenDescriptor> */ get CoinDescriptors()
            {
                return this.coins ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OJJQ.LCFCW.WalletTokenDescriptor), [(() =>
                {
                    //new $.$OJJQ.LCFCW.WalletTokenDescriptor()
                    const $t1 = $.$OJJQ.LCFCW.WalletTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Name = `Wallet`;
                    $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit(`_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png`);
                    $i1.Description = `Online PayCowry`;
                    return $i1;
                })()], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17181034220)
            
            //--TRIMMABLE-BOUNDARY-START(128850183916)
            /*string? */ get Title()
            {
                return "PayCowry Wallet";
            }
            //--TRIMMABLE-BOUNDARY-END(128850183916)
            
            //--TRIMMABLE-BOUNDARY-START(38655870700)
            /*string? */ get Description()
            {
                return "Online Payment";
            }
            //--TRIMMABLE-BOUNDARY-END(38655870700)
            
            //--TRIMMABLE-BOUNDARY-START(115965282028)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png");
            }
            //--TRIMMABLE-BOUNDARY-END(115965282028)
            
            //--TRIMMABLE-BOUNDARY-START(120260249324)
            /*string? */ get Name()
            {
                return "PayCowry";
            }
            //--TRIMMABLE-BOUNDARY-END(120260249324)
            
            //--TRIMMABLE-BOUNDARY-START(124555216620)
            /*ThemePack? */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Primary);
            }
            //--TRIMMABLE-BOUNDARY-END(124555216620)
            
            //--TRIMMABLE-BOUNDARY-START(12886066924)
            /*bool */ CanPayForService(/*string?*/ serviceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886066924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12886066924)
            
            //--TRIMMABLE-BOUNDARY-START(30065936108)
            /*Money */ Convert$1(/*WalletToken*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065936108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$fPer.LCFCDM.Money().$ctor$3(input.Amount, 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(30065936108)
            
            //--TRIMMABLE-BOUNDARY-START(25770968812)
            /*WalletToken */ Convert(/*Money*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770968812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletToken()
                    const $t2 = $.$OJJQ.LCFCW.WalletToken;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Amount = input.Value;
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(25770968812)
            
            //--TRIMMABLE-BOUNDARY-START(34360374477)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CurrencyUnit.get
            get LCFCW$IWalletIssuer$CurrencyUnit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885537997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrencyUnit;
            }
            //--TRIMMABLE-BOUNDARY-END(34360374477)
            
            //--TRIMMABLE-BOUNDARY-START(25770439885)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CoinDescriptors.get
            get LCFCW$IWalletIssuer$CoinDescriptors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590570701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CoinDescriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(25770439885)
            
            //--TRIMMABLE-BOUNDARY-START(4295603405)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CanPayForService(string?)
            LCFCW$IWalletIssuer$CanPayForService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295603405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanPayForService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295603405)
            
            //--TRIMMABLE-BOUNDARY-START(42950309069)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.Features.get
            get LCFCW$IWalletIssuer$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180505293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(42950309069)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Wallet.WalletToken, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>.Convert(LivingThing.Core.Frameworks.Common.Wallet.WalletToken, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Data.Measurements.Money, LivingThing.Core.Frameworks.Common.Wallet.WalletToken>.Convert(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(8591099628)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591099628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591099628)
            
            //--TRIMMABLE-BOUNDARY-START(8591099628)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591099628)
            
            static $h = 1165036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950837996),
    {
      "p": 2667725,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310576364,
        "f": 50331649
      },
      "n": "Features",
      "d": 1165036,
      "h": 42950837996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950837996),
//--TRIMMABLE-BOUNDARY-START(34360903404),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130707180,
        "f": 50331649
      },
      "n": "CurrencyUnit",
      "d": 1165036,
      "h": 34360903404,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360903404),
//--TRIMMABLE-BOUNDARY-START(17181034220),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540772588,
        "f": 50331649
      },
      "n": "CoinDescriptors",
      "d": 1165036,
      "h": 17181034220,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181034220),
//--TRIMMABLE-BOUNDARY-START(128850183916),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670314732,
        "f": 50331649
      },
      "n": "Title",
      "d": 1165036,
      "h": 128850183916,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850183916),
//--TRIMMABLE-BOUNDARY-START(38655870700),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720641772,
        "f": 50331649
      },
      "n": "Description",
      "d": 1165036,
      "h": 38655870700,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655870700),
//--TRIMMABLE-BOUNDARY-START(115965282028),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900510956,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1165036,
      "h": 115965282028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965282028),
//--TRIMMABLE-BOUNDARY-START(120260249324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490445548,
        "f": 50331649
      },
      "n": "Name",
      "d": 1165036,
      "h": 120260249324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260249324),
//--TRIMMABLE-BOUNDARY-START(124555216620),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080380140,
        "f": 50331649
      },
      "n": "Theme",
      "d": 1165036,
      "h": 124555216620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555216620)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886066924),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "CanPayForService",
      "d": 1165036,
      "h": 12886066924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886066924),
//--TRIMMABLE-BOUNDARY-START(30065936108),
    {
      "r": 27822422,
      "p": [
        {
          "n": "input",
          "p": 3192013
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 1165036,
      "h": 30065936108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065936108),
//--TRIMMABLE-BOUNDARY-START(25770968812),
    {
      "r": 3192013,
      "p": [
        {
          "n": "input",
          "p": 27822422
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "d": 1165036,
      "h": 25770968812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770968812)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476001516),
    {
      "t": $.$typeArray($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "n": "coins",
      "d": 1165036,
      "h": 21476001516,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476001516)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591099628),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1165036,
      "h": 8591099628,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591099628)
  ],
  "h": 1165036
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletIssuer, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataConverter$$$($.$OJJQ.LCFCW.WalletToken, $.$fPer.LCFCDM.Money), $.$fPer.LCFCD.IDataConverter$$$($.$fPer.LCFCDM.Money, $.$OJJQ.LCFCW.WalletToken) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.PayCowryOnlineCoinIssuer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}PayCowryOnlineCoinIssuer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1165036)
        
        

        //--TRIMMABLE-BOUNDARY-START(1033964)
        $asm.$cls(`$HSAN.LCPCS.PayCowryOfflineCoinIssuer`, ($self) => class PayCowryOfflineCoinIssuer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655739628)
            /*WalletFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(38655739628)
            
            //--TRIMMABLE-BOUNDARY-START(30065805036)
            /*string */ get CurrencyUnit()
            {
                return $.$$.S.String.ToString.call("\u20A6"/*Money.NairaSymbol*/);
            }
            //--TRIMMABLE-BOUNDARY-END(30065805036)
            
            //--TRIMMABLE-BOUNDARY-START(17180903148)
            /*IEnumerable<WalletTokenDescriptor> */ get CoinDescriptors()
            {
                return $.$UlXD.LCPCM.PayCowryTokenModel.CoinDescriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(17180903148)
            
            //--TRIMMABLE-BOUNDARY-START(124555085548)
            /*string? */ get Title()
            {
                return "Cowry";
            }
            //--TRIMMABLE-BOUNDARY-END(124555085548)
            
            //--TRIMMABLE-BOUNDARY-START(34360772332)
            /*string? */ get Description()
            {
                return "Offline Payment";
            }
            //--TRIMMABLE-BOUNDARY-END(34360772332)
            
            //--TRIMMABLE-BOUNDARY-START(111670183660)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("_content/LivingThing.Core.PayCowry.Client.Blazor/cowry.png");
            }
            //--TRIMMABLE-BOUNDARY-END(111670183660)
            
            //--TRIMMABLE-BOUNDARY-START(115965150956)
            /*string? */ get Name()
            {
                return "PayCowry"/*PayCowryTokenModel.IssuerName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(115965150956)
            
            //--TRIMMABLE-BOUNDARY-START(120260118252)
            /*ThemePack? */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Primary);
            }
            //--TRIMMABLE-BOUNDARY-END(120260118252)
            
            //--TRIMMABLE-BOUNDARY-START(12885935852)
            /*bool */ CanPayForService(/*string?*/ serviceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885935852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(12885935852)
            
            //--TRIMMABLE-BOUNDARY-START(25770837740)
            /*Money */ Convert$1(/*WalletToken*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770837740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$fPer.LCFCDM.Money().$ctor$3(input.Amount, 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25770837740)
            
            //--TRIMMABLE-BOUNDARY-START(21475870444)
            /*WalletToken */ Convert(/*Money*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475870444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletToken()
                    const $t1 = $.$OJJQ.LCFCW.WalletToken;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Amount = input.Value;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(21475870444)
            
            //--TRIMMABLE-BOUNDARY-START(34360374477)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CurrencyUnit.get
            get LCFCW$IWalletIssuer$CurrencyUnit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885537997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrencyUnit;
            }
            //--TRIMMABLE-BOUNDARY-END(34360374477)
            
            //--TRIMMABLE-BOUNDARY-START(25770439885)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CoinDescriptors.get
            get LCFCW$IWalletIssuer$CoinDescriptors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590570701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CoinDescriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(25770439885)
            
            //--TRIMMABLE-BOUNDARY-START(4295603405)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CanPayForService(string?)
            LCFCW$IWalletIssuer$CanPayForService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295603405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanPayForService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295603405)
            
            //--TRIMMABLE-BOUNDARY-START(42950309069)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.Features.get
            get LCFCW$IWalletIssuer$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180505293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(42950309069)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Wallet.WalletToken, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>.Convert(LivingThing.Core.Frameworks.Common.Wallet.WalletToken, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Data.Measurements.Money, LivingThing.Core.Frameworks.Common.Wallet.WalletToken>.Convert(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(8590968556)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590968556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590968556)
            
            //--TRIMMABLE-BOUNDARY-START(8590968556)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590968556)
            
            static $h = 1033964;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655739628),
    {
      "p": 2667725,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015477996,
        "f": 50331649
      },
      "n": "Features",
      "d": 1033964,
      "h": 38655739628,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655739628),
//--TRIMMABLE-BOUNDARY-START(30065805036),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835608812,
        "f": 50331649
      },
      "n": "CurrencyUnit",
      "d": 1033964,
      "h": 30065805036,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065805036),
//--TRIMMABLE-BOUNDARY-START(17180903148),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245674220,
        "f": 50331649
      },
      "n": "CoinDescriptors",
      "d": 1033964,
      "h": 17180903148,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180903148),
//--TRIMMABLE-BOUNDARY-START(124555085548),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375216364,
        "f": 50331649
      },
      "n": "Title",
      "d": 1033964,
      "h": 124555085548,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555085548),
//--TRIMMABLE-BOUNDARY-START(34360772332),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425543404,
        "f": 50331649
      },
      "n": "Description",
      "d": 1033964,
      "h": 34360772332,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360772332),
//--TRIMMABLE-BOUNDARY-START(111670183660),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605412588,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1033964,
      "h": 111670183660,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670183660),
//--TRIMMABLE-BOUNDARY-START(115965150956),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195347180,
        "f": 50331649
      },
      "n": "Name",
      "d": 1033964,
      "h": 115965150956,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965150956),
//--TRIMMABLE-BOUNDARY-START(120260118252),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785281772,
        "f": 50331649
      },
      "n": "Theme",
      "d": 1033964,
      "h": 120260118252,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260118252)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885935852),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "CanPayForService",
      "d": 1033964,
      "h": 12885935852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885935852),
//--TRIMMABLE-BOUNDARY-START(25770837740),
    {
      "r": 27822422,
      "p": [
        {
          "n": "input",
          "p": 3192013
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 1033964,
      "h": 25770837740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770837740),
//--TRIMMABLE-BOUNDARY-START(21475870444),
    {
      "r": 3192013,
      "p": [
        {
          "n": "input",
          "p": 27822422
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "d": 1033964,
      "h": 21475870444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475870444)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590968556),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1033964,
      "h": 8590968556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590968556)
  ],
  "h": 1033964
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletIssuer, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataConverter$$$($.$OJJQ.LCFCW.WalletToken, $.$fPer.LCFCDM.Money), $.$fPer.LCFCD.IDataConverter$$$($.$fPer.LCFCDM.Money, $.$OJJQ.LCFCW.WalletToken) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Services.PayCowryOfflineCoinIssuer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Services${separator}PayCowryOfflineCoinIssuer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1033964)
        
        

        //--TRIMMABLE-BOUNDARY-START(1885932)
        $asm.$cls(`$HSAN.LCPCS$1.PayCowryHeader`, ($self) => class PayCowryHeader extends $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService)
        {
            //--TRIMMABLE-BOUNDARY-START(42951558892)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(42951558892)
            
            //--TRIMMABLE-BOUNDARY-START(38656591596)
            /*string */ get OptimizedComponentName()
            {
                return "paycowryheader";
            }
            //--TRIMMABLE-BOUNDARY-END(38656591596)
            
            //--TRIMMABLE-BOUNDARY-START(34361624300)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361624300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34361624300)
            
            //--TRIMMABLE-BOUNDARY-START(12886787820)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886787820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pdt-10 pdb-10 pdx-7 cl-white");
                __builder.AddAttribute$5(2, "style", "background:" + $.$strNN(($.$fPer.LCFC.Theme.Gradient$2(1/*ThemeGradientType.Radial*/, $.$fPer.LCFC.Theme.Secondary, $.$fPer.LCFC.Theme.Primary, 180, 100))));
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "flex");
                __builder.AddMarkupContent(5, "<i class=\"mdi mdi-account fsz-40 flex mgc-a bd round wx-05 hx-05\"></i>\r\n        ");
                __builder.OpenElement(6, "h3");
                __builder.AddAttribute$5(7, "class", "mgl mgy-a");
                __builder.AddContent$4(8, "Welcome ");
                __builder.AddContent$4(9, (this.ViewModel.OfflineAccount?.Title ?? null) ?? (this.ViewModel.User?.Title ?? null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n    ");
                __builder.AddMarkupContent(11, "<h3 class=\"text-center\">Account Balance</h3>\r\n    ");
                __builder.OpenElement(12, "div");
                __builder.AddAttribute$5(13, "class", "flex");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$5(15, "class", "wx-03 hx-03 mgy-a");
                __builder.OpenElement(16, "img");
                __builder.AddAttribute$5(17, "class", "mawf mahf");
                __builder.AddAttribute$5(18, "style", "transform: rotate(90deg);");
                __builder.AddAttribute$5(19, "src", this.ResolvePath("cowry-1.png", true, false, false));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(20, "\r\n        ");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$5(22, "class", "stack mgy-a mgl-2");
                __builder.AddMarkupContent(23, "<span cOnlineWallet\">\r\n                Offline Cowry\r\n            </span>\r\n            ");
                __builder.OpenElement(24, "span");
                __builder.AddAttribute$5(25, "class", "fw-bold fsz-20 lh-1");
                __builder.AddMarkupContent(26, "\r\n                \u20A6");
                /*LivingThing.Core.PayCowry.Common.Models.PayCowryWalletInfo?*/ let __ca1__;
                __builder.AddContent$4(27, ((__ca1__ = this.ViewModel.OfflineWalletInfo) !== null ? $.$$.S.Double.ToString$3.call(__ca1__.Balance, "#,##0.##") : null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(28, "\r\n        ");
                __builder.OpenElement(29, "div");
                __builder.AddAttribute$5(30, "class", "fill text-center flex cl-white");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 31, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.Swap)));
                __builder.AddMarkupContent(32, "<i class=\"mg-a fsz-25 mdi mdi-swap-horizontal bg-gray-05 hx-04 wx-04 flex mgc-a round\"></i>");
                __builder.CloseElement();
                __builder.AddMarkupContent(33, "\r\n        ");
                __builder.OpenElement(34, "a");
                __builder.AddAttribute$5(35, "class", "stack mgy-a mgl-2 cl-white");
                __builder.AddAttribute$5(36, "href", "PayCowry/Wallet");
                __builder.AddMarkupContent(37, "<span>\r\n                Online Wallet\r\n            </span>\r\n            ");
                __builder.OpenElement(38, "span");
                __builder.AddAttribute$5(39, "class", "fw-bold text-right fsz-20 lh-1");
                __builder.AddMarkupContent(40, "\r\n                \u20A6");
                /*LivingThing.Core.PayCowry.Common.Models.PayCowryWalletInfo?*/ let __ca2__;
                __builder.AddContent$4(41, ((__ca2__ = this.ViewModel.OnlineWalletInfo) !== null ? ($.$$.S.Double.ToString$3.call(__ca2__.Balance, "#,##0.##") ?? "----") : "----"));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(42, "\r\n        <i class=\"mdi mdi-wallet fsz-25 mgy-a\"></i>");
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12886787820)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591820524)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591820524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591820524)
            
            //--TRIMMABLE-BOUNDARY-START(8591820524)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8591820524)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42951558892)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(42951558892)
                
            }
            static $h = 1885932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951558892),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066657004,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541493484,
        "f": 83886081
      },
      "n": "Service",
      "d": 1885932,
      "h": 42951558892,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951558892),
//--TRIMMABLE-BOUNDARY-START(38656591596),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476722412,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1885932,
      "h": 38656591596,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38656591596)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361624300),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1885932,
      "h": 34361624300,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361624300),
//--TRIMMABLE-BOUNDARY-START(12886787820),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1885932,
      "h": 12886787820,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886787820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591820524),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1885932,
      "h": 8591820524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591820524)
  ],
  "h": 1885932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.PayCowryHeader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}PayCowryHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1885932)
        
        

        //--TRIMMABLE-BOUNDARY-START(2344684)
        $asm.$cls(`$HSAN.LCPCS$1.Swap`, ($self) => class Swap extends $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService)
        {
            //--TRIMMABLE-BOUNDARY-START(42952017644)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(42952017644)
            
            //--TRIMMABLE-BOUNDARY-START(38657050348)
            /*string */ get OptimizedComponentName()
            {
                return "swap";
            }
            //--TRIMMABLE-BOUNDARY-END(38657050348)
            
            //--TRIMMABLE-BOUNDARY-START(34362083052)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362083052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34362083052)
            
            //--TRIMMABLE-BOUNDARY-START(12887246572)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887246572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Service.OfflinePaymentProvider !== null)
                {
                    __builder.OpenComponent$1($.$SeJP.LCWCS$1.WalletSwap, 0);
                    __builder.AddComponentParameter(1, "Wallet1", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Service.OnlineWalletProvider));
                    __builder.AddComponentParameter(2, "Wallet2", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Service.OfflinePaymentProvider));
                    __builder.AddComponentParameter(3, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(4, "OnFinish", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$SeJP.LCWCS$1.WalletSwapRequest), $.$mac.MAC.EventCallback.Factory.Create$10($.$SeJP.LCWCS$1.WalletSwapRequest, this, new ($.$$.S.Func$$$($.$SeJP.LCWCS$1.WalletSwapRequest, $.$$.STT.Task))().$ctor(this.Service, this.Service.DoSwap))));
                    __builder.AddAttribute$3(5, "Header", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$HSAN.LCPCS$1.PayCowryHeader, 6);
                        __builder2.CloseComponent();
                    }), $JDHWjb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2344684,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$HSAN.LCPCS$1.Error, 7);
                    __builder.AddComponentParameter(8, "Message", "Swap is disabled");
                    __builder.AddComponentParameter(9, "Details", "This can happen if you are using PayCorwy in a browser. Use the mobile app instead!");
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887246572)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592279276)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592279276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592279276)
            
            //--TRIMMABLE-BOUNDARY-START(8592279276)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592279276)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42952017644)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(42952017644)
                
            }
            static $h = 2344684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952017644),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067115756,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541952236,
        "f": 83886081
      },
      "n": "Service",
      "d": 2344684,
      "h": 42952017644,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952017644),
//--TRIMMABLE-BOUNDARY-START(38657050348),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477181164,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2344684,
      "h": 38657050348,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657050348)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362083052),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2344684,
      "h": 34362083052,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362083052),
//--TRIMMABLE-BOUNDARY-START(12887246572),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2344684,
      "h": 12887246572,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887246572)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592279276),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2344684,
      "h": 8592279276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592279276)
  ],
  "h": 2344684
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Swap`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Swap`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2344684)
        
        

        //--TRIMMABLE-BOUNDARY-START(1689324)
        $asm.$cls(`$HSAN.LCPCS$1.Home`, ($self) => class Home extends $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService)
        {
            //--TRIMMABLE-BOUNDARY-START(77311100652)
            /*string */ get OptimizedComponentName()
            {
                return "home";
            }
            //--TRIMMABLE-BOUNDARY-END(77311100652)
            
            //--TRIMMABLE-BOUNDARY-START(68721166060)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721166060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
                this.PaymentTiers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider), serviceProvider);
                this.PaymentTierFactories = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProviderFactory), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68721166060)
            
            //--TRIMMABLE-BOUNDARY-START(94490969836)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(94490969836)
            
            //--TRIMMABLE-BOUNDARY-START(90196002540)
            /*IEnumerable<IPaymentTierProvider>*/ PaymentTiers = null;
            //--TRIMMABLE-BOUNDARY-END(90196002540)
            
            //--TRIMMABLE-BOUNDARY-START(81606067948)
            /*IEnumerable<IPaymentTierProviderFactory>*/ PaymentTierFactories = null;
            //--TRIMMABLE-BOUNDARY-END(81606067948)
            
            //--TRIMMABLE-BOUNDARY-START(85901035244)
            /*Pager<IPaymentTierProvider>? */ get paymentTiers()
            {
                return $.$fPer.LCFCD.Paging.Concat$1($.$nYKj.LCFCP.IPaymentTierProvider, $.$sl.SL.Enumerable.Concat($.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTierProvider), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTierProvider)), [$.$fPer.LCFCD.Paging.GetPager($.$nYKj.LCFCP.IPaymentTierProvider, this.PaymentTiers, null)], null, null), $.$sl.SL.Enumerable.Select$1($.$nYKj.LCFCP.IPaymentTierProviderFactory, $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTierProvider), this.PaymentTierFactories, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTierProviderFactory, $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTierProvider)))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$fPer.LCFCD.Paging.GetPager$3($.$nYKj.LCFCP.IPaymentTierProvider, p.LCFCP$IPaymentTierProviderFactory$GetProviders());
                }, $lVKWhd ??= {"r":$.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTierProvider).$h,"p":[{"n":"p","p":1132312}],"n":"","d":1689324,"h":0,"f":17825794}))));
            }
            //--TRIMMABLE-BOUNDARY-END(85901035244)
            
            //--TRIMMABLE-BOUNDARY-START(128850708204)
            /*WalletHome?*/ walletHome = null;
            //--TRIMMABLE-BOUNDARY-END(128850708204)
            
            //--TRIMMABLE-BOUNDARY-START(73016133356)
            /*Task *//*async*/  OnPaid(/*PaymentModel*/ payment)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016133356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let transaction;
                    if ($.$is(payment.PaidUsing, $.$OJJQ.LCFCW.UserWalletTransactionModel, { set $v($v){ transaction = $v; } }))
                    {
                        if ((this.walletHome?.TransactionsPager ?? null) !== null)
                        {
                            let $t1, $r1;
                            ($t1 = this.walletHome.TransactionsPager.DataManager.Prepend($.$$.SRC.RuntimeHelpers.CreateArray($.$OJJQ.LCFCW.UserWalletTransactionModel.$type, [ transaction ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73016133356)
            
            //--TRIMMABLE-BOUNDARY-START(21476525804)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476525804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$SeJP.LCWCS$1.WalletHome, 0);
                __builder.AddComponentParameter(1, "Wallet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Service.OfflinePaymentProvider ?? this.Service.OnlineWalletProvider));
                __builder.AddComponentParameter(2, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(3, "body-class", "pdb-20");
                __builder.AddAttribute$3(4, "Header", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$HSAN.LCPCS$1.PayCowryHeader, 5);
                    __builder2.CloseComponent();
                }), $ESeoGd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794}));
                __builder.AddAttribute$3(6, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(7, "div");
                    __builder2.AddAttribute$5(8, "class", "grid colm-3 gap-3 mgt-10 mgb-10");
                    __builder2.OpenElement(9, "div");
                    __builder2.AddAttribute$5(10, "class", "stack");
                    __builder2.AddMarkupContent(11, "<h3 class=\"mgt-0 mgb\">Transfer</h3>\r\n                ");
                    __builder2.OpenElement(12, "div");
                    __builder2.AddAttribute$5(13, "class", "bg-card pd flex flex-spacebetween fill corner");
                    __builder2.OpenElement(14, "div");
                    __builder2.OpenElement(15, "div");
                    __builder2.AddAttribute$5(16, "class", "pd corner-3 flex hx-05 wx-05 mgx-a mgy-1 clickable bg-primary-01");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 17, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.SendOffline)));
                    __builder2.AddMarkupContent(18, "<div class=\"wx-03 hx-03 mg-a flex\"><img class=\"mawf mahf mg-a\" src=\"/_content/LivingThing.Core.PayCowry.Client.Blazor/cowry-1.png\"></div>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(19, "\r\n                        ");
                    __builder2.AddMarkupContent(20, "<span class=\"mgt-2 d-block nowrap text-center fsz-12\">\r\n                            Pay<br>Cowry\r\n                        </span>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(21, "\r\n                    ");
                    __builder2.OpenElement(22, "div");
                    __builder2.OpenElement(23, "div");
                    __builder2.AddAttribute$5(24, "class", "pd corner-3 flex hx-05 wx-05 mgx-a mgy-1 clickable bg-primary-01");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 25, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.SendOnline)));
                    __builder2.AddMarkupContent(26, "<i class=\"mdi mdi-wallet cl-primary fsz-25 mg-a\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(27, "\r\n                        ");
                    __builder2.AddMarkupContent(28, "<span class=\"mgt-2 d-block nowrap text-center fsz-12\">\r\n                            Pay<br>Wallet\r\n                        </span>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(29, "\r\n                    ");
                    __builder2.OpenElement(30, "div");
                    __builder2.OpenElement(31, "div");
                    __builder2.AddAttribute$5(32, "class", "pd corner-3 flex hx-05 wx-05 mgx-a mgy-1 bg-primary-01");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 33, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.Swap)));
                    __builder2.AddMarkupContent(34, "<i class=\"mdi mdi-swap-horizontal cl-primary fsz-25 mg-a\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(35, "\r\n                        ");
                    __builder2.AddMarkupContent(36, "<span class=\"mgt-2 d-block nowrap text-center fsz-12\">\r\n                            Swap<br>Cowry\r\n                        </span>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(37, "\r\n                    ");
                    __builder2.OpenElement(38, "div");
                    __builder2.OpenElement(39, "div");
                    __builder2.AddAttribute$5(40, "class", "bg-secondary-01 pd corner-3 flex hx-05 wx-05 mgx-a mgy-1");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 41, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.SendToBank)));
                    __builder2.AddMarkupContent(42, "<i class=\"mdi mdi-bank cl-secondary fsz-25 mg-a\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(43, "\r\n                        ");
                    __builder2.AddMarkupContent(44, "<span class=\"mgt-2 d-block nowrap text-center fsz-12\">\r\n                            To<br>Bank\r\n                        </span>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.paymentTiers !== null)
                    {
                        __builder2.OpenElement(45, "div");
                        __builder2.AddAttribute$5(46, "class", "stack");
                        __builder2.OpenElement(47, "div");
                        __builder2.AddAttribute$5(48, "class", "fill mgb flex");
                        __builder2.AddMarkupContent(49, "<h3 class=\"mgy-a fill\">Pay for Services</h3>\r\n                        ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 50);
                        __builder2.AddComponentParameter(51, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(52, "drawer-class", "bg-card pd");
                        __builder2.AddAttribute$3(53, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(54, "\r\n                                More >>\r\n                            ");
                        }), $UzBvnk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(55, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$1(56, this.Services(this.paymentTiers));
                            }, $LbpeLk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794});
                        }), $wqHMse ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1689324,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(57, "\r\n                    ");
                        __builder2.OpenElement(58, "div");
                        __builder2.AddAttribute$5(59, "class", "bg-card pd corner");
                        __builder2.AddContent$1(60, this.Services($.$fPer.LCFCD.Paging.Take($.$nYKj.LCFCP.IPaymentTierProvider, this.paymentTiers, 12)));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                }), $twguIc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794}));
                __builder.SetKey($.$box(this.Service.UIKey, $.$$.S.Int32));
                __builder.AddComponentReferenceCapture(61, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.walletHome = $.$cast(__value, $.$SeJP.LCWCS$1.WalletHome);
                }, $CWaqxf ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1689324,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(62, "\r\n");
                __builder.OpenElement(63, "div");
                __builder.AddAttribute$5(64, "class", "flex pos-abs l-0 b-0 r-0 z-2 mgb-22");
                __builder.OpenElement(65, "div");
                __builder.AddAttribute$5(66, "class", "mgx-a");
                __builder.OpenElement(67, "popup");
                __builder.AddAttribute$5(68, "class", "pos-rel");
                __builder.AddMarkupContent(69, "<button class=\"mdi mdi-swap-horizontal bg-primary fsz-25 corner-5 miwx-06\"></button>\r\n            ");
                __builder.OpenElement(70, "pop");
                __builder.AddAttribute$5(71, "class", "at bottomtobottom centerx");
                __builder.OpenElement(72, "div");
                __builder.AddAttribute$5(73, "class", "flex");
                __builder.OpenElement(74, "button");
                __builder.AddAttribute$5(75, "class", "bg-primary corner-5 pdx-4 pdy-2 miwx-07");
                __builder.AddAttribute$5(76, "style", "position:relative;top:-30px;left:20px");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 77, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.Send)));
                __builder.AddMarkupContent(78, "\r\n                        Send\r\n                    ");
                __builder.CloseElement();
                __builder.AddMarkupContent(79, "\r\n                    <i class=\"mdi mdi-arrow-up-left\"></i>\r\n                    <div class=\"wx-06\"></div>\r\n                    <i class=\"mdi mdi-arrow-up-right\"></i>\r\n                    ");
                __builder.OpenElement(80, "button");
                __builder.AddAttribute$5(81, "class", "bg-primary corner-5 pdx-4 pdy-2 miwx-07");
                __builder.AddAttribute$5(82, "style", "position:relative;top:-30px;left:-20px");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 83, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.Service, this.Service.Receive)));
                __builder.AddMarkupContent(84, "\r\n                        Receive\r\n                    ");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21476525804)
            
            //--TRIMMABLE-BOUNDARY-START(98785937132)
            /*RenderFragment */ Services(/*Pager<IPaymentTierProvider>*/ paymentTiers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785937132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 85);
                    __builder2.AddAttribute$3(86, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*themable*/ themable) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$nYKj.LCFCP.IPaymentTierProvider), 87);
                            __builder3.AddComponentParameter(88, "ItemName", "Service");
                            __builder3.AddComponentParameter(89, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 70368744177664n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(90, "Pager", (paymentTiers));
                            __builder3.AddComponentParameter(91, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                            __builder3.AddComponentParameter(92, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                            __builder3.AddComponentParameter(93, "li-class", "text-center clip");
                            __builder3.AddAttribute$3(94, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$nYKj.LCFCP.IPaymentTierProvider))))().$ctor(this, ( (/*service*/ service) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    /*var*/ let theme = $.$fPer.LCFC.Theme.FirstOf($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeNullable($.$fPer.LCFC.Theme)), [ service.Model.LCFC$IDisplayable$Icon.Theme, (() =>
                                    {
                                        //new $.$fPer.LCFC.Theme()
                                        const $t2 = $.$fPer.LCFC.Theme;
                                        const $i2 = new $t2();
                                        $i2.$ctor$2();
                                        const $t3 = () => themable.Data.ChartColors;
                                        $i2.BackgroundColor = $.$ifnn($t3, ($t) => $.$$.System.Array.$ReadT1.call($t, service.Index % 11)) ?? "146752";
                                        $i2.ForegroundColor = "#FFFFFF";
                                        return $i2;
                                    })() ], null, null));
                                    theme = theme.WithBackground(theme.BackgroundColor !== null ? $.$strNN(theme.BackgroundColor) + "20" : null).WithForeground(theme.BackgroundColor);
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCI.Icon, 95);
                                    __builder4.AddComponentParameter(96, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$with(service.Model.LCFC$IDisplayable$Icon, ($clone) =>
                                    {
                                        $clone.Icon = service.Model.LCFC$IDisplayable$Icon.Icon ?? "mdi mdi-cash";
                                        $clone.Theme = $.$clone(theme);
                                    })));
                                    __builder4.AddComponentParameter(97, "Class", "fsz-20 pd corner-3 flex mgc-a hx-04 wx-04 mgx-a mgy-1");
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(98, "\r\n                ");
                                    __builder4.OpenElement(99, "small");
                                    __builder4.AddAttribute$5(100, "class", "mgt-2 d-block");
                                    __builder4.AddContent$4(101, service.Model.LCFC$IDisplayable$Title);
                                    __builder4.CloseElement();
                                }, $jLQnyc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794});
                            }), $SKtMUf ??= {"r":6881395,"p":[{"n":"service","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$nYKj.LCFCP.IPaymentTierProvider)).$h}],"n":"","d":1689324,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(102, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$nYKj.LCFCP.IPaymentTierProvider))))().$ctor(this, ( (/*item*/ item) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.OpenElement(103, "div");
                                    __builder4.AddAttribute$5(104, "class", "pd bg-card");
                                    __builder4.OpenComponent$1($.$cnlM.LCBCS$1.BillChooseServiceTier, 105);
                                    __builder4.AddComponentParameter(106, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$nYKj.LCFCP.IPaymentTierProvider, item.Data));
                                    __builder4.AddComponentParameter(107, "Customer", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCC$2.IContact, this.Service.OnlineWalletProvider.Holder));
                                    __builder4.AddComponentParameter(108, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder4.AddComponentParameter(109, "OnPaid", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$Iaui.LCFCM.PaymentModel, this, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.STT.Task))().$ctor(this, this.OnPaid))));
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                }, $DynlYe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794});
                            }), $qwJqxk ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$nYKj.LCFCP.IPaymentTierProvider)).$h}],"n":"","d":1689324,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $rjTdGf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794});
                    }), $zKNkDa ??= {"r":6881395,"p":[{"n":"themable","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":1689324,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $VknqEe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1689324,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(98785937132)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181558508)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181558508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181558508)
            
            //--TRIMMABLE-BOUNDARY-START(17181558508)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17181558508)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94490969836)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(94490969836)
                
                //--TRIMMABLE-BOUNDARY-START(90196002540)
                this.PaymentTiers = null;
                //--TRIMMABLE-BOUNDARY-END(90196002540)
                
                //--TRIMMABLE-BOUNDARY-START(81606067948)
                this.PaymentTierFactories = null;
                //--TRIMMABLE-BOUNDARY-END(81606067948)
                
            }
            static $h = 1689324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311100652),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066460396,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1689324,
      "h": 77311100652,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77311100652),
//--TRIMMABLE-BOUNDARY-START(94490969836),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426198764,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555740908,
        "f": 83886081
      },
      "n": "Service",
      "d": 1689324,
      "h": 94490969836,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490969836),
//--TRIMMABLE-BOUNDARY-START(90196002540),
    {
      "p": $.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836264172,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965806316,
        "f": 83886081
      },
      "n": "PaymentTiers",
      "d": 1689324,
      "h": 90196002540,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90196002540),
//--TRIMMABLE-BOUNDARY-START(81606067948),
    {
      "p": $.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProviderFactory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656394988,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375871724,
        "f": 83886081
      },
      "n": "PaymentTierFactories",
      "d": 1689324,
      "h": 81606067948,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606067948),
//--TRIMMABLE-BOUNDARY-START(85901035244),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTierProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246329580,
        "f": 50331650
      },
      "n": "paymentTiers",
      "d": 1689324,
      "h": 85901035244,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85901035244)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721166060),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1689324,
      "h": 68721166060,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721166060),
//--TRIMMABLE-BOUNDARY-START(73016133356),
    {
      "r": 178454529,
      "p": [
        {
          "n": "payment",
          "p": 12592470
        }
      ],
      "n": "OnPaid",
      "d": 1689324,
      "h": 73016133356,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73016133356),
//--TRIMMABLE-BOUNDARY-START(21476525804),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1689324,
      "h": 21476525804,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476525804),
//--TRIMMABLE-BOUNDARY-START(98785937132),
    {
      "r": 6881395,
      "p": [
        {
          "n": "paymentTiers",
          "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTierProvider).$h
        }
      ],
      "n": "Services",
      "d": 1689324,
      "h": 98785937132,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98785937132)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128850708204),
    {
      "t": 2148103,
      "n": "walletHome",
      "d": 1689324,
      "h": 128850708204,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128850708204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181558508),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1689324,
      "h": 17181558508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181558508)
  ],
  "h": 1689324
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Home`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Home`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1689324)
        
        

        //--TRIMMABLE-BOUNDARY-START(2475756)
        $asm.$cls(`$HSAN.LCPCS$1.Wallet`, ($self) => class Wallet extends $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService)
        {
            //--TRIMMABLE-BOUNDARY-START(85901821676)
            /*PayCowryService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(85901821676)
            
            //--TRIMMABLE-BOUNDARY-START(25772279532)
            /*IClipboardAccessor*/ Clipboard = null;
            //--TRIMMABLE-BOUNDARY-END(25772279532)
            
            //--TRIMMABLE-BOUNDARY-START(120261560044)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(120261560044)
            
            //--TRIMMABLE-BOUNDARY-START(30067246828)
            /*ValueTask *//*async*/  CopyAddress()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067246828);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Clipboard.LCFCC$IClipboardAccessor$SetAsync($.$OJJQ.LCFCW.WalletAddress.op_Implicit(this.Service.OfflineAccount.NetworkAddress)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.Toast($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPage, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Address copied to clipboard", false), null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30067246828)
            
            //--TRIMMABLE-BOUNDARY-START(115966592748)
            /*Pager<IWalletTransaction> */ get Transactions()
            {
                return this.Service.OnlineWalletProvider.RecentTransactions;
            }
            //--TRIMMABLE-BOUNDARY-END(115966592748)
            
            //--TRIMMABLE-BOUNDARY-START(21477312236)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477312236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$SeJP.LCWCS$1.WalletIO, 0);
                __builder.AddComponentParameter(1, "Wallet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Service.OnlineWalletProvider));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21477312236)
            
            //--TRIMMABLE-BOUNDARY-START(81606854380)
            /*string */ get OptimizedComponentName()
            {
                return "wallet";
            }
            //--TRIMMABLE-BOUNDARY-END(81606854380)
            
            //--TRIMMABLE-BOUNDARY-START(77311887084)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311887084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HSAN.LCPCS.PayCowryService, serviceProvider);
                this.Clipboard = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IClipboardAccessor, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(77311887084)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17182344940)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182344940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182344940)
            
            //--TRIMMABLE-BOUNDARY-START(17182344940)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17182344940)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85901821676)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(85901821676)
                
                //--TRIMMABLE-BOUNDARY-START(25772279532)
                this.Clipboard = null;
                //--TRIMMABLE-BOUNDARY-END(25772279532)
                
                //--TRIMMABLE-BOUNDARY-START(120261560044)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(120261560044)
                
            }
            static $h = 2475756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseInjectedComponent$$($.$HSAN.LCPCS.PayCowryService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85901821676),
    {
      "p": 1296108,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837050604,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081690860,
        "f": 83886081
      },
      "n": "Service",
      "d": 2475756,
      "h": 85901821676,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85901821676),
//--TRIMMABLE-BOUNDARY-START(25772279532),
    {
      "p": 2776488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657181420,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491756268,
        "f": 83886081
      },
      "n": "Clipboard",
      "d": 2475756,
      "h": 25772279532,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772279532),
//--TRIMMABLE-BOUNDARY-START(120261560044),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016919788,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671625452,
        "f": 83886081
      },
      "n": "UI",
      "d": 2475756,
      "h": 120261560044,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261560044),
//--TRIMMABLE-BOUNDARY-START(115966592748),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$OJJQ.LCFCW.IWalletTransaction).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426985196,
        "f": 50331650
      },
      "n": "Transactions",
      "d": 2475756,
      "h": 115966592748,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(115966592748),
//--TRIMMABLE-BOUNDARY-START(81606854380),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247116012,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2475756,
      "h": 81606854380,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81606854380)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067246828),
    {
      "r": 181338113,
      "n": "CopyAddress",
      "d": 2475756,
      "h": 30067246828,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(30067246828),
//--TRIMMABLE-BOUNDARY-START(21477312236),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2475756,
      "h": 21477312236,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21477312236),
//--TRIMMABLE-BOUNDARY-START(77311887084),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2475756,
      "h": 77311887084,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311887084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182344940),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2475756,
      "h": 17182344940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182344940)
  ],
  "h": 2475756
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Client.Shared.Wallet`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Client${separator}Shared${separator}Wallet`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2475756)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Bcl.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.System.IdentityModel.Tokens.Jwt", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.PayCowry.Common", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(50924)
