
//--TRIMMABLE-BOUNDARY-START(22163)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $OJJQ) {
    "use strict";
    let _;
    let $EugiIi;
    let $YJBcMj;
    let $vxiijg;
    let $Eavlbb;
    let $IUBdLf;
    let $ejPcqi;
    let $BmpXgd;
    let $tXfZuk;
    let $DjhZYd;
    let $ArQDgh;
    let $IAvcpe;
    let $VlElif;
    let $JrMGck;
    let $GVtYZj;
    let $kdpyja;
    let $nNamCe;
    let $MINUNe;
    let $OZUTxd;
    let $ebBIyj;
    let $PHNZoa;
    let $DtnROd;
    let $eGObQb;
    let $CpzcXf;
    let $fBKBmk;
    let $eulVqh;
    let $QoFDKa;
    let $EMNftb;
    let $ZXwruj;
    let $cqUTZf;
    let $cZwBak;
    let $hKWksj;
    let $LRQToe;
    let $JgmnEd;
    let $wEFwke;
    let $Hbgiuc;
    let $iDzjRd;
    let $mVJPbg;
    let $xxPJBe;
    let $RAkAxc;
    let $kaYrjd;
    let $VzGMPc;
    let $FspgIj;
    let $Nmgujj;
    let $ikEsnc;
    let $AvjGhf;
    let $DrraQi;
    let $nnVeCb;
    let $qAqtug;
    let $CLUWVj;
    let $sdphlg;
    let $kLOfFd;
    let $NmUoVb;
    let $wfQuLg;
    let $qqyTqk;
    let $vVKfPa;
    let $doyotf;
    let $RgsJIj;
    let $YMfPIi;
    let $TpNkWj;
    let $FVzyee;
    let $VAVNTh;
    let $MkXDKc;
    let $AcgzBc;
    let $vuTzsf;
    let $tpACak;
    let $CCoMPi;
    let $oQYzTe;
    let $mgTqnd;
    let $QzojFd;
    let $Nijvbj;
    let $TlUHFc;
    let $IWnrmc;
    let $kDIVnf;
    let $lCMwYg;
    let $Wpcplh;
    let $biIDhf;
    let $OvmAyd;
    let $FsxONh;
    let $mtAIqk;
    let $axnfYb;
    let $Uwghxj;
    let $BRDfXi;
    let $LvmUbd;
    let $ldQdef;
    let $TdvWCb;
    let $GDKhki;
    let $TltVtb;
    let $kesZue;
    let $DAwZAc;
    let $UVsude;
    let $BWFXMj;
    let $XMtnBf;
    let $qeyxHb;
    let $gDoQpi;
    let $keGhyk;
    let $kNAxWk;
    let $kWUsEh;
    let $iloENd;
    let $mOwhzf;
    let $ndnFqd;
    let $pIoZVe;
    let $UaciMd;
    let $GWjsvg;
    let $fMkKHh;
    let $bqfFpg;
    let $asLZXd;
    let $PGujJi;
    let $yYFGCf;
    let $FjTcNa;
    let $ExfKwd;
    let $dSRuaa;
    let $VDIsuh;
    let $rLBmRf;
    let $Orlwyh;
    let $RAziCf;
    let $wBLlNa;
    let $ZRHyMi;
    let $vYGjVe;
    let $dnqijj;
    let $MWzbyk;
    let $EjYcqh;
    let $GIISYa;
    let $mWvGOb;
    let $LrneXf;
    let $NRhfIk;
    let $PKbTvk;
    let $xNoYLh;
    let $xEJOOg;
    let $vrnHNf;
    let $xOaRYc;
    let $vwYJXd;
    let $xaQFUc;
    let $TmJEfd;
    let $JeSSUe;
    let $DwEgka;
    let $EIlWPg;
    let $dHrLzb;
    let $ytojSf;
    let $hxZVYa;
    let $jhMIGg;
    let $WoqcTb;
    let $YhNDVj;
    let $cFEWBh;
    let $rUKjgf;
    let $aIojHd;
    let $SUpuyi;
    let $YbqInd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.PayCowry.Common", 
    {
  "h": 22163,
  "f": "LivingThing.Core.PayCowry.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.PayCowry.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.PayCowry.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(611987)
        $asm.$cls(`$UlXD.LCPCM.IProtectedData`, ($self) => class IProtectedData
        {
            static $h = 611987;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770415763),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180481171,
        "f": 50331905
      },
      "n": "ProtectionData",
      "o": "LCPCM$IProtectedData$ProtectionData",
      "d": 611987,
      "h": 25770415763,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770415763),
//--TRIMMABLE-BOUNDARY-START(21475448467),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590546579,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360350355,
        "f": 83886337
      },
      "n": "Protection",
      "o": "LCPCM$IProtectedData$Protection",
      "d": 611987,
      "h": 21475448467,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475448467)
  ],
  "h": 611987
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.IProtectedData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}IProtectedData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(611987)
        
        

        //--TRIMMABLE-BOUNDARY-START(3298963)
        $asm.$cls(`$UlXD.LCPCS.IDataProtector`, ($self) => class IDataProtector
        {
            static $h = 3298963;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298266259),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": 611987
        }
      ],
      "n": "Protect",
      "o": "LCPCS$IDataProtector$Protect",
      "d": 3298963,
      "h": 4298266259,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298266259),
//--TRIMMABLE-BOUNDARY-START(17183168147),
    {
      "r": 262145,
      "p": [
        {
          "n": "data",
          "p": 611987
        },
        {
          "n": "protect2",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Validate",
      "o": "LCPCS$IDataProtector$Validate",
      "d": 3298963,
      "h": 17183168147,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17183168147),
//--TRIMMABLE-BOUNDARY-START(12888200851),
    {
      "r": 2798797,
      "p": [
        {
          "n": "data",
          "p": 1310721
        }
      ],
      "n": "ProtectPin",
      "o": "LCPCS$IDataProtector$ProtectPin",
      "d": 3298963,
      "h": 12888200851,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12888200851),
//--TRIMMABLE-BOUNDARY-START(21478135443),
    {
      "r": 262145,
      "p": [
        {
          "n": "data",
          "p": 1310721
        },
        {
          "n": "hash",
          "p": 2798797
        }
      ],
      "n": "ValidatePin",
      "o": "LCPCS$IDataProtector$ValidatePin",
      "d": 3298963,
      "h": 21478135443,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21478135443),
//--TRIMMABLE-BOUNDARY-START(8593233555),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "key",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ProtectKey",
      "o": "LCPCS$IDataProtector$ProtectKey",
      "d": 3298963,
      "h": 8593233555,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593233555)
  ],
  "h": 3298963
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.IDataProtector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}IDataProtector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3298963)
        
        

        //--TRIMMABLE-BOUNDARY-START(3364499)
        $asm.$cls(`$UlXD.LCPCS.ILocalDatabase`, ($self) => class ILocalDatabase
        {
            static $h = 3364499;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363102867),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183233683,
        "f": 50331905
      },
      "n": "IsInitialized",
      "o": "LCPCS$ILocalDatabase$IsInitialized",
      "d": 3364499,
      "h": 34363102867,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34363102867)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38658070163),
    {
      "r": $.$$.STT.ValueTask$$($.$UlXD.LCPCM.PayCowryOfflineAccountModel).$h,
      "n": "Load",
      "o": "LCPCS$ILocalDatabase$Load",
      "d": 3364499,
      "h": 38658070163,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38658070163),
//--TRIMMABLE-BOUNDARY-START(30068135571),
    {
      "r": 181338113,
      "p": [
        {
          "n": "account",
          "p": 677523
        },
        {
          "n": "user",
          "p": 23799126
        }
      ],
      "n": "Initialize",
      "o": "LCPCS$ILocalDatabase$Initialize",
      "d": 3364499,
      "h": 30068135571,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30068135571),
//--TRIMMABLE-BOUNDARY-START(21478200979),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetTokensAsync",
      "o": "LCPCS$ILocalDatabase$GetTokensAsync",
      "d": 3364499,
      "h": 21478200979,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21478200979),
//--TRIMMABLE-BOUNDARY-START(25773168275),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$UlXD.LCPCM.PayCowryTransactionModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetTransactionsAsync",
      "o": "LCPCS$ILocalDatabase$GetTransactionsAsync",
      "d": 3364499,
      "h": 25773168275,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25773168275),
//--TRIMMABLE-BOUNDARY-START(8593299091),
    {
      "r": $.$$.STT.Task$$($.$UlXD.LCPCS.TokenExchangeContext).$h,
      "p": [
        {
          "n": "amount",
          "p": 655361
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32).$h
        },
        {
          "n": "receiver",
          "p": 2471117
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "BeginTokenTransfer",
      "o": "LCPCS$ILocalDatabase$BeginTokenTransfer",
      "d": 3364499,
      "h": 8593299091,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593299091),
//--TRIMMABLE-BOUNDARY-START(42953037459),
    {
      "r": $.$$.STT.Task$$($.$UlXD.LCPCM.PayCowryTransactionModel).$h,
      "p": [
        {
          "n": "sender",
          "p": 2471117
        },
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "ReceiveTokens",
      "o": "LCPCS$ILocalDatabase$ReceiveTokens",
      "d": 3364499,
      "h": 42953037459,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42953037459),
//--TRIMMABLE-BOUNDARY-START(47248004755),
    {
      "r": 178454529,
      "p": [
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h
        }
      ],
      "n": "SynchTokensFromServer",
      "o": "LCPCS$ILocalDatabase$SynchTokensFromServer",
      "d": 3364499,
      "h": 47248004755,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47248004755),
//--TRIMMABLE-BOUNDARY-START(4298331795),
    {
      "r": 178454529,
      "n": "BackupToServer",
      "o": "LCPCS$ILocalDatabase$BackupToServer",
      "d": 3364499,
      "h": 4298331795,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298331795)
  ],
  "h": 3364499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.ILocalDatabase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}ILocalDatabase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3364499)
        
        

        //--TRIMMABLE-BOUNDARY-START(546451)
        $asm.$cls(`$UlXD.LCPCM.IDoubleProtectedData`, ($self) => class IDoubleProtectedData
        {
            static $h = 546451;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770350227),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180415635,
        "f": 50331905
      },
      "n": "ProtectionData2",
      "o": "LCPCM$IDoubleProtectedData$ProtectionData2",
      "d": 546451,
      "h": 25770350227,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770350227),
//--TRIMMABLE-BOUNDARY-START(21475382931),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590481043,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360284819,
        "f": 83886337
      },
      "n": "Protection2",
      "o": "LCPCM$IDoubleProtectedData$Protection2",
      "d": 546451,
      "h": 21475382931,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475382931)
  ],
  "h": 546451
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UlXD.LCPCM.IProtectedData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.IDoubleProtectedData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}IDoubleProtectedData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(546451)
        
        

        //--TRIMMABLE-BOUNDARY-START(3430035)
        $asm.$cls(`$UlXD.LCPCS.IPayCowryAccountRemoteService`, ($self) => class IPayCowryAccountRemoteService
        {
            static $h = 3430035;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298397331),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)).$h,
      "p": [
        {
          "n": "email",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        }
      ],
      "n": "Login",
      "o": "LCPCS$IPayCowryAccountRemoteService$Login",
      "d": 3430035,
      "h": 4298397331,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298397331),
//--TRIMMABLE-BOUNDARY-START(8593364627),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)).$h,
      "p": [
        {
          "n": "email",
          "p": 1310721
        },
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "user",
          "p": 23799126
        }
      ],
      "n": "Register",
      "o": "LCPCS$IPayCowryAccountRemoteService$Register",
      "d": 3430035,
      "h": 8593364627,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593364627)
  ],
  "h": 3430035,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.IPayCowryAccountRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}IPayCowryAccountRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3430035)
        
        

        //--TRIMMABLE-BOUNDARY-START(3561107)
        $asm.$cls(`$UlXD.LCPCS.IPayCowryRemoteService`, ($self) => class IPayCowryRemoteService
        {
            static $h = 3561107;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30068332179),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,
      "p": [
        {
          "n": "sender",
          "p": 1595027
        },
        {
          "n": "recipient",
          "p": 1595027
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "pinCode",
          "p": 1310721
        }
      ],
      "n": "Transfer",
      "o": "LCPCS$IPayCowryRemoteService$Transfer",
      "d": 3561107,
      "h": 30068332179,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30068332179),
//--TRIMMABLE-BOUNDARY-START(8593495699),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel)).$h,
      "p": [
        {
          "n": "transactionId",
          "p": 1310721
        },
        {
          "n": "account",
          "p": 1595027
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32).$h
        },
        {
          "n": "password",
          "p": 1310721
        }
      ],
      "n": "BuyTokens",
      "o": "LCPCS$IPayCowryRemoteService$BuyTokens",
      "d": 3561107,
      "h": 8593495699,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593495699),
//--TRIMMABLE-BOUNDARY-START(25773364883),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "transactionId",
          "p": 1310721
        },
        {
          "n": "account",
          "p": 1595027
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h
        }
      ],
      "n": "SellTokens",
      "o": "LCPCS$IPayCowryRemoteService$SellTokens",
      "d": 3561107,
      "h": 25773364883,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25773364883),
//--TRIMMABLE-BOUNDARY-START(21478397587),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel)).$h,
      "p": [
        {
          "n": "account",
          "p": 1595027
        },
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetTokens",
      "o": "LCPCS$IPayCowryRemoteService$GetTokens",
      "d": 3561107,
      "h": 21478397587,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21478397587),
//--TRIMMABLE-BOUNDARY-START(4298528403),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)).$h,
      "p": [
        {
          "n": "account",
          "p": 1595027
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "bankAccount",
          "p": 5474646
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "BankTransfer",
      "o": "LCPCS$IPayCowryRemoteService$BankTransfer",
      "d": 3561107,
      "h": 4298528403,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298528403),
//--TRIMMABLE-BOUNDARY-START(17183430291),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.PaymentModel)).$h,
      "p": [
        {
          "n": "date",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": "GetSpinWheelParticipants",
      "o": "LCPCS$IPayCowryRemoteService$GetSpinWheelParticipants",
      "d": 3561107,
      "h": 17183430291,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17183430291),
//--TRIMMABLE-BOUNDARY-START(12888462995),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.String)).$h,
      "p": [
        {
          "n": "mAddress",
          "p": 1310721
        }
      ],
      "n": "GetBackups",
      "o": "LCPCS$IPayCowryRemoteService$GetBackups",
      "d": 3561107,
      "h": 12888462995,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12888462995)
  ],
  "h": 3561107,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.IPayCowryRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}IPayCowryRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3561107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1332883)
        $asm.$cls(`$UlXD.LCPCM.PayCowryLedgerModel`, ($self) => class PayCowryLedgerModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425842323)
            /*double*/ LastKnownWalletBalance = 0;
            //--TRIMMABLE-BOUNDARY-END(64425842323)
            
            //--TRIMMABLE-BOUNDARY-START(25771136659)
            /*IEnumerable<PayCowryDenominationModel>?*/ Denominations = null;
            //--TRIMMABLE-BOUNDARY-END(25771136659)
            
            //--TRIMMABLE-BOUNDARY-START(103080547987)
            /*IEnumerable<PayCowryTokenModel>?*/ Tokens = null;
            //--TRIMMABLE-BOUNDARY-END(103080547987)
            
            //--TRIMMABLE-BOUNDARY-START(107375515283)
            /*IEnumerable<PayCowryTransactionModel>?*/ Transactions = null;
            //--TRIMMABLE-BOUNDARY-END(107375515283)
            
            //--TRIMMABLE-BOUNDARY-START(21476169363)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476169363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476169363)
            
            //--TRIMMABLE-BOUNDARY-START(21476169363)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476169363)
            
            static $h = 1332883;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425842323),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951005843,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605711507,
        "f": 83886081
      },
      "n": "LastKnownWalletBalance",
      "d": 1332883,
      "h": 64425842323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425842323),
//--TRIMMABLE-BOUNDARY-START(25771136659),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361071251,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015776915,
        "f": 83886081
      },
      "n": "Denominations",
      "d": 1332883,
      "h": 25771136659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771136659),
//--TRIMMABLE-BOUNDARY-START(103080547987),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540940435,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195646099,
        "f": 83886081
      },
      "n": "Tokens",
      "d": 1332883,
      "h": 103080547987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080547987),
//--TRIMMABLE-BOUNDARY-START(107375515283),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130875027,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785580691,
        "f": 83886081
      },
      "n": "Transactions",
      "d": 1332883,
      "h": 107375515283,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375515283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476169363),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1332883,
      "h": 21476169363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476169363)
  ],
  "h": 1332883
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryLedgerModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1332883)
        
        

        //--TRIMMABLE-BOUNDARY-START(1857171)
        $asm.$cls(`$UlXD.LCPCM.PayCowryStorageModel`, ($self) => class PayCowryStorageModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181726355)
            /*PayCowryAccountFeatureModel?*/ Account = null;
            //--TRIMMABLE-BOUNDARY-END(17181726355)
            
            //--TRIMMABLE-BOUNDARY-START(38656562835)
            /*PayCowryLedgerModel?*/ Ledger = null;
            //--TRIMMABLE-BOUNDARY-END(38656562835)
            
            //--TRIMMABLE-BOUNDARY-START(12886759059)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886759059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886759059)
            
            //--TRIMMABLE-BOUNDARY-START(12886759059)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886759059)
            
            static $h = 1857171;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181726355),
    {
      "p": 677523,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771660947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246497427,
        "f": 83886081
      },
      "n": "Account",
      "d": 1857171,
      "h": 17181726355,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181726355),
//--TRIMMABLE-BOUNDARY-START(38656562835),
    {
      "p": 1332883,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361595539,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836432019,
        "f": 83886081
      },
      "n": "Ledger",
      "d": 1857171,
      "h": 38656562835,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656562835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886759059),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1857171,
      "h": 12886759059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886759059)
  ],
  "h": 1857171
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryStorageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1857171)
        
        

        //--TRIMMABLE-BOUNDARY-START(3036819)
        $asm.$cls(`$UlXD.LCPC.PayCowryConstants`, ($self) => class PayCowryConstants
        {
            //--TRIMMABLE-BOUNDARY-START(12887938707)
            /*int*/ static SpinWheelHour = 18;
            //--TRIMMABLE-BOUNDARY-END(12887938707)
            
            //--TRIMMABLE-BOUNDARY-START(8592971411)
            /*string*/ static SpinWheelCronTimeString = null;
            //--TRIMMABLE-BOUNDARY-END(8592971411)
            
            //--TRIMMABLE-BOUNDARY-START(4298004115)
            /*string*/ static SpinWheelCronReminderTimeString = null;
            //--TRIMMABLE-BOUNDARY-END(4298004115)
            
            //--TRIMMABLE-BOUNDARY-START(17182906003)
            /*string*/ static SpinWheelWinnerPropertyPrefix = null;
            //--TRIMMABLE-BOUNDARY-END(17182906003)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8592971411)
                    this.SpinWheelCronTimeString = "0 18 * * *";
                    //--TRIMMABLE-BOUNDARY-END(8592971411)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4298004115)
                    this.SpinWheelCronReminderTimeString = "55 17 * * *";
                    //--TRIMMABLE-BOUNDARY-END(4298004115)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17182906003)
                    this.SpinWheelWinnerPropertyPrefix = "PayCowry/Wallet/SpinWheel";
                    //--TRIMMABLE-BOUNDARY-END(17182906003)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3036819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887938707),
    {
      "t": 655361,
      "n": "SpinWheelHour",
      "d": 3036819,
      "h": 12887938707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887938707),
//--TRIMMABLE-BOUNDARY-START(8592971411),
    {
      "t": 1310721,
      "n": "SpinWheelCronTimeString",
      "d": 3036819,
      "h": 8592971411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592971411),
//--TRIMMABLE-BOUNDARY-START(4298004115),
    {
      "t": 1310721,
      "n": "SpinWheelCronReminderTimeString",
      "d": 3036819,
      "h": 4298004115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4298004115),
//--TRIMMABLE-BOUNDARY-START(17182906003),
    {
      "t": 1310721,
      "n": "SpinWheelWinnerPropertyPrefix",
      "d": 3036819,
      "h": 17182906003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182906003)
  ],
  "h": 3036819
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.PayCowryConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}PayCowryConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3036819)
        
        

        //--TRIMMABLE-BOUNDARY-START(2971283)
        $asm.$cls(`$UlXD.LCPCM.PayCowryWalletInfo`, ($self) => class PayCowryWalletInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067742355)
            /*string?*/ BankName = null;
            //--TRIMMABLE-BOUNDARY-END(30067742355)
            
            //--TRIMMABLE-BOUNDARY-START(21477807763)
            /*string?*/ AccountNumber = null;
            //--TRIMMABLE-BOUNDARY-END(21477807763)
            
            //--TRIMMABLE-BOUNDARY-START(25772775059)
            /*double*/ Balance = 0;
            //--TRIMMABLE-BOUNDARY-END(25772775059)
            
            //--TRIMMABLE-BOUNDARY-START(17182840467)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182840467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182840467)
            
            //--TRIMMABLE-BOUNDARY-START(17182840467)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182840467)
            
            static $h = 2971283;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067742355),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837546131,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607349907,
        "f": 83886081
      },
      "n": "BankName",
      "d": 2971283,
      "h": 30067742355,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067742355),
//--TRIMMABLE-BOUNDARY-START(21477807763),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657676947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427480723,
        "f": 83886081
      },
      "n": "AccountNumber",
      "d": 2971283,
      "h": 21477807763,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477807763),
//--TRIMMABLE-BOUNDARY-START(25772775059),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247611539,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017415315,
        "f": 83886081
      },
      "n": "Balance",
      "d": 2971283,
      "h": 25772775059,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772775059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182840467),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2971283,
      "h": 17182840467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182840467)
  ],
  "h": 2971283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryWalletInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryWalletInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2971283)
        
        

        //--TRIMMABLE-BOUNDARY-START(2905747)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTransactionTypeCustomAttributesProvider`, ($self) => class PayCowryTransactionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297873043)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297873043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297873043)
            
            static $h = 2905747;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297873043),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2905747,
      "h": 4297873043,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297873043)
  ],
  "h": 2905747
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTransactionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2905747)
        
        

        //--TRIMMABLE-BOUNDARY-START(3692179)
        $asm.$cls(`$UlXD.LCPCS.TokenExchangeContext`, ($self) => class TokenExchangeContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81608070803)
            /*IEnumerable<PayCowryTokenModel>*/ Tokens = null;
            //--TRIMMABLE-BOUNDARY-END(81608070803)
            
            //--TRIMMABLE-BOUNDARY-START(51543299731)
            /*Func<Task>*/ ReverseTransaction = null;
            //--TRIMMABLE-BOUNDARY-END(51543299731)
            
            //--TRIMMABLE-BOUNDARY-START(21478528659)
            /*Func<Task<PayCowryTransactionModel>>*/ CompleteTransaction = null;
            //--TRIMMABLE-BOUNDARY-END(21478528659)
            
            //--TRIMMABLE-BOUNDARY-START(17183561363)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183561363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183561363)
            
            //--TRIMMABLE-BOUNDARY-START(17183561363)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17183561363)
            
            static $h = 3692179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81608070803),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248332435,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77313103507,
        "f": 83886081
      },
      "n": "Tokens",
      "d": 3692179,
      "h": 81608070803,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81608070803),
//--TRIMMABLE-BOUNDARY-START(51543299731),
    {
      "p": $.$$.S.Func$$($.$$.STT.Task).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658397843,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68723168915,
        "f": 83886081
      },
      "n": "ReverseTransaction",
      "d": 3692179,
      "h": 51543299731,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51543299731),
//--TRIMMABLE-BOUNDARY-START(21478528659),
    {
      "p": $.$$.S.Func$$($.$$.STT.Task$$($.$UlXD.LCPCM.PayCowryTransactionModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068463251,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133234323,
        "f": 83886081
      },
      "n": "CompleteTransaction",
      "d": 3692179,
      "h": 21478528659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478528659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183561363),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3692179,
      "h": 17183561363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183561363)
  ],
  "h": 3692179
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.TokenExchangeContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}TokenExchangeContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3692179)
        
        

        //--TRIMMABLE-BOUNDARY-START(1005203)
        $asm.$cls(`$UlXD.LCPCM.PayCowryCurrencyCustomAttributesProvider`, ($self) => class PayCowryCurrencyCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295972499)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295972499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295972499)
            
            static $h = 1005203;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295972499),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1005203,
      "h": 4295972499,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295972499)
  ],
  "h": 1005203
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryCurrencyCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryCurrencyCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1005203)
        
        

        //--TRIMMABLE-BOUNDARY-START(1070739)
        $asm.$cls(`$UlXD.LCPCM.PayCowryDenominationModel`, ($self) => class PayCowryDenominationModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475907219)
            /*double*/ Denomination = 0;
            //--TRIMMABLE-BOUNDARY-END(21475907219)
            
            //--TRIMMABLE-BOUNDARY-START(64425580179)
            /*int*/ Quantity = 0;
            //--TRIMMABLE-BOUNDARY-END(64425580179)
            
            //--TRIMMABLE-BOUNDARY-START(17180939923)
            /*double */ get Amount()
            {
                return this.Quantity * this.Denomination;
            }
            //--TRIMMABLE-BOUNDARY-END(17180939923)
            
            //--TRIMMABLE-BOUNDARY-START(25770874515)
            static /*double[] */ get Denominations()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), [1000, 500, 200, 100, 50, 20, 10, 5, 2, 1], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25770874515)
            
            //--TRIMMABLE-BOUNDARY-START(12885972627)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885972627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885972627)
            
            //--TRIMMABLE-BOUNDARY-START(12885972627)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885972627)
            
            static $h = 1070739;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475907219),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950743699,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015514771,
        "f": 83886081
      },
      "n": "Denomination",
      "d": 1070739,
      "h": 21475907219,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475907219),
//--TRIMMABLE-BOUNDARY-START(64425580179),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130612883,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605449363,
        "f": 83886081
      },
      "n": "Quantity",
      "d": 1070739,
      "h": 64425580179,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425580179),
//--TRIMMABLE-BOUNDARY-START(17180939923),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360809107,
        "f": 50331649
      },
      "n": "Amount",
      "d": 1070739,
      "h": 17180939923,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180939923),
//--TRIMMABLE-BOUNDARY-START(25770874515),
    {
      "p": $.$typeArray($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540678291,
        "f": 50331681
      },
      "n": "Denominations",
      "d": 1070739,
      "h": 25770874515,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770874515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885972627),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1070739,
      "h": 12885972627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885972627)
  ],
  "h": 1070739
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryDenominationModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1070739)
        
        

        //--TRIMMABLE-BOUNDARY-START(1136275)
        $asm.$cls(`$UlXD.LCPCM.PayCowryDenominationModelCustomAttributesProvider`, ($self) => class PayCowryDenominationModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296103571)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296103571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296103571)
            
            static $h = 1136275;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296103571),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1136275,
      "h": 4296103571,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296103571)
  ],
  "h": 1136275
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryDenominationModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1136275)
        
        

        //--TRIMMABLE-BOUNDARY-START(1398419)
        $asm.$cls(`$UlXD.LCPCM.PayCowryLedgerModelCustomAttributesProvider`, ($self) => class PayCowryLedgerModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296365715)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296365715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296365715)
            
            static $h = 1398419;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296365715),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1398419,
      "h": 4296365715,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296365715)
  ],
  "h": 1398419
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryLedgerModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1398419)
        
        

        //--TRIMMABLE-BOUNDARY-START(349843)
        $asm.$cls(`$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelCustomAttributesProvider`, ($self) => class CommunityPayCowryRegisterResponseModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295317139)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295317139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295317139)
            
            static $h = 349843;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295317139),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 349843,
      "h": 4295317139,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295317139)
  ],
  "h": 349843
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}CommunityPayCowryRegisterResponseModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(349843)
        
        

        //--TRIMMABLE-BOUNDARY-START(2643603)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTransactionModelCustomAttributesProvider`, ($self) => class PayCowryTransactionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297610899)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297610899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297610899)
            
            static $h = 2643603;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297610899),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2643603,
      "h": 4297610899,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297610899)
  ],
  "h": 2643603
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTransactionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2643603)
        
        

        //--TRIMMABLE-BOUNDARY-START(153235)
        $asm.$cls(`$UlXD.LCPC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295120531)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295120531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295120531)
            
            static $h = 153235;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295120531),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 153235,
      "h": 4295120531,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295120531)
  ],
  "h": 153235
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(153235)
        
        

        //--TRIMMABLE-BOUNDARY-START(87699)
        $asm.$cls(`$UlXD.LCPC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295054995)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295054995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelCustomAttributesProvider, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryAccountFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryCurrency.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryCurrencyCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryCurrencyCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryDenominationModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryDenominationModelCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryDenominationModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryLedgerModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryLedgerModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryOfflineAccountModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryStorageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryStorageModelCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryStorageModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryTokenModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryTokenModelCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryTokenModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryTokenState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryTokenStateCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryTokenStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryTransactionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryTransactionModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UlXD.LCPCM.PayCowryTransactionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UlXD.LCPCM.PayCowryTransactionTypeCustomAttributesProvider, $.$UlXD.LCPCM.PayCowryTransactionTypeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295054995)
            
            static $h = 87699;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295054995),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 87699,
      "h": 4295054995,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295054995)
  ],
  "h": 87699
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(87699)
        
        

        //--TRIMMABLE-BOUNDARY-START(1922707)
        $asm.$cls(`$UlXD.LCPCM.PayCowryStorageModelCustomAttributesProvider`, ($self) => class PayCowryStorageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296890003)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296890003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296890003)
            
            static $h = 1922707;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296890003),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1922707,
      "h": 4296890003,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296890003)
  ],
  "h": 1922707
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryStorageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1922707)
        
        

        //--TRIMMABLE-BOUNDARY-START(2250387)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTokenModelCustomAttributesProvider`, ($self) => class PayCowryTokenModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297217683)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297217683)
            
            //--TRIMMABLE-BOUNDARY-START(8592184979)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592184979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$UlXD.LCPCM.PayCowryTokenModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("m");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SerialNumber", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("s");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SequenceNumber", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("n");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OwnerAddress", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("a");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Protection", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t7 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("p");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Protection2", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t8 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("r");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$UlXD.LCPCM.PayCowryTokenModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vxiijg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2250387,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $Eavlbb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2250387,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592184979)
            
            static $h = 2250387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592184979),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2250387,
      "h": 8592184979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592184979)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297217683),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2250387,
      "h": 4297217683,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297217683)
  ],
  "h": 2250387
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTokenModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2250387)
        
        

        //--TRIMMABLE-BOUNDARY-START(1660563)
        $asm.$cls(`$UlXD.LCPCM.PayCowryOfflineAccountModelCustomAttributesProvider`, ($self) => class PayCowryOfflineAccountModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296627859)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296627859)
            
            //--TRIMMABLE-BOUNDARY-START(8591595155)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591595155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$UlXD.LCPCM.PayCowryOfflineAccountModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(19, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Protection", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Pin", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Identity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DeviceId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("RemoteId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Version", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NetworkAddress", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FullName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Title", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Description", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Icon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BatchTransfer", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TransactionDescription", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t16 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i16 = new $t16();
                            $i16.$ctor$4();
                            $i16.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i16;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("InterfaceAddress", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t17 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i17 = new $t17();
                            $i17.$ctor$4();
                            $i17.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i17;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ProtectionData", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t18 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i18 = new $t18();
                            $i18.$ctor$4();
                            $i18.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i18;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Identifier", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t19 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i19 = new $t19();
                            $i19.$ctor$4();
                            $i19.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i19;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Location", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t20 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i20 = new $t20();
                            $i20.$ctor$4();
                            $i20.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i20;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Name", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t21 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i21 = new $t21();
                            $i21.$ctor$4();
                            $i21.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i21;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$UlXD.LCPCM.PayCowryOfflineAccountModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $tXfZuk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1660563,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $DjhZYd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1660563,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591595155)
            
            static $h = 1660563;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591595155),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1660563,
      "h": 8591595155,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591595155)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296627859),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1660563,
      "h": 4296627859,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296627859)
  ],
  "h": 1660563
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryOfflineAccountModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1660563)
        
        

        //--TRIMMABLE-BOUNDARY-START(480915)
        $asm.$cls(`$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptorBuilder`, ($self) => class CommunityPayCowryRegisterResponseModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590415507)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590415507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ArQDgh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":480915,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590415507)
            
            //--TRIMMABLE-BOUNDARY-START(4295448211)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295448211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295448211)
            
            //--TRIMMABLE-BOUNDARY-START(4295448211)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295448211)
            
            static $h = 480915;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590415507),
    {
      "r": 65537,
      "n": "Register",
      "d": 480915,
      "h": 8590415507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590415507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295448211),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 480915,
      "h": 4295448211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295448211)
  ],
  "h": 480915
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}CommunityPayCowryRegisterResponseModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(480915)
        
        

        //--TRIMMABLE-BOUNDARY-START(218771)
        $asm.$cls(`$UlXD.LCPC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295186067)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295186067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$UlXD.LCPCS.IPayCowryAccountRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$UlXD.LCPCS.IPayCowryAccountRemoteService_Mocking().$ctor$3(impl);
                }, $EugiIi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":218771,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$UlXD.LCPCS.IPayCowryRemoteService, $.$UlXD.LCPCS.IPayCowryRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$UlXD.LCPCS.IPayCowryRemoteService_Mocking().$ctor$3(impl);
                }, $YJBcMj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":218771,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295186067)
            
            static $h = 218771;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295186067),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 218771,
      "h": 4295186067,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295186067)
  ],
  "h": 218771
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(218771)
        
        

        //--TRIMMABLE-BOUNDARY-START(3757715)
        $asm.$cls(`$UlXD.LCPC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298725011)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298725011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptorBuilder.Register();
                $.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptorBuilder.Register();
                $.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptorBuilder.Register();
                $.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptorBuilder.Register();
                $.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptorBuilder.Register();
                $.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptorBuilder.Register();
                $.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptorBuilder.Register();
                $.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298725011)
            
            static $h = 3757715;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298725011),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3757715,
      "h": 4298725011,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298725011)
  ],
  "h": 3757715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3757715)
        
        

        //--TRIMMABLE-BOUNDARY-START(743059)
        $asm.$cls(`$UlXD.LCPCM.PayCowryAccountFeatureModelCustomAttributesProvider`, ($self) => class PayCowryAccountFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295710355)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295710355)
            
            //--TRIMMABLE-BOUNDARY-START(8590677651)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590677651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$UlXD.LCPCM.PayCowryAccountFeatureModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(12, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Identity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FirstName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LastName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PhoneNumber", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Email", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Pin", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DeviceId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Version", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NetworkAddress", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FullName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Protection", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ProtectionData", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$UlXD.LCPCM.PayCowryAccountFeatureModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ejPcqi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":743059,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $BmpXgd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":743059,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$Iaui.LCFCM.DataFeatureModelCustomAttributesProvider$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590677651)
            
            static $h = 743059;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590677651),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 743059,
      "h": 8590677651,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590677651)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295710355),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 743059,
      "h": 4295710355,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295710355)
  ],
  "h": 743059
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryAccountFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(743059)
        
        

        //--TRIMMABLE-BOUNDARY-START(1267347)
        $asm.$cls(`$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptorBuilder`, ($self) => class PayCowryDenominationModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591201939)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591201939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nNamCe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1267347,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.PayCowryDenominationModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591201939)
            
            //--TRIMMABLE-BOUNDARY-START(4296234643)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296234643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296234643)
            
            //--TRIMMABLE-BOUNDARY-START(4296234643)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296234643)
            
            static $h = 1267347;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591201939),
    {
      "r": 65537,
      "n": "Register",
      "d": 1267347,
      "h": 8591201939,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591201939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296234643),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1267347,
      "h": 4296234643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296234643)
  ],
  "h": 1267347
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryDenominationModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1267347)
        
        

        //--TRIMMABLE-BOUNDARY-START(2512531)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTokenStateCustomAttributesProvider`, ($self) => class PayCowryTokenStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297479827)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297479827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297479827)
            
            static $h = 2512531;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297479827),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2512531,
      "h": 4297479827,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297479827)
  ],
  "h": 2512531
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTokenStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTokenStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2512531)
        
        

        //--TRIMMABLE-BOUNDARY-START(2774675)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptorBuilder`, ($self) => class PayCowryTransactionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592709267)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592709267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VzGMPc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2774675,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.PayCowryTransactionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592709267)
            
            //--TRIMMABLE-BOUNDARY-START(4297741971)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297741971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297741971)
            
            //--TRIMMABLE-BOUNDARY-START(4297741971)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297741971)
            
            static $h = 2774675;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592709267),
    {
      "r": 65537,
      "n": "Register",
      "d": 2774675,
      "h": 8592709267,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592709267)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297741971),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2774675,
      "h": 4297741971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297741971)
  ],
  "h": 2774675
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTransactionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2774675)
        
        

        //--TRIMMABLE-BOUNDARY-START(1791635)
        $asm.$cls(`$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptorBuilder`, ($self) => class PayCowryOfflineAccountModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591726227)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591726227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FVzyee ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1791635,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591726227)
            
            //--TRIMMABLE-BOUNDARY-START(4296758931)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296758931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296758931)
            
            //--TRIMMABLE-BOUNDARY-START(4296758931)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296758931)
            
            static $h = 1791635;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591726227),
    {
      "r": 65537,
      "n": "Register",
      "d": 1791635,
      "h": 8591726227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591726227)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296758931),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1791635,
      "h": 4296758931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296758931)
  ],
  "h": 1791635
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryOfflineAccountModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1791635)
        
        

        //--TRIMMABLE-BOUNDARY-START(1529491)
        $asm.$cls(`$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptorBuilder`, ($self) => class PayCowryLedgerModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591464083)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591464083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hKWksj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1529491,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.PayCowryLedgerModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591464083)
            
            //--TRIMMABLE-BOUNDARY-START(4296496787)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296496787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296496787)
            
            //--TRIMMABLE-BOUNDARY-START(4296496787)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296496787)
            
            static $h = 1529491;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591464083),
    {
      "r": 65537,
      "n": "Register",
      "d": 1529491,
      "h": 8591464083,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591464083)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296496787),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1529491,
      "h": 4296496787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296496787)
  ],
  "h": 1529491
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryLedgerModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1529491)
        
        

        //--TRIMMABLE-BOUNDARY-START(2053779)
        $asm.$cls(`$UlXD.LCPCM.PayCowryStorageModelTypeDescriptorBuilder`, ($self) => class PayCowryStorageModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591988371)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591988371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eulVqh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2053779,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.PayCowryStorageModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591988371)
            
            //--TRIMMABLE-BOUNDARY-START(4297021075)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297021075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297021075)
            
            //--TRIMMABLE-BOUNDARY-START(4297021075)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297021075)
            
            static $h = 2053779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591988371),
    {
      "r": 65537,
      "n": "Register",
      "d": 2053779,
      "h": 8591988371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591988371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297021075),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2053779,
      "h": 4297021075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297021075)
  ],
  "h": 2053779
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryStorageModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2053779)
        
        

        //--TRIMMABLE-BOUNDARY-START(3823251)
        $asm.$cls(`$UlXD.LCPC.Utility`, ($self) => class Utility
        {
            //--TRIMMABLE-BOUNDARY-START(4298790547)
            static /*double */ _GetTransactionFee(/*double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298790547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*double*/ let payStackFee = 0;
                /*double*/ let payCowryFee = 0;
                if (amount < 5000)
                {
                    payStackFee = 10;
                    payCowryFee = 5;
                }
                else if (amount < 50000)
                {
                    payStackFee = 25;
                    payCowryFee = 5;
                }
                else 
                {
                    payStackFee = 50;
                    payCowryFee = 10;
                }
                return payStackFee + payCowryFee;
            }
            //--TRIMMABLE-BOUNDARY-END(4298790547)
            
            //--TRIMMABLE-BOUNDARY-START(8593757843)
            static /*Dictionary<int, int> */ Denominate(/*this int*/ amount, /*Func<int, int>?*/ getDenominationCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593757843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let amountLeft = amount;
                /*var*/ let countDenominations = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$1();
                let $en1 = $.$UlXD.LCPCM.PayCowryTokenModel.Denominations.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let denomination = $en1.SCG$IEnumerator$$$Current;
                    {
                        countDenominations.set_Item(denomination, 0);
                    }
                }
                let $en2 = $.$UlXD.LCPCM.PayCowryTokenModel.Denominations.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let denomination = $en2.SCG$IEnumerator$$$Current;
                    {
                        while(amountLeft >= denomination)
                        {
                            /*var*/ let countOfDenomnination = (getDenominationCount?.Invoke(denomination) ?? null) ?? 1;
                            if (countOfDenomnination === 0)
                            {
                                break;
                            }
                            countDenominations.set_Item(denomination, countDenominations.get_Item(denomination) + countOfDenomnination);
                            amountLeft -= ((countOfDenomnination * denomination) | 0);
                        }
                    }
                }
                return countDenominations;
            }
            //--TRIMMABLE-BOUNDARY-END(8593757843)
            
            //--TRIMMABLE-BOUNDARY-START(21478659731)
            static /*T */ ThrowIfNotValid$1(T, /*this T*/ data, /*IDataProtector*/ protector, /*bool*/ protect2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478659731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!protector.LCPCS$IDataProtector$Validate($.$box(data, T), protect2))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Invalid data");
                }
                return data;
            }
            //--TRIMMABLE-BOUNDARY-END(21478659731)
            
            //--TRIMMABLE-BOUNDARY-START(17183692435)
            static /*void */ ThrowIfNotValid(/*this IDataProtector*/ protector, /*string*/ pin, /*WalletHash*/ hash)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183692435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!protector.LCPCS$IDataProtector$ValidatePin(pin, $.$clone(hash)))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Invalid pin");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183692435)
            
            //--TRIMMABLE-BOUNDARY-START(12888725139)
            static /*T */ Protect(T, /*this T*/ data, /*IDataProtector*/ protector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888725139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                protector.LCPCS$IDataProtector$Protect($.$box(data, T));
                return data;
            }
            //--TRIMMABLE-BOUNDARY-END(12888725139)
            
            static $h = 3823251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298790547),
    {
      "r": 1179649,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "_GetTransactionFee",
      "d": 3823251,
      "h": 4298790547,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298790547),
//--TRIMMABLE-BOUNDARY-START(8593757843),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32).$h,
      "p": [
        {
          "n": "amount",
          "p": 655361
        },
        {
          "n": "getDenominationCount",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Int32).$h,
          "f": 65
        }
      ],
      "n": "Denominate",
      "d": 3823251,
      "h": 8593757843,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593757843),
//--TRIMMABLE-BOUNDARY-START(21478659731),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "data",
          "p": (T) => T.$h
        },
        {
          "n": "protector",
          "p": 3298963
        },
        {
          "n": "protect2",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfNotValid",
      "o": "@$1",
      "d": 3823251,
      "h": 21478659731,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21478659731),
//--TRIMMABLE-BOUNDARY-START(17183692435),
    {
      "r": 65537,
      "p": [
        {
          "n": "protector",
          "p": 3298963
        },
        {
          "n": "pin",
          "p": 1310721
        },
        {
          "n": "hash",
          "p": 2798797
        }
      ],
      "n": "ThrowIfNotValid",
      "d": 3823251,
      "h": 17183692435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17183692435),
//--TRIMMABLE-BOUNDARY-START(12888725139),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "data",
          "p": (T) => T.$h
        },
        {
          "n": "protector",
          "p": 3298963
        }
      ],
      "g": [
        "T"
      ],
      "n": "Protect",
      "d": 3823251,
      "h": 12888725139,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888725139)
  ],
  "h": 3823251
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Utility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Utility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3823251)
        
        

        //--TRIMMABLE-BOUNDARY-START(874131)
        $asm.$cls(`$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptorBuilder`, ($self) => class PayCowryAccountFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590808723)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590808723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pIoZVe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":874131,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590808723)
            
            //--TRIMMABLE-BOUNDARY-START(4295841427)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295841427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295841427)
            
            //--TRIMMABLE-BOUNDARY-START(4295841427)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295841427)
            
            static $h = 874131;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590808723),
    {
      "r": 65537,
      "n": "Register",
      "d": 874131,
      "h": 8590808723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590808723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295841427),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 874131,
      "h": 4295841427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295841427)
  ],
  "h": 874131
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryAccountFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(874131)
        
        

        //--TRIMMABLE-BOUNDARY-START(2381459)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTokenModelTypeDescriptorBuilder`, ($self) => class PayCowryTokenModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592316051)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592316051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor()
                        const $t1 = $.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xNoYLh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2381459,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UlXD.LCPCM.PayCowryTokenModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592316051)
            
            //--TRIMMABLE-BOUNDARY-START(4297348755)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297348755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297348755)
            
            //--TRIMMABLE-BOUNDARY-START(4297348755)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297348755)
            
            static $h = 2381459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592316051),
    {
      "r": 65537,
      "n": "Register",
      "d": 2381459,
      "h": 8592316051,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592316051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297348755),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2381459,
      "h": 4297348755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297348755)
  ],
  "h": 2381459
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTokenModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2381459)
        
        

        //--TRIMMABLE-BOUNDARY-START(2119315)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTokenBuilder`, ($self) => class PayCowryTokenBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111671269011)
            /*string?*/ Seed = null;
            //--TRIMMABLE-BOUNDARY-END(111671269011)
            
            //--TRIMMABLE-BOUNDARY-START(171800811155)
            /*string?*/ Time = null;
            //--TRIMMABLE-BOUNDARY-END(171800811155)
            
            //--TRIMMABLE-BOUNDARY-START(34361857683)
            /*double*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(34361857683)
            
            //--TRIMMABLE-BOUNDARY-START(115966236307)
            /*string?*/ SerialNumber = null;
            //--TRIMMABLE-BOUNDARY-END(115966236307)
            
            //--TRIMMABLE-BOUNDARY-START(98786367123)
            /*string?*/ OwnerAddress = null;
            //--TRIMMABLE-BOUNDARY-END(98786367123)
            
            //--TRIMMABLE-BOUNDARY-START(107376301715)
            /*Dictionary<string, object?> */ get ProtectionData()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Seed", this.Seed);
                    $i1.set_Item("Time", this.Time);
                    $i1.set_Item("Amount", $.$box(this.Amount, $.$$.S.Double));
                    $i1.set_Item("SerialNumber", this.SerialNumber);
                    $i1.set_Item("OwnerAddress", this.OwnerAddress);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(107376301715)
            
            //--TRIMMABLE-BOUNDARY-START(103081334419)
            /*WalletHash*/ Protection;
            //--TRIMMABLE-BOUNDARY-END(103081334419)
            
            //--TRIMMABLE-BOUNDARY-START(17180481171)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.ProtectionData.get
            get LCPCM$IProtectedData$ProtectionData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770415763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectionData;
            }
            //--TRIMMABLE-BOUNDARY-END(17180481171)
            
            //--TRIMMABLE-BOUNDARY-START(8590546579)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.get
            get LCPCM$IProtectedData$Protection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Protection;
            }
            //--TRIMMABLE-BOUNDARY-END(8590546579)
            
            //--TRIMMABLE-BOUNDARY-START(34360350355)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.set
            set LCPCM$IProtectedData$Protection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Protection = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360350355)
            
            //--TRIMMABLE-BOUNDARY-START(30066890387)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066890387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066890387)
            
            //--TRIMMABLE-BOUNDARY-START(30066890387)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30066890387)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(103081334419)
                this.Protection = $.$default($.$OJJQ.LCFCW.WalletHash);
                //--TRIMMABLE-BOUNDARY-END(103081334419)
                
            }
            static $h = 2119315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111671269011),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311530643,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325974675,
        "f": 83886081
      },
      "n": "Seed",
      "d": 2119315,
      "h": 111671269011,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671269011),
//--TRIMMABLE-BOUNDARY-START(171800811155),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491399827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505843859,
        "f": 83886081
      },
      "n": "Time",
      "d": 2119315,
      "h": 171800811155,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171800811155),
//--TRIMMABLE-BOUNDARY-START(34361857683),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951792275,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124556170899,
        "f": 83886081
      },
      "n": "Amount",
      "d": 2119315,
      "h": 34361857683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361857683),
//--TRIMMABLE-BOUNDARY-START(115966236307),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901465235,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915909267,
        "f": 83886081
      },
      "n": "SerialNumber",
      "d": 2119315,
      "h": 115966236307,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966236307),
//--TRIMMABLE-BOUNDARY-START(98786367123),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541726867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133146105491,
        "f": 83886081
      },
      "n": "OwnerAddress",
      "d": 2119315,
      "h": 98786367123,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786367123),
//--TRIMMABLE-BOUNDARY-START(107376301715),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721596051,
        "f": 50331649
      },
      "n": "ProtectionData",
      "d": 2119315,
      "h": 107376301715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376301715),
//--TRIMMABLE-BOUNDARY-START(103081334419),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131661459,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141736040083,
        "f": 83886081
      },
      "n": "Protection",
      "d": 2119315,
      "h": 103081334419,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103081334419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066890387),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2119315,
      "h": 30066890387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066890387)
  ],
  "h": 2119315
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UlXD.LCPCM.IProtectedData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTokenBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTokenBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2119315)
        
        

        //--TRIMMABLE-BOUNDARY-START(3102355)
        $asm.$cls(`$UlXD.LCPC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593036947)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593036947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$UlXD.LCPCS.IDataProtector, $.$UlXD.LCPCS.DataProtector, services);
                $.$UlXD.LCPC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$UlXD.LCPC.FastEnumStartupExtension.AddGeneratedFastEnums(services);
                $.$UlXD.LCPC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$UlXD.LCPC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593036947)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$UlXD.LCPC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298069651)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298069651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298069651)
            
            //--TRIMMABLE-BOUNDARY-START(4298069651)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298069651)
            
            static $h = 3102355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593036947),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3102355,
      "h": 8593036947,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593036947)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298069651),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3102355,
      "h": 4298069651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298069651)
  ],
  "h": 3102355
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3102355)
        
        

        //--TRIMMABLE-BOUNDARY-START(3233427)
        $asm.$cls(`$UlXD.LCPCS.FakeOCRScannerProvider`, ($self) => class FakeOCRScannerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593168019)
            /*ValueTask<IWalletHolder?> *//*async*/  ScanPeer(/*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder), $.$OJJQ.LCFCW.IWalletHolder, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593168019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$$.STT.Task.Delay$1(2000), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$UlXD.LCPCM.PayCowryOfflineAccountModel()
                        const $t2 = $.$UlXD.LCPCM.PayCowryOfflineAccountModel;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.UserName = "Samson";
                        $i2.FirstName = "Samson";
                        $i2.LastName = "Joe";
                        $i2.Protection = $.$OJJQ.LCFCW.WalletHash.op_Implicit$1("SDDSFSDZFCSswr34we5r");
                        return $i2;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8593168019)
            
            //--TRIMMABLE-BOUNDARY-START(4295931085)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletQRPaymentScannerProvider.ScanPeer(System.Threading.CancellationToken)
            LCFCW$IWalletQRPaymentScannerProvider$ScanPeer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295931085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ScanPeer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295931085)
            
            //--TRIMMABLE-BOUNDARY-START(4298200723)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298200723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298200723)
            
            //--TRIMMABLE-BOUNDARY-START(4298200723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298200723)
            
            static $h = 3233427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593168019),
    {
      "r": $.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ScanPeer",
      "d": 3233427,
      "h": 8593168019,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(8593168019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298200723),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3233427,
      "h": 4298200723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298200723)
  ],
  "h": 3233427
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletQRPaymentScannerProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.FakeOCRScannerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}FakeOCRScannerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3233427)
        
        

        //--TRIMMABLE-BOUNDARY-START(3167891)
        $asm.$cls(`$UlXD.LCPCS.DataProtector`, ($self) => class DataProtector extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593102483)
            static /*WalletHash */ Generate(/*Dictionary<string, object?>*/ metadata)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593102483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let str = $.$$.S.String.Join$5(",", $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String, $.$sl.SL.Enumerable.OrderBy$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String, metadata, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.Key;
                }, $CpzcXf ??= {"r":1310721,"p":[{"n":"o","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":3167891,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String))().$ctor(this,  (/*m*/ m) =>
                {
                    return `${$.$strNN(m.Key)}:${$.$strNN($.$dspc(m.Value, $.$$.S.Object, ($t) => $t.ToString))}`;
                }, $fBKBmk ??= {"r":1310721,"p":[{"n":"m","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":3167891,"h":0,"f":17825794})));
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletHash()
                    const $t1 = $.$OJJQ.LCFCW.WalletHash;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Hash = $.$fPer.LCFC.EncryptUtility.QuickHash512$2(str, null);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8593102483)
            
            //--TRIMMABLE-BOUNDARY-START(12888069779)
            /*void */ Protect(/*IProtectedData*/ $protected)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888069779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $protected.LCPCM$IProtectedData$Protection = $.$UlXD.LCPCS.DataProtector.Generate($protected.LCPCM$IProtectedData$ProtectionData);
                let dprotected;
                if ($.$is($protected, $.$UlXD.LCPCM.IDoubleProtectedData, { set $v($v){ dprotected = $v; } }))
                {
                    dprotected.LCPCM$IDoubleProtectedData$Protection2 = $.$UlXD.LCPCS.DataProtector.Generate(dprotected.LCPCM$IDoubleProtectedData$ProtectionData2);
                }
                $.$UlXD.LCPC.Utility.ThrowIfNotValid$1($.$UlXD.LCPCM.IProtectedData, $protected, this, true);
            }
            //--TRIMMABLE-BOUNDARY-END(12888069779)
            
            //--TRIMMABLE-BOUNDARY-START(25772971667)
            /*bool */ Validate(/*IProtectedData*/ $protected, /*bool*/ protect2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772971667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hash = $.$UlXD.LCPCS.DataProtector.Generate($protected.LCPCM$IProtectedData$ProtectionData);
                /*bool*/ let valid = $.$OJJQ.LCFCW.WalletHash.op_Equality($protected.LCPCM$IProtectedData$Protection, hash);
                let dprotected;
                if (valid && protect2 && $.$is($protected, $.$UlXD.LCPCM.IDoubleProtectedData, { set $v($v){ dprotected = $v; } }))
                {
                    /*var*/ let hash2 = $.$UlXD.LCPCS.DataProtector.Generate(dprotected.LCPCM$IDoubleProtectedData$ProtectionData2);
                    valid = $.$OJJQ.LCFCW.WalletHash.op_Equality(dprotected.LCPCM$IDoubleProtectedData$Protection2, hash2);
                }
                return valid;
            }
            //--TRIMMABLE-BOUNDARY-END(25772971667)
            
            //--TRIMMABLE-BOUNDARY-START(21478004371)
            /*WalletHash */ ProtectPin(/*string*/ pin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478004371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OJJQ.LCFCW.WalletHash.op_Implicit$1($.$fPer.LCFC.EncryptUtility.QuickHash512$2(pin, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478004371)
            
            //--TRIMMABLE-BOUNDARY-START(30067938963)
            /*bool */ ValidatePin(/*string*/ pinCode, /*WalletHash*/ hash)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067938963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _hash = $.$fPer.LCFC.EncryptUtility.QuickHash512$2(pinCode, null);
                return $.$OJJQ.LCFCW.WalletHash.op_Equality(hash, $.$OJJQ.LCFCW.WalletHash.op_Implicit$1(_hash));
            }
            //--TRIMMABLE-BOUNDARY-END(30067938963)
            
            //--TRIMMABLE-BOUNDARY-START(17183037075)
            /*byte[] */ ProtectKey(/*byte[]*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183037075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return key;
            }
            //--TRIMMABLE-BOUNDARY-END(17183037075)
            
            //--TRIMMABLE-BOUNDARY-START(4298266259)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Services.IDataProtector.Protect(LivingThing.Core.PayCowry.Common.Models.IProtectedData)
            LCPCS$IDataProtector$Protect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298266259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Protect(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298266259)
            
            //--TRIMMABLE-BOUNDARY-START(17183168147)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Services.IDataProtector.Validate(LivingThing.Core.PayCowry.Common.Models.IProtectedData, bool)
            LCPCS$IDataProtector$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183168147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17183168147)
            
            //--TRIMMABLE-BOUNDARY-START(12888200851)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Services.IDataProtector.ProtectPin(string)
            LCPCS$IDataProtector$ProtectPin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888200851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectPin(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12888200851)
            
            //--TRIMMABLE-BOUNDARY-START(21478135443)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Services.IDataProtector.ValidatePin(string, LivingThing.Core.Frameworks.Common.Wallet.WalletHash)
            LCPCS$IDataProtector$ValidatePin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478135443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidatePin(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478135443)
            
            //--TRIMMABLE-BOUNDARY-START(8593233555)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Services.IDataProtector.ProtectKey(byte[])
            LCPCS$IDataProtector$ProtectKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593233555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8593233555)
            
            //--TRIMMABLE-BOUNDARY-START(4298135187)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298135187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298135187)
            
            //--TRIMMABLE-BOUNDARY-START(4298135187)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298135187)
            
            static $h = 3167891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593102483),
    {
      "r": 2798797,
      "p": [
        {
          "n": "metadata",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "Generate",
      "d": 3167891,
      "h": 8593102483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593102483),
//--TRIMMABLE-BOUNDARY-START(12888069779),
    {
      "r": 65537,
      "p": [
        {
          "n": "protected",
          "p": 611987
        }
      ],
      "n": "Protect",
      "d": 3167891,
      "h": 12888069779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888069779),
//--TRIMMABLE-BOUNDARY-START(25772971667),
    {
      "r": 262145,
      "p": [
        {
          "n": "protected",
          "p": 611987
        },
        {
          "n": "protect2",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Validate",
      "d": 3167891,
      "h": 25772971667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772971667),
//--TRIMMABLE-BOUNDARY-START(21478004371),
    {
      "r": 2798797,
      "p": [
        {
          "n": "pin",
          "p": 1310721
        }
      ],
      "n": "ProtectPin",
      "d": 3167891,
      "h": 21478004371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478004371),
//--TRIMMABLE-BOUNDARY-START(30067938963),
    {
      "r": 262145,
      "p": [
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "hash",
          "p": 2798797
        }
      ],
      "n": "ValidatePin",
      "d": 3167891,
      "h": 30067938963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067938963),
//--TRIMMABLE-BOUNDARY-START(17183037075),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "key",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ProtectKey",
      "d": 3167891,
      "h": 17183037075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183037075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298135187),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3167891,
      "h": 4298135187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298135187)
  ],
  "h": 3167891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UlXD.LCPCS.IDataProtector ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.DataProtector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}DataProtector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3167891)
        
        

        //--TRIMMABLE-BOUNDARY-START(2578067)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTransactionModel`, ($self) => class PayCowryTransactionModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51542185619)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(51542185619)
            
            //--TRIMMABLE-BOUNDARY-START(47247218323)
            /*DateTime*/ Date;
            //--TRIMMABLE-BOUNDARY-END(47247218323)
            
            //--TRIMMABLE-BOUNDARY-START(42952251027)
            /*int*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(42952251027)
            
            //--TRIMMABLE-BOUNDARY-START(257700615827)
            /*string[]?*/ Tokens = null;
            //--TRIMMABLE-BOUNDARY-END(257700615827)
            
            //--TRIMMABLE-BOUNDARY-START(184686171795)
            /*WalletAddress*/ Sender;
            //--TRIMMABLE-BOUNDARY-END(184686171795)
            
            //--TRIMMABLE-BOUNDARY-START(180391204499)
            /*WalletAddress*/ Receiver;
            //--TRIMMABLE-BOUNDARY-END(180391204499)
            
            //--TRIMMABLE-BOUNDARY-START(261995583123)
            /*string*/ Version = null;
            //--TRIMMABLE-BOUNDARY-END(261995583123)
            
            //--TRIMMABLE-BOUNDARY-START(176096237203)
            /*Dictionary<string, object?> */ get ProtectionData()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Sender", this.Sender.Address);
                    $i1.set_Item("Receiver", this.Receiver.Address);
                    $i1.set_Item("Amount", $.$box(this.Amount, $.$$.S.Int32));
                    $i1.set_Item("Tokens", this.Tokens);
                    $i1.set_Item("Date", this.Date);
                    $i1.set_Item("Version", this.Version);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(176096237203)
            
            //--TRIMMABLE-BOUNDARY-START(171801269907)
            /*WalletHash*/ Protection;
            //--TRIMMABLE-BOUNDARY-END(171801269907)
            
            //--TRIMMABLE-BOUNDARY-START(137441531539)
            /*WalletIdentifier */ get LCFCW$IWalletTransaction$Coin()
            {
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletIdentifier()
                    const $t2 = $.$OJJQ.LCFCW.WalletIdentifier;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.IssuerName = "PayCowry"/*PayCowryTokenModel.IssuerName*/;
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(137441531539)
            
            //--TRIMMABLE-BOUNDARY-START(167506302611)
            /*string? */ get LCFCW$IWalletTransaction$Reference()
            {
                return `${$.$strNN(this.Date.ToString$3("yyyyMMddHHmmss"))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(167506302611)
            
            //--TRIMMABLE-BOUNDARY-START(133146564243)
            /*double */ get LCFCW$IWalletTransaction$Amount()
            {
                return this.Amount;
            }
            //--TRIMMABLE-BOUNDARY-END(133146564243)
            
            //--TRIMMABLE-BOUNDARY-START(17180481171)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.ProtectionData.get
            get LCPCM$IProtectedData$ProtectionData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770415763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectionData;
            }
            //--TRIMMABLE-BOUNDARY-END(17180481171)
            
            //--TRIMMABLE-BOUNDARY-START(8590546579)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.get
            get LCPCM$IProtectedData$Protection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Protection;
            }
            //--TRIMMABLE-BOUNDARY-END(8590546579)
            
            //--TRIMMABLE-BOUNDARY-START(34360350355)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.set
            set LCPCM$IProtectedData$Protection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Protection = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360350355)
            
            //--TRIMMABLE-BOUNDARY-START(51541030093)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Description.get
            get LCFCW$IWalletTransaction$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181291725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(51541030093)
            
            //--TRIMMABLE-BOUNDARY-START(42951095501)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Date.get
            get LCFCW$IWalletTransaction$Date()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886324429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Date;
            }
            //--TRIMMABLE-BOUNDARY-END(42951095501)
            
            //--TRIMMABLE-BOUNDARY-START(77310833869)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Sender.get
            get LCFCW$IWalletTransaction$Sender()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195735757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Sender;
            }
            //--TRIMMABLE-BOUNDARY-END(77310833869)
            
            //--TRIMMABLE-BOUNDARY-START(60130964685)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Receiver.get
            get LCFCW$IWalletTransaction$Receiver()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605801165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Receiver;
            }
            //--TRIMMABLE-BOUNDARY-END(60130964685)
            
            //--TRIMMABLE-BOUNDARY-START(38657283731)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657283731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657283731)
            
            //--TRIMMABLE-BOUNDARY-START(38657283731)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(38657283731)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47247218323)
                this.Date = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(47247218323)
                
                //--TRIMMABLE-BOUNDARY-START(184686171795)
                this.Sender = $.$default($.$OJJQ.LCFCW.WalletAddress);
                //--TRIMMABLE-BOUNDARY-END(184686171795)
                
                //--TRIMMABLE-BOUNDARY-START(180391204499)
                this.Receiver = $.$default($.$OJJQ.LCFCW.WalletAddress);
                //--TRIMMABLE-BOUNDARY-END(180391204499)
                
                //--TRIMMABLE-BOUNDARY-START(261995583123)
                this.Version = "1.0";
                //--TRIMMABLE-BOUNDARY-END(261995583123)
                
                //--TRIMMABLE-BOUNDARY-START(171801269907)
                this.Protection = $.$default($.$OJJQ.LCFCW.WalletHash);
                //--TRIMMABLE-BOUNDARY-END(171801269907)
                
            }
            static $h = 2578067;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542185619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311989395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210455975571,
        "f": 83886081
      },
      "n": "Description",
      "d": 2578067,
      "h": 51542185619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542185619),
//--TRIMMABLE-BOUNDARY-START(47247218323),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722054803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201866040979,
        "f": 83886081
      },
      "n": "Date",
      "d": 2578067,
      "h": 47247218323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247218323),
//--TRIMMABLE-BOUNDARY-START(42952251027),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132120211,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193276106387,
        "f": 83886081
      },
      "n": "Amount",
      "d": 2578067,
      "h": 42952251027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952251027),
//--TRIMMABLE-BOUNDARY-START(257700615827),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261662355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244815713939,
        "f": 83886081
      },
      "n": "Tokens",
      "d": 2578067,
      "h": 257700615827,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257700615827),
//--TRIMMABLE-BOUNDARY-START(184686171795),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671727763,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236225779347,
        "f": 83886081
      },
      "n": "Sender",
      "d": 2578067,
      "h": 184686171795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184686171795),
//--TRIMMABLE-BOUNDARY-START(180391204499),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081793171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227635844755,
        "f": 83886081
      },
      "n": "Receiver",
      "d": 2578067,
      "h": 180391204499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180391204499),
//--TRIMMABLE-BOUNDARY-START(261995583123),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851596947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253405648531,
        "f": 83886081
      },
      "n": "Version",
      "d": 2578067,
      "h": 261995583123,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261995583123),
//--TRIMMABLE-BOUNDARY-START(176096237203),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491858579,
        "f": 50331649
      },
      "n": "ProtectionData",
      "d": 2578067,
      "h": 176096237203,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176096237203),
//--TRIMMABLE-BOUNDARY-START(171801269907),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901923987,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219045910163,
        "f": 83886081
      },
      "n": "Protection",
      "d": 2578067,
      "h": 171801269907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171801269907),
//--TRIMMABLE-BOUNDARY-START(137441531539),
    {
      "p": 2864333,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621400723,
        "f": 50331650
      },
      "n": "{1422541}.Coin",
      "o": "LCFCW$IWalletTransaction$Coin",
      "d": 2578067,
      "h": 137441531539,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(137441531539),
//--TRIMMABLE-BOUNDARY-START(167506302611),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211335315,
        "f": 50331650
      },
      "n": "{1422541}.Reference",
      "o": "LCFCW$IWalletTransaction$Reference",
      "d": 2578067,
      "h": 167506302611,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(167506302611),
//--TRIMMABLE-BOUNDARY-START(133146564243),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031466131,
        "f": 50331650
      },
      "n": "{1422541}.Amount",
      "o": "LCFCW$IWalletTransaction$Amount",
      "d": 2578067,
      "h": 133146564243,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133146564243)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38657283731),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2578067,
      "h": 38657283731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657283731)
  ],
  "h": 2578067
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UlXD.LCPCM.IProtectedData, $.$OJJQ.LCFCW.IWalletTransaction ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTransactionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2578067)
        
        

        //--TRIMMABLE-BOUNDARY-START(2184851)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTokenModel`, ($self) => class PayCowryTokenModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77311596179)
            /*IEnumerable<int>*/ static Denominations = null;
            //--TRIMMABLE-BOUNDARY-END(77311596179)
            
            //--TRIMMABLE-BOUNDARY-START(219045516947)
            /*string*/ static IssuerName = null;
            //--TRIMMABLE-BOUNDARY-END(219045516947)
            
            //--TRIMMABLE-BOUNDARY-START(335009633939)
            /*string*/ static WalletName = null;
            //--TRIMMABLE-BOUNDARY-END(335009633939)
            
            //--TRIMMABLE-BOUNDARY-START(73016628883)
            /*WalletTokenDescriptor[]?*/ static coins = null;
            //--TRIMMABLE-BOUNDARY-END(73016628883)
            
            //--TRIMMABLE-BOUNDARY-START(64426694291)
            static /*IEnumerable<WalletTokenDescriptor> */ get CoinDescriptors()
            {
                return $.$UlXD.LCPCM.PayCowryTokenModel.coins ??= $.$sl.SL.Enumerable.ToArray($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$OJJQ.LCFCW.WalletTokenDescriptor, $.$UlXD.LCPCM.PayCowryTokenModel.Denominations, new ($.$$.S.Func$$$($.$$.S.Int32, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor(this,  (/*d*/ d) =>
                {
                    return (() =>
                    {
                        //new $.$OJJQ.LCFCW.WalletTokenDescriptor()
                        const $t1 = $.$OJJQ.LCFCW.WalletTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Amount = d;
                        $i1.Name = `${$.$strNN("\u20A6"/*Money.NairaSymbol*/)}${$.$strNN(d)}`;
                        $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit(`_content/LivingThing.Core.PayCowry.Client.Blazor/N${$.$strNN(d)}.png`);
                        $i1.Description = `Nigerian ${$.$strNN(d)} Naira`;
                        return $i1;
                    })();
                }, $IUBdLf ??= {"r":3257549,"p":[{"n":"d","p":655361}],"n":"","d":2184851,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(64426694291)
            
            //--TRIMMABLE-BOUNDARY-START(330714666643)
            /*string*/ Version = null;
            //--TRIMMABLE-BOUNDARY-END(330714666643)
            
            //--TRIMMABLE-BOUNDARY-START(55836759699)
            /*int*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(55836759699)
            
            //--TRIMMABLE-BOUNDARY-START(261995189907)
            /*string?*/ SerialNumber = null;
            //--TRIMMABLE-BOUNDARY-END(261995189907)
            
            //--TRIMMABLE-BOUNDARY-START(257700222611)
            /*long*/ SequenceNumber = 0n;
            //--TRIMMABLE-BOUNDARY-END(257700222611)
            
            //--TRIMMABLE-BOUNDARY-START(236225386131)
            /*WalletAddress*/ OwnerAddress;
            //--TRIMMABLE-BOUNDARY-END(236225386131)
            
            //--TRIMMABLE-BOUNDARY-START(240520353427)
            /*WalletHash*/ Protection;
            //--TRIMMABLE-BOUNDARY-END(240520353427)
            
            //--TRIMMABLE-BOUNDARY-START(249110288019)
            /*Dictionary<string, object?> */ get ProtectionData()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("Amount", $.$box(this.Amount, $.$$.S.Int32));
                    $i2.set_Item("SerialNumber", this.SerialNumber);
                    $i2.set_Item("Version", this.Version);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(249110288019)
            
            //--TRIMMABLE-BOUNDARY-START(244815320723)
            /*WalletHash*/ Protection2;
            //--TRIMMABLE-BOUNDARY-END(244815320723)
            
            //--TRIMMABLE-BOUNDARY-START(253405255315)
            /*Dictionary<string, object?> */ get ProtectionData2()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.set_Item("Amount", $.$box(this.Amount, $.$$.S.Int32));
                    $i3.set_Item("SerialNumber", this.SerialNumber);
                    $i3.set_Item("Version", this.Version);
                    $i3.set_Item("OwnerAddress", this.OwnerAddress.Address);
                    return $i3;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(253405255315)
            
            //--TRIMMABLE-BOUNDARY-START(68721661587)
            /*WalletIdentifier */ get CoinIdentifier()
            {
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletIdentifier()
                    const $t4 = $.$OJJQ.LCFCW.WalletIdentifier;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.IssuerName = "PayCowry"/*IssuerName*/;
                    $i4.CoinName = `${$.$strNN("\u20A6"/*Money.NairaSymbol*/)}${$.$strNN(this.Amount)}`;
                    return $i4;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(68721661587)
            
            //--TRIMMABLE-BOUNDARY-START(90196498067)
            /*double*/ FrozenAmount = 0;
            //--TRIMMABLE-BOUNDARY-END(90196498067)
            
            //--TRIMMABLE-BOUNDARY-START(60131726995)
            /*double*/ Cashback = 0;
            //--TRIMMABLE-BOUNDARY-END(60131726995)
            
            //--TRIMMABLE-BOUNDARY-START(223340484243)
            /*double */ get LCFCW$IWalletToken$Amount()
            {
                return this.Amount;
            }
            //--TRIMMABLE-BOUNDARY-END(223340484243)
            
            //--TRIMMABLE-BOUNDARY-START(214750549651)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750549651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.HashCode.Combine$6($.$OJJQ.LCFCW.WalletHash, $.$OJJQ.LCFCW.WalletHash, $.$clone(this.Protection), $.$clone(this.Protection2));
            }
            //--TRIMMABLE-BOUNDARY-END(214750549651)
            
            //--TRIMMABLE-BOUNDARY-START(81606563475)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606563475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                if ($.$is(obj, $.$UlXD.LCPCM.PayCowryTokenModel, { set $v($v){ other = $v; } }))
                {
                    return $.$OJJQ.LCFCW.WalletHash.op_Equality(other.Protection, this.Protection) && $.$OJJQ.LCFCW.WalletHash.op_Equality(other.Protection2, this.Protection2);
                }
                return $.$$.S.Object.Equals$1.call(this, obj);
            }
            //--TRIMMABLE-BOUNDARY-END(81606563475)
            
            //--TRIMMABLE-BOUNDARY-START(85901530771)
            /*bool */ Equals$2(/*PayCowryTokenModel?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901530771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (other?.Protection ?? null) === this.Protection && (other?.Protection2 ?? null) === this.Protection2;
            }
            //--TRIMMABLE-BOUNDARY-END(85901530771)
            
            //--TRIMMABLE-BOUNDARY-START(326419699347)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419699347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$strNN($.$strNN(this.Protection.ToString()) + "#") + $.$strNN(this.Protection2.ToString());
            }
            //--TRIMMABLE-BOUNDARY-END(326419699347)
            
            //--TRIMMABLE-BOUNDARY-START(42951029965)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletToken.CoinIdentifier.get
            get LCFCW$IWalletToken$CoinIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886258893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CoinIdentifier;
            }
            //--TRIMMABLE-BOUNDARY-END(42951029965)
            
            //--TRIMMABLE-BOUNDARY-START(51540964557)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletToken.FrozenAmount.get
            get LCFCW$IWalletToken$FrozenAmount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181226189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FrozenAmount;
            }
            //--TRIMMABLE-BOUNDARY-END(51540964557)
            
            //--TRIMMABLE-BOUNDARY-START(34361095373)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletToken.Cashback.get
            get LCFCW$IWalletToken$Cashback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591291597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Cashback;
            }
            //--TRIMMABLE-BOUNDARY-END(34361095373)
            
            //--TRIMMABLE-BOUNDARY-START(17180415635)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IDoubleProtectedData.ProtectionData2.get
            get LCPCM$IDoubleProtectedData$ProtectionData2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770350227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectionData2;
            }
            //--TRIMMABLE-BOUNDARY-END(17180415635)
            
            //--TRIMMABLE-BOUNDARY-START(8590481043)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IDoubleProtectedData.Protection2.get
            get LCPCM$IDoubleProtectedData$Protection2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475382931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Protection2;
            }
            //--TRIMMABLE-BOUNDARY-END(8590481043)
            
            //--TRIMMABLE-BOUNDARY-START(34360284819)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IDoubleProtectedData.Protection2.set
            set LCPCM$IDoubleProtectedData$Protection2(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475382931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Protection2 = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360284819)
            
            //--TRIMMABLE-BOUNDARY-START(17180481171)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.ProtectionData.get
            get LCPCM$IProtectedData$ProtectionData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770415763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectionData;
            }
            //--TRIMMABLE-BOUNDARY-END(17180481171)
            
            //--TRIMMABLE-BOUNDARY-START(8590546579)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.get
            get LCPCM$IProtectedData$Protection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Protection;
            }
            //--TRIMMABLE-BOUNDARY-END(8590546579)
            
            //--TRIMMABLE-BOUNDARY-START(34360350355)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.set
            set LCPCM$IProtectedData$Protection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Protection = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360350355)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel>.Equals(LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel?)
            S$IEquatable$LivingThing$Core$PayCowry$Common$Models$PayCowryTokenModel$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(51541792403)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541792403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541792403)
            
            //--TRIMMABLE-BOUNDARY-START(51541792403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(51541792403)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(330714666643)
                this.Version = "1.0";
                //--TRIMMABLE-BOUNDARY-END(330714666643)
                
                //--TRIMMABLE-BOUNDARY-START(55836759699)
                this.Amount = 1;
                //--TRIMMABLE-BOUNDARY-END(55836759699)
                
                //--TRIMMABLE-BOUNDARY-START(236225386131)
                this.OwnerAddress = $.$default($.$OJJQ.LCFCW.WalletAddress);
                //--TRIMMABLE-BOUNDARY-END(236225386131)
                
                //--TRIMMABLE-BOUNDARY-START(240520353427)
                this.Protection = $.$default($.$OJJQ.LCFCW.WalletHash);
                //--TRIMMABLE-BOUNDARY-END(240520353427)
                
                //--TRIMMABLE-BOUNDARY-START(244815320723)
                this.Protection2 = $.$default($.$OJJQ.LCFCW.WalletHash);
                //--TRIMMABLE-BOUNDARY-END(244815320723)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47246825107)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246825107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(77311596179)
                    this.Denominations = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [1000, 500, 200, 100, 50, 20, 10, 5, 2, 1], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(77311596179)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219045516947)
                    this.IssuerName = "PayCowry";
                    //--TRIMMABLE-BOUNDARY-END(219045516947)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335009633939)
                    this.WalletName = "PayCowry/Wallet";
                    //--TRIMMABLE-BOUNDARY-END(335009633939)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246825107)
            
            static $h = 2184851;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311596179),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146171027,
        "f": 50331681
      },
      "n": "Denominations",
      "d": 2184851,
      "h": 77311596179,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(77311596179),
//--TRIMMABLE-BOUNDARY-START(64426694291),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966301843,
        "f": 50331681
      },
      "n": "CoinDescriptors",
      "d": 2184851,
      "h": 64426694291,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(64426694291),
//--TRIMMABLE-BOUNDARY-START(330714666643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210455582355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322124732051,
        "f": 83886081
      },
      "n": "Version",
      "d": 2184851,
      "h": 330714666643,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330714666643),
//--TRIMMABLE-BOUNDARY-START(55836759699),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786432659,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270585124499,
        "f": 83886081
      },
      "n": "Amount",
      "d": 2184851,
      "h": 55836759699,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "m",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836759699),
//--TRIMMABLE-BOUNDARY-START(261995189907),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865647763,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313534797459,
        "f": 83886081
      },
      "n": "SerialNumber",
      "d": 2184851,
      "h": 261995189907,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "s",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261995189907),
//--TRIMMABLE-BOUNDARY-START(257700222611),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275713171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304944862867,
        "f": 83886081
      },
      "n": "SequenceNumber",
      "d": 2184851,
      "h": 257700222611,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "n",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257700222611),
//--TRIMMABLE-BOUNDARY-START(236225386131),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326040211,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279175059091,
        "f": 83886081
      },
      "n": "OwnerAddress",
      "d": 2184851,
      "h": 236225386131,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "a",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236225386131),
//--TRIMMABLE-BOUNDARY-START(240520353427),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915974803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287764993683,
        "f": 83886081
      },
      "n": "Protection",
      "d": 2184851,
      "h": 240520353427,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "p",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240520353427),
//--TRIMMABLE-BOUNDARY-START(249110288019),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095843987,
        "f": 50331649
      },
      "n": "ProtectionData",
      "d": 2184851,
      "h": 249110288019,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249110288019),
//--TRIMMABLE-BOUNDARY-START(244815320723),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505909395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296354928275,
        "f": 83886081
      },
      "n": "Protection2",
      "d": 2184851,
      "h": 244815320723,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "r",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244815320723),
//--TRIMMABLE-BOUNDARY-START(253405255315),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685778579,
        "f": 50331649
      },
      "n": "ProtectionData2",
      "d": 2184851,
      "h": 253405255315,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253405255315),
//--TRIMMABLE-BOUNDARY-START(68721661587),
    {
      "p": 2864333,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556236435,
        "f": 50331649
      },
      "n": "CoinIdentifier",
      "d": 2184851,
      "h": 68721661587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721661587),
//--TRIMMABLE-BOUNDARY-START(90196498067),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736105619,
        "f": 50331649
      },
      "n": "FrozenAmount",
      "d": 2184851,
      "h": 90196498067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196498067),
//--TRIMMABLE-BOUNDARY-START(60131726995),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376367251,
        "f": 50331649
      },
      "n": "Cashback",
      "d": 2184851,
      "h": 60131726995,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131726995),
//--TRIMMABLE-BOUNDARY-START(223340484243),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231930418835,
        "f": 50331650
      },
      "n": "{1357005}.Amount",
      "o": "LCFCW$IWalletToken$Amount",
      "d": 2184851,
      "h": 223340484243,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(223340484243)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(214750549651),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2184851,
      "h": 214750549651,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214750549651),
//--TRIMMABLE-BOUNDARY-START(81606563475),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2184851,
      "h": 81606563475,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606563475),
//--TRIMMABLE-BOUNDARY-START(85901530771),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2184851
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2184851,
      "h": 85901530771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901530771),
//--TRIMMABLE-BOUNDARY-START(326419699347),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2184851,
      "h": 326419699347,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(326419699347)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(219045516947),
    {
      "t": 1310721,
      "n": "IssuerName",
      "d": 2184851,
      "h": 219045516947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219045516947),
//--TRIMMABLE-BOUNDARY-START(335009633939),
    {
      "t": 1310721,
      "n": "WalletName",
      "d": 2184851,
      "h": 335009633939,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335009633939),
//--TRIMMABLE-BOUNDARY-START(73016628883),
    {
      "t": $.$typeArray($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "n": "coins",
      "d": 2184851,
      "h": 73016628883,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73016628883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51541792403),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2184851,
      "h": 51541792403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541792403)
  ],
  "h": 2184851
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletToken, $.$UlXD.LCPCM.IDoubleProtectedData, $.$UlXD.LCPCM.IProtectedData, $.$$.S.IEquatable$$($.$UlXD.LCPCM.PayCowryTokenModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTokenModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2184851)
        
        

        //--TRIMMABLE-BOUNDARY-START(1595027)
        $asm.$cls(`$UlXD.LCPCM.PayCowryOfflineAccountModel`, ($self) => class PayCowryOfflineAccountModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(369368782483)
            /*WalletHash*/ Protection;
            //--TRIMMABLE-BOUNDARY-END(369368782483)
            
            //--TRIMMABLE-BOUNDARY-START(365073815187)
            /*WalletHash*/ Pin;
            //--TRIMMABLE-BOUNDARY-END(365073815187)
            
            //--TRIMMABLE-BOUNDARY-START(335009044115)
            /*string?*/ Identity = null;
            //--TRIMMABLE-BOUNDARY-END(335009044115)
            
            //--TRIMMABLE-BOUNDARY-START(519692637843)
            /*string?*/ UserName = null;
            //--TRIMMABLE-BOUNDARY-END(519692637843)
            
            //--TRIMMABLE-BOUNDARY-START(98785842835)
            /*string?*/ DeviceId = null;
            //--TRIMMABLE-BOUNDARY-END(98785842835)
            
            //--TRIMMABLE-BOUNDARY-START(107375777427)
            /*string?*/ FirstName = null;
            //--TRIMMABLE-BOUNDARY-END(107375777427)
            
            //--TRIMMABLE-BOUNDARY-START(343598978707)
            /*string?*/ LastName = null;
            //--TRIMMABLE-BOUNDARY-END(343598978707)
            
            //--TRIMMABLE-BOUNDARY-START(360778847891)
            /*string?*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(360778847891)
            
            //--TRIMMABLE-BOUNDARY-START(103080810131)
            /*string?*/ Email = null;
            //--TRIMMABLE-BOUNDARY-END(103080810131)
            
            //--TRIMMABLE-BOUNDARY-START(377958717075)
            /*string?*/ RemoteId = null;
            //--TRIMMABLE-BOUNDARY-END(377958717075)
            
            //--TRIMMABLE-BOUNDARY-START(523987605139)
            /*string?*/ Version = null;
            //--TRIMMABLE-BOUNDARY-END(523987605139)
            
            //--TRIMMABLE-BOUNDARY-START(356483880595)
            /*WalletAddress */ get NetworkAddress()
            {
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletAddress()
                    const $t1 = $.$OJJQ.LCFCW.WalletAddress;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Address = this.Protection.Hash;
                    $i1.DisplayName = this.UserName;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(356483880595)
            
            //--TRIMMABLE-BOUNDARY-START(115965712019)
            /*string? */ get FullName()
            {
                return $.$strNN($.$strNN(this.FirstName) + " ") + $.$strNN(this.LastName);
            }
            //--TRIMMABLE-BOUNDARY-END(115965712019)
            
            //--TRIMMABLE-BOUNDARY-START(511102703251)
            /*string? */ get Title()
            {
                return $.$strNN($.$strNN(this.FirstName) + " ") + $.$strNN(this.LastName);
            }
            //--TRIMMABLE-BOUNDARY-END(511102703251)
            
            //--TRIMMABLE-BOUNDARY-START(94490875539)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(94490875539)
            
            //--TRIMMABLE-BOUNDARY-START(326419109523)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(326419109523)
            
            //--TRIMMABLE-BOUNDARY-START(90195908243)
            /*bool*/ BatchTransfer = false;
            //--TRIMMABLE-BOUNDARY-END(90195908243)
            
            //--TRIMMABLE-BOUNDARY-START(515397670547)
            /*string?*/ TransactionDescription = null;
            //--TRIMMABLE-BOUNDARY-END(515397670547)
            
            //--TRIMMABLE-BOUNDARY-START(85900940947)
            /*int?*/ Amount = null;
            //--TRIMMABLE-BOUNDARY-END(85900940947)
            
            //--TRIMMABLE-BOUNDARY-START(339304011411)
            /*string?*/ InterfaceAddress = null;
            //--TRIMMABLE-BOUNDARY-END(339304011411)
            
            //--TRIMMABLE-BOUNDARY-START(373663749779)
            /*Dictionary<string, object?> */ get ProtectionData()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("Identity", this.Identity);
                    $i2.set_Item("PhoneNumber", this.PhoneNumber);
                    $i2.set_Item("Email", this.Email);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(373663749779)
            
            //--TRIMMABLE-BOUNDARY-START(330714076819)
            /*DataId */ get Identifier()
            {
                return new $.$fPer.LCFCD.DataId().$ctor$3(this.RemoteId, null);
            }
            //--TRIMMABLE-BOUNDARY-END(330714076819)
            
            //--TRIMMABLE-BOUNDARY-START(347893946003)
            /*GeoLocation?*/ Location = null;
            //--TRIMMABLE-BOUNDARY-END(347893946003)
            
            //--TRIMMABLE-BOUNDARY-START(352188913299)
            /*string? */ get Name()
            {
                return this.UserName;
            }
            //--TRIMMABLE-BOUNDARY-END(352188913299)
            
            //--TRIMMABLE-BOUNDARY-START(111670744723)
            static /*PayCowryOfflineAccountModel */ From(/*PayCowryAccountFeatureModel*/ account)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670744723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$UlXD.LCPCM.PayCowryOfflineAccountModel()
                    const $t3 = $.$UlXD.LCPCM.PayCowryOfflineAccountModel;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Pin = account.Pin;
                    $i3.UserName = ($.$cast(account.Parent, $.$Iaui.LCFCM.UserModel)).Name;
                    $i3.FirstName = account.FirstName;
                    $i3.LastName = account.LastName;
                    $i3.PhoneNumber = account.PhoneNumber;
                    $i3.Email = account.Email;
                    $i3.Version = account.Version;
                    $i3.RemoteId = $.$dspc(($.$cast(account.Parent, $.$Iaui.LCFCM.UserModel)).Identifier.Id, $.$$.S.Object, ($t) => $t.ToString);
                    return $i3;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(111670744723)
            
            //--TRIMMABLE-BOUNDARY-START(17180481171)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.ProtectionData.get
            get LCPCM$IProtectedData$ProtectionData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770415763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectionData;
            }
            //--TRIMMABLE-BOUNDARY-END(17180481171)
            
            //--TRIMMABLE-BOUNDARY-START(8590546579)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.get
            get LCPCM$IProtectedData$Protection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Protection;
            }
            //--TRIMMABLE-BOUNDARY-END(8590546579)
            
            //--TRIMMABLE-BOUNDARY-START(34360350355)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.set
            set LCPCM$IProtectedData$Protection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Protection = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360350355)
            
            //--TRIMMABLE-BOUNDARY-START(8590505165)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder.NetworkAddress.get
            get LCFCW$IWalletHolder$NetworkAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885472461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NetworkAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(8590505165)
            
            //--TRIMMABLE-BOUNDARY-START(21479917910)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Identifier.get
            get LCFCC$2$IContact$Identifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544688982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(21479917910)
            
            //--TRIMMABLE-BOUNDARY-START(47249721686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.PhoneNumber.get
            get LCFCC$2$IContact$PhoneNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64429590870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhoneNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(47249721686)
            
            //--TRIMMABLE-BOUNDARY-START(12889983318)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Email.get
            get LCFCC$2$IContact$Email()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300048726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(12889983318)
            
            //--TRIMMABLE-BOUNDARY-START(38659787094)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Location.get
            get LCFCC$2$IContact$Location()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60134623574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Location;
            }
            //--TRIMMABLE-BOUNDARY-END(38659787094)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(81605973651)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605973651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605973651)
            
            //--TRIMMABLE-BOUNDARY-START(81605973651)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(81605973651)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(369368782483)
                this.Protection = $.$default($.$OJJQ.LCFCW.WalletHash);
                //--TRIMMABLE-BOUNDARY-END(369368782483)
                
                //--TRIMMABLE-BOUNDARY-START(365073815187)
                this.Pin = $.$default($.$OJJQ.LCFCW.WalletHash);
                //--TRIMMABLE-BOUNDARY-END(365073815187)
                
                //--TRIMMABLE-BOUNDARY-START(326419109523)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(326419109523)
                
            }
            static $h = 1595027;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(369368782483),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270584534675,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 472447997587,
        "f": 83886081
      },
      "n": "Protection",
      "d": 1595027,
      "h": 369368782483,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(369368782483),
//--TRIMMABLE-BOUNDARY-START(365073815187),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261994600083,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 463858062995,
        "f": 83886081
      },
      "n": "Pin",
      "d": 1595027,
      "h": 365073815187,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(365073815187),
//--TRIMMABLE-BOUNDARY-START(335009044115),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865057939,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429498324627,
        "f": 83886081
      },
      "n": "Identity",
      "d": 1595027,
      "h": 335009044115,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335009044115),
//--TRIMMABLE-BOUNDARY-START(519692637843),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313534207635,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 498217801363,
        "f": 83886081
      },
      "n": "UserName",
      "d": 1595027,
      "h": 519692637843,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(519692637843),
//--TRIMMABLE-BOUNDARY-START(98785842835),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325450387,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 403728520851,
        "f": 83886081
      },
      "n": "DeviceId",
      "d": 1595027,
      "h": 98785842835,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785842835),
//--TRIMMABLE-BOUNDARY-START(107375777427),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505319571,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 420908390035,
        "f": 83886081
      },
      "n": "FirstName",
      "d": 1595027,
      "h": 107375777427,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375777427),
//--TRIMMABLE-BOUNDARY-START(343598978707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044927123,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 446678193811,
        "f": 83886081
      },
      "n": "LastName",
      "d": 1595027,
      "h": 343598978707,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343598978707),
//--TRIMMABLE-BOUNDARY-START(360778847891),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253404665491,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 455268128403,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 1595027,
      "h": 360778847891,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(360778847891),
//--TRIMMABLE-BOUNDARY-START(103080810131),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915384979,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 412318455443,
        "f": 83886081
      },
      "n": "Email",
      "d": 1595027,
      "h": 103080810131,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080810131),
//--TRIMMABLE-BOUNDARY-START(377958717075),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287764403859,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 481037932179,
        "f": 83886081
      },
      "n": "RemoteId",
      "d": 1595027,
      "h": 377958717075,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(377958717075),
//--TRIMMABLE-BOUNDARY-START(523987605139),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322124142227,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 506807735955,
        "f": 83886081
      },
      "n": "Version",
      "d": 1595027,
      "h": 523987605139,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(523987605139),
//--TRIMMABLE-BOUNDARY-START(356483880595),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244814730899,
        "f": 50331649
      },
      "n": "NetworkAddress",
      "d": 1595027,
      "h": 356483880595,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(356483880595),
//--TRIMMABLE-BOUNDARY-START(115965712019),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095254163,
        "f": 50331649
      },
      "n": "FullName",
      "d": 1595027,
      "h": 115965712019,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965712019),
//--TRIMMABLE-BOUNDARY-START(511102703251),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296354338451,
        "f": 50331649
      },
      "n": "Title",
      "d": 1595027,
      "h": 511102703251,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(511102703251),
//--TRIMMABLE-BOUNDARY-START(94490875539),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735515795,
        "f": 50331649
      },
      "n": "Description",
      "d": 1595027,
      "h": 94490875539,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490875539),
//--TRIMMABLE-BOUNDARY-START(326419109523),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685188755,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1595027,
      "h": 326419109523,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(326419109523),
//--TRIMMABLE-BOUNDARY-START(90195908243),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145581203,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 395138586259,
        "f": 83886081
      },
      "n": "BatchTransfer",
      "d": 1595027,
      "h": 90195908243,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195908243),
//--TRIMMABLE-BOUNDARY-START(515397670547),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304944273043,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 489627866771,
        "f": 83886081
      },
      "n": "TransactionDescription",
      "d": 1595027,
      "h": 515397670547,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(515397670547),
//--TRIMMABLE-BOUNDARY-START(85900940947),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555646611,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386548651667,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1595027,
      "h": 85900940947,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900940947),
//--TRIMMABLE-BOUNDARY-START(339304011411),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454992531,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 438088259219,
        "f": 83886081
      },
      "n": "InterfaceAddress",
      "d": 1595027,
      "h": 339304011411,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339304011411),
//--TRIMMABLE-BOUNDARY-START(373663749779),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279174469267,
        "f": 50331649
      },
      "n": "ProtectionData",
      "d": 1595027,
      "h": 373663749779,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(373663749779),
//--TRIMMABLE-BOUNDARY-START(330714076819),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275123347,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 1595027,
      "h": 330714076819,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330714076819),
//--TRIMMABLE-BOUNDARY-START(347893946003),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634861715,
        "f": 50331649
      },
      "n": "Location",
      "d": 1595027,
      "h": 347893946003,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347893946003),
//--TRIMMABLE-BOUNDARY-START(352188913299),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224796307,
        "f": 50331649
      },
      "n": "Name",
      "d": 1595027,
      "h": 352188913299,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(352188913299)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111670744723),
    {
      "r": 1595027,
      "p": [
        {
          "n": "account",
          "p": 677523
        }
      ],
      "n": "From",
      "d": 1595027,
      "h": 111670744723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111670744723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(81605973651),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1595027,
      "h": 81605973651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605973651)
  ],
  "h": 1595027
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UlXD.LCPCM.IProtectedData, $.$OJJQ.LCFCW.IWalletHolder, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryOfflineAccountModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1595027)
        
        

        //--TRIMMABLE-BOUNDARY-START(284307)
        $asm.$str(`$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel`, ($self) => class CommunityPayCowryRegisterResponseModel extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(51539891859)
            /*DecodedAuthenticationTicket?*/ Ticket = null;
            //--TRIMMABLE-BOUNDARY-END(51539891859)
            
            //--TRIMMABLE-BOUNDARY-START(55834859155)
            /*UserModel*/ User = null;
            //--TRIMMABLE-BOUNDARY-END(55834859155)
            
            //--TRIMMABLE-BOUNDARY-START(12885186195)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885186195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885186195)
            
            //--TRIMMABLE-BOUNDARY-START(12885186195)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885186195)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Ticket = this.Ticket;
                copy.User = this.User;
                return copy;
            }
            static $h = 284307;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539891859),
    {
      "p": 1130882,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475120787,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38654989971,
        "f": 83886081
      },
      "n": "Ticket",
      "d": 284307,
      "h": 51539891859,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539891859),
//--TRIMMABLE-BOUNDARY-START(55834859155),
    {
      "p": 23799126,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065055379,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244924563,
        "f": 83886081
      },
      "n": "User",
      "d": 284307,
      "h": 55834859155,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834859155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885186195),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 284307,
      "h": 12885186195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885186195)
  ],
  "h": 284307
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}CommunityPayCowryRegisterResponseModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(284307)
        
        

        //--TRIMMABLE-BOUNDARY-START(3495571)
        $asm.$cls(`$UlXD.LCPCS.IPayCowryAccountRemoteService_Mocking`, ($self) => class IPayCowryAccountRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298462867)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298462867);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298462867)
            
            //--TRIMMABLE-BOUNDARY-START(8593430163)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel>> */ LCPCS$IPayCowryAccountRemoteService$Login(/*string*/ email, /*string*/ password)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593430163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$UlXD.LCPCS.IPayCowryAccountRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel).$type;
                    $i1.MethodName = "Login";
                    return $i1;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, email), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593430163)
            
            //--TRIMMABLE-BOUNDARY-START(12888397459)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel>> */ LCPCS$IPayCowryAccountRemoteService$Register(/*string*/ email, /*string*/ userName, /*string?*/ password, /*LivingThing.Core.Frameworks.Common.Models.UserModel*/ user)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888397459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$UlXD.LCPCS.IPayCowryAccountRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel).$type;
                    $i2.MethodName = "Register";
                    return $i2;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, email), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, userName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Iaui.LCFCM.UserModel.$type, user) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888397459)
            
            static $h = 3495571;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298462867),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3495571,
      "h": 4298462867,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298462867)
  ],
  "h": 3495571
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$UlXD.LCPCS.IPayCowryAccountRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.IPayCowryAccountRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}IPayCowryAccountRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3495571)
        
        

        //--TRIMMABLE-BOUNDARY-START(3626643)
        $asm.$cls(`$UlXD.LCPCS.IPayCowryRemoteService_Mocking`, ($self) => class IPayCowryRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298593939)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298593939);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298593939)
            
            //--TRIMMABLE-BOUNDARY-START(34363365011)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<string>> */ LCPCS$IPayCowryRemoteService$Transfer(/*LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel*/ sender, /*LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel*/ recipient, /*double*/ amount, /*string*/ pinCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363365011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$UlXD.LCPCS.IPayCowryRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String).$type;
                    $i1.MethodName = "Transfer";
                    return $i1;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, sender), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, recipient), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, pinCode) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34363365011)
            
            //--TRIMMABLE-BOUNDARY-START(12888528531)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel>> */ LCPCS$IPayCowryRemoteService$BuyTokens(/*string*/ transactionId, /*LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel*/ account, /*double*/ amount, /*System.Collections.Generic.Dictionary<int, int>?*/ denominations, /*string*/ password)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888528531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$UlXD.LCPCS.IPayCowryRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel).$type;
                    $i2.MethodName = "BuyTokens";
                    return $i2;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, account), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Int32).$type, denominations), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888528531)
            
            //--TRIMMABLE-BOUNDARY-START(30068397715)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCPCS$IPayCowryRemoteService$SellTokens(/*string*/ transactionId, /*LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel*/ account, /*double*/ amount, /*System.Collections.Generic.IEnumerable<LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel>*/ tokens)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068397715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$UlXD.LCPCS.IPayCowryRemoteService.$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i3.MethodName = "SellTokens";
                    return $i3;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, account), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel).$type, tokens) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30068397715)
            
            //--TRIMMABLE-BOUNDARY-START(25773430419)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel>> */ LCPCS$IPayCowryRemoteService$GetTokens(/*LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel*/ account, /*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773430419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$UlXD.LCPCS.IPayCowryRemoteService.$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel).$type;
                    $i4.MethodName = "GetTokens";
                    return $i4;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$UlXD.LCPCM.PayCowryTokenModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, account), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773430419)
            
            //--TRIMMABLE-BOUNDARY-START(8593561235)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Data.BankTransferResult>> */ LCPCS$IPayCowryRemoteService$BankTransfer(/*LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel*/ account, /*double*/ amount, /*LivingThing.Core.Frameworks.Common.Data.BankAccount*/ bankAccount, /*string*/ password, /*string*/ transactionDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593561235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$UlXD.LCPCS.IPayCowryRemoteService.$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult).$type;
                    $i5.MethodName = "BankTransfer";
                    return $i5;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, account), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.BankAccount.$type, $.$clone(bankAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593561235)
            
            //--TRIMMABLE-BOUNDARY-START(21478463123)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Models.PaymentModel>> */ LCPCS$IPayCowryRemoteService$GetSpinWheelParticipants(/*System.DateTime?*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478463123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$UlXD.LCPCS.IPayCowryRemoteService.$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.PaymentModel).$type;
                    $i6.MethodName = "GetSpinWheelParticipants";
                    return $i6;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.PaymentModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeNullable($.$$.S.DateTime).$type, $.$clone(date)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478463123)
            
            //--TRIMMABLE-BOUNDARY-START(17183495827)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<string>> */ LCPCS$IPayCowryRemoteService$GetBackups(/*string*/ mAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183495827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$UlXD.LCPCS.IPayCowryRemoteService.$type;
                    $i7.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.String).$type;
                    $i7.MethodName = "GetBackups";
                    return $i7;
                })();
                return this.InvokeAsync($.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.String), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, mAddress) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183495827)
            
            static $h = 3626643;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298593939),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3626643,
      "h": 4298593939,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298593939)
  ],
  "h": 3626643
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$UlXD.LCPCS.IPayCowryRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Services.IPayCowryRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Services${separator}IPayCowryRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3626643)
        
        

        //--TRIMMABLE-BOUNDARY-START(939667)
        $asm.$str(`$UlXD.LCPCM.PayCowryCurrency`, ($self) => class PayCowryCurrency extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static PayCowry = 0;
            static Wallet = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(939667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "PayCowry": 0n,
                    "Wallet": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295906963)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295906963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295906963)
            
            //--TRIMMABLE-BOUNDARY-START(4295906963)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295906963)
            
            static $h = 939667;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590874259),
    {
      "t": 939667,
      "n": "PayCowry",
      "d": 939667,
      "h": 8590874259,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590874259),
//--TRIMMABLE-BOUNDARY-START(12885841555),
    {
      "t": 939667,
      "n": "Wallet",
      "d": 939667,
      "h": 12885841555,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885841555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295906963),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 939667,
      "h": 4295906963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295906963)
  ],
  "h": 939667
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryCurrency`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryCurrency`; }
        });
        //--TRIMMABLE-BOUNDARY-END(939667)
        
        

        //--TRIMMABLE-BOUNDARY-START(2840211)
        $asm.$str(`$UlXD.LCPCM.PayCowryTransactionType`, ($self) => class PayCowryTransactionType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Offline = 0;
            static Online = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2840211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Offline": 0n,
                    "Online": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297807507)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297807507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297807507)
            
            //--TRIMMABLE-BOUNDARY-START(4297807507)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297807507)
            
            static $h = 2840211;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592774803),
    {
      "t": 2840211,
      "n": "Offline",
      "d": 2840211,
      "h": 8592774803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592774803),
//--TRIMMABLE-BOUNDARY-START(12887742099),
    {
      "t": 2840211,
      "n": "Online",
      "d": 2840211,
      "h": 12887742099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887742099)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297807507),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2840211,
      "h": 4297807507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297807507)
  ],
  "h": 2840211
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTransactionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2840211)
        
        

        //--TRIMMABLE-BOUNDARY-START(2446995)
        $asm.$str(`$UlXD.LCPCM.PayCowryTokenState`, ($self) => class PayCowryTokenState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Created = 0;
            static Owned = 1;
            static TransferingOut = 2;
            static TransferedOut = 3;
            static ReceivedIn = 4;
            static Deleted = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2446995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Created": 0n,
                    "Owned": 1n,
                    "TransferingOut": 2n,
                    "TransferedOut": 3n,
                    "ReceivedIn": 4n,
                    "Deleted": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297414291)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297414291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297414291)
            
            //--TRIMMABLE-BOUNDARY-START(4297414291)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297414291)
            
            static $h = 2446995;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592381587),
    {
      "t": 2446995,
      "n": "Created",
      "d": 2446995,
      "h": 8592381587,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592381587),
//--TRIMMABLE-BOUNDARY-START(17182316179),
    {
      "t": 2446995,
      "n": "Owned",
      "d": 2446995,
      "h": 17182316179,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182316179),
//--TRIMMABLE-BOUNDARY-START(30067218067),
    {
      "t": 2446995,
      "n": "TransferingOut",
      "d": 2446995,
      "h": 30067218067,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067218067),
//--TRIMMABLE-BOUNDARY-START(25772250771),
    {
      "t": 2446995,
      "n": "TransferedOut",
      "d": 2446995,
      "h": 25772250771,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772250771),
//--TRIMMABLE-BOUNDARY-START(21477283475),
    {
      "t": 2446995,
      "n": "ReceivedIn",
      "d": 2446995,
      "h": 21477283475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477283475),
//--TRIMMABLE-BOUNDARY-START(12887348883),
    {
      "t": 2446995,
      "n": "Deleted",
      "d": 2446995,
      "h": 12887348883,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887348883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297414291),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2446995,
      "h": 4297414291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297414291)
  ],
  "h": 2446995
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTokenState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTokenState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2446995)
        
        

        //--TRIMMABLE-BOUNDARY-START(677523)
        $asm.$cls(`$UlXD.LCPCM.PayCowryAccountFeatureModel`, ($self) => class PayCowryAccountFeatureModel extends $.$Iaui.LCFCM.DataFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(176094336659)
            /*string? */ get Identity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489958035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "Identity", null);
            }
            /*string? */ set Identity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223878803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Identity");
            }
            //--TRIMMABLE-BOUNDARY-END(176094336659)
            
            //--TRIMMABLE-BOUNDARY-START(25770481299)
            /*string? */ get FirstName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720154259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "FirstName", null);
            }
            /*string? */ set FirstName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633944211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "FirstName");
            }
            //--TRIMMABLE-BOUNDARY-END(25770481299)
            
            //--TRIMMABLE-BOUNDARY-START(180389303955)
            /*string? */ get LastName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079892627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "LastName", null);
            }
            /*string? */ set LastName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813813395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "LastName");
            }
            //--TRIMMABLE-BOUNDARY-END(180389303955)
            
            //--TRIMMABLE-BOUNDARY-START(188979238547)
            /*string? */ get PhoneNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259761811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "PhoneNumber", null);
            }
            /*string? */ set PhoneNumber(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403747987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "PhoneNumber");
            }
            //--TRIMMABLE-BOUNDARY-END(188979238547)
            
            //--TRIMMABLE-BOUNDARY-START(21475514003)
            /*string? */ get Email()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130219667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "Email", null);
            }
            /*string? */ set Email(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044009619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Email");
            }
            //--TRIMMABLE-BOUNDARY-END(21475514003)
            
            //--TRIMMABLE-BOUNDARY-START(193274205843)
            /*WalletHash */ get Pin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849696403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OJJQ.LCFCW.WalletHash.op_Implicit$1(this.GetProperty($.$$.S.String, "Pin", null));
            }
            /*WalletHash */ set Pin(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993682579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, $.$OJJQ.LCFCW.WalletHash.op_Implicit(value), "Pin");
            }
            //--TRIMMABLE-BOUNDARY-END(193274205843)
            
            //--TRIMMABLE-BOUNDARY-START(17180546707)
            /*string? */ get DeviceId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540285075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "DeviceId", null);
            }
            /*string? */ set DeviceId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454075027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "DeviceId");
            }
            //--TRIMMABLE-BOUNDARY-END(17180546707)
            
            //--TRIMMABLE-BOUNDARY-START(287763486355)
            /*string */ get Version()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209434771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "Version", "1.0");
            }
            /*string */ set Version(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173551763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Version");
            }
            //--TRIMMABLE-BOUNDARY-END(287763486355)
            
            //--TRIMMABLE-BOUNDARY-START(184684271251)
            /*WalletAddress */ get NetworkAddress()
            {
                return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1(this.Protection.Hash);
            }
            //--TRIMMABLE-BOUNDARY-END(184684271251)
            
            //--TRIMMABLE-BOUNDARY-START(34360415891)
            /*string */ get FullName()
            {
                return `${$.$strNN(this.FirstName)} ${$.$strNN(this.LastName)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(34360415891)
            
            //--TRIMMABLE-BOUNDARY-START(197569173139)
            /*WalletHash */ get Protection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439630995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OJJQ.LCFCW.WalletHash.op_Implicit$1(this.GetProperty($.$$.S.String, "Protection", null));
            }
            /*WalletHash */ set Protection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583617171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, $.$OJJQ.LCFCW.WalletHash.op_Implicit(value), "Protection");
            }
            //--TRIMMABLE-BOUNDARY-END(197569173139)
            
            //--TRIMMABLE-BOUNDARY-START(201864140435)
            /*Dictionary<string, object?> */ get ProtectionData()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Identity", this.Identity);
                    $i1.set_Item("PhoneNumber", this.PhoneNumber);
                    $i1.set_Item("Email", this.Email);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(201864140435)
            
            //--TRIMMABLE-BOUNDARY-START(283468519059)
            /*string? */ get Title()
            {
                return ($.$cast(this.Parent, $.$Iaui.LCFCM.UserModel)).Title;
            }
            //--TRIMMABLE-BOUNDARY-END(283468519059)
            
            //--TRIMMABLE-BOUNDARY-START(12885579411)
            /*string? */ get Description()
            {
                return ($.$cast(this.Parent, $.$Iaui.LCFCM.UserModel)).Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12885579411)
            
            //--TRIMMABLE-BOUNDARY-START(171799369363)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(171799369363)
            
            //--TRIMMABLE-BOUNDARY-START(30065448595)
            static /*PayCowryAccountFeatureModel? */ From(/*IDataModel*/ user, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065448595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$UlXD.LCPCM.PayCowryAccountFeatureModel, ($.$cast(user, $.$Iaui.LCFCM.DataModel)), $.$UlXD.LCPCM.PayCowryAccountFeatureModel.GetFeatureKey(context), createIfNotExist);
            }
            //--TRIMMABLE-BOUNDARY-END(30065448595)
            
            //--TRIMMABLE-BOUNDARY-START(167504402067)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504402067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$strNN("$"/*DataFeatureModel.PrefixIdentifier*/) + "PayCowry";
            }
            //--TRIMMABLE-BOUNDARY-END(167504402067)
            
            //--TRIMMABLE-BOUNDARY-START(17180481171)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.ProtectionData.get
            get LCPCM$IProtectedData$ProtectionData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770415763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProtectionData;
            }
            //--TRIMMABLE-BOUNDARY-END(17180481171)
            
            //--TRIMMABLE-BOUNDARY-START(8590546579)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.get
            get LCPCM$IProtectedData$Protection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Protection;
            }
            //--TRIMMABLE-BOUNDARY-END(8590546579)
            
            //--TRIMMABLE-BOUNDARY-START(34360350355)
            //Generated interface implemetation for LivingThing.Core.PayCowry.Common.Models.IProtectedData.Protection.set
            set LCPCM$IProtectedData$Protection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475448467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Protection = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360350355)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$UlXD.LCPCM.PayCowryAccountFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$UlXD.LCPCM.PayCowryAccountFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(8590612115)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590612115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590612115)
            
            //--TRIMMABLE-BOUNDARY-START(8590612115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590612115)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(171799369363)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(171799369363)
                
            }
            static $h = 677523;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.DataFeatureModel$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(176094336659),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489958035,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223878803,
        "f": 83886081
      },
      "n": "Identity",
      "d": 677523,
      "h": 176094336659,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094336659),
//--TRIMMABLE-BOUNDARY-START(25770481299),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720154259,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633944211,
        "f": 83886081
      },
      "n": "FirstName",
      "d": 677523,
      "h": 25770481299,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770481299),
//--TRIMMABLE-BOUNDARY-START(180389303955),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079892627,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813813395,
        "f": 83886081
      },
      "n": "LastName",
      "d": 677523,
      "h": 180389303955,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389303955),
//--TRIMMABLE-BOUNDARY-START(188979238547),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259761811,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403747987,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 677523,
      "h": 188979238547,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979238547),
//--TRIMMABLE-BOUNDARY-START(21475514003),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130219667,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044009619,
        "f": 83886081
      },
      "n": "Email",
      "d": 677523,
      "h": 21475514003,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475514003),
//--TRIMMABLE-BOUNDARY-START(193274205843),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849696403,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993682579,
        "f": 83886081
      },
      "n": "Pin",
      "d": 677523,
      "h": 193274205843,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274205843),
//--TRIMMABLE-BOUNDARY-START(17180546707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540285075,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454075027,
        "f": 83886081
      },
      "n": "DeviceId",
      "d": 677523,
      "h": 17180546707,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180546707),
//--TRIMMABLE-BOUNDARY-START(287763486355),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209434771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173551763,
        "f": 83886081
      },
      "n": "Version",
      "d": 677523,
      "h": 287763486355,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287763486355),
//--TRIMMABLE-BOUNDARY-START(184684271251),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669827219,
        "f": 50331649
      },
      "n": "NetworkAddress",
      "d": 677523,
      "h": 184684271251,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684271251),
//--TRIMMABLE-BOUNDARY-START(34360415891),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310088851,
        "f": 50331649
      },
      "n": "FullName",
      "d": 677523,
      "h": 34360415891,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360415891),
//--TRIMMABLE-BOUNDARY-START(197569173139),
    {
      "p": 2798797,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439630995,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583617171,
        "f": 83886081
      },
      "n": "Protection",
      "d": 677523,
      "h": 197569173139,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569173139),
//--TRIMMABLE-BOUNDARY-START(201864140435),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029565587,
        "f": 50331649
      },
      "n": "ProtectionData",
      "d": 677523,
      "h": 201864140435,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864140435),
//--TRIMMABLE-BOUNDARY-START(283468519059),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619500179,
        "f": 50331649
      },
      "n": "Title",
      "d": 677523,
      "h": 283468519059,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283468519059),
//--TRIMMABLE-BOUNDARY-START(12885579411),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950350483,
        "f": 50331649
      },
      "n": "Description",
      "d": 677523,
      "h": 12885579411,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885579411),
//--TRIMMABLE-BOUNDARY-START(171799369363),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900023443,
        "f": 50331649
      },
      "n": "Icon",
      "d": 677523,
      "h": 171799369363,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799369363)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065448595),
    {
      "r": 677523,
      "p": [
        {
          "n": "user",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 677523,
      "h": 30065448595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065448595),
//--TRIMMABLE-BOUNDARY-START(167504402067),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 677523,
      "h": 167504402067,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167504402067)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590612115),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 677523,
      "h": 8590612115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590612115)
  ],
  "h": 677523
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$UlXD.LCPCM.IProtectedData, $.$fPer.LCFCD.IDataFeatureModel$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryAccountFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(677523)
        
        

        //--TRIMMABLE-BOUNDARY-START(1201811)
        $asm.$cls(`$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor`, ($self) => class PayCowryDenominationModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryDenominationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296169107)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296169107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.PayCowryDenominationModel, this, factory);
                    }, $MINUNe ??= {"r":65537,"n":"","d":1201811,"h":0,"f":17825794}), 0, "PayCowryDenominationModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_PayCowryDenominationModel_LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModelTypeDescriptorBuilder.g.cs", "PayCowryDenominationModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296169107)
            
            //--TRIMMABLE-BOUNDARY-START(12886103699)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886103699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Denomination"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryDenominationModel.$type, $.$discardRef(), "Denomination", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Denomination")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Denomination";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$UlXD.LCPCM.PayCowryDenominationModel)).Denomination);
                        }, $OZUTxd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1201811,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Denomination = value.AsDouble();
                        }, $ebBIyj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1201811,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Quantity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryDenominationModel.$type, $.$discardRef(), "Quantity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Quantity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Quantity";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$UlXD.LCPCM.PayCowryDenominationModel)).Quantity);
                        }, $PHNZoa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1201811,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Quantity = value.AsInt();
                        }, $DtnROd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1201811,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryDenominationModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Amount";
                        $i5.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$UlXD.LCPCM.PayCowryDenominationModel)).Amount);
                        }, $eGObQb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1201811,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886103699)
            
            //--TRIMMABLE-BOUNDARY-START(17181070995)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181070995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Denomination = _target.Denomination;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Denomination"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Denomination, ($v) => _Denomination = $v, $.$$.S.Double)))
                    {
                        _target.Denomination = _Denomination;
                    }
                }
                {
                    /*var*/ let _Quantity = _target.Quantity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Quantity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Quantity, ($v) => _Quantity = $v, $.$$.S.Int32)))
                    {
                        _target.Quantity = _Quantity;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Amount, ($v) => _Amount = $v, $.$$.S.Double)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181070995)
            
            //--TRIMMABLE-BOUNDARY-START(8591136403)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591136403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$UlXD.LCPCM.PayCowryDenominationModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.PayCowryDenominationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryDenominationModel)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.PayCowryDenominationModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryDenominationModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.PayCowryDenominationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryDenominationModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591136403)
            
            static $h = 1201811;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryDenominationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886103699),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1201811,
      "h": 12886103699,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886103699),
//--TRIMMABLE-BOUNDARY-START(17181070995),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1070739,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1201811,
      "h": 17181070995,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181070995),
//--TRIMMABLE-BOUNDARY-START(8591136403),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1070739,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1201811,
      "h": 8591136403,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591136403)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296169107),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1201811,
      "h": 4296169107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296169107)
  ],
  "h": 1201811
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.PayCowryDenominationModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryDenominationModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryDenominationModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1201811)
        
        

        //--TRIMMABLE-BOUNDARY-START(1463955)
        $asm.$cls(`$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor`, ($self) => class PayCowryLedgerModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryLedgerModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296431251)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296431251);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.PayCowryLedgerModel, this, factory);
                    }, $LRQToe ??= {"r":65537,"n":"","d":1463955,"h":0,"f":17825794}), 0, "PayCowryLedgerModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_PayCowryLedgerModel_LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModelTypeDescriptorBuilder.g.cs", "PayCowryLedgerModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296431251)
            
            //--TRIMMABLE-BOUNDARY-START(12886365843)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886365843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastKnownWalletBalance"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryLedgerModel.$type, $.$discardRef(), "LastKnownWalletBalance", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastKnownWalletBalance")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "LastKnownWalletBalance";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$UlXD.LCPCM.PayCowryLedgerModel)).LastKnownWalletBalance);
                        }, $JgmnEd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1463955,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LastKnownWalletBalance = value.AsDouble();
                        }, $wEFwke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1463955,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Denominations"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryLedgerModel.$type, $.$discardRef(), "Denominations", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Denominations")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Denominations";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel), ($.$cast(target, $.$UlXD.LCPCM.PayCowryLedgerModel)).Denominations);
                        }, $Hbgiuc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1463955,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Denominations = value.AsReference($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel));
                        }, $iDzjRd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1463955,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tokens"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryLedgerModel.$type, $.$discardRef(), "Tokens", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tokens")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Tokens";
                        $i5.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), ($.$cast(target, $.$UlXD.LCPCM.PayCowryLedgerModel)).Tokens);
                        }, $mVJPbg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1463955,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Tokens = value.AsReference($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel));
                        }, $xxPJBe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1463955,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Transactions"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryLedgerModel.$type, $.$discardRef(), "Transactions", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Transactions")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Transactions";
                        $i7.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel), ($.$cast(target, $.$UlXD.LCPCM.PayCowryLedgerModel)).Transactions);
                        }, $RAkAxc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1463955,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Transactions = value.AsReference($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel));
                        }, $kaYrjd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1463955,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886365843)
            
            //--TRIMMABLE-BOUNDARY-START(17181333139)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181333139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _LastKnownWalletBalance = _target.LastKnownWalletBalance;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastKnownWalletBalance"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _LastKnownWalletBalance, ($v) => _LastKnownWalletBalance = $v, $.$$.S.Double)))
                    {
                        _target.LastKnownWalletBalance = _LastKnownWalletBalance;
                    }
                }
                {
                    /*var*/ let _Denominations = _target.Denominations;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Denominations"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel), $.$UlXD.LCPCM.PayCowryDenominationModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel), $.$UlXD.LCPCM.PayCowryDenominationModel, property, $.$ref(() => _Denominations, ($v) => _Denominations = $v, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel))))
                    {
                        _target.Denominations = _Denominations;
                        if (_Denominations !== null)
                        {
                            let $en11 = _Denominations.SCG$IEnumerable$$$GetEnumerator();
                            while ($en11.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en11.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$UlXD.LCPCM.PayCowryDenominationModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel), $.$UlXD.LCPCM.PayCowryDenominationModel, property, $.$ref(() => _Denominations, ($v) => _Denominations = $v, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryDenominationModel)));
                    }
                }
                {
                    /*var*/ let _Tokens = _target.Tokens;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tokens"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), $.$UlXD.LCPCM.PayCowryTokenModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), $.$UlXD.LCPCM.PayCowryTokenModel, property, $.$ref(() => _Tokens, ($v) => _Tokens = $v, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel))))
                    {
                        _target.Tokens = _Tokens;
                        if (_Tokens !== null)
                        {
                            let $en16 = _Tokens.SCG$IEnumerable$$$GetEnumerator();
                            while ($en16.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en16.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$UlXD.LCPCM.PayCowryTokenModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel), $.$UlXD.LCPCM.PayCowryTokenModel, property, $.$ref(() => _Tokens, ($v) => _Tokens = $v, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTokenModel)));
                    }
                }
                {
                    /*var*/ let _Transactions = _target.Transactions;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Transactions"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel), $.$UlXD.LCPCM.PayCowryTransactionModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel), $.$UlXD.LCPCM.PayCowryTransactionModel, property, $.$ref(() => _Transactions, ($v) => _Transactions = $v, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel))))
                    {
                        _target.Transactions = _Transactions;
                        if (_Transactions !== null)
                        {
                            let $en21 = _Transactions.SCG$IEnumerable$$$GetEnumerator();
                            while ($en21.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en21.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$UlXD.LCPCM.PayCowryTransactionModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel), $.$UlXD.LCPCM.PayCowryTransactionModel, property, $.$ref(() => _Transactions, ($v) => _Transactions = $v, $.$$.SCG.IEnumerable$$($.$UlXD.LCPCM.PayCowryTransactionModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181333139)
            
            //--TRIMMABLE-BOUNDARY-START(8591398547)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591398547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$UlXD.LCPCM.PayCowryLedgerModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.PayCowryLedgerModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryLedgerModel)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.PayCowryLedgerModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryLedgerModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.PayCowryLedgerModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryLedgerModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591398547)
            
            static $h = 1463955;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryLedgerModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886365843),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1463955,
      "h": 12886365843,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886365843),
//--TRIMMABLE-BOUNDARY-START(17181333139),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1332883,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1463955,
      "h": 17181333139,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181333139),
//--TRIMMABLE-BOUNDARY-START(8591398547),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1332883,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1463955,
      "h": 8591398547,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591398547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296431251),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1463955,
      "h": 4296431251,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296431251)
  ],
  "h": 1463955
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.PayCowryLedgerModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryLedgerModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryLedgerModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1463955)
        
        

        //--TRIMMABLE-BOUNDARY-START(1988243)
        $asm.$cls(`$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor`, ($self) => class PayCowryStorageModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryStorageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296955539)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296955539);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.PayCowryStorageModel, this, factory);
                    }, $QoFDKa ??= {"r":65537,"n":"","d":1988243,"h":0,"f":17825794}), 0, "PayCowryStorageModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_PayCowryStorageModel_LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModelTypeDescriptorBuilder.g.cs", "PayCowryStorageModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296955539)
            
            //--TRIMMABLE-BOUNDARY-START(12886890131)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886890131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Account"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryStorageModel.$type, $.$discardRef(), "Account", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Account")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$UlXD.LCPCM.PayCowryAccountFeatureModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Account";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$UlXD.LCPCM.PayCowryAccountFeatureModel, ($.$cast(target, $.$UlXD.LCPCM.PayCowryStorageModel)).Account);
                        }, $EMNftb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1988243,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Account = value.AsReference($.$UlXD.LCPCM.PayCowryAccountFeatureModel);
                        }, $ZXwruj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1988243,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Ledger"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryStorageModel.$type, $.$discardRef(), "Ledger", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Ledger")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$UlXD.LCPCM.PayCowryLedgerModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Ledger";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$UlXD.LCPCM.PayCowryLedgerModel, ($.$cast(target, $.$UlXD.LCPCM.PayCowryStorageModel)).Ledger);
                        }, $cqUTZf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1988243,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Ledger = value.AsReference($.$UlXD.LCPCM.PayCowryLedgerModel);
                        }, $cZwBak ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1988243,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886890131)
            
            //--TRIMMABLE-BOUNDARY-START(17181857427)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181857427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Account = _target.Account;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Account"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Account, ($v) => _Account = $v, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)))
                    {
                        _target.Account = _Account;
                    }
                }
                {
                    /*var*/ let _Ledger = _target.Ledger;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Ledger"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$UlXD.LCPCM.PayCowryLedgerModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Ledger, ($v) => _Ledger = $v, $.$UlXD.LCPCM.PayCowryLedgerModel)))
                    {
                        _target.Ledger = _Ledger;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181857427)
            
            //--TRIMMABLE-BOUNDARY-START(8591922835)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591922835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$UlXD.LCPCM.PayCowryStorageModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.PayCowryStorageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryStorageModel)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.PayCowryStorageModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryStorageModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.PayCowryStorageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryStorageModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591922835)
            
            static $h = 1988243;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryStorageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886890131),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1988243,
      "h": 12886890131,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886890131),
//--TRIMMABLE-BOUNDARY-START(17181857427),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1857171,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1988243,
      "h": 17181857427,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181857427),
//--TRIMMABLE-BOUNDARY-START(8591922835),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1857171,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1988243,
      "h": 8591922835,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591922835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296955539),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1988243,
      "h": 4296955539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296955539)
  ],
  "h": 1988243
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.PayCowryStorageModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryStorageModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryStorageModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1988243)
        
        

        //--TRIMMABLE-BOUNDARY-START(2709139)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor`, ($self) => class PayCowryTransactionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryTransactionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297676435)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297676435);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.PayCowryTransactionModel, this, factory);
                    }, $FspgIj ??= {"r":65537,"n":"","d":2709139,"h":0,"f":17825794}), 0, "PayCowryTransactionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_PayCowryTransactionModel_LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModelTypeDescriptorBuilder.g.cs", "PayCowryTransactionModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297676435)
            
            //--TRIMMABLE-BOUNDARY-START(12887611027)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887611027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Description";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Description);
                        }, $Nmgujj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Description = value.AsReference($.$$.S.String);
                        }, $ikEsnc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Date"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Date", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Date")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Date";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Date);
                        }, $AvjGhf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Date = value.AsDateTime();
                        }, $DrraQi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Amount";
                        $i5.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Amount);
                        }, $nnVeCb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsInt();
                        }, $qAqtug ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tokens"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Tokens", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tokens")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Tokens";
                        $i7.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Tokens);
                        }, $CLUWVj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Tokens = value.AsReference($.$typeArray($.$$.S.String));
                        }, $sdphlg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sender"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Sender", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sender")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletAddress, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Sender";
                        $i9.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletAddress, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Sender);
                        }, $kLOfFd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Sender = value.AsValue($.$OJJQ.LCFCW.WalletAddress);
                        }, $NmUoVb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Receiver"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Receiver", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Receiver")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletAddress, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Receiver";
                        $i11.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletAddress, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Receiver);
                        }, $wfQuLg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Receiver = value.AsValue($.$OJJQ.LCFCW.WalletAddress);
                        }, $qqyTqk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Version"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Version", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Version")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Version";
                        $i13.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Version);
                        }, $vVKfPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Version = value.AsReference($.$$.S.String);
                        }, $doyotf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProtectionData"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "ProtectionData", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProtectionData")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "ProtectionData";
                        $i15.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).ProtectionData);
                        }, $RgsJIj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Protection"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTransactionModel.$type, $.$discardRef(), "Protection", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Protection")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletHash, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Protection";
                        $i17.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletHash, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTransactionModel)).Protection);
                        }, $YMfPIi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2709139,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Protection = value.AsValue($.$OJJQ.LCFCW.WalletHash);
                        }, $TpNkWj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2709139,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887611027)
            
            //--TRIMMABLE-BOUNDARY-START(17182578323)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182578323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                        _target.Description = _Description;
                    }
                }
                {
                    /*var*/ let _Date = _target.Date;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Date"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Date, ($v) => _Date = $v, null, true)))
                    {
                        _target.Date = _Date;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Amount, ($v) => _Amount = $v, $.$$.S.Int32)))
                    {
                        _target.Amount = _Amount;
                    }
                }
                {
                    /*var*/ let _Tokens = _target.Tokens;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tokens"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Tokens, ($v) => _Tokens = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Tokens = _Tokens;
                        if (_Tokens !== null)
                        {
                            let $i23 = 0;
                            let $arr23 = _Tokens;
                            while ($i23 < $arr23.length)
                            {
                                let item = $arr23[$i23++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Tokens, ($v) => _Tokens = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Sender = _target.Sender;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sender"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletAddress));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletAddress, () => _Sender, ($v) => _Sender = $v, null, true)))
                    {
                        _target.Sender = $.$clone(_Sender);
                    }
                }
                {
                    /*var*/ let _Receiver = _target.Receiver;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Receiver"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletAddress));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletAddress, () => _Receiver, ($v) => _Receiver = $v, null, true)))
                    {
                        _target.Receiver = $.$clone(_Receiver);
                    }
                }
                {
                    /*var*/ let _Version = _target.Version;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Version"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Version, ($v) => _Version = $v, $.$$.S.String)))
                    {
                        _target.Version = _Version;
                    }
                }
                {
                    /*var*/ let _ProtectionData = _target.ProtectionData;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProtectionData"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ProtectionData, ($v) => _ProtectionData = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                    }
                }
                {
                    /*var*/ let _Protection = _target.Protection;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Protection"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletHash));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletHash, () => _Protection, ($v) => _Protection = $v, null, true)))
                    {
                        _target.Protection = $.$clone(_Protection);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182578323)
            
            //--TRIMMABLE-BOUNDARY-START(8592643731)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592643731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$UlXD.LCPCM.PayCowryTransactionModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.PayCowryTransactionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryTransactionModel)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.PayCowryTransactionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryTransactionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.PayCowryTransactionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryTransactionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592643731)
            
            static $h = 2709139;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryTransactionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887611027),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2709139,
      "h": 12887611027,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887611027),
//--TRIMMABLE-BOUNDARY-START(17182578323),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2578067,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2709139,
      "h": 17182578323,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182578323),
//--TRIMMABLE-BOUNDARY-START(8592643731),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2578067,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2709139,
      "h": 8592643731,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592643731)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297676435),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2709139,
      "h": 4297676435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297676435)
  ],
  "h": 2709139
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.PayCowryTransactionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTransactionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTransactionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2709139)
        
        

        //--TRIMMABLE-BOUNDARY-START(2315923)
        $asm.$cls(`$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor`, ($self) => class PayCowryTokenModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryTokenModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297283219)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297283219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.PayCowryTokenModel, this, factory);
                    }, $xEJOOg ??= {"r":65537,"n":"","d":2315923,"h":0,"f":17825794}), 0, "PayCowryTokenModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_PayCowryTokenModel_LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModelTypeDescriptorBuilder.g.cs", "PayCowryTokenModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297283219)
            
            //--TRIMMABLE-BOUNDARY-START(12887217811)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887217811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Version"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "Version", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Version")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Version";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).Version);
                        }, $vrnHNf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Version = value.AsReference($.$$.S.String);
                        }, $xOaRYc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Amount";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).Amount);
                        }, $vwYJXd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsInt();
                        }, $xaQFUc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SerialNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "SerialNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SerialNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "SerialNumber";
                        $i5.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).SerialNumber);
                        }, $TmJEfd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SerialNumber = value.AsReference($.$$.S.String);
                        }, $JeSSUe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SequenceNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "SequenceNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SequenceNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "SequenceNumber";
                        $i7.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$8(($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).SequenceNumber);
                        }, $DwEgka ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SequenceNumber = value.AsLong();
                        }, $EIlWPg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OwnerAddress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "OwnerAddress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OwnerAddress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletAddress, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "OwnerAddress";
                        $i9.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletAddress, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).OwnerAddress);
                        }, $dHrLzb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OwnerAddress = value.AsValue($.$OJJQ.LCFCW.WalletAddress);
                        }, $ytojSf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Protection"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "Protection", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Protection")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletHash, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Protection";
                        $i11.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletHash, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).Protection);
                        }, $hxZVYa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Protection = value.AsValue($.$OJJQ.LCFCW.WalletHash);
                        }, $jhMIGg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProtectionData"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "ProtectionData", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProtectionData")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "ProtectionData";
                        $i13.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).ProtectionData);
                        }, $WoqcTb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Protection2"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "Protection2", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Protection2")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletHash, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Protection2";
                        $i15.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletHash, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).Protection2);
                        }, $YhNDVj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Protection2 = value.AsValue($.$OJJQ.LCFCW.WalletHash);
                        }, $cFEWBh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProtectionData2"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "ProtectionData2", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProtectionData2")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "ProtectionData2";
                        $i17.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).ProtectionData2);
                        }, $rUKjgf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CoinIdentifier"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "CoinIdentifier", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CoinIdentifier")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletIdentifier, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "CoinIdentifier";
                        $i19.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletIdentifier, ($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).CoinIdentifier);
                        }, $aIojHd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FrozenAmount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "FrozenAmount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FrozenAmount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "FrozenAmount";
                        $i21.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).FrozenAmount);
                        }, $SUpuyi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Cashback"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryTokenModel.$type, $.$discardRef(), "Cashback", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Cashback")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "Cashback";
                        $i23.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$UlXD.LCPCM.PayCowryTokenModel)).Cashback);
                        }, $YbqInd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2315923,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887217811)
            
            //--TRIMMABLE-BOUNDARY-START(17182185107)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182185107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Version = _target.Version;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Version"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Version, ($v) => _Version = $v, $.$$.S.String)))
                    {
                        _target.Version = _Version;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Amount, ($v) => _Amount = $v, $.$$.S.Int32)))
                    {
                        _target.Amount = _Amount;
                    }
                }
                {
                    /*var*/ let _SerialNumber = _target.SerialNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SerialNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SerialNumber, ($v) => _SerialNumber = $v, $.$$.S.String)))
                    {
                        _target.SerialNumber = _SerialNumber;
                    }
                }
                {
                    /*var*/ let _SequenceNumber = _target.SequenceNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SequenceNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int64, property, $.$ref(() => _SequenceNumber, ($v) => _SequenceNumber = $v, $.$$.S.Int64)))
                    {
                        _target.SequenceNumber = _SequenceNumber;
                    }
                }
                {
                    /*var*/ let _OwnerAddress = _target.OwnerAddress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OwnerAddress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletAddress));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletAddress, () => _OwnerAddress, ($v) => _OwnerAddress = $v, null, true)))
                    {
                        _target.OwnerAddress = $.$clone(_OwnerAddress);
                    }
                }
                {
                    /*var*/ let _Protection = _target.Protection;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Protection"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletHash));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletHash, () => _Protection, ($v) => _Protection = $v, null, true)))
                    {
                        _target.Protection = $.$clone(_Protection);
                    }
                }
                {
                    /*var*/ let _ProtectionData = _target.ProtectionData;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProtectionData"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ProtectionData, ($v) => _ProtectionData = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                    }
                }
                {
                    /*var*/ let _Protection2 = _target.Protection2;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Protection2"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletHash));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletHash, () => _Protection2, ($v) => _Protection2 = $v, null, true)))
                    {
                        _target.Protection2 = $.$clone(_Protection2);
                    }
                }
                {
                    /*var*/ let _ProtectionData2 = _target.ProtectionData2;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProtectionData2"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ProtectionData2, ($v) => _ProtectionData2 = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                    }
                }
                {
                    /*var*/ let _CoinIdentifier = _target.CoinIdentifier;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CoinIdentifier"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletIdentifier));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletIdentifier, () => _CoinIdentifier, ($v) => _CoinIdentifier = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _FrozenAmount = _target.FrozenAmount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FrozenAmount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _FrozenAmount, ($v) => _FrozenAmount = $v, $.$$.S.Double)))
                    {
                    }
                }
                {
                    /*var*/ let _Cashback = _target.Cashback;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Cashback"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Cashback, ($v) => _Cashback = $v, $.$$.S.Double)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182185107)
            
            //--TRIMMABLE-BOUNDARY-START(8592250515)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592250515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$UlXD.LCPCM.PayCowryTokenModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.PayCowryTokenModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryTokenModel)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.PayCowryTokenModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryTokenModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.PayCowryTokenModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryTokenModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592250515)
            
            static $h = 2315923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryTokenModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887217811),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2315923,
      "h": 12887217811,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887217811),
//--TRIMMABLE-BOUNDARY-START(17182185107),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2184851,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2315923,
      "h": 17182185107,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182185107),
//--TRIMMABLE-BOUNDARY-START(8592250515),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2184851,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2315923,
      "h": 8592250515,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592250515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297283219),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2315923,
      "h": 4297283219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297283219)
  ],
  "h": 2315923
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.PayCowryTokenModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryTokenModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryTokenModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2315923)
        
        

        //--TRIMMABLE-BOUNDARY-START(1726099)
        $asm.$cls(`$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor`, ($self) => class PayCowryOfflineAccountModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryOfflineAccountModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296693395)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296693395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.PayCowryOfflineAccountModel, this, factory);
                    }, $VAVNTh ??= {"r":65537,"n":"","d":1726099,"h":0,"f":17825794}), 0, "PayCowryOfflineAccountModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_PayCowryOfflineAccountModel_LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModelTypeDescriptorBuilder.g.cs", "PayCowryOfflineAccountModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296693395)
            
            //--TRIMMABLE-BOUNDARY-START(12886627987)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886627987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Protection"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Protection", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Protection")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletHash, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Protection";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletHash, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Protection);
                        }, $MkXDKc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Protection = value.AsValue($.$OJJQ.LCFCW.WalletHash);
                        }, $AcgzBc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Pin"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Pin", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Pin")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletHash, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Pin";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletHash, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Pin);
                        }, $vuTzsf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Pin = value.AsValue($.$OJJQ.LCFCW.WalletHash);
                        }, $tpACak ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Identity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Identity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Identity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Identity";
                        $i5.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Identity);
                        }, $CCoMPi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Identity = value.AsReference($.$$.S.String);
                        }, $oQYzTe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UserName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "UserName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UserName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "UserName";
                        $i7.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).UserName);
                        }, $mgTqnd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UserName = value.AsReference($.$$.S.String);
                        }, $QzojFd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DeviceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "DeviceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DeviceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "DeviceId";
                        $i9.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).DeviceId);
                        }, $Nijvbj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DeviceId = value.AsReference($.$$.S.String);
                        }, $TlUHFc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FirstName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "FirstName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FirstName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "FirstName";
                        $i11.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).FirstName);
                        }, $IWnrmc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.FirstName = value.AsReference($.$$.S.String);
                        }, $kDIVnf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "LastName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "LastName";
                        $i13.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).LastName);
                        }, $lCMwYg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LastName = value.AsReference($.$$.S.String);
                        }, $Wpcplh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "PhoneNumber";
                        $i15.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).PhoneNumber);
                        }, $biIDhf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsReference($.$$.S.String);
                        }, $OvmAyd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Email"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Email", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Email")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Email";
                        $i17.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Email);
                        }, $FsxONh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Email = value.AsReference($.$$.S.String);
                        }, $mtAIqk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RemoteId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "RemoteId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RemoteId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "RemoteId";
                        $i19.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).RemoteId);
                        }, $axnfYb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RemoteId = value.AsReference($.$$.S.String);
                        }, $Uwghxj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Version"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Version", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Version")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Version";
                        $i21.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Version);
                        }, $BRDfXi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Version = value.AsReference($.$$.S.String);
                        }, $LvmUbd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NetworkAddress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "NetworkAddress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NetworkAddress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletAddress, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "NetworkAddress";
                        $i23.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletAddress, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).NetworkAddress);
                        }, $ldQdef ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FullName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "FullName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FullName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "FullName";
                        $i25.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).FullName);
                        }, $TdvWCb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "Title";
                        $i27.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Title);
                        }, $GDKhki ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "Description";
                        $i29.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Description);
                        }, $TltVtb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.IconDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t31 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Name = "Icon";
                        $i31.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i31.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFC.IconDescriptor, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Icon);
                        }, $kesZue ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i31;
                    })()), schemas, null, factory);
                    let $en32 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en32.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en32.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BatchTransfer"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "BatchTransfer", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BatchTransfer")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t33 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i33 = new $t33();
                        $i33.$ctor$2();
                        $i33.Name = "BatchTransfer";
                        $i33.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i33.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).BatchTransfer);
                        }, $DAwZAc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i33.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.BatchTransfer = value.AsBool();
                        }, $UVsude ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i33;
                    })()), schemas, null, factory);
                    let $en34 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en34.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en34.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TransactionDescription"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "TransactionDescription", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TransactionDescription")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t35 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i35 = new $t35();
                        $i35.$ctor$2();
                        $i35.Name = "TransactionDescription";
                        $i35.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i35.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).TransactionDescription);
                        }, $BWFXMj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i35.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TransactionDescription = value.AsReference($.$$.S.String);
                        }, $XMtnBf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i35;
                    })()), schemas, null, factory);
                    let $en36 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en36.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en36.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t37 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i37 = new $t37();
                        $i37.$ctor$2();
                        $i37.Name = "Amount";
                        $i37.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i37.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Int32, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Amount);
                        }, $qeyxHb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i37.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsNullableValue($.$$.S.Int32);
                        }, $gDoQpi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i37;
                    })()), schemas, null, factory);
                    let $en38 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en38.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en38.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InterfaceAddress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "InterfaceAddress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InterfaceAddress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t39 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i39 = new $t39();
                        $i39.$ctor$2();
                        $i39.Name = "InterfaceAddress";
                        $i39.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i39.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).InterfaceAddress);
                        }, $keGhyk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        $i39.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.InterfaceAddress = value.AsReference($.$$.S.String);
                        }, $kNAxWk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i39;
                    })()), schemas, null, factory);
                    let $en40 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en40.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en40.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProtectionData"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "ProtectionData", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProtectionData")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t41 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i41 = new $t41();
                        $i41.$ctor$2();
                        $i41.Name = "ProtectionData";
                        $i41.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i41.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).ProtectionData);
                        }, $kWUsEh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i41;
                    })()), schemas, null, factory);
                    let $en42 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en42.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en42.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Identifier"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Identifier", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Identifier")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t43 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i43 = new $t43();
                        $i43.$ctor$2();
                        $i43.Name = "Identifier";
                        $i43.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i43.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Identifier);
                        }, $iloENd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i43;
                    })()), schemas, null, factory);
                    let $en44 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en44.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en44.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Location"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Location", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Location")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDG.GeoLocation, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t45 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i45 = new $t45();
                        $i45.$ctor$2();
                        $i45.Name = "Location";
                        $i45.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i45.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDG.GeoLocation, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Location);
                        }, $mOwhzf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i45;
                    })()), schemas, null, factory);
                    let $en46 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en46.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en46.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryOfflineAccountModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t47 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i47 = new $t47();
                        $i47.$ctor$2();
                        $i47.Name = "Name";
                        $i47.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel";
                        $i47.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)).Name);
                        }, $ndnFqd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1726099,"h":0,"f":17825826});
                        return $i47;
                    })()), schemas, null, factory);
                    let $en48 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en48.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en48.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886627987)
            
            //--TRIMMABLE-BOUNDARY-START(17181595283)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181595283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Protection = _target.Protection;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Protection"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletHash));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletHash, () => _Protection, ($v) => _Protection = $v, null, true)))
                    {
                        _target.Protection = $.$clone(_Protection);
                    }
                }
                {
                    /*var*/ let _Pin = _target.Pin;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Pin"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletHash));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletHash, () => _Pin, ($v) => _Pin = $v, null, true)))
                    {
                        _target.Pin = $.$clone(_Pin);
                    }
                }
                {
                    /*var*/ let _Identity = _target.Identity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Identity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Identity, ($v) => _Identity = $v, $.$$.S.String)))
                    {
                        _target.Identity = _Identity;
                    }
                }
                {
                    /*var*/ let _UserName = _target.UserName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UserName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _UserName, ($v) => _UserName = $v, $.$$.S.String)))
                    {
                        _target.UserName = _UserName;
                    }
                }
                {
                    /*var*/ let _DeviceId = _target.DeviceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DeviceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DeviceId, ($v) => _DeviceId = $v, $.$$.S.String)))
                    {
                        _target.DeviceId = _DeviceId;
                    }
                }
                {
                    /*var*/ let _FirstName = _target.FirstName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FirstName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FirstName, ($v) => _FirstName = $v, $.$$.S.String)))
                    {
                        _target.FirstName = _FirstName;
                    }
                }
                {
                    /*var*/ let _LastName = _target.LastName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _LastName, ($v) => _LastName = $v, $.$$.S.String)))
                    {
                        _target.LastName = _LastName;
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PhoneNumber, ($v) => _PhoneNumber = $v, $.$$.S.String)))
                    {
                        _target.PhoneNumber = _PhoneNumber;
                    }
                }
                {
                    /*var*/ let _Email = _target.Email;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Email"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Email, ($v) => _Email = $v, $.$$.S.String)))
                    {
                        _target.Email = _Email;
                    }
                }
                {
                    /*var*/ let _RemoteId = _target.RemoteId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RemoteId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _RemoteId, ($v) => _RemoteId = $v, $.$$.S.String)))
                    {
                        _target.RemoteId = _RemoteId;
                    }
                }
                {
                    /*var*/ let _Version = _target.Version;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Version"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Version, ($v) => _Version = $v, $.$$.S.String)))
                    {
                        _target.Version = _Version;
                    }
                }
                {
                    /*var*/ let _NetworkAddress = _target.NetworkAddress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NetworkAddress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletAddress));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletAddress, () => _NetworkAddress, ($v) => _NetworkAddress = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _FullName = _target.FullName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FullName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FullName, ($v) => _FullName = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.IconDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.IconDescriptor, () => _Icon, ($v) => _Icon = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _BatchTransfer = _target.BatchTransfer;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BatchTransfer"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _BatchTransfer, ($v) => _BatchTransfer = $v, null, true)))
                    {
                        _target.BatchTransfer = _BatchTransfer;
                    }
                }
                {
                    /*var*/ let _TransactionDescription = _target.TransactionDescription;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TransactionDescription"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _TransactionDescription, ($v) => _TransactionDescription = $v, $.$$.S.String)))
                    {
                        _target.TransactionDescription = _TransactionDescription;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Int32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Int32), () => _Amount, ($v) => _Amount = $v, null, true)))
                    {
                        _target.Amount = _Amount;
                    }
                }
                {
                    /*var*/ let _InterfaceAddress = _target.InterfaceAddress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InterfaceAddress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _InterfaceAddress, ($v) => _InterfaceAddress = $v, $.$$.S.String)))
                    {
                        _target.InterfaceAddress = _InterfaceAddress;
                    }
                }
                {
                    /*var*/ let _ProtectionData = _target.ProtectionData;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProtectionData"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ProtectionData, ($v) => _ProtectionData = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                    }
                }
                {
                    /*var*/ let _Identifier = _target.Identifier;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Identifier"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _Identifier, ($v) => _Identifier = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Location = _target.Location;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Location"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDG.GeoLocation));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Location, ($v) => _Location = $v, $.$fPer.LCFCDG.GeoLocation)))
                    {
                    }
                }
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181595283)
            
            //--TRIMMABLE-BOUNDARY-START(8591660691)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591660691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$UlXD.LCPCM.PayCowryOfflineAccountModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.PayCowryOfflineAccountModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryOfflineAccountModel)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.PayCowryOfflineAccountModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryOfflineAccountModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.PayCowryOfflineAccountModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryOfflineAccountModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591660691)
            
            static $h = 1726099;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryOfflineAccountModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886627987),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1726099,
      "h": 12886627987,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886627987),
//--TRIMMABLE-BOUNDARY-START(17181595283),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1595027,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1726099,
      "h": 17181595283,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181595283),
//--TRIMMABLE-BOUNDARY-START(8591660691),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1595027,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1726099,
      "h": 8591660691,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591660691)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296693395),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1726099,
      "h": 4296693395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296693395)
  ],
  "h": 1726099
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.PayCowryOfflineAccountModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryOfflineAccountModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryOfflineAccountModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1726099)
        
        

        //--TRIMMABLE-BOUNDARY-START(415379)
        $asm.$cls(`$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor`, ($self) => class CommunityPayCowryRegisterResponseModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295382675)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295382675);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, this, factory);
                    }, $IAvcpe ??= {"r":65537,"n":"","d":415379,"h":0,"f":17825794}), 0, "CommunityPayCowryRegisterResponseModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_CommunityPayCowryRegisterResponseModel_LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModelTypeDescriptorBuilder.g.cs", "CommunityPayCowryRegisterResponseModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295382675)
            
            //--TRIMMABLE-BOUNDARY-START(12885317267)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885317267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Ticket"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel.$type, $.$discardRef(), "Ticket", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Ticket")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$GfYa.LCFCA.DecodedAuthenticationTicket, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Ticket";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$GfYa.LCFCA.DecodedAuthenticationTicket, ($.$cast(target, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)).Ticket);
                        }, $VlElif ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":415379,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, target).$v.Ticket = value.AsReference($.$GfYa.LCFCA.DecodedAuthenticationTicket);
                        }, $JrMGck ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":415379,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("User"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel.$type, $.$discardRef(), "User", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("User")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Iaui.LCFCM.UserModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "User";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$Iaui.LCFCM.UserModel, ($.$cast(target, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel)).User);
                        }, $GVtYZj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":415379,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, target).$v.User = value.AsReference($.$Iaui.LCFCM.UserModel);
                        }, $kdpyja ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":415379,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885317267)
            
            //--TRIMMABLE-BOUNDARY-START(17180284563)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180284563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Ticket = _target.Ticket;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Ticket"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Ticket, ($v) => _Ticket = $v, $.$GfYa.LCFCA.DecodedAuthenticationTicket)))
                    {
                        _target.Ticket = _Ticket;
                    }
                }
                {
                    /*var*/ let _User = _target.User;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("User"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Iaui.LCFCM.UserModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _User, ($v) => _User = $v, $.$Iaui.LCFCM.UserModel)))
                    {
                        _target.User = _User;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180284563)
            
            //--TRIMMABLE-BOUNDARY-START(8590349971)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590349971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590349971)
            
            static $h = 415379;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885317267),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 415379,
      "h": 12885317267,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885317267),
//--TRIMMABLE-BOUNDARY-START(17180284563),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 284307,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 415379,
      "h": 17180284563,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180284563),
//--TRIMMABLE-BOUNDARY-START(8590349971),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 284307,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 415379,
      "h": 8590349971,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590349971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295382675),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 415379,
      "h": 4295382675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295382675)
  ],
  "h": 415379
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.CommunityPayCowryRegisterResponseModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.CommunityPayCowryRegisterResponseModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}CommunityPayCowryRegisterResponseModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(415379)
        
        

        //--TRIMMABLE-BOUNDARY-START(808595)
        $asm.$cls(`$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor`, ($self) => class PayCowryAccountFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295775891)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295775891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor.GenerateProperties($.$UlXD.LCPCM.PayCowryAccountFeatureModel, this, factory);
                    }, $UaciMd ??= {"r":65537,"n":"","d":808595,"h":0,"f":17825794}), 0, "PayCowryAccountFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.PayCowry.Common\\Models_PayCowryAccountFeatureModel_LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModelTypeDescriptorBuilder.g.cs", "PayCowryAccountFeatureModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295775891)
            
            //--TRIMMABLE-BOUNDARY-START(12885710483)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885710483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Identity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Identity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Identity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Identity";
                        $i1.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Identity);
                        }, $GWjsvg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Identity = value.AsReference($.$$.S.String);
                        }, $fMkKHh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FirstName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "FirstName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FirstName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "FirstName";
                        $i3.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).FirstName);
                        }, $bqfFpg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FirstName = value.AsReference($.$$.S.String);
                        }, $asLZXd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "LastName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "LastName";
                        $i5.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).LastName);
                        }, $PGujJi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.LastName = value.AsReference($.$$.S.String);
                        }, $yYFGCf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PhoneNumber";
                        $i7.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).PhoneNumber);
                        }, $FjTcNa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsReference($.$$.S.String);
                        }, $ExfKwd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Email"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Email", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Email")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Email";
                        $i9.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Email);
                        }, $dSRuaa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Email = value.AsReference($.$$.S.String);
                        }, $VDIsuh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Pin"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Pin", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Pin")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletHash, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Pin";
                        $i11.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletHash, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Pin);
                        }, $rLBmRf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Pin = value.AsValue($.$OJJQ.LCFCW.WalletHash);
                        }, $Orlwyh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DeviceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "DeviceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DeviceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "DeviceId";
                        $i13.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).DeviceId);
                        }, $RAziCf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DeviceId = value.AsReference($.$$.S.String);
                        }, $wBLlNa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Version"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Version", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Version")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Version";
                        $i15.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Version);
                        }, $ZRHyMi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Version = value.AsReference($.$$.S.String);
                        }, $vYGjVe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NetworkAddress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "NetworkAddress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NetworkAddress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletAddress, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "NetworkAddress";
                        $i17.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletAddress, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).NetworkAddress);
                        }, $dnqijj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FullName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "FullName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FullName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "FullName";
                        $i19.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).FullName);
                        }, $MWzbyk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Protection"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Protection", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Protection")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletHash, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Protection";
                        $i21.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletHash, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Protection);
                        }, $EjYcqh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Protection = value.AsValue($.$OJJQ.LCFCW.WalletHash);
                        }, $GIISYa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProtectionData"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "ProtectionData", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProtectionData")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "ProtectionData";
                        $i23.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).ProtectionData);
                        }, $mWvGOb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "Title";
                        $i25.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Title);
                        }, $LrneXf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "Description";
                        $i27.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Description);
                        }, $NRhfIk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UlXD.LCPCM.PayCowryAccountFeatureModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.IconDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "Icon";
                        $i29.DelaredOn = "LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFC.IconDescriptor, ($.$cast(target, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)).Icon);
                        }, $PKbTvk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":808595,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.DataFeatureModelTypeDescriptor$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885710483)
            
            //--TRIMMABLE-BOUNDARY-START(17180677779)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180677779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.DataFeatureModel<LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.DataFeatureModelTypeDescriptor$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.DataFeatureModel$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel)));
                {
                    /*var*/ let _Identity = _target.Identity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Identity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Identity, ($v) => _Identity = $v, $.$$.S.String)))
                    {
                        _target.Identity = _Identity;
                    }
                }
                {
                    /*var*/ let _FirstName = _target.FirstName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FirstName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FirstName, ($v) => _FirstName = $v, $.$$.S.String)))
                    {
                        _target.FirstName = _FirstName;
                    }
                }
                {
                    /*var*/ let _LastName = _target.LastName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _LastName, ($v) => _LastName = $v, $.$$.S.String)))
                    {
                        _target.LastName = _LastName;
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PhoneNumber, ($v) => _PhoneNumber = $v, $.$$.S.String)))
                    {
                        _target.PhoneNumber = _PhoneNumber;
                    }
                }
                {
                    /*var*/ let _Email = _target.Email;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Email"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Email, ($v) => _Email = $v, $.$$.S.String)))
                    {
                        _target.Email = _Email;
                    }
                }
                {
                    /*var*/ let _Pin = _target.Pin;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Pin"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletHash));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletHash, () => _Pin, ($v) => _Pin = $v, null, true)))
                    {
                        _target.Pin = $.$clone(_Pin);
                    }
                }
                {
                    /*var*/ let _DeviceId = _target.DeviceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DeviceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DeviceId, ($v) => _DeviceId = $v, $.$$.S.String)))
                    {
                        _target.DeviceId = _DeviceId;
                    }
                }
                {
                    /*var*/ let _Version = _target.Version;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Version"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Version, ($v) => _Version = $v, $.$$.S.String)))
                    {
                        _target.Version = _Version;
                    }
                }
                {
                    /*var*/ let _NetworkAddress = _target.NetworkAddress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NetworkAddress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletAddress));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletAddress, () => _NetworkAddress, ($v) => _NetworkAddress = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _FullName = _target.FullName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FullName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FullName, ($v) => _FullName = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Protection = _target.Protection;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Protection"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletHash));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletHash, () => _Protection, ($v) => _Protection = $v, null, true)))
                    {
                        _target.Protection = $.$clone(_Protection);
                    }
                }
                {
                    /*var*/ let _ProtectionData = _target.ProtectionData;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProtectionData"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ProtectionData, ($v) => _ProtectionData = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.IconDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.IconDescriptor, () => _Icon, ($v) => _Icon = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180677779)
            
            //--TRIMMABLE-BOUNDARY-START(8590743187)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590743187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$UlXD.LCPCM.PayCowryAccountFeatureModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UlXD.LCPCM.PayCowryAccountFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryAccountFeatureModel)))
                {
                    /*var*/ let result = $.$UlXD.LCPCM.PayCowryAccountFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryAccountFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UlXD.LCPCM.PayCowryAccountFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UlXD.LCPCM.PayCowryAccountFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590743187)
            
            static $h = 808595;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885710483),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 808595,
      "h": 12885710483,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885710483),
//--TRIMMABLE-BOUNDARY-START(17180677779),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 677523,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 808595,
      "h": 17180677779,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180677779),
//--TRIMMABLE-BOUNDARY-START(8590743187),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 677523,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 808595,
      "h": 8590743187,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590743187)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295775891),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 808595,
      "h": 4295775891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295775891)
  ],
  "h": 808595
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UlXD.LCPCM.PayCowryAccountFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.PayCowry.Common.Models.PayCowryAccountFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}PayCowry${separator}Common${separator}Models${separator}PayCowryAccountFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(808595)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Wallet"));
})();
//--TRIMMABLE-BOUNDARY-END(22163)
