
//--TRIMMABLE-BOUNDARY-START(16103)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $nYKj, $wtdm, $AvdQ) {
    "use strict";
    let _;
    let $Tkjxuh;
    let $CfWWia;
    let $NiBlpb;
    let $fSvDTc;
    let $vLNMbe;
    let $CyOawg;
    let $hptzLf;
    let $BLugOg;
    let $hKkZhd;
    let $DCqpad;
    let $SCKnJa;
    let $YOLZbd;
    let $fmssEe;
    let $RYcKXh;
    let $hVXqvk;
    let $gZYxod;
    let $LGZruf;
    let $ThPNDi;
    let $WzfSpb;
    let $eYcfRj;
    let $SNBDKe;
    let $pdCHCb;
    let $Zrywrf;
    let $gdoaCg;
    let $qYdQMi;
    let $yaJNnl;
    let $SZdpti;
    let $eKIMUf;
    let $fAYQUh;
    let $tKmQZi;
    let $BMhyxj;
    let $dOMHKj;
    let $VSnlGg;
    let $MIcRsg;
    let $rIvMbk;
    let $FWNvuh;
    let $hWeyCk;
    let $rFtZge;
    let $eFwBNc;
    let $CAbcJj;
    let $xEmBvj;
    let $Iejbzf;
    let $NTNTwj;
    let $bDUTAg;
    let $pmFEfh;
    let $YPCTee;
    let $ewyTng;
    let $XPdBZa;
    let $guQsKi;
    let $PfpLtc;
    let $NcNDug;
    let $PLjYVf;
    let $sgXbNh;
    let $xIAzXa;
    let $VXIEze;
    let $SlpOxb;
    let $LdjKHg;
    let $lKPEpf;
    let $AvHjvc;
    let $UJPpbb;
    let $wMACCk;
    let $BXESOk;
    let $FIrgGk;
    let $KEnbBk;
    let $XvWKYk;
    let $hRWfWb;
    let $AknOXh;
    let $FqglAe;
    let $DYRLGe;
    let $fkHBYi;
    let $NzHfUf;
    let $ScMFvh;
    let $UlGCMi;
    let $BQYxBd;
    let $yPHbYk;
    let $ehUsXc;
    let $SeGeBe;
    let $iShfvc;
    let $fijABb;
    let $iavrgb;
    let $MAAXEc;
    let $pXbuCe;
    let $hbqzik;
    let $WvsLZe;
    let $nDNatk;
    let $eNAnZg;
    let $FnVQpe;
    let $lGThXa;
    let $THulKg;
    let $tzhGgj;
    let $kKlyVe;
    let $zpqQjj;
    let $shFYDi;
    let $UtnSEf;
    let $VoohOd;
    let $cMkcvh;
    let $WIgohj;
    let $Naikjk;
    let $JYRkJe;
    let $nphBsb;
    let $mMiOib;
    let $MvBGna;
    let $OSLIxh;
    let $cKeqca;
    let $gHYQOj;
    let $QqTIDa;
    let $mSCTqe;
    let $jCTnhb;
    let $wKVpIa;
    let $oyUSLi;
    let $BevUnb;
    let $QqBXlf;
    let $lMYwRf;
    let $zfiYUk;
    let $FKgjCi;
    let $kUNWUb;
    let $nfwmbl;
    let $eHKWsj;
    let $JhmFmb;
    let $mhulec;
    let $ZaErCa;
    let $oFWtrf;
    let $wRRQBd;
    let $FJArna;
    let $XAydsb;
    let $LdIPKj;
    let $XCoUil;
    let $Nemgjh;
    let $cnhUjl;
    let $XpwUGk;
    let $Dmznhf;
    let $rzenUg;
    let $UIyHXf;
    let $aGSyij;
    let $DuohEa;
    let $ygfmqg;
    let $iGfTFi;
    let $bXvZLf;
    let $IfLBYe;
    let $pxeIFf;
    let $YKnaFk;
    let $qrxcqe;
    let $klzaZd;
    let $ziuxAk;
    let $TvkUme;
    let $ecEDyc;
    let $xrPOQi;
    let $MAkGbc;
    let $XEsUXi;
    let $qMdhjk;
    let $mdKKQe;
    let $qggmja;
    let $ucjgYg;
    let $pjULVd;
    let $ofEyLi;
    let $KZcFka;
    let $GvQemc;
    let $qxZVhd;
    let $ZDoUel;
    let $FBGeqg;
    let $mEdmdi;
    let $QEVEHc;
    let $jxJPdj;
    let $BYQvbl;
    let $ADKvpa;
    let $KAyptf;
    let $UpflDk;
    let $ScBUmg;
    let $hPVnva;
    let $xtyxga;
    let $hbhYbk;
    let $Hgankf;
    let $TKOoUd;
    let $zctDOi;
    let $lOgiof;
    let $xrkVgh;
    let $VVCzOf;
    let $tyekFa;
    let $WwsTJa;
    let $tZtEFe;
    let $bkukLa;
    let $aOZsZd;
    let $zyCdZd;
    let $TLwUGk;
    let $NaklWi;
    let $wQvdha;
    let $cwTJyh;
    let $Mjrxrc;
    let $xWRCFd;
    let $IsijWa;
    let $GGiboj;
    let $Jauahe;
    let $JeMFjh;
    let $IlkYrh;
    let $VUObxa;
    let $FecZLe;
    let $rGVqSa;
    let $bNKMkj;
    let $NIstfb;
    let $ArCpla;
    let $igzwxa;
    let $rpxZdb;
    let $QDvWkh;
    let $kuJBzc;
    let $guTpZi;
    let $xOlrid;
    let $zBexEh;
    let $mnPPWi;
    let $Knalyc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", 
    {
  "h": 16103,
  "f": "LivingThing.Core.ProductsServices.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.ProductsServices.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.ProductsServices.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1720039)
        $asm.$cls(`$dgLE.LCPCSG.IAppServiceGuard`, ($self) => class IAppServiceGuard
        {
            static $h = 1720039;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181589223),
    {
      "p": 4480424,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591654631,
        "f": 50331905
      },
      "n": "Service",
      "o": "LCPCSG$IAppServiceGuard$Service",
      "d": 1720039,
      "h": 17181589223,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181589223)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886621927),
    {
      "r": 6881395,
      "p": [
        {
          "n": "onSelected",
          "p": $.$$.S.Action$$($.$fPer.LCFCD.IServiceDataModel).$h,
          "f": 65
        }
      ],
      "n": "GetSelectorView",
      "o": "LCPCSG$IAppServiceGuard$GetSelectorView",
      "d": 1720039,
      "h": 12886621927,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886621927)
  ],
  "h": 1720039
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.IAppServiceGuard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}IAppServiceGuard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1720039)
        
        

        //--TRIMMABLE-BOUNDARY-START(736999)
        $asm.$cls(`$dgLE.LCPCS.IProductStoreService`, ($self) => class IProductStoreService
        {
            static $h = 736999;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885638887),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IProductCatalogueModel).$h,
      "p": [
        {
          "n": "storeId",
          "p": 1310721
        }
      ],
      "n": "GetProductsCatalogue",
      "o": "LCPCS$IProductStoreService$GetProductsCatalogue",
      "d": 736999,
      "h": 12885638887,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885638887),
//--TRIMMABLE-BOUNDARY-START(8590671591),
    {
      "r": $.$$.STT.ValueTask$$($.$AvdQ.LCFCP.IProductCatalogueModel).$h,
      "p": [
        {
          "n": "productId",
          "p": 1310721
        }
      ],
      "n": "GetProduct",
      "o": "LCPCS$IProductStoreService$GetProduct",
      "d": 736999,
      "h": 8590671591,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590671591),
//--TRIMMABLE-BOUNDARY-START(4295704295),
    {
      "r": 6881395,
      "p": [
        {
          "n": "catalogue",
          "p": 4043712
        }
      ],
      "n": "GetCatalogueView",
      "o": "LCPCS$IProductStoreService$GetCatalogueView",
      "d": 736999,
      "h": 4295704295,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295704295)
  ],
  "h": 736999
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Services.IProductStoreService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Services${separator}IProductStoreService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(736999)
        
        

        //--TRIMMABLE-BOUNDARY-START(1851111)
        $asm.$cls(`$dgLE.LCPCS$1.ICatalogueOrderProvider`, ($self) => class ICatalogueOrderProvider
        {
            static $h = 1851111;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181720295),
    {
      "p": 933607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361589479,
        "f": 50331905
      },
      "n": "Features",
      "o": "LCPCS$1$ICatalogueOrderProvider$Features",
      "d": 1851111,
      "h": 17181720295,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181720295),
//--TRIMMABLE-BOUNDARY-START(12886752999),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$fPer.LCFCC$2.IContact).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771654887,
        "f": 50331905
      },
      "n": "Customers",
      "o": "LCPCS$1$ICatalogueOrderProvider$Customers",
      "d": 1851111,
      "h": 12886752999,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886752999)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591785703),
    {
      "r": 2929600,
      "p": [
        {
          "n": "catalogue",
          "p": 1946560
        }
      ],
      "n": "CreateOrderItem",
      "o": "LCPCS$1$ICatalogueOrderProvider$CreateOrderItem",
      "d": 1851111,
      "h": 8591785703,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591785703),
//--TRIMMABLE-BOUNDARY-START(4296818407),
    {
      "r": $.$$.STT.Task$$($.$AvdQ.LCFCP.ICatalogueOrderModel).$h,
      "p": [
        {
          "n": "payment",
          "p": 1459992
        },
        {
          "n": "customer",
          "p": 5081430
        },
        {
          "n": "items",
          "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h
        }
      ],
      "n": "CreateOrder",
      "o": "LCPCS$1$ICatalogueOrderProvider$CreateOrder",
      "d": 1851111,
      "h": 4296818407,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296818407)
  ],
  "h": 1851111
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ICatalogueOrderProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ICatalogueOrderProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1851111)
        
        

        //--TRIMMABLE-BOUNDARY-START(1785575)
        $asm.$cls(`$dgLE.LCPCSG.IServiceGuardViewModel<,,>`, (TServiceModel, TServiceTierType, TServiceFeatureType) => $asm.$gt(`$dgLE.LCPCSG.IServiceGuardViewModel<,,>`, [TServiceModel, TServiceTierType, TServiceFeatureType], ($self) => class IServiceGuardViewModel$$$$
        {
            static $H = 1785575;
            static $h = 1785575;
            static $g = 3;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296752871),
    {
      "p": $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12886687463,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331905
      },
      "n": "Catalogue",
      "o": "LCPCSG$IServiceGuardViewModel$$$$$Catalogue",
      "d": this.$h,
      "H": 4296752871,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296752871)
  ],
  "s": [
    {
      "h": TServiceModel?.$h??1572864,
      "n": "TServiceModel",
      "c": [23562582
      ]
    },
    {
      "h": TServiceTierType?.$h??1638400,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1703936,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 3,
  "H": 1785575,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$(TServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.IServiceGuardViewModel<${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}IServiceGuardViewModel$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1785575)
        
        

        //--TRIMMABLE-BOUNDARY-START(409319)
        $asm.$cls(`$dgLE.LCPC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295376615)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295376615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dgLE.LCPCSG.AppServiceGuardFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dgLE.LCPCSG.AppServiceGuardFeaturesCustomAttributesProvider, $.$dgLE.LCPCSG.AppServiceGuardFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dgLE.LCPCS$1.CatalogueOrderProviderFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dgLE.LCPCS$1.CatalogueOrderProviderFeaturesCustomAttributesProvider, $.$dgLE.LCPCS$1.CatalogueOrderProviderFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dgLE.LCPCS$1.ServiceMenuSelectorFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dgLE.LCPCS$1.ServiceMenuSelectorFeaturesCustomAttributesProvider, $.$dgLE.LCPCS$1.ServiceMenuSelectorFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dgLE.LCPCS$1.ServiceSignUpFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dgLE.LCPCS$1.ServiceSignUpFeaturesCustomAttributesProvider, $.$dgLE.LCPCS$1.ServiceSignUpFeaturesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295376615)
            
            static $h = 409319;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295376615),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 409319,
      "h": 4295376615,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295376615)
  ],
  "h": 409319
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(409319)
        
        

        //--TRIMMABLE-BOUNDARY-START(474855)
        $asm.$cls(`$dgLE.LCPC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295442151)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295442151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295442151)
            
            static $h = 474855;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295442151),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 474855,
      "h": 4295442151,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295442151)
  ],
  "h": 474855
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(474855)
        
        

        //--TRIMMABLE-BOUNDARY-START(2244327)
        $asm.$cls(`$dgLE.LCPCS$1.ServiceMenuSelectorFeaturesCustomAttributesProvider`, ($self) => class ServiceMenuSelectorFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297211623)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297211623)
            
            //--TRIMMABLE-BOUNDARY-START(8592178919)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592178919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dgLE.LCPCS$1.ServiceMenuSelectorFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dgLE.LCPCS$1.ServiceMenuSelectorFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $NiBlpb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2244327,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $fSvDTc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2244327,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592178919)
            
            static $h = 2244327;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592178919),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2244327,
      "h": 8592178919,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592178919)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297211623),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2244327,
      "h": 4297211623,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297211623)
  ],
  "h": 2244327
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ServiceMenuSelectorFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceMenuSelectorFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2244327)
        
        

        //--TRIMMABLE-BOUNDARY-START(1392359)
        $asm.$cls(`$dgLE.LCPCSG.AppServiceGuardFeaturesCustomAttributesProvider`, ($self) => class AppServiceGuardFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296359655)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296359655)
            
            //--TRIMMABLE-BOUNDARY-START(8591326951)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591326951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dgLE.LCPCSG.AppServiceGuardFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dgLE.LCPCSG.AppServiceGuardFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vLNMbe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1392359,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $CyOawg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1392359,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591326951)
            
            static $h = 1392359;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591326951),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1392359,
      "h": 8591326951,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591326951)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296359655),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1392359,
      "h": 4296359655,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296359655)
  ],
  "h": 1392359
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceGuardFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceGuardFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1392359)
        
        

        //--TRIMMABLE-BOUNDARY-START(999143)
        $asm.$cls(`$dgLE.LCPCS$1.CatalogueOrderProviderFeaturesCustomAttributesProvider`, ($self) => class CatalogueOrderProviderFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295966439)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295966439)
            
            //--TRIMMABLE-BOUNDARY-START(8590933735)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590933735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dgLE.LCPCS$1.CatalogueOrderProviderFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dgLE.LCPCS$1.CatalogueOrderProviderFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $Tkjxuh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":999143,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $CfWWia ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":999143,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590933735)
            
            static $h = 999143;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590933735),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 999143,
      "h": 8590933735,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590933735)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295966439),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 999143,
      "h": 4295966439,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295966439)
  ],
  "h": 999143
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.CatalogueOrderProviderFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}CatalogueOrderProviderFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(999143)
        
        

        //--TRIMMABLE-BOUNDARY-START(2572007)
        $asm.$cls(`$dgLE.LCPC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297539303)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297539303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$dgLE.LCPCV.ServiceSubscriptionModel$$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/*types*/ types) =>
                {
                    return $.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptorBuilder$$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $fmssEe ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":2572007,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4297539303)
            
            static $h = 2572007;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297539303),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2572007,
      "h": 4297539303,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297539303)
  ],
  "h": 2572007
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2572007)
        
        

        //--TRIMMABLE-BOUNDARY-START(343783)
        $asm.$cls(`$dgLE.LCPC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295311079)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295311079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$dgLE.LCPC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295311079)
            
            static $h = 343783;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295311079),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 343783,
      "h": 4295311079,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295311079)
  ],
  "h": 343783
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(343783)
        
        

        //--TRIMMABLE-BOUNDARY-START(2768615)
        $asm.$cls(`$dgLE.LCPCV.ServiceSubscriptionModelCustomAttributesProvider<,>`, (TServiceTierType, TFeatureType) => $asm.$gt(`$dgLE.LCPCV.ServiceSubscriptionModelCustomAttributesProvider<,>`, [TServiceTierType, TFeatureType], ($self) => class ServiceSubscriptionModelCustomAttributesProvider$$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297735911)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297735911)
            
            //--TRIMMABLE-BOUNDARY-START(8592703207)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592703207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dgLE.LCPCV.ServiceSubscriptionModelCustomAttributesProvider$$$(TServiceTierType, TFeatureType).compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(9, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ServiceType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.InputType = $.$cast(3n, $.$fPer.LCFC.InputType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TierName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.InputType = $.$cast(3n, $.$fPer.LCFC.InputType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ServiceName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Limits", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SubscriptionCounts", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (5);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Expiry", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (6);
                            $i8.InputType = $.$cast(3n, $.$fPer.LCFC.InputType);
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Dependents=SubscriptionMonths,Limits"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PayableAmount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (7);
                            $i9.InputType = $.$cast(3n, $.$fPer.LCFC.InputType);
                            $i9.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Dependents=SubscriptionMonths,Limits"], [-1], null);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Tier", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dgLE.LCPCV.ServiceSubscriptionModelCustomAttributesProvider$$$(TServiceTierType, TFeatureType).compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ThPNDi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WzfSpb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592703207)
            
            static $H = 2768615;
            static $h = 2768615;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592703207),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 8592703207,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592703207)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297735911),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": this.$h,
      "H": 4297735911,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297735911)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatureType?.$h??1638400,
      "n": "TFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 2768615,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModelCustomAttributesProvider<${TServiceTierType?.$fullName},${TFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ViewModels${separator}ServiceSubscriptionModelCustomAttributesProvider$${TServiceTierType?.$getFullName(separator)}$${TFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2768615)
        
        

        //--TRIMMABLE-BOUNDARY-START(2834151)
        $asm.$cls(`$dgLE.LCPCV.ServiceSubscriptionModelCustomAttributesProviderRegistrar2`, ($self) => class ServiceSubscriptionModelCustomAttributesProviderRegistrar2
        {
            //--TRIMMABLE-BOUNDARY-START(4297801447)
            static /*void */ AddGeneratedFastAttributesOfServiceSubscriptionModel(TServiceTierType, TFeatureType, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297801447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelCustomAttributesProvider$$$(TServiceTierType, TFeatureType), $.$dgLE.LCPCV.ServiceSubscriptionModelCustomAttributesProvider$$$(TServiceTierType, TFeatureType).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4297801447)
            
            static $h = 2834151;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297801447),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TServiceTierType",
        "TFeatureType"
      ],
      "n": "AddGeneratedFastAttributesOfServiceSubscriptionModel",
      "d": 2834151,
      "h": 4297801447,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4297801447)
  ],
  "h": 2834151
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModelCustomAttributesProviderRegistrar2`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ViewModels${separator}ServiceSubscriptionModelCustomAttributesProviderRegistrar2`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2834151)
        
        

        //--TRIMMABLE-BOUNDARY-START(605927)
        $asm.$cls(`$dgLE.LCPC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590540519)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590540519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$dgLE.LCPCS$1.ProductLandingPage1, "LivingThing.Core.ProductsServices.Client", "Shared\\ProductLandingPage1", "Product Landing Page1", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/LP" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590540519)
            
            //--TRIMMABLE-BOUNDARY-START(4295573223)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295573223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295573223)
            
            //--TRIMMABLE-BOUNDARY-START(4295573223)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295573223)
            
            static $h = 605927;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590540519),
    {
      "r": 65537,
      "n": "Build",
      "d": 605927,
      "h": 8590540519,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590540519)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295573223),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 605927,
      "h": 4295573223,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295573223)
  ],
  "h": 605927
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(605927)
        
        

        //--TRIMMABLE-BOUNDARY-START(2965223)
        $asm.$cls(`$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptorBuilder<,>`, (TServiceTierType, TFeatureType) => $asm.$gt(`$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptorBuilder<,>`, [TServiceTierType, TFeatureType], ($self) => class ServiceSubscriptionModelTypeDescriptorBuilder$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592899815)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592899815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType)()
                        const $t1 = $.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JYRkJe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592899815)
            
            //--TRIMMABLE-BOUNDARY-START(4297932519)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297932519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297932519)
            
            //--TRIMMABLE-BOUNDARY-START(4297932519)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297932519)
            
            static $H = 2965223;
            static $h = 2965223;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592899815),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8592899815,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592899815)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297932519),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297932519,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297932519)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatureType?.$h??1638400,
      "n": "TFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 2965223,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModelTypeDescriptorBuilder<${TServiceTierType?.$fullName},${TFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ViewModels${separator}ServiceSubscriptionModelTypeDescriptorBuilder$${TServiceTierType?.$getFullName(separator)}$${TFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2965223)
        
        

        //--TRIMMABLE-BOUNDARY-START(212711)
        $asm.$cls(`$dgLE._LCPCSS$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295180007)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::System.Int32*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295180007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "PadContent", $.$box(__arg1, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295180007)
            
            static $h = 212711;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295180007),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 655361
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 212711,
      "h": 4295180007,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295180007)
  ],
  "h": 212711
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.ProductsServices.Client.Shared.ServiceSignUp.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceSignUp${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(212711)
        
        

        //--TRIMMABLE-BOUNDARY-START(147175)
        $asm.$cls(`$dgLE._LCPCSS.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295114471)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Client.IViewController*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg3, /*int*/ __seq4, /*global::System.Collections.Generic.IEnumerable<global::System.Collections.Generic.KeyValuePair<global::LivingThing.Core.Frameworks.Common.Stringy, global::System.Object>>*/ __arg4, /*int*/ __seq5, /*global::System.Int32?*/ __arg5, /*int*/ __seq6, /*global::System.Int32?*/ __arg6, /*int*/ __seq7, /*global::System.String*/ __arg7, /*int*/ __seq8, /*global::System.Object*/ __arg8, /*int*/ __seq9, /*global::System.Object*/ __arg9, /*int*/ __seq10, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg10)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295114471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Controller", __arg1);
                __builder.AddComponentParameter(__seq2, "Theme", $.$clone(__arg2));
                __builder.AddComponentParameter(__seq3, "Features", $.$box(__arg3, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq4, "SetAttributes", __arg4);
                __builder.AddComponentParameter(__seq5, "GridWidth", $.$box(__arg5, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq6, "GridGap", $.$box(__arg6, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq7, "ItemName", __arg7);
                __builder.AddComponentParameter(__seq8, "li-class", __arg8);
                __builder.AddComponentParameter(__seq9, "menu-class", __arg9);
                __builder.AddComponentParameter(__seq10, "ChildContent", __arg10);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295114471)
            
            static $h = 147175;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295114471),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 5856680
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 65309014
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 14505642
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "__seq7",
          "p": 655361
        },
        {
          "n": "__arg7",
          "p": 1310721
        },
        {
          "n": "__seq8",
          "p": 655361
        },
        {
          "n": "__arg8",
          "p": 131073
        },
        {
          "n": "__seq9",
          "p": 655361
        },
        {
          "n": "__arg9",
          "p": 131073
        },
        {
          "n": "__seq10",
          "p": 655361
        },
        {
          "n": "__arg10",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 147175,
      "h": 4295114471,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295114471)
  ],
  "h": 147175
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.ProductsServices.Client.Shared.ServiceMenuSelector.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceMenuSelector${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(147175)
        
        

        //--TRIMMABLE-BOUNDARY-START(81639)
        $asm.$cls(`$dgLE._LCPCSC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295048935)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295048935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Theme", $.$clone(__arg1));
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295048935)
            
            //--TRIMMABLE-BOUNDARY-START(8590016231)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Common.Data.Pager<global::LivingThing.Core.Frameworks.Common.ISelectOption<TValue>>*/ __arg3, /*int*/ __seq4, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg4, /*int*/ __seq5, /*TValue*/ __arg5, /*int*/ __seq6, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg6, /*int*/ __seq7, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg7)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590016231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Theme", $.$clone(__arg1));
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Options", __arg3);
                __builder.AddComponentParameter(__seq4, "Type", $.$box(__arg4, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq5, "Value", $.$box(__arg5, TValue));
                __builder.AddComponentParameter(__seq6, "ValueChanged", __arg6);
                __builder.AddComponentParameter(__seq7, "ValueExpression", __arg7);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590016231)
            
            //--TRIMMABLE-BOUNDARY-START(12884983527)
            static /*void */ CreateInputEditor_2(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884983527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Theme", $.$clone(__arg1));
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12884983527)
            
            //--TRIMMABLE-BOUNDARY-START(17179950823)
            static /*void */ CreateInputEditor_3(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179950823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Theme", $.$clone(__arg1));
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17179950823)
            
            static $h = 81639;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295048935),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 65309014
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 81639,
      "h": 4295048935,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295048935),
//--TRIMMABLE-BOUNDARY-START(8590016231),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 65309014
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$(TValue)).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 47614294
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq7",
          "p": 655361
        },
        {
          "n": "__arg7",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 81639,
      "h": 8590016231,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590016231),
//--TRIMMABLE-BOUNDARY-START(12884983527),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 65309014
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_2",
      "d": 81639,
      "h": 12884983527,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12884983527),
//--TRIMMABLE-BOUNDARY-START(17179950823),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 65309014
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_3",
      "d": 81639,
      "h": 17179950823,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17179950823)
  ],
  "h": 81639
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.ProductsServices.Client.Shared.CatalogueOrder.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}CatalogueOrder${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(81639)
        
        

        //--TRIMMABLE-BOUNDARY-START(2440935)
        $asm.$cls(`$dgLE.LCPCS$1.ServiceSignUpFeaturesCustomAttributesProvider`, ($self) => class ServiceSignUpFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297408231)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297408231)
            
            //--TRIMMABLE-BOUNDARY-START(8592375527)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592375527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dgLE.LCPCS$1.ServiceSignUpFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dgLE.LCPCS$1.ServiceSignUpFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $mnPPWi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2440935,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $Knalyc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2440935,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592375527)
            
            static $h = 2440935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592375527),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2440935,
      "h": 8592375527,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592375527)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297408231),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2440935,
      "h": 4297408231,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297408231)
  ],
  "h": 2440935
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ServiceSignUpFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceSignUpFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2440935)
        
        

        //--TRIMMABLE-BOUNDARY-START(802535)
        $asm.$cls(`$dgLE.LCPCS.ProductServicesClient`, ($self) => class ProductServicesClient extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295769831)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295769831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295769831)
            
            //--TRIMMABLE-BOUNDARY-START(4295769831)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295769831)
            
            static $h = 802535;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295769831),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 802535,
      "h": 4295769831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295769831)
  ],
  "h": 802535
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.IProductServicesClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Services.ProductServicesClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Services${separator}ProductServicesClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(802535)
        
        

        //--TRIMMABLE-BOUNDARY-START(671463)
        $asm.$cls(`$dgLE.LCPC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590606055)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590606055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.IProductServicesClient, $.$dgLE.LCPCS.ProductServicesClient, services);
                $.$dgLE.LCPC._Startup.AddGeneratedComponentOptimizers(services);
                $.$dgLE.LCPC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$dgLE.LCPC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590606055)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dgLE.LCPC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295638759)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295638759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295638759)
            
            //--TRIMMABLE-BOUNDARY-START(4295638759)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295638759)
            
            static $h = 671463;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590606055),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 671463,
      "h": 8590606055,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590606055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295638759),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 671463,
      "h": 4295638759,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295638759)
  ],
  "h": 671463
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(671463)
        
        

        //--TRIMMABLE-BOUNDARY-START(540391)
        $asm.$cls(`$dgLE.LCPC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180409575)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dgLE.LCPCS$1.CatalogueOrder.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dgLE.LCPCS$1.CatalogueOrder().$ctor$3();
                    }, $hptzLf ??= {"r":2752627,"n":"","d":540391,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dgLE.LCPCS$1.ChooseServiceTier.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dgLE.LCPCS$1.ChooseServiceTier().$ctor$4();
                    }, $BLugOg ??= {"r":2752627,"n":"","d":540391,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dgLE.LCPCSG.AppServiceSwitch.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dgLE.LCPCSG.AppServiceSwitch().$ctor$3();
                    }, $hKkZhd ??= {"r":2752627,"n":"","d":540391,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dgLE.LCPCS$1.InvoiceReceipt.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dgLE.LCPCS$1.InvoiceReceipt().$ctor$5();
                    }, $DCqpad ??= {"r":2752627,"n":"","d":540391,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dgLE.LCPCS$1.ProductLandingPage1.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dgLE.LCPCS$1.ProductLandingPage1().$ctor$3();
                    }, $SCKnJa ??= {"r":2752627,"n":"","d":540391,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dgLE.LCPCS$1.ServiceMenuSelector.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dgLE.LCPCS$1.ServiceMenuSelector().$ctor$5();
                    }, $YOLZbd ??= {"r":2752627,"n":"","d":540391,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180409575)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295507687)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295507687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295507687)
            
            //--TRIMMABLE-BOUNDARY-START(4295507687)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295507687)
            
            static $h = 540391;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180409575),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885442279,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 540391,
      "h": 17180409575,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180409575)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295507687),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 540391,
      "h": 4295507687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295507687)
  ],
  "h": 540391
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(540391)
        
        

        //--TRIMMABLE-BOUNDARY-START(2703079)
        $asm.$cls(`$dgLE.LCPCV.ServiceSubscriptionModel<,>`, (TServiceTierType, TFeatureType) => $asm.$gt(`$dgLE.LCPCV.ServiceSubscriptionModel<,>`, [TServiceTierType, TFeatureType], ($self) => class ServiceSubscriptionModel$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067474151)
            $ctor$1(/*string*/ serviceType, /*string?*/ serviceName, /*ServiceTierModel<TServiceTierType, TFeatureType>*/ tier)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067474151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ServiceType = serviceType;
                    this.ServiceName = serviceName;
                    this.Tier = tier;
                    this.Limits = tier.Limit <= 0 ? 1 : tier.Limit;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067474151)
            
            //--TRIMMABLE-BOUNDARY-START(137441656551)
            /*string*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(137441656551)
            
            //--TRIMMABLE-BOUNDARY-START(193276231399)
            /*string? */ get TierName()
            {
                return this.Tier.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(193276231399)
            
            //--TRIMMABLE-BOUNDARY-START(133146689255)
            /*string?*/ ServiceName = null;
            //--TRIMMABLE-BOUNDARY-END(133146689255)
            
            //--TRIMMABLE-BOUNDARY-START(115966820071)
            /*int*/ Limits = 0;
            //--TRIMMABLE-BOUNDARY-END(115966820071)
            
            //--TRIMMABLE-BOUNDARY-START(184686296807)
            /*int*/ SubscriptionCounts = 0;
            //--TRIMMABLE-BOUNDARY-END(184686296807)
            
            //--TRIMMABLE-BOUNDARY-START(34362441447)
            /*DateTime */ get Expiry()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952376039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Service !== null && $.$fPer.LCFCD.ServiceExtension.IsExpired(this.Service) === false)
                {
                    return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Service.LCFCD$IServiceDataModel$ExpiryDate).Add($.$$.S.TimeSpan.op_Multiply$1((this.Tier.Duration ?? $.$$.S.TimeSpan.FromDays$2(30)), this.SubscriptionCounts));
                }
                return $.$$.S.DateTime.UtcNow.Add($.$$.S.TimeSpan.op_Multiply$1((this.Tier.Duration ?? $.$$.S.TimeSpan.FromDays$2(30)), this.SubscriptionCounts));
            }
            //--TRIMMABLE-BOUNDARY-END(34362441447)
            
            //--TRIMMABLE-BOUNDARY-START(124556754663)
            /*Money */ get PayableAmount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132245223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Tier.CalculateCost !== null)
                {
                    /*int*/ let limit = this.Limits;
                    /*int*/ let counts = this.SubscriptionCounts;
                    /*var*/ let amount = this.Tier.CalculateCost.Invoke(this.Tier, $.$ref(() => limit, ($v) => limit = $v, $.$$.S.Int32), $.$ref(() => counts, ($v) => counts = $v, $.$$.S.Int32));
                    this.Limits = limit;
                    this.SubscriptionCounts = counts;
                    return amount;
                }
                return $.$fPer.LCFCDM.Money.op_Implicit$1(((this.Limits * this.SubscriptionCounts) | 0)) * $.$fPer.LCFCDM.Money.op_Implicit(this.Tier.Cost);
            }
            //--TRIMMABLE-BOUNDARY-END(124556754663)
            
            //--TRIMMABLE-BOUNDARY-START(188981264103)
            /*ServiceTierModel<TServiceTierType, TFeatureType>*/ Tier = null;
            //--TRIMMABLE-BOUNDARY-END(188981264103)
            
            //--TRIMMABLE-BOUNDARY-START(128851721959)
            /*IServiceDataModel?*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(128851721959)
            
            //--TRIMMABLE-BOUNDARY-START(120261787367)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261787367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Tier.LimitLabel !== null)
                {
                    propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Edit($.$$.S.String, new ($.$$.S.Func$$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCA$1.SchemaType, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p, /*s*/ s) =>
                    {
                        return p.LCFCD$1$IPropertyDescriptor$Name === "Limits";
                    }, $MIcRsg ??= {"r":262145,"p":[{"n":"p","p":40733014},{"n":"s","p":2722134}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        /*var*/ let param_p = $.$sle.SLE.Expression.Parameter($.$fPer.LCFCD$1.IPropertyDescriptor.$type, "p");
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5(param_p, "Label"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ param_p ], null, null));
                    }, $rIvMbk ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke()), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.String))().$ctor(this,  (/**/ p) =>
                    {
                        return this.Tier.LimitLabel;
                    }, $FWNvuh ??= {"r":1310721,"p":[{"n":"p","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                if (this.Tier.DurationLabel !== null)
                {
                    propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Edit($.$$.S.String, new ($.$$.S.Func$$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCA$1.SchemaType, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p, /*s*/ s) =>
                    {
                        return p.LCFCD$1$IPropertyDescriptor$Name === "SubscriptionCounts";
                    }, $hWeyCk ??= {"r":262145,"p":[{"n":"p","p":40733014},{"n":"s","p":2722134}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        /*var*/ let param_p = $.$sle.SLE.Expression.Parameter($.$fPer.LCFCD$1.IPropertyDescriptor.$type, "p");
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5(param_p, "Label"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ param_p ], null, null));
                    }, $rFtZge ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke()), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.String))().$ctor(this,  (/*p*/ p) =>
                    {
                        return this.Tier.DurationLabel;
                    }, $eFwBNc ??= {"r":1310721,"p":[{"n":"p","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261787367)
            
            //--TRIMMABLE-BOUNDARY-START(197571198695)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571198695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Tier.Cost))
                {
                    descriptors = $.$sl.SL.Enumerable.Where($.$fPer.LCFCD$1.IPropertyDescriptor, descriptors, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.LCFCD$1$IPropertyDescriptor$Name !== "SubscriptionCounts" && d.LCFCD$1$IPropertyDescriptor$Name !== "Limits";
                    }, $CAbcJj ??= {"r":262145,"p":[{"n":"d","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                if (this.Tier.Duration !== null)
                {
                    descriptors = $.$sl.SL.Enumerable.Where($.$fPer.LCFCD$1.IPropertyDescriptor, descriptors, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.LCFCD$1$IPropertyDescriptor$Name !== "SubscriptionCounts";
                    }, $xEmBvj ??= {"r":262145,"p":[{"n":"d","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                if (this.Tier.Limit === 0)
                {
                    descriptors = $.$sl.SL.Enumerable.Where($.$fPer.LCFCD$1.IPropertyDescriptor, descriptors, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                    {
                        return d.LCFCD$1$IPropertyDescriptor$Name !== "Limits";
                    }, $Iejbzf ??= {"r":262145,"p":[{"n":"d","p":40733014}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                return descriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(197571198695)
            
            //--TRIMMABLE-BOUNDARY-START(4335962454)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorNotify.UpdateDescriptors(System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCD$1$IPropertyDescriptorNotify$UpdateDescriptors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4335962454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateDescriptors(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4335962454)
            
            //--TRIMMABLE-BOUNDARY-START(4335831382)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifier.ModifyDescriptor(LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifierBuilder)
            LCFCD$1$IPropertyDescriptorModifier$ModifyDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4335831382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ModifyDescriptor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4335831382)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(115966820071)
                this.Limits = 1;
                //--TRIMMABLE-BOUNDARY-END(115966820071)
                
                //--TRIMMABLE-BOUNDARY-START(184686296807)
                this.SubscriptionCounts = 1;
                //--TRIMMABLE-BOUNDARY-END(184686296807)
                
            }
            static $H = 2703079;
            static $h = 2703079;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137441656551),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85902048999,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "ServiceType",
      "d": this.$h,
      "H": 137441656551,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 3,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137441656551),
//--TRIMMABLE-BOUNDARY-START(193276231399),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111671852775,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "TierName",
      "d": this.$h,
      "H": 193276231399,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 3,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193276231399),
//--TRIMMABLE-BOUNDARY-START(133146689255),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77312114407,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 163211460327,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 83886081
      },
      "n": "ServiceName",
      "d": this.$h,
      "H": 133146689255,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133146689255),
//--TRIMMABLE-BOUNDARY-START(115966820071),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51542310631,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 146031591143,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 83886081
      },
      "n": "Limits",
      "d": this.$h,
      "H": 115966820071,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115966820071),
//--TRIMMABLE-BOUNDARY-START(184686296807),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94491983591,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 171801394919,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 83886081
      },
      "n": "SubscriptionCounts",
      "d": this.$h,
      "H": 184686296807,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184686296807),
//--TRIMMABLE-BOUNDARY-START(34362441447),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42952376039,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Expiry",
      "d": this.$h,
      "H": 34362441447,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 3,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//Dependents=SubscriptionMonths,Limits"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34362441447),
//--TRIMMABLE-BOUNDARY-START(124556754663),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60132245223,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "PayableAmount",
      "d": this.$h,
      "H": 124556754663,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 3,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//Dependents=SubscriptionMonths,Limits"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124556754663),
//--TRIMMABLE-BOUNDARY-START(188981264103),
    {
      "p": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103081918183,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 180391329511,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 83886081
      },
      "n": "Tier",
      "d": this.$h,
      "H": 188981264103,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188981264103),
//--TRIMMABLE-BOUNDARY-START(128851721959),
    {
      "p": 23562582,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68722179815,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 154621525735,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 128851721959,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128851721959)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120261787367),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": this.$h,
      "H": 120261787367,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120261787367),
//--TRIMMABLE-BOUNDARY-START(197571198695),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": this.$h,
      "H": 197571198695,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197571198695)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067474151),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 1310721
        },
        {
          "n": "serviceName",
          "p": 1310721
        },
        {
          "n": "tier",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30067474151,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067474151)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatureType?.$h??1638400,
      "n": "TFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 2703079,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<${TServiceTierType?.$fullName},${TFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ViewModels${separator}ServiceSubscriptionModel$${TServiceTierType?.$getFullName(separator)}$${TFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2703079)
        
        

        //--TRIMMABLE-BOUNDARY-START(3096295)
        $asm.$cls(`$dgLE.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298063591)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298063591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298063591)
            
            //--TRIMMABLE-BOUNDARY-START(4298063591)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298063591)
            
            static $h = 3096295;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298063591),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3096295,
      "h": 4298063591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298063591)
  ],
  "h": 3096295,
  "a": [
    {
      "t": 3030759,
      "c": 4297998055
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3096295)
        
        

        //--TRIMMABLE-BOUNDARY-START(3030759)
        $asm.$cls(`$dgLE.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297998055)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297998055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297998055)
            
            //--TRIMMABLE-BOUNDARY-START(4297998055)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297998055)
            
            static $h = 3030759;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297998055),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3030759,
      "h": 4297998055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297998055)
  ],
  "h": 3030759
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3030759)
        
        

        //--TRIMMABLE-BOUNDARY-START(1261287)
        $asm.$str(`$dgLE.LCPCSG.AppServiceGuardContext`, ($self) => class AppServiceGuardContext extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12886163175)
            /*string?*/ AppBasePath = null;
            //--TRIMMABLE-BOUNDARY-END(12886163175)
            
            //--TRIMMABLE-BOUNDARY-START(8591195879)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591195879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591195879)
            
            //--TRIMMABLE-BOUNDARY-START(8591195879)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591195879)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.AppBasePath = this.AppBasePath;
                return copy;
            }
            static $h = 1261287;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886163175),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476097767,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066032359,
        "f": 83886081
      },
      "n": "AppBasePath",
      "d": 1261287,
      "h": 12886163175,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886163175)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591195879),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1261287,
      "h": 8591195879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591195879)
  ],
  "h": 1261287
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceGuardContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceGuardContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1261287)
        
        

        //--TRIMMABLE-BOUNDARY-START(1457895)
        $asm.$str(`$dgLE.LCPCSG.AppServiceSelected<>`, (T) => $asm.$gt(`$dgLE.LCPCSG.AppServiceSelected<>`, [T], ($self) => class AppServiceSelected$$ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38656163559)
            /*T*/ Service = $.$default(T);
            //--TRIMMABLE-BOUNDARY-END(38656163559)
            
            //--TRIMMABLE-BOUNDARY-START(17181327079)
            /*bool*/ FromCache = false;
            //--TRIMMABLE-BOUNDARY-END(17181327079)
            
            //--TRIMMABLE-BOUNDARY-START(12886359783)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886359783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886359783)
            
            //--TRIMMABLE-BOUNDARY-START(12886359783)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886359783)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Service = this.Service;
                copy.FromCache = this.FromCache;
                return copy;
            }
            static $H = 1457895;
            static $h = 1457895;
            static $g = 1;
            static $z = 5;
            static $f = 0b1011000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656163559),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34361196263,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55836032743,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 38656163559,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656163559),
//--TRIMMABLE-BOUNDARY-START(17181327079),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25771261671,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47246098151,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886081
      },
      "n": "FromCache",
      "d": this.$h,
      "H": 17181327079,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181327079)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886359783),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 12886359783,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886359783)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 1457895,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceSelected<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceSelected$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1457895)
        
        

        //--TRIMMABLE-BOUNDARY-START(933607)
        $asm.$str(`$dgLE.LCPCS$1.CatalogueOrderProviderFeatures`, ($self) => class CatalogueOrderProviderFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Payment = 1;
            static Default = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(933607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Payment": 1n,
                    "Default": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295900903)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295900903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295900903)
            
            //--TRIMMABLE-BOUNDARY-START(4295900903)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295900903)
            
            static $h = 933607;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885835495),
    {
      "t": 933607,
      "n": "None",
      "d": 933607,
      "h": 12885835495,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885835495),
//--TRIMMABLE-BOUNDARY-START(17180802791),
    {
      "t": 933607,
      "n": "Payment",
      "d": 933607,
      "h": 17180802791,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180802791),
//--TRIMMABLE-BOUNDARY-START(8590868199),
    {
      "t": 933607,
      "n": "Default",
      "d": 933607,
      "h": 8590868199,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590868199)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295900903),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 933607,
      "h": 4295900903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295900903)
  ],
  "h": 933607,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.CatalogueOrderProviderFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}CatalogueOrderProviderFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(933607)
        
        

        //--TRIMMABLE-BOUNDARY-START(2178791)
        $asm.$str(`$dgLE.LCPCS$1.ServiceMenuSelectorFeatures`, ($self) => class ServiceMenuSelectorFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Search = 1;
            static Default = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2178791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Search": 1n,
                    "Default": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297146087)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297146087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297146087)
            
            //--TRIMMABLE-BOUNDARY-START(4297146087)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297146087)
            
            static $h = 2178791;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887080679),
    {
      "t": 2178791,
      "n": "None",
      "d": 2178791,
      "h": 12887080679,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887080679),
//--TRIMMABLE-BOUNDARY-START(17182047975),
    {
      "t": 2178791,
      "n": "Search",
      "d": 2178791,
      "h": 17182047975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182047975),
//--TRIMMABLE-BOUNDARY-START(8592113383),
    {
      "t": 2178791,
      "n": "Default",
      "d": 2178791,
      "h": 8592113383,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592113383)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297146087),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2178791,
      "h": 4297146087,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297146087)
  ],
  "h": 2178791,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ServiceMenuSelectorFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceMenuSelectorFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2178791)
        
        

        //--TRIMMABLE-BOUNDARY-START(1326823)
        $asm.$str(`$dgLE.LCPCSG.AppServiceGuardFeatures`, ($self) => class AppServiceGuardFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static UseHandleInPath = 1;
            static SelectServiceBeforeLogin = 2;
            static Default = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1326823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "UseHandleInPath": 1n,
                    "SelectServiceBeforeLogin": 2n,
                    "Default": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296294119)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296294119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296294119)
            
            //--TRIMMABLE-BOUNDARY-START(4296294119)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296294119)
            
            static $h = 1326823;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886228711),
    {
      "t": 1326823,
      "n": "None",
      "d": 1326823,
      "h": 12886228711,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886228711),
//--TRIMMABLE-BOUNDARY-START(21476163303),
    {
      "t": 1326823,
      "n": "UseHandleInPath",
      "d": 1326823,
      "h": 21476163303,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476163303),
//--TRIMMABLE-BOUNDARY-START(17181196007),
    {
      "t": 1326823,
      "n": "SelectServiceBeforeLogin",
      "d": 1326823,
      "h": 17181196007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181196007),
//--TRIMMABLE-BOUNDARY-START(8591261415),
    {
      "t": 1326823,
      "n": "Default",
      "d": 1326823,
      "h": 8591261415,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591261415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296294119),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1326823,
      "h": 4296294119,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296294119)
  ],
  "h": 1326823,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceGuardFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceGuardFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1326823)
        
        

        //--TRIMMABLE-BOUNDARY-START(2375399)
        $asm.$str(`$dgLE.LCPCS$1.ServiceSignUpFeatures`, ($self) => class ServiceSignUpFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static HidePrologue = 1;
            static AllowTierChange = 2;
            static Default = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2375399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "HidePrologue": 1n,
                    "AllowTierChange": 2n,
                    "Default": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297342695)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297342695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297342695)
            
            //--TRIMMABLE-BOUNDARY-START(4297342695)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297342695)
            
            static $h = 2375399;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477211879),
    {
      "t": 2375399,
      "n": "None",
      "d": 2375399,
      "h": 21477211879,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477211879),
//--TRIMMABLE-BOUNDARY-START(17182244583),
    {
      "t": 2375399,
      "n": "HidePrologue",
      "d": 2375399,
      "h": 17182244583,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182244583),
//--TRIMMABLE-BOUNDARY-START(8592309991),
    {
      "t": 2375399,
      "n": "AllowTierChange",
      "d": 2375399,
      "h": 8592309991,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592309991),
//--TRIMMABLE-BOUNDARY-START(12887277287),
    {
      "t": 2375399,
      "n": "Default",
      "d": 2375399,
      "h": 12887277287,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887277287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297342695),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2375399,
      "h": 4297342695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297342695)
  ],
  "h": 2375399,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ServiceSignUpFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceSignUpFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2375399)
        
        

        //--TRIMMABLE-BOUNDARY-START(2047719)
        $asm.$cls(`$dgLE.LCPCS$1.ProductLandingPage1`, ($self) => class ProductLandingPage1 extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591982311)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591982311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCL.ThreeColumnLayout, 0);
                __builder.AddComponentParameter(1, "FullPage", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 3);
                    __builder2.AddAttribute$3(4, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCB.Background, 5);
                            __builder3.AddComponentParameter(6, "Class", "hx-3 clip");
                            __builder3.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCB.BackgroundLayer, 8);
                                __builder4.AddAttribute$3(9, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(10, "<img src=\"LivingThing.Core.IOT.Devices/AutoTracks/Resources/img/autotracks.jpg\" style=\"background-size:cover;filter:blur(4px)\">");
                                }), $hbqzik ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                                __builder4.AddMarkupContent(11, "\r\n            ");
                                __builder4.OpenComponent$1($.$hDPm.LCFCCB.BackgroundLayer, 12);
                                __builder4.AddComponentParameter(13, "Class", "stack bg-dark-02");
                                __builder4.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder5) =>
                                {
                                    __builder5.OpenElement(15, "div");
                                    __builder5.AddAttribute$5(16, "class", "mg-a text-center cl-white");
                                    __builder5.AddMarkupContent(17, "<h1>LOREM IPSUM Title</h1>\r\n                    ");
                                    __builder5.AddMarkupContent(18, "<h2 class=\"op-8\">Lorem Ipsum Subtitle</h2>\r\n                    ");
                                    __builder5.AddMarkupContent(19, "<em class=\"fsz-20 op-6 d-block\">Lorem Ipsum SubSubtitle</em>\r\n                    ");
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 20);
                                    __builder5.AddComponentParameter(21, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder5.AddComponentParameter(22, "Class", "mgt-10");
                                    __builder5.AddComponentParameter(23, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~16/*ButtonFeatures.Shadow*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder5.AddAttribute$3(24, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder6) =>
                                    {
                                        __builder6.AddContent$4(25, "Click");
                                    }), $WvsLZe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                    __builder5.CloseElement();
                                }), $nDNatk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }), $eNAnZg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(26, "\r\n        ");
                            __builder3.OpenElement(27, "div");
                            __builder3.AddAttribute$5(28, "class", "pd-10 bg-dark flex");
                            __builder3.OpenElement(29, "div");
                            __builder3.AddAttribute$5(30, "class", "mg-a text-center");
                            __builder3.AddMarkupContent(31, "<h3 class=\"mgt-0 cl-white\">ENTER YOUR EMAIL TO BE NOTIFIED WHEN IT IS READY TO TRY OUT</h3>\r\n                ");
                            __builder3.OpenElement(32, "div");
                            __builder3.AddAttribute$5(33, "class", "row bg-white mawx-5 mg-a");
                            __builder3.AddMarkupContent(34, "<div class=\"col-10\"><input class=\"wp-100 hf pd bg-transparent bd-none\" placeholder=\"Email\"></div>\r\n                    ");
                            __builder3.OpenElement(35, "div");
                            __builder3.AddAttribute$5(36, "class", "col-a");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 37);
                            __builder3.AddComponentParameter(38, "Class", "nowrap");
                            __builder3.AddComponentParameter(39, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(40, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/ & ~16/*ButtonFeatures.Shadow*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder3.AddAttribute$3(41, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder4) =>
                            {
                                __builder4.AddContent$4(42, "NOTIFY ME");
                            }), $FnVQpe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(43, "\r\n        ");
                            __builder3.OpenElement(44, "div");
                            __builder3.AddAttribute$5(45, "class", "container clip pd-10");
                            __builder3.OpenElement(46, "div");
                            __builder3.AddAttribute$5(47, "class", "row responsive");
                            for(/*int*/ let i = 0; i < 4; i++)
                            {
                                __builder3.OpenElement(48, "div");
                                __builder3.AddAttribute$5(49, "class", "col-2 miwx-2 text-center");
                                __builder3.OpenElement(50, "div");
                                __builder3.AddAttribute$5(51, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("di-i-block" + " wx-07") + " hx-07") + " flex") + " bd") + " round") + " mgx-a") + " bg-") + $.$strNN(($.$$.S.String.ToLower.call($.$hDPm.LCFCC$1.ComponentExtension.Resolve(this, $.$fPer.LCFC.Theme.Random).ToString()))));
                                __builder3.AddMarkupContent(52, "<i class=\"mdi mdi-store fsz-50 text-center mg-a\"></i>");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(53, "\r\n                        ");
                                __builder3.AddMarkupContent(54, "<h4>Lorem Ipsum Feature</h4>\r\n                        ");
                                __builder3.AddMarkupContent(55, "<em class=\"fsz-small op-8\">\r\n                            Microsoft .AspNetCore .Cors .Infrastructure.CorsService: Information: CORS policy execution failed.\r\n                        </em>");
                                __builder3.CloseElement();
                            }
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(56, "\r\n        ");
                            __builder3.OpenElement(57, "div");
                            __builder3.AddAttribute$5(58, "class", "bg-primary pd-10 container clip");
                            __builder3.OpenElement(59, "div");
                            __builder3.AddAttribute$5(60, "class", "row responsive");
                            for(/*int*/ let i = 0; i < 4; i++)
                            {
                                __builder3.OpenElement(61, "div");
                                __builder3.AddAttribute$5(62, "class", "col-2 miwx-2 text-center");
                                __builder3.OpenElement(63, "h2");
                                __builder3.AddAttribute$5(64, "class", "cl-white mgt-0");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCC$12.Counter, 65);
                                __builder3.AddComponentParameter(66, "To", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, 1234), $.$$.S.Double));
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(67, "+\r\n                        ");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(68, "\r\n                        ");
                                __builder3.AddMarkupContent(69, "<h2 class=\"cl-white mgb-1\">Customers</h2>\r\n                        ");
                                __builder3.AddMarkupContent(70, "<em class=\"op-8\">acquired in 1 year</em>");
                                __builder3.CloseElement();
                            }
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(71, "\r\n        ");
                            __builder3.OpenElement(72, "div");
                            __builder3.AddAttribute$5(73, "class", "container clip pd-10");
                            __builder3.OpenElement(74, "div");
                            __builder3.AddAttribute$5(75, "class", "row responsive");
                            for(/*int*/ let i = 0; i < 4; i++)
                            {
                                __builder3.OpenElement(76, "div");
                                __builder3.AddAttribute$5(77, "class", "col-2 miwx-2 text-center");
                                __builder3.OpenElement(78, "div");
                                __builder3.AddAttribute$5(79, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("di-i-block" + " wx-07") + " hx-07") + " flex") + " bd") + " round") + " mgx-a") + " bg-") + $.$strNN(($.$$.S.String.ToLower.call($.$hDPm.LCFCC$1.ComponentExtension.Resolve(this, $.$fPer.LCFC.Theme.Random).ToString()))));
                                __builder3.AddMarkupContent(80, "<i class=\"mdi mdi-store fsz-50 text-center mg-a\"></i>");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(81, "\r\n                        ");
                                __builder3.AddMarkupContent(82, "<h4>Lorem Ipsum Feature</h4>\r\n                        ");
                                __builder3.AddMarkupContent(83, "<em class=\"fsz-small op-8\">\r\n                            Microsoft .AspNetCore .Cors .Infrastructure.CorsService: Information: CORS policy execution failed.\r\n                        </em>\r\n                        ");
                                __builder3.AddMarkupContent(84, "<a class=\"cl-primary d-block mgt fw-bold\">Learn more</a>");
                                __builder3.CloseElement();
                            }
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(85, "\r\n        ");
                            __builder3.AddMarkupContent(86, "<div class=\"clip bg-dark-03\"><div class=\"row\"><div class=\"col-5 flex pd-10\"><div class=\"wx-3 hx-3 round clip mg-a\"><img src=\"LivingThing.Core.IOT.Devices/AutoTracks/Resources/img/autotracks.jpg\"></div></div>\r\n                <div class=\"col-5\"><h1>Benefits</h1>\r\n                    <ul class=\"fsz-22\"><li>Benefit 1</li>\r\n                        <li>Benefit 2</li>\r\n                        <li>Benefit 3</li>\r\n                        <li>Benefit 4</li>\r\n                        <li>Benefit 5</li>\r\n                        <li>Benefit 6</li>\r\n                        <li>Benefit 7</li></ul></div></div></div>\r\n        ");
                            __builder3.AddMarkupContent(87, "<div class=\"clip bg-dark-05\"><div class=\"row\"><div class=\"col-5 flex pd-10\"><div class=\"wx-3 hx-3 round clip mg-a\"><img src=\"LivingThing.Core.IOT.Devices/AutoTracks/Resources/img/autotracks.jpg\"></div></div>\r\n                <div class=\"col-5\"><h1>Benefits</h1>\r\n                    <p class=\"fsz-22\">Partner with us and you wont regret it</p>\r\n                    <p>We have partenred with 100 compnaies...</p></div></div></div>\r\n        ");
                            __builder3.OpenElement(88, "div");
                            __builder3.AddAttribute$5(89, "class", "container clip pd bg-dark-01");
                            __builder3.OpenElement(90, "div");
                            __builder3.AddAttribute$5(91, "class", "row responsive");
                            __builder3.OpenElement(92, "div");
                            __builder3.AddAttribute$5(93, "class", "col-5 miwx-3");
                            __builder3.AddMarkupContent(94, "<h2>Our Monthly performace</h2>\r\n                    ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.S.Double), 95);
                            __builder3.AddComponentParameter(96, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.Double), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), [1, 2, 3, 4, 5, 6, 7, 8, 5, 2], null, null)));
                            __builder3.AddComponentParameter(97, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Double, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*t*/ t) =>
                            {
                                return $.$$.S.Int32.ToString.call(i);
                            }), $lGThXa ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"t","p":1179649}],"n":"","d":2047719,"h":0,"f":17825794}));
                            __builder3.AddComponentParameter(98, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/ & ~16/*ChartFeatures.Legend*/ & ~32/*ChartFeatures.LinePoint*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                            __builder3.AddAttribute$3(99, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double), 100);
                                    __builder4.AddComponentParameter(101, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.S.Double))().$ctor(this, ( (/*t*/ t) =>
                                    {
                                        return $.$box(t.LCFCCD$1$IDataListItemContext$$$Data, $.$$.S.Double);
                                    }), $THulKg ??= {"r":131073,"p":[{"n":"t","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Double).$h}],"n":"","d":2047719,"h":0,"f":17825794}));
                                    __builder4.AddComponentParameter(102, "Label", "");
                                    __builder4.AddComponentParameter(103, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 1)) + "20"));
                                    __builder4.AddComponentParameter(104, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 1)));
                                    __builder4.AddComponentParameter(105, "PointColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 1)));
                                    __builder4.CloseComponent();
                                }, $tzhGgj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794});
                            }), $kKlyVe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double)).$h}],"n":"","d":2047719,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(106, "\r\n                ");
                            __builder3.OpenElement(107, "div");
                            __builder3.AddAttribute$5(108, "class", "col-5 miwx-3");
                            __builder3.AddMarkupContent(109, "<h2>Our Monthly performace</h2>\r\n                    ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.S.Double), 110);
                            __builder3.AddComponentParameter(111, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.Double), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), [1, 2, 3, 4, 5, 6, 7, 8, 5, 2], null, null)));
                            __builder3.AddComponentParameter(112, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Double, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*t*/ t) =>
                            {
                                return $.$$.S.Int32.ToString.call(i);
                            }), $zpqQjj ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"t","p":1179649}],"n":"","d":2047719,"h":0,"f":17825794}));
                            __builder3.AddComponentParameter(113, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/ & ~16/*ChartFeatures.Legend*/ & ~32/*ChartFeatures.LinePoint*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                            __builder3.AddAttribute$3(114, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double), 115);
                                    __builder4.AddComponentParameter(116, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.S.Double))().$ctor(this, ( (/**/ t) =>
                                    {
                                        return $.$box(t.LCFCCD$1$IDataListItemContext$$$Data, $.$$.S.Double);
                                    }), $shFYDi ??= {"r":131073,"p":[{"n":"t","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Double).$h}],"n":"","d":2047719,"h":0,"f":17825794}));
                                    __builder4.AddComponentParameter(117, "Label", "");
                                    __builder4.AddComponentParameter(118, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)) + "20"));
                                    __builder4.AddComponentParameter(119, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 2)));
                                    __builder4.AddComponentParameter(120, "PointColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 2)));
                                    __builder4.CloseComponent();
                                }, $UtnSEf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794});
                            }), $VoohOd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double)).$h}],"n":"","d":2047719,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(121, "\r\n        ");
                            __builder3.OpenElement(122, "div");
                            __builder3.AddAttribute$5(123, "class", "bg-primary container pd");
                            __builder3.AddMarkupContent(124, "<h1 class=\"cl-white text-center\">\r\n                Everybody is signing up already. Don't be left behind.\r\n            </h1>\r\n            ");
                            __builder3.AddMarkupContent(125, "<h3 class=\"cl-white text-center\">Fill form to continue</h3>\r\n            ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 126);
                            __builder3.AddComponentParameter(127, "Class", "mg-a mawx-4 miwx-3");
                            __builder3.AddComponentParameter(128, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ | 4/*CardFeatures.Shadow*/), $.$hDPm.LCFCCC$1.CardFeatures));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                        }, $cMkcvh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794});
                    }), $WIgohj ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":2047719,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $Naikjk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2047719,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8591982311)
            
            //--TRIMMABLE-BOUNDARY-START(4297015015)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297015015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297015015)
            
            //--TRIMMABLE-BOUNDARY-START(4297015015)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297015015)
            
            static $h = 2047719;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591982311),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2047719,
      "h": 8591982311,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591982311)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297015015),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2047719,
      "h": 4297015015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297015015)
  ],
  "h": 2047719,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/LP",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ProductLandingPage1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ProductLandingPage1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2047719)
        
        

        //--TRIMMABLE-BOUNDARY-START(278247)
        $asm.$cls(`$dgLE.LCPC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590212839)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590212839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590212839)
            
            //--TRIMMABLE-BOUNDARY-START(4295245543)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295245543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295245543)
            
            //--TRIMMABLE-BOUNDARY-START(4295245543)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295245543)
            
            static $h = 278247;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590212839),
    {
      "r": 65537,
      "n": "Execute",
      "d": 278247,
      "h": 8590212839,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590212839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295245543),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 278247,
      "h": 4295245543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295245543)
  ],
  "h": 278247
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(278247)
        
        

        //--TRIMMABLE-BOUNDARY-START(1064679)
        $asm.$cls(`$dgLE.LCPCS$1.CatalogueOrderViews`, ($self) => class CatalogueOrderViews extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590999271)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590999271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590999271)
            
            //--TRIMMABLE-BOUNDARY-START(12885966567)
            static /*RenderFragment */ OrderItems(/*BaseComponent*/ caller, /*ICatalogueProvider*/ store, /*IEnumerable<ICatalogueOrderItemModel>*/ orderItems, /*bool*/ editable, /*bool*/ total)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885966567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(0, "\r\n        ");
                    __builder2.OpenElement(1, "div");
                    __builder2.AddAttribute$5(2, "class", "fill scroll");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), 3);
                    __builder2.AddComponentParameter(4, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), orderItems));
                    __builder2.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), 7);
                            __builder3.AddComponentParameter(8, "th-class", "miwx-2");
                            __builder3.AddAttribute$3(9, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)))().$ctor(this, ( (/*_*/ _0) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(10, "<div class=\"miwx-2\">ITEM</div>");
                                }, $TvkUme ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $ecEDyc ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(11, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))))().$ctor(this, ( (/*data*/ data) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(12, "div");
                                    __builder4.AddAttribute$5(13, "class", "flex");
                                    __builder4.OpenElement(14, "div");
                                    __builder4.AddAttribute$5(15, "class", "mgy-a mgr-3");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 16);
                                    __builder4.AddComponentParameter(17, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, $.$Iaui.LCFCM.ResourceModel.op_Implicit$1(data.Data.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFC$IDisplayable$Icon)));
                                    __builder4.AddComponentParameter(18, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                                    __builder4.AddComponentParameter(19, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                                    __builder4.AddComponentParameter(20, "Class", "round");
                                    __builder4.AddComponentParameter(21, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(22, "\r\n                            ");
                                    __builder4.OpenElement(23, "b");
                                    __builder4.AddAttribute$5(24, "class", "mgy-a");
                                    __builder4.AddContent$4(25, data.Data.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFC$IDisplayable$Title);
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                }, $xrPOQi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $MAkGbc ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(26, "\r\n                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), 27);
                            __builder3.AddAttribute$3(28, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)))().$ctor(this, ( (/*_*/ _0) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(29, "PRICE");
                                }, $XEsUXi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $qMdhjk ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))))().$ctor(this, ( (/*data*/ data) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$3(31, data.Data.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFCP$ICatalogueModel$UnitCost);
                                }, $mdKKQe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $qggmja ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(32, "\r\n                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), 33);
                            __builder3.AddAttribute$3(34, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)))().$ctor(this, ( (/*_*/ _0) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.AddContent$4(35, "QUANTITY");
                                }, $ucjgYg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $pjULVd ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(36, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))))().$ctor(this, ( (/*data*/ data) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(37, "div");
                                    __builder4.AddAttribute$5(38, "class", "stack");
                                    if (data.Data.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFCP$ICatalogueModel$UnitInPack > 0 && $.$fPer.LCFCDM.Money.op_Implicit(data.Data.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFCP$ICatalogueModel$PackCost) > 0)
                                    {
                                        __builder4.OpenElement(39, "div");
                                        __builder4.AddAttribute$5(40, "class", "flex");
                                        __builder4.AddMarkupContent(41, "<small class=\"op-8 mgr-2 mgy-a\">Pack</small>\r\n                                ");
                                        __builder4.OpenElement(42, "div");
                                        __builder4.AddAttribute$5(43, "class", "mgl-a flex mgb-1");
                                        if (editable)
                                        {
                                            /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ let att = null;
                                            att = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass(att, "hx-02 wx-02 pd-0 fsz-13 corner-2 bg-primary"), new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                if (data.Data.LCFCP$ICatalogueOrderItemModel$PackQuantity < 0)
                                                {
                                                    ($.$cast(data.Data, $.$AvdQ.LCFCP.IEditableCatalogueOrderItemModel)).LCFCP$IEditableCatalogueOrderItemModel$PackQuantity++;
                                                    let list;
                                                    if (data.Data.LCFCP$ICatalogueOrderItemModel$PackQuantity === 0 && data.Data.LCFCP$ICatalogueOrderItemModel$UnitQuantity === 0 && $.$is(orderItems, $.$$.SCG.List$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), { set $v($v){ list = $v; } }))
                                                    {
                                                        list.Remove(data.Data);
                                                    }
                                                }
                                            }, $ofEyLi ??= {"r":65537,"n":"","d":1064679,"h":0,"f":17825794}), caller, false, null, null, null, null, null, null);
                                            __builder4.OpenElement(44, "button");
                                            __builder4.AddMultipleAttributes(45, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(att)));
                                            __builder4.AddAttribute$5(46, "type", "button");
                                            __builder4.AddContent$4(47, "-");
                                            __builder4.CloseElement();
                                        }
                                        __builder4.OpenElement(48, "span");
                                        __builder4.AddAttribute$5(49, "class", "mgy-a mgx");
                                        __builder4.AddContent$3(50, $.$box($.$$.S.Math.Abs$3(data.Data.LCFCP$ICatalogueOrderItemModel$PackQuantity), $.$$.S.Int32));
                                        __builder4.CloseElement();
                                        if (editable)
                                        {
                                            /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ let att = null;
                                            att = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass(att, "hx-02 wx-02 pd-0 fsz-13 corner-2 bg-primary"), new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                ($.$cast(data.Data, $.$AvdQ.LCFCP.IEditableCatalogueOrderItemModel)).LCFCP$IEditableCatalogueOrderItemModel$PackQuantity--;
                                            }, $KZcFka ??= {"r":65537,"n":"","d":1064679,"h":0,"f":17825794}), caller, false, null, null, null, null, null, null);
                                            __builder4.OpenElement(51, "button");
                                            __builder4.AddMultipleAttributes(52, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(att)));
                                            __builder4.AddAttribute$5(53, "type", "button");
                                            __builder4.AddContent$4(54, "+");
                                            __builder4.CloseElement();
                                        }
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                    }
                                    __builder4.OpenElement(55, "div");
                                    __builder4.AddAttribute$5(56, "class", "flex");
                                    __builder4.AddMarkupContent(57, "<small class=\"op-8 mgr-2 mgy-a\">Unit</small>\r\n                                ");
                                    __builder4.OpenElement(58, "div");
                                    __builder4.AddAttribute$5(59, "class", "mgl-a flex");
                                    if (editable)
                                    {
                                        /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ let att = null;
                                        att = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass(att, "hx-02 wx-02 pd-0 fsz-13 corner-2 bg-primary"), new $.$$.S.Action().$ctor(this,  () =>
                                        {
                                            if (data.Data.LCFCP$ICatalogueOrderItemModel$UnitQuantity < 0)
                                            {
                                                ($.$cast(data.Data, $.$AvdQ.LCFCP.IEditableCatalogueOrderItemModel)).LCFCP$IEditableCatalogueOrderItemModel$UnitQuantity++;
                                                let list;
                                                if (data.Data.LCFCP$ICatalogueOrderItemModel$PackQuantity === 0 && data.Data.LCFCP$ICatalogueOrderItemModel$UnitQuantity === 0 && $.$is(orderItems, $.$$.SCG.List$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), { set $v($v){ list = $v; } }))
                                                {
                                                    list.Remove(data.Data);
                                                }
                                            }
                                        }, $GvQemc ??= {"r":65537,"n":"","d":1064679,"h":0,"f":17825794}), caller, false, null, null, null, null, null, null);
                                        __builder4.OpenElement(60, "button");
                                        __builder4.AddMultipleAttributes(61, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(att)));
                                        __builder4.AddAttribute$5(62, "type", "button");
                                        __builder4.AddContent$4(63, "-");
                                        __builder4.CloseElement();
                                    }
                                    __builder4.OpenElement(64, "span");
                                    __builder4.AddAttribute$5(65, "class", "mgy-a mgx");
                                    __builder4.AddContent$3(66, $.$box($.$$.S.Math.Abs$3(data.Data.LCFCP$ICatalogueOrderItemModel$UnitQuantity), $.$$.S.Int32));
                                    __builder4.CloseElement();
                                    if (editable)
                                    {
                                        /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ let att = null;
                                        att = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass(att, "hx-02 wx-02 pd-0 fsz-13 corner-2 bg-primary"), new $.$$.S.Action().$ctor(this,  () =>
                                        {
                                            ($.$cast(data.Data, $.$AvdQ.LCFCP.IEditableCatalogueOrderItemModel)).LCFCP$IEditableCatalogueOrderItemModel$UnitQuantity--;
                                        }, $qxZVhd ??= {"r":65537,"n":"","d":1064679,"h":0,"f":17825794}), caller, false, null, null, null, null, null, null);
                                        __builder4.OpenElement(67, "button");
                                        __builder4.AddMultipleAttributes(68, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(att)));
                                        __builder4.AddAttribute$5(69, "type", "button");
                                        __builder4.AddContent$4(70, "+");
                                        __builder4.CloseElement();
                                    }
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                }, $ZDoUel ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $FBGeqg ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(71, "\r\n                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), 72);
                            __builder3.AddAttribute$3(73, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)))().$ctor(this, ( (/*_*/ _0) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(74, "TOTAL");
                                }, $mEdmdi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $QEVEHc ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(75, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))))().$ctor(this, ( (/*data*/ data) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(76, "b");
                                    __builder4.AddContent$3(77, data.Data.LCFCP$ICatalogueOrderItemModel$TotalAmount);
                                    __builder4.CloseElement();
                                }, $jxJPdj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                            }), $BYQvbl ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            if (editable)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel), 78);
                                __builder3.AddAttribute$3(79, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))))().$ctor(this, ( (/*data*/ data) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ let att = null;
                                        att = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick($.$hDPm.LCFCC$1.ComponentExtension.AddClass(att, "mdi mdi-delete hx-02 wx-02 pd-0 fsz-13 corner-2 bg-fatal"), new $.$$.S.Action().$ctor(this,  () =>
                                        {
                                            ($.$cast(orderItems, $.$$.SCG.List$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))).Remove(data.Data);
                                        }, $ADKvpa ??= {"r":65537,"n":"","d":1064679,"h":0,"f":17825794}), caller, false, null, null, null, null, null, null);
                                        __builder4.OpenElement(80, "button");
                                        __builder4.AddMultipleAttributes(81, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(att)));
                                        __builder4.AddAttribute$5(82, "type", "button");
                                        __builder4.CloseElement();
                                    }, $KAyptf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                                }), $UpflDk ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                        }, $ScBUmg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
                    }), $hPVnva ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel)).$h}],"n":"","d":1064679,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    if (total)
                    {
                        /*var*/ let vatRate = (store.LCFCP$ICatalogueProvider$Settings?.LCFCP$ICatalogueSettings$VATRate ?? null) ?? 0;
                        __builder2.OpenElement(83, "div");
                        __builder2.AddAttribute$5(84, "class", "flex mgt-a pd bg-dark-02");
                        __builder2.AddMarkupContent(85, "<div class=\"fill\"></div>\r\n            ");
                        __builder2.OpenElement(86, "div");
                        __builder2.AddAttribute$6(87, "class");
                        __builder2.AddMarkupContent(88, "<div>Sub Total</div>");
                        if (vatRate > 0)
                        {
                            __builder2.OpenElement(89, "div");
                            __builder2.AddAttribute$5(90, "class", "mgy-1");
                            __builder2.AddContent$4(91, "VAT (");
                            __builder2.AddContent$3(92, $.$box(vatRate, $.$$.S.Double));
                            __builder2.AddContent$4(93, "%)");
                            __builder2.CloseElement();
                        }
                        __builder2.AddMarkupContent(94, "<div class=\"cl-primary fw-bold fsz-20\">Total Payment</div>");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(95, "\r\n            ");
                        __builder2.OpenElement(96, "div");
                        __builder2.AddAttribute$5(97, "class", "mgl-10 fw-bold");
                        /*var*/ let amount = $.$sl.SL.Enumerable.Count$1($.$AvdQ.LCFCP.ICatalogueOrderItemModel, orderItems) > 0 ? $.$sl.SL.Enumerable.Aggregate$2($.$fPer.LCFCDM.Money, $.$sl.SL.Enumerable.Select$1($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$fPer.LCFCDM.Money, orderItems, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*i*/ i) =>
                        {
                            return i.LCFCP$ICatalogueOrderItemModel$TotalAmount;
                        }, $xtyxga ??= {"r":27822422,"p":[{"n":"i","p":2077632}],"n":"","d":1064679,"h":0,"f":17825794})), new ($.$$.S.Func$$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                        {
                            return $.$fPer.LCFCDM.Money.op_Addition(a, b);
                        }, $hbhYbk ??= {"r":27822422,"p":[{"n":"a","p":27822422},{"n":"b","p":27822422}],"n":"","d":1064679,"h":0,"f":17825794})) : new $.$fPer.LCFCDM.Money().$ctor$2();
                        /*var*/ let vat = $.$fPer.LCFCDM.Money.op_Division($.$fPer.LCFCDM.Money.op_Implicit$1(vatRate) * $.$fPer.LCFCDM.Money.op_Implicit(amount), 100);
                        /*var*/ let total = $.$fPer.LCFCDM.Money.op_Addition(amount, vat);
                        __builder2.OpenElement(98, "div");
                        __builder2.AddAttribute$5(99, "class", "text-right");
                        __builder2.AddContent$3(100, $.$clone(amount));
                        __builder2.CloseElement();
                        if (vatRate > 0)
                        {
                            __builder2.OpenElement(101, "div");
                            __builder2.AddAttribute$5(102, "class", "mgy-1 text-right");
                            __builder2.AddContent$3(103, $.$clone(vat));
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(104, "div");
                        __builder2.AddAttribute$5(105, "class", "cl-primary text-right fsz-20");
                        __builder2.AddContent$3(106, $.$clone(total));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                }, $Hgankf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1064679,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12885966567)
            
            //--TRIMMABLE-BOUNDARY-START(4296031975)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296031975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296031975)
            
            //--TRIMMABLE-BOUNDARY-START(4296031975)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296031975)
            
            static $h = 1064679;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590999271),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1064679,
      "h": 8590999271,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590999271),
//--TRIMMABLE-BOUNDARY-START(12885966567),
    {
      "r": 6881395,
      "p": [
        {
          "n": "caller",
          "p": 4871850
        },
        {
          "n": "store",
          "p": 2339776
        },
        {
          "n": "orderItems",
          "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h
        },
        {
          "n": "editable",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "total",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "OrderItems",
      "d": 1064679,
      "h": 12885966567,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885966567)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296031975),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1064679,
      "h": 4296031975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296031975)
  ],
  "h": 1064679
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.CatalogueOrderViews`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}CatalogueOrderViews`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1064679)
        
        

        //--TRIMMABLE-BOUNDARY-START(1654503)
        $asm.$cls(`$dgLE.LCPCSG.AppServiceSwitch`, ($self) => class AppServiceSwitch extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21476490983)
            /*string */ get OptimizedComponentName()
            {
                return "appserviceswitch";
            }
            //--TRIMMABLE-BOUNDARY-END(21476490983)
            
            //--TRIMMABLE-BOUNDARY-START(8591589095)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591589095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591589095)
            
            //--TRIMMABLE-BOUNDARY-START(25771458279)
            static /*RenderFragment */ StaticComponentTitle(/*IClientUnitOfWork*/ unitOfWork, /*IFixedComponentControl*/ fixedComponent, /*IAppServiceGuard?*/ guard)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771458279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let att = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick$1($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "mdi mdi-cog bg-transparent"), new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        if (guard !== null)
                        {
                            /*CancellationTokenSource*/ let cts = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                            try
                            {
                                let $t1, $r1;
                                ($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                                {
                                    return guard.LCPCSG$IAppServiceGuard$GetSelectorView(new ($.$$.S.Action$$($.$fPer.LCFCD.IServiceDataModel))().$ctor(this,  (/**/ v) =>
                                    {
                                        return cts.Cancel();
                                    }, $RYcKXh ??= {"r":65537,"p":[{"n":"v","p":23562582}],"n":"","d":1654503,"h":0,"f":17825794}));
                                }, $hVXqvk ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1654503,"h":0,"f":17825794}), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Select ${$.$strNN((guard?.LCPCSG$IAppServiceGuard$Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel ?? null))}`, false), null, cts.Token, (() =>
                                {
                                    //new $.$hDPm.LCFCI.ViewConfiguration()
                                    const $t2 = $.$hDPm.LCFCI.ViewConfiguration;
                                    const $i2 = new $t2();
                                    $i2.$ctor$2();
                                    $i2.ViewFeatures = (5731/*ViewFeatures.ViewDefault*/ & ~1/*ViewFeatures.OKToolBar*/ & ~2/*ViewFeatures.CancelToolBar*/) | 32/*ViewFeatures.Header*/ | 128/*ViewFeatures.Closable*/;
                                    return $i2;
                                })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            }
                            finally
                            {
                                {
                                    let $t3, $r3;
                                    ($t3 = fixedComponent.LCFCS$IFixedComponentControl$Close(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                }
                            }
                        }
                    });
                }, $gZYxod ??= {"r":178454529,"n":"","d":1654503,"h":0,"f":17829890}), null, false, null, null, null, null, null, null);
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(0, "\r\n        ");
                    __builder2.OpenElement(1, "span");
                    __builder2.AddAttribute$5(2, "class", "fill");
                    __builder2.AddContent$4(3, "Switch ");
                    __builder2.AddContent$4(4, (guard?.LCPCSG$IAppServiceGuard$Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel ?? null));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(5, "\r\n        ");
                    __builder2.OpenElement(6, "button");
                    __builder2.AddMultipleAttributes(7, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build(att)));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(8, "\r\n    ");
                }, $LGZruf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1654503,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(25771458279)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296621799)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296621799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296621799)
            
            //--TRIMMABLE-BOUNDARY-START(4296621799)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296621799)
            
            static $h = 1654503;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476490983),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181523687,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1654503,
      "h": 21476490983,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476490983)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591589095),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1654503,
      "h": 8591589095,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591589095),
//--TRIMMABLE-BOUNDARY-START(25771458279),
    {
      "r": 6881395,
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "fixedComponent",
          "p": 69621418
        },
        {
          "n": "guard",
          "p": 1720039
        }
      ],
      "n": "StaticComponentTitle",
      "d": 1654503,
      "h": 25771458279,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25771458279)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296621799),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1654503,
      "h": 4296621799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296621799)
  ],
  "h": 1654503
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceSwitch`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceSwitch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1654503)
        
        

        //--TRIMMABLE-BOUNDARY-START(2506471)
        $asm.$cls(`$dgLE.LCPCS$1.ServiceTiers<,>`, (TServiceTierType, TServiceFeatureType) => $asm.$gt(`$dgLE.LCPCS$1.ServiceTiers<,>`, [TServiceTierType, TServiceFeatureType], ($self) => class ServiceTiers$$$ extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(68721983207)
            /*ServiceTierModel<TServiceTierType, TServiceFeatureType>?*/ selected = null;
            //--TRIMMABLE-BOUNDARY-END(68721983207)
            
            //--TRIMMABLE-BOUNDARY-START(90196819687)
            /*IEnumerable<ServiceTierModel<TServiceTierType, TServiceFeatureType>>*/ Tiers = null;
            //--TRIMMABLE-BOUNDARY-END(90196819687)
            
            //--TRIMMABLE-BOUNDARY-START(60132048615)
            /*EventCallback<ServiceTierModel<TServiceTierType, TServiceFeatureType>>*/ OnSelected;
            //--TRIMMABLE-BOUNDARY-END(60132048615)
            
            //--TRIMMABLE-BOUNDARY-START(51542114023)
            /*bool */ IsSingleBit(/*TServiceFeatureType*/ feature)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542114023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let hasSeenBit = false;
                for(/*long*/ let bt = 1n; bt !== 0n; bt <<= 1n)
                {
                    if ($.$fPer.LCFCT.EnumExtensions.IsEnumSet$1(TServiceFeatureType, feature, bt))
                    {
                        if (hasSeenBit)
                        {
                            return false;
                        }
                        hasSeenBit = true;
                    }
                }
                return hasSeenBit;
            }
            //--TRIMMABLE-BOUNDARY-END(51542114023)
            
            //--TRIMMABLE-BOUNDARY-START(21477342951)
            /*int */ CountTiersOf(/*TServiceFeatureType*/ feature)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477342951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Count($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), this.Tiers, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return ((t.Features & (feature)) == (feature));
                }, $NTNTwj ??= {"r":262145,"p":[{"n":"t","p":$.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(21477342951)
            
            //--TRIMMABLE-BOUNDARY-START(55837081319)
            /*void */ OnClick(/*ServiceTierModel<TServiceTierType, TServiceFeatureType>*/ tier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837081319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selected = tier;
            }
            //--TRIMMABLE-BOUNDARY-END(55837081319)
            
            //--TRIMMABLE-BOUNDARY-START(64427015911)
            /*string */ get OptimizedComponentName()
            {
                return "servicetiers";
            }
            //--TRIMMABLE-BOUNDARY-END(64427015911)
            
            //--TRIMMABLE-BOUNDARY-START(94491786983)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491786983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Tiers":
                    this.Tiers = $.$cast(parameter.Value, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)));
                    return true;
                    case "OnSelected":
                    this.OnSelected = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(94491786983)
            
            //--TRIMMABLE-BOUNDARY-START(17182375655)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182375655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCC$2.Carousel, 0);
                __builder.AddComponentParameter(1, "StepWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 250), $.$$.S.Int32));
                __builder.AddAttribute$3(2, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(3, "div");
                        __builder2.AddAttribute$5(4, "class", "row");
                        let $en2 = this.Tiers.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let _tier = $en2.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let tier = _tier;
                                __builder2.OpenElement(5, "div");
                                __builder2.AddAttribute$5(6, "class", `bg-card pdy-5 mgr text-center wx-25 bd ${$.$strNN((tier === this.selected ? "bdw-2 bd-primary" : ""))}`);
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 7, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                {
                                    return this.OnClick(tier);
                                }, $bDUTAg ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                                __builder2.OpenElement(8, "h2");
                                __builder2.AddAttribute$5(9, "class", "cl-primary mgt-0 mgb-2");
                                __builder2.AddContent$4(10, tier.Name);
                                __builder2.CloseElement();
                                if (tier.Description !== null)
                                {
                                    __builder2.OpenElement(11, "span");
                                    __builder2.AddAttribute$5(12, "class", "pdx d-block");
                                    if (tier.Description.length > 256)
                                    {
                                        __builder2.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 13);
                                        __builder2.AddComponentParameter(14, "pop-class", "shadow border bg-card");
                                        __builder2.AddAttribute$3(15, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ _0) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                            {
                                                __builder3.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 16);
                                                __builder3.AddComponentParameter(17, "Class", "mdi mdi-information-outline");
                                                __builder3.CloseComponent();
                                                __builder3.AddMarkupContent(18, "\r\n                                    ");
                                                __builder3.AddContent$4(19, $.$fPer.LCFCS$6.StringExtension.LimitLength(tier.Description, 256, true));
                                            }, $pmFEfh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                        }), $YPCTee ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder2.AddAttribute$3(20, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/*_*/ _0) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                            {
                                                __builder3.AddContent$4(21, tier.Description);
                                            }, $ewyTng ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                        }), $XPdBZa ??= {"r":6881395,"p":[{"n":"_","p":39540394}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder2.CloseComponent();
                                    }
                                    else 
                                    {
                                        __builder2.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 22);
                                        __builder2.AddComponentParameter(23, "Class", "mdi mdi-information-outline");
                                        __builder2.CloseComponent();
                                        __builder2.AddContent$4(24, tier.Description);
                                    }
                                    __builder2.CloseElement();
                                }
                                __builder2.OpenElement(25, "h2");
                                __builder2.AddAttribute$5(26, "class", "cl-secondary");
                                __builder2.AddContent$4(27, tier.Cost.ToString$1(0/*MoneyFormat.None*/));
                                __builder2.AddContent$4(28, " ");
                                __builder2.AddContent$4(29, tier.AmountQualification);
                                __builder2.CloseElement();
                                if (tier.Limit > 0)
                                {
                                    __builder2.OpenElement(30, "div");
                                    __builder2.AddAttribute$5(31, "class", "mgb-5");
                                    if (tier.Limit === 0)
                                    {
                                        __builder2.AddContent$4(32, "For more than one devices");
                                    }
                                    else 
                                    {
                                        __builder2.AddContent$4(33, "For ");
                                        __builder2.AddContent$3(34, $.$box(tier.Limit, $.$$.S.Int32));
                                        __builder2.AddContent$4(35, " ");
                                        __builder2.AddContent$4(36, tier.LimitQuantification);
                                    }
                                    __builder2.CloseElement();
                                }
                                __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType)), 37);
                                __builder2.AddComponentParameter(38, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder2.AddComponentParameter(39, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$18(1, 2147483647/*int.MaxValue*/)));
                                __builder2.AddComponentParameter(40, "Class", "text-center");
                                __builder2.AddComponentParameter(41, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType)), $.$sl.SL.Enumerable.OrderByDescending$1($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType), $.$$.S.Int32, $.$sl.SL.Enumerable.Where($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType), $.$fPer.LCFCF$1.FastEnumRegistry.GetNamesAndValues(TServiceFeatureType), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                                {
                                    return t.Item1 !== "None" && t.Item1 !== "All" && t.Item1 !== "Max" && this.IsSingleBit(t.Item2);
                                }, $guQsKi ??= {"r":262145,"p":[{"n":"t","p":$.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType), $.$$.S.Int32))().$ctor(this,  (/*t*/ t) =>
                                {
                                    return this.CountTiersOf(t.Item2);
                                }, $PfpLtc ??= {"r":655361,"p":[{"n":"t","p":$.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                                __builder2.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType)))))().$ctor(this, ( (/**/ feature) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenElement(43, "div");
                                        __builder3.AddAttribute$5(44, "class", "pd-2");
                                        if (((tier.ServiceFeatures & (feature.Data.Item2)) == (feature.Data.Item2)))
                                        {
                                            __builder3.AddMarkupContent(45, "<i class=\"mgr-2 mdi mdi-check cl-success\"></i>");
                                        }
                                        else 
                                        {
                                            __builder3.AddMarkupContent(46, "<i class=\"mgr-2 mdi mdi-close cl-error\"></i>");
                                        }
                                        /*var*/ let schema = $.$fPer.LCFCT.EnumExtensions.GetSchema(feature.Data.Item2);
                                        __builder3.AddContent$4(47, (schema?.Title ?? null) ?? $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(feature.Data.Item1));
                                        __builder3.CloseElement();
                                    }, $NcNDug ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                }), $PLjYVf ??= {"r":6881395,"p":[{"n":"feature","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.ValueTuple$$$($.$$.S.String, TServiceFeatureType))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                                __builder2.AddMarkupContent(48, "\r\n                ");
                                __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)), 49);
                                __builder2.AddComponentParameter(50, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), tier));
                                __builder2.AddComponentParameter(51, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder2.AddComponentParameter(52, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)), $.$mac.MAC.EventCallback.Factory.Create$6($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), this, this.OnSelected)));
                                __builder2.AddComponentParameter(53, "Class", "miwx-1 mgt corner-5");
                                $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 54, "onclick", true);
                                __builder2.AddAttribute$3(55, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddMarkupContent(56, "\r\n                    Subscribe\r\n                ");
                                }), $sgXbNh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                    }, $xIAzXa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $VXIEze ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17182375655)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887408359)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887408359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887408359)
            
            //--TRIMMABLE-BOUNDARY-START(12887408359)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12887408359)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90196819687)
                this.Tiers = null;
                //--TRIMMABLE-BOUNDARY-END(90196819687)
                
                //--TRIMMABLE-BOUNDARY-START(60132048615)
                this.OnSelected = $.$default($.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)));
                //--TRIMMABLE-BOUNDARY-END(60132048615)
                
            }
            static $H = 2506471;
            static $h = 2506471;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90196819687),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47247146727,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 85901852391,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 83886081
      },
      "n": "Tiers",
      "d": this.$h,
      "H": 90196819687,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90196819687),
//--TRIMMABLE-BOUNDARY-START(60132048615),
    {
      "p": $.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30067277543,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 77311917799,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 83886081
      },
      "n": "OnSelected",
      "d": this.$h,
      "H": 60132048615,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60132048615),
//--TRIMMABLE-BOUNDARY-START(64427015911),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38657212135,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 64427015911,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64427015911)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51542114023),
    {
      "r": 262145,
      "p": [
        {
          "n": "feature",
          "p": TServiceFeatureType?.$h??1638400
        }
      ],
      "n": "IsSingleBit",
      "d": this.$h,
      "H": 51542114023,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51542114023),
//--TRIMMABLE-BOUNDARY-START(21477342951),
    {
      "r": 655361,
      "p": [
        {
          "n": "feature",
          "p": TServiceFeatureType?.$h??1638400
        }
      ],
      "n": "CountTiersOf",
      "d": this.$h,
      "H": 21477342951,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21477342951),
//--TRIMMABLE-BOUNDARY-START(55837081319),
    {
      "r": 65537,
      "p": [
        {
          "n": "tier",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h
        }
      ],
      "n": "OnClick",
      "d": this.$h,
      "H": 55837081319,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55837081319),
//--TRIMMABLE-BOUNDARY-START(94491786983),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 94491786983,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491786983),
//--TRIMMABLE-BOUNDARY-START(17182375655),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 17182375655,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182375655)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68721983207),
    {
      "t": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h,
      "n": "selected",
      "d": this.$h,
      "H": 68721983207,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68721983207)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887408359),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 12887408359,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887408359)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1638400,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 2506471,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ServiceTiers<${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceTiers$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2506471)
        
        

        //--TRIMMABLE-BOUNDARY-START(1982183)
        $asm.$cls(`$dgLE.LCPCS$1.ManageServiceSubscribers<,>`, (TSubscriber, TSubscriptionDataModel) => $asm.$gt(`$dgLE.LCPCS$1.ManageServiceSubscribers<,>`, [TSubscriber, TSubscriptionDataModel], ($self) => class ManageServiceSubscribers$$$ extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(120261066471)
            /*string */ get OptimizedComponentName()
            {
                return "manageservicesubscribers";
            }
            //--TRIMMABLE-BOUNDARY-END(120261066471)
            
            //--TRIMMABLE-BOUNDARY-START(197570477799)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570477799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Service":
                    this.Service = $.$cast(parameter.Value, $.$vWqU.LCFCC.IServiceSubscriptionViewModel);
                    return true;
                    case "SubscriberLabel":
                    this.SubscriberLabel = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(197570477799)
            
            //--TRIMMABLE-BOUNDARY-START(137440935655)
            /*IServiceSubscriptionViewModel*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(137440935655)
            
            //--TRIMMABLE-BOUNDARY-START(184685575911)
            /*string?*/ SubscriberLabel = null;
            //--TRIMMABLE-BOUNDARY-END(184685575911)
            
            //--TRIMMABLE-BOUNDARY-START(42951655143)
            /*RemoteDataList<UserServiceSubscriptionModel<TSubscriber>>?*/ dataList = null;
            //--TRIMMABLE-BOUNDARY-END(42951655143)
            
            //--TRIMMABLE-BOUNDARY-START(141735902951)
            /*DataId */ get ServiceIdentifier()
            {
                return this.Service.LCFCC$IServiceSubscriptionViewModel$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service.LCFCD$IIded$Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(141735902951)
            
            //--TRIMMABLE-BOUNDARY-START(188980543207)
            /*string?*/ subsriptionKeyPrefix = null;
            //--TRIMMABLE-BOUNDARY-END(188980543207)
            
            //--TRIMMABLE-BOUNDARY-START(124556033767)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(124556033767)
            
            //--TRIMMABLE-BOUNDARY-START(124556033767)
            //--TRIMMABLE-BOUNDARY-START(30066753255)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066753255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066753255)
            
            //--TRIMMABLE-BOUNDARY-START(133145968359)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145968359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(133145968359)
            
            //--TRIMMABLE-BOUNDARY-END(124556033767)
            
            //--TRIMMABLE-BOUNDARY-START(193275510503)
            /*string */ get SubsriptionKeyPrefix()
            {
                return this.subsriptionKeyPrefix ??= `StockKeeperApp/${$.$strNN($.$dspc(this.ServiceIdentifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/`;
            }
            //--TRIMMABLE-BOUNDARY-END(193275510503)
            
            //--TRIMMABLE-BOUNDARY-START(115966099175)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(115966099175)
            
            //--TRIMMABLE-BOUNDARY-START(111671131879)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111671131879)
            
            //--TRIMMABLE-BOUNDARY-START(34361720551)
            /*Task *//*async*/  AddSubscriber()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361720551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let subscribers = ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select($.$hDPm.LCFCI.ViewConfiguration, TSubscriber, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Select Subscriber", false), null, 0, 2147483647, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Theme = $.$fPer.LCFC.Theme.Success;
                        $i3.ViewFeatures = 1/*ViewFeatures.OKToolBar*/;
                        return $i3;
                    })(), null, 35184381210624n | 8n | 4503599627370496n, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*var*/ let subscriptions = $.$sl.SL.Enumerable.ToList($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber), $.$sl.SL.Enumerable.Select$1(TSubscriber, $.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber), subscribers, new ($.$$.S.Func$$$(TSubscriber, $.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)))().$ctor(this,  (/*subscriber*/ subscriber) =>
                    {
                        return (() =>
                        {
                            //new $.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)()
                            const $t4 = $.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber);
                            const $i4 = new $t4();
                            $i4.$ctor$1();
                            $i4.ServiceId = $.$clone(this.ServiceIdentifier);
                            $i4.SubscriberId = subscriber.Identifier;
                            $i4.Service = subscriber;
                            return $i4;
                        })();
                    }, $AvHjvc ??= {"r":$.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber).$h,"p":[{"n":"subscriber","p":TSubscriber?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                    ($t5 = this.dataList.Append(subscriptions), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361720551)
            
            //--TRIMMABLE-BOUNDARY-START(201865445095)
            /*Task *//*async*/  UnSubscribe(/*UserServiceSubscriptionModel<TSubscriber>*/ subscriber)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201865445095);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t7, $r7;
                            let $t8, $r8;
                            ($t7 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)), [ subscriber ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            ($t8 = this.dataList.Remove$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)), [ subscriber ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        });
                    }, $UJPpbb ??= {"r":181338113,"n":"","d":this.$h,"H":0,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $wMACCk ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201865445095)
            
            //--TRIMMABLE-BOUNDARY-START(206160412391)
            /*Task *//*async*/  Update(/*UserServiceSubscriptionModel<TSubscriber>*/ subscriber)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206160412391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t9 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t10, $r10;
                            ($t10 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)), [ subscriber ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        });
                    }, $BXESOk ??= {"r":181338113,"n":"","d":this.$h,"H":0,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $FIrgGk ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206160412391)
            
            //--TRIMMABLE-BOUNDARY-START(107376164583)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376164583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(107376164583)
            
            //--TRIMMABLE-BOUNDARY-START(38656687847)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656687847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "fill flex bg-card pd");
                __builder.AddMarkupContent(2, "<div class=\"fill\"></div>\r\n    ");
                __builder.OpenElement(3, "button");
                __builder.AddAttribute$5(4, "class", "bg-primary mdi mdi-plus pd corner");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.AddSubscriber)));
                __builder.AddContent$4(6, "Add ");
                __builder.AddContent$4(7, this.SubscriberLabel);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(8, "\r\n\r\n");
                __builder.OpenElement(9, "div");
                __builder.AddAttribute$5(10, "class", "mgx-a mawx-6 bg-card pdx bdt");
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 11);
                __builder.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(13, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)), 15);
                    __builder2.AddComponentParameter(16, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12($.$clone(this.ServiceIdentifier))));
                    __builder2.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(18, "li-class", "pdy");
                    __builder2.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)))))().$ctor(this, ( (/*subscriber*/ subscriber) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(20, this.SubscriberCard($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber))).op_Implicit$1(subscriber)));
                        }, $KEnbBk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $XvWKYk ??= {"r":6881395,"p":[{"n":"subscriber","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(21, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 22);
                        __builder3.AddComponentParameter(23, "Class", "mg");
                        __builder3.AddComponentParameter(24, "Message", "Your staffs will appear here");
                        __builder3.AddComponentParameter(25, "ButtonClick", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.AddSubscriber))));
                        __builder3.AddComponentParameter(26, "ButtonText", "Add");
                        __builder3.CloseComponent();
                    }), $hRWfWb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.AddComponentReferenceCapture(27, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.dataList = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)));
                    }, $AknOXh ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $FqglAe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(38656687847)
            
            //--TRIMMABLE-BOUNDARY-START(180390608615)
            /*RenderFragment */ SubscriberCard(/*UserServiceSubscriptionModel<TSubscriber>*/ subscriber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390608615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 28);
                    __builder2.AddComponentParameter(29, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, (subscriber.Service?.Title ?? null)));
                    __builder2.AddComponentParameter(30, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, (subscriber.Service?.IconDescriptor.Icon ?? null) !== null ? subscriber.Service.IconDescriptor : $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account")));
                    __builder2.AddAttribute$3(31, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(TSubscriptionDataModel), 32);
                        __builder3.AddComponentParameter(33, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.FormBuilderFeatures, 0/*FormBuilderFeatures.Default*/ | 4/*FormBuilderFeatures.Horizontal*/ | 8/*FormBuilderFeatures.HorizontalFields*/ | 16/*FormBuilderFeatures.HorizontalFieldsResponsive*/), $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                        __builder3.AddComponentParameter(34, "FieldFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$2.InputFieldFeatures, 4/*InputFieldFeatures.Default*/ | 2/*InputFieldFeatures.Horizontal*/), $.$hDPm.LCFCCI$2.InputFieldFeatures));
                        __builder3.AddComponentParameter(35, "Class", "flex fill");
                        __builder3.AddComponentParameter(36, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$(TSubscriptionDataModel), $.$mac.MAC.EventCallback.Factory.Create$8(TSubscriptionDataModel, this, new ($.$$.S.Action$$(TSubscriptionDataModel))().$ctor(this,  (/*v*/ v) =>
                        {
                            return subscriber.SetDataAs(TSubscriptionDataModel, v, this.SubsriptionKeyPrefix);
                        }, $DYRLGe ??= {"r":65537,"p":[{"n":"v","p":TSubscriptionDataModel?.$h??1638400}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                        __builder3.AddComponentParameter(37, "Model", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(TSubscriptionDataModel, subscriber.GetDataAs(TSubscriptionDataModel, this.SubsriptionKeyPrefix)), TSubscriptionDataModel));
                        __builder3.AddComponentParameter(38, "ModelChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$(TSubscriptionDataModel), $.$mac.MAC.EventCallback.Factory.Create$6(TSubscriptionDataModel, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1(TSubscriptionDataModel, this, new ($.$$.S.Action$$(TSubscriptionDataModel))().$ctor(this,  (/*v*/ v) =>
                        {
                            return subscriber.SetDataAs(TSubscriptionDataModel, v, this.SubsriptionKeyPrefix);
                        }, $fkHBYi ??= {"r":65537,"p":[{"n":"v","p":TSubscriptionDataModel?.$h??1638400}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), subscriber.GetDataAs(TSubscriptionDataModel, this.SubsriptionKeyPrefix)))));
                        __builder3.AddComponentParameter(39, "ModelExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$(TSubscriptionDataModel)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Call$15($.$sle.SLE.Expression.Constant$1(subscriber), "GetDataAs", $.$$.S.Type.EmptyTypes, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [$.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "SubsriptionKeyPrefix")], [-1], null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $NzHfUf ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke())));
                        /*var*/ let  [ _11, _12 ] = $.$destructure(new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3("Model", 0), 2);
                        __builder3.AddAttribute$3(40, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            __builder4.OpenElement(41, "div");
                            __builder4.AddAttribute$5(42, "class", "flex mgl-a");
                            __builder4.OpenElement(43, "button");
                            __builder4.AddAttribute$5(44, "type", "button");
                            __builder4.AddAttribute$5(45, "class", "bg-primary pd corner miwx-1 mgl-a");
                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 46, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                            {
                                return this.Update(subscriber);
                            }, $ScMFvh ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                            __builder4.AddContent$4(47, "Save");
                            __builder4.CloseElement();
                            __builder4.AddMarkupContent(48, "\r\n                ");
                            __builder4.OpenElement(49, "button");
                            __builder4.AddAttribute$5(50, "type", "button");
                            __builder4.AddAttribute$5(51, "class", "bg-error pd corner miwx-1 mgl");
                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 52, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                            {
                                return this.UnSubscribe(subscriber);
                            }, $UlGCMi ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                            __builder4.AddContent$4(53, "Remove");
                            __builder4.CloseElement();
                            __builder4.CloseElement();
                        }), $BQYxBd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $yPHbYk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $ehUsXc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(180390608615)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(21476818663)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476818663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476818663)
            
            //--TRIMMABLE-BOUNDARY-START(21476818663)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476818663)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(115966099175)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(115966099175)
                
            }
            static $H = 1982183;
            static $h = 1982183;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120261066471),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721458919,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 120261066471,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120261066471),
//--TRIMMABLE-BOUNDARY-START(137440935655),
    {
      "p": 4480424,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311393511,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 167505706727,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 137440935655,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137440935655),
//--TRIMMABLE-BOUNDARY-START(184685575911),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94491262695,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 176095641319,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 83886081
      },
      "n": "SubscriberLabel",
      "d": this.$h,
      "H": 184685575911,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685575911),
//--TRIMMABLE-BOUNDARY-START(141735902951),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85901328103,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331650
      },
      "n": "ServiceIdentifier",
      "d": this.$h,
      "H": 141735902951,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(141735902951),
//--TRIMMABLE-BOUNDARY-START(193275510503),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103081197287,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331650
      },
      "n": "SubsriptionKeyPrefix",
      "d": this.$h,
      "H": 193275510503,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(193275510503),
//--TRIMMABLE-BOUNDARY-START(115966099175),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131524327,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 158915772135,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 83886081
      },
      "n": "Loading",
      "d": this.$h,
      "H": 115966099175,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966099175),
//--TRIMMABLE-BOUNDARY-START(111671131879),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541589735,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 150325837543,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": this.$h,
      "H": 111671131879,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671131879)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(197570477799),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 197570477799,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197570477799),
//--TRIMMABLE-BOUNDARY-START(34361720551),
    {
      "r": 178454529,
      "n": "AddSubscriber",
      "d": this.$h,
      "H": 34361720551,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34361720551),
//--TRIMMABLE-BOUNDARY-START(201865445095),
    {
      "r": 178454529,
      "p": [
        {
          "n": "subscriber",
          "p": $.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber).$h
        }
      ],
      "n": "UnSubscribe",
      "d": this.$h,
      "H": 201865445095,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(201865445095),
//--TRIMMABLE-BOUNDARY-START(206160412391),
    {
      "r": 178454529,
      "p": [
        {
          "n": "subscriber",
          "p": $.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber).$h
        }
      ],
      "n": "Update",
      "d": this.$h,
      "H": 206160412391,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(206160412391),
//--TRIMMABLE-BOUNDARY-START(107376164583),
    {
      "r": 181338113,
      "n": "Load",
      "d": this.$h,
      "H": 107376164583,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376164583),
//--TRIMMABLE-BOUNDARY-START(38656687847),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 38656687847,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38656687847),
//--TRIMMABLE-BOUNDARY-START(180390608615),
    {
      "r": 6881395,
      "p": [
        {
          "n": "subscriber",
          "p": $.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber).$h
        }
      ],
      "n": "SubscriberCard",
      "d": this.$h,
      "H": 180390608615,
      "h": Number(BigInt(this.$h)|0x2A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180390608615)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951655143),
    {
      "t": $.$hDPm.LCFCCD$1.RemoteDataList$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TSubscriber)).$h,
      "n": "dataList",
      "d": this.$h,
      "H": 42951655143,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951655143),
//--TRIMMABLE-BOUNDARY-START(188980543207),
    {
      "t": 1310721,
      "n": "subsriptionKeyPrefix",
      "d": this.$h,
      "H": 188980543207,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(188980543207)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476818663),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 21476818663,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476818663)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(124556033767),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 30066753255,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 133145968359,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": this.$h,
      "H": 124556033767,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(124556033767)
  ],
  "s": [
    {
      "h": TSubscriber?.$h??1572864,
      "n": "TSubscriber",
      "c": [8267094
      ]
    },
    {
      "h": TSubscriptionDataModel?.$h??1638400,
      "n": "TSubscriptionDataModel",
      "f": 1
    }
  ],
  "r": 2,
  "H": 1982183,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ManageServiceSubscribers<${TSubscriber?.$fullName},${TSubscriptionDataModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ManageServiceSubscribers$${TSubscriber?.$getFullName(separator)}$${TSubscriptionDataModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1982183)
        
        

        //--TRIMMABLE-BOUNDARY-START(868071)
        $asm.$cls(`$dgLE.LCPCS$1.CatalogueOrder`, ($self) => class CatalogueOrder extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(201864330983)
            /*string */ get OptimizedComponentName()
            {
                return "catalogueorder";
            }
            //--TRIMMABLE-BOUNDARY-END(201864330983)
            
            //--TRIMMABLE-BOUNDARY-START(343598251751)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598251751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Title":
                    this.Title = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Provider":
                    this.Provider = $.$cast(parameter.Value, $.$dgLE.LCPCS$1.ICatalogueOrderProvider);
                    return true;
                    case "Order":
                    this.Order = $.$cast(parameter.Value, $.$AvdQ.LCFCP.ICatalogueOrderModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(343598251751)
            
            //--TRIMMABLE-BOUNDARY-START(167504592615)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504592615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.JavaScript = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(167504592615)
            
            //--TRIMMABLE-BOUNDARY-START(335008317159)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(335008317159)
            
            //--TRIMMABLE-BOUNDARY-START(253403938535)
            /*ICatalogueOrderProvider*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(253403938535)
            
            //--TRIMMABLE-BOUNDARY-START(210454265575)
            /*ICatalogueOrderModel*/ Order = null;
            //--TRIMMABLE-BOUNDARY-END(210454265575)
            
            //--TRIMMABLE-BOUNDARY-START(171799559911)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(171799559911)
            
            //--TRIMMABLE-BOUNDARY-START(270583807719)
            /*string?*/ searchKey = null;
            //--TRIMMABLE-BOUNDARY-END(270583807719)
            
            //--TRIMMABLE-BOUNDARY-START(64425377511)
            /*ICatalogueCategoryModel?*/ currentCategory = null;
            //--TRIMMABLE-BOUNDARY-END(64425377511)
            
            //--TRIMMABLE-BOUNDARY-START(214749232871)
            /*List<ICatalogueOrderItemModel>*/ orderItems = null;
            //--TRIMMABLE-BOUNDARY-END(214749232871)
            
            //--TRIMMABLE-BOUNDARY-START(227634134759)
            /*PaymentMethod*/ payment = 0;
            //--TRIMMABLE-BOUNDARY-END(227634134759)
            
            //--TRIMMABLE-BOUNDARY-START(68720344807)
            /*IContact?*/ customer = null;
            //--TRIMMABLE-BOUNDARY-END(68720344807)
            
            //--TRIMMABLE-BOUNDARY-START(206159298279)
            /*ICatalogueOrderModel?*/ order = null;
            //--TRIMMABLE-BOUNDARY-END(206159298279)
            
            //--TRIMMABLE-BOUNDARY-START(73015312103)
            /*string?*/ customerName = null;
            //--TRIMMABLE-BOUNDARY-END(73015312103)
            
            //--TRIMMABLE-BOUNDARY-START(77310279399)
            /*string?*/ customerPhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(77310279399)
            
            //--TRIMMABLE-BOUNDARY-START(42950541031)
            /*Money */ get Amount()
            {
                return this.orderItems.Count > 0 ? $.$sl.SL.Enumerable.Aggregate$2($.$fPer.LCFCDM.Money, $.$sl.SL.Enumerable.Select$1($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$fPer.LCFCDM.Money, this.orderItems, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.LCFCP$ICatalogueOrderItemModel$TotalAmount;
                }, $TKOoUd ??= {"r":27822422,"p":[{"n":"i","p":2077632}],"n":"","d":868071,"h":0,"f":17825794})), new ($.$$.S.Func$$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Addition(a, b);
                }, $zctDOi ??= {"r":27822422,"p":[{"n":"a","p":27822422},{"n":"b","p":27822422}],"n":"","d":868071,"h":0,"f":17825794})) : new $.$fPer.LCFCDM.Money().$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(42950541031)
            
            //--TRIMMABLE-BOUNDARY-START(347893219047)
            /*Money */ get VAT()
            {
                return $.$fPer.LCFCDM.Money.op_Division($.$fPer.LCFCDM.Money.op_Implicit$1((this.Provider.LCFCP$ICatalogueProvider$Settings?.LCFCP$ICatalogueSettings$VATRate ?? null) ?? 0) * $.$fPer.LCFCDM.Money.op_Implicit(this.Amount), 100);
            }
            //--TRIMMABLE-BOUNDARY-END(347893219047)
            
            //--TRIMMABLE-BOUNDARY-START(339303284455)
            /*Money */ get Total()
            {
                return $.$fPer.LCFCDM.Money.op_Addition(this.Amount, this.VAT);
            }
            //--TRIMMABLE-BOUNDARY-END(339303284455)
            
            //--TRIMMABLE-BOUNDARY-START(184684461799)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(184684461799)
            
            //--TRIMMABLE-BOUNDARY-START(180389494503)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180389494503)
            
            //--TRIMMABLE-BOUNDARY-START(274878775015)
            /*int*/ searchSequence = 0;
            //--TRIMMABLE-BOUNDARY-END(274878775015)
            
            //--TRIMMABLE-BOUNDARY-START(219044200167)
            /*WizardSteps?*/ orderWizard = null;
            //--TRIMMABLE-BOUNDARY-END(219044200167)
            
            //--TRIMMABLE-BOUNDARY-START(249108971239)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(249108971239)
            
            //--TRIMMABLE-BOUNDARY-START(249108971239)
            //--TRIMMABLE-BOUNDARY-START(38655573735)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655573735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38655573735)
            
            //--TRIMMABLE-BOUNDARY-START(261993873127)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993873127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(261993873127)
            
            //--TRIMMABLE-BOUNDARY-END(249108971239)
            
            //--TRIMMABLE-BOUNDARY-START(188979429095)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979429095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Order !== null)
                {
                    this.order = this.Order;
                    if (this.Order.LCFCP$ICatalogueOrderModel$Items !== null)
                    {
                        this.orderItems.AddRange(this.Order.LCFCP$ICatalogueOrderModel$Items);
                    }
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(188979429095)
            
            //--TRIMMABLE-BOUNDARY-START(266288840423)
            /*void */ Search()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288840423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.searchSequence++;
            }
            //--TRIMMABLE-BOUNDARY-END(266288840423)
            
            //--TRIMMABLE-BOUNDARY-START(55835442919)
            /*ValueTask *//*async*/  ContinueOrder()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835442919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Provider.LCPCS$1$ICatalogueOrderProvider$Customers !== null || ((this.Provider.LCPCS$1$ICatalogueOrderProvider$Features & (1/*CatalogueOrderProviderFeatures.Payment*/)) == (1/*CatalogueOrderProviderFeatures.Payment*/)))
                    {
                        let $t2, $r2;
                        ($t2 = this.orderWizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    else 
                    {
                        let $t3, $r3;
                        ($t3 = this.CreateOrder(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835442919)
            
            //--TRIMMABLE-BOUNDARY-START(51540475623)
            /*void */ CancelOrder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540475623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.orderItems.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(51540475623)
            
            //--TRIMMABLE-BOUNDARY-START(231929102055)
            /*ElementReference*/ printElement;
            //--TRIMMABLE-BOUNDARY-END(231929102055)
            
            //--TRIMMABLE-BOUNDARY-START(236224069351)
            /*Task *//*async*/  PrintReceipt()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236224069351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                    {
                        return this.PrintView();
                    }, $lOgiof ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":868071,"h":0,"f":17825794}), null, null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t4 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.ViewFeatures = (5731/*ViewFeatures.ViewDefault*/ & ~1/*ViewFeatures.OKToolBar*/ & ~2/*ViewFeatures.CancelToolBar*/) | 256/*ViewFeatures.CloseOnClickOut*/;
                        $i4.PageBackgroundTheme = $.$fPer.LCFC.Theme.Transparent;
                        return $i4;
                    })());
                    ($t5 = $.$$.STT.Task.Delay$1(1000), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    ($t6 = this.JavaScript.LCFCI$IJavaScriptRunner$Queue$1("printElement", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ this.printElement ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(236224069351)
            
            //--TRIMMABLE-BOUNDARY-START(330713349863)
            /*Task *//*async*/  StartNewOrder()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(330713349863);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.orderItems.Clear();
                    ($t7 = this.orderWizard.SetCurrentView$1(0), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(330713349863)
            
            //--TRIMMABLE-BOUNDARY-START(60130410215)
            /*Task *//*async*/  CreateOrder()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130410215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!((this.Provider.LCPCS$1$ICatalogueOrderProvider$Features & (1/*CatalogueOrderProviderFeatures.Payment*/)) == (1/*CatalogueOrderProviderFeatures.Payment*/)) || ($t8 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Confirm("Payment Received?", `You confirmed you have received payment of ${$.$strNN(this.Total.ToString())} on this order?`, "Yes", "No"), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8))))
                    {
                        let $t9, $r9;
                        ($t9 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t11, $r11;
                                let $t13, $r13;
                                let $en10 = this.orderItems.GetEnumerator();
                                while ($en10.MoveNext())
                                {
                                    let item = $en10.Current;
                                    {
                                        let eitem;
                                        if ($.$is(item, $.$AvdQ.LCFCP.IEditableCatalogueOrderItemModel, { set $v($v){ eitem = $v; } }))
                                        {
                                            eitem.LCFCP$IEditableCatalogueOrderItemModel$Catalogue.LCFCP$IEditableCatalogueModel$UnitQuantity += item.LCFCP$ICatalogueOrderItemModel$UnitQuantity;
                                            eitem.LCFCP$IEditableCatalogueOrderItemModel$Catalogue.LCFCP$IEditableCatalogueModel$PackQuantity += item.LCFCP$ICatalogueOrderItemModel$PackQuantity;
                                        }
                                    }
                                }
                                /*var*/ let order = ($t11 = this.Provider.LCPCS$1$ICatalogueOrderProvider$CreateOrder(this.payment, this.customer ?? (this.customerName !== null || this.customerPhoneNumber !== null ? (() =>
                                {
                                    //new $.$fPer.LCFCC$2.Contact()
                                    const $t12 = $.$fPer.LCFCC$2.Contact;
                                    const $i12 = new $t12();
                                    $i12.$ctor$2();
                                    return $i12;
                                })() : null), this.orderItems), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                this.order = order;
                                this.customer = null;
                                ($t13 = this.orderWizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                            });
                        }, $xrkVgh ??= {"r":181338113,"n":"","d":868071,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                        }, $VVCzOf ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":868071,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60130410215)
            
            //--TRIMMABLE-BOUNDARY-START(193274396391)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<ICatalogueCategoryModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t14, $r14;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274396391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.currentCategory === selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data)
                    {
                        this.currentCategory = null;
                    }
                    else 
                    {
                        this.currentCategory = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data;
                    }
                    ($t14 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.ProductsServices.Client.Blazor\\CatalogueOrder.razor.cs", "OnSelected", 144), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(193274396391)
            
            //--TRIMMABLE-BOUNDARY-START(197569363687)
            /*ValueTask<bool> *//*async*/  OnSelected$1(/*DataListSelection<IProductCatalogueModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t15, $r15;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569363687);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let existing = $.$sl.SL.Enumerable.SingleOrDefault$1($.$AvdQ.LCFCP.ICatalogueOrderItemModel, this.orderItems, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$$.S.Boolean))().$ctor(this,  (/**/ o) =>
                    {
                        /*LivingThing.Core.Frameworks.Common.Product.ICatalogueModel*/ let __ca1__;
                        return ((__ca1__ = o.LCFCP$ICatalogueOrderItemModel$Catalogue) !== null ? $.$dsp(__ca1__, $.$$.S.Object, ($t) => $t.Equals$1, selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data) : false);
                    }, $tyekFa ??= {"r":262145,"p":[{"n":"o","p":2077632}],"n":"","d":868071,"h":0,"f":17825794}));
                    if (existing === null)
                    {
                        existing = this.Provider.LCPCS$1$ICatalogueOrderProvider$CreateOrderItem(selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data);
                        this.orderItems.Add(existing);
                    }
                    else 
                    {
                        let eitem;
                        if ($.$is(existing, $.$AvdQ.LCFCP.IEditableCatalogueOrderItemModel, { set $v($v){ eitem = $v; } }))
                        {
                            eitem.LCFCP$IEditableCatalogueOrderItemModel$UnitQuantity--;
                        }
                    }
                    ($t15 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.ProductsServices.Client.Blazor\\CatalogueOrder.razor.cs", "OnSelected", 166), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197569363687)
            
            //--TRIMMABLE-BOUNDARY-START(176094527207)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094527207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(176094527207)
            
            //--TRIMMABLE-BOUNDARY-START(47245508327)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245508327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "hf stack");
                    if (this.Title !== null)
                    {
                        __builder.OpenElement(2, "div");
                        __builder.AddAttribute$5(3, "class", "pd bg-card");
                        __builder.OpenElement(4, "h3");
                        __builder.AddAttribute$5(5, "class", "mg-0");
                        __builder.AddContent$4(6, this.Title);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    if (this.orderItems.Count > 0)
                    {
                        __builder.OpenElement(7, "div");
                        __builder.AddAttribute$5(8, "class", "mahv-45");
                        __builder.AddContent$1(9, this.OrderWizard(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box, null));
                        __builder.CloseElement();
                    }
                    __builder.OpenElement(10, "div");
                    __builder.AddAttribute$5(11, "class", "fill pd scroll");
                    __builder.AddContent$1(12, this.ProductListing());
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(13, "div");
                    __builder.AddAttribute$5(14, "class", "hf fill flex bdt clip");
                    __builder.AddContent$1(15, this.OrderWizard(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box, "mawx-5 miwx-5"));
                    __builder.AddMarkupContent(16, "\r\n        ");
                    __builder.OpenElement(17, "div");
                    __builder.AddAttribute$5(18, "class", "fill pd-10 clip hf scroll");
                    __builder.AddContent$1(19, this.ProductListing());
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245508327)
            
            //--TRIMMABLE-BOUNDARY-START(223339167463)
            /*RenderFragment */ OrderWizard(/*BoxSize?*/ box, /*string?*/ _class)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339167463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 20);
                    __builder2.AddComponentParameter(21, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `bg-card ${$.$strNN(_class)}`));
                    __builder2.AddComponentParameter(22, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                    __builder2.AddAttribute$3(23, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 24);
                        __builder3.AddComponentParameter(25, "Class", "stack");
                        __builder3.AddComponentParameter(26, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ViewFeatures, 5632/*ViewFeatures.Default*/ & ~512/*ViewFeatures.DeferRendering*/), $.$vWqU.LCFCC.ViewFeatures));
                        __builder3.AddAttribute$3(27, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*___*/ ___) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                if (this.orderItems.Count === 0)
                                {
                                    __builder4.OpenElement(28, "div");
                                    __builder4.AddAttribute$5(29, "class", "pd" + $.$strNN((((box?.IsMobile ?? null) ?? false) ? "" : "-10")));
                                    __builder4.OpenElement(30, "img");
                                    __builder4.AddAttribute$5(31, "src", this.ResolvePath("img/POS/prods.png", true, false, false));
                                    __builder4.AddAttribute$5(32, "class", "mawx-2 mgy-20 mgx-a d-block");
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(33, "\r\n                ");
                                    __builder4.AddMarkupContent(34, "<h1>No order in process</h1>\r\n                ");
                                    __builder4.AddMarkupContent(35, "<p class=\"op-7\">Click an Item to start an order</p>");
                                    __builder4.CloseElement();
                                }
                                else 
                                {
                                    __builder4.AddContent$1(36, $.$dgLE.LCPCS$1.CatalogueOrderViews.OrderItems(this, this.Provider, this.orderItems, true, true));
                                    __builder4.OpenElement(37, "div");
                                    __builder4.AddAttribute$5(38, "class", "row");
                                    __builder4.OpenElement(39, "button");
                                    __builder4.AddAttribute$5(40, "class", $.$strNN($.$strNN($.$strNN("pdy" + $.$strNN((((box?.IsMobile ?? null) ?? false) ? "" : "-7"))) + " col-5") + " bg-fatal") + " fsz-25");
                                    __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 41, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.CancelOrder)));
                                    __builder4.AddContent$4(42, "CANCEL");
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(43, "\r\n                ");
                                    __builder4.OpenElement(44, "button");
                                    __builder4.AddAttribute$5(45, "class", $.$strNN($.$strNN($.$strNN("pdy" + $.$strNN((((box?.IsMobile ?? null) ?? false) ? "" : "-7"))) + " col-5") + " bg-primary") + " fsz-25");
                                    __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 46, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.ContinueOrder)));
                                    __builder4.AddAttribute$5(47, "disable", "orderItems.Count==0");
                                    __builder4.AddContent$4(48, "ORDER");
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                }
                            }, $WwsTJa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
                        }), $tZtEFe ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":868071,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        if (this.Provider.LCPCS$1$ICatalogueOrderProvider$Customers !== null || ((this.Provider.LCPCS$1$ICatalogueOrderProvider$Features & (1/*CatalogueOrderProviderFeatures.Payment*/)) == (1/*CatalogueOrderProviderFeatures.Payment*/)))
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 49);
                            __builder3.AddComponentParameter(50, "Class", "stack pos-rel");
                            __builder3.AddComponentParameter(51, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ViewFeatures, 5632/*ViewFeatures.Default*/ & ~512/*ViewFeatures.DeferRendering*/), $.$vWqU.LCFCC.ViewFeatures));
                            __builder3.AddAttribute$3(52, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*___*/ ___) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 53);
                                    __builder4.AddComponentParameter(54, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                                    __builder4.AddComponentParameter(55, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                                    __builder4.AddAttribute$3(56, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder5) =>
                                    {
                                        let $t16 = this.orderWizard;
                                        __builder5.OpenComponent$1($.$macw.MACF.EditForm, 57);
                                        __builder5.AddComponentParameter(58, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                        __builder5.AddComponentParameter(59, "class", "fill scroll pd");
                                        __builder5.AddAttribute$3(60, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/**/ context) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.OpenElement(61, "h2");
                                                __builder6.AddMarkupContent(62, "\r\n                        Order Amount ");
                                                __builder6.AddContent$3(63, $.$clone(this.Total));
                                                __builder6.CloseElement();
                                                if (((this.Provider.LCPCS$1$ICatalogueOrderProvider$Features & (1/*CatalogueOrderProviderFeatures.Payment*/)) == (1/*CatalogueOrderProviderFeatures.Payment*/)))
                                                {
                                                    __builder6.AddMarkupContent(64, "<h3 class=\"op-9 mgt-10 mgb-2\">Payment mode</h3>\r\n                    ");
                                                    __builder6.OpenElement(65, "div");
                                                    __builder6.AddAttribute$5(66, "class", "flex");
                                                    $.$dgLE._LCPCSC.TypeInference.CreateInputEditor_0($.$nYKj.LCFCP.PaymentMethod, __builder6, 67, 68, 40n, 69, $.$fPer.LCFC.Theme.Primary, 70, this.payment, 71, $.$mac.MAC.EventCallback.Factory.Create$6($.$nYKj.LCFCP.PaymentMethod, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$nYKj.LCFCP.PaymentMethod, this, new ($.$$.S.Action$$($.$nYKj.LCFCP.PaymentMethod))().$ctor(this,  (/**/ __value) =>
                                                    {
                                                        return this.payment = __value;
                                                    }, $bkukLa ??= {"r":65537,"p":[{"n":"__value","p":1459992}],"n":"","d":868071,"h":0,"f":17825794}), this.payment)), 72, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "payment"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $aOZsZd ??= {"r":38797349,"n":"","d":868071,"h":0,"f":17825794})).Invoke()));
                                                    __builder6.CloseElement();
                                                }
                                                /*var*/ let customers = this.Provider.LCPCS$1$ICatalogueOrderProvider$Customers;
                                                if (customers !== null)
                                                {
                                                    __builder6.OpenElement(73, "div");
                                                    __builder6.AddAttribute$5(74, "class", "flex mgt-10");
                                                    __builder6.AddMarkupContent(75, "<h3 class=\"op-9 mgy-a fill\">Customer</h3>\r\n                        <div class=\"fill\"></div>\r\n                        ");
                                                    $.$dgLE._LCPCSC.TypeInference.CreateInputEditor_1($.$fPer.LCFCC$2.IContact, __builder6, 76, 77, "mgy-a mgl bg-dark-01", 78, $.$fPer.LCFC.Theme.Primary, 79, "Select Customer", 80, $.$fPer.LCFCD.Paging.Select($.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCC$2.IContact), customers, new ($.$$.S.Func$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCC$2.IContact)))().$ctor(this,  (/**/ c) =>
                                                    {
                                                        return new ($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCC$2.IContact))().$ctor$3(c);
                                                    }, $zyCdZd ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCC$2.IContact).$h,"p":[{"n":"c","p":5081430}],"n":"","d":868071,"h":0,"f":17825794})), 81, 21n, 82, this.customer, 83, $.$mac.MAC.EventCallback.Factory.Create$6($.$fPer.LCFCC$2.IContact, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fPer.LCFCC$2.IContact, this, new ($.$$.S.Action$$($.$fPer.LCFCC$2.IContact))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return this.customer = __value;
                                                    }, $TLwUGk ??= {"r":65537,"p":[{"n":"__value","p":5081430}],"n":"","d":868071,"h":0,"f":17825794}), this.customer)), 84, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "customer"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $NaklWi ??= {"r":38797349,"n":"","d":868071,"h":0,"f":17825794})).Invoke()));
                                                    __builder6.CloseElement();
                                                    __builder6.AddMarkupContent(85, "\r\n                    ");
                                                    __builder6.AddMarkupContent(86, "<p>Or enter new Customer details</p>\r\n                    ");
                                                    $.$dgLE._LCPCSC.TypeInference.CreateInputEditor_2($.$$.S.String, __builder6, 87, 88, "mgt bg-dark-01", 89, $.$fPer.LCFC.Theme.Primary, 90, "Customer Name", 91, this.customerName, 92, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return this.customerName = __value;
                                                    }, $wQvdha ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":868071,"h":0,"f":17825794}), this.customerName)), 93, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "customerName"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $cwTJyh ??= {"r":38797349,"n":"","d":868071,"h":0,"f":17825794})).Invoke()));
                                                    __builder6.AddMarkupContent(94, "\r\n                    ");
                                                    $.$dgLE._LCPCSC.TypeInference.CreateInputEditor_3($.$$.S.String, __builder6, 95, 96, "mgt bg-dark-01", 97, $.$fPer.LCFC.Theme.Primary, 98, "Customer Phone", 99, this.customerPhoneNumber, 100, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return this.customerPhoneNumber = __value;
                                                    }, $Mjrxrc ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":868071,"h":0,"f":17825794}), this.customerPhoneNumber)), 101, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "customerPhoneNumber"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $xWRCFd ??= {"r":38797349,"n":"","d":868071,"h":0,"f":17825794})).Invoke()));
                                                }
                                            }, $IsijWa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
                                        }), $GGiboj ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":868071,"h":0,"f":17825794}));
                                        __builder5.CloseComponent();
                                        __builder5.AddMarkupContent(102, "\r\n                ");
                                        __builder5.OpenElement(103, "div");
                                        __builder5.AddAttribute$5(104, "class", "row");
                                        __builder5.OpenElement(105, "button");
                                        __builder5.AddAttribute$5(106, "class", $.$strNN($.$strNN($.$strNN("pdy" + $.$strNN((((box?.IsMobile ?? null) ?? false) ? "" : "-7"))) + " col-5") + " bg-fatal") + " fsz-25");
                                        __builder5.AddAttribute$7($.$macw.MACW.MouseEventArgs, 107, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor($t16, $t16.PreviousView)));
                                        __builder5.AddContent$4(108, "BACK");
                                        __builder5.CloseElement();
                                        __builder5.AddMarkupContent(109, "\r\n                    ");
                                        __builder5.OpenElement(110, "button");
                                        __builder5.AddAttribute$5(111, "class", $.$strNN($.$strNN($.$strNN("pdy" + $.$strNN((((box?.IsMobile ?? null) ?? false) ? "" : "-7"))) + " col-5") + " bg-primary") + " fsz-25");
                                        __builder5.AddAttribute$7($.$macw.MACW.MouseEventArgs, 112, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.CreateOrder)));
                                        __builder5.AddContent$4(113, "SUBMIT");
                                        __builder5.CloseElement();
                                        __builder5.CloseElement();
                                    }), $Jauahe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":868071,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $JeMFjh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
                            }), $IlkYrh ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":868071,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 114);
                        __builder3.AddComponentParameter(115, "Class", "stack");
                        __builder3.AddComponentParameter(116, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ViewFeatures, 5632/*ViewFeatures.Default*/ & ~512/*ViewFeatures.DeferRendering*/), $.$vWqU.LCFCC.ViewFeatures));
                        __builder3.AddAttribute$3(117, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*___*/ ___) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(118, "div");
                                __builder4.AddAttribute$5(119, "class", "fill stack");
                                __builder4.AddMarkupContent(120, "<h1 class=\"mg cl-primary flex\"><i class=\"mdi mdi-check fsz-50 bd bg-primary wx-07 hx-07 d-i-block mgc-a round flex\"></i>\r\n                    <span class=\"mgl mgy-a\">\r\n                        Order Created Successfully\r\n                    </span></h1>\r\n                ");
                                __builder4.AddContent$1(121, $.$dgLE.LCPCS$1.CatalogueOrderViews.OrderItems(this, this.Provider, this.orderItems, false, true));
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(122, "\r\n            ");
                                __builder4.OpenElement(123, "div");
                                __builder4.AddAttribute$5(124, "class", "row");
                                __builder4.OpenElement(125, "button");
                                __builder4.AddAttribute$5(126, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("pdy" + $.$strNN((((box?.IsMobile ?? null) ?? false) ? "" : "-7"))) + " col-5") + " bg-secondary") + " fsz-25") + " mdi") + " mdi-printer");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 127, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.PrintReceipt)));
                                __builder4.AddContent$4(128, "RECEIPT");
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(129, "\r\n                ");
                                __builder4.OpenElement(130, "button");
                                __builder4.AddAttribute$5(131, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("pdy" + $.$strNN((((box?.IsMobile ?? null) ?? false) ? "" : "-7"))) + " col-5") + " bg-primary") + " fsz-25") + " mdi") + " mdi-check");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 132, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.StartNewOrder)));
                                __builder4.AddContent$4(133, "OK");
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }, $VUObxa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
                        }), $FecZLe ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":868071,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $rGVqSa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":868071,"h":0,"f":17825794}));
                    __builder2.AddComponentReferenceCapture(134, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.orderWizard = $.$cast(__value, $.$hDPm.LCFCCW$1.WizardSteps);
                    }, $bNKMkj ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":868071,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(135, "\r\n");
                }, $NIstfb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(223339167463)
            
            //--TRIMMABLE-BOUNDARY-START(244814003943)
            /*RenderFragment */ ProductListing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814003943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let categories = this.Provider.LCFCP$ICatalogueProvider$Categories;
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    if (categories !== null)
                    {
                        __builder2.OpenElement(136, "div");
                        __builder2.AddAttribute$5(137, "class", "flex scroll-x pd-1");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$AvdQ.LCFCP.ICatalogueCategoryModel), 138);
                        __builder2.AddComponentParameter(139, "Pager", (categories));
                        __builder2.AddComponentParameter(140, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 33554432n | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                        __builder2.AddComponentParameter(141, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                        __builder2.AddAttribute$3(142, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueCategoryModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$AvdQ.LCFCP.ICatalogueCategoryModel))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(143, "div");
                                __builder3.AddAttribute$5(144, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mgr" + " mgl-1") + " mgy-1") + " bg-") + $.$strNN((this.currentCategory === context.Data ? "primary" : "card"))) + " shadow") + " corner-5") + " clip") + " mawx-15") + " miwx-15");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 145);
                                __builder3.AddComponentParameter(146, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 150), $.$$.S.Int32));
                                __builder3.AddComponentParameter(147, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, $.$Iaui.LCFCM.ResourceModel.op_Implicit$1(context.Data.LCFC$IDisplayable$Icon)));
                                __builder3.AddComponentParameter(148, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/POS/cat1.png", true, false, false)));
                                __builder3.AddComponentParameter(149, "Class", "hx-1 mawf d-block mgx-a");
                                __builder3.AddComponentParameter(150, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(151, "\r\n                    ");
                                __builder3.OpenElement(152, "div");
                                __builder3.AddAttribute$5(153, "class", "pd");
                                __builder3.OpenElement(154, "h3");
                                __builder3.AddAttribute$5(155, "class", "mg-0 text-center nowrap");
                                __builder3.AddContent$4(156, context.Data.LCFC$IDisplayable$Title);
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }, $ArCpla ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
                        }), $igzwxa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.ICatalogueCategoryModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$AvdQ.LCFCP.ICatalogueCategoryModel)).$h}],"n":"","d":868071,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(157, "div");
                    __builder2.AddAttribute$5(158, "class", "flex mgy-10 corner clip");
                    __builder2.OpenElement(159, "input");
                    __builder2.AddAttribute$5(160, "placeholder", "Search Item");
                    __builder2.AddAttribute$5(161, "class", "cl-text fill bg-card-05 bd-0 pd-5 fsz-20 miwx-15");
                    __builder2.AddAttribute$5(162, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.searchKey, null));
                    __builder2.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 163, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.searchKey = __value;
                    }, $rpxZdb ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":868071,"h":0,"f":17825794}), this.searchKey, null));
                    __builder2.SetUpdatesAttributeName("value");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(164, "\r\n            ");
                    __builder2.OpenElement(165, "button");
                    __builder2.AddAttribute$5(166, "class", "bg-primary fw-bold fsz-20 pd-5");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 167, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Search)));
                    __builder2.AddContent$4(168, "Search");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(169, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$AvdQ.LCFCP.IProductCatalogueModel), 170);
                    __builder2.AddComponentParameter(171, "Pager", (this.Provider.LCFCP$ICatalogueProvider$Products));
                    __builder2.AddComponentParameter(172, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$22((this.currentCategory?.LCFCP$ICatalogueCategoryModel$SKU ?? null), null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null)));
                    __builder2.AddComponentParameter(173, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 150), $.$$.S.Int32));
                    __builder2.AddComponentParameter(174, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                    __builder2.AddComponentParameter(175, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(176, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                    __builder2.AddAttribute$3(177, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.IProductCatalogueModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$AvdQ.LCFCP.IProductCatalogueModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(178, "div");
                            __builder3.AddAttribute$5(179, "class", "bg-card corner clip");
                            __builder3.OpenElement(180, "div");
                            __builder3.AddAttribute$5(181, "class", "hx-1 flex");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 182);
                            __builder3.AddComponentParameter(183, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                            __builder3.AddComponentParameter(184, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, $.$Iaui.LCFCM.ResourceModel.op_Implicit$1(context.Data.LCFC$IDisplayable$Icon)));
                            __builder3.AddComponentParameter(185, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(186, "\r\n                ");
                            __builder3.OpenElement(187, "div");
                            __builder3.AddAttribute$5(188, "class", "pd bdt");
                            __builder3.OpenElement(189, "h3");
                            __builder3.AddAttribute$5(190, "class", "mg-0 lh-1");
                            __builder3.AddContent$4(191, context.Data.LCFC$IDisplayable$Title);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(192, "\r\n                    ");
                            __builder3.OpenElement(193, "h4");
                            __builder3.AddAttribute$5(194, "class", "mg-0 text-right cl-primary");
                            __builder3.AddContent$3(195, context.Data.LCFCP$ICatalogueModel$UnitCost);
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $QDvWkh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
                    }), $kuJBzc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$AvdQ.LCFCP.IProductCatalogueModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$AvdQ.LCFCP.IProductCatalogueModel)).$h}],"n":"","d":868071,"h":0,"f":17825794}));
                    __builder2.SetKey($.$box($.$$.S.HashCode.Combine$6($.$$.S.Object, $.$$.S.Int32, $.$cast(this.currentCategory, $.$$.S.Object) ?? this, this.searchSequence), $.$$.S.Int32));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(196, "\r\n    ");
                }, $guTpZi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(244814003943)
            
            //--TRIMMABLE-BOUNDARY-START(240519036647)
            /*RenderFragment */ PrintView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519036647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(197, "div");
                    __builder2.AddAttribute$5(198, "class", "wx-25 bd mihx-2 mgx-a pd bg-tertiary");
                    __builder2.AddElementReferenceCapture(199, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.printElement = __value;
                    }, $xOlrid ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":868071,"h":0,"f":17825794}));
                    __builder2.OpenElement(200, "div");
                    __builder2.AddAttribute$5(201, "class", "text-center");
                    __builder2.OpenElement(202, "h2");
                    __builder2.AddAttribute$5(203, "class", "mg-0");
                    __builder2.AddContent$4(204, this.Provider.LCFC$IDisplayable$Title);
                    __builder2.CloseElement();
                    if ((this.Provider.LCFCP$ICatalogueProvider$Settings?.LCFCP$ICatalogueSettings$Location?.Address ?? null) !== null)
                    {
                        __builder2.OpenElement(205, "p");
                        __builder2.AddAttribute$5(206, "class", "mg-0");
                        __builder2.AddContent$4(207, (this.Provider.LCFCP$ICatalogueProvider$Settings?.LCFCP$ICatalogueSettings$Location?.Address ?? null));
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(208, "p");
                    __builder2.AddAttribute$5(209, "class", "mg-0");
                    __builder2.AddContent$4(210, this.order.LCFC$IDisplayable$Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(211, "\r\n            ");
                    __builder2.OpenElement(212, "p");
                    __builder2.AddAttribute$5(213, "class", "mg-0");
                    __builder2.AddContent$3(214, this.order.LCFCP$ICatalogueOrderModel$DateCreated);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(215, "\r\n            ");
                    __builder2.AddMarkupContent(216, "<p class=\"mg-0 nowrap\">********************************************</p>\r\n            ");
                    __builder2.AddMarkupContent(217, "<h3 class=\"mg-0\">SALES RECEIPT</h3>\r\n            ");
                    __builder2.AddMarkupContent(218, "<p class=\"mg-0 nowrap\">********************************************</p>");
                    __builder2.CloseElement();
                    let $en17 = this.orderItems.GetEnumerator();
                    while ($en17.MoveNext())
                    {
                        let item = $en17.Current;
                        {
                            __builder2.OpenElement(219, "div");
                            __builder2.AddAttribute$5(220, "class", "flex bdb pdy-1");
                            __builder2.OpenElement(221, "div");
                            __builder2.AddAttribute$5(222, "class", "fill");
                            __builder2.OpenElement(223, "b");
                            __builder2.AddContent$3(224, $.$box($.$$.S.Math.Abs$3(item.LCFCP$ICatalogueOrderItemModel$UnitQuantity), $.$$.S.Int32));
                            __builder2.CloseElement();
                            __builder2.AddContent$4(225, " * ");
                            __builder2.AddContent$4(226, item.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFC$IDisplayable$Title);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(227, "\r\n            ");
                            __builder2.OpenElement(228, "div");
                            __builder2.AddAttribute$5(229, "class", "mgl");
                            __builder2.AddContent$3(230, item.LCFCP$ICatalogueOrderItemModel$TotalAmount);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                    }
                    __builder2.OpenElement(231, "div");
                    __builder2.AddAttribute$5(232, "class", "flex bdb pdy-1 mgl-5");
                    __builder2.AddMarkupContent(233, "<div class=\"fill mgy-a\"><b>Sub Total</b></div>\r\n            ");
                    __builder2.OpenElement(234, "div");
                    __builder2.AddAttribute$5(235, "class", "mgl fw-bold fsz-17");
                    __builder2.AddContent$3(236, $.$clone(this.Amount));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.VAT.Value > 0)
                    {
                        __builder2.OpenElement(237, "div");
                        __builder2.AddAttribute$5(238, "class", "flex bdb pdy-1 mgl-5");
                        __builder2.OpenElement(239, "div");
                        __builder2.AddAttribute$5(240, "class", "fill mgy-a");
                        __builder2.OpenElement(241, "b");
                        __builder2.AddContent$4(242, "VAT (");
                        __builder2.AddContent$3(243, $.$box((this.Provider.LCFCP$ICatalogueProvider$Settings?.LCFCP$ICatalogueSettings$VATRate ?? null), $.$$.S.Double));
                        __builder2.AddContent$4(244, "%)");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(245, "\r\n            ");
                        __builder2.OpenElement(246, "div");
                        __builder2.AddAttribute$5(247, "class", "mgl fw-bold fsz-17");
                        __builder2.AddContent$3(248, $.$clone(this.VAT));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(249, "div");
                    __builder2.AddAttribute$5(250, "class", "flex bdb pdy-1 mgl-5");
                    __builder2.AddMarkupContent(251, "<div class=\"fill mgy-a\"><b>Total</b></div>\r\n            ");
                    __builder2.OpenElement(252, "div");
                    __builder2.AddAttribute$5(253, "class", "mgl fw-bold fsz-20");
                    __builder2.AddContent$3(254, $.$clone(this.Total));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(255, "\r\n        ");
                    __builder2.AddMarkupContent(256, "<p class=\"nowrap\">*********************************************</p>");
                    if ((this.Provider.LCFCP$ICatalogueProvider$Settings?.LCFCP$ICatalogueSettings$ReceiptPrologue ?? null) !== null)
                    {
                        __builder2.OpenElement(257, "p");
                        __builder2.AddAttribute$5(258, "class", "text-center");
                        __builder2.AddContent$4(259, (this.Provider.LCFCP$ICatalogueProvider$Settings?.LCFCP$ICatalogueSettings$ReceiptPrologue ?? null));
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                }, $zBexEh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":868071,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(240519036647)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Product.ICatalogueCategoryModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Product.ICatalogueCategoryModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Product$ICatalogueCategoryModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Product.IProductCatalogueModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Product.IProductCatalogueModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Product$IProductCatalogueModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(30065639143)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065639143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065639143)
            
            //--TRIMMABLE-BOUNDARY-START(30065639143)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30065639143)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(253403938535)
                this.Provider = null;
                //--TRIMMABLE-BOUNDARY-END(253403938535)
                
                //--TRIMMABLE-BOUNDARY-START(210454265575)
                this.Order = null;
                //--TRIMMABLE-BOUNDARY-END(210454265575)
                
                //--TRIMMABLE-BOUNDARY-START(171799559911)
                this.JavaScript = null;
                //--TRIMMABLE-BOUNDARY-END(171799559911)
                
                //--TRIMMABLE-BOUNDARY-START(214749232871)
                this.orderItems = new ($.$$.SCG.List$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(214749232871)
                
                //--TRIMMABLE-BOUNDARY-START(184684461799)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(184684461799)
                
                //--TRIMMABLE-BOUNDARY-START(231929102055)
                this.printElement = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(231929102055)
                
            }
            static $h = 868071;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(201864330983),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259952359,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 868071,
      "h": 201864330983,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(201864330983),
//--TRIMMABLE-BOUNDARY-START(335008317159),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029756135,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418382567,
        "f": 83886081
      },
      "n": "Title",
      "d": 868071,
      "h": 335008317159,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335008317159),
//--TRIMMABLE-BOUNDARY-START(253403938535),
    {
      "p": 1851111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439821543,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828447975,
        "f": 83886081
      },
      "n": "Provider",
      "d": 868071,
      "h": 253403938535,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253403938535),
//--TRIMMABLE-BOUNDARY-START(210454265575),
    {
      "p": 2208704,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849886951,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238513383,
        "f": 83886081
      },
      "n": "Order",
      "d": 868071,
      "h": 210454265575,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210454265575),
//--TRIMMABLE-BOUNDARY-START(171799559911),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490148583,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468709607,
        "f": 83886081
      },
      "n": "JavaScript",
      "d": 868071,
      "h": 171799559911,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799559911),
//--TRIMMABLE-BOUNDARY-START(42950541031),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900213991,
        "f": 50331650
      },
      "n": "Amount",
      "d": 868071,
      "h": 42950541031,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950541031),
//--TRIMMABLE-BOUNDARY-START(347893219047),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209625319,
        "f": 50331650
      },
      "n": "VAT",
      "d": 868071,
      "h": 347893219047,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(347893219047),
//--TRIMMABLE-BOUNDARY-START(339303284455),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619690727,
        "f": 50331650
      },
      "n": "Total",
      "d": 868071,
      "h": 339303284455,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(339303284455),
//--TRIMMABLE-BOUNDARY-START(184684461799),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670017767,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648578791,
        "f": 83886081
      },
      "n": "Loading",
      "d": 868071,
      "h": 184684461799,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684461799),
//--TRIMMABLE-BOUNDARY-START(180389494503),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080083175,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058644199,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 868071,
      "h": 180389494503,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389494503)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(343598251751),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 868071,
      "h": 343598251751,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(343598251751),
//--TRIMMABLE-BOUNDARY-START(167504592615),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 868071,
      "h": 167504592615,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504592615),
//--TRIMMABLE-BOUNDARY-START(188979429095),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 868071,
      "h": 188979429095,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(188979429095),
//--TRIMMABLE-BOUNDARY-START(266288840423),
    {
      "r": 65537,
      "n": "Search",
      "d": 868071,
      "h": 266288840423,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(266288840423),
//--TRIMMABLE-BOUNDARY-START(55835442919),
    {
      "r": 181338113,
      "n": "ContinueOrder",
      "d": 868071,
      "h": 55835442919,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(55835442919),
//--TRIMMABLE-BOUNDARY-START(51540475623),
    {
      "r": 65537,
      "n": "CancelOrder",
      "d": 868071,
      "h": 51540475623,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540475623),
//--TRIMMABLE-BOUNDARY-START(236224069351),
    {
      "r": 178454529,
      "n": "PrintReceipt",
      "d": 868071,
      "h": 236224069351,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(236224069351),
//--TRIMMABLE-BOUNDARY-START(330713349863),
    {
      "r": 178454529,
      "n": "StartNewOrder",
      "d": 868071,
      "h": 330713349863,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(330713349863),
//--TRIMMABLE-BOUNDARY-START(60130410215),
    {
      "r": 178454529,
      "n": "CreateOrder",
      "d": 868071,
      "h": 60130410215,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(60130410215),
//--TRIMMABLE-BOUNDARY-START(193274396391),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 868071,
      "h": 193274396391,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(193274396391),
//--TRIMMABLE-BOUNDARY-START(197569363687),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$AvdQ.LCFCP.IProductCatalogueModel).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$1",
      "d": 868071,
      "h": 197569363687,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(197569363687),
//--TRIMMABLE-BOUNDARY-START(176094527207),
    {
      "r": 181338113,
      "n": "Load",
      "d": 868071,
      "h": 176094527207,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094527207),
//--TRIMMABLE-BOUNDARY-START(47245508327),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 868071,
      "h": 47245508327,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245508327),
//--TRIMMABLE-BOUNDARY-START(223339167463),
    {
      "r": 6881395,
      "p": [
        {
          "n": "box",
          "p": 417192
        },
        {
          "n": "_class",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "OrderWizard",
      "d": 868071,
      "h": 223339167463,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223339167463),
//--TRIMMABLE-BOUNDARY-START(244814003943),
    {
      "r": 6881395,
      "n": "ProductListing",
      "d": 868071,
      "h": 244814003943,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244814003943),
//--TRIMMABLE-BOUNDARY-START(240519036647),
    {
      "r": 6881395,
      "n": "PrintView",
      "d": 868071,
      "h": 240519036647,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240519036647)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(270583807719),
    {
      "t": 1310721,
      "n": "searchKey",
      "d": 868071,
      "h": 270583807719,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(270583807719),
//--TRIMMABLE-BOUNDARY-START(64425377511),
    {
      "t": 1749952,
      "n": "currentCategory",
      "d": 868071,
      "h": 64425377511,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425377511),
//--TRIMMABLE-BOUNDARY-START(214749232871),
    {
      "t": $.$$.SCG.List$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h,
      "n": "orderItems",
      "d": 868071,
      "h": 214749232871,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(214749232871),
//--TRIMMABLE-BOUNDARY-START(227634134759),
    {
      "t": 1459992,
      "n": "payment",
      "d": 868071,
      "h": 227634134759,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(227634134759),
//--TRIMMABLE-BOUNDARY-START(68720344807),
    {
      "t": 5081430,
      "n": "customer",
      "d": 868071,
      "h": 68720344807,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720344807),
//--TRIMMABLE-BOUNDARY-START(206159298279),
    {
      "t": 2208704,
      "n": "order",
      "d": 868071,
      "h": 206159298279,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(206159298279),
//--TRIMMABLE-BOUNDARY-START(73015312103),
    {
      "t": 1310721,
      "n": "customerName",
      "d": 868071,
      "h": 73015312103,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015312103),
//--TRIMMABLE-BOUNDARY-START(77310279399),
    {
      "t": 1310721,
      "n": "customerPhoneNumber",
      "d": 868071,
      "h": 77310279399,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310279399),
//--TRIMMABLE-BOUNDARY-START(274878775015),
    {
      "t": 655361,
      "n": "searchSequence",
      "d": 868071,
      "h": 274878775015,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(274878775015),
//--TRIMMABLE-BOUNDARY-START(219044200167),
    {
      "t": 59004586,
      "n": "orderWizard",
      "d": 868071,
      "h": 219044200167,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(219044200167),
//--TRIMMABLE-BOUNDARY-START(231929102055),
    {
      "t": 1900659,
      "n": "printElement",
      "d": 868071,
      "h": 231929102055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(231929102055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065639143),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 868071,
      "h": 30065639143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065639143)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(249108971239),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 868071,
        "h": 38655573735,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 868071,
        "h": 261993873127,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 868071,
      "h": 249108971239,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(249108971239)
  ],
  "h": 868071
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$AvdQ.LCFCP.ICatalogueCategoryModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$AvdQ.LCFCP.ICatalogueCategoryModel), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$AvdQ.LCFCP.IProductCatalogueModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$AvdQ.LCFCP.IProductCatalogueModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.CatalogueOrder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}CatalogueOrder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(868071)
        
        

        //--TRIMMABLE-BOUNDARY-START(1523431)
        $asm.$cls(`$dgLE.LCPCSG.AppServiceSelector<,,,,>`, (TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType) => $asm.$gt(`$dgLE.LCPCSG.AppServiceSelector<,,,,>`, [TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType], ($self) => class AppServiceSelector$$$$$$ extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(146030411495)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(146030411495)
            
            //--TRIMMABLE-BOUNDARY-START(184685117159)
            /*IServiceGuardViewModel<TServiceModel, TServiceTierType, TServiceFeatureType>*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(184685117159)
            
            //--TRIMMABLE-BOUNDARY-START(158915313383)
            /*EventCallback<AppServiceSelected<TServiceModel>>*/ OnServiceAccountSelected;
            //--TRIMMABLE-BOUNDARY-END(158915313383)
            
            //--TRIMMABLE-BOUNDARY-START(141735444199)
            /*bool*/ LoadLastAccount = false;
            //--TRIMMABLE-BOUNDARY-END(141735444199)
            
            //--TRIMMABLE-BOUNDARY-START(188980084455)
            /*string?*/ ServiceId = null;
            //--TRIMMABLE-BOUNDARY-END(188980084455)
            
            //--TRIMMABLE-BOUNDARY-START(137440476903)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(137440476903)
            
            //--TRIMMABLE-BOUNDARY-START(133145509607)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(133145509607)
            
            //--TRIMMABLE-BOUNDARY-START(167505247975)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(167505247975)
            
            //--TRIMMABLE-BOUNDARY-START(167505247975)
            //--TRIMMABLE-BOUNDARY-START(42951196391)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951196391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(42951196391)
            
            //--TRIMMABLE-BOUNDARY-START(176095182567)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095182567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(176095182567)
            
            //--TRIMMABLE-BOUNDARY-END(167505247975)
            
            //--TRIMMABLE-BOUNDARY-START(128850542311)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850542311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(128850542311)
            
            //--TRIMMABLE-BOUNDARY-START(193275051751)
            /*bool*/ serviceLoaded = false;
            //--TRIMMABLE-BOUNDARY-END(193275051751)
            
            //--TRIMMABLE-BOUNDARY-START(180390149863)
            /*Task *//*async*/  Select(/*TServiceModel*/ service, /*bool*/ fromCache)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180390149863);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.OnServiceAccountSelected.HasDelegate)
                    {
                        let $t1, $r1;
                        ($t1 = this.OnServiceAccountSelected.InvokeAsync$1((() =>
                        {
                            //new $.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel)()
                            const $t2 = $.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel);
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Service = service;
                            $i2.FromCache = fromCache;
                            return $i2;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(180390149863)
            
            //--TRIMMABLE-BOUNDARY-START(150325378791)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325378791);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.UnitOfWork.LCFCI$IClientUnitOfWork$Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        if (!$.$$.S.String.IsNullOrEmpty(this.ServiceId))
                        {
                            let $t3, $r3;
                            /*var*/ let account = ($t3 = this.Service.LCFCC$IServiceSubscriptionViewModel$$$GetLastService(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            /*object?*/ let __ca1__;
                            /*string?*/ let __ca2__;
                            if (account !== null && (((__ca1__ = account.Identifier.Id) !== null ? ((__ca2__ = $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString)) !== null ? $.$$.S.String.Equals$5.call(__ca2__, this.ServiceId) : false) : false)))
                            {
                                let $t4, $r4;
                                ($t4 = this.Select(account, true), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            }
                            else 
                            {
                                let $t5, $r5;
                                /*var*/ let ac = ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.TryReadSingle(TServiceModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$22(this.ServiceId, null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null), null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                if (ac !== null)
                                {
                                    let $t6, $r6;
                                    let $t7, $r7;
                                    ($t6 = this.Service.LCFCC$IServiceSubscriptionViewModel$$$SetLastService(ac), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                    ($t7 = this.Select(ac, false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                }
                                else if (account !== null)
                                {
                                    let $t8, $r8;
                                    ($t8 = this.Select(account, true), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                }
                            }
                        }
                        else if (this.LoadLastAccount)
                        {
                            let $t9, $r9;
                            ($t9 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    let $t10, $r10;
                                    /*var*/ let service = ($t10 = this.Service.LCFCC$IServiceSubscriptionViewModel$$$GetLastService(), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                                    this.serviceLoaded = true;
                                    if (service !== null)
                                    {
                                        let $t11, $r11;
                                        ($t11 = this.Select(service, true), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                    }
                                });
                            }, $SlpOxb ??= {"r":181338113,"n":"","d":this.$h,"H":0,"h":0,"f":17829890}), false, null, null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        }
                        else 
                        {
                            this.serviceLoaded = true;
                        }
                    }
                    ($t12 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150325378791)
            
            //--TRIMMABLE-BOUNDARY-START(154620346087)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<IUserServiceSubscriptionModel<IServiceDataModel>>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t13, $r13;
                    let $t14, $r14;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154620346087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t13 = this.Service.LCFCC$IServiceSubscriptionViewModel$$$SetLastService($.$cast(selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.LCFCM$IUserServiceSubscriptionModel$$$Service, TServiceModel)), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                    ($t14 = this.Select($.$cast(selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.LCFCM$IUserServiceSubscriptionModel$$$Service, TServiceModel), false), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154620346087)
            
            //--TRIMMABLE-BOUNDARY-START(51541130983)
            /*ValueTask *//*async*/  CreateServiceAccount()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t15, $r15;
                    let $t16, $r16;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541130983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t15 = this.UnitOfWork.LCFCI$IClientUnitOfWork$ClientAuthentication.LCFCI$IClientAuthenticationService$AuthenticateAsync($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, true, true, true, false, false), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                    ($t16 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$dgLE.LCPCSG.AppServiceSignup$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType), this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*s*/ s) =>
                    {
                        b.AddAttribute$4(s++, "Service", this.Service);
                        b.AddAttribute$3(s++, "Prologue", $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`<h2> Create New Service Subscription for ${$.$strNN(this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel)}</h2>\r\n                `, true));
                    }, $LdjKHg ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"s","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t17 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.PageBackgroundTheme = $.$fPer.LCFC.Theme.Card;
                        $i17.ViewFeatures = 63207/*ViewFeatures.PromptDefault*/ & ~1/*ViewFeatures.OKToolBar*/ & ~2/*ViewFeatures.CancelToolBar*/;
                        $i17.BodyAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t18 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i18 = new $t18();
                            $i18.$ctor$1();
                            $i18.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "pd");
                            return $i18;
                        })();
                        return $i17;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51541130983)
            
            //--TRIMMABLE-BOUNDARY-START(163210280679)
            /*string */ get OptimizedComponentName()
            {
                return "appserviceselector";
            }
            //--TRIMMABLE-BOUNDARY-END(163210280679)
            
            //--TRIMMABLE-BOUNDARY-START(257699561191)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699561191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch19 = parameter.Name;
                switch($switch19)
                {
                    case "Service":
                    this.Service = $.$cast(parameter.Value, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType));
                    return true;
                    case "OnServiceAccountSelected":
                    this.OnServiceAccountSelected = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel)));
                    return true;
                    case "LoadLastAccount":
                    this.LoadLastAccount = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                    case "ServiceId":
                    this.ServiceId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(257699561191)
            
            //--TRIMMABLE-BOUNDARY-START(124555575015)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555575015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(124555575015)
            
            //--TRIMMABLE-BOUNDARY-START(47246163687)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246163687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf bg-fill");
                __builder.AddAttribute$5(2, "style", $.$strNN("background-image:url('" + $.$strNN((this.ResolvePath("img/banner-4.jpg", true, true, false)))) + "')");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "bg-tertiary-08 hf scroll");
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 5);
                __builder.AddComponentParameter(6, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    if (this.serviceLoaded)
                    {
                        /*TServiceModel?*/ let __ca1__;
                        if (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected === null)
                        {
                            __builder2.OpenElement(9, "div");
                            __builder2.AddAttribute$5(10, "class", "hf scroll");
                            __builder2.OpenElement(11, "div");
                            __builder2.AddAttribute$5(12, "class", "pd mawx-4 mgx-a bdb");
                            __builder2.OpenElement(13, "div");
                            __builder2.AddAttribute$5(14, "class", "text-center");
                            __builder2.AddMarkupContent(15, "<i class=\"mdi mdi-school mgx-a d-block fsz-80 mgt\"></i>\r\n                                ");
                            __builder2.OpenElement(16, "p");
                            __builder2.AddContent$4(17, this.Service.LCFC$IDescribable$Description);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(18, "\r\n                                ");
                            __builder2.OpenElement(19, "h2");
                            __builder2.AddContent$4(20, "Please choose your ");
                            __builder2.AddContent$4(21, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(22, "\r\n                                ");
                            __builder2.AddMarkupContent(23, "<p>OR</p>\r\n                                ");
                            __builder2.OpenElement(24, "p");
                            __builder2.AddAttribute$5(25, "class", "cl-primary fsz-20 fw-bold mb-0");
                            __builder2.OpenElement(26, "button");
                            __builder2.AddAttribute$5(27, "class", "bg-primary pd-5 corner-5");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 28, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.CreateServiceAccount)));
                            __builder2.AddContent$4(29, "Create a New ");
                            __builder2.AddContent$4(30, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(31, "\r\n                        ");
                            __builder2.OpenComponent$1($.$dgLE.LCPCS$1.ServiceMenuSelector, 32);
                            __builder2.AddComponentParameter(33, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IServiceSubscriptionViewModel, this.Service));
                            __builder2.AddComponentParameter(34, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)), this));
                            __builder2.AddComponentParameter(35, "Class", "pd");
                            __builder2.AddComponentParameter(36, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$dgLE.LCPCS$1.ServiceMenuSelectorFeatures, 0/*ServiceMenuSelectorFeatures.Default*/ | 1/*ServiceMenuSelectorFeatures.Search*/), $.$dgLE.LCPCS$1.ServiceMenuSelectorFeatures));
                            __builder2.AddComponentParameter(37, "li-class", "bg-card");
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                        else if (((__ca1__ = this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service) !== null ? $.$fPer.LCFCD.ServiceExtension.IsExpired($.$box(__ca1__, TServiceModel)) : false) === true)
                        {
                            __builder2.OpenElement(38, "div");
                            __builder2.AddAttribute$5(39, "class", "pd hf scroll");
                            __builder2.OpenElement(40, "div");
                            __builder2.AddAttribute$5(41, "class", "pd mawx-4 mgx-a bdb");
                            __builder2.OpenElement(42, "h2");
                            __builder2.AddContent$4(43, this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service.Title);
                            __builder2.AddContent$4(44, " expired on ");
                            __builder2.AddContent$3(45, this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service.ExpiryDate);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(46, "\r\n                            ");
                            __builder2.OpenElement(47, "p");
                            __builder2.AddMarkupContent(48, "\r\n                                You need an active service subscription to use ");
                            __builder2.AddContent$4(49, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                            __builder2.AddMarkupContent(50, " Portal.\r\n                                If this is your first time, you can use a free trial subscription package\r\n                            ");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(51, "\r\n                        ");
                            __builder2.OpenComponent$1($.$dgLE.LCPCSG.AppServiceSignup$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType), 52);
                            __builder2.AddComponentParameter(53, "Service", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType), this.Service));
                            __builder2.AddComponentParameter(54, "ViewModel", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(TServiceModel, this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service), TServiceModel));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                        else 
                        {
                            __builder2.OpenElement(55, "div");
                            __builder2.AddAttribute$5(56, "class", "mg-a mawx-4 shadow corner pd");
                            __builder2.OpenElement(57, "h3");
                            __builder2.AddContent$4(58, "Loading ");
                            __builder2.OpenElement(59, "b");
                            __builder2.AddContent$4(60, (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service?.Name ?? null));
                            __builder2.CloseElement();
                            __builder2.AddContent$4(61, ".");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                    }
                }), $lKPEpf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(47246163687)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Models.IUserServiceSubscriptionModel<LivingThing.Core.Frameworks.Common.Data.IServiceDataModel>>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Models.IUserServiceSubscriptionModel<LivingThing.Core.Frameworks.Common.Data.IServiceDataModel>>)
            [`LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Models$IUserServiceSubscriptionModel$LivingThing$Core$Frameworks$Common$Data$IServiceDataModel$$OnSelected`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(34361261799)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361261799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361261799)
            
            //--TRIMMABLE-BOUNDARY-START(34361261799)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34361261799)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(146030411495)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(146030411495)
                
                //--TRIMMABLE-BOUNDARY-START(158915313383)
                this.OnServiceAccountSelected = $.$default($.$mac.MAC.EventCallback$$($.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel)));
                //--TRIMMABLE-BOUNDARY-END(158915313383)
                
                //--TRIMMABLE-BOUNDARY-START(141735444199)
                this.LoadLastAccount = true;
                //--TRIMMABLE-BOUNDARY-END(141735444199)
                
                //--TRIMMABLE-BOUNDARY-START(137440476903)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(137440476903)
                
            }
            static $H = 1523431;
            static $h = 1523431;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(146030411495),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85900869351,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 227634790119,
        "h": Number(BigInt(this.$h)|0x3500000000n),
        "f": 83886081
      },
      "n": "Navigation",
      "d": this.$h,
      "H": 146030411495,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030411495),
//--TRIMMABLE-BOUNDARY-START(184685117159),
    {
      "p": $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111670673127,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 244814659303,
        "h": Number(BigInt(this.$h)|0x3900000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 184685117159,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685117159),
//--TRIMMABLE-BOUNDARY-START(158915313383),
    {
      "p": $.$mac.MAC.EventCallback$$($.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94490803943,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 236224724711,
        "h": Number(BigInt(this.$h)|0x3700000000n),
        "f": 83886081
      },
      "n": "OnServiceAccountSelected",
      "d": this.$h,
      "H": 158915313383,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158915313383),
//--TRIMMABLE-BOUNDARY-START(141735444199),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77310934759,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 219044855527,
        "h": Number(BigInt(this.$h)|0x3300000000n),
        "f": 83886081
      },
      "n": "LoadLastAccount",
      "d": this.$h,
      "H": 141735444199,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141735444199),
//--TRIMMABLE-BOUNDARY-START(188980084455),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120260607719,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 253404593895,
        "h": Number(BigInt(this.$h)|0x3B00000000n),
        "f": 83886081
      },
      "n": "ServiceId",
      "d": this.$h,
      "H": 188980084455,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980084455),
//--TRIMMABLE-BOUNDARY-START(137440476903),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721000167,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 210454920935,
        "h": Number(BigInt(this.$h)|0x3100000000n),
        "f": 83886081
      },
      "n": "Loading",
      "d": this.$h,
      "H": 137440476903,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137440476903),
//--TRIMMABLE-BOUNDARY-START(133145509607),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131065575,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 201864986343,
        "h": Number(BigInt(this.$h)|0x2F00000000n),
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": this.$h,
      "H": 133145509607,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145509607),
//--TRIMMABLE-BOUNDARY-START(163210280679),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103080738535,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 163210280679,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163210280679)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850542311),
    {
      "r": 181338113,
      "n": "Load",
      "d": this.$h,
      "H": 128850542311,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850542311),
//--TRIMMABLE-BOUNDARY-START(180390149863),
    {
      "r": 178454529,
      "p": [
        {
          "n": "service",
          "p": TServiceModel?.$h??1572864
        },
        {
          "n": "fromCache",
          "p": 262145
        }
      ],
      "n": "Select",
      "d": this.$h,
      "H": 180390149863,
      "h": Number(BigInt(this.$h)|0x2A00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(180390149863),
//--TRIMMABLE-BOUNDARY-START(150325378791),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": this.$h,
      "H": 150325378791,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(150325378791),
//--TRIMMABLE-BOUNDARY-START(154620346087),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)).$h
        }
      ],
      "n": "OnSelected",
      "d": this.$h,
      "H": 154620346087,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(154620346087),
//--TRIMMABLE-BOUNDARY-START(51541130983),
    {
      "r": 181338113,
      "n": "CreateServiceAccount",
      "d": this.$h,
      "H": 51541130983,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(51541130983),
//--TRIMMABLE-BOUNDARY-START(257699561191),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 257699561191,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(257699561191),
//--TRIMMABLE-BOUNDARY-START(124555575015),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 124555575015,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555575015),
//--TRIMMABLE-BOUNDARY-START(47246163687),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 47246163687,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246163687)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(193275051751),
    {
      "t": 262145,
      "n": "serviceLoaded",
      "d": this.$h,
      "H": 193275051751,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(193275051751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361261799),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 34361261799,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361261799)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(167505247975),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 42951196391,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 176095182567,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": this.$h,
      "H": 167505247975,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(167505247975)
  ],
  "s": [
    {
      "h": TServiceModel?.$h??1572864,
      "n": "TServiceModel",
      "f": 4,
      "c": [$.$Iaui.LCFCM.ServiceModel$$$$(TServiceTierType, TServiceSettings, TServiceStates).$h
      ]
    },
    {
      "h": TServiceSettings?.$h??1638400,
      "n": "TServiceSettings",
      "f": 4,
      "c": [20456790
      ]
    },
    {
      "h": TServiceStates?.$h??1703936,
      "n": "TServiceStates",
      "f": 4,
      "c": [22422870
      ]
    },
    {
      "h": TServiceTierType?.$h??1769472,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1835008,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 5,
  "H": 1523431,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceSelector<${TServiceModel?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceSelector$${TServiceModel?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1523431)
        
        

        //--TRIMMABLE-BOUNDARY-START(1130215)
        $asm.$cls(`$dgLE.LCPCS$1.ChooseServiceTier`, ($self) => class ChooseServiceTier extends $.$hDPm.LCFCC$1.BaseModelContainer$$($.$nYKj.LCFCP.IPaymentTier)
        {
            //--TRIMMABLE-BOUNDARY-START(21475966695)
            /*object?*/ DataTag = null;
            //--TRIMMABLE-BOUNDARY-END(21475966695)
            
            //--TRIMMABLE-BOUNDARY-START(60130672359)
            /*IPaymentTierProvider*/ ServiceTierProvider = null;
            //--TRIMMABLE-BOUNDARY-END(60130672359)
            
            //--TRIMMABLE-BOUNDARY-START(51540737767)
            /*IconDescriptor */ GetIcon(/*IEnumerable<IPaymentTier>*/ paths)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540737767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = paths.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let p = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (p.LCFC$IDisplayable$Icon.Icon !== null)
                        {
                            return p.LCFC$IDisplayable$Icon;
                        }
                    }
                }
                return this.ServiceTierProvider.LCFC$IDisplayable$Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(51540737767)
            
            //--TRIMMABLE-BOUNDARY-START(55835705063)
            /*string */ get OptimizedComponentName()
            {
                return "chooseservicetier";
            }
            //--TRIMMABLE-BOUNDARY-END(55835705063)
            
            //--TRIMMABLE-BOUNDARY-START(81605508839)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605508839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "DataTag":
                    this.DataTag = parameter.Value;
                    return true;
                    case "ServiceTierProvider":
                    this.ServiceTierProvider = $.$cast(parameter.Value, $.$nYKj.LCFCP.IPaymentTierProvider);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81605508839)
            
            //--TRIMMABLE-BOUNDARY-START(17180999399)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180999399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.SelectHierachy, 0);
                __builder.AddComponentParameter(1, "PagerSource", ($.$fPer.LCFCD.Paging.Cast$1($.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IChildrenHierachy, this.ServiceTierProvider.LCFCP$IPaymentTierProvider$ServiceTiers)));
                __builder.AddComponentParameter(2, "DataTag", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.DataTag));
                __builder.AddComponentParameter(3, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                __builder.AddComponentParameter(4, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                __builder.AddComponentParameter(5, "SelectHierachyFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.SelectHierachyFeatures, 1/*SelectHierachyFeatures.Default*/ | 2/*SelectHierachyFeatures.BackButton*/), $.$hDPm.LCFCCD$1.SelectHierachyFeatures));
                __builder.AddAttribute$3(6, "Title", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)))().$ctor(this, ( (/**/ paths) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        if (!$.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD.IChildrenHierachy, paths))
                        {
                            __builder2.AddContent$4(7, `Choose ${$.$strNN((this.ServiceTierProvider.LCFCP$IPaymentTierProvider$ServiceTierName !== null ? "a " + $.$strNN(this.ServiceTierProvider.LCFCP$IPaymentTierProvider$ServiceTierName) : ""))}`);
                        }
                        else 
                        {
                            /*var*/ let current = $.$cast($.$sl.SL.Enumerable.Last$1($.$fPer.LCFCD.IChildrenHierachy, paths), $.$nYKj.LCFCP.IPaymentTier);
                            __builder2.AddContent$4(8, `Choose ${$.$strNN((current.LCFCP$IPaymentTier$ServiceTierName !== null ? "a " + $.$strNN(current.LCFCP$IPaymentTier$ServiceTierName) : ""))}`);
                        }
                    }, $gdoaCg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1130215,"h":0,"f":17825794});
                }), $qYdQMi ??= {"r":6881395,"p":[{"n":"paths","p":$.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy).$h}],"n":"","d":1130215,"h":0,"f":17825794}));
                __builder.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.IChildrenHierachy, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.IChildrenHierachy))))().$ctor(this, ( (/**/ _tier) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        /*IPaymentTier*/ let tier = $.$cast(_tier.Data, $.$nYKj.LCFCP.IPaymentTier);
                        __builder2.OpenElement(10, "div");
                        __builder2.AddAttribute$5(11, "class", "stack mgx text-center mawx-1 miwx-1");
                        __builder2.OpenElement(12, "div");
                        __builder2.AddAttribute$5(13, "class", "mgx-a hx-04 wx-04 flex corner-2 bd clip");
                        __builder2.AddAttribute$5(14, "style", tier.LCFC$IDisplayable$Icon.Theme.BackgroundColor !== null ? `background-color:${$.$strNN(tier.LCFC$IDisplayable$Icon.Theme.BackgroundColor)}` : "");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 15);
                        __builder2.AddComponentParameter(16, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, (tier.LCFC$IDisplayable$Icon.Icon !== null ? tier.LCFC$IDisplayable$Icon : this.ServiceTierProvider.LCFC$IDisplayable$Icon)));
                        __builder2.AddComponentParameter(17, "Class", "mg-a fsz-25");
                        __builder2.AddComponentParameter(18, "IconSize", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                        __builder2.AddComponentParameter(19, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                        __builder2.AddComponentParameter(20, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                        __builder2.AddComponentParameter(21, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(22, "\r\n            ");
                        __builder2.OpenElement(23, "span");
                        __builder2.AddContent$4(24, tier.LCFC$IDisplayable$Title);
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $yaJNnl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1130215,"h":0,"f":17825794});
                }), $SZdpti ??= {"r":6881395,"p":[{"n":"_tier","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.IChildrenHierachy, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.IChildrenHierachy)).$h}],"n":"","d":1130215,"h":0,"f":17825794}));
                __builder.AddAttribute$3(25, "SelectedView", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)))().$ctor(this, ( (/**/ paths) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(26, "div");
                        __builder2.AddAttribute$5(27, "class", "stack text-center");
                        __builder2.AddMarkupContent(28, "<h3 class=\"mgt-10\">You are entering</h3>\r\n            ");
                        __builder2.OpenElement(29, "div");
                        __builder2.AddAttribute$5(30, "class", "scroll");
                        __builder2.OpenElement(31, "div");
                        __builder2.AddAttribute$5(32, "class", "flex flex-center-x");
                        /*int*/ let ix = 0;
                        let $en3 = paths.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let _path = $en3.SCG$IEnumerator$$$Current;
                            {
                                if (ix !== 0)
                                {
                                    __builder2.AddMarkupContent(33, "<i class=\"mdi mdi-chevron-double-right mgx mgt-5\"></i>");
                                }
                                /*var*/ let path = $.$cast(_path, $.$nYKj.LCFCP.IPaymentTier);
                                __builder2.OpenElement(34, "div");
                                __builder2.AddAttribute$5(35, "class", "stack mgx text-center mawx-1 miwx-1");
                                __builder2.OpenElement(36, "div");
                                __builder2.AddAttribute$5(37, "class", "mgx-a hx-04 wx-04 flex corner-2 bd clip");
                                __builder2.AddAttribute$5(38, "style", path.LCFC$IDisplayable$Icon.Theme.BackgroundColor !== null ? `background-color:${$.$strNN(path.LCFC$IDisplayable$Icon.Theme.BackgroundColor)}` : "");
                                __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 39);
                                __builder2.AddComponentParameter(40, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, (path.LCFC$IDisplayable$Icon.Icon !== null ? path.LCFC$IDisplayable$Icon : this.GetIcon($.$sl.SL.Enumerable.Cast($.$nYKj.LCFCP.IPaymentTier, paths)))));
                                __builder2.AddComponentParameter(41, "Class", "mg-a fsz-25");
                                __builder2.AddComponentParameter(42, "IconSize", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                                __builder2.AddComponentParameter(43, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                                __builder2.AddComponentParameter(44, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                                __builder2.AddComponentParameter(45, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                __builder2.CloseComponent();
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(46, "\r\n                            ");
                                __builder2.OpenElement(47, "span");
                                __builder2.AddContent$4(48, path.LCFC$IDisplayable$Title);
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                ix++;
                            }
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        /*var*/ let last = $.$cast($.$sl.SL.Enumerable.LastOrDefault$3($.$fPer.LCFCD.IChildrenHierachy, paths), $.$nYKj.LCFCP.IPaymentTier);
                        /*LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?*/ let __ca1__;
                        if ((__ca1__ = last) !== null ? $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, __ca1__.LCFCP$IPaymentTier$Cost) : false)
                        {
                            __builder2.OpenElement(49, "h1");
                            __builder2.AddContent$4(50, "Costs ");
                            __builder2.AddContent$3(51, last.LCFCP$IPaymentTier$Cost);
                            __builder2.CloseElement();
                        }
                        __builder2.AddContent$1(52, (this.ChildContent?.Invoke(new ($.$hDPm.LCFCI.ContainerContext$$($.$nYKj.LCFCP.IPaymentTier))().$ctor$7(last)) ?? null));
                        __builder2.CloseElement();
                    }, $eKIMUf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1130215,"h":0,"f":17825794});
                }), $fAYQUh ??= {"r":6881395,"p":[{"n":"paths","p":$.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy).$h}],"n":"","d":1130215,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180999399)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886032103)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886032103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886032103)
            
            //--TRIMMABLE-BOUNDARY-START(12886032103)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12886032103)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130672359)
                this.ServiceTierProvider = null;
                //--TRIMMABLE-BOUNDARY-END(60130672359)
                
            }
            static $h = 1130215;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseModelContainer$$($.$nYKj.LCFCP.IPaymentTier); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475966695),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065901287,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720606951,
        "f": 83886081
      },
      "n": "DataTag",
      "d": 1130215,
      "h": 21475966695,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475966695),
//--TRIMMABLE-BOUNDARY-START(60130672359),
    {
      "p": 1001240,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245770471,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310541543,
        "f": 83886081
      },
      "n": "ServiceTierProvider",
      "d": 1130215,
      "h": 60130672359,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130672359),
//--TRIMMABLE-BOUNDARY-START(55835705063),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655835879,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1130215,
      "h": 55835705063,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835705063)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540737767),
    {
      "r": 46238038,
      "p": [
        {
          "n": "paths",
          "p": $.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTier).$h
        }
      ],
      "n": "GetIcon",
      "d": 1130215,
      "h": 51540737767,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540737767),
//--TRIMMABLE-BOUNDARY-START(81605508839),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1130215,
      "h": 81605508839,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605508839),
//--TRIMMABLE-BOUNDARY-START(17180999399),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1130215,
      "h": 17180999399,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180999399)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886032103),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1130215,
      "h": 12886032103,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886032103)
  ],
  "h": 1130215
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ChooseServiceTier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ChooseServiceTier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1130215)
        
        

        //--TRIMMABLE-BOUNDARY-START(1588967)
        $asm.$cls(`$dgLE.LCPCSG.AppServiceSignup<,,,,>`, (TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType) => $asm.$gt(`$dgLE.LCPCSG.AppServiceSignup<,,,,>`, [TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType], ($self) => class AppServiceSignup$$$$$$ extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(77311000295)
            /*IServiceGuardViewModel<TServiceModel, TServiceTierType, TServiceFeatureType>*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(77311000295)
            
            //--TRIMMABLE-BOUNDARY-START(73016032999)
            /*RenderFragment?*/ Prologue = null;
            //--TRIMMABLE-BOUNDARY-END(73016032999)
            
            //--TRIMMABLE-BOUNDARY-START(60131131111)
            /*EventCallback<TServiceModel>*/ OnCreated;
            //--TRIMMABLE-BOUNDARY-END(60131131111)
            
            //--TRIMMABLE-BOUNDARY-START(81605967591)
            /*Task *//*async*/  ServiceCreated(/*TServiceModel*/ service)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605967591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.LCFCC$IServiceSubscriptionViewModel$$$SetLastService(service), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = this.OnCreated.InvokeAsync$1(service), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81605967591)
            
            //--TRIMMABLE-BOUNDARY-START(64426098407)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426098407);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64426098407)
            
            //--TRIMMABLE-BOUNDARY-START(68721065703)
            /*string */ get OptimizedComponentName()
            {
                return "appservicesignup";
            }
            //--TRIMMABLE-BOUNDARY-END(68721065703)
            
            //--TRIMMABLE-BOUNDARY-START(111670738663)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670738663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch4 = parameter.Name;
                switch($switch4)
                {
                    case "Service":
                    this.Service = $.$cast(parameter.Value, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType));
                    return true;
                    case "Prologue":
                    this.Prologue = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "OnCreated":
                    this.OnCreated = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$(TServiceModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111670738663)
            
            //--TRIMMABLE-BOUNDARY-START(21476425447)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476425447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Common.Models.IUserServiceSubscriptionModel<TServiceModel>?*/ let __ca1__;
                if (!$.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$(TServiceModel), this.Service.LCFCC$IServiceSubscriptionViewModel$$$Subscriptions) || (((__ca1__ = this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected) !== null ? $.$fPer.LCFCD.ServiceExtension.IsExpired($.$box(__ca1__.LCFCM$IUserServiceSubscriptionModel$$$Service, TServiceModel)) : false) === true))
                {
                    if (this.Service.LCPCSG$IServiceGuardViewModel$$$$$Catalogue !== null)
                    {
                        __builder.OpenElement(0, "div");
                        __builder.AddAttribute$5(1, "class", "flex pd");
                        __builder.OpenComponent$1($.$dgLE.LCPCS$1.ServiceSignUp$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType), 2);
                        __builder.AddComponentParameter(3, "ServiceName", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel));
                        __builder.AddComponentParameter(4, "Service", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(TServiceModel, (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected?.LCFCM$IUserServiceSubscriptionModel$$$Service ?? null)), TServiceModel));
                        __builder.AddComponentParameter(5, "Provider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType), this.Service.LCPCSG$IServiceGuardViewModel$$$$$Catalogue));
                        __builder.AddComponentParameter(6, "Prologue", (this.Prologue));
                        __builder.AddComponentParameter(7, "OnServiceCreated", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$(TServiceModel), $.$mac.MAC.EventCallback.Factory.Create$10(TServiceModel, this, new ($.$$.S.Func$$$(TServiceModel, $.$$.STT.Task))().$ctor(this, this.ServiceCreated))));
                        __builder.AddAttribute$3(8, "Finished", new ($.$mac.MAC.RenderFragment$$(TServiceModel))().$ctor(this, ( (/*account*/ account) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                            {
                                __builder2.OpenElement(9, "div");
                                __builder2.AddAttribute$5(10, "class", "text-center stack pd");
                                __builder2.AddMarkupContent(11, "<i class=\"cl-primary mdi mdi-check-circle fsz-100 mgx-a\"></i>\r\n                        ");
                                __builder2.AddMarkupContent(12, "<h2>Congratulations</h2>\r\n                        ");
                                __builder2.OpenElement(13, "p");
                                __builder2.AddContent$4(14, account.Title);
                                __builder2.AddContent$4(15, " service is now setup and ready to use.");
                                __builder2.CloseElement();
                                if (account.ServiceLink !== null)
                                {
                                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 16);
                                    __builder2.AddComponentParameter(17, "Class", "d-block mgx-a mgb");
                                    __builder2.AddComponentParameter(18, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder2.AddComponentParameter(19, "PageLink", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, account.ServiceLink));
                                    __builder2.AddComponentParameter(20, "target", "_blank");
                                    __builder2.AddAttribute$3(21, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.AddContent$4(22, "Go to Portal");
                                    }), $eYcfRj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder2.CloseComponent();
                                }
                                else 
                                {
                                    __builder2.AddMarkupContent(23, "<p>Please refresh this page to access your portal</p>");
                                }
                                __builder2.CloseElement();
                            }, $SNBDKe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $pdCHCb ??= {"r":6881395,"p":[{"n":"account","p":TServiceModel?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.AddMarkupContent(24, "<p>You do not have an active subscription to this service</p>");
                    }
                }
                else 
                {
                    __builder.OpenComponent$1($.$dgLE.LCPCS$1.ServiceMenuSelector, 25);
                    __builder.AddComponentParameter(26, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IServiceSubscriptionViewModel, this.Service));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476425447)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181458151)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181458151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181458151)
            
            //--TRIMMABLE-BOUNDARY-START(17181458151)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17181458151)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77311000295)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(77311000295)
                
                //--TRIMMABLE-BOUNDARY-START(60131131111)
                this.OnCreated = $.$default($.$mac.MAC.EventCallback$$(TServiceModel));
                //--TRIMMABLE-BOUNDARY-END(60131131111)
                
            }
            static $H = 1588967;
            static $h = 1588967;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311000295),
    {
      "p": $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55836163815,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 107375771367,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 77311000295,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311000295),
//--TRIMMABLE-BOUNDARY-START(73016032999),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246229223,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 98785836775,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 83886081
      },
      "n": "Prologue",
      "d": this.$h,
      "H": 73016032999,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016032999),
//--TRIMMABLE-BOUNDARY-START(60131131111),
    {
      "p": $.$mac.MAC.EventCallback$$(TServiceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30066360039,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 90195902183,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 83886081
      },
      "n": "OnCreated",
      "d": this.$h,
      "H": 60131131111,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131131111),
//--TRIMMABLE-BOUNDARY-START(68721065703),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38656294631,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 68721065703,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68721065703)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605967591),
    {
      "r": 178454529,
      "p": [
        {
          "n": "service",
          "p": TServiceModel?.$h??1572864
        }
      ],
      "n": "ServiceCreated",
      "d": this.$h,
      "H": 81605967591,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(81605967591),
//--TRIMMABLE-BOUNDARY-START(64426098407),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": this.$h,
      "H": 64426098407,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(64426098407),
//--TRIMMABLE-BOUNDARY-START(111670738663),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 111670738663,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111670738663),
//--TRIMMABLE-BOUNDARY-START(21476425447),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 21476425447,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476425447)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181458151),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 17181458151,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181458151)
  ],
  "s": [
    {
      "h": TServiceModel?.$h??1572864,
      "n": "TServiceModel",
      "f": 4,
      "c": [$.$Iaui.LCFCM.ServiceModel$$$$(TServiceTierType, TServiceSettings, TServiceStates).$h
      ]
    },
    {
      "h": TServiceSettings?.$h??1638400,
      "n": "TServiceSettings",
      "f": 4,
      "c": [20456790
      ]
    },
    {
      "h": TServiceStates?.$h??1703936,
      "n": "TServiceStates",
      "f": 4,
      "c": [22422870
      ]
    },
    {
      "h": TServiceTierType?.$h??1769472,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1835008,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 5,
  "H": 1588967,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceSignup<${TServiceModel?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceSignup$${TServiceModel?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1588967)
        
        

        //--TRIMMABLE-BOUNDARY-START(1916647)
        $asm.$cls(`$dgLE.LCPCS$1.InvoiceReceipt`, ($self) => class InvoiceReceipt extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$AvdQ.LCFCP.IInvoiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(103081131751)
            /*string */ get OptimizedComponentName()
            {
                return "invoicereceipt";
            }
            //--TRIMMABLE-BOUNDARY-END(103081131751)
            
            //--TRIMMABLE-BOUNDARY-START(176095575783)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095575783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "OnPaid":
                    this.OnPaid = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.InvoicePayment));
                    return true;
                    case "PaymentServiceName":
                    this.PaymentServiceName = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(176095575783)
            
            //--TRIMMABLE-BOUNDARY-START(85901262567)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901262567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.JS = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(85901262567)
            
            //--TRIMMABLE-BOUNDARY-START(94491197159)
            /*IJavaScriptRunner*/ JS = null;
            //--TRIMMABLE-BOUNDARY-END(94491197159)
            
            //--TRIMMABLE-BOUNDARY-START(98786164455)
            /*EventCallback<InvoicePayment>*/ OnPaid;
            //--TRIMMABLE-BOUNDARY-END(98786164455)
            
            //--TRIMMABLE-BOUNDARY-START(120261000935)
            /*string?*/ PaymentServiceName = null;
            //--TRIMMABLE-BOUNDARY-END(120261000935)
            
            //--TRIMMABLE-BOUNDARY-START(34361655015)
            /*string?*/ couponCode = null;
            //--TRIMMABLE-BOUNDARY-END(34361655015)
            
            //--TRIMMABLE-BOUNDARY-START(90196229863)
            /*bool*/ isReceipt = false;
            //--TRIMMABLE-BOUNDARY-END(90196229863)
            
            //--TRIMMABLE-BOUNDARY-START(115966033639)
            /*InvoicePaymentMethod*/ payment = 0;
            //--TRIMMABLE-BOUNDARY-END(115966033639)
            
            //--TRIMMABLE-BOUNDARY-START(133145902823)
            /*ElementReference*/ printArea;
            //--TRIMMABLE-BOUNDARY-END(133145902823)
            
            //--TRIMMABLE-BOUNDARY-START(4296883943)
            /*int */ get _payment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951589607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.payment;
            }
            /*int */ set _payment(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735837415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.payment = $.$cast(value, $.$AvdQ.LCFCP.InvoicePaymentMethod);
            }
            //--TRIMMABLE-BOUNDARY-END(4296883943)
            
            //--TRIMMABLE-BOUNDARY-START(171800608487)
            /*void */ ShowReceipt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800608487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.isReceipt = !this.isReceipt;
            }
            //--TRIMMABLE-BOUNDARY-END(171800608487)
            
            //--TRIMMABLE-BOUNDARY-START(124555968231)
            /*Task *//*async*/  PayPart()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555968231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let amt = ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$$.S.Double, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Part payment amount (> ${$.$strNN(this.ViewModel.LCFCP$IInvoiceModel$MinimumPartPayment.ToString())})`, false), null, 0, 0n, null, 0, 4, 4131, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    if (amt < $.$fPer.LCFCDM.Money.op_Implicit(this.ViewModel.LCFCP$IInvoiceModel$MinimumPartPayment))
                    {
                        let $t3, $r3;
                        ($t3 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Message("Error", `Amount must be greater than or equal to ${$.$strNN(this.ViewModel.LCFCP$IInvoiceModel$MinimumPartPayment.ToString())}`, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*var*/ let partPayment = new $.$fPer.LCFCDM.Money().$ctor$3(amt, 1/*MoneyUnitTypes.Naira*/);
                    ($t4 = this.Pay$1($.$clone(partPayment)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124555968231)
            
            //--TRIMMABLE-BOUNDARY-START(111671066343)
            /*Task *//*async*/  Pay$1(/*Money?*/ amount)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671066343);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let now = $.$$.S.DateTime.UtcNow;
                    /*var*/ let paymentResult = ($t5 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment(amount ?? this.ViewModel.LCFCP$IInvoiceModel$Balance, this.ViewModel.LCFCP$IInvoiceModel$InvoiceNumber ?? $.$fPer.LCFCS$6.StringExtension.GetRandomString(16, true, true, false), $.$strNN(this.ViewModel.LCFCP$IInvoiceModel$InvoiceNumber) + $.$strNN((() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 6);
                        $handler.AppendLiteral("/");
                        $handler.AppendFormatted($.$box(now.Year, $.$$.S.Int32), null, "D2");
                        $handler.AppendFormatted($.$box(now.Month, $.$$.S.Int32), null, "D2");
                        $handler.AppendFormatted($.$box(now.Day, $.$$.S.Int32), null, "D2");
                        $handler.AppendFormatted($.$box(now.Hour, $.$$.S.Int32), null, "D2");
                        $handler.AppendFormatted($.$box(now.Minute, $.$$.S.Int32), null, "D2");
                        $handler.AppendFormatted($.$box(now.Second, $.$$.S.Int32), null, "D2");
                        return $handler.ToStringAndClear                ();
                    })()), null, null, null, null, this.ViewModel.LCFCP$IInvoiceModel$InvoiceTo, null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    ($t6 = this.OnPaid.InvokeAsync$1((() =>
                    {
                        //new $.$AvdQ.LCFCP.InvoicePayment()
                        const $t7 = $.$AvdQ.LCFCP.InvoicePayment;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Amount = $.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Discount).op_Implicit(amount ?? this.ViewModel.LCFCP$IInvoiceModel$Balance);
                        $i7.PaymentReference = paymentResult.Reference;
                        return $i7;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111671066343)
            
            //--TRIMMABLE-BOUNDARY-START(107376099047)
            /*Task */ Pay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376099047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pay$1(null);
            }
            //--TRIMMABLE-BOUNDARY-END(107376099047)
            
            //--TRIMMABLE-BOUNDARY-START(25771720423)
            /*Task *//*async*/  ApplyCouponCode()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771720423);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.S.String.IsNullOrEmpty(this.couponCode))
                    {
                        let $t8, $r8;
                        let $t9, $r9;
                        let $t11, $r11;
                        let $t12, $r12;
                        /*var*/ let coupon = ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$Iaui.LCFCM.PaymentCouponModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$22(this.couponCode, null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null), null), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        if (coupon.IsExpired)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("coupon has expired");
                        }
                        /*var*/ let userId = $.$$.S.Guid.Parse$5($.$firstOf(((($t9 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9))))?.Id ?? null), () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Unknown user") }));
                        coupon.UsedBy = (() =>
                        {
                            //new $.$Iaui.LCFCM.UserModel()
                            const $t10 = $.$Iaui.LCFCM.UserModel;
                            const $i10 = new $t10();
                            $i10.$ctor$7();
                            $i10.Identifier = $.$fPer.LCFCD.DataId.op_Implicit(userId);
                            return $i10;
                        })();
                        ($t11 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$Iaui.LCFCM.PaymentCouponModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.PaymentCouponModel), [ coupon ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        ($t12 = this.OnPaid.InvokeAsync$1((() =>
                        {
                            //new $.$AvdQ.LCFCP.InvoicePayment()
                            const $t13 = $.$AvdQ.LCFCP.InvoicePayment;
                            const $i13 = new $t13();
                            $i13.$ctor$2();
                            $i13.Amount = coupon.Rate < 0 ? $.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Discount).op_Implicit$1((() =>
                            {
                                //new $.$fPer.LCFCDM.Discount()
                                const $t14 = $.$fPer.LCFCDM.Discount;
                                const $i14 = new $t14();
                                $i14.$ctor$2();
                                $i14.Rate = coupon.Rate;
                                $i14.Type = 0/*DiscountType.Percentage*/;
                                return $i14;
                            })()) : $.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Discount).op_Implicit(new $.$fPer.LCFCDM.Money().$ctor$3(coupon.Rate, 1/*MoneyUnitTypes.Naira*/));
                            $i13.PaymentReference = coupon.Code;
                            return $i13;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25771720423)
            
            //--TRIMMABLE-BOUNDARY-START(81606295271)
            /*Task */ IhaveTransfered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606295271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(81606295271)
            
            //--TRIMMABLE-BOUNDARY-START(128850935527)
            /*Task *//*async*/  Print()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t15, $r15;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850935527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t15 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.PrintElement(this.JS, this.printArea, null), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128850935527)
            
            //--TRIMMABLE-BOUNDARY-START(30066687719)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066687719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf scroll");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "container clip pd-10");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "row responsive");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "col-7");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "bg-card pd-10");
                __builder.AddElementReferenceCapture(10, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.printArea = __value;
                }, $zfiYUk ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":1916647,"h":0,"f":17825794}));
                __builder.OpenElement(11, "div");
                __builder.AddAttribute$5(12, "class", "container");
                __builder.OpenElement(13, "div");
                __builder.AddAttribute$5(14, "class", "row responsive col-5");
                __builder.OpenElement(15, "h1");
                __builder.AddAttribute$5(16, "class", " miwx-35 cl--primary fsz-80 mg-0 lh-1");
                __builder.AddContent$4(17, this.isReceipt ? "PAYMENT RECEIPT" : "INVOICE");
                __builder.CloseElement();
                __builder.AddMarkupContent(18, "\r\n                            ");
                __builder.OpenElement(19, "div");
                __builder.AddAttribute$5(20, "class", "stack miwx-35");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$5(22, "class", "row");
                __builder.AddMarkupContent(23, "<h2 class=\"col-4 mg-0 cl--primary\">DATE:</h2>\r\n                                    ");
                __builder.OpenElement(24, "h2");
                __builder.AddAttribute$5(25, "class", "col-6 mg-0");
                __builder.AddContent$4(26, this.ViewModel.LCFCP$IInvoiceModel$InvoiceDate.ToString$3("dd MMM, yyyy"));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(27, "\r\n                                ");
                __builder.OpenElement(28, "div");
                __builder.AddAttribute$5(29, "class", "row");
                __builder.AddMarkupContent(30, "<h2 class=\"col-4 mg-0 cl--primary nowrap\">INVOICE NO:</h2>\r\n                                    ");
                __builder.OpenElement(31, "h2");
                __builder.AddAttribute$5(32, "class", "col-6 mg-0");
                __builder.AddContent$4(33, this.ViewModel.LCFCP$IInvoiceModel$InvoiceNumber);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(34, "\r\n\r\n                    ");
                __builder.OpenElement(35, "h1");
                __builder.AddContent$4(36, this.ViewModel.LCFCP$IInvoiceModel$Title);
                __builder.CloseElement();
                if (this.ViewModel.LCFCP$IInvoiceModel$InvoiceTo !== null)
                {
                    __builder.OpenElement(37, "div");
                    __builder.AddAttribute$5(38, "class", "container");
                    __builder.OpenElement(39, "div");
                    __builder.AddAttribute$5(40, "class", "row responsive");
                    __builder.AddMarkupContent(41, "<h1 class=\"col-a cl--primary\">TO:</h1>\r\n                                ");
                    __builder.OpenElement(42, "h1");
                    __builder.AddContent$4(43, this.ViewModel.LCFCP$IInvoiceModel$InvoiceTo.LCFC$INamed$Name);
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                if (this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom !== null)
                {
                    __builder.OpenElement(44, "div");
                    __builder.AddAttribute$5(45, "class", "container mgt");
                    __builder.OpenElement(46, "div");
                    __builder.AddAttribute$5(47, "class", "row responsive col-5");
                    __builder.OpenElement(48, "div");
                    __builder.AddAttribute$5(49, "class", "stack miwx-35");
                    __builder.AddMarkupContent(50, "<h1 class=\"mg-0 cl--primary\">FROM:</h1>\r\n                                    ");
                    __builder.OpenElement(51, "div");
                    __builder.AddAttribute$5(52, "class", "flex");
                    if (this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom.LCFC$IDisplayable$Icon.Icon !== null)
                    {
                        __builder.OpenElement(53, "div");
                        __builder.AddAttribute$5(54, "class", "mgr wx-1 mahx-1");
                        __builder.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 55);
                        __builder.AddComponentParameter(56, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, $.$Iaui.LCFCM.ResourceModel.op_Implicit$1(this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom.LCFC$IDisplayable$Icon)));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    __builder.OpenElement(57, "h1");
                    __builder.AddAttribute$5(58, "class", "mgy-a fsz-45 lh-1");
                    __builder.AddContent$4(59, this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom.LCFC$INamed$Name);
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if ((this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom.LCFCC$2$IContact$Location?.Address ?? null) !== null)
                    {
                        __builder.OpenElement(60, "h3");
                        __builder.AddContent$4(61, (this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom.LCFCC$2$IContact$Location?.Address ?? null));
                        __builder.CloseElement();
                    }
                    if (this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom.LCFCC$2$IContact$Email !== null)
                    {
                        __builder.OpenElement(62, "div");
                        __builder.AddAttribute$5(63, "class", "row mgt");
                        __builder.AddMarkupContent(64, "<h3 class=\"col-4 mg-0 cl--primary nowrap\">EMAIL:</h3>\r\n                                            ");
                        __builder.OpenElement(65, "h3");
                        __builder.AddAttribute$5(66, "class", "col-6 mg-0");
                        __builder.AddContent$4(67, this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom.LCFCC$2$IContact$Email);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                    __builder.AddMarkupContent(68, "\r\n                                ");
                    __builder.OpenElement(69, "div");
                    __builder.AddAttribute$5(70, "class", "stack miwx-35 mgy-a");
                    if (((this.ViewModel.LCFCP$IInvoiceModel$Payment & (1/*InvoicePaymentMethod.BankTransfer*/)) == (1/*InvoicePaymentMethod.BankTransfer*/)) && this.ViewModel.LCFCP$IInvoiceModel$Bank.AccountNumber !== null)
                    {
                        __builder.AddMarkupContent(71, "<h1 class=\"cl--primary\">PAYMENT METHOD</h1>\r\n                                        ");
                        __builder.OpenElement(72, "div");
                        __builder.AddAttribute$5(73, "class", "row");
                        __builder.AddMarkupContent(74, "<h3 class=\"col-4 mg-0 cl--primary\">ACCOUNT NO:</h3>\r\n                                            ");
                        __builder.OpenElement(75, "div");
                        __builder.AddAttribute$5(76, "class", "col-6 stack");
                        __builder.OpenElement(77, "h3");
                        __builder.AddAttribute$5(78, "class", "mg-0");
                        __builder.AddContent$3(79, this.ViewModel.LCFCP$IInvoiceModel$Bank);
                        __builder.CloseElement();
                        __builder.AddMarkupContent(80, "\r\n                                                ");
                        __builder.OpenElement(81, "span");
                        __builder.AddContent$4(82, this.ViewModel.LCFCP$IInvoiceModel$Bank.AccountName);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.OpenElement(83, "div");
                __builder.AddAttribute$5(84, "class", "scroll wf");
                __builder.OpenElement(85, "table");
                __builder.AddAttribute$5(86, "class", "wf mgt-10");
                __builder.OpenElement(87, "thead");
                __builder.AddAttribute$5(88, "class", "bg-primary fw-bold");
                __builder.OpenElement(89, "tr");
                __builder.AddMarkupContent(90, "<td class=\"pd\">DATE</td>\r\n                                    ");
                __builder.AddMarkupContent(91, "<td class=\"pd\">ITEMS</td>\r\n                                    ");
                __builder.AddMarkupContent(92, "<td class=\"pd\">QUANTITY</td>\r\n                                    ");
                __builder.AddMarkupContent(93, "<td class=\"pd\">UNIT PRICE</td>");
                if ($.$sl.SL.Enumerable.Any($.$AvdQ.LCFCP.IInvoiceItem, this.ViewModel.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return c.LCFCP$IInvoiceItem$Discount > 0;
                }, $FKgjCi ??= {"r":262145,"p":[{"n":"c","p":3060672}],"n":"","d":1916647,"h":0,"f":17825794})))
                {
                    __builder.AddMarkupContent(94, "<td class=\"pd\">DISCOUNT</td>");
                }
                __builder.AddMarkupContent(95, "<td class=\"pd\">TOTAL</td>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(96, "\r\n                            ");
                __builder.OpenElement(97, "tbody");
                let $en16 = this.ViewModel.LCFCP$IInvoiceModel$Catalogues.SCG$IEnumerable$$$GetEnumerator();
                while ($en16.SC$1$IEnumerator$MoveNext())
                {
                    let catalog = $en16.SCG$IEnumerator$$$Current;
                    {
                        __builder.OpenElement(98, "tr");
                        __builder.OpenElement(99, "td");
                        __builder.AddAttribute$5(100, "class", "pd");
                        __builder.AddContent$4(101, this.ViewModel.LCFCP$IInvoiceModel$InvoiceDate.ToString$3("yyyy/MM/dd"));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(102, "\r\n                                        ");
                        __builder.OpenElement(103, "td");
                        __builder.AddAttribute$5(104, "class", "pd");
                        __builder.AddContent$4(105, catalog.LCFC$INamed$Name);
                        __builder.CloseElement();
                        __builder.AddMarkupContent(106, "\r\n                                        ");
                        __builder.OpenElement(107, "td");
                        __builder.AddAttribute$5(108, "class", "pd");
                        __builder.AddContent$3(109, $.$box(catalog.LCFCP$IInvoiceItem$Quantity, $.$$.S.Int32));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(110, "\r\n                                        ");
                        __builder.OpenElement(111, "td");
                        __builder.AddAttribute$5(112, "class", "pd");
                        __builder.AddContent$3(113, catalog.LCFCP$IInvoiceItem$Cost);
                        __builder.CloseElement();
                        if ($.$sl.SL.Enumerable.Any($.$AvdQ.LCFCP.IInvoiceItem, this.ViewModel.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                        {
                            return c.LCFCP$IInvoiceItem$Discount > 0;
                        }, $kUNWUb ??= {"r":262145,"p":[{"n":"c","p":3060672}],"n":"","d":1916647,"h":0,"f":17825794})))
                        {
                            __builder.OpenElement(114, "td");
                            __builder.AddAttribute$5(115, "class", "pd");
                            if (catalog.LCFCP$IInvoiceItem$Discount > 0)
                            {
                                __builder.AddContent$4(116, "-");
                                __builder.AddContent$3(117, $.$box(catalog.LCFCP$IInvoiceItem$Discount, $.$$.S.Double));
                                __builder.AddContent$4(118, "%, -");
                                __builder.AddContent$3(119, catalog.LCFCP$IInvoiceItem$DiscountedCost);
                            }
                            __builder.CloseElement();
                        }
                        __builder.OpenElement(120, "td");
                        __builder.AddAttribute$5(121, "class", "pd");
                        __builder.AddContent$3(122, catalog.LCFCP$IInvoiceItem$DiscountedTotal);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(123, "\r\n                            ");
                __builder.OpenElement(124, "tfoot");
                __builder.OpenElement(125, "tr");
                __builder.AddMarkupContent(126, "<td></td>\r\n                                    <td></td>\r\n                                    <td></td>\r\n                                    ");
                __builder.AddMarkupContent(127, "<td class=\"pd fw-bold\">TOTAL</td>");
                if ($.$sl.SL.Enumerable.Any($.$AvdQ.LCFCP.IInvoiceItem, this.ViewModel.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.LCFCP$IInvoiceItem$Discount > 0;
                }, $nfwmbl ??= {"r":262145,"p":[{"n":"c","p":3060672}],"n":"","d":1916647,"h":0,"f":17825794})))
                {
                    __builder.AddMarkupContent(128, "<td></td>");
                }
                __builder.OpenElement(129, "td");
                __builder.AddAttribute$5(130, "class", "pd fw-bold");
                __builder.AddContent$3(131, this.ViewModel.LCFCP$IInvoiceModel$Total);
                __builder.CloseElement();
                __builder.CloseElement();
                if (this.ViewModel.LCFCP$IInvoiceModel$Discount > 0)
                {
                    __builder.OpenElement(132, "tr");
                    __builder.AddMarkupContent(133, "<td></td>\r\n                                        <td></td>\r\n                                        <td></td>\r\n                                        ");
                    __builder.OpenElement(134, "td");
                    __builder.AddAttribute$5(135, "class", "pd fw-bold");
                    __builder.AddContent$4(136, "DISCOUNT (-");
                    __builder.AddContent$3(137, $.$box(this.ViewModel.LCFCP$IInvoiceModel$Discount, $.$$.S.Double));
                    __builder.AddContent$4(138, "%)");
                    __builder.CloseElement();
                    if ($.$sl.SL.Enumerable.Any($.$AvdQ.LCFCP.IInvoiceItem, this.ViewModel.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.LCFCP$IInvoiceItem$Discount > 0;
                    }, $eHKWsj ??= {"r":262145,"p":[{"n":"c","p":3060672}],"n":"","d":1916647,"h":0,"f":17825794})))
                    {
                        __builder.AddMarkupContent(139, "<td></td>");
                    }
                    __builder.OpenElement(140, "td");
                    __builder.AddAttribute$5(141, "class", "pd fw-bold");
                    __builder.AddContent$3(142, this.ViewModel.LCFCP$IInvoiceModel$DiscountCost);
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(143, "\r\n                                    ");
                    __builder.OpenElement(144, "tr");
                    __builder.AddMarkupContent(145, "<td></td>\r\n                                        <td></td>\r\n                                        <td></td>\r\n                                        ");
                    __builder.AddMarkupContent(146, "<td class=\"pd fw-bold\">GRAND TOTAL</td>");
                    if ($.$sl.SL.Enumerable.Any($.$AvdQ.LCFCP.IInvoiceItem, this.ViewModel.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                    {
                        return c.LCFCP$IInvoiceItem$Discount > 0;
                    }, $JhmFmb ??= {"r":262145,"p":[{"n":"c","p":3060672}],"n":"","d":1916647,"h":0,"f":17825794})))
                    {
                        __builder.AddMarkupContent(147, "<td></td>");
                    }
                    __builder.OpenElement(148, "td");
                    __builder.AddAttribute$5(149, "class", "pd fw-bold");
                    __builder.AddContent$3(150, this.ViewModel.LCFCP$IInvoiceModel$TotalDiscounted);
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.IInvoicePayment>?*/ let __ca1__;
                if ((__ca1__ = this.ViewModel.LCFCP$IInvoiceModel$Payments) !== null ? $.$sl.SL.Enumerable.Any$1($.$AvdQ.LCFCP.IInvoicePayment, __ca1__) : false)
                {
                    let $en17 = this.ViewModel.LCFCP$IInvoiceModel$Payments.SCG$IEnumerable$$$GetEnumerator();
                    while ($en17.SC$1$IEnumerator$MoveNext())
                    {
                        let payment = $en17.SCG$IEnumerator$$$Current;
                        {
                            __builder.OpenElement(151, "tr");
                            __builder.AddMarkupContent(152, "<td></td>\r\n                                            <td></td>\r\n                                            <td></td>\r\n                                            ");
                            __builder.OpenElement(153, "td");
                            __builder.AddAttribute$5(154, "class", "pd fw-bold");
                            __builder.AddContent$4(155, "PAID (");
                            __builder.AddContent$4(156, payment.LCFCP$IInvoicePayment$Date.ToString$3("dd MMM, yyyy"));
                            __builder.AddContent$4(157, ")");
                            __builder.CloseElement();
                            if ($.$sl.SL.Enumerable.Any($.$AvdQ.LCFCP.IInvoiceItem, this.ViewModel.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                            {
                                return c.LCFCP$IInvoiceItem$Discount > 0;
                            }, $mhulec ??= {"r":262145,"p":[{"n":"c","p":3060672}],"n":"","d":1916647,"h":0,"f":17825794})))
                            {
                                __builder.AddMarkupContent(158, "<td></td>");
                            }
                            __builder.OpenElement(159, "td");
                            __builder.AddAttribute$5(160, "class", "pd fw-bold");
                            __builder.AddContent$3(161, payment.LCFCP$IInvoicePayment$Amount);
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                    __builder.OpenElement(162, "tr");
                    __builder.AddMarkupContent(163, "<td></td>\r\n                                        <td></td>\r\n                                        <td></td>\r\n                                        ");
                    __builder.AddMarkupContent(164, "<td class=\"pd fw-bold\">BALANCE</td>");
                    if ($.$sl.SL.Enumerable.Any($.$AvdQ.LCFCP.IInvoiceItem, this.ViewModel.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.LCFCP$IInvoiceItem$Discount > 0;
                    }, $ZaErCa ??= {"r":262145,"p":[{"n":"c","p":3060672}],"n":"","d":1916647,"h":0,"f":17825794})))
                    {
                        __builder.AddMarkupContent(165, "<td></td>");
                    }
                    __builder.OpenElement(166, "td");
                    __builder.AddAttribute$5(167, "class", "pd fw-bold");
                    __builder.AddContent$3(168, this.ViewModel.LCFCP$IInvoiceModel$Balance);
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(169, "\r\n                ");
                __builder.OpenElement(170, "div");
                __builder.AddAttribute$5(171, "class", "mgt text-right");
                __builder.OpenElement(172, "button");
                __builder.AddAttribute$5(173, "class", "bg-primary pd fw-bold miwx-1");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 174, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Print)));
                __builder.AddContent$4(175, "PRINT ");
                __builder.AddContent$4(176, this.isReceipt ? "RECEIPT" : "INVOICE");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(177, "\r\n            ");
                __builder.OpenElement(178, "div");
                __builder.AddAttribute$5(179, "class", "col-3 miwx-3");
                if ($.$fPer.LCFCDM.Money.op_Implicit(this.ViewModel.LCFCP$IInvoiceModel$Balance) > 0)
                {
                    if (this.ViewModel.LCFCP$IInvoiceModel$Payment !== 0/*InvoicePaymentMethod.None*/ && this.OnPaid.HasDelegate)
                    {
                        __builder.OpenElement(180, "div");
                        __builder.AddAttribute$5(181, "class", "bg-card pd-10");
                        __builder.OpenElement(182, "div");
                        __builder.AddAttribute$5(183, "class", "flex");
                        __builder.OpenElement(184, "h3");
                        __builder.AddAttribute$5(185, "class", "mg-0 fill");
                        __builder.AddContent$4(186, "PAY ");
                        __builder.AddContent$3(187, this.ViewModel.LCFCP$IInvoiceModel$Balance);
                        __builder.AddContent$4(188, " WITH");
                        __builder.CloseElement();
                        if (this.ViewModel.LCFCP$IInvoiceModel$MinimumPartPayment !== null && ((this.ViewModel.LCFCP$IInvoiceModel$Payment & (2/*InvoicePaymentMethod.MasterCard*/)) == (2/*InvoicePaymentMethod.MasterCard*/)))
                        {
                            __builder.OpenElement(189, "button");
                            __builder.AddAttribute$5(190, "class", "bg-primary corner");
                            __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 191, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.PayPart)));
                            __builder.AddContent$4(192, "Pay Part");
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                        __builder.AddMarkupContent(193, "\r\n                            ");
                        __builder.OpenElement(194, "select");
                        __builder.AddAttribute$5(195, "class", "pd bd wf mgt");
                        __builder.AddAttribute$5(196, "value", $.$mac.MAC.BindConverter.FormatValue$10(this._payment, null));
                        __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 197, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$10($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this._payment = __value;
                        }, $oFWtrf ??= {"r":65537,"p":[{"n":"__value","p":655361}],"n":"","d":1916647,"h":0,"f":17825794}), this._payment, null));
                        __builder.SetUpdatesAttributeName("value");
                        __builder.OpenElement(198, "option");
                        __builder.AddAttribute$5(199, "class", "pd");
                        __builder.AddAttribute$5(200, "value", "0");
                        __builder.AddContent$4(201, "--Select Payment Method--");
                        __builder.CloseElement();
                        let $i18 = 0;
                        let $arr18 = $.$$.S.Enum.GetValues$1($.$AvdQ.LCFCP.InvoicePaymentMethod);
                        while ($i18 < $arr18.length)
                        {
                            let method = $arr18[$i18++];
                            if (method === 0/*InvoicePaymentMethod.None*/)
                            {
                                continue;
                            }
                            if (method === 1/*InvoicePaymentMethod.BankTransfer*/ && this.ViewModel.LCFCP$IInvoiceModel$Bank.AccountNumber === null)
                            {
                                continue;
                            }
                            if (method === 2/*InvoicePaymentMethod.MasterCard*/ && this.PaymentServiceName === null)
                            {
                                continue;
                            }
                            __builder.OpenElement(202, "option");
                            __builder.AddAttribute$5(203, "class", "pd");
                            __builder.AddAttribute$4(204, "value", $.$box(method, $.$$.S.Int32));
                            __builder.AddContent$4(205, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$AvdQ.LCFCP.InvoicePaymentMethod, $.$$.S.UInt32, method)));
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                        if (this.payment === 1/*InvoicePaymentMethod.BankTransfer*/)
                        {
                            __builder.OpenElement(206, "p");
                            __builder.AddMarkupContent(207, "\r\n                                    If you have paid already via bank transfer,\r\n                                    wait for ");
                            __builder.AddContent$4(208, (this.ViewModel.LCFCP$IInvoiceModel$InvoiceFrom?.LCFC$INamed$Name ?? null) ?? "them");
                            __builder.AddMarkupContent(209, " to confirm your payment and print the\r\n                                    receipt.\r\n                                ");
                            __builder.CloseElement();
                        }
                        else if (this.payment === 2/*InvoicePaymentMethod.MasterCard*/)
                        {
                            __builder.OpenElement(210, "button");
                            __builder.AddAttribute$5(211, "class", "mgt wf bg-primary pd fw-bold fsz-25");
                            __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 212, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Pay)));
                            __builder.AddContent$4(213, "PAY");
                            __builder.CloseElement();
                        }
                        else if (this.payment === 4/*InvoicePaymentMethod.Coupon*/)
                        {
                            __builder.AddMarkupContent(214, "<b class=\"d-block mgt\">Apply Coupon Code</b>\r\n                                ");
                            __builder.OpenElement(215, "div");
                            __builder.AddAttribute$5(216, "class", "flex");
                            __builder.OpenElement(217, "input");
                            __builder.AddAttribute$5(218, "type", "text");
                            __builder.AddAttribute$5(219, "class", "pd bd-0 fill");
                            __builder.AddAttribute$5(220, "placeholder", "Coupon code");
                            __builder.AddAttribute$5(221, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.couponCode, null));
                            __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 222, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return this.couponCode = __value;
                            }, $wRRQBd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1916647,"h":0,"f":17825794}), this.couponCode, null));
                            __builder.SetUpdatesAttributeName("value");
                            __builder.CloseElement();
                            __builder.AddMarkupContent(223, "\r\n                                    ");
                            __builder.OpenElement(224, "button");
                            __builder.AddAttribute$5(225, "class", "mgl wf bg-primary pd fw-bold fsz-25");
                            __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 226, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ApplyCouponCode)));
                            __builder.AddContent$4(227, "Apply");
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                    }
                }
                else 
                {
                    __builder.OpenElement(228, "div");
                    __builder.AddAttribute$5(229, "class", "bg-card pd stack");
                    __builder.AddMarkupContent(230, "<i class=\"mdi mdi-check-circle fsz-100 cl-success mg-a\"></i>\r\n                        ");
                    __builder.AddMarkupContent(231, "<h1 class=\"cl-success text-center mg-0\">PAID</h1>\r\n                        ");
                    __builder.OpenElement(232, "button");
                    __builder.AddAttribute$5(233, "class", "mgt wf bg-success pd fw-bold fsz-25");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 234, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ShowReceipt)));
                    __builder.AddContent$4(235, "VIEW RECEIPT");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(30066687719)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21476753127)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476753127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476753127)
            
            //--TRIMMABLE-BOUNDARY-START(21476753127)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(21476753127)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94491197159)
                this.JS = null;
                //--TRIMMABLE-BOUNDARY-END(94491197159)
                
                //--TRIMMABLE-BOUNDARY-START(98786164455)
                this.OnPaid = $.$default($.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.InvoicePayment));
                //--TRIMMABLE-BOUNDARY-END(98786164455)
                
                //--TRIMMABLE-BOUNDARY-START(133145902823)
                this.printArea = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(133145902823)
                
            }
            static $h = 1916647;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$AvdQ.LCFCP.IInvoiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103081131751),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721393383,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1916647,
      "h": 103081131751,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103081131751),
//--TRIMMABLE-BOUNDARY-START(94491197159),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541524199,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325772007,
        "f": 83886081
      },
      "n": "JS",
      "d": 1916647,
      "h": 94491197159,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94491197159),
//--TRIMMABLE-BOUNDARY-START(98786164455),
    {
      "p": $.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.InvoicePayment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131458791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915706599,
        "f": 83886081
      },
      "n": "OnPaid",
      "d": 1916647,
      "h": 98786164455,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98786164455),
//--TRIMMABLE-BOUNDARY-START(120261000935),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311327975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505641191,
        "f": 83886081
      },
      "n": "PaymentServiceName",
      "d": 1916647,
      "h": 120261000935,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261000935),
//--TRIMMABLE-BOUNDARY-START(4296883943),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951589607,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735837415,
        "f": 83886082
      },
      "n": "_payment",
      "d": 1916647,
      "h": 4296883943,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4296883943)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176095575783),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1916647,
      "h": 176095575783,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176095575783),
//--TRIMMABLE-BOUNDARY-START(85901262567),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1916647,
      "h": 85901262567,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901262567),
//--TRIMMABLE-BOUNDARY-START(171800608487),
    {
      "r": 65537,
      "n": "ShowReceipt",
      "d": 1916647,
      "h": 171800608487,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171800608487),
//--TRIMMABLE-BOUNDARY-START(124555968231),
    {
      "r": 178454529,
      "n": "PayPart",
      "d": 1916647,
      "h": 124555968231,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(124555968231),
//--TRIMMABLE-BOUNDARY-START(111671066343),
    {
      "r": 178454529,
      "p": [
        {
          "n": "amount",
          "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h
        }
      ],
      "n": "Pay",
      "o": "@$1",
      "d": 1916647,
      "h": 111671066343,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(111671066343),
//--TRIMMABLE-BOUNDARY-START(107376099047),
    {
      "r": 178454529,
      "n": "Pay",
      "d": 1916647,
      "h": 107376099047,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107376099047),
//--TRIMMABLE-BOUNDARY-START(25771720423),
    {
      "r": 178454529,
      "n": "ApplyCouponCode",
      "d": 1916647,
      "h": 25771720423,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25771720423),
//--TRIMMABLE-BOUNDARY-START(81606295271),
    {
      "r": 178454529,
      "n": "IhaveTransfered",
      "d": 1916647,
      "h": 81606295271,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81606295271),
//--TRIMMABLE-BOUNDARY-START(128850935527),
    {
      "r": 178454529,
      "n": "Print",
      "d": 1916647,
      "h": 128850935527,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(128850935527),
//--TRIMMABLE-BOUNDARY-START(30066687719),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1916647,
      "h": 30066687719,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30066687719)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361655015),
    {
      "t": 1310721,
      "n": "couponCode",
      "d": 1916647,
      "h": 34361655015,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361655015),
//--TRIMMABLE-BOUNDARY-START(90196229863),
    {
      "t": 262145,
      "n": "isReceipt",
      "d": 1916647,
      "h": 90196229863,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90196229863),
//--TRIMMABLE-BOUNDARY-START(115966033639),
    {
      "t": 3912640,
      "n": "payment",
      "d": 1916647,
      "h": 115966033639,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115966033639),
//--TRIMMABLE-BOUNDARY-START(133145902823),
    {
      "t": 1900659,
      "n": "printArea",
      "d": 1916647,
      "h": 133145902823,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133145902823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476753127),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1916647,
      "h": 21476753127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476753127)
  ],
  "h": 1916647
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.InvoiceReceipt`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}InvoiceReceipt`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1916647)
        
        

        //--TRIMMABLE-BOUNDARY-START(2113255)
        $asm.$cls(`$dgLE.LCPCS$1.ServiceMenuSelector`, ($self) => class ServiceMenuSelector extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$vWqU.LCFCC.IServiceSubscriptionViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(30066884327)
            /*ServiceMenuSelectorFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(30066884327)
            
            //--TRIMMABLE-BOUNDARY-START(25771917031)
            /*IDataEnumerableController<IUserServiceSubscriptionModel<IServiceDataModel>>?*/ Controller = null;
            //--TRIMMABLE-BOUNDARY-END(25771917031)
            
            //--TRIMMABLE-BOUNDARY-START(73016557287)
            /*EventCallback<IUserServiceSubscriptionModel<IServiceDataModel>>*/ OnSelected;
            //--TRIMMABLE-BOUNDARY-END(73016557287)
            
            //--TRIMMABLE-BOUNDARY-START(68721589991)
            /*ValueTask<bool> *//*async*/  [`LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Models$IUserServiceSubscriptionModel$LivingThing$Core$Frameworks$Common$Data$IServiceDataModel$$OnSelected`](/*DataListSelection<IUserServiceSubscriptionModel<IServiceDataModel>>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721589991);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.OnSelected.InvokeAsync$1(selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68721589991)
            
            //--TRIMMABLE-BOUNDARY-START(77311524583)
            /*string */ get OptimizedComponentName()
            {
                return "servicemenuselector";
            }
            //--TRIMMABLE-BOUNDARY-END(77311524583)
            
            //--TRIMMABLE-BOUNDARY-START(107376295655)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376295655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "Features":
                    this.Features = $.$cast(parameter.Value, $.$dgLE.LCPCS$1.ServiceMenuSelectorFeatures);
                    return true;
                    case "Controller":
                    this.Controller = $.$cast(parameter.Value, $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)));
                    return true;
                    case "OnSelected":
                    this.OnSelected = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(107376295655)
            
            //--TRIMMABLE-BOUNDARY-START(21476949735)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476949735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(this.OwnAttributes(null))));
                if ($.$sl.SL.Enumerable.Any($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel), this.ViewModel.LCFCC$IServiceSubscriptionViewModel$Subscriptions, new ($.$$.S.Func$$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel), $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    /*LivingThing.Core.Frameworks.Common.Data.IServiceDataModel?*/ let __ca1__;
                    return $.$$.S.Int32.op_LessThan(((__ca1__ = s.LCFCM$IUserServiceSubscriptionModel$$$Service) !== null ? $.$fPer.LCFCD.ServiceExtension.ExpireDays(__ca1__) : null), 30);
                }, $tKmQZi ??= {"r":262145,"p":[{"n":"s","p":$.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel).$h}],"n":"","d":2113255,"h":0,"f":17825794})))
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCA$1.Alert, 2);
                    __builder.AddComponentParameter(3, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfFatal(0.1)));
                    __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCA$1.AlertFeatures, 2/*AlertFeatures.Default*/ | 1/*AlertFeatures.Closable*/), $.$hDPm.LCFCCA$1.AlertFeatures));
                    __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(6, "\r\n            Some services are expiring soon. Renew them to keep them working.\r\n        ");
                    }), $BMhyxj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2113255,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                $.$dgLE._LCPCSS.TypeInference.CreateDataList_0($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel), __builder, 7, 8, this.ViewModel.LCFCC$IServiceSubscriptionViewModel$Subscriptions, 9, this.Controller ?? this, 10, $.$fPer.LCFC.Theme.Primary, 11, 35184372092928n | 65536n | 8388608n | (((this.Features & (1/*ServiceMenuSelectorFeatures.Search*/)) == (1/*ServiceMenuSelectorFeatures.Search*/)) ? 8n : 0n), 12, this.AttributesFor("datalist"), 13, 250, 14, 20, 15, "Services", 16, `pdx-2 pdy ${$.$strNN($.$dspc(this.ValueFor("li-class"), $.$$.S.Object, ($t) => $t.ToString))}`, 17, "bg-primary-01 mawx-4 mgx-a mgb", 18, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)))))().$ctor(this,  (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(19, "div");
                        __builder2.AddAttribute$5(20, "class", "flex");
                        __builder2.AddAttribute$5(21, "href", (context.Data.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFCD$IServiceDataModel$ServiceLink ?? null) ?? (context.Data.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFCD$IComponentDataModel$Link ?? null) ?? "#");
                        __builder2.OpenElement(22, "div");
                        __builder2.AddAttribute$5(23, "class", "wx-04 hx-04 round clip mgy-a bd");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 24);
                        __builder2.AddComponentParameter(25, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, $.$cast((context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFCD$IServiceDataModel$Icon ?? null), $.$Iaui.LCFCM.ResourceModel)));
                        __builder2.AddComponentParameter(26, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), true), $.$$.S.Boolean));
                        __builder2.AddComponentParameter(27, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                        __builder2.AddComponentParameter(28, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                        __builder2.AddComponentParameter(29, "Class", "round");
                        __builder2.AddComponentParameter(30, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(31, "\r\n            ");
                        __builder2.OpenElement(32, "div");
                        __builder2.AddAttribute$5(33, "class", "fill mgl-2");
                        __builder2.OpenElement(34, "h4");
                        __builder2.AddAttribute$5(35, "class", "mg-0");
                        __builder2.AddContent$4(36, (context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFC$IDisplayable$Title ?? null));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(37, "\r\n                ");
                        __builder2.OpenElement(38, "small");
                        __builder2.AddAttribute$5(39, "class", "op-9");
                        __builder2.AddContent$4(40, (context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFC$IDescribable$Description ?? null));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(41, "\r\n                ");
                        __builder2.OpenElement(42, "div");
                        __builder2.AddAttribute$5(43, "class", "flex mgt-2");
                        __builder2.OpenElement(44, "div");
                        __builder2.AddAttribute$5(45, "class", "fsz-10 op-9 mgy-a bg-success corner-5 pdx-2 pdy-1");
                        __builder2.AddContent$4(46, (((context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFCD$IServiceDataModel$RenewDate ?? null) ?? (context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFCD$IEntryDataModel$DateCreated ?? null))?.ToString$3("MMM, yyyy") ?? null));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(47, "\r\n                    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 48);
                        /*LivingThing.Core.Frameworks.Common.Data.IServiceDataModel?*/ let __ca2__;
                        __builder2.AddComponentParameter(49, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.$cast((((__ca2__ = context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service) !== null ? ($.$fPer.LCFCD.ServiceExtension.Usage(__ca2__) ?? 0) : 0)), $.$$.S.Int32)), $.$$.S.Int32));
                        __builder2.AddComponentParameter(50, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfDark(0.5)));
                        __builder2.AddComponentParameter(51, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(52, "Class", "fill mgy-a mgl corner-3 clip");
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(53, "\r\n                    ");
                        __builder2.OpenElement(54, "div");
                        __builder2.AddAttribute$5(55, "class", "fsz-10 op-9 mgy-a bg-error corner-5 pdx-2 pdy-1");
                        __builder2.AddContent$4(56, (context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFCD$IServiceDataModel$ExpiryDate?.ToString$3("MMM, yyyy") ?? null));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        if ((context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service?.LCFCD$IServiceDataModel$Contents ?? null) !== null)
                        {
                            __builder2.OpenElement(57, "div");
                            __builder2.AddAttribute$5(58, "class", "flex mgt-2");
                            let $en3 = context.Model.LCFCM$IUserServiceSubscriptionModel$$$Service.LCFCD$IServiceDataModel$Contents.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let g = $en3.SCG$IEnumerator$$$Current;
                                {
                                    __builder2.OpenElement(59, "div");
                                    __builder2.AddAttribute$5(60, "class", "bg-primary corner-5 fsz-10 pdx-2 pdy-1 mgr");
                                    __builder2.AddContent$3(61, $.$box($.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD.IEntityDataModel, g), $.$$.S.Int32));
                                    __builder2.AddContent$4(62, " ");
                                    __builder2.AddContent$4(63, g.SL$IGrouping$$$$Key);
                                    __builder2.CloseElement();
                                }
                            }
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $dOMHKj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2113255,"h":0,"f":17825794});
                }, $VSnlGg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel))).$h}],"n":"","d":2113255,"h":0,"f":17825794}));
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21476949735)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181982439)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181982439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181982439)
            
            //--TRIMMABLE-BOUNDARY-START(17181982439)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17181982439)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30066884327)
                this.Features = 0;
                //--TRIMMABLE-BOUNDARY-END(30066884327)
                
                //--TRIMMABLE-BOUNDARY-START(73016557287)
                this.OnSelected = $.$default($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)));
                //--TRIMMABLE-BOUNDARY-END(73016557287)
                
            }
            static $h = 2113255;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$vWqU.LCFCC.IServiceSubscriptionViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066884327),
    {
      "p": 2178791,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246753511,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491393767,
        "f": 83886081
      },
      "n": "Features",
      "d": 2113255,
      "h": 30066884327,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066884327),
//--TRIMMABLE-BOUNDARY-START(25771917031),
    {
      "p": $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656818919,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901459175,
        "f": 83886081
      },
      "n": "Controller",
      "d": 2113255,
      "h": 25771917031,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771917031),
//--TRIMMABLE-BOUNDARY-START(73016557287),
    {
      "p": $.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836688103,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081328359,
        "f": 83886081
      },
      "n": "OnSelected",
      "d": 2113255,
      "h": 73016557287,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016557287),
//--TRIMMABLE-BOUNDARY-START(77311524583),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426622695,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2113255,
      "h": 77311524583,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77311524583)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107376295655),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2113255,
      "h": 107376295655,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107376295655),
//--TRIMMABLE-BOUNDARY-START(21476949735),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2113255,
      "h": 21476949735,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476949735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181982439),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2113255,
      "h": 17181982439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181982439)
  ],
  "h": 2113255
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$($.$fPer.LCFCD.IServiceDataModel)), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ServiceMenuSelector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceMenuSelector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2113255)
        
        

        //--TRIMMABLE-BOUNDARY-START(2637543)
        $asm.$cls(`$dgLE.LCPCV.ServiceSignupViewModel<,,,,>`, (TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType) => $asm.$gt(`$dgLE.LCPCV.ServiceSignupViewModel<,,,,>`, [TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType], ($self) => class ServiceSignupViewModel$$$$$$ extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(42952310503)
            $ctor$3(/*IAuthenticationService*/ authorizationManager, /*IServerRemoteService*/ remoteServer, /*ICatalogueProvider<TServiceTierType, TServiceFeatureType>*/ provider, /*Func<TServiceModel, Task>*/ onCreated, /*Action<TServiceModel, ServiceSubscriptionModel<TServiceTierType, TServiceFeatureType>>?*/ initialize, /*TServiceModel?*/ service)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952310503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AuthorizationManager = authorizationManager;
                    this.Server = remoteServer;
                    this.provider = provider;
                    this.onCreated = onCreated;
                    this.initialize = initialize;
                    this.Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952310503)
            
            //--TRIMMABLE-BOUNDARY-START(146031525607)
            /*Func<TServiceModel, Task>*/ onCreated = null;
            //--TRIMMABLE-BOUNDARY-END(146031525607)
            
            //--TRIMMABLE-BOUNDARY-START(137441591015)
            /*Action<TServiceModel, ServiceSubscriptionModel<TServiceTierType, TServiceFeatureType>>?*/ initialize = null;
            //--TRIMMABLE-BOUNDARY-END(137441591015)
            
            //--TRIMMABLE-BOUNDARY-START(154621460199)
            /*ICatalogueProvider<TServiceTierType, TServiceFeatureType>*/ provider = null;
            //--TRIMMABLE-BOUNDARY-END(154621460199)
            
            //--TRIMMABLE-BOUNDARY-START(249110740711)
            /*IEnumerable<ServiceTierModel<TServiceTierType, TServiceFeatureType>>?*/ Tiers = null;
            //--TRIMMABLE-BOUNDARY-END(249110740711)
            
            //--TRIMMABLE-BOUNDARY-START(244815773415)
            /*ServiceSubscriptionModel<TServiceTierType, TServiceFeatureType>?*/ Subscription = null;
            //--TRIMMABLE-BOUNDARY-END(244815773415)
            
            //--TRIMMABLE-BOUNDARY-START(158916427495)
            /*void */ SelectTier(/*ServiceTierModel<TServiceTierType, TServiceFeatureType>*/ tier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916427495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Subscription = (() =>
                {
                    //new $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)()
                    const $t1 = $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType);
                    const $i1 = new $t1();
                    $i1.$ctor$1(this.provider.LCFC$INamed$Name, this.ServiceName ?? this.provider.LCFC$INamed$Name, tier);
                    $i1.Service = $.$box(this.Service, TServiceModel);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(158916427495)
            
            //--TRIMMABLE-BOUNDARY-START(171801329383)
            /*string?*/ ServiceName = null;
            //--TRIMMABLE-BOUNDARY-END(171801329383)
            
            //--TRIMMABLE-BOUNDARY-START(55837212391)
            /*string?*/ ErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(55837212391)
            
            //--TRIMMABLE-BOUNDARY-START(167506362087)
            /*TServiceModel?*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(167506362087)
            
            //--TRIMMABLE-BOUNDARY-START(141736558311)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141736558311);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Tiers = (($t2 = this.provider.LCFCP$ICatalogueProvider$$$$ServiceTiers.Invoke($.$fPer.LCFCD.DataFilter.Default), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).Data ?? $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType));
                    ($t3 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(141736558311)
            
            //--TRIMMABLE-BOUNDARY-START(150326492903)
            /*Task *//*async*/  Paid(/*string*/ referenceNumber, /*PaymentModel?*/ payment)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150326492903);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t7, $r7;
                            let $t8, $r8;
                            /*var*/ let serviceModel = this.Service ?? new TServiceModel().$gctor();
                            /*var*/ let dynamicService = (serviceModel);
                            if (this.initialize === null)
                            {
                                dynamicService.Name = serviceModel.LCFC$INamed$Name ?? this.ServiceName ?? this.Subscription.ServiceName;
                                dynamicService.Limits = this.Subscription.Limits;
                                dynamicService.ServiceTier = this.Subscription.Tier.ServiceType;
                                dynamicService.ExpiryDate = this.Subscription.Expiry;
                                dynamicService.RenewDate = $.$$.S.DateTime.UtcNow;
                            }
                            else 
                            {
                                this.initialize.Invoke(serviceModel, this.Subscription);
                            }
                            dynamicService.Payment = payment;
                            if (serviceModel.LCFCD$IIded$Identifier.Empty)
                            {
                                let $t5, $r5;
                                /*var*/ let model = ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create(TServiceModel, this.Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(TServiceModel), [ serviceModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                this.Service = $.$sl.SL.Enumerable.First$1(TServiceModel, model.Data);
                            }
                            else 
                            {
                                let $t6, $r6;
                                /*var*/ let model = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update(TServiceModel, this.Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(TServiceModel), [ serviceModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                this.Service = $.$sl.SL.Enumerable.First$1(TServiceModel, model.Data);
                            }
                            ($t7 = this.onCreated.Invoke(this.Service), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            ($t8 = this.wizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        });
                    }, $Zrywrf ??= {"r":181338113,"n":"","d":this.$h,"H":0,"h":0,"f":17829890}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150326492903)
            
            //--TRIMMABLE-BOUNDARY-START(47247277799)
            /*IAuthenticationService*/ AuthorizationManager = null;
            //--TRIMMABLE-BOUNDARY-END(47247277799)
            
            //--TRIMMABLE-BOUNDARY-START(163211394791)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(163211394791)
            
            //--TRIMMABLE-BOUNDARY-START(253405708007)
            /*DecodedAuthenticationTicket?*/ UserToken = null;
            //--TRIMMABLE-BOUNDARY-END(253405708007)
            
            //--TRIMMABLE-BOUNDARY-START(257700675303)
            /*WizardSteps?*/ wizard = null;
            //--TRIMMABLE-BOUNDARY-END(257700675303)
            
            //--TRIMMABLE-BOUNDARY-START(51542245095)
            /*int*/ CurrentStep = 0;
            //--TRIMMABLE-BOUNDARY-END(51542245095)
            
            //--TRIMMABLE-BOUNDARY-START(261995642599)
            /*Task *//*async*/  WizardStep(/*ViewChangingEventArgs*/ args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261995642599);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.wizard = $.$as(args.Sender, $.$hDPm.LCFCCW$1.WizardSteps);
                    let $switch9 = args.To;
                    switch($switch9)
                    {
                        case 1:
                        {
                            let $t10, $r10;
                            if ((this.Subscription?.Tier ?? null) === null)
                            {
                                throw new $.$$.S.Exception().$ctor$4("Must Select a Tier to Proceed");
                            }
                            /*var*/ let logged = ($t10 = this.AuthorizationManager.LCFCA$IReadOnlyAuthenticationService$GetIsLoggedIn(), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                            if (logged)
                            {
                                args.To = 2;
                            }
                        }
                        break;
                        case 3:
                        {
                            let $t11, $r11;
                            let $t12, $r12;
                            /*var*/ let logged = ($t11 = this.AuthorizationManager.LCFCA$IReadOnlyAuthenticationService$GetIsLoggedIn(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                            if (!logged)
                            {
                                throw new $.$$.S.Exception().$ctor$4("Please login to continue");
                            }
                            this.UserToken = ($t12 = this.AuthorizationManager.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        }
                        break;
                    }
                    this.CurrentStep = args.To;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(261995642599)
            
            static $H = 2637543;
            static $h = 2637543;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(249110740711),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124556689127,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 231930871527,
        "h": Number(BigInt(this.$h)|0x3600000000n),
        "f": 83886082
      },
      "n": "Tiers",
      "d": this.$h,
      "H": 249110740711,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249110740711),
//--TRIMMABLE-BOUNDARY-START(244815773415),
    {
      "p": $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115966754535,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 223340936935,
        "h": Number(BigInt(this.$h)|0x3400000000n),
        "f": 83886081
      },
      "n": "Subscription",
      "d": this.$h,
      "H": 244815773415,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244815773415),
//--TRIMMABLE-BOUNDARY-START(171801329383),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107376819943,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 214751002343,
        "h": Number(BigInt(this.$h)|0x3200000000n),
        "f": 83886081
      },
      "n": "ServiceName",
      "d": this.$h,
      "H": 171801329383,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171801329383),
//--TRIMMABLE-BOUNDARY-START(55837212391),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81607016167,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 188981198567,
        "h": Number(BigInt(this.$h)|0x2C00000000n),
        "f": 83886081
      },
      "n": "ErrorMessage",
      "d": this.$h,
      "H": 55837212391,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837212391),
//--TRIMMABLE-BOUNDARY-START(167506362087),
    {
      "p": TServiceModel?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98786885351,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 206161067751,
        "h": Number(BigInt(this.$h)|0x3000000000n),
        "f": 83886082
      },
      "n": "Service",
      "d": this.$h,
      "H": 167506362087,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167506362087),
//--TRIMMABLE-BOUNDARY-START(47247277799),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64427146983,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "AuthorizationManager",
      "d": this.$h,
      "H": 47247277799,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247277799),
//--TRIMMABLE-BOUNDARY-START(163211394791),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90196950759,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 197571133159,
        "h": Number(BigInt(this.$h)|0x2E00000000n),
        "f": 83886081
      },
      "n": "Server",
      "d": this.$h,
      "H": 163211394791,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163211394791),
//--TRIMMABLE-BOUNDARY-START(253405708007),
    {
      "p": 1130882,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133146623719,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 240520806119,
        "h": Number(BigInt(this.$h)|0x3800000000n),
        "f": 83886081
      },
      "n": "UserToken",
      "d": this.$h,
      "H": 253405708007,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253405708007),
//--TRIMMABLE-BOUNDARY-START(51542245095),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73017081575,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 180391263975,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 83886081
      },
      "n": "CurrentStep",
      "d": this.$h,
      "H": 51542245095,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542245095)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158916427495),
    {
      "r": 65537,
      "p": [
        {
          "n": "tier",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h
        }
      ],
      "n": "SelectTier",
      "d": this.$h,
      "H": 158916427495,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158916427495),
//--TRIMMABLE-BOUNDARY-START(141736558311),
    {
      "r": 181338113,
      "n": "Load",
      "d": this.$h,
      "H": 141736558311,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(141736558311),
//--TRIMMABLE-BOUNDARY-START(150326492903),
    {
      "r": 178454529,
      "p": [
        {
          "n": "referenceNumber",
          "p": 1310721
        },
        {
          "n": "payment",
          "p": 12592470
        }
      ],
      "n": "Paid",
      "d": this.$h,
      "H": 150326492903,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(150326492903),
//--TRIMMABLE-BOUNDARY-START(261995642599),
    {
      "r": 178454529,
      "p": [
        {
          "n": "args",
          "p": 38098602
        }
      ],
      "n": "WizardStep",
      "d": this.$h,
      "H": 261995642599,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(261995642599)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(146031525607),
    {
      "t": $.$$.S.Func$$$(TServiceModel, $.$$.STT.Task).$h,
      "n": "onCreated",
      "d": this.$h,
      "H": 146031525607,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(146031525607),
//--TRIMMABLE-BOUNDARY-START(137441591015),
    {
      "t": $.$$.S.Action$$$(TServiceModel, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "n": "initialize",
      "d": this.$h,
      "H": 137441591015,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137441591015),
//--TRIMMABLE-BOUNDARY-START(154621460199),
    {
      "t": $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType).$h,
      "n": "provider",
      "d": this.$h,
      "H": 154621460199,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154621460199),
//--TRIMMABLE-BOUNDARY-START(257700675303),
    {
      "t": 59004586,
      "n": "wizard",
      "d": this.$h,
      "H": 257700675303,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(257700675303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42952310503),
    {
      "p": [
        {
          "n": "authorizationManager",
          "p": 1655170
        },
        {
          "n": "remoteServer",
          "p": 1309651
        },
        {
          "n": "provider",
          "p": $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType).$h
        },
        {
          "n": "onCreated",
          "p": $.$$.S.Func$$$(TServiceModel, $.$$.STT.Task).$h
        },
        {
          "n": "initialize",
          "p": $.$$.S.Action$$$(TServiceModel, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)).$h
        },
        {
          "n": "service",
          "p": TServiceModel?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 42952310503,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952310503)
  ],
  "s": [
    {
      "h": TServiceModel?.$h??1572864,
      "n": "TServiceModel",
      "f": 4,
      "c": [$.$fPer.LCFCD.IServiceDataModel$$(TServiceTierType).$h
      ]
    },
    {
      "h": TServiceSettings?.$h??1638400,
      "n": "TServiceSettings",
      "f": 4,
      "c": [20456790
      ]
    },
    {
      "h": TServiceStates?.$h??1703936,
      "n": "TServiceStates",
      "f": 4,
      "c": [22422870
      ]
    },
    {
      "h": TServiceTierType?.$h??1769472,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1835008,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 5,
  "H": 2637543,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSignupViewModel<${TServiceModel?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ViewModels${separator}ServiceSignupViewModel$${TServiceModel?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2637543)
        
        

        //--TRIMMABLE-BOUNDARY-START(1195751)
        $asm.$cls(`$dgLE.LCPCSG.AppServiceGuard<,,,,>`, (TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType) => $asm.$gt(`$dgLE.LCPCSG.AppServiceGuard<,,,,>`, [TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType], ($self) => class AppServiceGuard$$$$$$ extends $.$hDPm.LCFCC$1.BaseModelContainer$$($.$dgLE.LCPCSG.AppServiceGuardContext)
        {
            //--TRIMMABLE-BOUNDARY-START(219044527847)
            /*string */ get OptimizedComponentName()
            {
                return "appserviceguard";
            }
            //--TRIMMABLE-BOUNDARY-END(219044527847)
            
            //--TRIMMABLE-BOUNDARY-START(309238841063)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238841063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "PageRoute":
                    this.PageRoute = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "DefaultHandle":
                    this.DefaultHandle = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Features":
                    this.Features = $.$cast(parameter.Value, $.$dgLE.LCPCSG.AppServiceGuardFeatures);
                    return true;
                    case "Service":
                    this.Service = $.$cast(parameter.Value, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType));
                    return true;
                    case "NotAuthorizedView":
                    this.NotAuthorizedView = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "CustomAuthentication":
                    this.CustomAuthentication = $.$cast(parameter.Value, $.$$.S.Func$$($.$$.S.Boolean));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(309238841063)
            
            //--TRIMMABLE-BOUNDARY-START(167504920295)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504920295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(167504920295)
            
            //--TRIMMABLE-BOUNDARY-START(197569691367)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(197569691367)
            
            //--TRIMMABLE-BOUNDARY-START(55835770599)
            /*string?*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(55835770599)
            
            //--TRIMMABLE-BOUNDARY-START(227634462439)
            /*string?*/ PageRoute = null;
            //--TRIMMABLE-BOUNDARY-END(227634462439)
            
            //--TRIMMABLE-BOUNDARY-START(68720672487)
            /*string?*/ DefaultHandle = null;
            //--TRIMMABLE-BOUNDARY-END(68720672487)
            
            //--TRIMMABLE-BOUNDARY-START(77310607079)
            /*AppServiceGuardFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(77310607079)
            
            //--TRIMMABLE-BOUNDARY-START(231929429735)
            /*IServiceGuardViewModel<TServiceModel, TServiceTierType, TServiceFeatureType>*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(231929429735)
            
            //--TRIMMABLE-BOUNDARY-START(201864658663)
            /*RenderFragment?*/ NotAuthorizedView = null;
            //--TRIMMABLE-BOUNDARY-END(201864658663)
            
            //--TRIMMABLE-BOUNDARY-START(64425705191)
            /*Func<bool>?*/ CustomAuthentication = null;
            //--TRIMMABLE-BOUNDARY-END(64425705191)
            
            //--TRIMMABLE-BOUNDARY-START(184684789479)
            /*IServiceSubscriptionViewModel */ get LCPCSG$IAppServiceGuard$Service()
            {
                return this.Service;
            }
            //--TRIMMABLE-BOUNDARY-END(184684789479)
            
            //--TRIMMABLE-BOUNDARY-START(51540803303)
            /*string?*/ basePath = null;
            //--TRIMMABLE-BOUNDARY-END(51540803303)
            
            //--TRIMMABLE-BOUNDARY-START(223339495143)
            /*string?*/ pageRoute = null;
            //--TRIMMABLE-BOUNDARY-END(223339495143)
            
            //--TRIMMABLE-BOUNDARY-START(180389822183)
            /*RenderFragment */ LCPCSG$IAppServiceGuard$GetSelectorView(/*Action<IServiceDataModel>?*/ onSelected)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389822183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceSelector(false, null, $.$$.N.InterfaceVarianceStubHandler.Create(onSelected, $.$$.S.Action$$($.$fPer.LCFCD.IServiceDataModel), $.$$.S.Action$$(TServiceModel)));
            }
            //--TRIMMABLE-BOUNDARY-END(180389822183)
            
            //--TRIMMABLE-BOUNDARY-START(42950868711)
            /*string?*/ appBasePath = null;
            //--TRIMMABLE-BOUNDARY-END(42950868711)
            
            //--TRIMMABLE-BOUNDARY-START(47245836007)
            /*string? */ get AppBasePath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900541671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.appBasePath !== null)
                {
                    return this.appBasePath;
                }
                if (this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type === 4/*RuntimeType.WasmMobileApp*/)
                {
                    return this.appBasePath = "";
                }
                if ($.$$.S.String.IsNullOrEmpty(this.basePath))
                {
                    return this.appBasePath = this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceHandle;
                }
                return this.appBasePath = `${$.$strNN(this.basePath)}/${$.$strNN(this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceHandle)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(47245836007)
            
            //--TRIMMABLE-BOUNDARY-START(210454593255)
            /*ValueTask<bool> */ OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454593255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, false);
            }
            //--TRIMMABLE-BOUNDARY-END(210454593255)
            
            //--TRIMMABLE-BOUNDARY-START(214749560551)
            /*ValueTask */ OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749560551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(214749560551)
            
            //--TRIMMABLE-BOUNDARY-START(188979756775)
            /*Task *//*async*/  LoadAccount(/*AppServiceSelected<TServiceModel>*/ selected)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979756775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$scsl.S.Console.WriteLine$17(`Loading \"${$.$strNN(selected.Service.Title)}\"`);
                    ($t2 = this.Service.LCFCC$IServiceSubscriptionViewModel$$$LoadService(selected.Service), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(188979756775)
            
            //--TRIMMABLE-BOUNDARY-START(206159625959)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159625959);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.UnitOfWork.LCFCI$IClientUnitOfWork$Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        /*var*/ let uri = new $.$spu.S.Uri().$ctor$5(this.Navigation.Uri);
                        this.basePath = this.BasePath;
                        this.pageRoute = this.PageRoute;
                        /*var*/ let tokens = $.$fPer.LCFCS$6.StringExtension.SplitByPath($.$fPer.LCFC.StringyExtension.AsStringy$1(uri.AbsolutePath).Trim$1(/*/*/ 47));
                        /*int*/ let where = 0;
                        if (this.basePath === null && tokens.Length > 0)
                        {
                            this.basePath = $.$fPer.LCFC.Stringy.op_Implicit$1(tokens.get_Item$1(where++));
                        }
                        if (where < tokens.Length)
                        {
                            /*var*/ let _handle = tokens.get_Item$1(where);
                            if (_handle.StartsWith($.$fPer.LCFC.Stringy.op_Implicit$3("@"), 4) || ((this.Features & (1/*AppServiceGuardFeatures.UseHandleInPath*/)) == (1/*AppServiceGuardFeatures.UseHandleInPath*/)))
                            {
                                this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceHandle = $.$fPer.LCFC.Stringy.op_Implicit$1(_handle);
                                this.basePath += "/" + $.$strNN(_handle.ToString());
                                where++;
                            }
                        }
                        if (this.pageRoute === null && where < tokens.Length)
                        {
                            this.pageRoute = $.$fPer.LCFC.Stringy.op_Implicit$1(tokens.get_Item$1(where));
                        }
                        this.appBasePath = this.basePath;
                        $.$fPer.LCFCD.WorkSpaceExtension.Set($.$dgLE.LCPCSG.IAppServiceGuard, this.UnitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter, this, null, null, true);
                        try
                        {
                            let $t3, $r3;
                            ($t3 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        }
                        catch($e)
                        {
                            if ($e instanceof $.$vWqU.LCFCC.NoServiceSubscriptionException)
                            {
                            }
                            else if ($e instanceof $.$vWqU.LCFCC.NoActiveServiceSubscriptionException)
                            {
                            }
                            else if ($e instanceof $.$$.S.UnauthorizedAccessException)
                            {
                            }
                            else
                            {
                                throw $e;
                            }
                        }
                    }
                    ($t4 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206159625959)
            
            //--TRIMMABLE-BOUNDARY-START(73015639783)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015639783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCD.WorkSpaceExtension.Remove($.$dgLE.LCPCSG.IAppServiceGuard, this.UnitOfWork.LCFCI$IClientUnitOfWork$MessagingCenter, null, null, true);
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(73015639783)
            
            //--TRIMMABLE-BOUNDARY-START(193274724071)
            /*Task *//*async*/  LogOut()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274724071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let uri = new $.$spu.S.Uri().$ctor$5(this.Navigation.Uri);
                    ($t5 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$LogOut(null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.Navigation.NavigateTo$2(uri.PathAndQuery, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(193274724071)
            
            //--TRIMMABLE-BOUNDARY-START(60130737895)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130737895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UnitOfWork.LCFCI$IClientUnitOfWork$Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "hv-10 stack");
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 2);
                    __builder.AddComponentParameter(3, "Class", "mg-a");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else if (((this.Features & (2/*AppServiceGuardFeatures.SelectServiceBeforeLogin*/)) == (2/*AppServiceGuardFeatures.SelectServiceBeforeLogin*/)))
                {
                    if (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected === null)
                    {
                        __builder.AddContent$1(4, this.ServiceSelector(true, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceHandle, null));
                    }
                    else 
                    {
                        __builder.AddContent$1(5, this.View());
                    }
                }
                else 
                {
                    __builder.AddContent$1(6, this.View());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130737895)
            
            //--TRIMMABLE-BOUNDARY-START(313533808359)
            /*RenderFragment */ View()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533808359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(7, "div");
                    __builder2.AddAttribute$5(8, "class", "hv-10");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCA$3.AuthorizeUser, 9);
                    __builder2.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCA$3.AuthorizeUserFeatures, 0/*AuthorizeUserFeatures.Default*/ | 2/*AuthorizeUserFeatures.ShowLogin*/), $.$hDPm.LCFCCA$3.AuthorizeUserFeatures));
                    __builder2.AddComponentParameter(11, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, $.$as(this.Service, $.$GfYa.LCFCA.IAuthenticationClient)));
                    __builder2.AddComponentParameter(12, "NotAuthorized", (this.NotAuthorizedView));
                    __builder2.AddAttribute$3(13, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)))().$ctor(this, ( (/*ticket*/ ticket) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            if (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected === null)
                            {
                                __builder3.AddContent$1(14, this.ServiceSelector(true, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceHandle, null));
                            }
                            else if ($.$vWqU.LCFCC.LoadingExtension.IsLoadOK(this.Service.LCFCC$ILoadableViewModel$Loading))
                            {
                                /*var*/ let hasSubscription = this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected !== null;
                                /*LivingThing.Core.Frameworks.Common.Models.IUserServiceSubscriptionModel<TServiceModel>?*/ let __ca1__;
                                /*TServiceModel?*/ let __ca2__;
                                /*var*/ let subscriptionExpired = ((__ca1__ = this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected) !== null ? ((__ca2__ = __ca1__.LCFCM$IUserServiceSubscriptionModel$$$Service) !== null ? $.$fPer.LCFCD.ServiceExtension.IsExpired($.$box(__ca2__, TServiceModel)) : false) : false) === true;
                                /*var*/ let hasValidSubscription = hasSubscription && !subscriptionExpired;
                                /*LivingThing.Core.Frameworks.Common.Models.IUserServiceSubscriptionModel<TServiceModel>?*/ let __ca3__;
                                /*TServiceModel?*/ let __ca4__;
                                /*LivingThing.Core.Frameworks.Common.Models.EntityModel?*/ let __ca5__;
                                /*object?*/ let __ca6__;
                                /*bool*/ let isOwner = ((__ca3__ = this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected) !== null ? ((__ca4__ = __ca3__.LCFCM$IUserServiceSubscriptionModel$$$Service) !== null ? ((__ca5__ = __ca4__.Owner) !== null ? ((__ca6__ = __ca5__.Identifier.Id) !== null ? $.$dspc(__ca6__, $.$$.S.Object, ($t) => $t.Equals$1, ticket.Data.Id) : false) : false) : false) : false);
                                if (this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceHandle !== null && this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected === null)
                                {
                                    __builder3.OpenElement(15, "p");
                                    __builder3.AddContent$4(16, "We couldn't find a service with id \"");
                                    __builder3.AddContent$4(17, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceHandle);
                                    __builder3.AddContent$4(18, "\"");
                                    __builder3.CloseElement();
                                }
                                else if (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected !== null && !hasValidSubscription && isOwner)
                                {
                                    __builder3.OpenElement(19, "div");
                                    __builder3.AddAttribute$5(20, "class", "pd hf scroll");
                                    __builder3.OpenComponent$1($.$dgLE.LCPCSG.AppServiceSignup$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType), 21);
                                    __builder3.AddComponentParameter(22, "Service", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType), this.Service));
                                    __builder3.AddComponentParameter(23, "ViewModel", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(TServiceModel, this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service), TServiceModel));
                                    __builder3.AddAttribute$3(24, "Prologue", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        if ($.$sl.SL.Enumerable.Count$1($.$Iaui.LCFCM.IUserServiceSubscriptionModel$$(TServiceModel), this.Service.LCFCC$IServiceSubscriptionViewModel$$$Subscriptions) === 0)
                                        {
                                            __builder4.OpenElement(25, "h2");
                                            __builder4.AddContent$4(26, "No Service Subscription for ");
                                            __builder4.AddContent$4(27, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                                            __builder4.AddContent$4(28, " yet");
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(29, "\r\n                            ");
                                            __builder4.OpenElement(30, "p");
                                            __builder4.AddMarkupContent(31, "\r\n                                You need a service subscription to use ");
                                            __builder4.AddContent$4(32, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                                            __builder4.AddMarkupContent(33, " Portal. If this is your first time,\r\n                                you can use the free trial subscription package.\r\n                            ");
                                            __builder4.CloseElement();
                                        }
                                        else 
                                        {
                                            __builder4.AddMarkupContent(34, "<h4 class=\"cl-error\">Service Expired!</h4>\r\n                            ");
                                            __builder4.OpenElement(35, "p");
                                            __builder4.AddContent$4(36, "Your subscription on ");
                                            __builder4.AddContent$4(37, (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected.LCFCM$IUserServiceSubscriptionModel$$$Service?.Title ?? null));
                                            __builder4.AddContent$4(38, " expired on ");
                                            __builder4.AddContent$3(39, (this.Service.LCFCC$IServiceSubscriptionViewModel$$$Selected?.LCFCM$IUserServiceSubscriptionModel$$$Service?.ExpiryDate ?? null));
                                            __builder4.CloseElement();
                                        }
                                    }), $SeGeBe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                }
                                else if (hasValidSubscription || ((this.CustomAuthentication?.Invoke() ?? null) ?? false))
                                {
                                    __builder3.AddContent$1(40, (this.ChildContent?.Invoke($.$hDPm.LCFCI.ContainerContext$$($.$dgLE.LCPCSG.AppServiceGuardContext).op_Implicit$1((() =>
                                    {
                                        //new $.$dgLE.LCPCSG.AppServiceGuardContext()
                                        const $t6 = $.$dgLE.LCPCSG.AppServiceGuardContext;
                                        const $i6 = new $t6();
                                        $i6.$ctor$2();
                                        $i6.AppBasePath = this.AppBasePath;
                                        return $i6;
                                    })())) ?? null));
                                }
                                else 
                                {
                                    __builder3.OpenElement(41, "div");
                                    __builder3.AddAttribute$5(42, "class", "pd hf scroll");
                                    __builder3.OpenElement(43, "div");
                                    __builder3.AddAttribute$5(44, "class", "text-center");
                                    __builder3.AddMarkupContent(45, "<h2>Access denied</h2>\r\n                        ");
                                    __builder3.OpenElement(46, "p");
                                    __builder3.AddMarkupContent(47, "\r\n                            This can happen if the owner of ");
                                    __builder3.OpenElement(48, "b");
                                    __builder3.AddContent$4(49, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(50, "\r\n                            ");
                                    __builder3.AddContent$4(51, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                                    __builder3.AddMarkupContent(52, " has not made a service subscription on it or\r\n                            you have not been granted acces by them.\r\n                        ");
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(53, "\r\n                        ");
                                    __builder3.OpenElement(54, "h3");
                                    __builder3.AddContent$4(55, "Find another ");
                                    __builder3.AddContent$4(56, this.Service.LCFCC$IServiceSubscriptionViewModel$ServiceLabel);
                                    __builder3.AddContent$4(57, " below");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(58, "\r\n                    ");
                                    __builder3.AddContent$1(59, this.ServiceSelector(false, null, null));
                                    __builder3.CloseElement();
                                }
                            }
                            else 
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 60);
                                __builder3.AddComponentParameter(61, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this.Service));
                                __builder3.CloseComponent();
                                if (this.Service.LCFCC$ILoadableViewModel$Loading.State === 1073741824/*LoadingState.LoadError*/ && this.Service.LCFCC$ILoadableViewModel$LoadErrorMessage === "Not Authorized")
                                {
                                    __builder3.OpenElement(62, "div");
                                    __builder3.AddAttribute$5(63, "class", "flex");
                                    __builder3.OpenElement(64, "button");
                                    __builder3.AddAttribute$5(65, "class", "cl-warning mg-a corner pd");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 66, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.LogOut)));
                                    __builder3.AddContent$4(67, "LogOut");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                            }
                        }, $iShfvc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $fijABb ??= {"r":6881395,"p":[{"n":"ticket","p":$.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                }, $iavrgb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(313533808359)
            
            //--TRIMMABLE-BOUNDARY-START(236224397031)
            /*RenderFragment */ ServiceSelector(/*bool*/ loadLastAccount, /*string?*/ selectByHandle, /*Action<TServiceModel>?*/ onSelected)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224397031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task*/ /*async*/  function Selected(/*AppServiceSelected<TServiceModel>*/ selected)
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t7, $r7;
                        let $t8, $r8;
                        onSelected?.Invoke(selected.Service);
                        ($t7 = this.LoadAccount($.$clone(selected)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        ($t8 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.ProductsServices.Client.Blazor\\AppServiceGuard_razor.g.cs", "ServiceSelector", 1183), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    });
                }
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$dgLE.LCPCSG.AppServiceSelector$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType), 68);
                    __builder2.AddComponentParameter(69, "Service", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType), this.Service));
                    __builder2.AddComponentParameter(70, "LoadLastAccount", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, loadLastAccount), $.$$.S.Boolean));
                    __builder2.AddComponentParameter(71, "ServiceId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, selectByHandle));
                    __builder2.AddComponentParameter(72, "OnServiceAccountSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel)), $.$mac.MAC.EventCallback.Factory.Create$10($.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel), this, new ($.$$.S.Func$$$($.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel), $.$$.STT.Task))().$ctor(this, Selected.bind(this), $MAAXEc ??= {"r":178454529,"p":[{"n":"selected","p":$.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel).$h}],"n":"Selected","d":this.$h,"H":0,"h":0,"f":16781314}))));
                    __builder2.CloseComponent();
                }, $pXbuCe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(236224397031)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(38655901415)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655901415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655901415)
            
            //--TRIMMABLE-BOUNDARY-START(38655901415)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(38655901415)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(197569691367)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(197569691367)
                
                //--TRIMMABLE-BOUNDARY-START(77310607079)
                this.Features = 0;
                //--TRIMMABLE-BOUNDARY-END(77310607079)
                
                //--TRIMMABLE-BOUNDARY-START(231929429735)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(231929429735)
                
            }
            static $H = 1195751;
            static $h = 1195751;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseModelContainer$$($.$dgLE.LCPCSG.AppServiceGuardContext); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(219044527847),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 146030083815,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 219044527847,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(219044527847),
//--TRIMMABLE-BOUNDARY-START(197569691367),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128850214631,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 279174069991,
        "h": Number(BigInt(this.$h)|0x4100000000n),
        "f": 83886081
      },
      "n": "Navigation",
      "d": this.$h,
      "H": 197569691367,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569691367),
//--TRIMMABLE-BOUNDARY-START(55835770599),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94490476263,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 244814331623,
        "h": Number(BigInt(this.$h)|0x3900000000n),
        "f": 83886081
      },
      "n": "BasePath",
      "d": this.$h,
      "H": 55835770599,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835770599),
//--TRIMMABLE-BOUNDARY-START(227634462439),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 154620018407,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 296353939175,
        "h": Number(BigInt(this.$h)|0x4500000000n),
        "f": 83886081
      },
      "n": "PageRoute",
      "d": this.$h,
      "H": 227634462439,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227634462439),
//--TRIMMABLE-BOUNDARY-START(68720672487),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111670345447,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 261994200807,
        "h": Number(BigInt(this.$h)|0x3D00000000n),
        "f": 83886081
      },
      "n": "DefaultHandle",
      "d": this.$h,
      "H": 68720672487,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720672487),
//--TRIMMABLE-BOUNDARY-START(77310607079),
    {
      "p": 1326823,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120260280039,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 270584135399,
        "h": Number(BigInt(this.$h)|0x3F00000000n),
        "f": 83886081
      },
      "n": "Features",
      "d": this.$h,
      "H": 77310607079,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310607079),
//--TRIMMABLE-BOUNDARY-START(231929429735),
    {
      "p": $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$(TServiceModel, TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 163209952999,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 304943873767,
        "h": Number(BigInt(this.$h)|0x4700000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 231929429735,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231929429735),
//--TRIMMABLE-BOUNDARY-START(201864658663),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137440149223,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 287764004583,
        "h": Number(BigInt(this.$h)|0x4300000000n),
        "f": 83886081
      },
      "n": "NotAuthorizedView",
      "d": this.$h,
      "H": 201864658663,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864658663),
//--TRIMMABLE-BOUNDARY-START(64425705191),
    {
      "p": $.$$.S.Func$$($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103080410855,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 253404266215,
        "h": Number(BigInt(this.$h)|0x3B00000000n),
        "f": 83886081
      },
      "n": "CustomAuthentication",
      "d": this.$h,
      "H": 64425705191,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425705191),
//--TRIMMABLE-BOUNDARY-START(184684789479),
    {
      "p": 4480424,
      "g": {
        "r": 0,
        "d": 0,
        "H": 176094854887,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 50331650
      },
      "n": "{1720039}.Service",
      "o": "LCPCSG$IAppServiceGuard$Service",
      "d": this.$h,
      "H": 184684789479,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(184684789479),
//--TRIMMABLE-BOUNDARY-START(47245836007),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85900541671,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "AppBasePath",
      "d": this.$h,
      "H": 47245836007,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245836007)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(309238841063),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 309238841063,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(309238841063),
//--TRIMMABLE-BOUNDARY-START(167504920295),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 167504920295,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504920295),
//--TRIMMABLE-BOUNDARY-START(210454593255),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": this.$h,
      "H": 210454593255,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454593255),
//--TRIMMABLE-BOUNDARY-START(214749560551),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "d": this.$h,
      "H": 214749560551,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749560551),
//--TRIMMABLE-BOUNDARY-START(188979756775),
    {
      "r": 178454529,
      "p": [
        {
          "n": "selected",
          "p": $.$dgLE.LCPCSG.AppServiceSelected$$(TServiceModel).$h
        }
      ],
      "n": "LoadAccount",
      "d": this.$h,
      "H": 188979756775,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(188979756775),
//--TRIMMABLE-BOUNDARY-START(206159625959),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": this.$h,
      "H": 206159625959,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(206159625959),
//--TRIMMABLE-BOUNDARY-START(73015639783),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 73015639783,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015639783),
//--TRIMMABLE-BOUNDARY-START(193274724071),
    {
      "r": 178454529,
      "n": "LogOut",
      "d": this.$h,
      "H": 193274724071,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(193274724071),
//--TRIMMABLE-BOUNDARY-START(60130737895),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 60130737895,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60130737895),
//--TRIMMABLE-BOUNDARY-START(313533808359),
    {
      "r": 6881395,
      "n": "View",
      "d": this.$h,
      "H": 313533808359,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(313533808359),
//--TRIMMABLE-BOUNDARY-START(236224397031),
    {
      "r": 6881395,
      "p": [
        {
          "n": "loadLastAccount",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "selectByHandle",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "onSelected",
          "p": $.$$.S.Action$$(TServiceModel).$h,
          "f": 65
        }
      ],
      "n": "ServiceSelector",
      "d": this.$h,
      "H": 236224397031,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236224397031)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540803303),
    {
      "t": 1310721,
      "n": "basePath",
      "d": this.$h,
      "H": 51540803303,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540803303),
//--TRIMMABLE-BOUNDARY-START(223339495143),
    {
      "t": 1310721,
      "n": "pageRoute",
      "d": this.$h,
      "H": 223339495143,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(223339495143),
//--TRIMMABLE-BOUNDARY-START(42950868711),
    {
      "t": 1310721,
      "n": "appBasePath",
      "d": this.$h,
      "H": 42950868711,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950868711)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655901415),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 38655901415,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655901415)
  ],
  "s": [
    {
      "h": TServiceModel?.$h??1572864,
      "n": "TServiceModel",
      "f": 4,
      "c": [$.$Iaui.LCFCM.ServiceModel$$$$(TServiceTierType, TServiceSettings, TServiceStates).$h
      ]
    },
    {
      "h": TServiceSettings?.$h??1638400,
      "n": "TServiceSettings",
      "f": 4,
      "c": [20456790
      ]
    },
    {
      "h": TServiceStates?.$h??1703936,
      "n": "TServiceStates",
      "f": 4,
      "c": [22422870
      ]
    },
    {
      "h": TServiceTierType?.$h??1769472,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1835008,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 5,
  "H": 1195751,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent, $.$dgLE.LCPCSG.IAppServiceGuard ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.Guard.AppServiceGuard<${TServiceModel?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}Guard${separator}AppServiceGuard$${TServiceModel?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1195751)
        
        

        //--TRIMMABLE-BOUNDARY-START(2899687)
        $asm.$cls(`$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor<,>`, (TServiceTierType, TFeatureType) => $asm.$gt(`$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor<,>`, [TServiceTierType, TFeatureType], ($self) => class ServiceSubscriptionModelTypeDescriptor$$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))
        {
            //--TRIMMABLE-BOUNDARY-START(4297866983)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297866983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType).GenerateProperties($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType), this, factory);
                    }, $nphBsb ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "ServiceSubscriptionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.ProductsServices.Client.Blazor\\ViewModels_ServiceSubscriptionModel_LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel_TServiceTierType__TFeatureType_TypeDescriptorBuilder.g.cs", "ServiceSubscriptionModelTypeDescriptor", 42);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297866983)
            
            //--TRIMMABLE-BOUNDARY-START(12887801575)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887801575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "ServiceType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ServiceType";
                        $i1.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).ServiceType);
                        }, $mMiOib ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TierName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "TierName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TierName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "TierName";
                        $i3.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).TierName);
                        }, $MvBGna ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "ServiceName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ServiceName";
                        $i5.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).ServiceName);
                        }, $OSLIxh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceName = value.AsReference($.$$.S.String);
                        }, $cKeqca ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Limits"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "Limits", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Limits")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Limits";
                        $i7.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).Limits);
                        }, $gHYQOj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Limits = value.AsInt();
                        }, $QqTIDa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SubscriptionCounts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "SubscriptionCounts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SubscriptionCounts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "SubscriptionCounts";
                        $i9.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).SubscriptionCounts);
                        }, $mSCTqe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.SubscriptionCounts = value.AsInt();
                        }, $jCTnhb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Expiry"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "Expiry", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Expiry")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Expiry";
                        $i11.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).Expiry);
                        }, $wKVpIa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PayableAmount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "PayableAmount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PayableAmount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "PayableAmount";
                        $i13.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).PayableAmount);
                        }, $oyUSLi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tier"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "Tier", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tier")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Tier";
                        $i15.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType), ($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).Tier);
                        }, $BevUnb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Tier = value.AsReference($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType));
                        }, $QqBXlf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.IServiceDataModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Service";
                        $i17.DelaredOn = "LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCD.IServiceDataModel, ($.$cast(target, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))).Service);
                        }, $lMYwRf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887801575)
            
            //--TRIMMABLE-BOUNDARY-START(17182768871)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182768871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _ServiceType = _target.ServiceType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceType, ($v) => _ServiceType = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _TierName = _target.TierName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TierName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _TierName, ($v) => _TierName = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _ServiceName = _target.ServiceName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceName, ($v) => _ServiceName = $v, $.$$.S.String)))
                    {
                        _target.ServiceName = _ServiceName;
                    }
                }
                {
                    /*var*/ let _Limits = _target.Limits;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Limits"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Limits, ($v) => _Limits = $v, $.$$.S.Int32)))
                    {
                        _target.Limits = _Limits;
                    }
                }
                {
                    /*var*/ let _SubscriptionCounts = _target.SubscriptionCounts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SubscriptionCounts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _SubscriptionCounts, ($v) => _SubscriptionCounts = $v, $.$$.S.Int32)))
                    {
                        _target.SubscriptionCounts = _SubscriptionCounts;
                    }
                }
                {
                    /*var*/ let _Expiry = _target.Expiry;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Expiry"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Expiry, ($v) => _Expiry = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _PayableAmount = _target.PayableAmount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PayableAmount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _PayableAmount, ($v) => _PayableAmount = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Tier = _target.Tier;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tier"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Tier, ($v) => _Tier = $v, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType))))
                    {
                        _target.Tier = _Tier;
                    }
                }
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.IServiceDataModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$fPer.LCFCD.IServiceDataModel)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182768871)
            
            //--TRIMMABLE-BOUNDARY-START(8592834279)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModel<TServiceTierType, TFeatureType>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592834279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType), null, $.$ref(() => _target, ($v) => _target = $v, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType))))
                {
                    /*var*/ let result = $.$dgLE.LCPCV.ServiceSubscriptionModelTypeDescriptor$$$(TServiceTierType, TFeatureType).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType), null, $.$ref(() => _target, ($v) => _target = $v, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592834279)
            
            static $H = 2899687;
            static $h = 2899687;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887801575),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12887801575,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887801575),
//--TRIMMABLE-BOUNDARY-START(17182768871),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17182768871,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182768871),
//--TRIMMABLE-BOUNDARY-START(8592834279),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8592834279,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592834279)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297866983),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4297866983,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297866983)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatureType?.$h??1638400,
      "n": "TFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 2899687,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TFeatureType)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.ViewModels.ServiceSubscriptionModelTypeDescriptor<${TServiceTierType?.$fullName},${TFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}ViewModels${separator}ServiceSubscriptionModelTypeDescriptor$${TServiceTierType?.$getFullName(separator)}$${TFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2899687)
        
        

        //--TRIMMABLE-BOUNDARY-START(2309863)
        $asm.$cls(`$dgLE.LCPCS$1.ServiceSignUp<,,,,>`, (TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType) => $asm.$gt(`$dgLE.LCPCS$1.ServiceSignUp<,,,,>`, [TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType], ($self) => class ServiceSignUp$$$$$$ extends $.$hDPm.LCFCC$1.BaseComponent$$($.$dgLE.LCPCV.ServiceSignupViewModel$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType))
        {
            //--TRIMMABLE-BOUNDARY-START(313534922471)
            /*string */ get OptimizedComponentName()
            {
                return "servicesignup";
            }
            //--TRIMMABLE-BOUNDARY-END(313534922471)
            
            //--TRIMMABLE-BOUNDARY-START(485333614311)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485333614311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Features":
                    this.Features = $.$cast(parameter.Value, $.$dgLE.LCPCS$1.ServiceSignUpFeatures);
                    return true;
                    case "ServiceName":
                    this.ServiceName = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Prologue":
                    this.Prologue = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "PaymentReferencePrefix":
                    this.PaymentReferencePrefix = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Finished":
                    this.Finished = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment$$(TServiceModel));
                    return true;
                    case "OnServiceCreated":
                    this.OnServiceCreated = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$(TServiceModel));
                    return true;
                    case "InitializeService":
                    this.InitializeService = $.$cast(parameter.Value, $.$$.S.Action$$$(TServiceModel, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)));
                    return true;
                    case "Service":
                    this.Service = $.$cast(parameter.Value, TServiceModel);
                    return true;
                    case "Provider":
                    this.Provider = $.$cast(parameter.Value, $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(485333614311)
            
            //--TRIMMABLE-BOUNDARY-START(283470151399)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283470151399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthorizationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
                this.ClientAuthorizationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientAuthenticationService, serviceProvider);
                this.RemoteService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(283470151399)
            
            //--TRIMMABLE-BOUNDARY-START(489628581607)
            /*ServiceSignupViewModel<TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType>*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(489628581607)
            
            //--TRIMMABLE-BOUNDARY-START(107376492263)
            /*ServiceSignUpFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(107376492263)
            
            //--TRIMMABLE-BOUNDARY-START(352189628135)
            /*string?*/ ServiceName = null;
            //--TRIMMABLE-BOUNDARY-END(352189628135)
            
            //--TRIMMABLE-BOUNDARY-START(330714791655)
            /*RenderFragment?*/ Prologue = null;
            //--TRIMMABLE-BOUNDARY-END(330714791655)
            
            //--TRIMMABLE-BOUNDARY-START(326419824359)
            /*string?*/ PaymentReferencePrefix = null;
            //--TRIMMABLE-BOUNDARY-END(326419824359)
            
            //--TRIMMABLE-BOUNDARY-START(111671459559)
            /*RenderFragment<TServiceModel?>?*/ Finished = null;
            //--TRIMMABLE-BOUNDARY-END(111671459559)
            
            //--TRIMMABLE-BOUNDARY-START(309239955175)
            /*EventCallback<TServiceModel>*/ OnServiceCreated;
            //--TRIMMABLE-BOUNDARY-END(309239955175)
            
            //--TRIMMABLE-BOUNDARY-START(279175184103)
            /*Action<TServiceModel, ServiceSubscriptionModel<TServiceTierType, TServiceFeatureType>>?*/ InitializeService = null;
            //--TRIMMABLE-BOUNDARY-END(279175184103)
            
            //--TRIMMABLE-BOUNDARY-START(347894660839)
            /*TServiceModel?*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(347894660839)
            
            //--TRIMMABLE-BOUNDARY-START(335009758951)
            /*ICatalogueProvider<TServiceTierType, TServiceFeatureType>*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(335009758951)
            
            //--TRIMMABLE-BOUNDARY-START(77311721191)
            /*IAuthenticationService*/ AuthorizationManager = null;
            //--TRIMMABLE-BOUNDARY-END(77311721191)
            
            //--TRIMMABLE-BOUNDARY-START(90196623079)
            /*IClientAuthenticationService*/ ClientAuthorizationManager = null;
            //--TRIMMABLE-BOUNDARY-END(90196623079)
            
            //--TRIMMABLE-BOUNDARY-START(339304726247)
            /*IServerRemoteService*/ RemoteService = null;
            //--TRIMMABLE-BOUNDARY-END(339304726247)
            
            //--TRIMMABLE-BOUNDARY-START(73016753895)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(73016753895)
            
            //--TRIMMABLE-BOUNDARY-START(98786557671)
            /*ServiceTierModel<TServiceTierType, TServiceFeatureType>?*/ expiredTier = null;
            //--TRIMMABLE-BOUNDARY-END(98786557671)
            
            //--TRIMMABLE-BOUNDARY-START(103081524967)
            /*bool*/ expiredTierIsTrial = false;
            //--TRIMMABLE-BOUNDARY-END(103081524967)
            
            //--TRIMMABLE-BOUNDARY-START(81606688487)
            /*IEnumerable<ServiceTierModel<TServiceTierType, TServiceFeatureType>>? */ get BaseTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441263335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TServiceFeatureType>>?*/ let __ca1__;
                return ((this.expiredTier !== null && this.expiredTierIsTrial) ? ((__ca1__ = this.ViewModel.Tiers) !== null ? $.$sl.SL.Enumerable.Where($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), __ca1__, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e !== this.expiredTier;
                }, $FJArna ??= {"r":262145,"p":[{"n":"e","p":$.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) : null) : this.ViewModel.Tiers);
            }
            //--TRIMMABLE-BOUNDARY-END(81606688487)
            
            //--TRIMMABLE-BOUNDARY-START(481038647015)
            /*IEnumerable<ServiceTierModel<TServiceTierType, TServiceFeatureType>>? */ get Tiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266290282215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TServiceFeatureType>>?*/ let __ca2__;
                return _ = ((__ca2__ = this.BaseTiers) !== null ? $.$sl.SL.Enumerable.Where($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), __ca2__, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return this.Service === null || $.$fPer.LCFCD.ServiceExtension.IsExpired($.$box(this.Service, TServiceModel)) === true || $.$$.S.Enum.Equals$1.call(this.Service.LCFCD$IServiceDataModel$$$ServiceTier, $.$box(e.ServiceType, TServiceTierType));
                }, $XAydsb ??= {"r":262145,"p":[{"n":"e","p":$.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(481038647015)
            
            //--TRIMMABLE-BOUNDARY-START(476743679719)
            /*bool */ get TierFiltered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700347623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TServiceFeatureType>>?*/ let __ca3__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TServiceFeatureType>>?*/ let __ca4__;
                return ((__ca3__ = this.BaseTiers) !== null ? $.$sl.SL.Enumerable.Count$1($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), __ca3__) : null) !== ((__ca4__ = this.Tiers) !== null ? $.$sl.SL.Enumerable.Count$1($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), __ca4__) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(476743679719)
            
            //--TRIMMABLE-BOUNDARY-START(296355053287)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(296355053287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ViewModel = (() =>
                    {
                        //new $.$dgLE.LCPCV.ServiceSignupViewModel$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType)()
                        const $t2 = $.$dgLE.LCPCV.ServiceSignupViewModel$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType);
                        const $i2 = new $t2();
                        $i2.$ctor$3(this.AuthorizationManager, this.RemoteService, this.Provider, new ($.$$.S.Func$$$(TServiceModel, $.$$.STT.Task))().$ctor(this,  (/*s*/ s) =>
                        {
                            return this.OnServiceCreated.InvokeAsync$1(s);
                        }, $LdIPKj ??= {"r":178454529,"p":[{"n":"s","p":TServiceModel?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this.InitializeService, this.Service);
                        $i2.ServiceName = this.ServiceName;
                        return $i2;
                    })();
                    ($t3 = this.ViewModel.Load(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    if (this.Provider.LCFCP$ICatalogueProvider$$$$ServiceTiers !== null && this.Service !== null && $.$fPer.LCFCD.ServiceExtension.IsExpired($.$box(this.Service, TServiceModel)) === true)
                    {
                        let $t4, $r4;
                        /*var*/ let tiers = (($t4 = this.Provider.LCFCP$ICatalogueProvider$$$$ServiceTiers.Invoke($.$fPer.LCFCD.DataFilter.Default), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)))).Data;
                        this.expiredTier = $.$sl.SL.Enumerable.SingleOrDefault$1($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), tiers, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                        {
                            return $.$$.S.Enum.Equals$1.call(t.Service, $.$box(this.Service.LCFCD$IServiceDataModel$$$ServiceTier, TServiceTierType));
                        }, $XCoUil ??= {"r":262145,"p":[{"n":"t","p":$.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        if (this.expiredTier !== null)
                        {
                            this.expiredTierIsTrial = this.expiredTier.Cost.Value === 0 && $.$sl.SL.Enumerable.First$1($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), tiers) === this.expiredTier;
                            if (!this.expiredTierIsTrial)
                            {
                                this.ViewModel.SelectTier(this.expiredTier);
                            }
                        }
                    }
                    ($t5 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(296355053287)
            
            //--TRIMMABLE-BOUNDARY-START(493923548903)
            /*WizardSteps?*/ wizard = null;
            //--TRIMMABLE-BOUNDARY-END(493923548903)
            
            //--TRIMMABLE-BOUNDARY-START(343599693543)
            /*ValueTask */ SelectTier(/*ServiceTierModel<TServiceTierType, TServiceFeatureType>*/ tier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599693543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.SelectTier(tier);
                return this.Next();
            }
            //--TRIMMABLE-BOUNDARY-END(343599693543)
            
            //--TRIMMABLE-BOUNDARY-START(287765118695)
            /*ValueTask *//*async*/  Next()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(287765118695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = this.wizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.ProductsServices.Client.Blazor\\ServiceSignUp.razor.cs", "Next", 110), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(287765118695)
            
            //--TRIMMABLE-BOUNDARY-START(94491590375)
            /*AuthenticationClientDescriptor?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(94491590375)
            
            //--TRIMMABLE-BOUNDARY-START(300650020583)
            /*ValueTask<bool> *//*async*/  OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300650020583);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = this.wizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    ($t9 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.ProductsServices.Client.Blazor\\ServiceSignUp.razor.cs", "OnLoggedIn", 118), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(300650020583)
            
            //--TRIMMABLE-BOUNDARY-START(304944987879)
            /*ValueTask */ OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944987879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(304944987879)
            
            //--TRIMMABLE-BOUNDARY-START(292060085991)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t11, $r11;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(292060085991);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender && this.expiredTier !== null && !this.expiredTierIsTrial && !((this.Features & (2/*ServiceSignUpFeatures.AllowTierChange*/)) == (2/*ServiceSignUpFeatures.AllowTierChange*/)))
                    {
                        let $t10, $r10;
                        ($t10 = this.wizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                    ($t11 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(292060085991)
            
            //--TRIMMABLE-BOUNDARY-START(322124857063)
            /*string*/ paymentRef = null;
            //--TRIMMABLE-BOUNDARY-END(322124857063)
            
            //--TRIMMABLE-BOUNDARY-START(317829889767)
            /*Task *//*async*/  Pay()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(317829889767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ViewModel.Subscription.PayableAmount.Value > 0)
                    {
                        let $t12, $r12;
                        let $t14, $r14;
                        let $t16, $r16;
                        /*var*/ let ticket = ($t12 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        /*var*/ let payment = (() =>
                        {
                            //new $.$Iaui.LCFCM.PaymentModel()
                            const $t13 = $.$Iaui.LCFCM.PaymentModel;
                            const $i13 = new $t13();
                            $i13.$ctor$3();
                            $i13.Reference = this.paymentRef;
                            $i13.Amount = $.$fPer.LCFCDM.Money.op_Implicit(this.ViewModel.Subscription.PayableAmount);
                            $i13.Summary = $.$strNN($.$strNN(this.Provider.LCFC$IDisplayable$Title) + ": ") + $.$strNN(this.Provider.LCFC$IDescribable$Description);
                            $i13.TargetId = (this.Service?.LCFCD$IIded$Identifier ?? null) ?? new $.$fPer.LCFCD.DataId();
                            return $i13;
                        })();
                        payment.SetProperty($.$$.S.Int32, this.ViewModel.Subscription.SubscriptionCounts, "SubscriptionCounts");
                        /*var*/ let paymentResult = ($t14 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment(this.ViewModel.Subscription.PayableAmount, this.Provider.LCFC$IDisplayable$Title, this.paymentRef, this.Provider.LCFC$IDescribable$Description, null, this.Provider.LCFC$INamed$Name, null, ticket, null, payment), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                        /*var*/ let reference = paymentResult.Reference;
                        reference = $.$strNN((this.PaymentReferencePrefix !== null ? $.$strNN(this.PaymentReferencePrefix) + "/" : null)) + $.$strNN(reference);
                        if (payment.Identifier.Empty)
                        {
                            let $t15, $r15;
                            ($t15 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Iaui.LCFCM.PaymentModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.PaymentModel), [ payment ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                        }
                        ($t16 = this.ViewModel.Paid(reference, payment), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                    }
                    else 
                    {
                        let $t17, $r17;
                        ($t17 = this.ViewModel.Paid(this.paymentRef, null), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(317829889767)
            
            //--TRIMMABLE-BOUNDARY-START(85901655783)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901655783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(this.OwnAttributes(null))));
                __builder.AddAttribute$5(2, "style", "margin:auto;" + $.$strNN((this.ViewModel.CurrentStep !== 0 && this.ViewModel.CurrentStep !== 4 ? "width:min(480px, 100%)" : "")));
                if (!((this.Features & (1/*ServiceSignUpFeatures.HidePrologue*/)) == (1/*ServiceSignUpFeatures.HidePrologue*/)))
                {
                    __builder.OpenElement(3, "h1");
                    __builder.AddAttribute$5(4, "class", "mg-0 text-center");
                    __builder.AddContent$4(5, this.Provider.LCFC$IDisplayable$Title);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(6, "\r\n        ");
                    __builder.OpenElement(7, "p");
                    __builder.AddAttribute$5(8, "class", "text-center");
                    __builder.AddContent$4(9, this.Provider.LCFC$IDescribable$Description);
                    __builder.CloseElement();
                }
                __builder.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 10);
                __builder.AddComponentParameter(11, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$mac.MAC.EventCallback.Factory.Create$10($.$hDPm.LCFCCM$6.ViewChangingEventArgs, this, new ($.$$.S.Func$$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$$.STT.Task))().$ctor(this.ViewModel, this.ViewModel.WizardStep))));
                __builder.AddComponentParameter(12, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                __builder.AddComponentParameter(13, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN((this.ViewModel.CurrentStep !== 0 && this.ViewModel.CurrentStep !== 4 ? "bd shadow corner-5 clip" : ""))}`));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 15);
                    __builder2.AddComponentParameter(16, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                    __builder2.AddAttribute$3(17, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(18, this.Prologue);
                            if (!((this.Features & (1/*ServiceSignUpFeatures.HidePrologue*/)) == (1/*ServiceSignUpFeatures.HidePrologue*/)))
                            {
                                if (this.Provider.LCFC$IDescribable$Description !== null)
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 19);
                                    __builder3.AddComponentParameter(20, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Provider.LCFC$IDescribable$Description));
                                    __builder3.AddComponentParameter(21, "Class", "lh-2");
                                    __builder3.CloseComponent();
                                }
                            }
                            __builder3.OpenElement(22, "h2");
                            __builder3.AddAttribute$5(23, "class", /*true ?*/ "mgt-0"/* : ""*/);
                            __builder3.AddContent$4(24, "Service Packages");
                            __builder3.CloseElement();
                            if (this.TierFiltered)
                            {
                                __builder3.AddMarkupContent(25, "<p class=\"cl-warning fw-bold\">\r\n                        Some Packages are hidden because your current subscription is not expired.\r\n                        When expired, you will be able to switch/choose a new package.\r\n                    </p>");
                            }
                            __builder3.OpenComponent$1($.$dgLE.LCPCS$1.ServiceTiers$$$(TServiceTierType, TServiceFeatureType), 26);
                            __builder3.AddComponentParameter(27, "Tiers", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)), this.Tiers));
                            __builder3.AddComponentParameter(28, "OnSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$$.STT.ValueTask))().$ctor(this, this.SelectTier))));
                            __builder3.CloseComponent();
                        }, $Nemgjh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $cnhUjl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(29, "\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 30);
                    __builder2.AddComponentParameter(31, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                    __builder2.AddAttribute$3(32, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(33, this.ClientAuthorizationManager.LCFCI$IClientAuthenticationService$Authenticate((() =>
                            {
                                //new $.$hDPm.LCFCI.AuthenticationParameter()
                                const $t18 = $.$hDPm.LCFCI.AuthenticationParameter;
                                const $i18 = new $t18();
                                $i18.$ctor$1();
                                $i18.Client = this;
                                $i18.Theme = $.$fPer.LCFC.Theme.Primary;
                                return $i18;
                            })()));
                        }, $XpwUGk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $Dmznhf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(34, "\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 35);
                    __builder2.AddComponentParameter(36, "Class", "bg-card pd-10");
                    __builder2.AddAttribute$3(37, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (this.ViewModel.Subscription !== null)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)), 38);
                                __builder3.AddComponentParameter(39, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType), this.ViewModel.Subscription));
                                __builder3.AddComponentParameter(40, "field-input-class", "corner-5 fsz-20");
                                __builder3.AddComponentParameter(41, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)), $.$mac.MAC.EventCallback.Factory.Create$8($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType), this, new ($.$$.S.Action$$($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)))().$ctor(this,  (/**/ b) =>
                                {
                                    return this.Next();
                                }, $rzenUg ??= {"r":65537,"p":[{"n":"b","p":$.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                                __builder3.AddAttribute$3(42, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 43);
                                    __builder4.AddComponentParameter(44, "Class", "mgx-a mgt-10 wf d-block");
                                    __builder4.AddComponentParameter(45, "type", "submit");
                                    __builder4.AddComponentParameter(46, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder4.AddComponentParameter(47, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder4.AddAttribute$3(48, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddMarkupContent(49, "\r\n                                Continue\r\n                            ");
                                    }), $UIyHXf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }), $aGSyij ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                        }, $DuohEa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $ygfmqg ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(50, "\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 51);
                    __builder2.AddComponentParameter(52, "Class", "pd-10 bg-card");
                    __builder2.AddComponentParameter(53, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                    __builder2.AddAttribute$3(54, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(55, "<h2 class=\"mgt-0\">Service Information</h2>\r\n                ");
                            __builder3.AddMarkupContent(56, "<p>Please confirm the information below before continuing to payment.</p>\r\n                ");
                            $.$dgLE._LCPCSS$1.TypeInference.CreatePropertySheet_0($.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType), __builder3, 57, 58, this.ViewModel.Subscription, 59, 2, 60, 35184372092928n | 8388608n);
                            if (this.ViewModel.Subscription.PayableAmount.Value > 0)
                            {
                                __builder3.OpenElement(61, "h2");
                                __builder3.AddMarkupContent(62, "\r\n                        Pay\r\n                        ");
                                __builder3.OpenElement(63, "span");
                                __builder3.AddAttribute$5(64, "class", "cl-secondary");
                                __builder3.AddContent$3(65, (this.ViewModel.Subscription?.PayableAmount ?? null));
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(66, "\r\n                        with\r\n                    ");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(67, "\r\n                    ");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 68);
                                __builder3.AddComponentParameter(69, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(70, "Class", "mgt wf d-block");
                                __builder3.AddComponentParameter(71, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Pay))));
                                __builder3.AddAttribute$3(72, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(73, "Make Payment");
                                }), $iGfTFi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                            else 
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 74);
                                __builder3.AddComponentParameter(75, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(76, "Class", "mgt wf d-block");
                                __builder3.AddComponentParameter(77, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Pay))));
                                __builder3.AddAttribute$3(78, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(79, "Continue");
                                }), $bXvZLf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                        }, $IfLBYe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $pxeIFf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(80, "\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 81);
                    __builder2.AddComponentParameter(82, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                    __builder2.AddAttribute$3(83, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(84, (this.Finished?.Invoke(this.ViewModel.Service) ?? null));
                            if (this.Finished === null)
                            {
                                __builder3.OpenElement(85, "p");
                                __builder3.AddContent$4(86, "Your service subscription is now completed. Expires ");
                                __builder3.AddContent$3(87, (this.ViewModel.Service?.LCFCD$IServiceDataModel$ExpiryDate ?? null));
                                __builder3.AddContent$4(88, ".");
                                __builder3.CloseElement();
                            }
                        }, $YKnaFk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $qrxcqe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $klzaZd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(89, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.wizard = $.$cast(__value, $.$hDPm.LCFCCW$1.WizardSteps);
                }, $ziuxAk ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(90, "\r\n    ");
                __builder.OpenElement(91, "b");
                __builder.AddAttribute$5(92, "class", "cl-error");
                __builder.AddContent$4(93, this.ViewModel.ErrorMessage);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(85901655783)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886491522)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.Descriptor.get
            get LCFCA$IAuthenticationClient$Descriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296556930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(12886491522)
            
            //--TRIMMABLE-BOUNDARY-START(17181458818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoggedIn(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket)
            LCFCA$IAuthenticationClient$OnLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181458818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoggedIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181458818)
            
            //--TRIMMABLE-BOUNDARY-START(21476426114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoginAborted()
            LCFCA$IAuthenticationClient$OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476426114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoginAborted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476426114)
            
            //--TRIMMABLE-BOUNDARY-START(68721786599)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721786599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68721786599)
            
            //--TRIMMABLE-BOUNDARY-START(68721786599)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(68721786599)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(107376492263)
                this.Features = 2;
                //--TRIMMABLE-BOUNDARY-END(107376492263)
                
                //--TRIMMABLE-BOUNDARY-START(309239955175)
                this.OnServiceCreated = $.$default($.$mac.MAC.EventCallback$$(TServiceModel));
                //--TRIMMABLE-BOUNDARY-END(309239955175)
                
                //--TRIMMABLE-BOUNDARY-START(335009758951)
                this.Provider = null;
                //--TRIMMABLE-BOUNDARY-END(335009758951)
                
                //--TRIMMABLE-BOUNDARY-START(77311721191)
                this.AuthorizationManager = null;
                //--TRIMMABLE-BOUNDARY-END(77311721191)
                
                //--TRIMMABLE-BOUNDARY-START(90196623079)
                this.ClientAuthorizationManager = null;
                //--TRIMMABLE-BOUNDARY-END(90196623079)
                
                //--TRIMMABLE-BOUNDARY-START(339304726247)
                this.RemoteService = null;
                //--TRIMMABLE-BOUNDARY-END(339304726247)
                
                //--TRIMMABLE-BOUNDARY-START(73016753895)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(73016753895)
                
                //--TRIMMABLE-BOUNDARY-START(322124857063)
                this.paymentRef = $.$fPer.LCFCS$6.StringExtension.GetRandomString(8, true, true, false);
                //--TRIMMABLE-BOUNDARY-END(322124857063)
                
            }
            static $H = 2309863;
            static $h = 2309863;
            static $g = 5;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$dgLE.LCPCV.ServiceSignupViewModel$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(313534922471),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 197570805479,
        "h": Number(BigInt(this.$h)|0x2E00000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 313534922471,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(313534922471),
//--TRIMMABLE-BOUNDARY-START(489628581607),
    {
      "p": $.$dgLE.LCPCV.ServiceSignupViewModel$$$$$$(TServiceModel, TServiceSettings, TServiceStates, TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 274880216807,
        "h": Number(BigInt(this.$h)|0x4000000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 472448712423,
        "h": Number(BigInt(this.$h)|0x6E00000000n),
        "f": 83918849
      },
      "n": "ViewModel",
      "d": this.$h,
      "H": 489628581607,
      "h": Number(BigInt(this.$h)|0x7200000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(489628581607),
//--TRIMMABLE-BOUNDARY-START(107376492263),
    {
      "p": 2375399,
      "g": {
        "r": 0,
        "d": 0,
        "H": 163211067111,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 386549366503,
        "h": Number(BigInt(this.$h)|0x5A00000000n),
        "f": 83886081
      },
      "n": "Features",
      "d": this.$h,
      "H": 107376492263,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107376492263),
//--TRIMMABLE-BOUNDARY-START(352189628135),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 249110413031,
        "h": Number(BigInt(this.$h)|0x3A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 463858777831,
        "h": Number(BigInt(this.$h)|0x6C00000000n),
        "f": 83886081
      },
      "n": "ServiceName",
      "d": this.$h,
      "H": 352189628135,
      "h": Number(BigInt(this.$h)|0x5200000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(352189628135),
//--TRIMMABLE-BOUNDARY-START(330714791655),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 214750674663,
        "h": Number(BigInt(this.$h)|0x3200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 429499039463,
        "h": Number(BigInt(this.$h)|0x6400000000n),
        "f": 83886081
      },
      "n": "Prologue",
      "d": this.$h,
      "H": 330714791655,
      "h": Number(BigInt(this.$h)|0x4D00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330714791655),
//--TRIMMABLE-BOUNDARY-START(326419824359),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 206160740071,
        "h": Number(BigInt(this.$h)|0x3000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 420909104871,
        "h": Number(BigInt(this.$h)|0x6200000000n),
        "f": 83886081
      },
      "n": "PaymentReferencePrefix",
      "d": this.$h,
      "H": 326419824359,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(326419824359),
//--TRIMMABLE-BOUNDARY-START(111671459559),
    {
      "p": $.$mac.MAC.RenderFragment$$(TServiceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 171801001703,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 395139301095,
        "h": Number(BigInt(this.$h)|0x5C00000000n),
        "f": 83886081
      },
      "n": "Finished",
      "d": this.$h,
      "H": 111671459559,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111671459559),
//--TRIMMABLE-BOUNDARY-START(309239955175),
    {
      "p": $.$mac.MAC.EventCallback$$(TServiceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 188980870887,
        "h": Number(BigInt(this.$h)|0x2C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 412319170279,
        "h": Number(BigInt(this.$h)|0x6000000000n),
        "f": 83886081
      },
      "n": "OnServiceCreated",
      "d": this.$h,
      "H": 309239955175,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(309239955175),
//--TRIMMABLE-BOUNDARY-START(279175184103),
    {
      "p": $.$$.S.Action$$$(TServiceModel, $.$dgLE.LCPCV.ServiceSubscriptionModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 180390936295,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 403729235687,
        "h": Number(BigInt(this.$h)|0x5E00000000n),
        "f": 83886081
      },
      "n": "InitializeService",
      "d": this.$h,
      "H": 279175184103,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279175184103),
//--TRIMMABLE-BOUNDARY-START(347894660839),
    {
      "p": TServiceModel?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 240520478439,
        "h": Number(BigInt(this.$h)|0x3800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 455268843239,
        "h": Number(BigInt(this.$h)|0x6A00000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 347894660839,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347894660839),
//--TRIMMABLE-BOUNDARY-START(335009758951),
    {
      "p": $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 223340609255,
        "h": Number(BigInt(this.$h)|0x3400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 438088974055,
        "h": Number(BigInt(this.$h)|0x6600000000n),
        "f": 83886081
      },
      "n": "Provider",
      "d": this.$h,
      "H": 335009758951,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335009758951),
//--TRIMMABLE-BOUNDARY-START(77311721191),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128851328743,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 369369497319,
        "h": Number(BigInt(this.$h)|0x5600000000n),
        "f": 83886081
      },
      "n": "AuthorizationManager",
      "d": this.$h,
      "H": 77311721191,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311721191),
//--TRIMMABLE-BOUNDARY-START(90196623079),
    {
      "p": 63592106,
      "g": {
        "r": 0,
        "d": 0,
        "H": 146031197927,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 377959431911,
        "h": Number(BigInt(this.$h)|0x5800000000n),
        "f": 83886081
      },
      "n": "ClientAuthorizationManager",
      "d": this.$h,
      "H": 90196623079,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90196623079),
//--TRIMMABLE-BOUNDARY-START(339304726247),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "H": 231930543847,
        "h": Number(BigInt(this.$h)|0x3600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 446678908647,
        "h": Number(BigInt(this.$h)|0x6800000000n),
        "f": 83886081
      },
      "n": "RemoteService",
      "d": this.$h,
      "H": 339304726247,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339304726247),
//--TRIMMABLE-BOUNDARY-START(73016753895),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120261394151,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 360779562727,
        "h": Number(BigInt(this.$h)|0x5400000000n),
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": this.$h,
      "H": 73016753895,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016753895),
//--TRIMMABLE-BOUNDARY-START(81606688487),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137441263335,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331650
      },
      "n": "BaseTiers",
      "d": this.$h,
      "H": 81606688487,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(81606688487),
//--TRIMMABLE-BOUNDARY-START(481038647015),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 266290282215,
        "h": Number(BigInt(this.$h)|0x3E00000000n),
        "f": 50331650
      },
      "n": "Tiers",
      "d": this.$h,
      "H": 481038647015,
      "h": Number(BigInt(this.$h)|0x7000000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(481038647015),
//--TRIMMABLE-BOUNDARY-START(476743679719),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 257700347623,
        "h": Number(BigInt(this.$h)|0x3C00000000n),
        "f": 50331650
      },
      "n": "TierFiltered",
      "d": this.$h,
      "H": 476743679719,
      "h": Number(BigInt(this.$h)|0x6F00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(476743679719),
//--TRIMMABLE-BOUNDARY-START(94491590375),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "H": 154621132519,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 50331649
      },
      "n": "Descriptor",
      "d": this.$h,
      "H": 94491590375,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491590375)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(485333614311),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 485333614311,
      "h": Number(BigInt(this.$h)|0x7100000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(485333614311),
//--TRIMMABLE-BOUNDARY-START(283470151399),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 283470151399,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(283470151399),
//--TRIMMABLE-BOUNDARY-START(296355053287),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": this.$h,
      "H": 296355053287,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(296355053287),
//--TRIMMABLE-BOUNDARY-START(343599693543),
    {
      "r": 181338113,
      "p": [
        {
          "n": "tier",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h
        }
      ],
      "n": "SelectTier",
      "d": this.$h,
      "H": 343599693543,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(343599693543),
//--TRIMMABLE-BOUNDARY-START(287765118695),
    {
      "r": 181338113,
      "n": "Next",
      "d": this.$h,
      "H": 287765118695,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(287765118695),
//--TRIMMABLE-BOUNDARY-START(300650020583),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": this.$h,
      "H": 300650020583,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(300650020583),
//--TRIMMABLE-BOUNDARY-START(304944987879),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "d": this.$h,
      "H": 304944987879,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(304944987879),
//--TRIMMABLE-BOUNDARY-START(292060085991),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": this.$h,
      "H": 292060085991,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(292060085991),
//--TRIMMABLE-BOUNDARY-START(317829889767),
    {
      "r": 178454529,
      "n": "Pay",
      "d": this.$h,
      "H": 317829889767,
      "h": Number(BigInt(this.$h)|0x4A00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(317829889767),
//--TRIMMABLE-BOUNDARY-START(85901655783),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 85901655783,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(85901655783)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98786557671),
    {
      "t": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h,
      "n": "expiredTier",
      "d": this.$h,
      "H": 98786557671,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98786557671),
//--TRIMMABLE-BOUNDARY-START(103081524967),
    {
      "t": 262145,
      "n": "expiredTierIsTrial",
      "d": this.$h,
      "H": 103081524967,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103081524967),
//--TRIMMABLE-BOUNDARY-START(493923548903),
    {
      "t": 59004586,
      "n": "wizard",
      "d": this.$h,
      "H": 493923548903,
      "h": Number(BigInt(this.$h)|0x7300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(493923548903),
//--TRIMMABLE-BOUNDARY-START(322124857063),
    {
      "t": 1310721,
      "n": "paymentRef",
      "d": this.$h,
      "H": 322124857063,
      "h": Number(BigInt(this.$h)|0x4B00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(322124857063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(68721786599),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 68721786599,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721786599)
  ],
  "s": [
    {
      "h": TServiceModel?.$h??1572864,
      "n": "TServiceModel",
      "f": 4,
      "c": [$.$fPer.LCFCD.IServiceDataModel$$(TServiceTierType).$h
      ]
    },
    {
      "h": TServiceSettings?.$h??1638400,
      "n": "TServiceSettings",
      "f": 4,
      "c": [20456790
      ]
    },
    {
      "h": TServiceStates?.$h??1703936,
      "n": "TServiceStates",
      "f": 4,
      "c": [22422870
      ]
    },
    {
      "h": TServiceTierType?.$h??1769472,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1835008,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 5,
  "H": 2309863,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$GfYa.LCFCA.IAuthenticationClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.ProductsServices.Client.Shared.ServiceSignUp<${TServiceModel?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}ProductsServices${separator}Client${separator}Shared${separator}ServiceSignUp$${TServiceModel?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2309863)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Product"));
})();
//--TRIMMABLE-BOUNDARY-END(16103)
