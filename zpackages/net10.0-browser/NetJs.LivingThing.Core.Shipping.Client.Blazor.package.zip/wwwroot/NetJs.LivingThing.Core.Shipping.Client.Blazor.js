
//--TRIMMABLE-BOUNDARY-START(59832)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $wtdm, $lJUR, $YUlm) {
    "use strict";
    let _;
    let $dfoaAk;
    let $OZjUTf;
    let $MEvcQa;
    let $PhFDed;
    let $AeumNd;
    let $kmNVKe;
    let $bznHrb;
    let $BssBri;
    let $gvnMtj;
    let $TqAZQf;
    let $nSopvd;
    let $AjSXMk;
    let $VNQAoc;
    let $RQTmYh;
    let $LabDuf;
    let $wZdPaj;
    let $BWiLie;
    let $FXqrGc;
    let $AfnAza;
    let $IRjlCf;
    let $hHqVHg;
    let $yRKEGj;
    let $ZjJUjc;
    let $VIisZi;
    let $KCxqCk;
    let $PHSiVd;
    let $isxOYe;
    let $atVUyh;
    let $XtQWNe;
    let $qKFxAb;
    let $DKTZWi;
    let $uDwlPa;
    let $pMvbOj;
    let $XuuOzg;
    let $UBmjye;
    let $lvyufe;
    let $IEzGPj;
    let $wkjkzb;
    let $epIqrf;
    let $khIDti;
    let $oNApkg;
    let $FEaJGd;
    let $DderJf;
    let $BFwKIg;
    let $WBXfhd;
    let $EZdzca;
    let $lUuZok;
    let $YmjVmj;
    let $SmJImj;
    let $ObxnQe;
    let $wZibcj;
    let $ctBEDg;
    let $zXWmKe;
    let $BFHGUk;
    let $XVuDfl;
    let $KNMtal;
    let $ZmvlHf;
    let $AAjVma;
    let $IQeKca;
    let $ZnCaPk;
    let $czdYOj;
    let $SdOjzc;
    let $ktJvUb;
    let $oABXNi;
    let $HaBRha;
    let $xLGjBb;
    let $lcQcFa;
    let $SmJSDc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Shipping.Client.Blazor", 
    {
  "h": 59832,
  "f": "LivingThing.Core.Shipping.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Shipping.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Shipping.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(518584)
        $asm.$cls(`$oUrI.LCSCS.IShipmentTrackingProvider`, ($self) => class IShipmentTrackingProvider
        {
            static $h = 518584;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295485880),
    {
      "r": 6881395,
      "p": [
        {
          "n": "shipment",
          "p": 821369
        }
      ],
      "n": "Track",
      "o": "LCSCS$IShipmentTrackingProvider$Track",
      "d": 518584,
      "h": 4295485880,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295485880)
  ],
  "h": 518584
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Services.IShipmentTrackingProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Services${separator}IShipmentTrackingProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(518584)
        
        

        //--TRIMMABLE-BOUNDARY-START(453048)
        $asm.$cls(`$oUrI.LCSCS.IShipmentDashboardResolver<,>`, (TShipmentPackageModel, TShipmentProductModel) => $asm.$gt(`$oUrI.LCSCS.IShipmentDashboardResolver<,>`, [TShipmentPackageModel, TShipmentProductModel], ($self) => class IShipmentDashboardResolver$$$
        {
            static $H = 453048;
            static $h = 453048;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590387640),
    {
      "r": $.$fPer.LCFCD.Pager$$(TShipmentPackageModel).$h,
      "n": "GetShipmentPackages",
      "o": `LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$GetShipmentPackages`,
      "d": this.$h,
      "H": 8590387640,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590387640),
//--TRIMMABLE-BOUNDARY-START(4295420344),
    {
      "r": $.$fPer.LCFCD.Pager$$(TShipmentProductModel).$h,
      "p": [
        {
          "n": "package",
          "p": TShipmentPackageModel?.$h??1572864
        }
      ],
      "n": "GetProductsInPackage",
      "o": `LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$GetProductsInPackage`,
      "d": this.$h,
      "H": 4295420344,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295420344),
//--TRIMMABLE-BOUNDARY-START(12885354936),
    {
      "r": 6881395,
      "p": [
        {
          "n": "package",
          "p": TShipmentPackageModel?.$h??1572864
        }
      ],
      "n": "GetView",
      "o": `LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$GetView`,
      "d": this.$h,
      "H": 12885354936,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885354936),
//--TRIMMABLE-BOUNDARY-START(17180322232),
    {
      "r": 6881395,
      "p": [
        {
          "n": "product",
          "p": TShipmentProductModel?.$h??1638400
        }
      ],
      "n": "GetView",
      "o": `LCSCS$IShipmentDashboardResolver$$$$GetView$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$1`,
      "d": this.$h,
      "H": 17180322232,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180322232),
//--TRIMMABLE-BOUNDARY-START(21475289528),
    {
      "r": 181338113,
      "p": [
        {
          "n": "package",
          "p": TShipmentPackageModel?.$h??1572864
        },
        {
          "n": "paymentReferenceId",
          "p": 1310721
        }
      ],
      "n": "UpdatePackagePaid",
      "o": `LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$UpdatePackagePaid`,
      "d": this.$h,
      "H": 21475289528,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475289528)
  ],
  "s": [
    {
      "h": TShipmentPackageModel?.$h??1572864,
      "n": "TShipmentPackageModel",
      "c": [952441
      ]
    },
    {
      "h": TShipmentProductModel?.$h??1638400,
      "n": "TShipmentProductModel",
      "c": [1083513
      ]
    }
  ],
  "r": 2,
  "H": 453048,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Services.IShipmentDashboardResolver<${TShipmentPackageModel?.$fullName},${TShipmentProductModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Services${separator}IShipmentDashboardResolver$${TShipmentPackageModel?.$getFullName(separator)}$${TShipmentProductModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(453048)
        
        

        //--TRIMMABLE-BOUNDARY-START(125368)
        $asm.$cls(`$oUrI._LCSCSA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295092664)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::System.Int32*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295092664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "PadContent", $.$box(__arg1, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq3, "ChildContent", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295092664)
            
            static $h = 125368;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295092664),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 655361
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 125368,
      "h": 4295092664,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295092664)
  ],
  "h": 125368
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Shipping.Client.Shared.AppDispatchHome.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}AppDispatchHome${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125368)
        
        

        //--TRIMMABLE-BOUNDARY-START(387512)
        $asm.$cls(`$oUrI.LCSC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590322104)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590322104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$oUrI.LCSCS.IShipmentTrackingProvider, $.$oUrI.LCSCS.ShipmentTrackingProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590322104)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$oUrI.LCSC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295354808)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295354808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295354808)
            
            //--TRIMMABLE-BOUNDARY-START(4295354808)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295354808)
            
            static $h = 387512;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590322104),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 387512,
      "h": 8590322104,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590322104)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295354808),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 387512,
      "h": 4295354808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295354808)
  ],
  "h": 387512
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(387512)
        
        

        //--TRIMMABLE-BOUNDARY-START(584120)
        $asm.$cls(`$oUrI.LCSCS.ShipmentTrackingProvider`, ($self) => class ShipmentTrackingProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590518712)
            /*RenderFragment */ Track(/*IShipmentModel*/ shipment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590518712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590518712)
            
            //--TRIMMABLE-BOUNDARY-START(4295485880)
            //Generated interface implemetation for LivingThing.Core.Shipping.Client.Services.IShipmentTrackingProvider.Track(LivingThing.Core.Shipping.Common.Models.IShipmentModel)
            LCSCS$IShipmentTrackingProvider$Track()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295485880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Track(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295485880)
            
            //--TRIMMABLE-BOUNDARY-START(4295551416)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295551416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295551416)
            
            //--TRIMMABLE-BOUNDARY-START(4295551416)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295551416)
            
            static $h = 584120;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590518712),
    {
      "r": 6881395,
      "p": [
        {
          "n": "shipment",
          "p": 821369
        }
      ],
      "n": "Track",
      "d": 584120,
      "h": 8590518712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590518712)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295551416),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 584120,
      "h": 4295551416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295551416)
  ],
  "h": 584120
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$oUrI.LCSCS.IShipmentTrackingProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Services.ShipmentTrackingProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Services${separator}ShipmentTrackingProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(584120)
        
        

        //--TRIMMABLE-BOUNDARY-START(1108408)
        $asm.$cls(`$oUrI.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296075704)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296075704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296075704)
            
            //--TRIMMABLE-BOUNDARY-START(4296075704)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296075704)
            
            static $h = 1108408;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296075704),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1108408,
      "h": 4296075704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296075704)
  ],
  "h": 1108408
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1108408)
        
        

        //--TRIMMABLE-BOUNDARY-START(1173944)
        $asm.$cls(`$oUrI.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296141240)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296141240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296141240)
            
            //--TRIMMABLE-BOUNDARY-START(4296141240)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296141240)
            
            static $h = 1173944;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296141240),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1173944,
      "h": 4296141240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296141240)
  ],
  "h": 1173944,
  "a": [
    {
      "t": 1108408,
      "c": 4296075704
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1173944)
        
        

        //--TRIMMABLE-BOUNDARY-START(190904)
        $asm.$cls(`$oUrI.LCSC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590125496)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590125496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590125496)
            
            //--TRIMMABLE-BOUNDARY-START(4295158200)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295158200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295158200)
            
            //--TRIMMABLE-BOUNDARY-START(4295158200)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295158200)
            
            static $h = 190904;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590125496),
    {
      "r": 65537,
      "n": "Execute",
      "d": 190904,
      "h": 8590125496,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590125496)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295158200),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 190904,
      "h": 4295158200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295158200)
  ],
  "h": 190904
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(190904)
        
        

        //--TRIMMABLE-BOUNDARY-START(780728)
        $asm.$cls(`$oUrI.LCSCS$1.AppDispatchSplashScreen`, ($self) => class AppDispatchSplashScreen extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590715320)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590715320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hv-10 bg-primary flex");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "mg-a text-center");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "hx-2 wx-2 mg-a");
                __builder.OpenElement(6, "img");
                __builder.AddAttribute$5(7, "src", this.ResolvePath("iLogistics.png", true, false, false));
                __builder.AddAttribute$5(8, "class", "mawp-10");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\r\n        ");
                __builder.AddMarkupContent(10, "<h1 class=\"cl-white\"><span class=\"cl-info\">i</span>Log<span class=\"cl-info\">i</span>st<span class=\"cl-info\">i</span>cs</h1>\r\n        ");
                __builder.AddMarkupContent(11, "<h3 class=\"text-italics cl-white\">...delivery with peace of mind...</h3>");
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590715320)
            
            //--TRIMMABLE-BOUNDARY-START(4295748024)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295748024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295748024)
            
            //--TRIMMABLE-BOUNDARY-START(4295748024)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295748024)
            
            static $h = 780728;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590715320),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 780728,
      "h": 8590715320,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590715320)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295748024),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 780728,
      "h": 4295748024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295748024)
  ],
  "h": 780728
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Shared.AppDispatchSplashScreen`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}AppDispatchSplashScreen`; }
        });
        //--TRIMMABLE-BOUNDARY-END(780728)
        
        

        //--TRIMMABLE-BOUNDARY-START(715192)
        $asm.$cls(`$oUrI.LCSCS$1.AppDispatchItems`, ($self) => class AppDispatchItems extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590649784)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590649784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormWizard$$($.$YUlm.LCSCM.DispatchWizardModel), 0);
                __builder.AddComponentParameter(1, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(2, "Class", "hf");
                __builder.AddComponentParameter(3, "step-class", "pd");
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590649784)
            
            //--TRIMMABLE-BOUNDARY-START(4295682488)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295682488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295682488)
            
            //--TRIMMABLE-BOUNDARY-START(4295682488)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295682488)
            
            static $h = 715192;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590649784),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 715192,
      "h": 8590649784,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590649784)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295682488),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 715192,
      "h": 4295682488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295682488)
  ],
  "h": 715192
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Shared.AppDispatchItems`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}AppDispatchItems`; }
        });
        //--TRIMMABLE-BOUNDARY-END(715192)
        
        

        //--TRIMMABLE-BOUNDARY-START(911800)
        $asm.$cls(`$oUrI.LCSCS$1.ShipmentMap`, ($self) => class ShipmentMap extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590846392)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590846392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCM.LeafletMap, 0);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590846392)
            
            //--TRIMMABLE-BOUNDARY-START(4295879096)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295879096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295879096)
            
            //--TRIMMABLE-BOUNDARY-START(4295879096)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295879096)
            
            static $h = 911800;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590846392),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 911800,
      "h": 8590846392,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590846392)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295879096),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 911800,
      "h": 4295879096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295879096)
  ],
  "h": 911800
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Shared.ShipmentMap`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}ShipmentMap`; }
        });
        //--TRIMMABLE-BOUNDARY-END(911800)
        
        

        //--TRIMMABLE-BOUNDARY-START(649656)
        $asm.$cls(`$oUrI.LCSCS$1.AppDispatchHome`, ($self) => class AppDispatchHome extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590584248)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590584248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCS$7.SideBar, 0);
                __builder.AddComponentParameter(1, "Class", "hf");
                __builder.AddComponentParameter(2, "Side", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarSide, 4/*SideBarSide.Bottom*/), $.$hDPm.LCFCCS$7.SideBarSide));
                __builder.AddComponentParameter(3, "bar-class", "pd bg-card shadow");
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "bdb pd");
                    __builder2.OpenElement(7, "div");
                    __builder2.AddAttribute$5(8, "class", "row");
                    __builder2.AddMarkupContent(9, "<div class=\"col-a\"><div class=\"hx-1 wx-1 round shadow bd flex\"><i class=\"mdi mdi-account cl-primary fsz-80 mg-a\"></i></div></div>\r\n                ");
                    __builder2.OpenElement(10, "div");
                    __builder2.AddAttribute$5(11, "class", "pdl");
                    __builder2.OpenElement(12, "div");
                    __builder2.AddAttribute$5(13, "class", "row");
                    __builder2.OpenElement(14, "div");
                    __builder2.AddMarkupContent(15, "<h2 class=\"cl-primary nowrap mgt-1 mgb-3 text-italics\">Hello Sandra</h2>\r\n                            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 16);
                    __builder2.AddAttribute$3(17, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 18);
                            __builder3.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 20);
                                    __builder4.AddComponentParameter(21, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Error));
                                    __builder4.AddAttribute$3(22, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddMarkupContent(23, "<i class=\"mdi mdi-star\"></i> 12");
                                    }), $yRKEGj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $ZjJUjc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":649656,"h":0,"f":17825794});
                            }), $VIisZi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":649656,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(24, "\r\n                                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 25);
                            __builder3.AddAttribute$3(26, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 27);
                                    __builder4.AddComponentParameter(28, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder4.AddAttribute$3(29, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddMarkupContent(30, "<i class=\"mdi mdi-star\"></i> 12");
                                    }), $KCxqCk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $PHSiVd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":649656,"h":0,"f":17825794});
                            }), $isxOYe ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":649656,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $atVUyh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":649656,"h":0,"f":17825794});
                    }), $XtQWNe ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":649656,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(31, "\r\n                        ");
                    __builder2.OpenElement(32, "div");
                    __builder2.AddAttribute$5(33, "class", "col-a");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 34);
                    __builder2.AddComponentParameter(35, "Class", "mdi mdi-logout");
                    __builder2.AddComponentParameter(36, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(37, "\r\n                    ");
                    __builder2.AddMarkupContent(38, "<b class=\"mgt d-block\">What woud you like to do today?</b>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(39, "\r\n\r\n        ");
                    __builder2.OpenElement(40, "div");
                    __builder2.AddAttribute$5(41, "class", "row responsive");
                    __builder2.OpenElement(42, "div");
                    __builder2.AddAttribute$5(43, "class", "col-5 mawx-3 pd");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 44);
                    __builder2.AddComponentParameter(45, "Class", "text-center");
                    __builder2.AddAttribute$3(46, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(47, "<i class=\"mdi mdi-package fsz-80 d-block mg-a cl-blueviolet\"></i>\r\n                    ");
                        __builder3.AddMarkupContent(48, "<h3 class=\"nowrap mgy-1\">Dispatch item(s)</h3>\r\n                    ");
                        __builder3.AddMarkupContent(49, "<span class=\"op-7\">2000 riders available</span>");
                    }), $qKFxAb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(50, "\r\n            ");
                    __builder2.OpenElement(51, "div");
                    __builder2.AddAttribute$5(52, "class", "col-5 mawx-3 pd");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 53);
                    __builder2.AddComponentParameter(54, "Class", "text-center");
                    __builder2.AddAttribute$3(55, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(56, "<i class=\"mdi mdi-map-marker-path fsz-80 d-block mg-a cl-info\"></i>\r\n                    ");
                        __builder3.AddMarkupContent(57, "<h3 class=\"nowrap mgy-1\">Track a dispatch</h3>\r\n                    ");
                        __builder3.AddMarkupContent(58, "<span class=\"op-7\">2 Items enroute</span>");
                    }), $DKTZWi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(59, "\r\n            ");
                    __builder2.OpenElement(60, "div");
                    __builder2.AddAttribute$5(61, "class", "col-5 mawx-3 pd");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 62);
                    __builder2.AddComponentParameter(63, "Class", "text-center");
                    __builder2.AddAttribute$3(64, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(65, "<i class=\"mdi mdi-bike fsz-80 d-block mg-a cl-message\"></i>\r\n                    ");
                        __builder3.AddMarkupContent(66, "<h3 class=\"nowrap mgy-1\">Be a dispatcher</h3>\r\n                    ");
                        __builder3.AddMarkupContent(67, "<span class=\"op-7\">Dispatch and earn</span>");
                    }), $uDwlPa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(68, "\r\n            ");
                    __builder2.OpenElement(69, "div");
                    __builder2.AddAttribute$5(70, "class", "col-5 mawx-3 pd");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 71);
                    __builder2.AddComponentParameter(72, "Class", "text-center");
                    __builder2.AddAttribute$3(73, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(74, "<i class=\"mdi mdi-share fsz-80 d-block mg-a cl-warning\"></i>\r\n                    ");
                        __builder3.AddMarkupContent(75, "<h3 class=\"nowrap mgy-1\">Refer a friend</h3>\r\n                    ");
                        __builder3.AddMarkupContent(76, "<span class=\"op-7\">Share and earn</span>");
                    }), $pMvbOj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(77, "\r\n        ");
                    $.$oUrI._LCSCSA.TypeInference.CreateDataList_0($.$$.S.Int32, __builder2, 78, 79, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [1, 2, 3, 4], null, null), 80, 2, 81, 35184372092928n | 8388608n, 82, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Int32, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Int32))))().$ctor(this,  (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 83);
                            __builder3.AddComponentParameter(84, "Icon", "mdi mdi-bike");
                            __builder3.AddComponentParameter(85, "Title", "Package 1234");
                            __builder3.AddComponentParameter(86, "Description", "Dispatch is 50m away from delivery. ETA 2m");
                            __builder3.AddComponentParameter(87, "icon-class", "cl-warning");
                            __builder3.CloseComponent();
                        }, $XuuOzg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":649656,"h":0,"f":17825794});
                    }, $UBmjye ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Int32, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Int32)).$h}],"n":"","d":649656,"h":0,"f":17825794}));
                }), $lvyufe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                __builder.AddAttribute$3(88, "Bar", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(89, "<div class=\"row\"><div class=\"col-a\"><i class=\"mdi mdi-comment-question cl-info fsz-20 mgr\"></i></div>\r\n            <div><h3 class=\"mg-0\">Did you know</h3></div></div>\r\n        ");
                    __builder2.AddMarkupContent(90, "<p class=\"fsz-small mgt-1 mgb-0\">\r\n            Dispatchers using GPS tracking systems get more jobs on iLogistics than their counterparts.\r\n            Customers prefer to know the location and ETA of their goods at all times.\r\n        </p>");
                }), $IEzGPj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":649656,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590584248)
            
            //--TRIMMABLE-BOUNDARY-START(4295616952)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295616952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295616952)
            
            //--TRIMMABLE-BOUNDARY-START(4295616952)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295616952)
            
            static $h = 649656;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590584248),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 649656,
      "h": 8590584248,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590584248)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295616952),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 649656,
      "h": 4295616952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295616952)
  ],
  "h": 649656
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Shared.AppDispatchHome`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}AppDispatchHome`; }
        });
        //--TRIMMABLE-BOUNDARY-END(649656)
        
        

        //--TRIMMABLE-BOUNDARY-START(321976)
        $asm.$cls(`$oUrI.LCSCPD.AppShell`, ($self) => class AppShell extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(34360060344)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(34360060344)
            
            //--TRIMMABLE-BOUNDARY-START(25770125752)
            /*IApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(25770125752)
            
            //--TRIMMABLE-BOUNDARY-START(30065093048)
            /*EventHandler*/ ApplicationRendered = null;
            //--TRIMMABLE-BOUNDARY-END(30065093048)
            
            //--TRIMMABLE-BOUNDARY-START(30065093048)
            //--TRIMMABLE-BOUNDARY-START(21475158456)
            add_ApplicationRendered(/*EventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475158456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Combine$2(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475158456)
            
            //--TRIMMABLE-BOUNDARY-START(73014766008)
            remove_ApplicationRendered(/*EventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014766008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Remove(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(73014766008)
            
            //--TRIMMABLE-BOUNDARY-END(30065093048)
            
            //--TRIMMABLE-BOUNDARY-START(64424831416)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424831416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "https://fonts.googleapis.com/css2?family=Raleway:wght@300&display=swap", this.ResolvePath("LivingThing.Core.Shipping.Client.css", true, false, false) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(64424831416)
            
            //--TRIMMABLE-BOUNDARY-START(60129864120)
            /*void */ OnAfterRender(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129864120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (firstRender)
                {
                    this.ApplicationRendered?.Invoke(this, $.$$.S.EventArgs.Empty);
                }
                super.OnAfterRender(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(60129864120)
            
            //--TRIMMABLE-BOUNDARY-START(38655027640)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655027640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCS$3.ServerConnection, 0);
                __builder.CloseComponent();
                __builder.AddMarkupContent(1, "\r\n\r\n    ");
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 2);
                __builder.AddComponentParameter(3, "InitialViewIndex", "2");
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 6);
                    __builder2.AddComponentParameter(7, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(8, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 0/*ApplicationPageFeatures.None*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$oUrI.LCSCS$1.AppDispatchSplashScreen, 10);
                            __builder3.CloseComponent();
                        }, $MEvcQa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":321976,"h":0,"f":17825794});
                    }), $PhFDed ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":321976,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(11, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 12);
                    __builder2.AddComponentParameter(13, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(14, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 0/*ApplicationPageFeatures.None*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(15, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$oUrI.LCSCS$1.AppDispatchHome, 16);
                            __builder3.CloseComponent();
                        }, $AeumNd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":321976,"h":0,"f":17825794});
                    }), $kmNVKe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":321976,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(17, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 18);
                    __builder2.AddComponentParameter(19, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(20, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(21, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(22, "Dispatch Items");
                        }, $bznHrb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":321976,"h":0,"f":17825794});
                    }), $BssBri ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":321976,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(23, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$oUrI.LCSCS$1.AppDispatchItems, 24);
                            __builder3.CloseComponent();
                        }, $gvnMtj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":321976,"h":0,"f":17825794});
                    }), $TqAZQf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":321976,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $nSopvd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":321976,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(25, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.Application = $.$cast(__value, $.$lJUR.LCFCS.Application);
                }, $AjSXMk ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":321976,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(38655027640)
            
            //--TRIMMABLE-BOUNDARY-START(25774862409)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.Application.get
            get LCFCS$IApplicationShell$Application()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889960521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Application;
            }
            //--TRIMMABLE-BOUNDARY-END(25774862409)
            
            //--TRIMMABLE-BOUNDARY-START(8594993225)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered.add
            LCFCS$IApplicationShell$add_ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594993225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_ApplicationRendered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8594993225)
            
            //--TRIMMABLE-BOUNDARY-START(34364797001)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered.remove
            LCFCS$IApplicationShell$remove_ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364797001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_ApplicationRendered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34364797001)
            
            //--TRIMMABLE-BOUNDARY-START(17184927817)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered
            LivingThing$Core$Frameworks$Client$SPA$IApplicationShell$ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184927817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered;
            }
            //--TRIMMABLE-BOUNDARY-END(17184927817)
            
            //--TRIMMABLE-BOUNDARY-START(12885223864)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885223864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885223864)
            
            //--TRIMMABLE-BOUNDARY-START(12885223864)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885223864)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360060344)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(34360060344)
                
            }
            static $h = 321976;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360060344),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834896824,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194635192,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 321976,
      "h": 34360060344,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360060344),
//--TRIMMABLE-BOUNDARY-START(25770125752),
    {
      "p": 4337737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244962232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604700600,
        "f": 83886081
      },
      "n": "Application",
      "d": 321976,
      "h": 25770125752,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770125752)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424831416),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 321976,
      "h": 64424831416,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64424831416),
//--TRIMMABLE-BOUNDARY-START(60129864120),
    {
      "r": 65537,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRender",
      "d": 321976,
      "h": 60129864120,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60129864120),
//--TRIMMABLE-BOUNDARY-START(38655027640),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 321976,
      "h": 38655027640,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655027640)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885223864),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 321976,
      "h": 12885223864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885223864)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(30065093048),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_ApplicationRendered",
        "d": 321976,
        "h": 21475158456,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_ApplicationRendered",
        "d": 321976,
        "h": 73014766008,
        "f": 285212673
      },
      "n": "ApplicationRendered",
      "d": 321976,
      "h": 30065093048,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(30065093048)
  ],
  "h": 321976,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Dispatch",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationShell ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Pages.Dispatch.AppShell`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Pages${separator}Dispatch${separator}AppShell`; }
        });
        //--TRIMMABLE-BOUNDARY-END(321976)
        
        

        //--TRIMMABLE-BOUNDARY-START(977336)
        $asm.$cls(`$oUrI.LCSCS$1.ShipmentPackage<,>`, (TShipmentPackageModel, TShipmentProductModel) => $asm.$gt(`$oUrI.LCSCS$1.ShipmentPackage<,>`, [TShipmentPackageModel, TShipmentProductModel], ($self) => class ShipmentPackage$$$ extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TShipmentPackageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(240519145912)
            /*IShipmentTrackingProvider*/ ShipmentTrackingProvider = null;
            //--TRIMMABLE-BOUNDARY-END(240519145912)
            
            //--TRIMMABLE-BOUNDARY-START(163209734584)
            /*IShipmentDashboardResolver<TShipmentPackageModel, TShipmentProductModel>*/ Resolver = null;
            //--TRIMMABLE-BOUNDARY-END(163209734584)
            
            //--TRIMMABLE-BOUNDARY-START(236224178616)
            /*IShipmentModel*/ Shipment = null;
            //--TRIMMABLE-BOUNDARY-END(236224178616)
            
            //--TRIMMABLE-BOUNDARY-START(51540584888)
            /*bool*/ CanEdit = false;
            //--TRIMMABLE-BOUNDARY-END(51540584888)
            
            //--TRIMMABLE-BOUNDARY-START(167504701880)
            /*double*/ ScalePrice = 0;
            //--TRIMMABLE-BOUNDARY-END(167504701880)
            
            //--TRIMMABLE-BOUNDARY-START(115965094328)
            /*Pager<TShipmentProductModel> */ GetProducts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965094328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.LCSCM$IShipmentPackageModel$Products !== null)
                {
                    return $.$fPer.LCFCD.Paging.GetPager(TShipmentProductModel, ($.$cast(this.ViewModel.LCSCM$IShipmentPackageModel$Products, $.$$.SCG.IEnumerable$$(TShipmentProductModel))), null);
                }
                return this.Resolver[`LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$GetProductsInPackage`](this.ViewModel);
            }
            //--TRIMMABLE-BOUNDARY-END(115965094328)
            
            //--TRIMMABLE-BOUNDARY-START(120260061624)
            /*int */ GetQuantity(/*IShipmentProductModel*/ product)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260061624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Single($.$YUlm.LCSCM.IShipmentProductModel, this.ViewModel.LCSCM$IShipmentPackageModel$Products, new ($.$$.S.Func$$$($.$YUlm.LCSCM.IShipmentProductModel, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.LCFCD$IIded$Identifier.Equals$2(product.LCFCD$IIded$Identifier);
                }, $wkjkzb ??= {"r":262145,"p":[{"n":"o","p":1083513}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).LCSCM$IShipmentProductModel$Quantity;
            }
            //--TRIMMABLE-BOUNDARY-END(120260061624)
            
            //--TRIMMABLE-BOUNDARY-START(231929211320)
            /*ValueTask *//*async*/  Ship()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231929211320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                });
            }
            //--TRIMMABLE-BOUNDARY-END(231929211320)
            
            //--TRIMMABLE-BOUNDARY-START(124555028920)
            /*Money */ GetTotalAmount(/*IEnumerable<TShipmentProductModel>*/ products)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555028920);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$fPer.LCFCDM.Money().$ctor$3($.$sl.SL.Enumerable.Sum$16(TShipmentProductModel, products, new ($.$$.S.Func$$$(TShipmentProductModel, $.$$.S.Double))().$ctor(this,  (/*it*/ it) =>
                    {
                        return $.$fPer.LCFCDM.Money.op_Implicit($.$fPer.LCFCDM.Money.op_Multiply(it.LCSCM$IShipmentProductModel$Cost, it.LCSCM$IShipmentProductModel$Quantity));
                    }, $epIqrf ??= {"r":1179649,"p":[{"n":"it","p":TShipmentProductModel?.$h??1638400}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) * this.ScalePrice, 1/*MoneyUnitTypes.Naira*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555028920)
            
            //--TRIMMABLE-BOUNDARY-START(137439930808)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(137439930808)
            
            //--TRIMMABLE-BOUNDARY-START(133144963512)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(133144963512)
            
            //--TRIMMABLE-BOUNDARY-START(150324832696)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(150324832696)
            
            //--TRIMMABLE-BOUNDARY-START(150324832696)
            //--TRIMMABLE-BOUNDARY-START(42950650296)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950650296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(42950650296)
            
            //--TRIMMABLE-BOUNDARY-START(158914767288)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914767288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(158914767288)
            
            //--TRIMMABLE-BOUNDARY-END(150324832696)
            
            //--TRIMMABLE-BOUNDARY-START(244814113208)
            /*WizardSteps?*/ steps = null;
            //--TRIMMABLE-BOUNDARY-END(244814113208)
            
            //--TRIMMABLE-BOUNDARY-START(249109080504)
            /*void */ WizardStep(/*ViewChangingEventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109080504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args.From === 0 && this.ViewModel.LCSCM$IShipmentPackageModel$DatePaid === null)
                {
                    throw new $.$$.S.Exception().$ctor$4("Order has not been paid for");
                }
                if (args.From === 1 && args.To > 1 && this.Shipment === null)
                {
                    throw new $.$$.S.Exception().$ctor$4("Awaiting shipment");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249109080504)
            
            //--TRIMMABLE-BOUNDARY-START(146029865400)
            /*ValueTask *//*async*/  Pay(/*double*/ amount)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029865400);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let paymentResult = ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment($.$fPer.LCFCDM.Money.op_Implicit$1(amount), this.ViewModel.LCFC$IDisplayable$Title, $.$strNN($.$strNN($.$dspc(this.ViewModel.LCFCD$IIded$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)) + "/") + $.$strNN($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.DateTime.UtcNow.ToString(), "/", "_"), " ", "_"), ":", "_")), this.ViewModel.LCFC$IDescribable$Description, null, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = this.Resolver[`LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$UpdatePackagePaid`](this.ViewModel, paymentResult.Reference), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Shipping.Client.Blazor\\ShipmentPackage.razor.cs", "Pay", 80), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    ($t4 = this.steps.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(146029865400)
            
            //--TRIMMABLE-BOUNDARY-START(141734898104)
            /*ValueTask *//*async*/  Paid(/*string*/ referenceNumber)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734898104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                });
            }
            //--TRIMMABLE-BOUNDARY-END(141734898104)
            
            //--TRIMMABLE-BOUNDARY-START(128849996216)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849996216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(128849996216)
            
            //--TRIMMABLE-BOUNDARY-START(47245617592)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245617592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 0);
                __builder.AddComponentParameter(1, "InitialViewIndex", "0");
                __builder.AddComponentParameter(2, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, (3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/) | 4/*WizardFeatures.Progress*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                __builder.AddComponentParameter(3, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$mac.MAC.EventCallback.Factory.Create$8($.$hDPm.LCFCCM$6.ViewChangingEventArgs, this, new ($.$$.S.Action$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs))().$ctor(this, this.WizardStep))));
                __builder.AddComponentParameter(4, "toolbar-class", "bdb");
                __builder.AddComponentParameter(5, "head-class", "bdt bdb bg-card");
                __builder.AddAttribute$3(6, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 7);
                    __builder2.AddComponentParameter(8, "Class", "hf");
                    __builder2.AddAttribute$3(9, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(10, "\r\n                Payment\r\n            ");
                        }, $khIDti ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $oNApkg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(11, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(TShipmentProductModel), 12);
                            __builder3.AddComponentParameter(13, "Selectable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder3.AddComponentParameter(14, "Class", "mgb-20");
                            __builder3.AddComponentParameter(15, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 16777216n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(16, "Pager", (this.GetProducts()));
                            __builder3.AddComponentParameter(17, "li-class", "pdy-2 mihx-15");
                            __builder3.AddComponentParameter(18, "defer-class", "mihx-15");
                            __builder3.AddAttribute$3(19, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 20);
                                __builder4.AddComponentParameter(21, "Message", "Your products is empty");
                                __builder4.AddComponentParameter(22, "Class", "mgy");
                                __builder4.CloseComponent();
                            }), $FEaJGd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(23, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel))))().$ctor(this, ( (/*item*/ item) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    /*var*/ let view = this.Resolver[`LCSCS$IShipmentDashboardResolver$$$$GetView$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$1`](item.Model);
                                    if (view !== null)
                                    {
                                        __builder4.AddContent$1(24, view);
                                    }
                                    else 
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 25);
                                        __builder4.AddComponentParameter(26, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, item.Model.LCFC$IDisplayable$Title));
                                        __builder4.AddComponentParameter(27, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, item.Model.LCFC$IDescribable$Description));
                                        __builder4.AddComponentParameter(28, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, item.Model.LCSCM$IShipmentProductModel$Cost) ? `${$.$strNN(item.Model.LCSCM$IShipmentProductModel$Quantity)} * ${$.$strNN($.$fPer.LCFCDM.Money.op_Multiply(item.Model.LCSCM$IShipmentProductModel$Cost, this.ScalePrice).ToString())}` : "Unknown Cost"));
                                        __builder4.AddComponentParameter(29, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, item.Model.LCFC$IDisplayable$Icon));
                                        __builder4.AddComponentParameter(30, "NavigateIcon", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                        __builder4.AddComponentParameter(31, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, item.Model.LCSCM$IShipmentProductModel$Link));
                                        __builder4.AddComponentParameter(32, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                                        __builder4.CloseComponent();
                                    }
                                }, $DderJf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $BFwKIg ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(33, "Footer", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)))))().$ctor(this, ( (/*items*/ items) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    if (this.CanEdit)
                                    {
                                        if (items !== null && this.ViewModel.LCSCM$IShipmentPackageModel$DatePaid === null)
                                        {
                                            /*var*/ let hasNoPrice = $.$sl.SL.Enumerable.Any($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)), items, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)), $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                                            {
                                                return p.Data.LCSCM$IShipmentProductModel$Cost.Value === 0;
                                            }, $WBXfhd ??= {"r":262145,"p":[{"n":"p","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder4.OpenElement(34, "div");
                                            __builder4.AddAttribute$5(35, "class", "pd bg-card pos-fix b-0 l-0 r-0");
                                            if (hasNoPrice)
                                            {
                                                __builder4.AddMarkupContent(36, "<em>Some items does not have a valid cost yet. Payment is disabled!!!</em>");
                                            }
                                            else 
                                            {
                                                /*var*/ let amount = $.$sl.SL.Enumerable.Sum$16($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)), items, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)), $.$$.S.Double))().$ctor(this,  (/*p*/ p) =>
                                                {
                                                    return p.Data.LCSCM$IShipmentProductModel$Cost.Naira.Value * p.Data.LCSCM$IShipmentProductModel$Quantity;
                                                }, $EZdzca ??= {"r":1179649,"p":[{"n":"p","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) * this.ScalePrice;
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$$.S.Double), 37);
                                                __builder4.AddComponentParameter(38, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, amount), $.$$.S.Double));
                                                __builder4.AddComponentParameter(39, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Double), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$$.S.Double, $.$mac.MAC.EventCallback.Factory, this, $.$hDPm.LCFCC$1.BaseComponent.NoStateChanged$5($.$$.S.Double, new ($.$$.S.Func$$$($.$$.S.Double, $.$$.STT.ValueTask))().$ctor(this, this.Pay)))));
                                                __builder4.AddComponentParameter(40, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                                __builder4.AddComponentParameter(41, "Class", "wf");
                                                __builder4.AddAttribute$3(42, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddMarkupContent(43, "\r\n                                            Pay ");
                                                    __builder5.AddContent$3(44, (() =>
                                                    {
                                                        //new $.$fPer.LCFCDM.Money()
                                                        const $t5 = $.$fPer.LCFCDM.Money;
                                                        const $i5 = new $t5();
                                                        $i5.$ctor$2();
                                                        $i5.Value = amount;
                                                        $i5.Unit = 1/*MoneyUnitTypes.Naira*/;
                                                        return $i5;
                                                    })());
                                                }), $lUuZok ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }
                                            __builder4.CloseElement();
                                        }
                                    }
                                }, $YmjVmj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $SmJImj ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentProductModel))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $ObxnQe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $wZibcj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(45, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 46);
                    __builder2.AddAttribute$3(47, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(48, "\r\n                Progress\r\n            ");
                        }, $ctBEDg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $zXWmKe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(49, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$$.SCG.IEnumerable$$(TShipmentProductModel)), 50);
                            __builder3.AddComponentParameter(51, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TShipmentProductModel)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))), $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TShipmentProductModel)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TShipmentProductModel)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))), $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TShipmentProductModel)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))).op_Implicit$2(new ($.$$.S.Func$$($.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))))().$ctor(this, ( () =>
                            {
                                return this.GetProducts().Invoke(new $.$fPer.LCFCD.DataFilter().$ctor$1()).AsTask().ContinueWith$47($.$$.SCG.IEnumerable$$(TShipmentProductModel), new ($.$$.S.Func$$$($.$$.STT.Task$$($.$fPer.LCFCD.PagingDataResult$$(TShipmentProductModel)), $.$$.SCG.IEnumerable$$(TShipmentProductModel)))().$ctor(this,  (/*t*/ t) =>
                                {
                                    return t.Result.Data;
                                }, $BFHGUk ??= {"r":$.$$.SCG.IEnumerable$$(TShipmentProductModel).$h,"p":[{"n":"t","p":$.$$.STT.Task$$($.$fPer.LCFCD.PagingDataResult$$(TShipmentProductModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            }), $XVuDfl ??= {"r":$.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TShipmentProductModel)).$h,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                            __builder3.AddAttribute$3(52, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$(TShipmentProductModel))))().$ctor(this, ( (/**/ products) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLines, 53);
                                    __builder4.AddComponentParameter(54, "Class", "pd");
                                    __builder4.AddComponentParameter(55, "Style", "margin-left:-80%");
                                    __builder4.AddAttribute$3(56, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        if (this.ViewModel.LCSCM$IShipmentPackageModel$DatePaid !== null)
                                        {
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 57);
                                            __builder5.AddAttribute$3(58, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                            {
                                                __builder6.OpenElement(59, "h4");
                                                __builder6.AddAttribute$5(60, "class", "mg-0");
                                                __builder6.AddContent$4(61, "Paid ");
                                                __builder6.AddContent$3(62, this.GetTotalAmount(products.Data));
                                                __builder6.CloseElement();
                                                __builder6.AddMarkupContent(63, "\r\n                                ");
                                                __builder6.OpenElement(64, "small");
                                                __builder6.AddContent$3(65, this.ViewModel.LCSCM$IShipmentPackageModel$DatePaid);
                                                __builder6.CloseElement();
                                            }), $KNMtal ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            if (this.Shipment !== null)
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 66);
                                                __builder5.AddAttribute$3(67, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddMarkupContent(68, "<h4 class=\"mg-0\">Shipped out</h4>\r\n                                    ");
                                                    __builder6.OpenElement(69, "small");
                                                    __builder6.AddContent$3(70, this.Shipment.LCFCD$IEntryDataModel$DateCreated);
                                                    __builder6.CloseElement();
                                                    __builder6.AddMarkupContent(71, "\r\n                                    ");
                                                    __builder6.OpenElement(72, "div");
                                                    __builder6.AddAttribute$5(73, "class", "hx-3 mgy");
                                                    __builder6.AddContent$1(74, this.ShipmentTrackingProvider.LCSCS$IShipmentTrackingProvider$Track(this.Shipment));
                                                    __builder6.CloseElement();
                                                }), $ZmvlHf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                                if (this.Shipment.LCSCM$IShipmentModel$State !== 5/*ShipmentState.Delivered*/)
                                                {
                                                    __builder5.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 75);
                                                    __builder5.AddAttribute$3(76, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                    {
                                                        __builder6.AddMarkupContent(77, "<h4 class=\"op-7 mg-0\">Awaiting Delivery</h4>");
                                                    }), $AAjVma ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                    __builder5.CloseComponent();
                                                }
                                            }
                                            else 
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 78);
                                                __builder5.AddAttribute$3(79, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddMarkupContent(80, "<h4 class=\"mg-0\">Processing Order</h4>");
                                                }), $IQeKca ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                            }
                                        }
                                    }), $ZnCaPk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $czdYOj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $SdOjzc ??= {"r":6881395,"p":[{"n":"products","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$(TShipmentProductModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $ktJvUb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $oABXNi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(81, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 82);
                    __builder2.AddAttribute$3(83, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(84, "\r\n                Confirm\r\n            ");
                        }, $HaBRha ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $xLGjBb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $lcQcFa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(85, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.steps = $.$cast(__value, $.$hDPm.LCFCCW$1.WizardSteps);
                }, $SmJSDc ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(47245617592)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(34360715704)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360715704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360715704)
            
            //--TRIMMABLE-BOUNDARY-START(34360715704)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(34360715704)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(240519145912)
                this.ShipmentTrackingProvider = null;
                //--TRIMMABLE-BOUNDARY-END(240519145912)
                
                //--TRIMMABLE-BOUNDARY-START(167504701880)
                this.ScalePrice = 1;
                //--TRIMMABLE-BOUNDARY-END(167504701880)
                
                //--TRIMMABLE-BOUNDARY-START(137439930808)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(137439930808)
                
            }
            static $H = 977336;
            static $h = 977336;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$(TShipmentPackageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(240519145912),
    {
      "p": 518584,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111670127032,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 227634244024,
        "h": Number(BigInt(this.$h)|0x3500000000n),
        "f": 83886081
      },
      "n": "ShipmentTrackingProvider",
      "d": this.$h,
      "H": 240519145912,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240519145912),
//--TRIMMABLE-BOUNDARY-START(163209734584),
    {
      "p": $.$oUrI.LCSCS.IShipmentDashboardResolver$$$(TShipmentPackageModel, TShipmentProductModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85900323256,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 201864440248,
        "h": Number(BigInt(this.$h)|0x2F00000000n),
        "f": 83886081
      },
      "n": "Resolver",
      "d": this.$h,
      "H": 163209734584,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209734584),
//--TRIMMABLE-BOUNDARY-START(236224178616),
    {
      "p": 821369,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103080192440,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 219044309432,
        "h": Number(BigInt(this.$h)|0x3300000000n),
        "f": 83886081
      },
      "n": "Shipment",
      "d": this.$h,
      "H": 236224178616,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236224178616),
//--TRIMMABLE-BOUNDARY-START(51540584888),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60130519480,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 176094636472,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 83886081
      },
      "n": "CanEdit",
      "d": this.$h,
      "H": 51540584888,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540584888),
//--TRIMMABLE-BOUNDARY-START(167504701880),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94490257848,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 210454374840,
        "h": Number(BigInt(this.$h)|0x3100000000n),
        "f": 83886081
      },
      "n": "ScalePrice",
      "d": this.$h,
      "H": 167504701880,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504701880),
//--TRIMMABLE-BOUNDARY-START(137439930808),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77310388664,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 193274505656,
        "h": Number(BigInt(this.$h)|0x2D00000000n),
        "f": 83886081
      },
      "n": "Loading",
      "d": this.$h,
      "H": 137439930808,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439930808),
//--TRIMMABLE-BOUNDARY-START(133144963512),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68720454072,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 184684571064,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": this.$h,
      "H": 133144963512,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144963512)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115965094328),
    {
      "r": $.$fPer.LCFCD.Pager$$(TShipmentProductModel).$h,
      "n": "GetProducts",
      "d": this.$h,
      "H": 115965094328,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115965094328),
//--TRIMMABLE-BOUNDARY-START(120260061624),
    {
      "r": 655361,
      "p": [
        {
          "n": "product",
          "p": 1083513
        }
      ],
      "n": "GetQuantity",
      "d": this.$h,
      "H": 120260061624,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260061624),
//--TRIMMABLE-BOUNDARY-START(231929211320),
    {
      "r": 181338113,
      "n": "Ship",
      "d": this.$h,
      "H": 231929211320,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(231929211320),
//--TRIMMABLE-BOUNDARY-START(124555028920),
    {
      "r": 27822422,
      "p": [
        {
          "n": "products",
          "p": $.$$.SCG.IEnumerable$$(TShipmentProductModel).$h
        }
      ],
      "n": "GetTotalAmount",
      "d": this.$h,
      "H": 124555028920,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555028920),
//--TRIMMABLE-BOUNDARY-START(249109080504),
    {
      "r": 65537,
      "p": [
        {
          "n": "args",
          "p": 38098602
        }
      ],
      "n": "WizardStep",
      "d": this.$h,
      "H": 249109080504,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249109080504),
//--TRIMMABLE-BOUNDARY-START(146029865400),
    {
      "r": 181338113,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "Pay",
      "d": this.$h,
      "H": 146029865400,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(146029865400),
//--TRIMMABLE-BOUNDARY-START(141734898104),
    {
      "r": 181338113,
      "p": [
        {
          "n": "referenceNumber",
          "p": 1310721
        }
      ],
      "n": "Paid",
      "d": this.$h,
      "H": 141734898104,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(141734898104),
//--TRIMMABLE-BOUNDARY-START(128849996216),
    {
      "r": 181338113,
      "n": "Load",
      "d": this.$h,
      "H": 128849996216,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849996216),
//--TRIMMABLE-BOUNDARY-START(47245617592),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 47245617592,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245617592)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(244814113208),
    {
      "t": 59004586,
      "n": "steps",
      "d": this.$h,
      "H": 244814113208,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(244814113208)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360715704),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 34360715704,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360715704)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(150324832696),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 42950650296,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 158914767288,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": this.$h,
      "H": 150324832696,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(150324832696)
  ],
  "s": [
    {
      "h": TShipmentPackageModel?.$h??1572864,
      "n": "TShipmentPackageModel",
      "c": [952441
      ]
    },
    {
      "h": TShipmentProductModel?.$h??1638400,
      "n": "TShipmentProductModel",
      "c": [1083513
      ]
    }
  ],
  "r": 2,
  "H": 977336,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Shared.ShipmentPackage<${TShipmentPackageModel?.$fullName},${TShipmentProductModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}ShipmentPackage$${TShipmentPackageModel?.$getFullName(separator)}$${TShipmentProductModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(977336)
        
        

        //--TRIMMABLE-BOUNDARY-START(1042872)
        $asm.$cls(`$oUrI.LCSCS$1.ShipmentPackages<,>`, (TShipmentPackageModel, TShipmentProductModel) => $asm.$gt(`$oUrI.LCSCS$1.ShipmentPackages<,>`, [TShipmentPackageModel, TShipmentProductModel], ($self) => class ShipmentPackages$$$ extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$$.SCG.IEnumerable$$(TShipmentPackageModel))
        {
            //--TRIMMABLE-BOUNDARY-START(94490323384)
            /*IShippingService*/ ShippingService = null;
            //--TRIMMABLE-BOUNDARY-END(94490323384)
            
            //--TRIMMABLE-BOUNDARY-START(25770846648)
            /*bool*/ EnableMasterDetails = false;
            //--TRIMMABLE-BOUNDARY-END(25770846648)
            
            //--TRIMMABLE-BOUNDARY-START(64425552312)
            /*IShipmentDashboardResolver<TShipmentPackageModel, TShipmentProductModel>*/ Resolver = null;
            //--TRIMMABLE-BOUNDARY-END(64425552312)
            
            //--TRIMMABLE-BOUNDARY-START(55835617720)
            /*Pager<TShipmentPackageModel> */ GetPackages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835617720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel !== null)
                {
                    return $.$fPer.LCFCD.Paging.GetPager(TShipmentPackageModel, this.ViewModel, null);
                }
                return this.Resolver[`LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$GetShipmentPackages`]();
            }
            //--TRIMMABLE-BOUNDARY-END(55835617720)
            
            //--TRIMMABLE-BOUNDARY-START(60130585016)
            /*IShipmentModel */ GetShipment(/*TShipmentPackageModel*/ $package)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130585016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(60130585016)
            
            //--TRIMMABLE-BOUNDARY-START(21475879352)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475879352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCM$2.MasterDetailsSelection$$(TShipmentPackageModel), 0);
                __builder.AddComponentParameter(1, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                __builder.AddComponentParameter(2, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.EnableMasterDetails), $.$$.S.Boolean));
                __builder.AddComponentParameter(3, "content-class", "miwx-3 bdr");
                __builder.AddAttribute$3(4, "Master", new ($.$mac.MAC.RenderFragment$$(TShipmentPackageModel))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(TShipmentPackageModel), 5);
                        __builder2.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                        __builder2.AddComponentParameter(7, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(8, "Pager", (this.GetPackages()));
                        __builder2.AddComponentParameter(9, "li-class", "pd");
                        __builder2.AddAttribute$3(10, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentPackageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentPackageModel))))().$ctor(this, ( (/*order*/ order) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                /*var*/ let view = this.Resolver[`LCSCS$IShipmentDashboardResolver$${TShipmentPackageModel.$getFullName('$')}$${TShipmentProductModel.$getFullName('$')}$GetView`](order.Model);
                                if (view !== null)
                                {
                                    __builder3.AddContent$1(11, view);
                                }
                                else 
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 12);
                                    __builder3.AddComponentParameter(13, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, !$.$$.S.String.IsNullOrEmpty(order.Model.LCFC$INamed$Name) ? order.Model.LCFC$INamed$Name : `Order ${$.$strNN($.$$.S.String.Replace$3.call($.$dspc(order.Model.LCFCD$IIded$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString), "-", ""))}`));
                                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Shipping.Common.Models.IShipmentProductModel>?*/ let __ca1__;
                                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Shipping.Common.Models.IShipmentProductModel>?*/ let __ca2__;
                                    __builder3.AddComponentParameter(14, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN(((__ca1__ = order.Model.LCSCM$IShipmentPackageModel$Products) !== null ? $.$sl.SL.Enumerable.Sum$17($.$YUlm.LCSCM.IShipmentProductModel, __ca1__, new ($.$$.S.Func$$$($.$YUlm.LCSCM.IShipmentProductModel, $.$$.S.Int32))().$ctor(this,  (/*o*/ o) =>
                                    {
                                        return o.LCSCM$IShipmentProductModel$Quantity;
                                    }, $VNQAoc ??= {"r":655361,"p":[{"n":"o","p":1083513}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) : 0))} items, ${$.$strNN(((__ca2__ = order.Model.LCSCM$IShipmentPackageModel$Products) !== null ? $.$sl.SL.Enumerable.Count$1($.$YUlm.LCSCM.IShipmentProductModel, __ca2__) : 0))} distinct products`));
                                    /*LivingThing.Core.Shipping.Common.Models.IShipmentModel*/ let __ca3__;
                                    /*string*/ let __ca4__;
                                    __builder3.AddComponentParameter(15, "_Description", `At ${$.$strNN($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(order.Model.LCFCD$IEntryDataModel$DateCreated).ToString$3("HH:mm tt dd/MM/yyyy"))}, ${$.$strNN(((__ca3__ = this.GetShipment(order.Model)) !== null ? ((__ca4__ = $.$$.S.Enum.ToStringT($.$YUlm.LCSCM.ShipmentState, $.$$.S.UInt32, __ca3__.LCSCM$IShipmentModel$State)) !== null ? $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(__ca4__) : null) : null))}`);
                                    __builder3.AddComponentParameter(16, "_Image", "product.Images.First()");
                                    __builder3.AddComponentParameter(17, "NavigateIcon", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                    __builder3.AddComponentParameter(18, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, order.Model.LCSCM$IShipmentPackageModel$Link));
                                    __builder3.AddComponentParameter(19, "LinkParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, $.$box(order.Model, TShipmentPackageModel)));
                                    __builder3.AddComponentParameter(20, "imgw-class", "mg-a round clip flex hx-05 wx-05");
                                    __builder3.AddComponentParameter(21, "img-class", "mg-a mawp-10 mahp-10");
                                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder3, 22, "onclick", order.Model.LCSCM$IShipmentPackageModel$Link !== null);
                                    __builder3.AddAttribute$3(23, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenElement(24, "div");
                                        __builder4.AddAttribute$5(25, "class", "row fsz-small mgt-2 op-8");
                                        __builder4.OpenElement(26, "div");
                                        __builder4.AddAttribute$5(27, "class", "col-10");
                                        __builder4.AddContent$4(28, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(order.Model.LCFCD$IEntryDataModel$DateCreated).ToString$3("HH:mm tt dd/MM/yyyy"));
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(29, "\r\n                            ");
                                        __builder4.OpenElement(30, "div");
                                        __builder4.AddAttribute$5(31, "class", "col-a text-right cl-secondary");
                                        __builder4.OpenElement(32, "span");
                                        __builder4.AddAttribute$5(33, "class", "nowrap");
                                        /*LivingThing.Core.Shipping.Common.Models.IShipmentModel*/ let __ca5__;
                                        /*string*/ let __ca6__;
                                        __builder4.AddContent$4(34, ((__ca5__ = this.GetShipment(order.Model)) !== null ? ((__ca6__ = $.$$.S.Enum.ToStringT($.$YUlm.LCSCM.ShipmentState, $.$$.S.UInt32, __ca5__.LCSCM$IShipmentModel$State)) !== null ? $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(__ca6__) : null) : null));
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                    }), $RQTmYh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }
                            }, $LabDuf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $wZdPaj ??= {"r":6881395,"p":[{"n":"order","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$(TShipmentPackageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(TShipmentPackageModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(35, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 36);
                            __builder3.AddComponentParameter(37, "Message", "Your order is empty");
                            __builder3.AddComponentParameter(38, "Class", "mg");
                            __builder3.CloseComponent();
                        }), $BWiLie ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $FXqrGc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $AfnAza ??= {"r":6881395,"p":[{"n":"context","p":TShipmentPackageModel?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(39, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$(TShipmentPackageModel)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$oUrI.LCSCS$1.ShipmentPackage$$$(TShipmentPackageModel, TShipmentProductModel), 40);
                        __builder2.AddComponentParameter(41, "Resolver", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$oUrI.LCSCS.IShipmentDashboardResolver$$$(TShipmentPackageModel, TShipmentProductModel), this.Resolver));
                        __builder2.AddComponentParameter(42, "Shipment", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$YUlm.LCSCM.IShipmentModel, this.GetShipment(context.Model)));
                        __builder2.AddComponentParameter(43, "ViewModel", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(TShipmentPackageModel, context.Model), TShipmentPackageModel));
                        __builder2.SetKey($.$box(context.Model, TShipmentPackageModel));
                        __builder2.CloseComponent();
                    }, $IRjlCf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $hHqVHg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$(TShipmentPackageModel).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475879352)
            
            //--TRIMMABLE-BOUNDARY-START(17180912056)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180912056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180912056)
            
            //--TRIMMABLE-BOUNDARY-START(17180912056)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17180912056)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94490323384)
                this.ShippingService = null;
                //--TRIMMABLE-BOUNDARY-END(94490323384)
                
                //--TRIMMABLE-BOUNDARY-START(25770846648)
                this.EnableMasterDetails = true;
                //--TRIMMABLE-BOUNDARY-END(25770846648)
                
            }
            static $H = 1042872;
            static $h = 1042872;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$$.SCG.IEnumerable$$(TShipmentPackageModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94490323384),
    {
      "p": 2459769,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540650424,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 90195356088,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 83886081
      },
      "n": "ShippingService",
      "d": this.$h,
      "H": 94490323384,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490323384),
//--TRIMMABLE-BOUNDARY-START(25770846648),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360781240,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 73015486904,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 83886081
      },
      "n": "EnableMasterDetails",
      "d": this.$h,
      "H": 25770846648,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770846648),
//--TRIMMABLE-BOUNDARY-START(64425552312),
    {
      "p": $.$oUrI.LCSCS.IShipmentDashboardResolver$$$(TShipmentPackageModel, TShipmentProductModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950715832,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 81605421496,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 83886081
      },
      "n": "Resolver",
      "d": this.$h,
      "H": 64425552312,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425552312)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835617720),
    {
      "r": $.$fPer.LCFCD.Pager$$(TShipmentPackageModel).$h,
      "n": "GetPackages",
      "d": this.$h,
      "H": 55835617720,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835617720),
//--TRIMMABLE-BOUNDARY-START(60130585016),
    {
      "r": 821369,
      "p": [
        {
          "n": "package",
          "p": TShipmentPackageModel?.$h??1572864
        }
      ],
      "n": "GetShipment",
      "d": this.$h,
      "H": 60130585016,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130585016),
//--TRIMMABLE-BOUNDARY-START(21475879352),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 21475879352,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475879352)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180912056),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 17180912056,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180912056)
  ],
  "s": [
    {
      "h": TShipmentPackageModel?.$h??1572864,
      "n": "TShipmentPackageModel",
      "c": [952441
      ]
    },
    {
      "h": TShipmentProductModel?.$h??1638400,
      "n": "TShipmentProductModel",
      "c": [1083513
      ]
    }
  ],
  "r": 2,
  "H": 1042872,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Shared.ShipmentPackages<${TShipmentPackageModel?.$fullName},${TShipmentProductModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}ShipmentPackages$${TShipmentPackageModel?.$getFullName(separator)}$${TShipmentProductModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1042872)
        
        

        //--TRIMMABLE-BOUNDARY-START(846264)
        $asm.$cls(`$oUrI.LCSCS$1.Shipment<,>`, (TShipmentPackageModel, TShipmentProductModel) => $asm.$gt(`$oUrI.LCSCS$1.Shipment<,>`, [TShipmentPackageModel, TShipmentProductModel], ($self) => class Shipment$$$ extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$YUlm.LCSCM.IShipmentModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590780856)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590780856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$oUrI.LCSCS$1.ShipmentPackages$$$(TShipmentPackageModel, TShipmentProductModel), 0);
                __builder.AddComponentParameter(1, "_ViewModel", "ViewModel.Packages");
                __builder.AddComponentParameter(2, "Shipment", "ViewModel");
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590780856)
            
            //--TRIMMABLE-BOUNDARY-START(4295813560)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295813560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295813560)
            
            //--TRIMMABLE-BOUNDARY-START(4295813560)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295813560)
            
            static $H = 846264;
            static $h = 846264;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$YUlm.LCSCM.IShipmentModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590780856),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 8590780856,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590780856)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295813560),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4295813560,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295813560)
  ],
  "s": [
    {
      "h": TShipmentPackageModel?.$h??1572864,
      "n": "TShipmentPackageModel",
      "c": [952441
      ]
    },
    {
      "h": TShipmentProductModel?.$h??1638400,
      "n": "TShipmentProductModel",
      "c": [1083513
      ]
    }
  ],
  "r": 2,
  "H": 846264,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Shared.Shipment<${TShipmentPackageModel?.$fullName},${TShipmentProductModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Shared${separator}Shipment$${TShipmentPackageModel?.$getFullName(separator)}$${TShipmentProductModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(846264)
        
        

        //--TRIMMABLE-BOUNDARY-START(256440)
        $asm.$cls(`$oUrI.LCSCP.CreatePackageShipmentEmail`, ($self) => class CreatePackageShipmentEmail extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(8590191032)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590191032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex");
                __builder.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 2);
                __builder.AddComponentParameter(3, "Class", "mg-a mawx-5");
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~16/*CardFeatures.Pad*/ | 8/*CardFeatures.Border*/), $.$hDPm.LCFCCC$1.CardFeatures));
                __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", "pd");
                    __builder2.OpenElement(8, "h3");
                    __builder2.AddAttribute$5(9, "class", "mgt-0 op-8");
                    __builder2.AddContent$4(10, "Hello ");
                    __builder2.AddContent$4(11, this.Name);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(12, "\r\n            ");
                    __builder2.OpenElement(13, "p");
                    __builder2.AddContent$4(14, "This is to notify you that your order ");
                    __builder2.OpenElement(15, "b");
                    __builder2.AddContent$4(16, "\"");
                    __builder2.AddContent$4(17, this.Label);
                    __builder2.AddContent$4(18, "\"");
                    __builder2.CloseElement();
                    __builder2.AddContent$4(19, " with  id ");
                    __builder2.OpenElement(20, "b");
                    __builder2.AddContent$4(21, this.PackageId);
                    __builder2.CloseElement();
                    __builder2.AddContent$4(22, " is now shipped.");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(23, "\r\n            ");
                    __builder2.AddMarkupContent(24, "<p>Please track its progress on your order page which you can find here.</p>\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 25);
                    __builder2.AddComponentParameter(26, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(27, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(28, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Link));
                    __builder2.AddComponentParameter(29, "Class", "pd-4 d-block text-center wp-100");
                    __builder2.AddAttribute$3(30, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddContent$4(31, "Track Shipment");
                    }), $dfoaAk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":256440,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(32, "\r\n            ");
                    __builder2.AddMarkupContent(33, "<p>Thank you for patronizing us.</p>");
                    __builder2.CloseElement();
                }), $OZjUTf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":256440,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590191032)
            
            //--TRIMMABLE-BOUNDARY-START(60129798584)
            /*string */ get PackageId()
            {
                return this.GetQuery("Id", false);
            }
            //--TRIMMABLE-BOUNDARY-END(60129798584)
            
            //--TRIMMABLE-BOUNDARY-START(55834831288)
            /*string */ get Name()
            {
                return this.GetQuery("Name", false);
            }
            //--TRIMMABLE-BOUNDARY-END(55834831288)
            
            //--TRIMMABLE-BOUNDARY-START(51539863992)
            /*string */ get Link()
            {
                return this.GetQuery("Link", false);
            }
            //--TRIMMABLE-BOUNDARY-END(51539863992)
            
            //--TRIMMABLE-BOUNDARY-START(47244896696)
            /*string */ get Label()
            {
                return this.GetQuery("Label", false);
            }
            //--TRIMMABLE-BOUNDARY-END(47244896696)
            
            //--TRIMMABLE-BOUNDARY-START(4295223736)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295223736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295223736)
            
            //--TRIMMABLE-BOUNDARY-START(4295223736)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295223736)
            
            static $h = 256440;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129798584),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949929400,
        "f": 50331650
      },
      "n": "PackageId",
      "d": 256440,
      "h": 60129798584,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60129798584),
//--TRIMMABLE-BOUNDARY-START(55834831288),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359994808,
        "f": 50331650
      },
      "n": "Name",
      "d": 256440,
      "h": 55834831288,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55834831288),
//--TRIMMABLE-BOUNDARY-START(51539863992),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770060216,
        "f": 50331650
      },
      "n": "Link",
      "d": 256440,
      "h": 51539863992,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51539863992),
//--TRIMMABLE-BOUNDARY-START(47244896696),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180125624,
        "f": 50331650
      },
      "n": "Label",
      "d": 256440,
      "h": 47244896696,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47244896696)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590191032),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 256440,
      "h": 8590191032,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590191032)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295223736),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 256440,
      "h": 4295223736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295223736)
  ],
  "h": 256440,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/CreatePackageShipmentEmail",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Client.Pages.CreatePackageShipmentEmail`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Client${separator}Pages${separator}CreatePackageShipmentEmail`; }
        });
        //--TRIMMABLE-BOUNDARY-END(256440)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Shipping.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(59832)
