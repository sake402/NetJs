
//--TRIMMABLE-BOUNDARY-START(34937)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $Iaui, $uvJL) {
    "use strict";
    let _;
    let $nJBClf;
    let $BANDBk;
    let $yJqJlc;
    let $GOEzje;
    let $fggZwc;
    let $iFywdc;
    let $OwzpDb;
    let $pnqGvb;
    let $VhZQId;
    let $pSHJhf;
    let $jWmoBb;
    let $QEwxPe;
    let $yqQrHk;
    let $RyTnTh;
    let $UvvKLi;
    let $mMSXci;
    let $YBMFNi;
    let $DZqKNh;
    let $uxzxke;
    let $DgaWUc;
    let $RIiTug;
    let $aEnkYh;
    let $ZrOZqd;
    let $CitQvj;
    let $nCHKJk;
    let $suXIah;
    let $IcvUJc;
    let $ANRzuk;
    let $nRxybh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Shipping.Common", 
    {
  "h": 34937,
  "f": "LivingThing.Core.Shipping.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Shipping.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Shipping.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(755833)
        $asm.$cls(`$YUlm.LCSCM.IShipmentAccount`, ($self) => class IShipmentAccount
        {
            static $h = 755833;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 755833
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$Iaui.LCFCM.IApplicationAccountModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.IShipmentAccount`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}IShipmentAccount`; }
        });
        //--TRIMMABLE-BOUNDARY-END(755833)
        
        

        //--TRIMMABLE-BOUNDARY-START(2459769)
        $asm.$cls(`$YUlm.LCSCS.IShippingService`, ($self) => class IShippingService
        {
            static $h = 2459769;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657165433),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$YUlm.LCSCM.IShipmentModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477296249,
        "f": 50331905
      },
      "n": "Shipments",
      "o": "LCSCS$IShippingService$Shipments",
      "d": 2459769,
      "h": 38657165433,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38657165433)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887361657),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "pickupLocation",
          "p": 13928790
        },
        {
          "n": "deliveryLocation",
          "p": 13928790
        }
      ],
      "n": "EstimateCost",
      "o": "LCSCS$IShippingService$EstimateCost",
      "d": 2459769,
      "h": 12887361657,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887361657),
//--TRIMMABLE-BOUNDARY-START(30067230841),
    {
      "r": $.$$.STT.Task$$($.$YUlm.LCSCM.IShipmentModel).$h,
      "p": [
        {
          "n": "id",
          "p": 10455382
        }
      ],
      "n": "GetShipmentAsync",
      "o": "LCSCS$IShippingService$GetShipmentAsync",
      "d": 2459769,
      "h": 30067230841,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30067230841),
//--TRIMMABLE-BOUNDARY-START(8592394361),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel)).$h,
      "p": [
        {
          "n": "packages",
          "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h
        },
        {
          "n": "shipmentLabel",
          "p": 1310721
        }
      ],
      "n": "CreateShipmentAsync",
      "o": "LCSCS$IShippingService$CreateShipmentAsync",
      "d": 2459769,
      "h": 8592394361,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592394361),
//--TRIMMABLE-BOUNDARY-START(4297427065),
    {
      "r": 178454529,
      "p": [
        {
          "n": "shipment",
          "p": 821369
        },
        {
          "n": "packages",
          "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h
        }
      ],
      "n": "AddPackagesToShipment",
      "o": "LCSCS$IShippingService$AddPackagesToShipment",
      "d": 2459769,
      "h": 4297427065,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297427065),
//--TRIMMABLE-BOUNDARY-START(25772263545),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDG.GeoLocation).$h,
      "p": [
        {
          "n": "shipmentId",
          "p": 10455382
        }
      ],
      "n": "GetLocationAsync",
      "o": "LCSCS$IShippingService$GetLocationAsync",
      "d": 2459769,
      "h": 25772263545,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25772263545),
//--TRIMMABLE-BOUNDARY-START(34362198137),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "shipmentId",
          "p": 10455382
        },
        {
          "n": "packageId",
          "p": 10455382
        }
      ],
      "n": "SetPackageDelivered",
      "o": "LCSCS$IShippingService$SetPackageDelivered",
      "d": 2459769,
      "h": 34362198137,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34362198137)
  ],
  "h": 2459769
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Services.IShippingService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Services${separator}IShippingService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2459769)
        
        

        //--TRIMMABLE-BOUNDARY-START(952441)
        $asm.$cls(`$YUlm.LCSCM.IShipmentPackageModel`, ($self) => class IShipmentPackageModel
        {
            static $h = 952441;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(167504676985),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144938617,
        "f": 50331905
      },
      "n": "SKU",
      "o": "LCSCM$IShipmentPackageModel$SKU",
      "d": 952441,
      "h": 167504676985,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(167504676985),
//--TRIMMABLE-BOUNDARY-START(163209709689),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555004025,
        "f": 50331905
      },
      "n": "ShipmentId",
      "o": "LCSCM$IShipmentPackageModel$ShipmentId",
      "d": 952441,
      "h": 163209709689,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(163209709689),
//--TRIMMABLE-BOUNDARY-START(141734873209),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605331065,
        "f": 50331905
      },
      "n": "PaymentReference",
      "o": "LCSCM$IShipmentPackageModel$PaymentReference",
      "d": 952441,
      "h": 141734873209,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(141734873209),
//--TRIMMABLE-BOUNDARY-START(12885854329),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245592697,
        "f": 50331905
      },
      "n": "DatePaid",
      "o": "LCSCM$IShipmentPackageModel$DatePaid",
      "d": 952441,
      "h": 12885854329,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885854329),
//--TRIMMABLE-BOUNDARY-START(17180821625),
    {
      "p": 1214585,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835527289,
        "f": 50331905
      },
      "n": "Delivery",
      "o": "LCSCM$IShipmentPackageModel$Delivery",
      "d": 952441,
      "h": 17180821625,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180821625),
//--TRIMMABLE-BOUNDARY-START(146029840505),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195265657,
        "f": 50331905
      },
      "n": "PickupLocation",
      "o": "LCSCM$IShipmentPackageModel$PickupLocation",
      "d": 952441,
      "h": 146029840505,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(146029840505),
//--TRIMMABLE-BOUNDARY-START(21475788921),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425461881,
        "f": 50331905
      },
      "n": "DeliveryLocation",
      "o": "LCSCM$IShipmentPackageModel$DeliveryLocation",
      "d": 952441,
      "h": 21475788921,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475788921),
//--TRIMMABLE-BOUNDARY-START(8590887033),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655658105,
        "f": 50331905
      },
      "n": "DateDelivered",
      "o": "LCSCM$IShipmentPackageModel$DateDelivered",
      "d": 952441,
      "h": 8590887033,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590887033),
//--TRIMMABLE-BOUNDARY-START(4295919737),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065723513,
        "f": 50331905
      },
      "n": "DateConfirmed",
      "o": "LCSCM$IShipmentPackageModel$DateConfirmed",
      "d": 952441,
      "h": 4295919737,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295919737),
//--TRIMMABLE-BOUNDARY-START(158914742393),
    {
      "p": 755833,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965069433,
        "f": 50331905
      },
      "n": "Sender",
      "o": "LCSCM$IShipmentPackageModel$Sender",
      "d": 952441,
      "h": 158914742393,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158914742393),
//--TRIMMABLE-BOUNDARY-START(154619775097),
    {
      "p": 755833,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375134841,
        "f": 50331905
      },
      "n": "Receiver",
      "o": "LCSCM$IShipmentPackageModel$Receiver",
      "d": 952441,
      "h": 154619775097,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(154619775097),
//--TRIMMABLE-BOUNDARY-START(137439905913),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015396473,
        "f": 50331905
      },
      "n": "Link",
      "o": "LCSCM$IShipmentPackageModel$Link",
      "d": 952441,
      "h": 137439905913,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137439905913),
//--TRIMMABLE-BOUNDARY-START(150324807801),
    {
      "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentProductModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785200249,
        "f": 50331905
      },
      "n": "Products",
      "o": "LCSCM$IShipmentPackageModel$Products",
      "d": 952441,
      "h": 150324807801,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(150324807801)
  ],
  "h": 952441
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}IShipmentPackageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(952441)
        
        

        //--TRIMMABLE-BOUNDARY-START(821369)
        $asm.$cls(`$YUlm.LCSCM.IShipmentModel`, ($self) => class IShipmentModel
        {
            static $h = 821369;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655527033),
    {
      "p": 1738873,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770625145,
        "f": 50331905
      },
      "n": "State",
      "o": "LCSCM$IShipmentModel$State",
      "d": 821369,
      "h": 38655527033,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655527033),
//--TRIMMABLE-BOUNDARY-START(34360559737),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180690553,
        "f": 50331905
      },
      "n": "ShippingServiceId",
      "o": "LCSCM$IShipmentModel$ShippingServiceId",
      "d": 821369,
      "h": 34360559737,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360559737),
//--TRIMMABLE-BOUNDARY-START(30065592441),
    {
      "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590755961,
        "f": 50331905
      },
      "n": "Packages",
      "o": "LCSCM$IShipmentModel$Packages",
      "d": 821369,
      "h": 30065592441,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065592441)
  ],
  "h": 821369
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.IShipmentModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}IShipmentModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(821369)
        
        

        //--TRIMMABLE-BOUNDARY-START(1083513)
        $asm.$cls(`$YUlm.LCSCM.IShipmentProductModel`, ($self) => class IShipmentProductModel
        {
            static $h = 1083513;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296050809),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885985401,
        "f": 50331905
      },
      "n": "Cost",
      "o": "LCSCM$IShipmentProductModel$Cost",
      "d": 1083513,
      "h": 4296050809,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296050809),
//--TRIMMABLE-BOUNDARY-START(38655789177),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065854585,
        "f": 50331905
      },
      "n": "Quantity",
      "o": "LCSCM$IShipmentProductModel$Quantity",
      "d": 1083513,
      "h": 38655789177,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655789177),
//--TRIMMABLE-BOUNDARY-START(34360821881),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475919993,
        "f": 50331905
      },
      "n": "Link",
      "o": "LCSCM$IShipmentProductModel$Link",
      "d": 1083513,
      "h": 34360821881,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360821881)
  ],
  "h": 1083513
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.IShipmentProductModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}IShipmentProductModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1083513)
        
        

        //--TRIMMABLE-BOUNDARY-START(886905)
        $asm.$cls(`$YUlm.LCSCM.IShipmentModelCustomAttributesProvider`, ($self) => class IShipmentModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295854201)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295854201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295854201)
            
            static $h = 886905;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295854201),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 886905,
      "h": 4295854201,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295854201)
  ],
  "h": 886905
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.IShipmentModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}IShipmentModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(886905)
        
        

        //--TRIMMABLE-BOUNDARY-START(100473)
        $asm.$cls(`$YUlm.LCSC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295067769)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295067769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.WeightClass.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.WeightClassCustomAttributesProvider, $.$YUlm.LCSCM.WeightClassCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.DispatchWizardModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.DispatchWizardModelCustomAttributesProvider, $.$YUlm.LCSCM.DispatchWizardModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.IShipmentModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.IShipmentModelCustomAttributesProvider, $.$YUlm.LCSCM.IShipmentModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.IShipmentPackageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.IShipmentPackageModelCustomAttributesProvider, $.$YUlm.LCSCM.IShipmentPackageModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.IShipmentProductModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.IShipmentProductModelCustomAttributesProvider, $.$YUlm.LCSCM.IShipmentProductModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.ShipmentDeliveryType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.ShipmentDeliveryTypeCustomAttributesProvider, $.$YUlm.LCSCM.ShipmentDeliveryTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.ShipmentModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.ShipmentModelCustomAttributesProvider, $.$YUlm.LCSCM.ShipmentModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.ShipmentPickupType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.ShipmentPickupTypeCustomAttributesProvider, $.$YUlm.LCSCM.ShipmentPickupTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.ShipmentState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.ShipmentStateCustomAttributesProvider, $.$YUlm.LCSCM.ShipmentStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCM.ShippingModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCM.ShippingModelCustomAttributesProvider, $.$YUlm.LCSCM.ShippingModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCS$1.ShippingSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCS$1.ShippingSettingsCustomAttributesProvider, $.$YUlm.LCSCS$1.ShippingSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$YUlm.LCSCS$2.ShippingStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$YUlm.LCSCS$2.ShippingStatesCustomAttributesProvider, $.$YUlm.LCSCS$2.ShippingStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295067769)
            
            static $h = 100473;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295067769),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 100473,
      "h": 4295067769,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295067769)
  ],
  "h": 100473
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(100473)
        
        

        //--TRIMMABLE-BOUNDARY-START(1411193)
        $asm.$cls(`$YUlm.LCSCM.ShipmentModelCustomAttributesProvider`, ($self) => class ShipmentModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296378489)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296378489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.EntityModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296378489)
            
            static $h = 1411193;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296378489),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1411193,
      "h": 4296378489,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296378489)
  ],
  "h": 1411193
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1411193)
        
        

        //--TRIMMABLE-BOUNDARY-START(2656377)
        $asm.$cls(`$YUlm.LCSCS$1.ShippingSettingsCustomAttributesProvider`, ($self) => class ShippingSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297623673)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297623673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297623673)
            
            static $h = 2656377;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297623673),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2656377,
      "h": 4297623673,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297623673)
  ],
  "h": 2656377
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Settings.ShippingSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Settings${separator}ShippingSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2656377)
        
        

        //--TRIMMABLE-BOUNDARY-START(1017977)
        $asm.$cls(`$YUlm.LCSCM.IShipmentPackageModelCustomAttributesProvider`, ($self) => class IShipmentPackageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295985273)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295985273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295985273)
            
            static $h = 1017977;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295985273),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1017977,
      "h": 4295985273,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295985273)
  ],
  "h": 1017977
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.IShipmentPackageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}IShipmentPackageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1017977)
        
        

        //--TRIMMABLE-BOUNDARY-START(1149049)
        $asm.$cls(`$YUlm.LCSCM.IShipmentProductModelCustomAttributesProvider`, ($self) => class IShipmentProductModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296116345)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296116345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296116345)
            
            static $h = 1149049;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296116345),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1149049,
      "h": 4296116345,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296116345)
  ],
  "h": 1149049
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.IShipmentProductModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}IShipmentProductModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1149049)
        
        

        //--TRIMMABLE-BOUNDARY-START(2918521)
        $asm.$cls(`$YUlm.LCSCS$2.ShippingStatesCustomAttributesProvider`, ($self) => class ShippingStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297885817)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297885817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297885817)
            
            static $h = 2918521;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297885817),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2918521,
      "h": 4297885817,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297885817)
  ],
  "h": 2918521
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.States.ShippingStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}States${separator}ShippingStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2918521)
        
        

        //--TRIMMABLE-BOUNDARY-START(1935481)
        $asm.$cls(`$YUlm.LCSCM.ShippingModelCustomAttributesProvider`, ($self) => class ShippingModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296902777)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296902777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$YUlm.LCSCS$1.ShippingSettings, $.$YUlm.LCSCS$2.ShippingStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296902777)
            
            static $h = 1935481;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296902777),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1935481,
      "h": 4296902777,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296902777)
  ],
  "h": 1935481
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShippingModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShippingModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1935481)
        
        

        //--TRIMMABLE-BOUNDARY-START(1804409)
        $asm.$cls(`$YUlm.LCSCM.ShipmentStateCustomAttributesProvider`, ($self) => class ShipmentStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296771705)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296771705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296771705)
            
            static $h = 1804409;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296771705),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1804409,
      "h": 4296771705,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296771705)
  ],
  "h": 1804409
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1804409)
        
        

        //--TRIMMABLE-BOUNDARY-START(166009)
        $asm.$cls(`$YUlm.LCSC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295133305)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295133305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295133305)
            
            static $h = 166009;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295133305),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 166009,
      "h": 4295133305,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295133305)
  ],
  "h": 166009
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(166009)
        
        

        //--TRIMMABLE-BOUNDARY-START(1673337)
        $asm.$cls(`$YUlm.LCSCM.ShipmentPickupTypeCustomAttributesProvider`, ($self) => class ShipmentPickupTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296640633)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296640633)
            
            //--TRIMMABLE-BOUNDARY-START(8591607929)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591607929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$YUlm.LCSCM.ShipmentPickupTypeCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("DropOff", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Description = "Package will be dropped off at our outlet address.";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("HomePickup", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Description = "Package will be picked up from your location.";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$YUlm.LCSCM.ShipmentPickupTypeCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $BANDBk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1673337,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $yJqJlc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1673337,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591607929)
            
            static $h = 1673337;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591607929),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1673337,
      "h": 8591607929,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591607929)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296640633),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1673337,
      "h": 4296640633,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296640633)
  ],
  "h": 1673337
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentPickupTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentPickupTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1673337)
        
        

        //--TRIMMABLE-BOUNDARY-START(297081)
        $asm.$cls(`$YUlm.LCSCM.DispatchItemsImage`, ($self) => class DispatchItemsImage extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475133561)
            /*IEnumerable<ResourceModel>*/ Images = null;
            //--TRIMMABLE-BOUNDARY-END(21475133561)
            
            //--TRIMMABLE-BOUNDARY-START(8590231673)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590231673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590231673)
            
            //--TRIMMABLE-BOUNDARY-START(8590231673)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590231673)
            
            static $h = 297081;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475133561),
    {
      "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180166265,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065068153,
        "f": 83886081
      },
      "n": "Images",
      "d": 297081,
      "h": 21475133561,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 14,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475133561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590231673),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 297081,
      "h": 8590231673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590231673)
  ],
  "h": 297081
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DispatchItemsImage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DispatchItemsImage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(297081)
        
        

        //--TRIMMABLE-BOUNDARY-START(2787449)
        $asm.$cls(`$YUlm.LCSCS$1.ShippingSettingsTypeDescriptorBuilder`, ($self) => class ShippingSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592722041)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592722041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$YUlm.LCSCS$1.ShippingSettingsTypeDescriptor()
                        const $t1 = $.$YUlm.LCSCS$1.ShippingSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Shipping.Common.Settings.ShippingSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GOEzje ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2787449,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$YUlm.LCSCS$1.ShippingSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592722041)
            
            //--TRIMMABLE-BOUNDARY-START(4297754745)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297754745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297754745)
            
            //--TRIMMABLE-BOUNDARY-START(4297754745)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297754745)
            
            static $h = 2787449;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592722041),
    {
      "r": 65537,
      "n": "Register",
      "d": 2787449,
      "h": 8592722041,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592722041)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297754745),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2787449,
      "h": 4297754745,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297754745)
  ],
  "h": 2787449
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Settings.ShippingSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Settings${separator}ShippingSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2787449)
        
        

        //--TRIMMABLE-BOUNDARY-START(362617)
        $asm.$cls(`$YUlm.LCSCM.DispatchProportion`, ($self) => class DispatchProportion extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81604741241)
            /*WeightClass*/ WeightClass = 0;
            //--TRIMMABLE-BOUNDARY-END(81604741241)
            
            //--TRIMMABLE-BOUNDARY-START(25770166393)
            /*Weight*/ ExactWeight;
            //--TRIMMABLE-BOUNDARY-END(25770166393)
            
            //--TRIMMABLE-BOUNDARY-START(21475199097)
            /*Volume*/ ExactVolume;
            //--TRIMMABLE-BOUNDARY-END(21475199097)
            
            //--TRIMMABLE-BOUNDARY-START(17180231801)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180231801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180231801)
            
            //--TRIMMABLE-BOUNDARY-START(17180231801)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180231801)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770166393)
                this.ExactWeight = $.$default($.$fPer.LCFCDM.Weight);
                //--TRIMMABLE-BOUNDARY-END(25770166393)
                
                //--TRIMMABLE-BOUNDARY-START(21475199097)
                this.ExactVolume = $.$default($.$fPer.LCFCDM.Volume);
                //--TRIMMABLE-BOUNDARY-END(21475199097)
                
            }
            static $h = 362617;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604741241),
    {
      "p": 2132089,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539970169,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309773945,
        "f": 83886081
      },
      "n": "WeightClass",
      "d": 362617,
      "h": 81604741241,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 41,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604741241),
//--TRIMMABLE-BOUNDARY-START(25770166393),
    {
      "p": 29985110,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950035577,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719839353,
        "f": 83886081
      },
      "n": "ExactWeight",
      "d": 362617,
      "h": 25770166393,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Please leave blank if you do not know",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770166393),
//--TRIMMABLE-BOUNDARY-START(21475199097),
    {
      "p": 29788502,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360100985,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129904761,
        "f": 83886081
      },
      "n": "ExactVolume",
      "d": 362617,
      "h": 21475199097,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Please leave blank if you do not know",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475199097)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180231801),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 362617,
      "h": 17180231801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180231801)
  ],
  "h": 362617
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DispatchProportion`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DispatchProportion`; }
        });
        //--TRIMMABLE-BOUNDARY-END(362617)
        
        

        //--TRIMMABLE-BOUNDARY-START(2197625)
        $asm.$cls(`$YUlm.LCSCM.WeightClassCustomAttributesProvider`, ($self) => class WeightClassCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297164921)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297164921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297164921)
            
            static $h = 2197625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297164921),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2197625,
      "h": 4297164921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297164921)
  ],
  "h": 2197625
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.WeightClassCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}WeightClassCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2197625)
        
        

        //--TRIMMABLE-BOUNDARY-START(690297)
        $asm.$cls(`$YUlm.LCSCM.DispatchWorth`, ($self) => class DispatchWorth extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475526777)
            /*double*/ PackageWorth = 0;
            //--TRIMMABLE-BOUNDARY-END(21475526777)
            
            //--TRIMMABLE-BOUNDARY-START(8590624889)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590624889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590624889)
            
            //--TRIMMABLE-BOUNDARY-START(8590624889)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590624889)
            
            static $h = 690297;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475526777),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180559481,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065461369,
        "f": 83886081
      },
      "n": "PackageWorth",
      "d": 690297,
      "h": 21475526777,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Please leave blank if you do not know",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475526777)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590624889),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 690297,
      "h": 8590624889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590624889)
  ],
  "h": 690297
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DispatchWorth`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DispatchWorth`; }
        });
        //--TRIMMABLE-BOUNDARY-END(690297)
        
        

        //--TRIMMABLE-BOUNDARY-START(428153)
        $asm.$cls(`$YUlm.LCSCM.DispatchWizardModel`, ($self) => class DispatchWizardModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245068409)
            /*DispatchItemsImage*/ Images = null;
            //--TRIMMABLE-BOUNDARY-END(47245068409)
            
            //--TRIMMABLE-BOUNDARY-START(51540035705)
            /*DispatchProportion*/ Proportion = null;
            //--TRIMMABLE-BOUNDARY-END(51540035705)
            
            //--TRIMMABLE-BOUNDARY-START(81604806777)
            /*DispatchWorth*/ Worth = null;
            //--TRIMMABLE-BOUNDARY-END(81604806777)
            
            //--TRIMMABLE-BOUNDARY-START(17180297337)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180297337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180297337)
            
            //--TRIMMABLE-BOUNDARY-START(17180297337)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180297337)
            
            static $h = 428153;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245068409),
    {
      "p": 297081,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770231929,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129970297,
        "f": 83886081
      },
      "n": "Images",
      "d": 428153,
      "h": 47245068409,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Please take one or more pictures of the package or packages you are dispatching",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245068409),
//--TRIMMABLE-BOUNDARY-START(51540035705),
    {
      "p": 362617,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360166521,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719904889,
        "f": 83886081
      },
      "n": "Proportion",
      "d": 428153,
      "h": 51540035705,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Please specify a close approximate size of the packages",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540035705),
//--TRIMMABLE-BOUNDARY-START(81604806777),
    {
      "p": 690297,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950101113,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309839481,
        "f": 83886081
      },
      "n": "Worth",
      "d": 428153,
      "h": 81604806777,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Please specify a close approximate size of the packages",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604806777)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180297337),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 428153,
      "h": 17180297337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180297337)
  ],
  "h": 428153
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DispatchWizardModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DispatchWizardModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(428153)
        
        

        //--TRIMMABLE-BOUNDARY-START(2525305)
        $asm.$cls(`$YUlm.LCSCS.ShippingServiceExtensions`, ($self) => class ShippingServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297492601)
            static /*IShippingService */ GetShippingService(/*this IShipmentModel*/ shipment, /*IEnumerable<IShippingService>*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297492601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$YUlm.LCSCS.IShippingService, services, new ($.$$.S.Func$$$($.$YUlm.LCSCS.IShippingService, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.S.Object.GetType.call(e).FullName === shipment.LCSCM$IShipmentModel$ShippingServiceId;
                }, $nJBClf ??= {"r":262145,"p":[{"n":"e","p":2459769}],"n":"","d":2525305,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4297492601)
            
            static $h = 2525305;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297492601),
    {
      "r": 2459769,
      "p": [
        {
          "n": "shipment",
          "p": 821369
        },
        {
          "n": "services",
          "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCS.IShippingService).$h
        }
      ],
      "n": "GetShippingService",
      "d": 2525305,
      "h": 4297492601,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297492601)
  ],
  "h": 2525305
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Services.ShippingServiceExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Services${separator}ShippingServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2525305)
        
        

        //--TRIMMABLE-BOUNDARY-START(2066553)
        $asm.$cls(`$YUlm.LCSCM.ShippingModelTypeDescriptorBuilder`, ($self) => class ShippingModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592001145)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592001145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$YUlm.LCSCM.ShippingModelTypeDescriptor()
                        const $t1 = $.$YUlm.LCSCM.ShippingModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Shipping.Common.Models.ShippingModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iFywdc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2066553,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$YUlm.LCSCM.ShippingModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592001145)
            
            //--TRIMMABLE-BOUNDARY-START(4297033849)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297033849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297033849)
            
            //--TRIMMABLE-BOUNDARY-START(4297033849)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297033849)
            
            static $h = 2066553;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592001145),
    {
      "r": 65537,
      "n": "Register",
      "d": 2066553,
      "h": 8592001145,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592001145)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297033849),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2066553,
      "h": 4297033849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297033849)
  ],
  "h": 2066553
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShippingModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShippingModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2066553)
        
        

        //--TRIMMABLE-BOUNDARY-START(1542265)
        $asm.$cls(`$YUlm.LCSCM.ShipmentModelTypeDescriptorBuilder`, ($self) => class ShipmentModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591476857)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591476857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$YUlm.LCSCM.ShipmentModelTypeDescriptor()
                        const $t1 = $.$YUlm.LCSCM.ShipmentModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Shipping.Common.Models.ShipmentModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QEwxPe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1542265,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$YUlm.LCSCM.ShipmentModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591476857)
            
            //--TRIMMABLE-BOUNDARY-START(4296509561)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296509561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296509561)
            
            //--TRIMMABLE-BOUNDARY-START(4296509561)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296509561)
            
            static $h = 1542265;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591476857),
    {
      "r": 65537,
      "n": "Register",
      "d": 1542265,
      "h": 8591476857,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591476857)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296509561),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1542265,
      "h": 4296509561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296509561)
  ],
  "h": 1542265
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1542265)
        
        

        //--TRIMMABLE-BOUNDARY-START(1280121)
        $asm.$cls(`$YUlm.LCSCM.ShipmentDeliveryTypeCustomAttributesProvider`, ($self) => class ShipmentDeliveryTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296247417)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296247417)
            
            //--TRIMMABLE-BOUNDARY-START(8591214713)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591214713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$YUlm.LCSCM.ShipmentDeliveryTypeCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("PickUp", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Description = "Package will be picked up from our outlet address.";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("HomeDelivery", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Description = "Package will be dispatched to your home address.";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$YUlm.LCSCM.ShipmentDeliveryTypeCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $pnqGvb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1280121,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $VhZQId ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1280121,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591214713)
            
            static $h = 1280121;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591214713),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1280121,
      "h": 8591214713,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591214713)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296247417),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1280121,
      "h": 4296247417,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296247417)
  ],
  "h": 1280121
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentDeliveryTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentDeliveryTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1280121)
        
        

        //--TRIMMABLE-BOUNDARY-START(3115129)
        $asm.$cls(`$YUlm.LCSC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298082425)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298082425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$YUlm.LCSCM.DispatchWizardModelTypeDescriptorBuilder.Register();
                $.$YUlm.LCSCM.ShipmentModelTypeDescriptorBuilder.Register();
                $.$YUlm.LCSCM.ShippingModelTypeDescriptorBuilder.Register();
                $.$YUlm.LCSCS$1.ShippingSettingsTypeDescriptorBuilder.Register();
                $.$YUlm.LCSCS$2.ShippingStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298082425)
            
            static $h = 3115129;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298082425),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3115129,
      "h": 4298082425,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298082425)
  ],
  "h": 3115129
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3115129)
        
        

        //--TRIMMABLE-BOUNDARY-START(624761)
        $asm.$cls(`$YUlm.LCSCM.DispatchWizardModelTypeDescriptorBuilder`, ($self) => class DispatchWizardModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590559353)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590559353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor()
                        const $t1 = $.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Shipping.Common.Models.DispatchWizardModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aEnkYh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":624761,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$YUlm.LCSCM.DispatchWizardModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590559353)
            
            //--TRIMMABLE-BOUNDARY-START(4295592057)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295592057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295592057)
            
            //--TRIMMABLE-BOUNDARY-START(4295592057)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295592057)
            
            static $h = 624761;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590559353),
    {
      "r": 65537,
      "n": "Register",
      "d": 624761,
      "h": 8590559353,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590559353)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295592057),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 624761,
      "h": 4295592057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295592057)
  ],
  "h": 624761
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DispatchWizardModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DispatchWizardModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(624761)
        
        

        //--TRIMMABLE-BOUNDARY-START(493689)
        $asm.$cls(`$YUlm.LCSCM.DispatchWizardModelCustomAttributesProvider`, ($self) => class DispatchWizardModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295460985)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295460985)
            
            //--TRIMMABLE-BOUNDARY-START(8590428281)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590428281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$YUlm.LCSCM.DispatchWizardModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Images", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Description = "Please take one or more pictures of the package or packages you are dispatching";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Proportion", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.Description = "Please specify a close approximate size of the packages";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Worth", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.Description = "Please specify a close approximate size of the packages";
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$YUlm.LCSCM.DispatchWizardModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $pSHJhf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":493689,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $jWmoBb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":493689,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590428281)
            
            static $h = 493689;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590428281),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 493689,
      "h": 8590428281,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590428281)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295460985),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 493689,
      "h": 4295460985,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295460985)
  ],
  "h": 493689
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DispatchWizardModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DispatchWizardModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(493689)
        
        

        //--TRIMMABLE-BOUNDARY-START(3049593)
        $asm.$cls(`$YUlm.LCSCS$2.ShippingStatesTypeDescriptorBuilder`, ($self) => class ShippingStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592984185)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592984185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$YUlm.LCSCS$2.ShippingStatesTypeDescriptor()
                        const $t1 = $.$YUlm.LCSCS$2.ShippingStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Shipping.Common.States.ShippingStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DgaWUc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3049593,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$YUlm.LCSCS$2.ShippingStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592984185)
            
            //--TRIMMABLE-BOUNDARY-START(4298016889)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298016889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298016889)
            
            //--TRIMMABLE-BOUNDARY-START(4298016889)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298016889)
            
            static $h = 3049593;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592984185),
    {
      "r": 65537,
      "n": "Register",
      "d": 3049593,
      "h": 8592984185,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592984185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298016889),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3049593,
      "h": 4298016889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298016889)
  ],
  "h": 3049593
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.States.ShippingStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}States${separator}ShippingStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3049593)
        
        

        //--TRIMMABLE-BOUNDARY-START(2263161)
        $asm.$cls(`$YUlm.LCSC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592197753)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592197753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$YUlm.LCSC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$YUlm.LCSC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592197753)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$YUlm.LCSC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297230457)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297230457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297230457)
            
            //--TRIMMABLE-BOUNDARY-START(4297230457)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297230457)
            
            static $h = 2263161;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592197753),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2263161,
      "h": 8592197753,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592197753)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297230457),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2263161,
      "h": 4297230457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297230457)
  ],
  "h": 2263161
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2263161)
        
        

        //--TRIMMABLE-BOUNDARY-START(231545)
        $asm.$cls(`$YUlm.LCSCM.DeliveryInfoFilter`, ($self) => class DeliveryInfoFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590166137)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590166137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $package;
                if ($.$is(target, $.$YUlm.LCSCM.IShipmentPackageModel, { set $v($v){ $package = $v; } }))
                {
                    let $switch1 = typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name;
                    switch($switch1)
                    {
                        case "DeliveryLocation":
                        return $package.LCSCM$IShipmentPackageModel$Delivery === 2/*ShipmentDeliveryType.HomeDelivery*/;
                    }
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8590166137)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4295198841)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295198841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295198841)
            
            //--TRIMMABLE-BOUNDARY-START(4295198841)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295198841)
            
            static $h = 231545;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590166137),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 231545,
      "h": 8590166137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590166137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295198841),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 231545,
      "h": 4295198841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295198841)
  ],
  "h": 231545
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DeliveryInfoFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DeliveryInfoFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(231545)
        
        

        //--TRIMMABLE-BOUNDARY-START(2328697)
        $asm.$cls(`$YUlm.LCSCS.DefaultShippingService`, ($self) => class DefaultShippingService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85901674617)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(85901674617)
            
            //--TRIMMABLE-BOUNDARY-START(17182197881)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182197881);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182197881)
            
            //--TRIMMABLE-BOUNDARY-START(94491609209)
            /*Pager<IShipmentModel> */ get Shipments()
            {
                return $.$fPer.LCFCD.Paging.Cast$1($.$YUlm.LCSCM.ShipmentModel, $.$YUlm.LCSCM.IShipmentModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$YUlm.LCSCM.ShipmentModel, this.Server, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(94491609209)
            
            //--TRIMMABLE-BOUNDARY-START(98786576505)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(98786576505)
            
            //--TRIMMABLE-BOUNDARY-START(30067099769)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30067099769)
            
            //--TRIMMABLE-BOUNDARY-START(81606707321)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(81606707321)
            
            //--TRIMMABLE-BOUNDARY-START(21477165177)
            /*Task */ AddPackagesToShipment(/*IShipmentModel*/ shipment, /*IEnumerable<IShipmentPackageModel>*/ packages)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477165177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(21477165177)
            
            //--TRIMMABLE-BOUNDARY-START(25772132473)
            /*Task<IEnumerable<IShipmentModel>> *//*async*/  CreateShipmentAsync(/*IEnumerable<IShipmentPackageModel>*/ packages, /*string*/ shipmentLabel)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel)), $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772132473);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let shipment = $.$sl.SL.Enumerable.First$1($.$YUlm.LCSCM.ShipmentModel, (($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$YUlm.LCSCM.ShipmentModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$YUlm.LCSCM.ShipmentModel), [ new $.$YUlm.LCSCM.ShipmentModel().$ctor$4() ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)))).AsEnumerable());
                    ($t2 = this.AddPackagesToShipment(shipment, packages), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$YUlm.LCSCM.ShipmentModel), [shipment], null, null), $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.ShipmentModel), $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25772132473)
            
            //--TRIMMABLE-BOUNDARY-START(34362067065)
            /*Task<Money> */ EstimateCost(/*GeoLocation*/ pickupLocation, /*GeoLocation*/ deliveryLocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362067065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(34362067065)
            
            //--TRIMMABLE-BOUNDARY-START(73016772729)
            /*Task<GeoLocation> */ GetLocationAsync(/*DataId*/ shipmentId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016772729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(73016772729)
            
            //--TRIMMABLE-BOUNDARY-START(77311740025)
            /*Task<IShipmentModel> *//*async*/  GetShipmentAsync(/*DataId*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$YUlm.LCSCM.IShipmentModel), $.$YUlm.LCSCM.IShipmentModel, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311740025);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$YUlm.LCSCM.ShipmentModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12($.$clone(id)), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77311740025)
            
            //--TRIMMABLE-BOUNDARY-START(90196641913)
            /*Task<bool> */ SetPackageDelivered(/*DataId*/ shipmentId, /*DataId*/ packageId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196641913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(90196641913)
            
            //--TRIMMABLE-BOUNDARY-START(12887361657)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.EstimateCost(LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation, LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation)
            LCSCS$IShippingService$EstimateCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887361657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EstimateCost(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12887361657)
            
            //--TRIMMABLE-BOUNDARY-START(21477296249)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.Shipments.get
            get LCSCS$IShippingService$Shipments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657165433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Shipments;
            }
            //--TRIMMABLE-BOUNDARY-END(21477296249)
            
            //--TRIMMABLE-BOUNDARY-START(30067230841)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.GetShipmentAsync(LivingThing.Core.Frameworks.Common.Data.DataId)
            LCSCS$IShippingService$GetShipmentAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067230841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetShipmentAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30067230841)
            
            //--TRIMMABLE-BOUNDARY-START(8592394361)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.CreateShipmentAsync(System.Collections.Generic.IEnumerable<LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel>, string)
            LCSCS$IShippingService$CreateShipmentAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592394361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateShipmentAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8592394361)
            
            //--TRIMMABLE-BOUNDARY-START(4297427065)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.AddPackagesToShipment(LivingThing.Core.Shipping.Common.Models.IShipmentModel, System.Collections.Generic.IEnumerable<LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel>)
            LCSCS$IShippingService$AddPackagesToShipment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297427065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddPackagesToShipment(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297427065)
            
            //--TRIMMABLE-BOUNDARY-START(25772263545)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.GetLocationAsync(LivingThing.Core.Frameworks.Common.Data.DataId)
            LCSCS$IShippingService$GetLocationAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772263545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetLocationAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25772263545)
            
            //--TRIMMABLE-BOUNDARY-START(34362198137)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.SetPackageDelivered(LivingThing.Core.Frameworks.Common.Data.DataId, LivingThing.Core.Frameworks.Common.Data.DataId)
            LCSCS$IShippingService$SetPackageDelivered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362198137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetPackageDelivered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34362198137)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81606707321)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(81606707321)
                
            }
            static $h = 2328697;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94491609209),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$YUlm.LCSCM.IShipmentModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131870841,
        "f": 50331649
      },
      "n": "Shipments",
      "d": 2328697,
      "h": 94491609209,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491609209),
//--TRIMMABLE-BOUNDARY-START(98786576505),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721805433,
        "f": 50331649
      },
      "n": "Title",
      "d": 2328697,
      "h": 98786576505,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786576505),
//--TRIMMABLE-BOUNDARY-START(30067099769),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952001657,
        "f": 50331649
      },
      "n": "Description",
      "d": 2328697,
      "h": 30067099769,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067099769),
//--TRIMMABLE-BOUNDARY-START(81606707321),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541936249,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2328697,
      "h": 81606707321,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606707321)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477165177),
    {
      "r": 178454529,
      "p": [
        {
          "n": "shipment",
          "p": 821369
        },
        {
          "n": "packages",
          "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h
        }
      ],
      "n": "AddPackagesToShipment",
      "d": 2328697,
      "h": 21477165177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477165177),
//--TRIMMABLE-BOUNDARY-START(25772132473),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel)).$h,
      "p": [
        {
          "n": "packages",
          "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h
        },
        {
          "n": "shipmentLabel",
          "p": 1310721
        }
      ],
      "n": "CreateShipmentAsync",
      "d": 2328697,
      "h": 25772132473,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25772132473),
//--TRIMMABLE-BOUNDARY-START(34362067065),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "pickupLocation",
          "p": 13928790
        },
        {
          "n": "deliveryLocation",
          "p": 13928790
        }
      ],
      "n": "EstimateCost",
      "d": 2328697,
      "h": 34362067065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362067065),
//--TRIMMABLE-BOUNDARY-START(73016772729),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDG.GeoLocation).$h,
      "p": [
        {
          "n": "shipmentId",
          "p": 10455382
        }
      ],
      "n": "GetLocationAsync",
      "d": 2328697,
      "h": 73016772729,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016772729),
//--TRIMMABLE-BOUNDARY-START(77311740025),
    {
      "r": $.$$.STT.Task$$($.$YUlm.LCSCM.IShipmentModel).$h,
      "p": [
        {
          "n": "id",
          "p": 10455382
        }
      ],
      "n": "GetShipmentAsync",
      "d": 2328697,
      "h": 77311740025,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(77311740025),
//--TRIMMABLE-BOUNDARY-START(90196641913),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "shipmentId",
          "p": 10455382
        },
        {
          "n": "packageId",
          "p": 10455382
        }
      ],
      "n": "SetPackageDelivered",
      "d": 2328697,
      "h": 90196641913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90196641913)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85901674617),
    {
      "t": 1309651,
      "n": "Server",
      "d": 2328697,
      "h": 85901674617,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85901674617)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182197881),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2328697,
      "h": 17182197881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182197881)
  ],
  "h": 2328697
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$YUlm.LCSCS.IShippingService, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Services.DefaultShippingService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Services${separator}DefaultShippingService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2328697)
        
        

        //--TRIMMABLE-BOUNDARY-START(1738873)
        $asm.$str(`$YUlm.LCSCM.ShipmentState`, ($self) => class ShipmentState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static AwaitingAward = 0;
            static Awarded = 1;
            static AwaitingPayment = 1;
            static Paid = 2;
            static AwaitingShipment = 2;
            static Shipped = 3;
            static AwaitingDelivery = 3;
            static Arrived = 4;
            static Delivered = 5;
            static Disputing = 6;
            static Confirmed = 7;
            static Closed = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1738873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "AwaitingAward": 0n,
                    "Awarded": 1n,
                    "AwaitingPayment": 1n,
                    "Paid": 2n,
                    "AwaitingShipment": 2n,
                    "Shipped": 3n,
                    "AwaitingDelivery": 3n,
                    "Arrived": 4n,
                    "Delivered": 5n,
                    "Disputing": 6n,
                    "Confirmed": 7n,
                    "Closed": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296706169)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296706169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296706169)
            
            //--TRIMMABLE-BOUNDARY-START(4296706169)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296706169)
            
            static $h = 1738873;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886640761),
    {
      "t": 1738873,
      "n": "AwaitingAward",
      "d": 1738873,
      "h": 12886640761,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886640761),
//--TRIMMABLE-BOUNDARY-START(30066509945),
    {
      "t": 1738873,
      "n": "Awarded",
      "d": 1738873,
      "h": 30066509945,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066509945),
//--TRIMMABLE-BOUNDARY-START(21476575353),
    {
      "t": 1738873,
      "n": "AwaitingPayment",
      "d": 1738873,
      "h": 21476575353,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476575353),
//--TRIMMABLE-BOUNDARY-START(51541346425),
    {
      "t": 1738873,
      "n": "Paid",
      "d": 1738873,
      "h": 51541346425,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541346425),
//--TRIMMABLE-BOUNDARY-START(25771542649),
    {
      "t": 1738873,
      "n": "AwaitingShipment",
      "d": 1738873,
      "h": 25771542649,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771542649),
//--TRIMMABLE-BOUNDARY-START(55836313721),
    {
      "t": 1738873,
      "n": "Shipped",
      "d": 1738873,
      "h": 55836313721,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836313721),
//--TRIMMABLE-BOUNDARY-START(17181608057),
    {
      "t": 1738873,
      "n": "AwaitingDelivery",
      "d": 1738873,
      "h": 17181608057,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181608057),
//--TRIMMABLE-BOUNDARY-START(8591673465),
    {
      "t": 1738873,
      "n": "Arrived",
      "d": 1738873,
      "h": 8591673465,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591673465),
//--TRIMMABLE-BOUNDARY-START(42951411833),
    {
      "t": 1738873,
      "n": "Delivered",
      "d": 1738873,
      "h": 42951411833,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951411833),
//--TRIMMABLE-BOUNDARY-START(47246379129),
    {
      "t": 1738873,
      "n": "Disputing",
      "d": 1738873,
      "h": 47246379129,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246379129),
//--TRIMMABLE-BOUNDARY-START(38656444537),
    {
      "t": 1738873,
      "n": "Confirmed",
      "d": 1738873,
      "h": 38656444537,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656444537),
//--TRIMMABLE-BOUNDARY-START(34361477241),
    {
      "t": 1738873,
      "n": "Closed",
      "d": 1738873,
      "h": 34361477241,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361477241)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296706169),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1738873,
      "h": 4296706169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296706169)
  ],
  "h": 1738873
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1738873)
        
        

        //--TRIMMABLE-BOUNDARY-START(1214585)
        $asm.$str(`$YUlm.LCSCM.ShipmentDeliveryType`, ($self) => class ShipmentDeliveryType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static PickUp = 1;
            static HomeDelivery = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1214585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "PickUp": 1n,
                    "HomeDelivery": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296181881)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296181881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296181881)
            
            //--TRIMMABLE-BOUNDARY-START(4296181881)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296181881)
            
            static $h = 1214585;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886116473),
    {
      "t": 1214585,
      "n": "None",
      "d": 1214585,
      "h": 12886116473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886116473),
//--TRIMMABLE-BOUNDARY-START(17181083769),
    {
      "t": 1214585,
      "n": "PickUp",
      "d": 1214585,
      "h": 17181083769,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Package will be picked up from our outlet address.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181083769),
//--TRIMMABLE-BOUNDARY-START(8591149177),
    {
      "t": 1214585,
      "n": "HomeDelivery",
      "d": 1214585,
      "h": 8591149177,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Package will be dispatched to your home address.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591149177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296181881),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1214585,
      "h": 4296181881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296181881)
  ],
  "h": 1214585
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentDeliveryType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentDeliveryType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1214585)
        
        

        //--TRIMMABLE-BOUNDARY-START(1607801)
        $asm.$str(`$YUlm.LCSCM.ShipmentPickupType`, ($self) => class ShipmentPickupType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static DropOff = 1;
            static HomePickup = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1607801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "DropOff": 1n,
                    "HomePickup": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296575097)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296575097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296575097)
            
            //--TRIMMABLE-BOUNDARY-START(4296575097)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296575097)
            
            static $h = 1607801;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181476985),
    {
      "t": 1607801,
      "n": "None",
      "d": 1607801,
      "h": 17181476985,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181476985),
//--TRIMMABLE-BOUNDARY-START(8591542393),
    {
      "t": 1607801,
      "n": "DropOff",
      "d": 1607801,
      "h": 8591542393,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Package will be dropped off at our outlet address.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591542393),
//--TRIMMABLE-BOUNDARY-START(12886509689),
    {
      "t": 1607801,
      "n": "HomePickup",
      "d": 1607801,
      "h": 12886509689,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Package will be picked up from your location.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886509689)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296575097),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1607801,
      "h": 4296575097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296575097)
  ],
  "h": 1607801
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentPickupType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentPickupType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1607801)
        
        

        //--TRIMMABLE-BOUNDARY-START(2132089)
        $asm.$str(`$YUlm.LCSCM.WeightClass`, ($self) => class WeightClass extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static VeryLight = 0;
            static Light = 1;
            static Heavy = 2;
            static VeryHeavy = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2132089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "VeryLight": 0n,
                    "Light": 1n,
                    "Heavy": 2n,
                    "VeryHeavy": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297099385)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297099385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297099385)
            
            //--TRIMMABLE-BOUNDARY-START(4297099385)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297099385)
            
            static $h = 2132089;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476968569),
    {
      "t": 2132089,
      "n": "VeryLight",
      "d": 2132089,
      "h": 21476968569,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476968569),
//--TRIMMABLE-BOUNDARY-START(12887033977),
    {
      "t": 2132089,
      "n": "Light",
      "d": 2132089,
      "h": 12887033977,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887033977),
//--TRIMMABLE-BOUNDARY-START(8592066681),
    {
      "t": 2132089,
      "n": "Heavy",
      "d": 2132089,
      "h": 8592066681,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592066681),
//--TRIMMABLE-BOUNDARY-START(17182001273),
    {
      "t": 2132089,
      "n": "VeryHeavy",
      "d": 2132089,
      "h": 17182001273,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182001273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297099385),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2132089,
      "h": 4297099385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297099385)
  ],
  "h": 2132089
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.WeightClass`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}WeightClass`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2132089)
        
        

        //--TRIMMABLE-BOUNDARY-START(2590841)
        $asm.$cls(`$YUlm.LCSCS$1.ShippingSettings`, ($self) => class ShippingSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297558137)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297558137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297558137)
            
            //--TRIMMABLE-BOUNDARY-START(4297558137)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297558137)
            
            static $h = 2590841;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297558137),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2590841,
      "h": 4297558137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297558137)
  ],
  "h": 2590841
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Settings.ShippingSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Settings${separator}ShippingSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2590841)
        
        

        //--TRIMMABLE-BOUNDARY-START(2852985)
        $asm.$cls(`$YUlm.LCSCS$2.ShippingStates`, ($self) => class ShippingStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4297820281)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297820281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297820281)
            
            //--TRIMMABLE-BOUNDARY-START(4297820281)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297820281)
            
            static $h = 2852985;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297820281),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2852985,
      "h": 4297820281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297820281)
  ],
  "h": 2852985
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.States.ShippingStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}States${separator}ShippingStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2852985)
        
        

        //--TRIMMABLE-BOUNDARY-START(559225)
        $asm.$cls(`$YUlm.LCSCM.DispatchWizardModelTypeDescriptor`, ($self) => class DispatchWizardModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCM.DispatchWizardModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295526521)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295526521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor.GenerateProperties($.$YUlm.LCSCM.DispatchWizardModel, this, factory);
                    }, $ZrOZqd ??= {"r":65537,"n":"","d":559225,"h":0,"f":17825794}), 0, "DispatchWizardModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Shipping.Common\\Models_DispatchWizardModel_LivingThing.Core.Shipping.Common.Models.DispatchWizardModelTypeDescriptorBuilder.g.cs", "DispatchWizardModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295526521)
            
            //--TRIMMABLE-BOUNDARY-START(12885461113)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885461113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Images"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$YUlm.LCSCM.DispatchWizardModel.$type, $.$discardRef(), "Images", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Images")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$YUlm.LCSCM.DispatchItemsImage, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Images";
                        $i1.DelaredOn = "LivingThing.Core.Shipping.Common.Models.DispatchWizardModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$YUlm.LCSCM.DispatchItemsImage, ($.$cast(target, $.$YUlm.LCSCM.DispatchWizardModel)).Images);
                        }, $CitQvj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":559225,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Images = value.AsReference($.$YUlm.LCSCM.DispatchItemsImage);
                        }, $nCHKJk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":559225,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Proportion"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$YUlm.LCSCM.DispatchWizardModel.$type, $.$discardRef(), "Proportion", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Proportion")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$YUlm.LCSCM.DispatchProportion, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Proportion";
                        $i3.DelaredOn = "LivingThing.Core.Shipping.Common.Models.DispatchWizardModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$YUlm.LCSCM.DispatchProportion, ($.$cast(target, $.$YUlm.LCSCM.DispatchWizardModel)).Proportion);
                        }, $suXIah ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":559225,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Proportion = value.AsReference($.$YUlm.LCSCM.DispatchProportion);
                        }, $IcvUJc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":559225,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Worth"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$YUlm.LCSCM.DispatchWizardModel.$type, $.$discardRef(), "Worth", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Worth")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$YUlm.LCSCM.DispatchWorth, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Worth";
                        $i5.DelaredOn = "LivingThing.Core.Shipping.Common.Models.DispatchWizardModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$YUlm.LCSCM.DispatchWorth, ($.$cast(target, $.$YUlm.LCSCM.DispatchWizardModel)).Worth);
                        }, $ANRzuk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":559225,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Worth = value.AsReference($.$YUlm.LCSCM.DispatchWorth);
                        }, $nRxybh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":559225,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885461113)
            
            //--TRIMMABLE-BOUNDARY-START(17180428409)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Models.DispatchWizardModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180428409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Images = _target.Images;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Images"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$YUlm.LCSCM.DispatchItemsImage));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Images, ($v) => _Images = $v, $.$YUlm.LCSCM.DispatchItemsImage)))
                    {
                        _target.Images = _Images;
                    }
                }
                {
                    /*var*/ let _Proportion = _target.Proportion;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Proportion"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$YUlm.LCSCM.DispatchProportion));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Proportion, ($v) => _Proportion = $v, $.$YUlm.LCSCM.DispatchProportion)))
                    {
                        _target.Proportion = _Proportion;
                    }
                }
                {
                    /*var*/ let _Worth = _target.Worth;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Worth"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$YUlm.LCSCM.DispatchWorth));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Worth, ($v) => _Worth = $v, $.$YUlm.LCSCM.DispatchWorth)))
                    {
                        _target.Worth = _Worth;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180428409)
            
            //--TRIMMABLE-BOUNDARY-START(8590493817)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Models.DispatchWizardModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590493817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$YUlm.LCSCM.DispatchWizardModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$YUlm.LCSCM.DispatchWizardModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.DispatchWizardModel)))
                {
                    /*var*/ let result = $.$YUlm.LCSCM.DispatchWizardModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.DispatchWizardModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$YUlm.LCSCM.DispatchWizardModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.DispatchWizardModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590493817)
            
            static $h = 559225;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCM.DispatchWizardModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885461113),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 559225,
      "h": 12885461113,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885461113),
//--TRIMMABLE-BOUNDARY-START(17180428409),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 428153,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 559225,
      "h": 17180428409,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180428409),
//--TRIMMABLE-BOUNDARY-START(8590493817),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 428153,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 559225,
      "h": 8590493817,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590493817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295526521),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 559225,
      "h": 4295526521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295526521)
  ],
  "h": 559225
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$YUlm.LCSCM.DispatchWizardModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.DispatchWizardModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}DispatchWizardModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(559225)
        
        

        //--TRIMMABLE-BOUNDARY-START(1345657)
        $asm.$cls(`$YUlm.LCSCM.ShipmentModel`, ($self) => class ShipmentModel extends $.$Iaui.LCFCM.EntityModel
        {
            //--TRIMMABLE-BOUNDARY-START(81605724281)
            /*ShipmentState*/ State = 0;
            //--TRIMMABLE-BOUNDARY-END(81605724281)
            
            //--TRIMMABLE-BOUNDARY-START(77310756985)
            /*string*/ ShippingServiceId = null;
            //--TRIMMABLE-BOUNDARY-END(77310756985)
            
            //--TRIMMABLE-BOUNDARY-START(47245985913)
            /*IEnumerable<IShipmentPackageModel>*/ Packages = null;
            //--TRIMMABLE-BOUNDARY-END(47245985913)
            
            //--TRIMMABLE-BOUNDARY-START(25770625145)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentModel.State.get
            get LCSCM$IShipmentModel$State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655527033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.State;
            }
            //--TRIMMABLE-BOUNDARY-END(25770625145)
            
            //--TRIMMABLE-BOUNDARY-START(17180690553)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentModel.ShippingServiceId.get
            get LCSCM$IShipmentModel$ShippingServiceId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360559737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ShippingServiceId;
            }
            //--TRIMMABLE-BOUNDARY-END(17180690553)
            
            //--TRIMMABLE-BOUNDARY-START(8590755961)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentModel.Packages.get
            get LCSCM$IShipmentModel$Packages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065592441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Packages;
            }
            //--TRIMMABLE-BOUNDARY-END(8590755961)
            
            //--TRIMMABLE-BOUNDARY-START(17181214841)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181214841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181214841)
            
            //--TRIMMABLE-BOUNDARY-START(17181214841)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17181214841)
            
            static $h = 1345657;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.EntityModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605724281),
    {
      "p": 1738873,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951018617,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015789689,
        "f": 83886081
      },
      "n": "State",
      "d": 1345657,
      "h": 81605724281,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605724281),
//--TRIMMABLE-BOUNDARY-START(77310756985),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361084025,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425855097,
        "f": 83886081
      },
      "n": "ShippingServiceId",
      "d": 1345657,
      "h": 77310756985,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310756985),
//--TRIMMABLE-BOUNDARY-START(47245985913),
    {
      "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771149433,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835920505,
        "f": 83886081
      },
      "n": "Packages",
      "d": 1345657,
      "h": 47245985913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245985913)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181214841),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1345657,
      "h": 17181214841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181214841)
  ],
  "h": 1345657
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$YUlm.LCSCM.IShipmentModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1345657)
        
        

        //--TRIMMABLE-BOUNDARY-START(2394233)
        $asm.$cls(`$YUlm.LCSCS.IShipmentRemoteService`, ($self) => class IShipmentRemoteService
        {
            static $h = 2394233;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2394233
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFCD.ICreateDataService$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFCD.IReadDataService$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFCD.IReadManyDataService$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFCD.IUpdateDataService$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFCD.IDeleteDataService$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Services.IShipmentRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Services${separator}IShipmentRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2394233)
        
        

        //--TRIMMABLE-BOUNDARY-START(2721913)
        $asm.$cls(`$YUlm.LCSCS$1.ShippingSettingsTypeDescriptor`, ($self) => class ShippingSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCS$1.ShippingSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297689209)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297689209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$YUlm.LCSCS$1.ShippingSettingsTypeDescriptor.GenerateProperties($.$YUlm.LCSCS$1.ShippingSettings, this, factory);
                    }, $fggZwc ??= {"r":65537,"n":"","d":2721913,"h":0,"f":17825794}), 0, "ShippingSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Shipping.Common\\Settings_ShippingSettings_LivingThing.Core.Shipping.Common.Settings.ShippingSettingsTypeDescriptorBuilder.g.cs", "ShippingSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297689209)
            
            //--TRIMMABLE-BOUNDARY-START(12887623801)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887623801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887623801)
            
            //--TRIMMABLE-BOUNDARY-START(17182591097)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Settings.ShippingSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182591097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182591097)
            
            //--TRIMMABLE-BOUNDARY-START(8592656505)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Settings.ShippingSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592656505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$YUlm.LCSCS$1.ShippingSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$YUlm.LCSCS$1.ShippingSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCS$1.ShippingSettings)))
                {
                    /*var*/ let result = $.$YUlm.LCSCS$1.ShippingSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCS$1.ShippingSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$YUlm.LCSCS$1.ShippingSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCS$1.ShippingSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592656505)
            
            static $h = 2721913;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCS$1.ShippingSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887623801),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2721913,
      "h": 12887623801,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887623801),
//--TRIMMABLE-BOUNDARY-START(17182591097),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2590841,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2721913,
      "h": 17182591097,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182591097),
//--TRIMMABLE-BOUNDARY-START(8592656505),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2590841,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2721913,
      "h": 8592656505,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592656505)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297689209),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2721913,
      "h": 4297689209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297689209)
  ],
  "h": 2721913
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$YUlm.LCSCS$1.ShippingSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Settings.ShippingSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Settings${separator}ShippingSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2721913)
        
        

        //--TRIMMABLE-BOUNDARY-START(2984057)
        $asm.$cls(`$YUlm.LCSCS$2.ShippingStatesTypeDescriptor`, ($self) => class ShippingStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCS$2.ShippingStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297951353)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297951353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$YUlm.LCSCS$2.ShippingStatesTypeDescriptor.GenerateProperties($.$YUlm.LCSCS$2.ShippingStates, this, factory);
                    }, $RIiTug ??= {"r":65537,"n":"","d":2984057,"h":0,"f":17825794}), 0, "ShippingStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Shipping.Common\\States_ShippingStates_LivingThing.Core.Shipping.Common.States.ShippingStatesTypeDescriptorBuilder.g.cs", "ShippingStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297951353)
            
            //--TRIMMABLE-BOUNDARY-START(12887885945)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887885945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887885945)
            
            //--TRIMMABLE-BOUNDARY-START(17182853241)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.States.ShippingStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182853241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182853241)
            
            //--TRIMMABLE-BOUNDARY-START(8592918649)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.States.ShippingStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592918649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$YUlm.LCSCS$2.ShippingStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$YUlm.LCSCS$2.ShippingStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCS$2.ShippingStates)))
                {
                    /*var*/ let result = $.$YUlm.LCSCS$2.ShippingStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCS$2.ShippingStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$YUlm.LCSCS$2.ShippingStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCS$2.ShippingStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592918649)
            
            static $h = 2984057;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCS$2.ShippingStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887885945),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2984057,
      "h": 12887885945,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887885945),
//--TRIMMABLE-BOUNDARY-START(17182853241),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2852985,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2984057,
      "h": 17182853241,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182853241),
//--TRIMMABLE-BOUNDARY-START(8592918649),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2852985,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2984057,
      "h": 8592918649,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592918649)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297951353),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2984057,
      "h": 4297951353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297951353)
  ],
  "h": 2984057
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$YUlm.LCSCS$2.ShippingStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.States.ShippingStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}States${separator}ShippingStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2984057)
        
        

        //--TRIMMABLE-BOUNDARY-START(1476729)
        $asm.$cls(`$YUlm.LCSCM.ShipmentModelTypeDescriptor`, ($self) => class ShipmentModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCM.ShipmentModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296444025)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296444025);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$YUlm.LCSCM.ShipmentModelTypeDescriptor.GenerateProperties($.$YUlm.LCSCM.ShipmentModel, this, factory);
                    }, $yqQrHk ??= {"r":65537,"n":"","d":1476729,"h":0,"f":17825794}), 0, "ShipmentModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Shipping.Common\\Models_ShipmentModel_LivingThing.Core.Shipping.Common.Models.ShipmentModelTypeDescriptorBuilder.g.cs", "ShipmentModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296444025)
            
            //--TRIMMABLE-BOUNDARY-START(12886378617)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886378617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$YUlm.LCSCM.ShipmentModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$YUlm.LCSCM.ShipmentState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "State";
                        $i1.DelaredOn = "LivingThing.Core.Shipping.Common.Models.ShipmentModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.ShipmentModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$YUlm.LCSCM.ShipmentState, ($.$cast(target, $.$YUlm.LCSCM.ShipmentModel)).State);
                        }, $RyTnTh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1476729,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.ShipmentModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.State = value.AsEnumValue($.$YUlm.LCSCM.ShipmentState);
                        }, $UvvKLi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1476729,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ShippingServiceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$YUlm.LCSCM.ShipmentModel.$type, $.$discardRef(), "ShippingServiceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ShippingServiceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ShippingServiceId";
                        $i3.DelaredOn = "LivingThing.Core.Shipping.Common.Models.ShipmentModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.ShipmentModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$YUlm.LCSCM.ShipmentModel)).ShippingServiceId);
                        }, $mMSXci ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1476729,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.ShipmentModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ShippingServiceId = value.AsReference($.$$.S.String);
                        }, $YBMFNi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1476729,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Packages"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$YUlm.LCSCM.ShipmentModel.$type, $.$discardRef(), "Packages", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Packages")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Packages";
                        $i5.DelaredOn = "LivingThing.Core.Shipping.Common.Models.ShipmentModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.ShipmentModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel), ($.$cast(target, $.$YUlm.LCSCM.ShipmentModel)).Packages);
                        }, $DZqKNh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1476729,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$YUlm.LCSCM.ShipmentModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Packages = value.AsReference($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel));
                        }, $uxzxke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1476729,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.EntityModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886378617)
            
            //--TRIMMABLE-BOUNDARY-START(17181345913)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Models.ShipmentModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181345913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.EntityModel?*/ let targetBase = _target;
                $.$Iaui.LCFCM.EntityModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.EntityModel));
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$YUlm.LCSCM.ShipmentState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$YUlm.LCSCM.ShipmentState, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _ShippingServiceId = _target.ShippingServiceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ShippingServiceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ShippingServiceId, ($v) => _ShippingServiceId = $v, $.$$.S.String)))
                    {
                        _target.ShippingServiceId = _ShippingServiceId;
                    }
                }
                {
                    /*var*/ let _Packages = _target.Packages;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Packages"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel), $.$YUlm.LCSCM.IShipmentPackageModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel), $.$YUlm.LCSCM.IShipmentPackageModel, property, $.$ref(() => _Packages, ($v) => _Packages = $v, $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel))))
                    {
                        _target.Packages = _Packages;
                        if (_Packages !== null)
                        {
                            let $en13 = _Packages.SCG$IEnumerable$$$GetEnumerator();
                            while ($en13.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en13.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$YUlm.LCSCM.IShipmentPackageModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel), $.$YUlm.LCSCM.IShipmentPackageModel, property, $.$ref(() => _Packages, ($v) => _Packages = $v, $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181345913)
            
            //--TRIMMABLE-BOUNDARY-START(8591411321)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Models.ShipmentModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591411321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$YUlm.LCSCM.ShipmentModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$YUlm.LCSCM.ShipmentModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.ShipmentModel)))
                {
                    /*var*/ let result = $.$YUlm.LCSCM.ShipmentModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.ShipmentModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$YUlm.LCSCM.ShipmentModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.ShipmentModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591411321)
            
            static $h = 1476729;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCM.ShipmentModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886378617),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1476729,
      "h": 12886378617,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886378617),
//--TRIMMABLE-BOUNDARY-START(17181345913),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1345657,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1476729,
      "h": 17181345913,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181345913),
//--TRIMMABLE-BOUNDARY-START(8591411321),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1345657,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1476729,
      "h": 8591411321,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591411321)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296444025),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1476729,
      "h": 4296444025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296444025)
  ],
  "h": 1476729
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$YUlm.LCSCM.ShipmentModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShipmentModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShipmentModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1476729)
        
        

        //--TRIMMABLE-BOUNDARY-START(1869945)
        $asm.$cls(`$YUlm.LCSCM.ShippingModel`, ($self) => class ShippingModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$YUlm.LCSCS$1.ShippingSettings, $.$YUlm.LCSCS$2.ShippingStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296837241)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296837241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296837241)
            
            //--TRIMMABLE-BOUNDARY-START(4296837241)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296837241)
            
            static $h = 1869945;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$YUlm.LCSCS$1.ShippingSettings, $.$YUlm.LCSCS$2.ShippingStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296837241),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1869945,
      "h": 4296837241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296837241)
  ],
  "h": 1869945
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShippingModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShippingModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1869945)
        
        

        //--TRIMMABLE-BOUNDARY-START(2001017)
        $asm.$cls(`$YUlm.LCSCM.ShippingModelTypeDescriptor`, ($self) => class ShippingModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCM.ShippingModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296968313)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296968313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$YUlm.LCSCM.ShippingModelTypeDescriptor.GenerateProperties($.$YUlm.LCSCM.ShippingModel, this, factory);
                    }, $OwzpDb ??= {"r":65537,"n":"","d":2001017,"h":0,"f":17825794}), 0, "ShippingModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Shipping.Common\\Models_ShippingModel_LivingThing.Core.Shipping.Common.Models.ShippingModelTypeDescriptorBuilder.g.cs", "ShippingModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296968313)
            
            //--TRIMMABLE-BOUNDARY-START(12886902905)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886902905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$YUlm.LCSCS$1.ShippingSettings, $.$YUlm.LCSCS$2.ShippingStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886902905)
            
            //--TRIMMABLE-BOUNDARY-START(17181870201)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Models.ShippingModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181870201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Shipping.Common.Settings.ShippingSettings, LivingThing.Core.Shipping.Common.States.ShippingStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$YUlm.LCSCS$1.ShippingSettings, $.$YUlm.LCSCS$2.ShippingStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$YUlm.LCSCS$1.ShippingSettings, $.$YUlm.LCSCS$2.ShippingStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181870201)
            
            //--TRIMMABLE-BOUNDARY-START(8591935609)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Shipping.Common.Models.ShippingModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591935609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$YUlm.LCSCM.ShippingModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$YUlm.LCSCM.ShippingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.ShippingModel)))
                {
                    /*var*/ let result = $.$YUlm.LCSCM.ShippingModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.ShippingModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$YUlm.LCSCM.ShippingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$YUlm.LCSCM.ShippingModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591935609)
            
            static $h = 2001017;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$YUlm.LCSCM.ShippingModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886902905),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2001017,
      "h": 12886902905,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886902905),
//--TRIMMABLE-BOUNDARY-START(17181870201),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1869945,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2001017,
      "h": 17181870201,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181870201),
//--TRIMMABLE-BOUNDARY-START(8591935609),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1869945,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2001017,
      "h": 8591935609,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591935609)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296968313),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2001017,
      "h": 4296968313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296968313)
  ],
  "h": 2001017
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$YUlm.LCSCM.ShippingModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Shipping.Common.Models.ShippingModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Shipping${separator}Common${separator}Models${separator}ShippingModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2001017)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(34937)
