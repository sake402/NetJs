
//--TRIMMABLE-BOUNDARY-START(61173)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $gGJx) {
    "use strict";
    let _;
    let $qaACUc;
    let $MOULIi;
    let $nXsOyd;
    let $WkhZXb;
    let $Fbclka;
    let $zzIVTd;
    let $JcxeBg;
    let $nWZapj;
    let $bICefi;
    let $TXYuIe;
    let $TZtNxb;
    let $gyFOJk;
    let $vgxbcj;
    let $RvLgeh;
    let $WbmCZh;
    let $FjpwLc;
    let $ivqKSk;
    let $ZADtOg;
    let $XEzVbb;
    let $IbjCek;
    let $LuDKSk;
    let $YZqSOi;
    let $uCbjji;
    let $WVsrAi;
    let $IYtIYf;
    let $vdyePj;
    let $KliVKk;
    let $iViYTg;
    let $fyBhbf;
    let $oXdOll;
    let $ClMFMg;
    let $LFBLVa;
    let $XSQGMk;
    let $XSlPee;
    let $CylsOd;
    let $AyjnEc;
    let $bfafPc;
    let $FoQVBf;
    let $ecmdae;
    let $zuoPrj;
    let $iffoti;
    let $ejHyEa;
    let $zCrnyd;
    let $xcLIVd;
    let $aGxQoi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Uri.Client.Blazor", 
    {
  "h": 61173,
  "f": "LivingThing.Core.Uri.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Uri.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Uri.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(323317)
        $asm.$cls(`$cHnS.LCUC.IUriAppRootEntryProvider`, ($self) => class IUriAppRootEntryProvider
        {
            static $h = 323317;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 323317
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sZVd.LCFCA.IAppRootEntryProvider, $.$yleQ.LCFCA.IApplicationRootEntryProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.IUriAppRootEntryProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}IUriAppRootEntryProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(323317)
        
        

        //--TRIMMABLE-BOUNDARY-START(650997)
        $asm.$cls(`$cHnS.LCUCS.IUriResourceTypeProvider`, ($self) => class IUriResourceTypeProvider
        {
            //--TRIMMABLE-BOUNDARY-START(21475487477)
            /*InputType */ get LCUCS$IUriResourceTypeProvider$InputType()
            {
                return 12n;
            }
            //--TRIMMABLE-BOUNDARY-END(21475487477)
            
            //--TRIMMABLE-BOUNDARY-START(12885552885)
            /*RenderFragment? */ LCUCS$IUriResourceTypeProvider$GetEditorView(/*DelegateValueBinder<string>*/ binder)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885552885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885552885)
            
            //--TRIMMABLE-BOUNDARY-START(17180520181)
            /*RenderFragment? */ LCUCS$IUriResourceTypeProvider$GetView(/*UriLinkItem*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180520181);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(item.Text, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180520181)
            
            static $h = 650997;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475487477),
    {
      "p": 47614294,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590585589,
        "f": 50331777
      },
      "n": "InputType",
      "o": "LCUCS$IUriResourceTypeProvider$InputType",
      "d": 650997,
      "h": 21475487477,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21475487477)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885552885),
    {
      "r": 6881395,
      "p": [
        {
          "n": "binder",
          "p": $.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.String).$h
        }
      ],
      "n": "GetEditorView",
      "o": "LCUCS$IUriResourceTypeProvider$GetEditorView",
      "d": 650997,
      "h": 12885552885,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885552885),
//--TRIMMABLE-BOUNDARY-START(17180520181),
    {
      "r": 6881395,
      "p": [
        {
          "n": "item",
          "p": 89850
        }
      ],
      "n": "GetView",
      "o": "LCUCS$IUriResourceTypeProvider$GetView",
      "d": 650997,
      "h": 17180520181,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180520181)
  ],
  "h": 650997
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IThemable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.Services.IUriResourceTypeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}Services${separator}IUriResourceTypeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(650997)
        
        

        //--TRIMMABLE-BOUNDARY-START(192245)
        $asm.$cls(`$cHnS.LCUC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295159541)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295159541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$cHnS.LCUC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295159541)
            
            static $h = 192245;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295159541),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 192245,
      "h": 4295159541,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295159541)
  ],
  "h": 192245
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(192245)
        
        

        //--TRIMMABLE-BOUNDARY-START(454389)
        $asm.$cls(`$cHnS.LCUC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590388981)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590388981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$cHnS.LCUCP.UriApp, "LivingThing.Core.Uri.Client", "Pages\\UriApp", "Uri App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/{*Code}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590388981)
            
            //--TRIMMABLE-BOUNDARY-START(4295421685)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295421685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295421685)
            
            //--TRIMMABLE-BOUNDARY-START(4295421685)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295421685)
            
            static $h = 454389;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590388981),
    {
      "r": 65537,
      "n": "Build",
      "d": 454389,
      "h": 8590388981,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590388981)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295421685),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 454389,
      "h": 4295421685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295421685)
  ],
  "h": 454389
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(454389)
        
        

        //--TRIMMABLE-BOUNDARY-START(388853)
        $asm.$cls(`$cHnS.LCUC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180258037)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cHnS.LCUC.App.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cHnS.LCUC.App().$ctor$4();
                    }, $MOULIi ??= {"r":2752627,"n":"","d":388853,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cHnS.LCUCP.UriApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cHnS.LCUCP.UriApp().$ctor$3();
                    }, $nXsOyd ??= {"r":2752627,"n":"","d":388853,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cHnS.LCUC.UriAppEntry.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cHnS.LCUC.UriAppEntry().$ctor$5();
                    }, $WkhZXb ??= {"r":2752627,"n":"","d":388853,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180258037)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295356149)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295356149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295356149)
            
            //--TRIMMABLE-BOUNDARY-START(4295356149)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295356149)
            
            static $h = 388853;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180258037),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885290741,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 388853,
      "h": 17180258037,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180258037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295356149),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 388853,
      "h": 4295356149,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295356149)
  ],
  "h": 388853
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(388853)
        
        

        //--TRIMMABLE-BOUNDARY-START(585461)
        $asm.$cls(`$cHnS.LCUC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590520053)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590520053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$cHnS.LCUCS.UriPhoneProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$cHnS.LCUCS.UriAddressProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$cHnS.LCUCS.UriEmailProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$cHnS.LCUCS.UriLinkProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$cHnS.LCUCS.UriImageProvider, services);
                if (options.Runtime !== 1/*RuntimeType.WebServer*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$sZVd.LCFCA.IAppRootEntryProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$yleQ.LCFCA.IApplicationRootEntryProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$cHnS.LCUC.IUriAppRootEntryProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$cHnS.LCUC.UriClientAppRootEntryProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$cHnS.LCUC.IUriAppRootEntryProvider))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cHnS.LCUC.UriClientAppRootEntryProvider, x);
                    }, $Fbclka ??= {"r":323317,"p":[{"n":"x","p":327718}],"n":"","d":585461,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$yleQ.LCFCA.IApplicationRootEntryProvider))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cHnS.LCUC.UriClientAppRootEntryProvider, x);
                    }, $zzIVTd ??= {"r":1678816,"p":[{"n":"x","p":327718}],"n":"","d":585461,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IAppRootEntryProvider))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cHnS.LCUC.UriClientAppRootEntryProvider, x);
                    }, $JcxeBg ??= {"r":1344211,"p":[{"n":"x","p":327718}],"n":"","d":585461,"h":0,"f":17825794}));
                }
                $.$sZVd.LCFCA.ClientApplicationExtension.AddApplication$1($.$cHnS.LCUCP.UriApp, services, "uri.ng", "Link Container", "Create short link around anything", $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-link"/*MaterialDesignIconNames.Link*/), $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#234590";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })()), new ($.$$.S.Action$$($.$sZVd.LCFCA.ClientApplicationModel$$($.$cHnS.LCUCP.UriApp)))().$ctor(this,  (/*a*/ a) =>
                {
                    a.Link = "https://uri.ng";
                    a.Domains = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["uri.ng"], null, null);
                    a.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [""], null, null);
                }, $nWZapj ??= {"r":65537,"p":[{"n":"a","p":$.$sZVd.LCFCA.ClientApplicationModel$$($.$cHnS.LCUCP.UriApp).$h}],"n":"","d":585461,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590520053)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cHnS.LCUC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295552757)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295552757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295552757)
            
            //--TRIMMABLE-BOUNDARY-START(4295552757)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295552757)
            
            static $h = 585461;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590520053),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 585461,
      "h": 8590520053,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590520053)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295552757),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 585461,
      "h": 4295552757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295552757)
  ],
  "h": 585461
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(585461)
        
        

        //--TRIMMABLE-BOUNDARY-START(1109749)
        $asm.$cls(`$cHnS.LCUC.UriClientAppRootEntryProvider`, ($self) => class UriClientAppRootEntryProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770913525)
            /*IEnumerable<string>*/ static domains = null;
            //--TRIMMABLE-BOUNDARY-END(25770913525)
            
            //--TRIMMABLE-BOUNDARY-START(30065880821)
            /*IEnumerable<string> */ get Domains()
            {
                return $.$cHnS.LCUC.UriClientAppRootEntryProvider.domains;
            }
            //--TRIMMABLE-BOUNDARY-END(30065880821)
            
            //--TRIMMABLE-BOUNDARY-START(17180978933)
            /*Type */ get AppEntryType()
            {
                return $.$cHnS.LCUC.UriAppEntry.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180978933)
            
            //--TRIMMABLE-BOUNDARY-START(73015553781)
            /*Type?*/ SplashScreen = null;
            //--TRIMMABLE-BOUNDARY-END(73015553781)
            
            //--TRIMMABLE-BOUNDARY-START(68720586485)
            /*IComponentRenderMode? */ GetDefaultRenderMode(/*System.Uri*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720586485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macw.MACW.RenderMode.InteractiveAuto;
            }
            //--TRIMMABLE-BOUNDARY-END(68720586485)
            
            //--TRIMMABLE-BOUNDARY-START(21475946229)
            /*IEnumerable<Assembly>? */ get ApplicationAssemblies()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.Assembly), [$.$cHnS.LCUC._Imports.$type.Assembly], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475946229)
            
            //--TRIMMABLE-BOUNDARY-START(42951017171)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IAppRootEntryProvider.Domains.get
            get LCFCA$IAppRootEntryProvider$Domains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886246099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Domains;
            }
            //--TRIMMABLE-BOUNDARY-END(42951017171)
            
            //--TRIMMABLE-BOUNDARY-START(90195657427)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Application.IAppRootEntryProvider.GetDefaultRenderMode(System.Uri)
            LCFCA$IAppRootEntryProvider$GetDefaultRenderMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195657427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDefaultRenderMode(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(90195657427)
            
            //--TRIMMABLE-BOUNDARY-START(34361417184)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationRootEntryProvider.SplashScreen.get
            get LCFCA$IApplicationRootEntryProvider$SplashScreen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656384480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SplashScreen;
            }
            //--TRIMMABLE-BOUNDARY-END(34361417184)
            
            //--TRIMMABLE-BOUNDARY-START(17181548000)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationRootEntryProvider.AppEntryType.get
            get LCFCA$IApplicationRootEntryProvider$AppEntryType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296646112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AppEntryType;
            }
            //--TRIMMABLE-BOUNDARY-END(17181548000)
            
            //--TRIMMABLE-BOUNDARY-START(25771482592)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationRootEntryProvider.ApplicationAssemblies.get
            get LCFCA$IApplicationRootEntryProvider$ApplicationAssemblies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591613408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ApplicationAssemblies;
            }
            //--TRIMMABLE-BOUNDARY-END(25771482592)
            
            //--TRIMMABLE-BOUNDARY-START(12886011637)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886011637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886011637)
            
            //--TRIMMABLE-BOUNDARY-START(12886011637)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886011637)
            
            //--TRIMMABLE-BOUNDARY-START(8591044341)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591044341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770913525)
                    this.domains = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["uri.ng"], null, null);
                    //--TRIMMABLE-BOUNDARY-END(25770913525)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591044341)
            
            static $h = 1109749;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065880821),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835684597,
        "f": 50331649
      },
      "n": "Domains",
      "d": 1109749,
      "h": 30065880821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065880821),
//--TRIMMABLE-BOUNDARY-START(17180978933),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655815413,
        "f": 50331649
      },
      "n": "AppEntryType",
      "d": 1109749,
      "h": 17180978933,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180978933),
//--TRIMMABLE-BOUNDARY-START(73015553781),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425619189,
        "f": 50331649
      },
      "n": "SplashScreen",
      "d": 1109749,
      "h": 73015553781,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015553781),
//--TRIMMABLE-BOUNDARY-START(21475946229),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SR.Assembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245750005,
        "f": 50331649
      },
      "n": "ApplicationAssemblies",
      "d": 1109749,
      "h": 21475946229,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475946229)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720586485),
    {
      "r": 2883699,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "GetDefaultRenderMode",
      "d": 1109749,
      "h": 68720586485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720586485)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770913525),
    {
      "t": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "n": "domains",
      "d": 1109749,
      "h": 25770913525,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770913525)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886011637),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1109749,
      "h": 12886011637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886011637)
  ],
  "h": 1109749
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$cHnS.LCUC.IUriAppRootEntryProvider, $.$sZVd.LCFCA.IAppRootEntryProvider, $.$yleQ.LCFCA.IApplicationRootEntryProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.UriClientAppRootEntryProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}UriClientAppRootEntryProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1109749)
        
        

        //--TRIMMABLE-BOUNDARY-START(847605)
        $asm.$cls(`$cHnS.LCUCS.UriImageProvider`, ($self) => class UriImageProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015291637)
            /*string? */ get Title()
            {
                return "Image";
            }
            //--TRIMMABLE-BOUNDARY-END(73015291637)
            
            //--TRIMMABLE-BOUNDARY-START(12885749493)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885749493)
            
            //--TRIMMABLE-BOUNDARY-START(60130389749)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-image"/*MaterialDesignIconNames.Image*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60130389749)
            
            //--TRIMMABLE-BOUNDARY-START(68720324341)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Success);
            }
            //--TRIMMABLE-BOUNDARY-END(68720324341)
            
            //--TRIMMABLE-BOUNDARY-START(64425357045)
            /*string? */ get Name()
            {
                return "Image";
            }
            //--TRIMMABLE-BOUNDARY-END(64425357045)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8590782197)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590782197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590782197)
            
            //--TRIMMABLE-BOUNDARY-START(8590782197)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590782197)
            
            static $h = 847605;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015291637),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835422453,
        "f": 50331649
      },
      "n": "Title",
      "d": 847605,
      "h": 73015291637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015291637),
//--TRIMMABLE-BOUNDARY-START(12885749493),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475684085,
        "f": 50331649
      },
      "n": "Description",
      "d": 847605,
      "h": 12885749493,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885749493),
//--TRIMMABLE-BOUNDARY-START(60130389749),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065618677,
        "f": 50331649
      },
      "n": "Icon",
      "d": 847605,
      "h": 60130389749,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130389749),
//--TRIMMABLE-BOUNDARY-START(68720324341),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245487861,
        "f": 50331649
      },
      "n": "Theme",
      "d": 847605,
      "h": 68720324341,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720324341),
//--TRIMMABLE-BOUNDARY-START(64425357045),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655553269,
        "f": 50331649
      },
      "n": "Name",
      "d": 847605,
      "h": 64425357045,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425357045)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590782197),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 847605,
      "h": 8590782197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590782197)
  ],
  "h": 847605
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$cHnS.LCUCS.IUriResourceTypeProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IThemable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.Services.UriImageProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}Services${separator}UriImageProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(847605)
        
        

        //--TRIMMABLE-BOUNDARY-START(782069)
        $asm.$cls(`$cHnS.LCUCS.UriEmailProvider`, ($self) => class UriEmailProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015226101)
            /*string? */ get Title()
            {
                return "Email";
            }
            //--TRIMMABLE-BOUNDARY-END(73015226101)
            
            //--TRIMMABLE-BOUNDARY-START(12885683957)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885683957)
            
            //--TRIMMABLE-BOUNDARY-START(60130324213)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-email"/*MaterialDesignIconNames.Email*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60130324213)
            
            //--TRIMMABLE-BOUNDARY-START(68720258805)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Success);
            }
            //--TRIMMABLE-BOUNDARY-END(68720258805)
            
            //--TRIMMABLE-BOUNDARY-START(64425291509)
            /*string? */ get Name()
            {
                return "Email";
            }
            //--TRIMMABLE-BOUNDARY-END(64425291509)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8590716661)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590716661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590716661)
            
            //--TRIMMABLE-BOUNDARY-START(8590716661)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590716661)
            
            static $h = 782069;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015226101),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835356917,
        "f": 50331649
      },
      "n": "Title",
      "d": 782069,
      "h": 73015226101,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015226101),
//--TRIMMABLE-BOUNDARY-START(12885683957),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475618549,
        "f": 50331649
      },
      "n": "Description",
      "d": 782069,
      "h": 12885683957,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885683957),
//--TRIMMABLE-BOUNDARY-START(60130324213),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065553141,
        "f": 50331649
      },
      "n": "Icon",
      "d": 782069,
      "h": 60130324213,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130324213),
//--TRIMMABLE-BOUNDARY-START(68720258805),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245422325,
        "f": 50331649
      },
      "n": "Theme",
      "d": 782069,
      "h": 68720258805,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720258805),
//--TRIMMABLE-BOUNDARY-START(64425291509),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655487733,
        "f": 50331649
      },
      "n": "Name",
      "d": 782069,
      "h": 64425291509,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425291509)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590716661),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 782069,
      "h": 8590716661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590716661)
  ],
  "h": 782069
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$cHnS.LCUCS.IUriResourceTypeProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IThemable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.Services.UriEmailProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}Services${separator}UriEmailProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(782069)
        
        

        //--TRIMMABLE-BOUNDARY-START(716533)
        $asm.$cls(`$cHnS.LCUCS.UriAddressProvider`, ($self) => class UriAddressProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015160565)
            /*string? */ get Title()
            {
                return "Address";
            }
            //--TRIMMABLE-BOUNDARY-END(73015160565)
            
            //--TRIMMABLE-BOUNDARY-START(12885618421)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885618421)
            
            //--TRIMMABLE-BOUNDARY-START(60130258677)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-map-marker"/*MaterialDesignIconNames.MapMarker*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60130258677)
            
            //--TRIMMABLE-BOUNDARY-START(68720193269)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Warning);
            }
            //--TRIMMABLE-BOUNDARY-END(68720193269)
            
            //--TRIMMABLE-BOUNDARY-START(64425225973)
            /*string? */ get Name()
            {
                return "Address";
            }
            //--TRIMMABLE-BOUNDARY-END(64425225973)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8590651125)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590651125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590651125)
            
            //--TRIMMABLE-BOUNDARY-START(8590651125)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590651125)
            
            static $h = 716533;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015160565),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835291381,
        "f": 50331649
      },
      "n": "Title",
      "d": 716533,
      "h": 73015160565,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015160565),
//--TRIMMABLE-BOUNDARY-START(12885618421),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475553013,
        "f": 50331649
      },
      "n": "Description",
      "d": 716533,
      "h": 12885618421,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885618421),
//--TRIMMABLE-BOUNDARY-START(60130258677),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065487605,
        "f": 50331649
      },
      "n": "Icon",
      "d": 716533,
      "h": 60130258677,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130258677),
//--TRIMMABLE-BOUNDARY-START(68720193269),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245356789,
        "f": 50331649
      },
      "n": "Theme",
      "d": 716533,
      "h": 68720193269,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720193269),
//--TRIMMABLE-BOUNDARY-START(64425225973),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655422197,
        "f": 50331649
      },
      "n": "Name",
      "d": 716533,
      "h": 64425225973,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425225973)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590651125),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 716533,
      "h": 8590651125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590651125)
  ],
  "h": 716533
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$cHnS.LCUCS.IUriResourceTypeProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IThemable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.Services.UriAddressProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}Services${separator}UriAddressProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(716533)
        
        

        //--TRIMMABLE-BOUNDARY-START(978677)
        $asm.$cls(`$cHnS.LCUCS.UriPhoneProvider`, ($self) => class UriPhoneProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015422709)
            /*string? */ get Title()
            {
                return "Phone";
            }
            //--TRIMMABLE-BOUNDARY-END(73015422709)
            
            //--TRIMMABLE-BOUNDARY-START(12885880565)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885880565)
            
            //--TRIMMABLE-BOUNDARY-START(60130520821)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-phone"/*MaterialDesignIconNames.Phone*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60130520821)
            
            //--TRIMMABLE-BOUNDARY-START(68720455413)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Secondary);
            }
            //--TRIMMABLE-BOUNDARY-END(68720455413)
            
            //--TRIMMABLE-BOUNDARY-START(64425488117)
            /*string? */ get Name()
            {
                return "Phone";
            }
            //--TRIMMABLE-BOUNDARY-END(64425488117)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8590913269)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590913269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590913269)
            
            //--TRIMMABLE-BOUNDARY-START(8590913269)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590913269)
            
            static $h = 978677;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015422709),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835553525,
        "f": 50331649
      },
      "n": "Title",
      "d": 978677,
      "h": 73015422709,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015422709),
//--TRIMMABLE-BOUNDARY-START(12885880565),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475815157,
        "f": 50331649
      },
      "n": "Description",
      "d": 978677,
      "h": 12885880565,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885880565),
//--TRIMMABLE-BOUNDARY-START(60130520821),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065749749,
        "f": 50331649
      },
      "n": "Icon",
      "d": 978677,
      "h": 60130520821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130520821),
//--TRIMMABLE-BOUNDARY-START(68720455413),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245618933,
        "f": 50331649
      },
      "n": "Theme",
      "d": 978677,
      "h": 68720455413,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720455413),
//--TRIMMABLE-BOUNDARY-START(64425488117),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655684341,
        "f": 50331649
      },
      "n": "Name",
      "d": 978677,
      "h": 64425488117,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425488117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590913269),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 978677,
      "h": 8590913269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590913269)
  ],
  "h": 978677
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$cHnS.LCUCS.IUriResourceTypeProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IThemable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.Services.UriPhoneProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}Services${separator}UriPhoneProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(978677)
        
        

        //--TRIMMABLE-BOUNDARY-START(913141)
        $asm.$cls(`$cHnS.LCUCS.UriLinkProvider`, ($self) => class UriLinkProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77310324469)
            /*string? */ get Title()
            {
                return "Link";
            }
            //--TRIMMABLE-BOUNDARY-END(77310324469)
            
            //--TRIMMABLE-BOUNDARY-START(12885815029)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885815029)
            
            //--TRIMMABLE-BOUNDARY-START(60130455285)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-link"/*MaterialDesignIconNames.Link*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60130455285)
            
            //--TRIMMABLE-BOUNDARY-START(73015357173)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Primary);
            }
            //--TRIMMABLE-BOUNDARY-END(73015357173)
            
            //--TRIMMABLE-BOUNDARY-START(68720389877)
            /*string? */ get Name()
            {
                return "Link";
            }
            //--TRIMMABLE-BOUNDARY-END(68720389877)
            
            //--TRIMMABLE-BOUNDARY-START(64425422581)
            /*RenderFragment? */ LCUCS$IUriResourceTypeProvider$GetView(/*UriLinkItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425422581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(1, "a");
                    builder.AddAttribute$5(2, "href", item.Text);
                    builder.AddContent$4(3, item.Title ?? item.Text);
                    builder.CloseElement();
                }, $qaACUc ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":913141,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(64425422581)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8590847733)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590847733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590847733)
            
            //--TRIMMABLE-BOUNDARY-START(8590847733)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590847733)
            
            static $h = 913141;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310324469),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835487989,
        "f": 50331649
      },
      "n": "Title",
      "d": 913141,
      "h": 77310324469,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310324469),
//--TRIMMABLE-BOUNDARY-START(12885815029),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475749621,
        "f": 50331649
      },
      "n": "Description",
      "d": 913141,
      "h": 12885815029,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885815029),
//--TRIMMABLE-BOUNDARY-START(60130455285),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065684213,
        "f": 50331649
      },
      "n": "Icon",
      "d": 913141,
      "h": 60130455285,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130455285),
//--TRIMMABLE-BOUNDARY-START(73015357173),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245553397,
        "f": 50331649
      },
      "n": "Theme",
      "d": 913141,
      "h": 73015357173,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015357173),
//--TRIMMABLE-BOUNDARY-START(68720389877),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655618805,
        "f": 50331649
      },
      "n": "Name",
      "d": 913141,
      "h": 68720389877,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720389877)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590847733),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 913141,
      "h": 8590847733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590847733)
  ],
  "h": 913141
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$cHnS.LCUCS.IUriResourceTypeProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IThemable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.Services.UriLinkProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}Services${separator}UriLinkProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(913141)
        
        

        //--TRIMMABLE-BOUNDARY-START(1175285)
        $asm.$cls(`$cHnS.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296142581)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296142581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296142581)
            
            //--TRIMMABLE-BOUNDARY-START(4296142581)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296142581)
            
            static $h = 1175285;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296142581),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1175285,
      "h": 4296142581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296142581)
  ],
  "h": 1175285
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1175285)
        
        

        //--TRIMMABLE-BOUNDARY-START(1240821)
        $asm.$cls(`$cHnS.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296208117)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296208117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296208117)
            
            //--TRIMMABLE-BOUNDARY-START(4296208117)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296208117)
            
            static $h = 1240821;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296208117),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1240821,
      "h": 4296208117,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296208117)
  ],
  "h": 1240821,
  "a": [
    {
      "t": 1175285,
      "c": 4296142581
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1240821)
        
        

        //--TRIMMABLE-BOUNDARY-START(126709)
        $asm.$cls(`$cHnS.LCUC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590061301)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590061301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590061301)
            
            //--TRIMMABLE-BOUNDARY-START(4295094005)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295094005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295094005)
            
            //--TRIMMABLE-BOUNDARY-START(4295094005)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295094005)
            
            static $h = 126709;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590061301),
    {
      "r": 65537,
      "n": "Execute",
      "d": 126709,
      "h": 8590061301,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590061301)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295094005),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 126709,
      "h": 4295094005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295094005)
  ],
  "h": 126709
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(126709)
        
        

        //--TRIMMABLE-BOUNDARY-START(519925)
        $asm.$cls(`$cHnS.LCUCP.UriApp`, ($self) => class UriApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(219043852021)
            /*string */ get OptimizedComponentName()
            {
                return "uriapp";
            }
            //--TRIMMABLE-BOUNDARY-END(219043852021)
            
            //--TRIMMABLE-BOUNDARY-START(317828099829)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828099829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Code":
                    this.Code = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(317828099829)
            
            //--TRIMMABLE-BOUNDARY-START(167504244469)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504244469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Clipboard = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IClipboardAccessor, serviceProvider);
                this.Providers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$cHnS.LCUCS.IUriResourceTypeProvider), serviceProvider);
                this.NavigationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(167504244469)
            
            //--TRIMMABLE-BOUNDARY-START(64425029365)
            /*string?*/ Code = null;
            //--TRIMMABLE-BOUNDARY-END(64425029365)
            
            //--TRIMMABLE-BOUNDARY-START(55835094773)
            /*IClipboardAccessor*/ Clipboard = null;
            //--TRIMMABLE-BOUNDARY-END(55835094773)
            
            //--TRIMMABLE-BOUNDARY-START(231928753909)
            /*IEnumerable<IUriResourceTypeProvider>*/ Providers = null;
            //--TRIMMABLE-BOUNDARY-END(231928753909)
            
            //--TRIMMABLE-BOUNDARY-START(206158950133)
            /*NavigationManager*/ NavigationManager = null;
            //--TRIMMABLE-BOUNDARY-END(206158950133)
            
            //--TRIMMABLE-BOUNDARY-START(201863982837)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(201863982837)
            
            //--TRIMMABLE-BOUNDARY-START(197569015541)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197569015541)
            
            //--TRIMMABLE-BOUNDARY-START(322123067125)
            /*WizardSteps?*/ wizard = null;
            //--TRIMMABLE-BOUNDARY-END(322123067125)
            
            //--TRIMMABLE-BOUNDARY-START(176094179061)
            /*List<UriLinkItem>*/ items = null;
            //--TRIMMABLE-BOUNDARY-END(176094179061)
            
            //--TRIMMABLE-BOUNDARY-START(47245160181)
            /*bool*/ autoRedirect = false;
            //--TRIMMABLE-BOUNDARY-END(47245160181)
            
            //--TRIMMABLE-BOUNDARY-START(60130062069)
            /*string?*/ code = null;
            //--TRIMMABLE-BOUNDARY-END(60130062069)
            
            //--TRIMMABLE-BOUNDARY-START(223338819317)
            /*string?*/ password = null;
            //--TRIMMABLE-BOUNDARY-END(223338819317)
            
            //--TRIMMABLE-BOUNDARY-START(77309931253)
            /*string?*/ description = null;
            //--TRIMMABLE-BOUNDARY-END(77309931253)
            
            //--TRIMMABLE-BOUNDARY-START(81604898549)
            /*Dictionary<IUriResourceTypeProvider, string?>*/ entries = null;
            //--TRIMMABLE-BOUNDARY-END(81604898549)
            
            //--TRIMMABLE-BOUNDARY-START(227633786613)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(227633786613)
            
            //--TRIMMABLE-BOUNDARY-START(227633786613)
            //--TRIMMABLE-BOUNDARY-START(38655225589)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655225589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38655225589)
            
            //--TRIMMABLE-BOUNDARY-START(240518688501)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518688501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(240518688501)
            
            //--TRIMMABLE-BOUNDARY-END(227633786613)
            
            //--TRIMMABLE-BOUNDARY-START(313533132533)
            /*string?*/ get_Item$1(/*IUriResourceTypeProvider*/ provider)
            {
                /*var*/ let e;
                this.entries.TryGetValue(provider, $.$ref(() => e, ($v) => e = $v, $.$$.S.String));
                return e;
            }
            /*void*/ set_Item$1(/*IUriResourceTypeProvider*/ provider, /*string?*/ value)
            {
                this.entries.set_Item(provider, value);
            }
            //--TRIMMABLE-BOUNDARY-END(313533132533)
            
            //--TRIMMABLE-BOUNDARY-START(188979080949)
            /*ValueTask */ LoadCode(/*string*/ code)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979080949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t3, $r3;
                        /*var*/ let link = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$Iaui.LCFCM.ShortLinkModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(code, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        if (link !== null)
                        {
                            /*var*/ let uri = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$gGJx.LCUCM.UriModel, link.Link, false, "LoadCode", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Uri.Client.Blazor\\UriApp.razor.cs", "LoadCode", 62);
                            if ((uri?.Items ?? null) !== null)
                            {
                                this.items.AddRange(uri.Items);
                                if (this.wizard !== null)
                                {
                                    let $t4, $r4;
                                    ($t4 = this.wizard.SetCurrentViewName("View"), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                }
                            }
                        }
                    });
                }, $bICefi ??= {"r":181338113,"n":"","d":519925,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                }, $TXYuIe ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":519925,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(188979080949)
            
            //--TRIMMABLE-BOUNDARY-START(193274048245)
            /*ValueTask */ LoadEntry()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274048245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.String.IsNullOrEmpty(this.code))
                {
                    return this.LoadCode(this.code);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(193274048245)
            
            //--TRIMMABLE-BOUNDARY-START(214748884725)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748884725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t5 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(214748884725)
            
            //--TRIMMABLE-BOUNDARY-START(210453917429)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210453917429);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender)
                    {
                        if (this.Code === "Create")
                        {
                            let $t6, $r6;
                            ($t6 = this.wizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        }
                        else if (!$.$$.S.String.IsNullOrEmpty(this.Code))
                        {
                            let $t7, $r7;
                            ($t7 = this.LoadCode(this.Code), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        }
                    }
                    ($t8 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(210453917429)
            
            //--TRIMMABLE-BOUNDARY-START(42950192885)
            /*void */ AddItem(/*IUriResourceTypeProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950192885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.items.Add((() =>
                {
                    //new $.$gGJx.LCUCM.UriLinkItem()
                    const $t9 = $.$gGJx.LCUCM.UriLinkItem;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.ProviderName = provider.LCFC$INamed$Name;
                    $i9.Text = this.get_Item$1(provider);
                    return $i9;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(42950192885)
            
            //--TRIMMABLE-BOUNDARY-START(244813655797)
            /*void */ RemoveItem(/*UriLinkItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813655797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.items.Remove($.$clone(item));
            }
            //--TRIMMABLE-BOUNDARY-END(244813655797)
            
            //--TRIMMABLE-BOUNDARY-START(180389146357)
            /*ShortLinkModel?*/ link = null;
            //--TRIMMABLE-BOUNDARY-END(180389146357)
            
            //--TRIMMABLE-BOUNDARY-START(73014963957)
            /*ValueTask */ Create()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014963957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t12, $r12;
                        let $t13, $r13;
                        /*var*/ let uri = (() =>
                        {
                            //new $.$gGJx.LCUCM.UriModel()
                            const $t10 = $.$gGJx.LCUCM.UriModel;
                            const $i10 = new $t10();
                            $i10.$ctor$1();
                            $i10.AutoRedirects = this.autoRedirect;
                            $i10.Password = this.password;
                            $i10.Description = this.description;
                            $i10.Items = this.items;
                            return $i10;
                        })();
                        /*var*/ let json = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$gGJx.LCUCM.UriModel, uri, true, false, true, false, false, false, false, "Create", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Uri.Client.Blazor\\UriApp.razor.cs", "Create", 128);
                        /*var*/ let shortLink = (() =>
                        {
                            //new $.$Iaui.LCFCM.ShortLinkModel()
                            const $t11 = $.$Iaui.LCFCM.ShortLinkModel;
                            const $i11 = new $t11();
                            $i11.$ctor$2();
                            $i11.Link = $.$fPer.LCFCS$1.Serialized.op_Implicit$1(json);
                            return $i11;
                        })();
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ShortLinkModel>?*/ let __ca1__;
                        this.link = ((__ca1__ = (($t12 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Iaui.LCFCM.ShortLinkModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.ShortLinkModel), [ shortLink ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)))).Data) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$Iaui.LCFCM.ShortLinkModel, __ca1__) : null);
                        ($t13 = this.wizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                    });
                }, $TZtNxb ??= {"r":181338113,"n":"","d":519925,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                }, $gyFOJk ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":519925,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(73014963957)
            
            //--TRIMMABLE-BOUNDARY-START(68719996661)
            /*ValueTask */ CopyToClipBoard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719996661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clipboard.LCFCC$IClipboardAccessor$SetAsync(`https://${$.$strNN($.$sl.SL.Enumerable.First$1($.$$.S.String, $.$gGJx.LCUCM.UriModel.Hosts))}/${$.$strNN(this.link.Id)}`);
            }
            //--TRIMMABLE-BOUNDARY-END(68719996661)
            
            //--TRIMMABLE-BOUNDARY-START(309238165237)
            /*MarkupString */ get SVG()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209277173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let qr = $.$wZnq.NCQ.QrCode.EncodeText(`https://uri.ng/${$.$strNN(this.link.Id)}`, 0/*QrCode.Ecc.Low*/);
                /*string*/ let svg = qr.ToSvgString(4, "#000000", "#ffffff");
                return new $.$mac.MAC.MarkupString().$ctor$3(svg);
            }
            //--TRIMMABLE-BOUNDARY-END(309238165237)
            
            //--TRIMMABLE-BOUNDARY-START(85899865845)
            /*void */ Finish()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899865845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.entries.Clear();
                this.items.Clear();
                this.password = null;
                this.autoRedirect = false;
                this.NavigationManager.NavigateTo$2($.$strNN($.$strNN(this.NavigationManager.Uri) + "/") + $.$strNN(this.link.Id), true);
            }
            //--TRIMMABLE-BOUNDARY-END(85899865845)
            
            //--TRIMMABLE-BOUNDARY-START(184684113653)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684113653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(184684113653)
            
            //--TRIMMABLE-BOUNDARY-START(51540127477)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540127477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hv-10 stack bg-fill pos-rel");
                __builder.AddAttribute$5(2, "style", $.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/bg.jpg", true, false, false)))) + "');");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "mg-a pd-10 bg-card shadow corner op-9 mawx-6 clip pos-rel");
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 5);
                __builder.AddComponentParameter(6, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 9);
                    __builder2.AddComponentParameter(10, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                    __builder2.AddComponentParameter(11, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                    __builder2.AddComponentParameter(12, "MultiViewFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$6.MultiViewFeatures, 68/*MultiViewFeatures.Default*/ | 2/*MultiViewFeatures.Transition*/), $.$hDPm.LCFCCM$6.MultiViewFeatures));
                    __builder2.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 14);
                        __builder3.AddComponentParameter(15, "Name", "Start");
                        __builder3.AddComponentParameter(16, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 83/*DisplayMode.SlideInUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddComponentParameter(17, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 87/*DisplayMode.SlideOutUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddAttribute$3(18, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(19, "<h1 class=\"mgt-0 text-center\">\r\n                        Enter your URI Code\r\n                    </h1>\r\n                    ");
                                __builder4.OpenComponent$1($.$macw.MACF.EditForm, 20);
                                __builder4.AddComponentParameter(21, "class", "flex corner clip");
                                __builder4.AddComponentParameter(22, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                __builder4.AddComponentParameter(23, "OnValidSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macf.MACF.EditContext), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macf.MACF.EditContext, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.LoadEntry))));
                                __builder4.AddAttribute$3(24, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*__*/ __) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenElement(25, "input");
                                        __builder5.AddAttribute$5(26, "type", "text");
                                        __builder5.AddAttribute$5(27, "class", "bd pd fsz-30");
                                        __builder5.AddAttribute$5(28, "placeholder", "URI Code here");
                                        __builder5.AddAttribute$5(29, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.code, null));
                                        __builder5.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 30, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            return this.code = __value;
                                        }, $vgxbcj ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":519925,"h":0,"f":17825794}), this.code, null));
                                        __builder5.SetUpdatesAttributeName("value");
                                        __builder5.CloseElement();
                                        __builder5.AddMarkupContent(31, "\r\n                        <button class=\"bg-primary pd mdi mdi-google-lens fsz-30\" type=\"submit\"></button>");
                                    }, $RvLgeh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                                }), $WbmCZh ??= {"r":6881395,"p":[{"n":"__","p":131188}],"n":"","d":519925,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                                __builder4.AddMarkupContent(32, "\r\n                    ");
                                __builder4.AddMarkupContent(33, "<p class=\"text-center\">OR</p>\r\n                    ");
                                __builder4.OpenElement(34, "div");
                                __builder4.AddAttribute$5(35, "class", "flex");
                                __builder4.OpenElement(36, "button");
                                __builder4.AddAttribute$5(37, "class", "mg-a bg-primary pd miwx-25 corner fsz-30 fw-bold");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 38, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.wizard, this.wizard.NextView)));
                                __builder4.AddContent$4(39, "Create a link");
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }, $FjpwLc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                        }), $ivqKSk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":519925,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(40, "\r\n                ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 41);
                        __builder3.AddComponentParameter(42, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 83/*DisplayMode.SlideInUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddComponentParameter(43, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 87/*DisplayMode.SlideOutUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddAttribute$3(44, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(45, "h1");
                                __builder4.AddAttribute$5(46, "class", "mgt-0 text-center");
                                __builder4.OpenElement(47, "button");
                                __builder4.AddAttribute$5(48, "class", "bg-transparent mdi mdi-arrow-left fsz-25");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 49, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.wizard, this.wizard.PreviousView)));
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(50, "\r\n                        What do you want to link with your code?\r\n                    ");
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(51, "\r\n                    ");
                                __builder4.OpenElement(52, "div");
                                __builder4.AddAttribute$5(53, "class", "flex flex-center-x flex-spacebetween-x pos-rel");
                                let $en14 = $.$sl.SL.Enumerable.Where($.$cHnS.LCUCS.IUriResourceTypeProvider, this.Providers, new ($.$$.S.Func$$$($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                                {
                                    return !this.autoRedirect || p.LCFC$INamed$Name === "Link";
                                }, $ZADtOg ??= {"r":262145,"p":[{"n":"p","p":650997}],"n":"","d":519925,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                                while ($en14.SC$1$IEnumerator$MoveNext())
                                {
                                    let provider = $en14.SCG$IEnumerator$$$Current;
                                    {
                                        __builder4.OpenElement(54, "div");
                                        __builder4.AddAttribute$5(55, "class", "stack text-center mgx popup");
                                        __builder4.AddAttribute$5(56, "tabindex", "-1");
                                        __builder4.OpenElement(57, "div");
                                        __builder4.AddAttribute$5(58, "class", "mg-a hx-05 wx-05 bd round flex clickable");
                                        __builder4.OpenElement(59, "i");
                                        __builder4.AddMultipleAttributes(60, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(provider.LCFCC$IThemable$Theme.ToHtmlAttributes("cl-"), `${$.$strNN(provider.LCFC$IDisplayable$Icon.Icon)}-plus fsz-30 mg-a`))));
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(61, "\r\n                                ");
                                        __builder4.OpenElement(62, "span");
                                        __builder4.AddContent$4(63, provider.LCFC$INamed$Name);
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(64, "\r\n                                ");
                                        __builder4.OpenElement(65, "pop");
                                        __builder4.AddAttribute$5(66, "class", "bg-card mgt pd shadow at lefttoleft toptobottom wf");
                                        __builder4.OpenElement(67, "h3");
                                        __builder4.AddAttribute$5(68, "class", "mgt-0");
                                        __builder4.AddContent$4(69, "Enter ");
                                        __builder4.AddContent$4(70, provider.LCFC$INamed$Name);
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(71, "\r\n                                    ");
                                        __builder4.OpenComponent$1($.$macw.MACF.EditForm, 72);
                                        __builder4.AddComponentParameter(73, "class", "flex");
                                        __builder4.AddComponentParameter(74, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                        __builder4.AddComponentParameter(75, "OnValidSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macf.MACF.EditContext), $.$mac.MAC.EventCallback.Factory.Create$7($.$macf.MACF.EditContext, this, new $.$$.S.Action().$ctor(this,  () =>
                                        {
                                            return this.AddItem(provider);
                                        }, $XEzVbb ??= {"r":65537,"n":"","d":519925,"h":0,"f":17825794}))));
                                        __builder4.AddAttribute$3(76, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                /*var*/ let binder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.String))().$ctor$7(this.get_Item$1(provider), new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*v*/ v) =>
                                                {
                                                    return this.set_Item$1(provider, v);
                                                }, $IbjCek ??= {"r":65537,"p":[{"n":"v","p":1310721}],"n":"","d":519925,"h":0,"f":17825794}));
                                                /*var*/ let editor = provider.LCUCS$IUriResourceTypeProvider$GetEditorView(binder);
                                                if (editor !== null)
                                                {
                                                    __builder5.AddContent$1(77, editor);
                                                }
                                                else 
                                                {
                                                    __builder5.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 78);
                                                    __builder5.AddComponentParameter(79, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, provider.LCUCS$IUriResourceTypeProvider$InputType), $.$fPer.LCFC.InputType));
                                                    __builder5.AddComponentParameter(80, "Class", "pd wf bd fsz-20");
                                                    __builder5.AddComponentParameter(81, "PlaceHolder", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, provider.LCFC$INamed$Name));
                                                    __builder5.AddComponentParameter(82, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, binder.Value));
                                                    __builder5.AddComponentParameter(83, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return binder.Value = __value;
                                                    }, $LuDKSk ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":519925,"h":0,"f":17825794}), binder.Value))));
                                                    __builder5.AddComponentParameter(84, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(binder), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $YZqSOi ??= {"r":38797349,"n":"","d":519925,"h":0,"f":17825794})).Invoke())));
                                                    __builder5.CloseComponent();
                                                }
                                                __builder5.AddMarkupContent(85, "<button class=\"bg-primary mdi mdi-plus pd-5 fsz-20\" type=\"submit\"></button>");
                                            }, $uCbjji ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                                        }), $WVsrAi ??= {"r":6881395,"p":[{"n":"__","p":131188}],"n":"","d":519925,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                    }
                                }
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(86, "\r\n                    ");
                                __builder4.OpenElement(87, "div");
                                __builder4.AddAttribute$5(88, "class", "mgt-10 mahx-15 scroll");
                                __builder4.AddContent$1(89, this.ItemList(new ($.$mac.MAC.RenderFragment$$($.$gGJx.LCUCM.UriLinkItem))().$ctor(this,  (/*item*/ item) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenElement(90, "button");
                                        __builder5.AddAttribute$5(91, "class", "mdi mdi-delete bg-transparent cl-error fsz-25 mgy-a wx-04 hx-04 bd bd-error round");
                                        __builder5.AddAttribute$7($.$macw.MACW.MouseEventArgs, 92, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                        {
                                            return this.RemoveItem($.$clone(item));
                                        }, $IYtIYf ??= {"r":65537,"n":"","d":519925,"h":0,"f":17825794})));
                                        __builder5.CloseElement();
                                    }, $vdyePj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                                }, $KliVKk ??= {"r":6881395,"p":[{"n":"item","p":89850}],"n":"","d":519925,"h":0,"f":17825794})));
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(93, "\r\n                    ");
                                __builder4.OpenElement(94, "div");
                                __builder4.AddAttribute$5(95, "class", "flex");
                                __builder4.OpenElement(96, "input");
                                __builder4.AddAttribute$5(97, "class", "mgy-a");
                                __builder4.AddAttribute$5(98, "id", "autoRedirect");
                                __builder4.AddAttribute$5(99, "type", "checkbox");
                                __builder4.AddAttribute$2(100, "value", $.$mac.MAC.BindConverter.FormatValue(this.autoRedirect, null));
                                __builder4.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 101, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.autoRedirect = __value;
                                }, $iViYTg ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":519925,"h":0,"f":17825794}), this.autoRedirect, null));
                                __builder4.SetUpdatesAttributeName("value");
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(102, "\r\n                        ");
                                __builder4.AddMarkupContent(103, "<label class=\"mgy-a\" for=\"autoRedirect\"> Automatic Redirect</label>\r\n                        ");
                                __builder4.OpenElement(104, "div");
                                __builder4.AddAttribute$5(105, "class", "fill stack mgx");
                                if (this.autoRedirect)
                                {
                                    __builder4.AddMarkupContent(106, "<span class=\"mgy-a cl-warning\">A redirection uri can only contains link</span>");
                                }
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(107, "\r\n                        ");
                                __builder4.OpenElement(108, "button");
                                __builder4.AddAttribute$5(109, "class", "bg-primary pd-5 corner miwx-15 fsz-20 fw-bold");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 110, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.wizard, this.wizard.NextView)));
                                __builder4.AddContent$4(111, "Continue");
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }, $fyBhbf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                        }), $oXdOll ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":519925,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(112, "\r\n                ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 113);
                        __builder3.AddComponentParameter(114, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 83/*DisplayMode.SlideInUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddComponentParameter(115, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 87/*DisplayMode.SlideOutUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddAttribute$3(116, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(117, "h1");
                                __builder4.AddAttribute$5(118, "class", "mgt-0 text-center");
                                __builder4.OpenElement(119, "button");
                                __builder4.AddAttribute$5(120, "class", "bg-transparent mdi mdi-arrow-left fsz-25");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 121, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.wizard, this.wizard.PreviousView)));
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(122, "\r\n                        Optionally set a description and a password to protect this link. Leave blank to keep link open\r\n                    ");
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(123, "\r\n                    ");
                                __builder4.OpenElement(124, "input");
                                __builder4.AddAttribute$5(125, "type", "text");
                                __builder4.AddAttribute$5(126, "class", "bd fsz-25 pd wf");
                                __builder4.AddAttribute$5(127, "placeholder", "Description");
                                __builder4.AddAttribute$5(128, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.description, null));
                                __builder4.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 129, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.description = __value;
                                }, $ClMFMg ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":519925,"h":0,"f":17825794}), this.description, null));
                                __builder4.SetUpdatesAttributeName("value");
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(130, "\r\n                    ");
                                __builder4.OpenElement(131, "input");
                                __builder4.AddAttribute$5(132, "type", "text");
                                __builder4.AddAttribute$5(133, "class", "bd fsz-25 pd wf mgt");
                                __builder4.AddAttribute$5(134, "placeholder", "Enter Password");
                                __builder4.AddAttribute$5(135, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.password, null));
                                __builder4.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 136, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.password = __value;
                                }, $LFBLVa ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":519925,"h":0,"f":17825794}), this.password, null));
                                __builder4.SetUpdatesAttributeName("value");
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(137, "\r\n                    ");
                                __builder4.OpenElement(138, "div");
                                __builder4.AddAttribute$5(139, "class", "flex mgt");
                                __builder4.AddMarkupContent(140, "<div class=\"fill\"></div>\r\n                        ");
                                __builder4.OpenElement(141, "button");
                                __builder4.AddAttribute$5(142, "class", "bg-primary pd-5 corner miwx-15 fsz-20 fw-bold");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 143, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.wizard, this.wizard.NextView)));
                                __builder4.AddContent$4(144, "Continue");
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }, $XSQGMk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                        }), $XSlPee ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":519925,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(145, "\r\n                ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 146);
                        __builder3.AddComponentParameter(147, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 83/*DisplayMode.SlideInUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddComponentParameter(148, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 87/*DisplayMode.SlideOutUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddAttribute$3(149, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(150, "h1");
                                __builder4.AddAttribute$5(151, "class", "mgt-0 text-center");
                                __builder4.OpenElement(152, "button");
                                __builder4.AddAttribute$5(153, "class", "bg-transparent mdi mdi-arrow-left fsz-25");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 154, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.wizard, this.wizard.PreviousView)));
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(155, "\r\n                        Ready to Publish? These are the items in your link.\r\n                    ");
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(156, "\r\n                    ");
                                __builder4.AddContent$1(157, this.ItemList(null));
                                __builder4.AddMarkupContent(158, "\r\n                    ");
                                __builder4.OpenElement(159, "div");
                                __builder4.AddAttribute$5(160, "class", "flex mgt");
                                __builder4.AddMarkupContent(161, "<div class=\"fill\"></div>\r\n                        ");
                                __builder4.OpenElement(162, "button");
                                __builder4.AddAttribute$5(163, "class", "bg-primary pd-5 corner miwx-15 fsz-20 fw-bold");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 164, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Create)));
                                __builder4.AddContent$4(165, "Publish");
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }, $CylsOd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                        }), $AyjnEc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":519925,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(166, "\r\n                ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 167);
                        __builder3.AddComponentParameter(168, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 83/*DisplayMode.SlideInUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddComponentParameter(169, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 87/*DisplayMode.SlideOutUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddAttribute$3(170, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(171, "h1");
                                __builder4.AddAttribute$5(172, "class", "mgt-0 text-center");
                                __builder4.AddMarkupContent(173, "\r\n                        Your uri is published! Link code is\r\n                        ");
                                __builder4.OpenElement(174, "a");
                                __builder4.AddAttribute$5(175, "href", $.$strNN($.$strNN("https://" + $.$strNN(($.$sl.SL.Enumerable.First$1($.$$.S.String, $.$gGJx.LCUCM.UriModel.Hosts)))) + "/") + $.$strNN((this.link.Id)));
                                __builder4.AddAttribute$5(176, "class", "cl-primary");
                                __builder4.AddContent$4(177, this.link.Id);
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(178, "\r\n                    ");
                                __builder4.OpenElement(179, "h1");
                                __builder4.AddAttribute$5(180, "class", "text-center fsz-80 mg-0");
                                __builder4.AddContent$4(181, this.link.Id);
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(182, "\r\n                    ");
                                __builder4.OpenElement(183, "div");
                                __builder4.AddAttribute$5(184, "class", "flex flex-center-x mgb");
                                __builder4.AddMarkupContent(185, "<h3 class=\"mgy-a\">Share</h3>\r\n                        ");
                                __builder4.OpenElement(186, "button");
                                __builder4.AddAttribute$5(187, "class", "mgl mgy-a mdi mdi-content-copy bg-success hx-04 wx-04 round");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 188, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.CopyToClipBoard)));
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(189, "\r\n                    ");
                                __builder4.OpenElement(190, "div");
                                __builder4.AddAttribute$5(191, "class", "flex");
                                __builder4.OpenElement(192, "div");
                                __builder4.AddAttribute$5(193, "class", "mgx-a hx-2 wx-2");
                                __builder4.AddContent(194, this.SVG);
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(195, "\r\n                    ");
                                __builder4.OpenElement(196, "div");
                                __builder4.AddAttribute$5(197, "class", "flex mgt");
                                __builder4.AddMarkupContent(198, "<div class=\"fill\"></div>\r\n                        ");
                                __builder4.OpenElement(199, "button");
                                __builder4.AddAttribute$5(200, "class", "bg-primary pd-5 corner miwx-15 fsz-20 fw-bold");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 201, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Finish)));
                                __builder4.AddContent$4(202, "Finish");
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }, $bfafPc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                        }), $FoQVBf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":519925,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(203, "\r\n                ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 204);
                        __builder3.AddComponentParameter(205, "Name", "View");
                        __builder3.AddComponentParameter(206, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 83/*DisplayMode.SlideInUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddComponentParameter(207, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 87/*DisplayMode.SlideOutUp*/), $.$hDPm.LCFCI.DisplayMode));
                        __builder3.AddAttribute$3(208, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(209, "h1");
                                __builder4.AddAttribute$5(210, "class", "mgt-0 text-center");
                                __builder4.AddContent$4(211, "URI code ");
                                __builder4.OpenElement(212, "span");
                                __builder4.AddAttribute$5(213, "class", "cl-primary");
                                __builder4.AddContent$4(214, this.Code);
                                __builder4.CloseElement();
                                __builder4.AddContent$4(215, " is linked to");
                                __builder4.CloseElement();
                                if (this.items.Count > 0)
                                {
                                    __builder4.AddContent$1(216, this.ItemList(null));
                                }
                                else 
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 217);
                                    __builder4.AddComponentParameter(218, "Class", "mgx-a");
                                    __builder4.AddComponentParameter(219, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                                    __builder4.CloseComponent();
                                }
                            }, $ecmdae ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
                        }), $zuoPrj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":519925,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $iffoti ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":519925,"h":0,"f":17825794}));
                    __builder2.AddComponentReferenceCapture(220, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.wizard = $.$cast(__value, $.$hDPm.LCFCCW$1.WizardSteps);
                    }, $ejHyEa ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":519925,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $zCrnyd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":519925,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(51540127477)
            
            //--TRIMMABLE-BOUNDARY-START(171799211765)
            /*RenderFragment */ ItemList(/*RenderFragment<UriLinkItem>?*/ more)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799211765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    let $en15 = this.items.GetEnumerator();
                    while ($en15.MoveNext())
                    {
                        let item = $en15.Current;
                        {
                            /*var*/ let provider = $.$sl.SL.Enumerable.SingleOrDefault$1($.$cHnS.LCUCS.IUriResourceTypeProvider, this.Providers, new ($.$$.S.Func$$$($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                            {
                                return s.LCFC$INamed$Name === item.ProviderName;
                            }, $xcLIVd ??= {"r":262145,"p":[{"n":"s","p":650997}],"n":"","d":519925,"h":0,"f":17825794}));
                            if (provider !== null)
                            {
                                __builder2.OpenElement(221, "div");
                                __builder2.AddMultipleAttributes(222, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(provider.LCFCC$IThemable$Theme.ToHtmlAttributes("cl-"), "flex mgy"))));
                                __builder2.OpenElement(223, "div");
                                __builder2.AddAttribute$5(224, "class", "hx-06 wx-06 bd round flex");
                                __builder2.OpenElement(225, "i");
                                __builder2.AddAttribute$5(226, "class", $.$strNN($.$strNN("mg-a" + " ") + $.$strNN((provider.LCFC$IDisplayable$Icon.Icon))) + " fsz-30");
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(227, "\r\n                        ");
                                __builder2.OpenElement(228, "h1");
                                __builder2.AddAttribute$5(229, "class", "mgy-a mgl fill");
                                __builder2.AddContent$1(230, provider.LCUCS$IUriResourceTypeProvider$GetView($.$clone(item)));
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(231, "\r\n                        ");
                                __builder2.AddContent$1(232, (more?.Invoke($.$clone(item)) ?? null));
                                __builder2.CloseElement();
                            }
                        }
                    }
                }, $aGxQoi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":519925,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(171799211765)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(30065290997)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065290997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065290997)
            
            //--TRIMMABLE-BOUNDARY-START(30065290997)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30065290997)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835094773)
                this.Clipboard = null;
                //--TRIMMABLE-BOUNDARY-END(55835094773)
                
                //--TRIMMABLE-BOUNDARY-START(231928753909)
                this.Providers = null;
                //--TRIMMABLE-BOUNDARY-END(231928753909)
                
                //--TRIMMABLE-BOUNDARY-START(206158950133)
                this.NavigationManager = null;
                //--TRIMMABLE-BOUNDARY-END(206158950133)
                
                //--TRIMMABLE-BOUNDARY-START(201863982837)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(201863982837)
                
                //--TRIMMABLE-BOUNDARY-START(176094179061)
                this.items = new ($.$$.SCG.List$$($.$gGJx.LCUCM.UriLinkItem))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(176094179061)
                
                //--TRIMMABLE-BOUNDARY-START(81604898549)
                this.entries = new ($.$$.SCG.Dictionary$$$($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(81604898549)
                
            }
            static $h = 519925;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(219043852021),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029407989,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 519925,
      "h": 219043852021,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(219043852021),
//--TRIMMABLE-BOUNDARY-START(64425029365),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079735029,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993524981,
        "f": 83886081
      },
      "n": "Code",
      "d": 519925,
      "h": 64425029365,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425029365),
//--TRIMMABLE-BOUNDARY-START(55835094773),
    {
      "p": 2776488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489800437,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403590389,
        "f": 83886081
      },
      "n": "Clipboard",
      "d": 519925,
      "h": 55835094773,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835094773),
//--TRIMMABLE-BOUNDARY-START(231928753909),
    {
      "p": $.$$.SCG.IEnumerable$$($.$cHnS.LCUCS.IUriResourceTypeProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619342581,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943197941,
        "f": 83886081
      },
      "n": "Providers",
      "d": 519925,
      "h": 231928753909,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231928753909),
//--TRIMMABLE-BOUNDARY-START(206158950133),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439473397,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353263349,
        "f": 83886081
      },
      "n": "NavigationManager",
      "d": 519925,
      "h": 206158950133,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206158950133),
//--TRIMMABLE-BOUNDARY-START(201863982837),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849538805,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763328757,
        "f": 83886081
      },
      "n": "Loading",
      "d": 519925,
      "h": 201863982837,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201863982837),
//--TRIMMABLE-BOUNDARY-START(197569015541),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259604213,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173394165,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 519925,
      "h": 197569015541,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569015541),
//--TRIMMABLE-BOUNDARY-START(313533132533),
    {
      "p": 1310721,
      "i": [
        {
          "n": "provider",
          "p": 650997
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669669621,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583459573,
        "f": 83886082
      },
      "n": "Item",
      "o": "@$1",
      "d": 519925,
      "h": 313533132533,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(313533132533),
//--TRIMMABLE-BOUNDARY-START(309238165237),
    {
      "p": 4849779,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209277173,
        "f": 50331650
      },
      "n": "SVG",
      "d": 519925,
      "h": 309238165237,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(309238165237)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(317828099829),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 519925,
      "h": 317828099829,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(317828099829),
//--TRIMMABLE-BOUNDARY-START(167504244469),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 519925,
      "h": 167504244469,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504244469),
//--TRIMMABLE-BOUNDARY-START(188979080949),
    {
      "r": 181338113,
      "p": [
        {
          "n": "code",
          "p": 1310721
        }
      ],
      "n": "LoadCode",
      "d": 519925,
      "h": 188979080949,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188979080949),
//--TRIMMABLE-BOUNDARY-START(193274048245),
    {
      "r": 181338113,
      "n": "LoadEntry",
      "d": 519925,
      "h": 193274048245,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193274048245),
//--TRIMMABLE-BOUNDARY-START(214748884725),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 519925,
      "h": 214748884725,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(214748884725),
//--TRIMMABLE-BOUNDARY-START(210453917429),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 519925,
      "h": 210453917429,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(210453917429),
//--TRIMMABLE-BOUNDARY-START(42950192885),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 650997
        }
      ],
      "n": "AddItem",
      "d": 519925,
      "h": 42950192885,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950192885),
//--TRIMMABLE-BOUNDARY-START(244813655797),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": 89850
        }
      ],
      "n": "RemoveItem",
      "d": 519925,
      "h": 244813655797,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244813655797),
//--TRIMMABLE-BOUNDARY-START(73014963957),
    {
      "r": 181338113,
      "n": "Create",
      "d": 519925,
      "h": 73014963957,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014963957),
//--TRIMMABLE-BOUNDARY-START(68719996661),
    {
      "r": 181338113,
      "n": "CopyToClipBoard",
      "d": 519925,
      "h": 68719996661,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68719996661),
//--TRIMMABLE-BOUNDARY-START(85899865845),
    {
      "r": 65537,
      "n": "Finish",
      "d": 519925,
      "h": 85899865845,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899865845),
//--TRIMMABLE-BOUNDARY-START(184684113653),
    {
      "r": 181338113,
      "n": "Load",
      "d": 519925,
      "h": 184684113653,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684113653),
//--TRIMMABLE-BOUNDARY-START(51540127477),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 519925,
      "h": 51540127477,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540127477),
//--TRIMMABLE-BOUNDARY-START(171799211765),
    {
      "r": 6881395,
      "p": [
        {
          "n": "more",
          "p": $.$mac.MAC.RenderFragment$$($.$gGJx.LCUCM.UriLinkItem).$h,
          "f": 65
        }
      ],
      "n": "ItemList",
      "d": 519925,
      "h": 171799211765,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171799211765)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(322123067125),
    {
      "t": 59004586,
      "n": "wizard",
      "d": 519925,
      "h": 322123067125,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(322123067125),
//--TRIMMABLE-BOUNDARY-START(176094179061),
    {
      "t": $.$$.SCG.List$$($.$gGJx.LCUCM.UriLinkItem).$h,
      "n": "items",
      "d": 519925,
      "h": 176094179061,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(176094179061),
//--TRIMMABLE-BOUNDARY-START(47245160181),
    {
      "t": 262145,
      "n": "autoRedirect",
      "d": 519925,
      "h": 47245160181,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245160181),
//--TRIMMABLE-BOUNDARY-START(60130062069),
    {
      "t": 1310721,
      "n": "code",
      "d": 519925,
      "h": 60130062069,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130062069),
//--TRIMMABLE-BOUNDARY-START(223338819317),
    {
      "t": 1310721,
      "n": "password",
      "d": 519925,
      "h": 223338819317,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(223338819317),
//--TRIMMABLE-BOUNDARY-START(77309931253),
    {
      "t": 1310721,
      "n": "description",
      "d": 519925,
      "h": 77309931253,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77309931253),
//--TRIMMABLE-BOUNDARY-START(81604898549),
    {
      "t": $.$$.SCG.Dictionary$$$($.$cHnS.LCUCS.IUriResourceTypeProvider, $.$$.S.String).$h,
      "n": "entries",
      "d": 519925,
      "h": 81604898549,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81604898549),
//--TRIMMABLE-BOUNDARY-START(180389146357),
    {
      "t": 21243222,
      "n": "link",
      "d": 519925,
      "h": 180389146357,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(180389146357)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065290997),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 519925,
      "h": 30065290997,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065290997)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(227633786613),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 519925,
        "h": 38655225589,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 519925,
        "h": 240518688501,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 519925,
      "h": 227633786613,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(227633786613)
  ],
  "h": 519925,
  "a": [
    {
      "t": 30640470,
      "c": 25800444246,
      "n": [
        {
          "n": "OpenGraphTitle",
          "v": "Uri Code",
          "t": 1310721
        },
        {
          "n": "OpenGraphImage",
          "v": "/_content/LivingThing.Core.Uri.Client.Blazor/img/bg.jpg",
          "t": 1310721
        },
        {
          "n": "OpenGraphDescription",
          "v": "Your friendly uri and resource code shortener",
          "t": 1310721
        },
        {
          "n": "OpenGraphType",
          "v": 2,
          "t": 30902614
        },
        {
          "n": "OpenGraphPath",
          "v": "https://uri.ng",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/{*Code}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.Pages.UriApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}Pages${separator}UriApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(519925)
        
        

        //--TRIMMABLE-BOUNDARY-START(257781)
        $asm.$cls(`$cHnS.LCUC.App`, ($self) => class App extends $.$hDPm.LCFCA$1.AppRouterBase$$$($self, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(17180126965)
            /*string */ get OptimizedComponentName()
            {
                return "app";
            }
            //--TRIMMABLE-BOUNDARY-END(17180126965)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295225077)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295225077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295225077)
            
            //--TRIMMABLE-BOUNDARY-START(4295225077)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295225077)
            
            static $h = 257781;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCA$1.AppRouterBase$$$($.$cHnS.LCUC.App, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180126965),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885159669,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 257781,
      "h": 17180126965,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180126965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295225077),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 257781,
      "h": 4295225077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295225077)
  ],
  "h": 257781
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCA$1.IAppRouterBase, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$vWqU.LCFCC.IViewStackPresenter$$($.$hDPm.LCFCI.ViewConfiguration), $.$vWqU.LCFCC.IViewStackPresenter, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.App`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}App`; }
        });
        //--TRIMMABLE-BOUNDARY-END(257781)
        
        

        //--TRIMMABLE-BOUNDARY-START(1044213)
        $asm.$cls(`$cHnS.LCUC.UriAppEntry`, ($self) => class UriAppEntry extends $.$sZVd.LCFCA.AppEntryRouter$$$$($self, $.$cHnS.LCUC.IUriAppRootEntryProvider, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(17180913397)
            /*string */ get OptimizedComponentName()
            {
                return "uriappentry appentryrouter";
            }
            //--TRIMMABLE-BOUNDARY-END(17180913397)
            
            //--TRIMMABLE-BOUNDARY-START(4296011509)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296011509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296011509)
            
            //--TRIMMABLE-BOUNDARY-START(4296011509)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296011509)
            
            static $h = 1044213;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.AppEntryRouter$$$$($.$cHnS.LCUC.UriAppEntry, $.$cHnS.LCUC.IUriAppRootEntryProvider, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180913397),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885946101,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1044213,
      "h": 17180913397,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180913397)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296011509),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1044213,
      "h": 4296011509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296011509)
  ],
  "h": 1044213
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCA$1.IAppRouterBase, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$vWqU.LCFCC.IViewStackPresenter$$($.$hDPm.LCFCI.ViewConfiguration), $.$vWqU.LCFCC.IViewStackPresenter, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Client.UriAppEntry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Client${separator}UriAppEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1044213)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Uri.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(61173)
