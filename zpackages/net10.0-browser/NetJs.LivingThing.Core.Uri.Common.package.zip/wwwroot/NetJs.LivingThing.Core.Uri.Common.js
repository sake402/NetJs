
//--TRIMMABLE-BOUNDARY-START(24314)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Uri.Common", 
    {
  "h": 24314,
  "f": "LivingThing.Core.Uri.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Uri.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Uri.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(155386)
        $asm.$cls(`$gGJx.LCUCM.UriModel`, ($self) => class UriModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85899501306)
            /*string[]*/ static Hosts = null;
            //--TRIMMABLE-BOUNDARY-END(85899501306)
            
            //--TRIMMABLE-BOUNDARY-START(34359893754)
            /*bool*/ AutoRedirects = false;
            //--TRIMMABLE-BOUNDARY-END(34359893754)
            
            //--TRIMMABLE-BOUNDARY-START(94489435898)
            /*string?*/ Password = null;
            //--TRIMMABLE-BOUNDARY-END(94489435898)
            
            //--TRIMMABLE-BOUNDARY-START(38654861050)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(38654861050)
            
            //--TRIMMABLE-BOUNDARY-START(90194468602)
            /*IEnumerable<UriLinkItem>?*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(90194468602)
            
            //--TRIMMABLE-BOUNDARY-START(30064926458)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064926458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064926458)
            
            //--TRIMMABLE-BOUNDARY-START(30064926458)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30064926458)
            
            //--TRIMMABLE-BOUNDARY-START(25769959162)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769959162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(85899501306)
                    this.Hosts = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["www.uri.ng", "uri.ng", "uri.localhost"], null, null);
                    //--TRIMMABLE-BOUNDARY-END(85899501306)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769959162)
            
            static $h = 155386;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899501306),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424664826,
        "f": 50331681
      },
      "n": "Hosts",
      "d": 155386,
      "h": 85899501306,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(85899501306),
//--TRIMMABLE-BOUNDARY-START(34359893754),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244795642,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079370490,
        "f": 83886081
      },
      "n": "AutoRedirects",
      "d": 155386,
      "h": 34359893754,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359893754),
//--TRIMMABLE-BOUNDARY-START(94489435898),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604534010,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849174266,
        "f": 83886081
      },
      "n": "Password",
      "d": 155386,
      "h": 94489435898,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489435898),
//--TRIMMABLE-BOUNDARY-START(38654861050),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834730234,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669305082,
        "f": 83886081
      },
      "n": "Description",
      "d": 155386,
      "h": 38654861050,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654861050),
//--TRIMMABLE-BOUNDARY-START(90194468602),
    {
      "p": $.$$.SCG.IEnumerable$$($.$gGJx.LCUCM.UriLinkItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014599418,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259239674,
        "f": 83886081
      },
      "n": "Items",
      "d": 155386,
      "h": 90194468602,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194468602)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064926458),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 155386,
      "h": 30064926458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064926458)
  ],
  "h": 155386
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Common.Models.UriModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Common${separator}Models${separator}UriModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(155386)
        
        

        //--TRIMMABLE-BOUNDARY-START(89850)
        $asm.$str(`$gGJx.LCUCM.UriLinkItem`, ($self) => class UriLinkItem extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(60129631994)
            /*string?*/ ProviderName = null;
            //--TRIMMABLE-BOUNDARY-END(60129631994)
            
            //--TRIMMABLE-BOUNDARY-START(94489370362)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(94489370362)
            
            //--TRIMMABLE-BOUNDARY-START(90194403066)
            /*string?*/ Text = null;
            //--TRIMMABLE-BOUNDARY-END(90194403066)
            
            //--TRIMMABLE-BOUNDARY-START(25769893626)
            /*bool */ Equals$2(/*UriLinkItem*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769893626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProviderName === other.ProviderName && this.Text === other.Text;
            }
            //--TRIMMABLE-BOUNDARY-END(25769893626)
            
            //--TRIMMABLE-BOUNDARY-START(21474926330)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474926330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                if ($.$is(obj, $.$gGJx.LCUCM.UriLinkItem, { set $v($v){ other = $v; } }))
                {
                    return this.ProviderName === other.ProviderName && this.Text === other.Text;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(21474926330)
            
            //--TRIMMABLE-BOUNDARY-START(55834664698)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834664698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.HashCode.Combine$6($.$$.S.String, $.$$.S.String, this.ProviderName, this.Text);
            }
            //--TRIMMABLE-BOUNDARY-END(55834664698)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Uri.Common.Models.UriLinkItem>.Equals(LivingThing.Core.Uri.Common.Models.UriLinkItem)
            S$IEquatable$LivingThing$Core$Uri$Common$Models$UriLinkItem$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(17179959034)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179959034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179959034)
            
            //--TRIMMABLE-BOUNDARY-START(17179959034)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17179959034)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ProviderName = this.ProviderName;
                copy.Title = this.Title;
                copy.Text = this.Text;
                return copy;
            }
            static $h = 89850;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129631994),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359828218,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719566586,
        "f": 83886081
      },
      "n": "ProviderName",
      "d": 89850,
      "h": 60129631994,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129631994),
//--TRIMMABLE-BOUNDARY-START(94489370362),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539697402,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899435770,
        "f": 83886081
      },
      "n": "Title",
      "d": 89850,
      "h": 94489370362,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489370362),
//--TRIMMABLE-BOUNDARY-START(90194403066),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949762810,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309501178,
        "f": 83886081
      },
      "n": "Text",
      "d": 89850,
      "h": 90194403066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194403066)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769893626),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 89850
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 89850,
      "h": 25769893626,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769893626),
//--TRIMMABLE-BOUNDARY-START(21474926330),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 89850,
      "h": 21474926330,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21474926330),
//--TRIMMABLE-BOUNDARY-START(55834664698),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 89850,
      "h": 55834664698,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834664698)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17179959034),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 89850,
      "h": 17179959034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179959034)
  ],
  "h": 89850
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$gGJx.LCUCM.UriLinkItem) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Uri.Common.Models.UriLinkItem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Uri${separator}Common${separator}Models${separator}UriLinkItem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(89850)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"));
})();
//--TRIMMABLE-BOUNDARY-END(24314)
