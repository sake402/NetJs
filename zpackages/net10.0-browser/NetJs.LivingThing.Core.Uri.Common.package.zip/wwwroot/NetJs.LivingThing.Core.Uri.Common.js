
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $srsp, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Uri.Common", 
    {"h":65284,"f":"LivingThing.Core.Uri.Common","v":"1.0.35.0","a":[{"t":158728193,"c":13043630081,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":105906177,"c":4400873473,"a":[{"v":"SIT","t":1310721}]},{"t":105971713,"c":4400939009,"a":[{"v":"Debug","t":1310721}]},{"t":106430465,"c":4401397761,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":106561537,"c":4401528833,"a":[{"v":"1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361","t":1310721}]},{"t":107413505,"c":4402380801,"a":[{"v":"LivingThing.Core.Uri.Common","t":1310721}]},{"t":107544577,"c":4402511873,"a":[{"v":"LivingThing.Core.Uri.Common","t":1310721}]},{"t":107675649,"c":4402642945,"a":[{"v":"1.0.35.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196356)
        $asm.$cls("$lcuc.LivingThing.Core.Uri.Common.Models.UriModel", ($self) => class UriModel extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85899542276)
            /*string[]*/ static Hosts = null;
            //--TRIMMABLE-BOUNDARY-END(85899542276)
            
            //--TRIMMABLE-BOUNDARY-START(34359934724)
            /*bool*/ AutoRedirects = false;
            //--TRIMMABLE-BOUNDARY-END(34359934724)
            
            //--TRIMMABLE-BOUNDARY-START(94489476868)
            /*string?*/ Password = null;
            //--TRIMMABLE-BOUNDARY-END(94489476868)
            
            //--TRIMMABLE-BOUNDARY-START(38654902020)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(38654902020)
            
            //--TRIMMABLE-BOUNDARY-START(90194509572)
            /*IEnumerable<UriLinkItem>?*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(90194509572)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AutoRedirects = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Hosts = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), ["www.uri.ng", "uri.ng", "uri.localhost"], null, null);
                }
            }
            static $h = 196356;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":64424705796,"f":50331681},"n":"Hosts","d":196356,"h":85899542276,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":47244836612,"f":50331649},"s":{"r":0,"d":0,"h":103079411460,"f":83886081},"n":"AutoRedirects","d":196356,"h":34359934724,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":81604574980,"f":50331649},"s":{"r":0,"d":0,"h":128849215236,"f":83886081},"n":"Password","d":196356,"h":94489476868,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55834771204,"f":50331649},"s":{"r":0,"d":0,"h":111669346052,"f":83886081},"n":"Description","d":196356,"h":38654902020,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$lcuc.LivingThing.Core.Uri.Common.Models.UriLinkItem).$h,"g":{"r":0,"d":0,"h":73014640388,"f":50331649},"s":{"r":0,"d":0,"h":120259280644,"f":83886081},"n":"Items","d":196356,"h":90194509572,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":196356,"h":8590130948,"f":16777217}],"h":196356}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LivingThing.Core.Uri.Common.Models.UriModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196356)
        
        
        //--TRIMMABLE-BOUNDARY-START(130820)
        $asm.$str("$lcuc.LivingThing.Core.Uri.Common.Models.UriLinkItem", ($self) => class UriLinkItem extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(60129672964)
            /*string?*/ ProviderName = null;
            //--TRIMMABLE-BOUNDARY-END(60129672964)
            
            //--TRIMMABLE-BOUNDARY-START(94489411332)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(94489411332)
            
            //--TRIMMABLE-BOUNDARY-START(90194444036)
            /*string?*/ Text = null;
            //--TRIMMABLE-BOUNDARY-END(90194444036)
            
            //--TRIMMABLE-BOUNDARY-START(21474967300)
            /*bool */ Equals$2(/*UriLinkItem*/ other)
            {
                $.$trace(21474967300);
                {
                    return $.$$.System.String.op_Equality(this.ProviderName, other.ProviderName) && $.$$.System.String.op_Equality(this.Text, other.Text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474967300)
            
            //--TRIMMABLE-BOUNDARY-START(25769934596)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                $.$trace(25769934596);
                {
                    let other;
                    if ($.$is(obj, $.$lcuc.LivingThing.Core.Uri.Common.Models.UriLinkItem, { set $v(v){ other = v; } }))
                    {
                        return $.$$.System.String.op_Equality(this.ProviderName, other.ProviderName) && $.$$.System.String.op_Equality(this.Text, other.Text);
                    }
                    return $.$$.System.ValueType.Equals$1.call(this, obj);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$lcuc.LivingThing.Core.Uri.Common.Models.UriLinkItem.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25769934596)
            
            //--TRIMMABLE-BOUNDARY-START(55834705668)
            static/*conventional*/ /*int */ GetHashCode()
            {
                $.$trace(55834705668);
                {
                    return $.$$.System.HashCode.Combine$6($.$$.System.String, $.$$.System.String, this.ProviderName, this.Text);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$lcuc.LivingThing.Core.Uri.Common.Models.UriLinkItem.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(55834705668)
            
            //--TRIMMABLE-BOUNDARY-START(4384817153)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Uri.Common.Models.UriLinkItem>.Equals(LivingThing.Core.Uri.Common.Models.UriLinkItem)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384817153)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ProviderName = this.ProviderName;
                copy.Title = this.Title;
                copy.Text = this.Text;
                return copy;
            }
            static $h = 130820;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":34359869188,"f":50331649},"s":{"r":0,"d":0,"h":68719607556,"f":83886081},"n":"ProviderName","d":130820,"h":60129672964,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51539738372,"f":50331649},"s":{"r":0,"d":0,"h":85899476740,"f":83886081},"n":"Title","d":130820,"h":94489411332,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42949803780,"f":50331649},"s":{"r":0,"d":0,"h":77309542148,"f":83886081},"n":"Text","d":130820,"h":90194444036,"f":2097153}],"m":[{"r":262145,"p":[{"n":"other","p":130820}],"n":"Equals","o":"@$2","d":130820,"h":21474967300,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":130820,"h":25769934596,"f":16809985},{"r":655361,"n":"GetHashCode","d":130820,"h":55834705668,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$2","d":130820,"h":4295098116,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$lcuc.LivingThing.Core.Uri.Common.Models.UriLinkItem).$h],"h":130820}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$lcuc.LivingThing.Core.Uri.Common.Models.UriLinkItem) ]; }
            static get $fullName() { return `LivingThing.Core.Uri.Common.Models.UriLinkItem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(130820)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))