
//--TRIMMABLE-BOUNDARY-START(50951)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $wtdm, $lJUR, $OJJQ) {
    "use strict";
    let _;
    let $qcVJDh;
    let $lsVaAg;
    let $dHNwib;
    let $GAinKf;
    let $fAotqj;
    let $aYYnQf;
    let $mtAJah;
    let $WhFvua;
    let $PWCXLf;
    let $rlSzya;
    let $fBcsIk;
    let $KsQkZe;
    let $nWwJxj;
    let $wQZklc;
    let $kglLHd;
    let $OCFNda;
    let $ERIyrj;
    let $VRhqNj;
    let $JEoAch;
    let $NZEcbi;
    let $dtfgna;
    let $IzhkIk;
    let $TMTrnk;
    let $RyGNvj;
    let $IVzqrg;
    let $pzUxdl;
    let $JoGcJa;
    let $DTYhAb;
    let $eYYomf;
    let $UITRti;
    let $lCfBNk;
    let $pSiFOj;
    let $ynsaLe;
    let $WHmYti;
    let $qIeVgc;
    let $GyoxBg;
    let $ppXkxd;
    let $ICZJCc;
    let $dklMbh;
    let $qqTpRb;
    let $XXQgIk;
    let $JfnVnf;
    let $FXHmrf;
    let $XjVJTi;
    let $uIThdc;
    let $TMOFqi;
    let $tMABrc;
    let $EEbypk;
    let $LeYYVa;
    let $lRsMui;
    let $szyIha;
    let $psNFig;
    let $WmPgMj;
    let $fiytRj;
    let $aBxxBg;
    let $BlkCFb;
    let $rrsBja;
    let $UaVsei;
    let $TyUZEh;
    let $yLtSfg;
    let $ZOkZfb;
    let $lgcoac;
    let $KJkjpl;
    let $eeQspi;
    let $aBzcfh;
    let $hhYBDd;
    let $WGDESc;
    let $RMsiNb;
    let $nOTbUb;
    let $rfhIHi;
    let $vvuanf;
    let $LZWqWi;
    let $sEekOb;
    let $tqJUtb;
    let $LQTTYj;
    let $gQbpXb;
    let $tiGxcj;
    let $fickha;
    let $xQdGSj;
    let $xEybwj;
    let $LquQzi;
    let $YTxdye;
    let $hWDJgd;
    let $hbbXOj;
    let $EzVcSj;
    let $BcVtad;
    let $dpVWId;
    let $slCbdg;
    let $NreBnd;
    let $nWDfJd;
    let $mCxvUe;
    let $iMzUXc;
    let $usEAcb;
    let $gPftWc;
    let $VKQyGd;
    let $HxQvrc;
    let $CYKNNf;
    let $YPmzTj;
    let $TFCioc;
    let $EgxwJd;
    let $HDqOVf;
    let $YeAqae;
    let $wZOEdb;
    let $rLRRwj;
    let $AvVOBa;
    let $OkxZpf;
    let $tumydf;
    let $TETRYd;
    let $iyPdFi;
    let $bAhTqb;
    let $PWrDsb;
    let $isqLpb;
    let $YQdgsj;
    let $XYGekg;
    let $PzCTtk;
    let $IvcpEd;
    let $DYWsji;
    let $BHAHPd;
    let $iKSCmb;
    let $sFwRll;
    let $OhfPSk;
    let $NwKgNa;
    let $kZcJHb;
    let $sYhwEj;
    let $AcmKjk;
    let $RjxMze;
    let $ivqFig;
    let $ZJjZik;
    let $SThpaf;
    let $wbCpFg;
    let $gJhINd;
    let $akuypg;
    let $tXAyxe;
    let $XeltBi;
    let $RZSIkf;
    let $MTAmke;
    let $VNbWka;
    let $PwWOXa;
    let $mqLSii;
    let $KFqMtf;
    let $pHukBb;
    let $wDqAWc;
    let $vUqtvk;
    let $DVvBHe;
    let $aIoBWg;
    let $RZMSnd;
    let $KrIvab;
    let $xzjFka;
    let $ZOIvPf;
    let $nIXtsj;
    let $zXDtak;
    let $NvgWlf;
    let $UYcQke;
    let $tbXHgb;
    let $TOCxSk;
    let $iZQUrg;
    let $chOAOb;
    let $pMFRJi;
    let $VAvvXd;
    let $WiCHTa;
    let $gJeDWd;
    let $FiqAnd;
    let $pHkfZa;
    let $pdpbQh;
    let $aNYoyb;
    let $sMeBAd;
    let $lvFkJf;
    let $ymLWil;
    let $IKZOFi;
    let $iMCsol;
    let $LaTaqk;
    let $VAgUJa;
    let $kJVCUb;
    let $QDaWRi;
    let $vvxcPd;
    let $OrAcxk;
    let $xXiVuk;
    let $AWfrre;
    let $uayJzb;
    let $Fybvkf;
    let $OhUxWk;
    let $rfoYIi;
    let $AdQrFb;
    let $oDRHCj;
    let $cqsObj;
    let $OrsBWf;
    let $EYMQHd;
    let $WDxvNi;
    let $ImTzli;
    let $UbXDYc;
    let $oYqGca;
    let $nGZONe;
    let $hNdLof;
    let $gUGgZb;
    let $HDctMe;
    let $HFfZdh;
    let $oRXlNh;
    let $FFaQDk;
    let $ULjbha;
    let $aobOLg;
    let $IEKzYh;
    let $aRrgSh;
    let $ilDuEi;
    let $Savhye;
    let $qvhmLg;
    let $HkIvBb;
    let $xxJSTb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Wallet.Client.Blazor", 
    {
  "h": 50951,
  "f": "LivingThing.Core.Wallet.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Wallet.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Wallet.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(968455)
        $asm.$cls(`$SeJP.LCWCS.IWalletSendProvider`, ($self) => class IWalletSendProvider
        {
            //--TRIMMABLE-BOUNDARY-START(8590903047)
            /*Dictionary<string, double>? */ LCWCS$IWalletSendProvider$GetTransactionFee(/*double*/ amount)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590903047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590903047)
            
            static $h = 968455;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295935751),
    {
      "r": $.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "GetPeer",
      "o": "LCWCS$IWalletSendProvider$GetPeer",
      "d": 968455,
      "h": 4295935751,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295935751),
//--TRIMMABLE-BOUNDARY-START(8590903047),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double).$h,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "GetTransactionFee",
      "o": "LCWCS$IWalletSendProvider$GetTransactionFee",
      "d": 968455,
      "h": 8590903047,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590903047),
//--TRIMMABLE-BOUNDARY-START(12885870343),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "sender",
          "p": 570573
        },
        {
          "n": "recipient",
          "p": 570573
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        },
        {
          "n": "progressIndicator",
          "p": 898253
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "Pay",
      "o": "LCWCS$IWalletSendProvider$Pay",
      "d": 968455,
      "h": 12885870343,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885870343)
  ],
  "h": 968455
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.IWalletSendProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}IWalletSendProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(968455)
        
        

        //--TRIMMABLE-BOUNDARY-START(902919)
        $asm.$cls(`$SeJP.LCWCS.IWalletReceiveProvider`, ($self) => class IWalletReceiveProvider
        {
            static $h = 902919;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180772103),
    {
      "p": 1033991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590837511,
        "f": 50331905
      },
      "n": "SelfAddress",
      "o": "LCWCS$IWalletReceiveProvider$SelfAddress",
      "d": 902919,
      "h": 17180772103,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180772103)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885804807),
    {
      "r": $.$$.STT.Task$$($.$$.S.IDisposable).$h,
      "p": [
        {
          "n": "self",
          "p": 570573
        },
        {
          "n": "receiverHandler",
          "p": 832717
        }
      ],
      "n": "Receive",
      "o": "LCWCS$IWalletReceiveProvider$Receive",
      "d": 902919,
      "h": 12885804807,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885804807)
  ],
  "h": 902919
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.IWalletReceiveProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}IWalletReceiveProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(902919)
        
        

        //--TRIMMABLE-BOUNDARY-START(1165063)
        $asm.$cls(`$SeJP.LCWCS.WalletFundFormModel`, ($self) => class WalletFundFormModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655870727)
            /*IWalletIssuer*/ issuer = null;
            //--TRIMMABLE-BOUNDARY-END(38655870727)
            
            //--TRIMMABLE-BOUNDARY-START(51540772615)
            /*WalletTokenDescriptor*/ token;
            //--TRIMMABLE-BOUNDARY-END(51540772615)
            
            //--TRIMMABLE-BOUNDARY-START(8591099655)
            $ctor$1(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591099655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.issuer = issuer;
                    this.token = $.$clone(token);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591099655)
            
            //--TRIMMABLE-BOUNDARY-START(12886066951)
            /*int*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(12886066951)
            
            //--TRIMMABLE-BOUNDARY-START(17181034247)
            /*WalletToken */ get Coins()
            {
                return this.issuer.LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$Convert(new $.$fPer.LCFCDM.Money().$ctor$3(this.Amount, 1/*MoneyUnitTypes.Naira*/), null);
            }
            //--TRIMMABLE-BOUNDARY-END(17181034247)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540772615)
                this.token = $.$default($.$OJJQ.LCFCW.WalletTokenDescriptor);
                //--TRIMMABLE-BOUNDARY-END(51540772615)
                
            }
            static $h = 1165063;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886066951),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770968839,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245805319,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1165063,
      "h": 12886066951,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "You pay ",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Unit=\u20A6"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886066951),
//--TRIMMABLE-BOUNDARY-START(17181034247),
    {
      "p": 3192013,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360903431,
        "f": 50331649
      },
      "n": "Coins",
      "d": 1165063,
      "h": 17181034247,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "You get ",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//DependsOn=Amount",
                "//Unit=\u20A6"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181034247)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655870727),
    {
      "t": 636109,
      "n": "issuer",
      "d": 1165063,
      "h": 38655870727,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655870727),
//--TRIMMABLE-BOUNDARY-START(51540772615),
    {
      "t": 3257549,
      "n": "token",
      "d": 1165063,
      "h": 51540772615,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540772615)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591099655),
    {
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1165063,
      "h": 8591099655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591099655)
  ],
  "h": 1165063
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletFundFormModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletFundFormModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1165063)
        
        

        //--TRIMMABLE-BOUNDARY-START(2803463)
        $asm.$cls(`$SeJP.LCWCS$1.WalletSwapRequest`, ($self) => class WalletSwapRequest extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(124556855047)
            /*IWalletSystem*/ Source = null;
            //--TRIMMABLE-BOUNDARY-END(124556855047)
            
            //--TRIMMABLE-BOUNDARY-START(30067574535)
            /*IWalletSystem*/ Destination = null;
            //--TRIMMABLE-BOUNDARY-END(30067574535)
            
            //--TRIMMABLE-BOUNDARY-START(128851822343)
            /*double*/ SourceAmount = 0;
            //--TRIMMABLE-BOUNDARY-END(128851822343)
            
            //--TRIMMABLE-BOUNDARY-START(133146789639)
            /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>?*/ SourceDenomination = null;
            //--TRIMMABLE-BOUNDARY-END(133146789639)
            
            //--TRIMMABLE-BOUNDARY-START(34362541831)
            /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>?*/ DestinationDenomination = null;
            //--TRIMMABLE-BOUNDARY-END(34362541831)
            
            //--TRIMMABLE-BOUNDARY-START(25772607239)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772607239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772607239)
            
            //--TRIMMABLE-BOUNDARY-START(25772607239)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25772607239)
            
            static $h = 2803463;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124556855047),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132345607,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103082018567,
        "f": 83886081
      },
      "n": "Source",
      "d": 2803463,
      "h": 124556855047,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124556855047),
//--TRIMMABLE-BOUNDARY-START(30067574535),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952476423,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902149383,
        "f": 83886081
      },
      "n": "Destination",
      "d": 2803463,
      "h": 30067574535,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067574535),
//--TRIMMABLE-BOUNDARY-START(128851822343),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722280199,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671953159,
        "f": 83886081
      },
      "n": "SourceAmount",
      "d": 2803463,
      "h": 128851822343,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128851822343),
//--TRIMMABLE-BOUNDARY-START(133146789639),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312214791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261887751,
        "f": 83886081
      },
      "n": "SourceDenomination",
      "d": 2803463,
      "h": 133146789639,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146789639),
//--TRIMMABLE-BOUNDARY-START(34362541831),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542411015,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94492083975,
        "f": 83886081
      },
      "n": "DestinationDenomination",
      "d": 2803463,
      "h": 34362541831,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362541831)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772607239),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2803463,
      "h": 25772607239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772607239)
  ],
  "h": 2803463
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletSwapRequest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletSwapRequest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2803463)
        
        

        //--TRIMMABLE-BOUNDARY-START(575239)
        $asm.$cls(`$SeJP.LCWC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295542535)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295542535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295542535)
            
            static $h = 575239;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295542535),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 575239,
      "h": 4295542535,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295542535)
  ],
  "h": 575239
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(575239)
        
        

        //--TRIMMABLE-BOUNDARY-START(2737927)
        $asm.$cls(`$SeJP.LCWCS$1.WalletSwapFeaturesCustomAttributesProvider`, ($self) => class WalletSwapFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297705223)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297705223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297705223)
            
            static $h = 2737927;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297705223),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2737927,
      "h": 4297705223,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297705223)
  ],
  "h": 2737927
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletSwapFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletSwapFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2737927)
        
        

        //--TRIMMABLE-BOUNDARY-START(444167)
        $asm.$cls(`$SeJP.LCWC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295411463)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295411463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$SeJP.LCWC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295411463)
            
            static $h = 444167;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295411463),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 444167,
      "h": 4295411463,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295411463)
  ],
  "h": 444167
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(444167)
        
        

        //--TRIMMABLE-BOUNDARY-START(1230599)
        $asm.$cls(`$SeJP.LCWCS.WalletFundFormModelCustomAttributesProvider`, ($self) => class WalletFundFormModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296197895)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296197895)
            
            //--TRIMMABLE-BOUNDARY-START(8591165191)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591165191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$SeJP.LCWCS.WalletFundFormModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Title = "You pay ";
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=\u20A6"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Coins", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Title = "You get ";
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//DependsOn=Amount", "//Unit=\u20A6"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$SeJP.LCWCS.WalletFundFormModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $rlSzya ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1230599,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $fBcsIk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1230599,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591165191)
            
            static $h = 1230599;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591165191),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1230599,
      "h": 8591165191,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591165191)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296197895),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1230599,
      "h": 4296197895,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296197895)
  ],
  "h": 1230599
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletFundFormModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletFundFormModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1230599)
        
        

        //--TRIMMABLE-BOUNDARY-START(3065607)
        $asm.$cls(`$SeJP.LCWC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298032903)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298032903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$SeJP.LCWCS.WalletFundFormModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298032903)
            
            static $h = 3065607;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298032903),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3065607,
      "h": 4298032903,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298032903)
  ],
  "h": 3065607
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3065607)
        
        

        //--TRIMMABLE-BOUNDARY-START(2279175)
        $asm.$cls(`$SeJP.LCWCS$1.WalletHomeFeaturesCustomAttributesProvider`, ($self) => class WalletHomeFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297246471)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297246471)
            
            //--TRIMMABLE-BOUNDARY-START(8592213767)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592213767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$SeJP.LCWCS$1.WalletHomeFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$SeJP.LCWCS$1.WalletHomeFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KJkjpl ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2279175,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $eeQspi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2279175,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592213767)
            
            static $h = 2279175;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592213767),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2279175,
      "h": 8592213767,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592213767)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297246471),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2279175,
      "h": 4297246471,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297246471)
  ],
  "h": 2279175
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletHomeFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletHomeFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2279175)
        
        

        //--TRIMMABLE-BOUNDARY-START(1361671)
        $asm.$cls(`$SeJP.LCWCS.WalletFundFormModelTypeDescriptorBuilder`, ($self) => class WalletFundFormModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591296263)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591296263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$SeJP.LCWCS.WalletFundFormModelTypeDescriptor()
                        const $t1 = $.$SeJP.LCWCS.WalletFundFormModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Wallet.Client.Services.WalletFundFormModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hbbXOj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1361671,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$SeJP.LCWCS.WalletFundFormModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591296263)
            
            //--TRIMMABLE-BOUNDARY-START(4296328967)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296328967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296328967)
            
            //--TRIMMABLE-BOUNDARY-START(4296328967)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296328967)
            
            static $h = 1361671;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591296263),
    {
      "r": 65537,
      "n": "Register",
      "d": 1361671,
      "h": 8591296263,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591296263)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296328967),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1361671,
      "h": 4296328967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296328967)
  ],
  "h": 1361671
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletFundFormModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletFundFormModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1361671)
        
        

        //--TRIMMABLE-BOUNDARY-START(247559)
        $asm.$cls(`$SeJP._LCWCSW$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(8590182151)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*T*/ __arg1, /*int*/ __seq2, /*object*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590182151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Target", $.$box(__arg1, T));
                __builder.SetKey(__arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590182151)
            
            //--TRIMMABLE-BOUNDARY-START(12885149447)
            static /*void */ CreatePropertySheet_1(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*T*/ __arg1, /*int*/ __seq2, /*object*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885149447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Target", $.$box(__arg1, T));
                __builder.SetKey(__arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885149447)
            
            //--TRIMMABLE-BOUNDARY-START(17180116743)
            static /*void */ CreatePropertySheet_2(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::System.Object*/ __arg1, /*int*/ __seq2, /*global::System.Int32*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180116743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "value-class", __arg1);
                __builder.AddComponentParameter(__seq2, "PadContent", $.$box(__arg2, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq3, "Features", $.$box(__arg3, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180116743)
            
            //--TRIMMABLE-BOUNDARY-START(4295214855)
            static /*void */ CreateInputEditor_3(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295214855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295214855)
            
            //--TRIMMABLE-BOUNDARY-START(21475084039)
            static /*void */ CreatePropertySheet_4(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::System.Int32*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475084039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "PadContent", $.$box(__arg1, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475084039)
            
            static $h = 247559;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590182151),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => T.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 247559,
      "h": 8590182151,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590182151),
//--TRIMMABLE-BOUNDARY-START(12885149447),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => T.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_1",
      "d": 247559,
      "h": 12885149447,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885149447),
//--TRIMMABLE-BOUNDARY-START(17180116743),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 131073
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 655361
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 14505642
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_2",
      "d": 247559,
      "h": 17180116743,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180116743),
//--TRIMMABLE-BOUNDARY-START(4295214855),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_3",
      "d": 247559,
      "h": 4295214855,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295214855),
//--TRIMMABLE-BOUNDARY-START(21475084039),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 655361
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_4",
      "d": 247559,
      "h": 21475084039,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475084039)
  ],
  "h": 247559
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Wallet.Client.Shared.WalletSend.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletSend${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(247559)
        
        

        //--TRIMMABLE-BOUNDARY-START(116487)
        $asm.$cls(`$SeJP._LCWCSB.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(8590051079)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590051079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590051079)
            
            //--TRIMMABLE-BOUNDARY-START(4295083783)
            static /*void */ CreateDataList_1(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Client.IViewController*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295083783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Controller", __arg1);
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq3, "ChildContent", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295083783)
            
            static $h = 116487;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590051079),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 116487,
      "h": 8590051079,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590051079),
//--TRIMMABLE-BOUNDARY-START(4295083783),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 5856680
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_1",
      "d": 116487,
      "h": 4295083783,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295083783)
  ],
  "h": 116487
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Wallet.Client.Shared.BankGetBeneficiary.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}BankGetBeneficiary${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(116487)
        
        

        //--TRIMMABLE-BOUNDARY-START(182023)
        $asm.$cls(`$SeJP._LCWCSW.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295149319)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::System.Object*/ __arg1, /*int*/ __seq2, /*global::System.Int32*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295149319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "value-class", __arg1);
                __builder.AddComponentParameter(__seq2, "PadContent", $.$box(__arg2, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq3, "Features", $.$box(__arg3, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295149319)
            
            static $h = 182023;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295149319),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 131073
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 655361
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 14505642
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 182023,
      "h": 4295149319,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295149319)
  ],
  "h": 182023
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Wallet.Client.Shared.WalletReceive.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletReceive${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(182023)
        
        

        //--TRIMMABLE-BOUNDARY-START(509703)
        $asm.$cls(`$SeJP.LCWC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295476999)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295476999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$SeJP.LCWCS.WalletFundFormModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$SeJP.LCWCS.WalletFundFormModelCustomAttributesProvider, $.$SeJP.LCWCS.WalletFundFormModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$SeJP.LCWCS$1.WalletHomeFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$SeJP.LCWCS$1.WalletHomeFeaturesCustomAttributesProvider, $.$SeJP.LCWCS$1.WalletHomeFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$SeJP.LCWCS$1.WalletSwapFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$SeJP.LCWCS$1.WalletSwapFeaturesCustomAttributesProvider, $.$SeJP.LCWCS$1.WalletSwapFeaturesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295476999)
            
            static $h = 509703;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295476999),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 509703,
      "h": 4295476999,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295476999)
  ],
  "h": 509703
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(509703)
        
        

        //--TRIMMABLE-BOUNDARY-START(837383)
        $asm.$cls(`$SeJP.LCWC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590771975)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590771975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$SeJP.LCWC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IUIPaymentProcessor, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$SeJP.LCWCS.WalletPaymentProcessor, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IUIPaymentProcessor))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletPaymentProcessor, x);
                }, $RyGNvj ??= {"r":65623722,"p":[{"n":"x","p":327718}],"n":"","d":837383,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$SeJP.LCWCS.WalletService, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$SeJP.LCWCS.WalletApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletApplication, x);
                }, $IVzqrg ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":837383,"h":0,"f":17825794}));
                $.$SeJP.LCWC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590771975)
            
            //--TRIMMABLE-BOUNDARY-START(12885739271)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885739271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_WalletPaymentProcessor(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$SeJP.LCWCS.WalletPaymentProcessor().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$SeJP.LCWCS.WalletPaymentProcessor.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$SeJP.LCWC.ServiceRegistrar, Get_WalletPaymentProcessor, $pzUxdl ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WalletPaymentProcessor","d":837383,"h":0,"f":16777250})));
                /*static object*/  function Get_IUIPaymentProcessor(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletPaymentProcessor, x);
                    }), $JoGcJa ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":837383,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCI.IUIPaymentProcessor.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$SeJP.LCWC.ServiceRegistrar, Get_IUIPaymentProcessor, $DTYhAb ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IUIPaymentProcessor","d":837383,"h":0,"f":16777250})));
                /*static object*/  function Get_WalletService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$SeJP.LCWCS.WalletService().$ctor$5(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer), provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$SeJP.LCWCS.WalletService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$SeJP.LCWC.ServiceRegistrar, Get_WalletService, $eYYomf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WalletService","d":837383,"h":0,"f":16777250})));
                /*static object*/  function Get_WalletApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$SeJP.LCWCS.WalletApplication().$ctor$3(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$SeJP.LCWCS.WalletService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$SeJP.LCWCS.WalletApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$SeJP.LCWC.ServiceRegistrar, Get_WalletApplication, $UITRti ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WalletApplication","d":837383,"h":0,"f":16777250})));
                /*static object*/  function Get_IClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletApplication, x);
                    }), $lCfBNk ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":837383,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$sZVd.LCFCA.IClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$SeJP.LCWC.ServiceRegistrar, Get_IClientApplication, $pSiFOj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IClientApplication","d":837383,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885739271)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$SeJP.LCWC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295804679)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295804679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295804679)
            
            //--TRIMMABLE-BOUNDARY-START(4295804679)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295804679)
            
            static $h = 837383;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590771975),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 837383,
      "h": 8590771975,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590771975),
//--TRIMMABLE-BOUNDARY-START(12885739271),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 837383,
      "h": 12885739271,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885739271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295804679),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 837383,
      "h": 4295804679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295804679)
  ],
  "h": 837383
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(837383)
        
        

        //--TRIMMABLE-BOUNDARY-START(313095)
        $asm.$cls(`$SeJP.LCFCS.WithdrawToBankWalletSendProvider`, ($self) => class WithdrawToBankWalletSendProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590247687)
            /*IWalletIssuer*/ _wallet = null;
            //--TRIMMABLE-BOUNDARY-END(8590247687)
            
            //--TRIMMABLE-BOUNDARY-START(4295280391)
            /*IClientUnitOfWork*/ _unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(4295280391)
            
            //--TRIMMABLE-BOUNDARY-START(12885214983)
            $ctor$1(/*IWalletIssuer*/ wallet, /*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885214983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._wallet = wallet;
                    this._unitOfWork = unitOfWork;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885214983)
            
            //--TRIMMABLE-BOUNDARY-START(21475149575)
            /*Dictionary<string, double>? */ GetTransactionFee(/*double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475149575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (amount === 0)
                {
                    return null;
                }
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Transaction Fee", $.$OJJQ.LCFCW.WalletServiceExtension.GetTransactionFee(amount));
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(21475149575)
            
            //--TRIMMABLE-BOUNDARY-START(17180182279)
            /*Task<IWalletHolder> *//*async*/  GetPeer(/*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder), $.$OJJQ.LCFCW.IWalletHolder, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180182279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.ViewForResult($.$hDPm.LCFCI.ViewConfiguration, $.$OJJQ.LCFCW.IWalletHolder, $.$SeJP.LCWCS$1.BankGetBeneficiary, this._unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, null, token, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180182279)
            
            //--TRIMMABLE-BOUNDARY-START(25770116871)
            /*ValueTask<object> *//*async*/  Pay(/*IWalletHolder*/ sender, /*IWalletHolder*/ recipient, /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ denominations, /*string*/ pinCode, /*string?*/ transactionDescription, /*IWalletPaymentSendProgressReportIndicator*/ progressIndicator, /*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770116871);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let stub = $.$cast(recipient, $.$SeJP.LCWCS$1.BankGetBeneficiary.WalletHolder);
                    /*var*/ let amount = $.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), denominations, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.Value;
                    }, $KsQkZe ??= {"r":1179649,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":313095,"h":0,"f":17825794}));
                    /*var*/ let result = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.BankTransferResult, this._unitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)))().$ctor(this,  (/**/ server) =>
                    {
                        return server.LCFCW$IWalletRemoteService$BankTransfer($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(this._wallet, $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.WalletTokenDescriptor, this._wallet.LCFCW$IWalletIssuer$CoinDescriptors)), amount, stub.Account, pinCode, transactionDescription);
                    }, $nWwJxj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)).$h,"p":[{"n":"server","p":1029325}],"n":"","d":313095,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770116871)
            
            //--TRIMMABLE-BOUNDARY-START(4295935751)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.GetPeer(System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$GetPeer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295935751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPeer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295935751)
            
            //--TRIMMABLE-BOUNDARY-START(8590903047)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.GetTransactionFee(double)
            LCWCS$IWalletSendProvider$GetTransactionFee()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590903047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetTransactionFee(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590903047)
            
            //--TRIMMABLE-BOUNDARY-START(12885870343)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.Pay(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, System.Collections.Generic.Dictionary<(LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer, LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor), double>, string, string?, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator, System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$Pay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885870343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pay(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885870343)
            
            static $h = 313095;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475149575),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double).$h,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "GetTransactionFee",
      "d": 313095,
      "h": 21475149575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475149575),
//--TRIMMABLE-BOUNDARY-START(17180182279),
    {
      "r": $.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "GetPeer",
      "d": 313095,
      "h": 17180182279,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17180182279),
//--TRIMMABLE-BOUNDARY-START(25770116871),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "sender",
          "p": 570573
        },
        {
          "n": "recipient",
          "p": 570573
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        },
        {
          "n": "progressIndicator",
          "p": 898253
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "Pay",
      "d": 313095,
      "h": 25770116871,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25770116871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590247687),
    {
      "t": 636109,
      "n": "_wallet",
      "d": 313095,
      "h": 8590247687,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590247687),
//--TRIMMABLE-BOUNDARY-START(4295280391),
    {
      "t": 63657642,
      "n": "_unitOfWork",
      "d": 313095,
      "h": 4295280391,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295280391)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885214983),
    {
      "p": [
        {
          "n": "wallet",
          "p": 636109
        },
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 313095,
      "h": 12885214983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885214983)
  ],
  "h": 313095
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$SeJP.LCWCS.IWalletSendProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.Services.WithdrawToBankWalletSendProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}Services${separator}WithdrawToBankWalletSendProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(313095)
        
        

        //--TRIMMABLE-BOUNDARY-START(640775)
        $asm.$cls(`$SeJP.LCWC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180509959)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCP.WalletApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCP.WalletApp().$ctor$3();
                    }, $RMsiNb ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCP.WalletAppPages.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCP.WalletAppPages().$ctor$3();
                    }, $nOTbUb ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.BankGetBeneficiary.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.BankGetBeneficiary().$ctor$3();
                    }, $rfhIHi ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.PinEntry.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.PinEntry().$ctor$3();
                    }, $vvuanf ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletBuy.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletBuy().$ctor$3();
                    }, $LZWqWi ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletDenominate.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletDenominate().$ctor$3();
                    }, $sEekOb ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletHeader.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletHeader().$ctor$5();
                    }, $tqJUtb ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletHome.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletHome().$ctor$4();
                    }, $LQTTYj ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletIO.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletIO().$ctor$3();
                    }, $gQbpXb ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletPayment.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletPayment().$ctor$3();
                    }, $tiGxcj ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletReceive.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletReceive().$ctor$3();
                    }, $fickha ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletSend.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletSend().$ctor$3();
                    }, $xQdGSj ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletSwap.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletSwap().$ctor$3();
                    }, $xEybwj ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletTransactionDetail.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletTransactionDetail().$ctor$5();
                    }, $LquQzi ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletTransactionListItem.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletTransactionListItem().$ctor$5();
                    }, $YTxdye ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SeJP.LCWCS$1.WalletTransactions.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SeJP.LCWCS$1.WalletTransactions().$ctor$3();
                    }, $hWDJgd ??= {"r":2752627,"n":"","d":640775,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180509959)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295608071)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295608071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295608071)
            
            //--TRIMMABLE-BOUNDARY-START(4295608071)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295608071)
            
            static $h = 640775;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180509959),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885542663,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 640775,
      "h": 17180509959,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180509959)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295608071),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 640775,
      "h": 4295608071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295608071)
  ],
  "h": 640775
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(640775)
        
        

        //--TRIMMABLE-BOUNDARY-START(1492743)
        $asm.$cls(`$SeJP.LCWCS.WalletPaymentProcessor`, ($self) => class WalletPaymentProcessor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(98785740551)
            /*string? */ get Title()
            {
                return "Pay from Wallet";
            }
            //--TRIMMABLE-BOUNDARY-END(98785740551)
            
            //--TRIMMABLE-BOUNDARY-START(25771296519)
            /*string? */ get Description()
            {
                return "Pay for goods and services from your wallet";
            }
            //--TRIMMABLE-BOUNDARY-END(25771296519)
            
            //--TRIMMABLE-BOUNDARY-START(73015936775)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-hand-coin"/*MaterialDesignIconNames.HandCoin*/);
            }
            //--TRIMMABLE-BOUNDARY-END(73015936775)
            
            //--TRIMMABLE-BOUNDARY-START(17181361927)
            /*bool*/ AllowUseCashback = false;
            //--TRIMMABLE-BOUNDARY-END(17181361927)
            
            //--TRIMMABLE-BOUNDARY-START(103080707847)
            /*IWalletIssuer?*/ UseIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(103080707847)
            
            //--TRIMMABLE-BOUNDARY-START(21476329223)
            /*bool */ CanPayFor(/*string?*/ serviceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476329223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (serviceName === null)
                {
                    return true;
                }
                return !$.$$.S.String.StartsWith$3.call(serviceName, "Wallet/");
            }
            //--TRIMMABLE-BOUNDARY-END(21476329223)
            
            //--TRIMMABLE-BOUNDARY-START(77310904071)
            /*RenderFragment<ContainerContext<object?>> */ Pay(/*Money*/ transactionAmount, /*string*/ transactionTitle, /*string*/ transactionReferenceId, /*Action<PaymentResult>*/ onPaid, /*string?*/ transactionDescription, /*string?*/ serviceName, /*IContact?*/ payer, /*Dictionary<IContact, Money>?*/ payeeSplit, /*PaymentModel?*/ createPayment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310904071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                payer = $.$firstOf(payer, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Customer required") });
                return new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$hDPm.LCFC.FragmentView.From$1($.$SeJP.LCWCS$1.WalletPayment, (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.set_Item("ServiceName", serviceName);
                        $i1.set_Item("PaymentReference", transactionReferenceId);
                        $i1.set_Item("TransactionDescription", transactionDescription);
                        $i1.set_Item("Amount", $.$clone(transactionAmount));
                        $i1.set_Item("OnPaid", $.$mac.MAC.EventCallback.Factory.Create$8($.$hDPm.LCFCI.PaymentResult, this, onPaid));
                        $i1.set_Item("Payer", payer);
                        $i1.set_Item("Payee", payeeSplit);
                        $i1.set_Item("CreatePayment", createPayment);
                        $i1.set_Item("UseIssuer", this.UseIssuer);
                        $i1.set_Item("WalletSegment", $.$box(this.AllowUseCashback ? 1/*WalletSegment.Primary*/ | 2/*WalletSegment.Cashback*/ : 1/*WalletSegment.Primary*/, $.$OJJQ.LCFCW.WalletSegment));
                        return $i1;
                    })(), null, null);
                }, $ynsaLe ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1492743,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(77310904071)
            
            //--TRIMMABLE-BOUNDARY-START(4360591018)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IUIPaymentProcessor.CanPayFor(string?)
            LCFCI$IUIPaymentProcessor$CanPayFor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360591018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanPayFor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360591018)
            
            //--TRIMMABLE-BOUNDARY-START(8655558314)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IUIPaymentProcessor.Pay(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, string, string, System.Action<LivingThing.Core.Frameworks.Client.Interface.PaymentResult>, string?, string?, LivingThing.Core.Frameworks.Common.Contacts.IContact?, System.Collections.Generic.Dictionary<LivingThing.Core.Frameworks.Common.Contacts.IContact, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?, LivingThing.Core.Frameworks.Common.Models.PaymentModel?)
            LCFCI$IUIPaymentProcessor$Pay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8655558314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pay(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8655558314)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(12886394631)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886394631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886394631)
            
            //--TRIMMABLE-BOUNDARY-START(12886394631)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886394631)
            
            static $h = 1492743;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98785740551),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131034887,
        "f": 50331649
      },
      "n": "Title",
      "d": 1492743,
      "h": 98785740551,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785740551),
//--TRIMMABLE-BOUNDARY-START(25771296519),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951165703,
        "f": 50331649
      },
      "n": "Description",
      "d": 1492743,
      "h": 25771296519,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771296519),
//--TRIMMABLE-BOUNDARY-START(73015936775),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541100295,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1492743,
      "h": 73015936775,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015936775),
//--TRIMMABLE-BOUNDARY-START(17181361927),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361231111,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900838663,
        "f": 83886081
      },
      "n": "AllowUseCashback",
      "d": 1492743,
      "h": 17181361927,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181361927),
//--TRIMMABLE-BOUNDARY-START(103080707847),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720969479,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490773255,
        "f": 83886081
      },
      "n": "UseIssuer",
      "d": 1492743,
      "h": 103080707847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080707847)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476329223),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "CanPayFor",
      "d": 1492743,
      "h": 21476329223,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476329223),
//--TRIMMABLE-BOUNDARY-START(77310904071),
    {
      "r": $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)).$h,
      "p": [
        {
          "n": "transactionAmount",
          "p": 27822422
        },
        {
          "n": "transactionTitle",
          "p": 1310721
        },
        {
          "n": "transactionReferenceId",
          "p": 1310721
        },
        {
          "n": "onPaid",
          "p": $.$$.S.Action$$($.$hDPm.LCFCI.PaymentResult).$h
        },
        {
          "n": "transactionDescription",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "serviceName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "payer",
          "p": 5081430,
          "f": 65
        },
        {
          "n": "payeeSplit",
          "p": $.$$.SCG.Dictionary$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money).$h,
          "f": 65
        },
        {
          "n": "createPayment",
          "p": 12592470,
          "f": 65
        }
      ],
      "n": "Pay",
      "d": 1492743,
      "h": 77310904071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310904071)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886394631),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1492743,
      "h": 12886394631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886394631)
  ],
  "h": 1492743
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IUIPaymentProcessor, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletPaymentProcessor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletPaymentProcessor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1492743)
        
        

        //--TRIMMABLE-BOUNDARY-START(1427207)
        $asm.$cls(`$SeJP.LCWCS.WalletHolderFromTicket`, ($self) => class WalletHolderFromTicket extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(137440380679)
            /*DecodedAuthenticationTicket*/ ticket = null;
            //--TRIMMABLE-BOUNDARY-END(137440380679)
            
            //--TRIMMABLE-BOUNDARY-START(21476263687)
            $ctor$1(/*DecodedAuthenticationTicket*/ ticket)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476263687);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ticket = ticket;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476263687)
            
            //--TRIMMABLE-BOUNDARY-START(115965544199)
            /*DataId */ get Identifier()
            {
                return $.$fPer.LCFCD.DataId.op_Implicit$1(this.ticket.Id);
            }
            //--TRIMMABLE-BOUNDARY-END(115965544199)
            
            //--TRIMMABLE-BOUNDARY-START(128850446087)
            /*WalletAddress */ get NetworkAddress()
            {
                return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1(this.ticket.UserName);
            }
            //--TRIMMABLE-BOUNDARY-END(128850446087)
            
            //--TRIMMABLE-BOUNDARY-START(124555478791)
            /*string? */ get Name()
            {
                return this.ticket.UserName;
            }
            //--TRIMMABLE-BOUNDARY-END(124555478791)
            
            //--TRIMMABLE-BOUNDARY-START(141735347975)
            /*string? */ get Title()
            {
                return this.ticket.UserName;
            }
            //--TRIMMABLE-BOUNDARY-END(141735347975)
            
            //--TRIMMABLE-BOUNDARY-START(25771230983)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(25771230983)
            
            //--TRIMMABLE-BOUNDARY-START(111670576903)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(111670576903)
            
            //--TRIMMABLE-BOUNDARY-START(30066198279)
            /*string? */ get Email()
            {
                return this.ticket.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(30066198279)
            
            //--TRIMMABLE-BOUNDARY-START(133145413383)
            /*string?*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(133145413383)
            
            //--TRIMMABLE-BOUNDARY-START(120260511495)
            /*GeoLocation?*/ Location = null;
            //--TRIMMABLE-BOUNDARY-END(120260511495)
            
            //--TRIMMABLE-BOUNDARY-START(8590505165)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder.NetworkAddress.get
            get LCFCW$IWalletHolder$NetworkAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885472461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NetworkAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(8590505165)
            
            //--TRIMMABLE-BOUNDARY-START(21479917910)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Identifier.get
            get LCFCC$2$IContact$Identifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544688982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(21479917910)
            
            //--TRIMMABLE-BOUNDARY-START(47249721686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.PhoneNumber.get
            get LCFCC$2$IContact$PhoneNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64429590870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhoneNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(47249721686)
            
            //--TRIMMABLE-BOUNDARY-START(12889983318)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Email.get
            get LCFCC$2$IContact$Email()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300048726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(12889983318)
            
            //--TRIMMABLE-BOUNDARY-START(38659787094)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Location.get
            get LCFCC$2$IContact$Location()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60134623574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Location;
            }
            //--TRIMMABLE-BOUNDARY-END(38659787094)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(111670576903)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(111670576903)
                
            }
            static $h = 1427207;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115965544199),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425936647,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 1427207,
      "h": 115965544199,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965544199),
//--TRIMMABLE-BOUNDARY-START(128850446087),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195740423,
        "f": 50331649
      },
      "n": "NetworkAddress",
      "d": 1427207,
      "h": 128850446087,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850446087),
//--TRIMMABLE-BOUNDARY-START(124555478791),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605805831,
        "f": 50331649
      },
      "n": "Name",
      "d": 1427207,
      "h": 124555478791,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555478791),
//--TRIMMABLE-BOUNDARY-START(141735347975),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375609607,
        "f": 50331649
      },
      "n": "Title",
      "d": 1427207,
      "h": 141735347975,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141735347975),
//--TRIMMABLE-BOUNDARY-START(25771230983),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656132871,
        "f": 50331649
      },
      "n": "Description",
      "d": 1427207,
      "h": 25771230983,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771230983),
//--TRIMMABLE-BOUNDARY-START(111670576903),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836002055,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1427207,
      "h": 111670576903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670576903),
//--TRIMMABLE-BOUNDARY-START(30066198279),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246067463,
        "f": 50331649
      },
      "n": "Email",
      "d": 1427207,
      "h": 30066198279,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066198279),
//--TRIMMABLE-BOUNDARY-START(133145413383),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785675015,
        "f": 50331649
      },
      "n": "PhoneNumber",
      "d": 1427207,
      "h": 133145413383,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145413383),
//--TRIMMABLE-BOUNDARY-START(120260511495),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015871239,
        "f": 50331649
      },
      "n": "Location",
      "d": 1427207,
      "h": 120260511495,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260511495)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(137440380679),
    {
      "t": 1130882,
      "n": "ticket",
      "d": 1427207,
      "h": 137440380679,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137440380679)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476263687),
    {
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1427207,
      "h": 21476263687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476263687)
  ],
  "h": 1427207
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletHolder, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletHolderFromTicket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletHolderFromTicket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1427207)
        
        

        //--TRIMMABLE-BOUNDARY-START(1689351)
        $asm.$cls(`$SeJP.LCWCS.WalletUserHolder`, ($self) => class WalletUserHolder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(133145675527)
            /*UserModel*/ user = null;
            //--TRIMMABLE-BOUNDARY-END(133145675527)
            
            //--TRIMMABLE-BOUNDARY-START(12886591239)
            $ctor$1(/*UserModel*/ user)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886591239);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.user = $.$firstOf(user, () => { throw new $.$$.S.NullReferenceException().$ctor$12("User required") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886591239)
            
            //--TRIMMABLE-BOUNDARY-START(120260773639)
            /*WalletAddress */ get NetworkAddress()
            {
                return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1(this.user.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(120260773639)
            
            //--TRIMMABLE-BOUNDARY-START(115965806343)
            /*string? */ get Name()
            {
                return this.user.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(115965806343)
            
            //--TRIMMABLE-BOUNDARY-START(128850708231)
            /*string? */ get Title()
            {
                return this.user.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(128850708231)
            
            //--TRIMMABLE-BOUNDARY-START(17181558535)
            /*string? */ get Description()
            {
                return this.user.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(17181558535)
            
            //--TRIMMABLE-BOUNDARY-START(103080904455)
            /*IconDescriptor */ get Icon()
            {
                return this.user.IconDescriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(103080904455)
            
            //--TRIMMABLE-BOUNDARY-START(107375871751)
            /*DataId */ get Identifier()
            {
                return this.user.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(107375871751)
            
            //--TRIMMABLE-BOUNDARY-START(21476525831)
            /*string? */ get Email()
            {
                return this.user.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(21476525831)
            
            //--TRIMMABLE-BOUNDARY-START(124555740935)
            /*string?*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(124555740935)
            
            //--TRIMMABLE-BOUNDARY-START(111670839047)
            /*GeoLocation?*/ Location = null;
            //--TRIMMABLE-BOUNDARY-END(111670839047)
            
            //--TRIMMABLE-BOUNDARY-START(8590505165)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder.NetworkAddress.get
            get LCFCW$IWalletHolder$NetworkAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885472461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NetworkAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(8590505165)
            
            //--TRIMMABLE-BOUNDARY-START(21479917910)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Identifier.get
            get LCFCC$2$IContact$Identifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544688982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(21479917910)
            
            //--TRIMMABLE-BOUNDARY-START(47249721686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.PhoneNumber.get
            get LCFCC$2$IContact$PhoneNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64429590870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhoneNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(47249721686)
            
            //--TRIMMABLE-BOUNDARY-START(12889983318)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Email.get
            get LCFCC$2$IContact$Email()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300048726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(12889983318)
            
            //--TRIMMABLE-BOUNDARY-START(38659787094)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Location.get
            get LCFCC$2$IContact$Location()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60134623574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Location;
            }
            //--TRIMMABLE-BOUNDARY-END(38659787094)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            static $h = 1689351;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260773639),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606067975,
        "f": 50331649
      },
      "n": "NetworkAddress",
      "d": 1689351,
      "h": 120260773639,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260773639),
//--TRIMMABLE-BOUNDARY-START(115965806343),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016133383,
        "f": 50331649
      },
      "n": "Name",
      "d": 1689351,
      "h": 115965806343,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965806343),
//--TRIMMABLE-BOUNDARY-START(128850708231),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785937159,
        "f": 50331649
      },
      "n": "Title",
      "d": 1689351,
      "h": 128850708231,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850708231),
//--TRIMMABLE-BOUNDARY-START(17181558535),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066460423,
        "f": 50331649
      },
      "n": "Description",
      "d": 1689351,
      "h": 17181558535,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181558535),
//--TRIMMABLE-BOUNDARY-START(103080904455),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246329607,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1689351,
      "h": 103080904455,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080904455),
//--TRIMMABLE-BOUNDARY-START(107375871751),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836264199,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 1689351,
      "h": 107375871751,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375871751),
//--TRIMMABLE-BOUNDARY-START(21476525831),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656395015,
        "f": 50331649
      },
      "n": "Email",
      "d": 1689351,
      "h": 21476525831,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476525831),
//--TRIMMABLE-BOUNDARY-START(124555740935),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196002567,
        "f": 50331649
      },
      "n": "PhoneNumber",
      "d": 1689351,
      "h": 124555740935,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555740935),
//--TRIMMABLE-BOUNDARY-START(111670839047),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426198791,
        "f": 50331649
      },
      "n": "Location",
      "d": 1689351,
      "h": 111670839047,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670839047)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(133145675527),
    {
      "t": 23799126,
      "n": "user",
      "d": 1689351,
      "h": 133145675527,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133145675527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886591239),
    {
      "p": [
        {
          "n": "user",
          "p": 23799126
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1689351,
      "h": 12886591239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886591239)
  ],
  "h": 1689351
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletHolder, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletUserHolder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletUserHolder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1689351)
        
        

        //--TRIMMABLE-BOUNDARY-START(1623815)
        $asm.$cls(`$SeJP.LCWCS.WalletSystem`, ($self) => class WalletSystem extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(266289596167)
            /*WalletService*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(266289596167)
            
            //--TRIMMABLE-BOUNDARY-START(42951296775)
            $ctor$1(/*WalletService*/ service, /*UserModel*/ holder, /*IWalletIssuer?*/ issuer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951296775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = service;
                    this.Holder = new $.$SeJP.LCWCS.WalletUserHolder().$ctor$1($.$firstOf(holder, () => { throw new $.$$.S.NullReferenceException().$ctor$12("User required") }));
                    this.Issuers = issuer !== null ? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OJJQ.LCFCW.IWalletIssuer), [issuer], null, null) : service.Issuers;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951296775)
            
            //--TRIMMABLE-BOUNDARY-START(47246264071)
            $ctor$2(/*WalletService*/ service, /*IWalletHolder*/ holder, /*IWalletIssuer?*/ issuer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246264071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = service;
                    this.Holder = holder;
                    this.Issuers = issuer !== null ? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OJJQ.LCFCW.IWalletIssuer), [issuer], null, null) : service.Issuers;
                    if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers) === 1)
                    {
                        this.Title = $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers).LCFC$IDisplayable$Title ?? this.Title;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246264071)
            
            //--TRIMMABLE-BOUNDARY-START(257699661575)
            /*int*/ RecentTransactionSequenceNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(257699661575)
            
            //--TRIMMABLE-BOUNDARY-START(227634890503)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227634890503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let filter = this.service.Issuers !== this.Issuers || $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers) === 1 ? new $.$fPer.LCFCD.DataFilter().$ctor$22($.$$.S.String.Join$5(";", $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.String, $.$sl.SL.Enumerable.SelectMany$2($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), this.Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))))().$ctor(this,  (/*i*/ i) =>
                    {
                        return $.$sl.SL.Enumerable.Select$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), i.LCFCW$IWalletIssuer$CoinDescriptors, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)))().$ctor(this,  (/*c*/ c) =>
                        {
                            return new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(i, $.$clone(c));
                        }, $iyPdFi ??= {"r":$.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h,"p":[{"n":"c","p":3257549}],"n":"","d":1623815,"h":0,"f":17825794}));
                    }, $bAhTqb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)).$h,"p":[{"n":"i","p":636109}],"n":"","d":1623815,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.String))().$ctor(this,  (/*i*/ i) =>
                    {
                        return $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(i.Item1, i.Item2);
                    }, $PWrDsb ??= {"r":1310721,"p":[{"n":"i","p":$.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h}],"n":"","d":1623815,"h":0,"f":17825794}))), null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null) : $.$fPer.LCFCD.DataFilter.Default;
                    filter = $.$with(filter, ($clone) =>
                    {
                        $clone.DataId = $.$fPer.LCFCD.CompositeDataId.op_Implicit$1(this.Holder.LCFCC$2$IContact$Identifier);
                    });
                    this.Coins = (($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$OJJQ.LCFCW.UserWalletDataModel, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, filter, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)))).AsEnumerable();
                    this.RecentTransactionSequenceNumber++;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(227634890503)
            
            //--TRIMMABLE-BOUNDARY-START(51541231367)
            /*IEnumerable<UserWalletDataModel>?*/ Coins = null;
            //--TRIMMABLE-BOUNDARY-END(51541231367)
            
            //--TRIMMABLE-BOUNDARY-START(231929857799)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(231929857799)
            
            //--TRIMMABLE-BOUNDARY-START(339304040199)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(339304040199)
            
            //--TRIMMABLE-BOUNDARY-START(219044955911)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(219044955911)
            
            //--TRIMMABLE-BOUNDARY-START(214749988615)
            /*IWalletHolder*/ Holder = null;
            //--TRIMMABLE-BOUNDARY-END(214749988615)
            
            //--TRIMMABLE-BOUNDARY-START(343599007495)
            /*IEnumerable<IGrouping<string, IWalletToken>> */ get Tokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980184839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>?*/ let __ca1__;
                return ((__ca1__ = this.Coins) !== null ? ($.$sl.SL.Enumerable.GroupBy$7($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.CoinIdentifier.IssuerName;
                }, $isqLpb ??= {"r":1310721,"p":[{"n":"c","p":1881293}],"n":"","d":1623815,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken))) : $.$sl.SL.Enumerable.Empty($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken)));
            }
            //--TRIMMABLE-BOUNDARY-END(343599007495)
            
            //--TRIMMABLE-BOUNDARY-START(253404694279)
            /*Pager<IWalletTransaction> */ get RecentTransactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440577287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let filter = this.service.Issuers !== this.Issuers || $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers) === 1 ? new $.$fPer.LCFCD.DataFilter().$ctor$22($.$$.S.String.Join$5(";", $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.String, $.$sl.SL.Enumerable.SelectMany$2($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), this.Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$sl.SL.Enumerable.Select$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), i.LCFCW$IWalletIssuer$CoinDescriptors, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)))().$ctor(this,  (/**/ c) =>
                    {
                        return new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(i, $.$clone(c));
                    }, $YQdgsj ??= {"r":$.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h,"p":[{"n":"c","p":3257549}],"n":"","d":1623815,"h":0,"f":17825794}));
                }, $XYGekg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)).$h,"p":[{"n":"i","p":636109}],"n":"","d":1623815,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.String))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(i.Item1, i.Item2);
                }, $PzCTtk ??= {"r":1310721,"p":[{"n":"i","p":$.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h}],"n":"","d":1623815,"h":0,"f":17825794}))), null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null) : null;
                return $.$fPer.LCFCD.Paging.Cast$1($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$OJJQ.LCFCW.IWalletTransaction, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$OJJQ.LCFCW.UserWalletTransactionModel, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, filter, null));
            }
            //--TRIMMABLE-BOUNDARY-END(253404694279)
            
            //--TRIMMABLE-BOUNDARY-START(270584563463)
            /*IWalletServices */ get Services()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(270584563463)
            
            //--TRIMMABLE-BOUNDARY-START(223339923207)
            /*IEnumerable<IWalletIssuer>*/ Issuers = null;
            //--TRIMMABLE-BOUNDARY-END(223339923207)
            
            //--TRIMMABLE-BOUNDARY-START(236224825095)
            /*IWalletOfflinePaymentProvider?*/ OfflinePayment = null;
            //--TRIMMABLE-BOUNDARY-END(236224825095)
            
            //--TRIMMABLE-BOUNDARY-START(240519792391)
            /*IWalletOnlinePaymentProvider? */ get OnlinePayment()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(240519792391)
            
            //--TRIMMABLE-BOUNDARY-START(335009072903)
            /*Theme*/ Theme;
            //--TRIMMABLE-BOUNDARY-END(335009072903)
            
            //--TRIMMABLE-BOUNDARY-START(60131165959)
            /*IWalletFundPaymentProvider? */ get FundPayment()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60131165959)
            
            //--TRIMMABLE-BOUNDARY-START(261994628871)
            /*SelfAddress */ get SelfAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620446471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$SeJP.LCWCS.SelfAddress()
                    const $t2 = $.$SeJP.LCWCS.SelfAddress;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Address = this.Holder.LCFCW$IWalletHolder$NetworkAddress.ToString();
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(261994628871)
            
            //--TRIMMABLE-BOUNDARY-START(201865086727)
            /*ValueTask<IWalletHolder> *//*async*/  GetHolder(/*string*/ networkAddress)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder), $.$OJJQ.LCFCW.IWalletHolder, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201865086727);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let account = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$Iaui.LCFCM.UserModel, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(networkAddress, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new $.$SeJP.LCWCS.WalletUserHolder().$ctor$1(account));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201865086727)
            
            //--TRIMMABLE-BOUNDARY-START(210455021319)
            /*ValueTask<PagingDataResult<IWalletTransaction>> *//*async*/  GetTransactions(/*DataFilter*/ filter)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)), $.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction), async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210455021319);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let _filter = this.service.Issuers !== this.Issuers || $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers) === 1 ? new $.$fPer.LCFCD.DataFilter().$ctor$22($.$$.S.String.Join$5(";", $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.String, $.$sl.SL.Enumerable.SelectMany$2($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), this.Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))))().$ctor(this,  (/*i*/ i) =>
                    {
                        return $.$sl.SL.Enumerable.Select$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), i.LCFCW$IWalletIssuer$CoinDescriptors, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)))().$ctor(this,  (/*c*/ c) =>
                        {
                            return new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(i, $.$clone(c));
                        }, $IvcpEd ??= {"r":$.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h,"p":[{"n":"c","p":3257549}],"n":"","d":1623815,"h":0,"f":17825794}));
                    }, $DYWsji ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)).$h,"p":[{"n":"i","p":636109}],"n":"","d":1623815,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.String))().$ctor(this,  (/*i*/ i) =>
                    {
                        return $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(i.Item1, i.Item2);
                    }, $BHAHPd ??= {"r":1310721,"p":[{"n":"i","p":$.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h}],"n":"","d":1623815,"h":0,"f":17825794}))), null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null) : null;
                    /*var*/ let data = ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$OJJQ.LCFCW.UserWalletTransactionModel, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, filter.OverrideWith(_filter), null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCD.Paging.AsPagingDataResult$2($.$OJJQ.LCFCW.IWalletTransaction, ($.$cast(data.Data, $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletTransaction))), data.TotalCount));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(210455021319)
            
            //--TRIMMABLE-BOUNDARY-START(347893974791)
            /*Task<IEnumerable<UserWalletTransactionModel>> *//*async*/  Transfer(/*IWalletHolder*/ sender, /*IWalletHolder*/ recipient, /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ denominations, /*string*/ pinCode, /*string?*/ transactionDescription)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel)), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(347893974791);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*List<UserWalletTransactionModel>*/ let paymentReferences = new ($.$$.SCG.List$$($.$OJJQ.LCFCW.UserWalletTransactionModel))().$ctor$1();
                    let $en5 = denominations.GetEnumerator();
                    while ($en5.MoveNext())
                    {
                        let denom = $en5.Current;
                        {
                            let $t6, $r6;
                            /*var*/ let amount = denom.Key.Item2.Amount > 0 ? denom.Key.Item2.Amount * denom.Value : denom.Value;
                            /*var*/ let transaction = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$OJJQ.LCFCW.IWalletRemoteService, $.$OJJQ.LCFCW.UserWalletTransactionModel, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)))().$ctor(this,  (/**/ service) =>
                            {
                                return service.LCFCW$IWalletRemoteService$TransferTo($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(denom.Key.Item1, denom.Key.Item2), sender.LCFCC$2$IContact$Identifier, recipient.LCFCC$2$IContact$Identifier, amount, $.$fPer.LCFCS$6.StringExtension.GetRandomString(16, true, true, false), new $.$fPer.LCFCD.DataId().$ctor$2(), `Transfer: ${$.$strNN(transactionDescription)}`, pinCode, false, 1, 1);
                            }, $iKSCmb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,"p":[{"n":"service","p":1029325}],"n":"","d":1623815,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                            paymentReferences.Add(transaction);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, paymentReferences);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(347893974791)
            
            //--TRIMMABLE-BOUNDARY-START(55836198663)
            /*ValueTask<double> *//*async*/  FundAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Double), $.$$.S.Double, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836198663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let issuer = $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers) === 1 ? $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers) : (($t7 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select$2($.$hDPm.LCFCI.ViewConfiguration, $.$OJJQ.LCFCW.IWalletIssuer, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, "Select Issuer", "Select a coint issuer", new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.String))().$ctor(this,  (/**/ i) =>
                    {
                        return i.LCFC$IDisplayable$Title;
                    }, $sFwRll ??= {"r":1310721,"p":[{"n":"i","p":636109}],"n":"","d":1623815,"h":0,"f":17825794}), this.Issuers, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7))));
                    if (issuer !== null)
                    {
                        let $t8, $r8;
                        let $t9, $r9;
                        /*var*/ let tok = $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.WalletTokenDescriptor, issuer.LCFCW$IWalletIssuer$CoinDescriptors) === 1 ? $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.WalletTokenDescriptor, issuer.LCFCW$IWalletIssuer$CoinDescriptors) : ($t8 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select$2($.$hDPm.LCFCI.ViewConfiguration, $.$OJJQ.LCFCW.WalletTokenDescriptor, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, "Select Issuer", "Select a coint issuer", new ($.$$.S.Func$$$($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.String))().$ctor(this,  (/*i*/ i) =>
                        {
                            return i.Title;
                        }, $OhfPSk ??= {"r":1310721,"p":[{"n":"i","p":3257549}],"n":"","d":1623815,"h":0,"f":17825794}), issuer.LCFCW$IWalletIssuer$CoinDescriptors, null), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        /*var*/ let amt = ($t9 = this.service.FundAsync(this, issuer, $.$clone(tok)), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCDM.Money.op_Implicit(amt));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55836198663)
            
            //--TRIMMABLE-BOUNDARY-START(193275152135)
            /*double */ GetBalance(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275152135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>?*/ let __ca2__;
                return ((__ca2__ = this.Coins) !== null ? $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletDataModel, $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.UserWalletDataModel, __ca2__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.String.Equals$5.call(c.WalletName, $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(token)));
                }, $NwKgNa ??= {"r":262145,"p":[{"n":"c","p":1881293}],"n":"","d":1623815,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Amount;
                }, $kZcJHb ??= {"r":1179649,"p":[{"n":"c","p":1881293}],"n":"","d":1623815,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(193275152135)
            
            //--TRIMMABLE-BOUNDARY-START(197570119431)
            /*double */ GetCashback(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570119431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>?*/ let __ca3__;
                return ((__ca3__ = this.Coins) !== null ? $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletDataModel, $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.UserWalletDataModel, __ca3__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.String.Equals$5.call(c.WalletName, $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(token)));
                }, $sYhwEj ??= {"r":262145,"p":[{"n":"c","p":1881293}],"n":"","d":1623815,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Cashback;
                }, $AcmKjk ??= {"r":1179649,"p":[{"n":"c","p":1881293}],"n":"","d":1623815,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(197570119431)
            
            //--TRIMMABLE-BOUNDARY-START(206160054023)
            /*Task<IWalletHolder> *//*async*/  GetPeer(/*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder), $.$OJJQ.LCFCW.IWalletHolder, async ($asnycContext) => 
                {
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206160054023);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let user = ($t10 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select($.$hDPm.LCFCI.ViewConfiguration, $.$Iaui.LCFCM.UserModel, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, this.service.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Select Recipient", false), null, 1, 1, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t11 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Theme = $.$fPer.LCFC.Theme.Primary;
                        return $i11;
                    })(), null, 35184372092928n | 65536n | 8n | 4503599627370496n, null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new $.$SeJP.LCWCS.WalletUserHolder().$ctor$1($.$sl.SL.Enumerable.Single$1($.$Iaui.LCFCM.UserModel, user)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206160054023)
            
            //--TRIMMABLE-BOUNDARY-START(244814759687)
            /*ValueTask<object> *//*async*/  Pay(/*IWalletHolder*/ sender, /*IWalletHolder*/ recipient, /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ denominations, /*string*/ pinCode, /*string?*/ transactionDescription, /*IWalletPaymentSendProgressReportIndicator*/ progressIndicator, /*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244814759687);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let r = ($t12 = this.Transfer(sender, recipient, denominations, pinCode, transactionDescription), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.UserWalletTransactionModel, r) === 1)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.UserWalletTransactionModel, r));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, r);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(244814759687)
            
            //--TRIMMABLE-BOUNDARY-START(249109726983)
            /*Task<IDisposable?> */ Receive(/*IWalletHolder*/ self, /*IWalletPaymentReceiveProgressReportIndicator*/ receiverHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109726983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.S.IDisposable, null);
            }
            //--TRIMMABLE-BOUNDARY-END(249109726983)
            
            //--TRIMMABLE-BOUNDARY-START(34361029837)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Name.get
            get LCFCW$IWalletSystem$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080506573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(34361029837)
            
            //--TRIMMABLE-BOUNDARY-START(68720768205)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Title.get
            get LCFCW$IWalletSystem$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260375757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(68720768205)
            
            //--TRIMMABLE-BOUNDARY-START(17181160653)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Icon.get
            get LCFCW$IWalletSystem$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490571981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(17181160653)
            
            //--TRIMMABLE-BOUNDARY-START(60130833613)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Theme.get
            get LCFCW$IWalletSystem$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965408461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(60130833613)
            
            //--TRIMMABLE-BOUNDARY-START(8591226061)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Holder.get
            get LCFCW$IWalletSystem$Holder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195604685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Holder;
            }
            //--TRIMMABLE-BOUNDARY-END(8591226061)
            
            //--TRIMMABLE-BOUNDARY-START(25771095245)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Issuers.get
            get LCFCW$IWalletSystem$Issuers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785539277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Issuers;
            }
            //--TRIMMABLE-BOUNDARY-END(25771095245)
            
            //--TRIMMABLE-BOUNDARY-START(77310702797)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Tokens.get
            get LCFCW$IWalletSystem$Tokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555343053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Tokens;
            }
            //--TRIMMABLE-BOUNDARY-END(77310702797)
            
            //--TRIMMABLE-BOUNDARY-START(42950964429)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.RecentTransactions.get
            get LCFCW$IWalletSystem$RecentTransactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375473869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RecentTransactions;
            }
            //--TRIMMABLE-BOUNDARY-END(42950964429)
            
            //--TRIMMABLE-BOUNDARY-START(51540899021)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.Services.get
            get LCFCW$IWalletSystem$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670441165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(51540899021)
            
            //--TRIMMABLE-BOUNDARY-START(85900637389)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem.GetTransactions(LivingThing.Core.Frameworks.Common.Data.DataFilter)
            LCFCW$IWalletSystem$GetTransactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900637389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetTransactions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(85900637389)
            
            //--TRIMMABLE-BOUNDARY-START(21476062413)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.Issuers.get
            get LCFCW$IWalletServices$Issuers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245866189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Issuers;
            }
            //--TRIMMABLE-BOUNDARY-END(21476062413)
            
            //--TRIMMABLE-BOUNDARY-START(30065997005)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.OfflinePayment.get
            get LCFCW$IWalletServices$OfflinePayment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540833485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OfflinePayment;
            }
            //--TRIMMABLE-BOUNDARY-END(30065997005)
            
            //--TRIMMABLE-BOUNDARY-START(38655931597)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.OnlinePayment.get
            get LCFCW$IWalletServices$OnlinePayment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835800781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnlinePayment;
            }
            //--TRIMMABLE-BOUNDARY-END(38655931597)
            
            //--TRIMMABLE-BOUNDARY-START(12886127821)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.FundPayment.get
            get LCFCW$IWalletServices$FundPayment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296193229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FundPayment;
            }
            //--TRIMMABLE-BOUNDARY-END(12886127821)
            
            //--TRIMMABLE-BOUNDARY-START(42950898893)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletServices.GetHolder(string)
            LCFCW$IWalletServices$GetHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950898893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHolder(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42950898893)
            
            //--TRIMMABLE-BOUNDARY-START(4295734477)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletOnlinePaymentProvider.GetBalance(LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer, LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor)
            LCFCW$IWalletOnlinePaymentProvider$GetBalance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295734477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBalance(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295734477)
            
            //--TRIMMABLE-BOUNDARY-START(4295472333)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletFundPaymentProvider.FundAsync()
            LCFCW$IWalletFundPaymentProvider$FundAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295472333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FundAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295472333)
            
            //--TRIMMABLE-BOUNDARY-START(4295935751)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.GetPeer(System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$GetPeer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295935751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPeer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295935751)
            
            //--TRIMMABLE-BOUNDARY-START(12885870343)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletSendProvider.Pay(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, System.Collections.Generic.Dictionary<(LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer, LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor), double>, string, string?, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator, System.Threading.CancellationToken)
            LCWCS$IWalletSendProvider$Pay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885870343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pay(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885870343)
            
            //--TRIMMABLE-BOUNDARY-START(8590837511)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletReceiveProvider.SelfAddress.get
            get LCWCS$IWalletReceiveProvider$SelfAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180772103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SelfAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(8590837511)
            
            //--TRIMMABLE-BOUNDARY-START(12885804807)
            //Generated interface implemetation for LivingThing.Core.Wallet.Client.Services.IWalletReceiveProvider.Receive(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator)
            LCWCS$IWalletReceiveProvider$Receive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885804807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Receive(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885804807)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(231929857799)
                this.Name = "Coins";
                //--TRIMMABLE-BOUNDARY-END(231929857799)
                
                //--TRIMMABLE-BOUNDARY-START(339304040199)
                this.Title = "Zoey Coins";
                //--TRIMMABLE-BOUNDARY-END(339304040199)
                
                //--TRIMMABLE-BOUNDARY-START(219044955911)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(219044955911)
                
                //--TRIMMABLE-BOUNDARY-START(335009072903)
                this.Theme = $.$SeJP.LCWCS.WalletApplication.GlobalTheme;
                //--TRIMMABLE-BOUNDARY-END(335009072903)
                
            }
            static $h = 1623815;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(257699661575),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030511879,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313534236423,
        "f": 83886082
      },
      "n": "RecentTransactionSequenceNumber",
      "d": 1623815,
      "h": 257699661575,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257699661575),
//--TRIMMABLE-BOUNDARY-START(51541231367),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletDataModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721100551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279174498055,
        "f": 83886082
      },
      "n": "Coins",
      "d": 1623815,
      "h": 51541231367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541231367),
//--TRIMMABLE-BOUNDARY-START(231929857799),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670773511,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296354367239,
        "f": 83886081
      },
      "n": "Name",
      "d": 1623815,
      "h": 231929857799,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231929857799),
//--TRIMMABLE-BOUNDARY-START(339304040199),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390250247,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330714105607,
        "f": 83886081
      },
      "n": "Title",
      "d": 1623815,
      "h": 339304040199,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339304040199),
//--TRIMMABLE-BOUNDARY-START(219044955911),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490904327,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287764432647,
        "f": 83886081
      },
      "n": "Icon",
      "d": 1623815,
      "h": 219044955911,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044955911),
//--TRIMMABLE-BOUNDARY-START(214749988615),
    {
      "p": 570573,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900969735,
        "f": 50331649
      },
      "n": "Holder",
      "d": 1623815,
      "h": 214749988615,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749988615),
//--TRIMMABLE-BOUNDARY-START(343599007495),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980184839,
        "f": 50331649
      },
      "n": "Tokens",
      "d": 1623815,
      "h": 343599007495,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343599007495),
//--TRIMMABLE-BOUNDARY-START(253404694279),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$OJJQ.LCFCW.IWalletTransaction).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440577287,
        "f": 50331649
      },
      "n": "RecentTransactions",
      "d": 1623815,
      "h": 253404694279,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253404694279),
//--TRIMMABLE-BOUNDARY-START(270584563463),
    {
      "p": 1225933,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210381063,
        "f": 50331649
      },
      "n": "Services",
      "d": 1623815,
      "h": 270584563463,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270584563463),
//--TRIMMABLE-BOUNDARY-START(223339923207),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080838919,
        "f": 50331649
      },
      "n": "Issuers",
      "d": 1623815,
      "h": 223339923207,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339923207),
//--TRIMMABLE-BOUNDARY-START(236224825095),
    {
      "p": 701645,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260708103,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304944301831,
        "f": 83886081
      },
      "n": "OfflinePayment",
      "d": 1623815,
      "h": 236224825095,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224825095),
//--TRIMMABLE-BOUNDARY-START(240519792391),
    {
      "p": 767181,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850642695,
        "f": 50331649
      },
      "n": "OnlinePayment",
      "d": 1623815,
      "h": 240519792391,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519792391),
//--TRIMMABLE-BOUNDARY-START(335009072903),
    {
      "p": 65309014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800315655,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322124171015,
        "f": 83886081
      },
      "n": "Theme",
      "d": 1623815,
      "h": 335009072903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335009072903),
//--TRIMMABLE-BOUNDARY-START(60131165959),
    {
      "p": 505037,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311035143,
        "f": 50331649
      },
      "n": "FundPayment",
      "d": 1623815,
      "h": 60131165959,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131165959),
//--TRIMMABLE-BOUNDARY-START(261994628871),
    {
      "p": 1033991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620446471,
        "f": 50331649
      },
      "n": "SelfAddress",
      "d": 1623815,
      "h": 261994628871,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261994628871)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(227634890503),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1623815,
      "h": 227634890503,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(227634890503),
//--TRIMMABLE-BOUNDARY-START(201865086727),
    {
      "r": $.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "networkAddress",
          "p": 1310721
        }
      ],
      "n": "GetHolder",
      "d": 1623815,
      "h": 201865086727,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(201865086727),
//--TRIMMABLE-BOUNDARY-START(210455021319),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetTransactions",
      "d": 1623815,
      "h": 210455021319,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(210455021319),
//--TRIMMABLE-BOUNDARY-START(347893974791),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "sender",
          "p": 570573
        },
        {
          "n": "recipient",
          "p": 570573
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "Transfer",
      "d": 1623815,
      "h": 347893974791,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(347893974791),
//--TRIMMABLE-BOUNDARY-START(55836198663),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Double).$h,
      "n": "FundAsync",
      "d": 1623815,
      "h": 55836198663,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(55836198663),
//--TRIMMABLE-BOUNDARY-START(193275152135),
    {
      "r": 1179649,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "GetBalance",
      "d": 1623815,
      "h": 193275152135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193275152135),
//--TRIMMABLE-BOUNDARY-START(197570119431),
    {
      "r": 1179649,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "GetCashback",
      "d": 1623815,
      "h": 197570119431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197570119431),
//--TRIMMABLE-BOUNDARY-START(206160054023),
    {
      "r": $.$$.STT.Task$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "GetPeer",
      "d": 1623815,
      "h": 206160054023,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(206160054023),
//--TRIMMABLE-BOUNDARY-START(244814759687),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "sender",
          "p": 570573
        },
        {
          "n": "recipient",
          "p": 570573
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        },
        {
          "n": "progressIndicator",
          "p": 898253
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "Pay",
      "d": 1623815,
      "h": 244814759687,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(244814759687),
//--TRIMMABLE-BOUNDARY-START(249109726983),
    {
      "r": $.$$.STT.Task$$($.$$.S.IDisposable).$h,
      "p": [
        {
          "n": "self",
          "p": 570573
        },
        {
          "n": "receiverHandler",
          "p": 832717
        }
      ],
      "n": "Receive",
      "d": 1623815,
      "h": 249109726983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249109726983)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(266289596167),
    {
      "t": 1558279,
      "n": "service",
      "d": 1623815,
      "h": 266289596167,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(266289596167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951296775),
    {
      "p": [
        {
          "n": "service",
          "p": 1558279
        },
        {
          "n": "holder",
          "p": 23799126
        },
        {
          "n": "issuer",
          "p": 636109,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1623815,
      "h": 42951296775,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951296775),
//--TRIMMABLE-BOUNDARY-START(47246264071),
    {
      "p": [
        {
          "n": "service",
          "p": 1558279
        },
        {
          "n": "holder",
          "p": 570573
        },
        {
          "n": "issuer",
          "p": 636109,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1623815,
      "h": 47246264071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246264071)
  ],
  "h": 1623815
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletSystem, $.$OJJQ.LCFCW.IWalletServices, $.$OJJQ.LCFCW.IWalletOnlinePaymentProvider, $.$OJJQ.LCFCW.IWalletFundPaymentProvider, $.$SeJP.LCWCS.IWalletSendProvider, $.$SeJP.LCWCS.IWalletReceiveProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletSystem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletSystem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1623815)
        
        

        //--TRIMMABLE-BOUNDARY-START(1033991)
        $asm.$str(`$SeJP.LCWCS.SelfAddress`, ($self) => class SelfAddress extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180903175)
            /*string?*/ Address = null;
            //--TRIMMABLE-BOUNDARY-END(17180903175)
            
            //--TRIMMABLE-BOUNDARY-START(55835608839)
            /*MarkupString?*/ SVG = null;
            //--TRIMMABLE-BOUNDARY-END(55835608839)
            
            //--TRIMMABLE-BOUNDARY-START(12885935879)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885935879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885935879)
            
            //--TRIMMABLE-BOUNDARY-START(12885935879)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885935879)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Address = this.Address;
                copy.SVG = this.SVG?.$clone() ?? null;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835608839)
                this.SVG = null;
                //--TRIMMABLE-BOUNDARY-END(55835608839)
                
            }
            static $h = 1033991;
            static $z = 9;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180903175),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770837767,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950706951,
        "f": 83886081
      },
      "n": "Address",
      "d": 1033991,
      "h": 17180903175,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180903175),
//--TRIMMABLE-BOUNDARY-START(55835608839),
    {
      "p": $.$typeNullable($.$mac.MAC.MarkupString).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360772359,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540641543,
        "f": 83886081
      },
      "n": "SVG",
      "d": 1033991,
      "h": 55835608839,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835608839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885935879),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1033991,
      "h": 12885935879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885935879)
  ],
  "h": 1033991
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.SelfAddress`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}SelfAddress`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1033991)
        
        

        //--TRIMMABLE-BOUNDARY-START(3131143)
        $asm.$cls(`$SeJP.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298098439)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298098439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298098439)
            
            //--TRIMMABLE-BOUNDARY-START(4298098439)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298098439)
            
            static $h = 3131143;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298098439),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3131143,
      "h": 4298098439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298098439)
  ],
  "h": 3131143
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3131143)
        
        

        //--TRIMMABLE-BOUNDARY-START(3196679)
        $asm.$cls(`$SeJP.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298163975)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298163975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298163975)
            
            //--TRIMMABLE-BOUNDARY-START(4298163975)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298163975)
            
            static $h = 3196679;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298163975),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3196679,
      "h": 4298163975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298163975)
  ],
  "h": 3196679,
  "a": [
    {
      "t": 3131143,
      "c": 4298098439
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3196679)
        
        

        //--TRIMMABLE-BOUNDARY-START(2213639)
        $asm.$str(`$SeJP.LCWCS$1.WalletHomeFeatures`, ($self) => class WalletHomeFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static ToolBarControls = 1;
            static Default = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2213639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ToolBarControls": 1n,
                    "Default": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297180935)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297180935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297180935)
            
            //--TRIMMABLE-BOUNDARY-START(4297180935)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297180935)
            
            static $h = 2213639;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887115527),
    {
      "t": 2213639,
      "n": "None",
      "d": 2213639,
      "h": 12887115527,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887115527),
//--TRIMMABLE-BOUNDARY-START(17182082823),
    {
      "t": 2213639,
      "n": "ToolBarControls",
      "d": 2213639,
      "h": 17182082823,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182082823),
//--TRIMMABLE-BOUNDARY-START(8592148231),
    {
      "t": 2213639,
      "n": "Default",
      "d": 2213639,
      "h": 8592148231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592148231)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297180935),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2213639,
      "h": 4297180935,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297180935)
  ],
  "h": 2213639,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletHomeFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletHomeFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2213639)
        
        

        //--TRIMMABLE-BOUNDARY-START(2672391)
        $asm.$str(`$SeJP.LCWCS$1.WalletSwapFeatures`, ($self) => class WalletSwapFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Header = 1;
            static Default = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2672391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Header": 1n,
                    "Default": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297639687)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297639687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297639687)
            
            //--TRIMMABLE-BOUNDARY-START(4297639687)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297639687)
            
            static $h = 2672391;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182541575),
    {
      "t": 2672391,
      "n": "None",
      "d": 2672391,
      "h": 17182541575,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182541575),
//--TRIMMABLE-BOUNDARY-START(12887574279),
    {
      "t": 2672391,
      "n": "Header",
      "d": 2672391,
      "h": 12887574279,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887574279),
//--TRIMMABLE-BOUNDARY-START(8592606983),
    {
      "t": 2672391,
      "n": "Default",
      "d": 2672391,
      "h": 8592606983,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592606983)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297639687),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2672391,
      "h": 4297639687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297639687)
  ],
  "h": 2672391
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletSwapFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletSwapFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2672391)
        
        

        //--TRIMMABLE-BOUNDARY-START(771847)
        $asm.$cls(`$SeJP.LCWCP.WalletAppPages`, ($self) => class WalletAppPages extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590706439)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590706439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590706439)
            
            //--TRIMMABLE-BOUNDARY-START(12885673735)
            static /*RenderFragment */ GetPages(/*string*/ walletName, /*Func<IWalletSystem>*/ getWallet, /*ApplicationPageAccessibility*/ pageAccessibility, /*RenderFragment<ContainerContext<IApplicationPageContext<object>>>?*/ walletIcon, /*string?*/ path, /*Action<IApplicationPageContext<object>>?*/ configureHomeContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885673735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(0, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 1);
                    __builder2.AddComponentParameter(2, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, walletName));
                    __builder2.AddComponentParameter(3, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(path ?? "**"/*RoutePath.ZeroOrMorePathSegment*/)));
                    __builder2.AddComponentParameter(4, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(5, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, pageAccessibility), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(6, "ConfigureContext", (configureHomeContext));
                    __builder2.AddAttribute$3(7, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$4(8, walletName);
                        }, $dHNwib ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":771847,"h":0,"f":17825794});
                    }), $GAinKf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":771847,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(9, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (walletIcon !== null)
                            {
                                __builder3.AddContent$1(10, walletIcon.Invoke($.$clone(context)));
                            }
                            else 
                            {
                                __builder3.AddMarkupContent(11, "<i class=\"mdi mdi-wallet\"></i>");
                            }
                        }, $fAotqj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":771847,"h":0,"f":17825794});
                    }), $aYYnQf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":771847,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(12, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$SeJP.LCWCS$1.WalletHome, 13);
                            __builder3.AddComponentParameter(14, "Wallet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, getWallet.Invoke()));
                            __builder3.CloseComponent();
                        }, $mtAJah ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":771847,"h":0,"f":17825794});
                    }), $WhFvua ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":771847,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(15, "\r\n    ");
                }, $PWCXLf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":771847,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12885673735)
            
            //--TRIMMABLE-BOUNDARY-START(4295739143)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295739143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295739143)
            
            //--TRIMMABLE-BOUNDARY-START(4295739143)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295739143)
            
            static $h = 771847;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590706439),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 771847,
      "h": 8590706439,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590706439),
//--TRIMMABLE-BOUNDARY-START(12885673735),
    {
      "r": 6881395,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "getWallet",
          "p": $.$$.S.Func$$($.$OJJQ.LCFCW.IWalletSystem).$h
        },
        {
          "n": "pageAccessibility",
          "p": 1912905
        },
        {
          "n": "walletIcon",
          "p": $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))).$h,
          "f": 65
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "configureHomeContext",
          "p": $.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h,
          "f": 65
        }
      ],
      "n": "GetPages",
      "d": 771847,
      "h": 12885673735,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885673735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295739143),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 771847,
      "h": 4295739143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295739143)
  ],
  "h": 771847
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Pages.WalletAppPages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Pages${separator}WalletAppPages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(771847)
        
        

        //--TRIMMABLE-BOUNDARY-START(378631)
        $asm.$cls(`$SeJP.LCWC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590313223)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590313223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590313223)
            
            //--TRIMMABLE-BOUNDARY-START(4295345927)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295345927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295345927)
            
            //--TRIMMABLE-BOUNDARY-START(4295345927)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295345927)
            
            static $h = 378631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590313223),
    {
      "r": 65537,
      "n": "Execute",
      "d": 378631,
      "h": 8590313223,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590313223)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295345927),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 378631,
      "h": 4295345927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295345927)
  ],
  "h": 378631
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(378631)
        
        

        //--TRIMMABLE-BOUNDARY-START(706311)
        $asm.$cls(`$SeJP.LCWCP.WalletApp`, ($self) => class WalletApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(77310117639)
            /*WalletService*/ WalletService = null;
            //--TRIMMABLE-BOUNDARY-END(77310117639)
            
            //--TRIMMABLE-BOUNDARY-START(73015150343)
            /*WalletApplication*/ WalletApplication = null;
            //--TRIMMABLE-BOUNDARY-END(73015150343)
            
            //--TRIMMABLE-BOUNDARY-START(51540313863)
            /*string */ get OptimizedComponentName()
            {
                return "walletapp";
            }
            //--TRIMMABLE-BOUNDARY-END(51540313863)
            
            //--TRIMMABLE-BOUNDARY-START(47245346567)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245346567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.WalletService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletService, serviceProvider);
                this.WalletApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(47245346567)
            
            //--TRIMMABLE-BOUNDARY-START(17180575495)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180575495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "Wallet");
                __builder.AddComponentParameter(2, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("")));
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.WalletService));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.AddContent$4(6, "Wallet");
                    }, $wQZklc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":706311,"h":0,"f":17825794});
                }), $kglLHd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":706311,"h":0,"f":17825794}));
                __builder.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$1(8, $.$SeJP.LCWCP.WalletAppPages.GetPages("Coins", new ($.$$.S.Func$$($.$OJJQ.LCFCW.IWalletSystem))().$ctor(this,  () =>
                    {
                        return $.$firstOf(this.WalletService.System, () => { throw new $.$$.S.ArgumentNullException().$ctor$15() });
                    }, $OCFNda ??= {"r":1291469,"n":"","d":706311,"h":0,"f":17825794}), $.$lJUR.LCFCS.ApplicationUtility.GetPageAccessibility(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box), null, null, null));
                    __builder2.AddMarkupContent(9, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 10);
                    __builder2.AddComponentParameter(11, "Name", "Buy");
                    __builder2.AddComponentParameter(12, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, $.$lJUR.LCFCS.ApplicationUtility.GetPageAccessibility(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(13, "Class", "pd");
                    __builder2.AddAttribute$3(14, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(15, "Buy Coins");
                        }, $ERIyrj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706311,"h":0,"f":17825794});
                    }), $VRhqNj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706311,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(16, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(17, "<i class=\"mdi mdi-cash\"></i>");
                        }, $JEoAch ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706311,"h":0,"f":17825794});
                    }), $NZEcbi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706311,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(18, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$SeJP.LCWCS$1.WalletBuy, 19);
                            __builder3.CloseComponent();
                        }, $dtfgna ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":706311,"h":0,"f":17825794});
                    }), $IzhkIk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":706311,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $TMTrnk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":706311,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180575495)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885608199)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885608199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885608199)
            
            //--TRIMMABLE-BOUNDARY-START(12885608199)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885608199)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77310117639)
                this.WalletService = null;
                //--TRIMMABLE-BOUNDARY-END(77310117639)
                
                //--TRIMMABLE-BOUNDARY-START(73015150343)
                this.WalletApplication = null;
                //--TRIMMABLE-BOUNDARY-END(73015150343)
                
            }
            static $h = 706311;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310117639),
    {
      "p": 1558279,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950379271,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720183047,
        "f": 83886081
      },
      "n": "WalletService",
      "d": 706311,
      "h": 77310117639,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310117639),
//--TRIMMABLE-BOUNDARY-START(73015150343),
    {
      "p": 1099527,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360444679,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130248455,
        "f": 83886081
      },
      "n": "WalletApplication",
      "d": 706311,
      "h": 73015150343,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015150343),
//--TRIMMABLE-BOUNDARY-START(51540313863),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770510087,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 706311,
      "h": 51540313863,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540313863)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245346567),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 706311,
      "h": 47245346567,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245346567),
//--TRIMMABLE-BOUNDARY-START(17180575495),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 706311,
      "h": 17180575495,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180575495)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885608199),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 706311,
      "h": 12885608199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885608199)
  ],
  "h": 706311
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Pages.WalletApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Pages${separator}WalletApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(706311)
        
        

        //--TRIMMABLE-BOUNDARY-START(3000071)
        $asm.$cls(`$SeJP.LCWCS$1.WalletTransactions`, ($self) => class WalletTransactions extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(77312411399)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(77312411399)
            
            //--TRIMMABLE-BOUNDARY-START(47247640327)
            /*IWalletIssuer*/ Issuer = null;
            //--TRIMMABLE-BOUNDARY-END(47247640327)
            
            //--TRIMMABLE-BOUNDARY-START(51542607623)
            /*string */ get OptimizedComponentName()
            {
                return "wallettransactions";
            }
            //--TRIMMABLE-BOUNDARY-END(51542607623)
            
            //--TRIMMABLE-BOUNDARY-START(73017444103)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017444103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "Issuer":
                    this.Issuer = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletIssuer);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(73017444103)
            
            //--TRIMMABLE-BOUNDARY-START(17182869255)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182869255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$OJJQ.LCFCW.UserWalletTransactionModel), 0);
                __builder.AddComponentParameter(1, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$22(this.Issuer.LCFC$INamed$Name, null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null)));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OJJQ.LCFCW.UserWalletTransactionModel))))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$SeJP.LCWCS$1.WalletTransactionListItem, 4);
                        __builder2.AddComponentParameter(5, "Wallet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Wallet));
                        __builder2.AddComponentParameter(6, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletTransaction, context.Data));
                        __builder2.CloseComponent();
                    }, $qcVJDh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3000071,"h":0,"f":17825794});
                }), $lsVaAg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h}],"n":"","d":3000071,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17182869255)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887901959)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887901959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887901959)
            
            //--TRIMMABLE-BOUNDARY-START(12887901959)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12887901959)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77312411399)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(77312411399)
                
                //--TRIMMABLE-BOUNDARY-START(47247640327)
                this.Issuer = null;
                //--TRIMMABLE-BOUNDARY-END(47247640327)
                
            }
            static $h = 3000071;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77312411399),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952673031,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722476807,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 3000071,
      "h": 77312411399,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77312411399),
//--TRIMMABLE-BOUNDARY-START(47247640327),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772803847,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132542215,
        "f": 83886081
      },
      "n": "Issuer",
      "d": 3000071,
      "h": 47247640327,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247640327),
//--TRIMMABLE-BOUNDARY-START(51542607623),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362738439,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3000071,
      "h": 51542607623,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51542607623)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73017444103),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3000071,
      "h": 73017444103,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73017444103),
//--TRIMMABLE-BOUNDARY-START(17182869255),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3000071,
      "h": 17182869255,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182869255)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887901959),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3000071,
      "h": 12887901959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887901959)
  ],
  "h": 3000071
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletTransactions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletTransactions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3000071)
        
        

        //--TRIMMABLE-BOUNDARY-START(1885959)
        $asm.$cls(`$SeJP.LCWCS$1.PinEntry`, ($self) => class PinEntry extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(94491166471)
            /*string */ get OptimizedComponentName()
            {
                return "pinentry";
            }
            //--TRIMMABLE-BOUNDARY-END(94491166471)
            
            //--TRIMMABLE-BOUNDARY-START(150325741319)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325741319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Size":
                    this.Size = $.$cast(parameter.Value, $.$$.S.Int32);
                    return true;
                    case "Pin":
                    this.Pin = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "PinChanged":
                    this.PinChanged = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$$.S.String));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(150325741319)
            
            //--TRIMMABLE-BOUNDARY-START(146030774023)
            /*int*/ Size = 0;
            //--TRIMMABLE-BOUNDARY-END(146030774023)
            
            //--TRIMMABLE-BOUNDARY-START(111671035655)
            /*string?*/ Pin = null;
            //--TRIMMABLE-BOUNDARY-END(111671035655)
            
            //--TRIMMABLE-BOUNDARY-START(115966002951)
            /*EventCallback<string>*/ PinChanged;
            //--TRIMMABLE-BOUNDARY-END(115966002951)
            
            //--TRIMMABLE-BOUNDARY-START(90196199175)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196199175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.password = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [this.Size], null);
                this.pass = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mac.MAC.ElementReference), null, [this.Size], null);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(90196199175)
            
            //--TRIMMABLE-BOUNDARY-START(98786133767)
            /*ElementReference[]*/ pass = null;
            //--TRIMMABLE-BOUNDARY-END(98786133767)
            
            //--TRIMMABLE-BOUNDARY-START(107376068359)
            /*string[]*/ password = null;
            //--TRIMMABLE-BOUNDARY-END(107376068359)
            
            //--TRIMMABLE-BOUNDARY-START(68721362695)
            /*Task *//*async*/  NextPass1()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721362695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$macw.MAC.ElementReferenceExtensions.FocusAsync$1($.$$.System.Array.$ReadT1.call(this.pass, 1)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.Notify(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68721362695)
            
            //--TRIMMABLE-BOUNDARY-START(73016329991)
            /*Task *//*async*/  NextPass2()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016329991);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = $.$macw.MAC.ElementReferenceExtensions.FocusAsync$1($.$$.System.Array.$ReadT1.call(this.pass, 2)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    ($t5 = this.Notify(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73016329991)
            
            //--TRIMMABLE-BOUNDARY-START(77311297287)
            /*Task *//*async*/  NextPass3()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311297287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = $.$macw.MAC.ElementReferenceExtensions.FocusAsync$1($.$$.System.Array.$ReadT1.call(this.pass, 3)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = this.Notify(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77311297287)
            
            //--TRIMMABLE-BOUNDARY-START(81606264583)
            /*Task *//*async*/  NextPass4()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606264583);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = $.$macw.MAC.ElementReferenceExtensions.FocusAsync$1($.$$.System.Array.$ReadT1.call(this.pass, 3)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    ($t9 = this.Notify(), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81606264583)
            
            //--TRIMMABLE-BOUNDARY-START(85901231879)
            /*Task */ Notify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901231879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PinChanged.InvokeAsync$1($.$$.S.String.Join$10("", this.password));
            }
            //--TRIMMABLE-BOUNDARY-END(85901231879)
            
            //--TRIMMABLE-BOUNDARY-START(103081101063)
            /*bool */ get PassEntered()
            {
                return $.$sl.SL.Enumerable.All($.$$.S.String, this.password, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/**/ p) =>
                {
                    return !$.$$.S.String.IsNullOrEmpty(p) && !$.$$.S.String.IsNullOrWhiteSpace(p);
                }, $JfnVnf ??= {"r":262145,"p":[{"n":"p","p":1310721}],"n":"","d":1885959,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(103081101063)
            
            //--TRIMMABLE-BOUNDARY-START(21476722439)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476722439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex mgy");
                __builder.AddMarkupContent(2, "<div class=\"fill\"></div>\r\n    ");
                __builder.OpenElement(3, "input");
                __builder.AddAttribute$5(4, "maxlength", "1");
                __builder.AddAttribute$5(5, "class", "pd-5 bg-primary-01 bd bdw-2 fsz-20 wx-07 text-center mgr");
                __builder.AddAttribute$5(6, "type", "password");
                __builder.AddAttribute$5(7, "value", $.$mac.MAC.BindConverter.FormatValue$28($.$$.System.Array.$ReadT1.call(this.password, 0), null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 8, "oninput", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$59($.$mac.MAC.EventCallback.Factory, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.password, __value, 0);
                    return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.NextPass1));
                }, $FXHmrf ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":1885959,"h":0,"f":17825794}), $.$$.System.Array.$ReadT1.call(this.password, 0)), $.$$.System.Array.$ReadT1.call(this.password, 0), null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddElementReferenceCapture(9, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/**/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.pass, __value, 0);
                }, $XjVJTi ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":1885959,"h":0,"f":17825794}));
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n    ");
                __builder.OpenElement(11, "input");
                __builder.AddAttribute$5(12, "maxlength", "1");
                __builder.AddAttribute$5(13, "class", "pd-5 bg-primary-01 bd bdw-2 fsz-20 wx-07 text-center mgr");
                __builder.AddAttribute$5(14, "type", "password");
                __builder.AddAttribute$5(15, "value", $.$mac.MAC.BindConverter.FormatValue$28($.$$.System.Array.$ReadT1.call(this.password, 1), null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 16, "oninput", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$59($.$mac.MAC.EventCallback.Factory, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.password, __value, 1);
                    return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.NextPass2));
                }, $uIThdc ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":1885959,"h":0,"f":17825794}), $.$$.System.Array.$ReadT1.call(this.password, 1)), $.$$.System.Array.$ReadT1.call(this.password, 1), null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddElementReferenceCapture(17, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/**/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.pass, __value, 1);
                }, $TMOFqi ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":1885959,"h":0,"f":17825794}));
                __builder.CloseElement();
                __builder.AddMarkupContent(18, "\r\n    ");
                __builder.OpenElement(19, "input");
                __builder.AddAttribute$5(20, "maxlength", "1");
                __builder.AddAttribute$5(21, "class", "pd-5 bg-primary-01 bd bdw-2 fsz-20 wx-07 text-center mgr");
                __builder.AddAttribute$5(22, "type", "password");
                __builder.AddAttribute$5(23, "value", $.$mac.MAC.BindConverter.FormatValue$28($.$$.System.Array.$ReadT1.call(this.password, 2), null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 24, "oninput", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$59($.$mac.MAC.EventCallback.Factory, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.password, __value, 2);
                    return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.NextPass3));
                }, $tMABrc ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":1885959,"h":0,"f":17825794}), $.$$.System.Array.$ReadT1.call(this.password, 2)), $.$$.System.Array.$ReadT1.call(this.password, 2), null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddElementReferenceCapture(25, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/**/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.pass, __value, 2);
                }, $EEbypk ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":1885959,"h":0,"f":17825794}));
                __builder.CloseElement();
                __builder.AddMarkupContent(26, "\r\n    ");
                __builder.OpenElement(27, "input");
                __builder.AddAttribute$5(28, "maxlength", "1");
                __builder.AddAttribute$5(29, "class", "pd-5 bg-primary-01 bd bdw-2 fsz-20 wx-07 text-center");
                __builder.AddAttribute$5(30, "type", "password");
                __builder.AddAttribute$5(31, "value", $.$mac.MAC.BindConverter.FormatValue$28($.$$.System.Array.$ReadT1.call(this.password, 3), null));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 32, "oninput", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$59($.$mac.MAC.EventCallback.Factory, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.password, __value, 3);
                    return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.NextPass4));
                }, $LeYYVa ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":1885959,"h":0,"f":17825794}), $.$$.System.Array.$ReadT1.call(this.password, 3)), $.$$.System.Array.$ReadT1.call(this.password, 3), null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddElementReferenceCapture(33, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                {
                    $.$$.System.Array.$WriteT1.call(this.pass, __value, 3);
                }, $lRsMui ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":1885959,"h":0,"f":17825794}));
                __builder.CloseElement();
                __builder.AddMarkupContent(34, "\r\n    <div class=\"fill\"></div>");
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21476722439)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181755143)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181755143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181755143)
            
            //--TRIMMABLE-BOUNDARY-START(17181755143)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17181755143)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(146030774023)
                this.Size = 4;
                //--TRIMMABLE-BOUNDARY-END(146030774023)
                
                //--TRIMMABLE-BOUNDARY-START(115966002951)
                this.PinChanged = $.$default($.$mac.MAC.EventCallback$$($.$$.S.String));
                //--TRIMMABLE-BOUNDARY-END(115966002951)
                
            }
            static $h = 1885959;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94491166471),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066657031,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1885959,
      "h": 94491166471,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94491166471),
//--TRIMMABLE-BOUNDARY-START(146030774023),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426395399,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735806727,
        "f": 83886081
      },
      "n": "Size",
      "d": 1885959,
      "h": 146030774023,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030774023),
//--TRIMMABLE-BOUNDARY-START(111671035655),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246526215,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555937543,
        "f": 83886081
      },
      "n": "Pin",
      "d": 1885959,
      "h": 111671035655,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111671035655),
//--TRIMMABLE-BOUNDARY-START(115966002951),
    {
      "p": $.$mac.MAC.EventCallback$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836460807,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145872135,
        "f": 83886081
      },
      "n": "PinChanged",
      "d": 1885959,
      "h": 115966002951,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115966002951),
//--TRIMMABLE-BOUNDARY-START(103081101063),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656591623,
        "f": 50331650
      },
      "n": "PassEntered",
      "d": 1885959,
      "h": 103081101063,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(103081101063)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150325741319),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1885959,
      "h": 150325741319,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325741319),
//--TRIMMABLE-BOUNDARY-START(90196199175),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1885959,
      "h": 90196199175,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(90196199175),
//--TRIMMABLE-BOUNDARY-START(68721362695),
    {
      "r": 178454529,
      "n": "NextPass1",
      "d": 1885959,
      "h": 68721362695,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68721362695),
//--TRIMMABLE-BOUNDARY-START(73016329991),
    {
      "r": 178454529,
      "n": "NextPass2",
      "d": 1885959,
      "h": 73016329991,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73016329991),
//--TRIMMABLE-BOUNDARY-START(77311297287),
    {
      "r": 178454529,
      "n": "NextPass3",
      "d": 1885959,
      "h": 77311297287,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(77311297287),
//--TRIMMABLE-BOUNDARY-START(81606264583),
    {
      "r": 178454529,
      "n": "NextPass4",
      "d": 1885959,
      "h": 81606264583,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(81606264583),
//--TRIMMABLE-BOUNDARY-START(85901231879),
    {
      "r": 178454529,
      "n": "Notify",
      "d": 1885959,
      "h": 85901231879,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901231879),
//--TRIMMABLE-BOUNDARY-START(21476722439),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1885959,
      "h": 21476722439,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476722439)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98786133767),
    {
      "t": $.$typeArray($.$mac.MAC.ElementReference).$h,
      "n": "pass",
      "d": 1885959,
      "h": 98786133767,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98786133767),
//--TRIMMABLE-BOUNDARY-START(107376068359),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "password",
      "d": 1885959,
      "h": 107376068359,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107376068359)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181755143),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1885959,
      "h": 17181755143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181755143)
  ],
  "h": 1885959
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.PinEntry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}PinEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1885959)
        
        

        //--TRIMMABLE-BOUNDARY-START(2017031)
        $asm.$cls(`$SeJP.LCWCS$1.WalletDenominate`, ($self) => class WalletDenominate extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(107376199431)
            /*string */ get OptimizedComponentName()
            {
                return "walletdenominate";
            }
            //--TRIMMABLE-BOUNDARY-END(107376199431)
            
            //--TRIMMABLE-BOUNDARY-START(146030905095)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030905095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "EnforceWalletLimit":
                    this.EnforceWalletLimit = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "Denomination":
                    this.Denomination = $.$cast(parameter.Value, $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double));
                    return true;
                    case "DenominationChanged":
                    this.DenominationChanged = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double)));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(146030905095)
            
            //--TRIMMABLE-BOUNDARY-START(42951689991)
            /*bool*/ EnforceWalletLimit = false;
            //--TRIMMABLE-BOUNDARY-END(42951689991)
            
            //--TRIMMABLE-BOUNDARY-START(154620839687)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(154620839687)
            
            //--TRIMMABLE-BOUNDARY-START(30066788103)
            /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ Denomination = null;
            //--TRIMMABLE-BOUNDARY-END(30066788103)
            
            //--TRIMMABLE-BOUNDARY-START(34361755399)
            /*EventCallback<Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>>*/ DenominationChanged;
            //--TRIMMABLE-BOUNDARY-END(34361755399)
            
            //--TRIMMABLE-BOUNDARY-START(103081232135)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081232135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Denomination === null)
                {
                    this.Denomination = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double))().$ctor$1();
                    this.DenominationChanged.InvokeAsync$1(this.Denomination);
                }
                else if (this.EnforceWalletLimit)
                {
                    let $en2 = $.$sl.SL.Enumerable.ToList($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), this.Denomination).GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let den = $en2.Current;
                        {
                            /*var*/ let coins = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.SelectMany$2($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.Where($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.SL$IGrouping$$$$Key === den.Key.Item1.LCFC$INamed$Name;
                            }, $mCxvUe ??= {"r":262145,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken)))().$ctor(this,  (/**/ w) =>
                            {
                                return w;
                            }, $iMzUXc ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,"p":[{"n":"w","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                            {
                                return c.LCFCW$IWalletToken$CoinIdentifier.Equals$1($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(den.Key.Item1, den.Key.Item2));
                            }, $usEAcb ??= {"r":262145,"p":[{"n":"c","p":1357005}],"n":"","d":2017031,"h":0,"f":17825794}));
                            /*var*/ let maxCount = $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletToken, coins);
                            if (den.Value > maxCount)
                            {
                                this.Denomination.set_Item(den.Key, maxCount);
                            }
                        }
                    }
                    this.DenominationChanged.InvokeAsync$1(this.Denomination);
                }
                let $en3 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let issuer = $en3.SCG$IEnumerator$$$Current;
                    {
                        let $en4 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let coin = $en4.SCG$IEnumerator$$$Current;
                            {
                                if (!this.Denomination.ContainsKey(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin))))
                                {
                                    this.Denomination.set_Item(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), 0);
                                }
                            }
                        }
                    }
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(103081232135)
            
            //--TRIMMABLE-BOUNDARY-START(94491297543)
            /*double */ GetEnteredAmount(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                /*var*/ let count;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491297543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Denomination.TryGetValue(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(token)), $.$ref(() => count, ($v) => count = $v, $.$$.S.Double)))
                {
                    return count * token.Amount;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(94491297543)
            
            //--TRIMMABLE-BOUNDARY-START(98786264839)
            /*double */ GetMaxAmount(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786264839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.SelectMany$2($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.Where($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                {
                    return t.SL$IGrouping$$$$Key === issuer.LCFC$INamed$Name;
                }, $gPftWc ??= {"r":262145,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken)))().$ctor(this,  (/**/ w) =>
                {
                    return w;
                }, $VKQyGd ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,"p":[{"n":"w","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$OJJQ.LCFCW.CoinTokenExtension.GetAmount(a, issuer);
                }, $HxQvrc ??= {"r":1179649,"p":[{"n":"a","p":1357005}],"n":"","d":2017031,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(98786264839)
            
            //--TRIMMABLE-BOUNDARY-START(90196330247)
            /*int */ GetCount(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin)
            {
                /*var*/ let currentCount;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196330247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Denomination.TryGetValue(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), $.$ref(() => currentCount, ($v) => currentCount = $v, $.$$.S.Double));
                return $.$cast(currentCount, $.$$.S.Int32);
            }
            //--TRIMMABLE-BOUNDARY-END(90196330247)
            
            //--TRIMMABLE-BOUNDARY-START(150325872391)
            /*Task *//*async*/  Up(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    /*var*/ let dcurrentCount;
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325872391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let coins = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.SelectMany$2($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.Where($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.SL$IGrouping$$$$Key === issuer.LCFC$INamed$Name;
                    }, $CYKNNf ??= {"r":262145,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken)))().$ctor(this,  (/*w*/ w) =>
                    {
                        return w;
                    }, $YPmzTj ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,"p":[{"n":"w","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.LCFCW$IWalletToken$CoinIdentifier.Equals$1($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(coin)));
                    }, $TFCioc ??= {"r":262145,"p":[{"n":"c","p":1357005}],"n":"","d":2017031,"h":0,"f":17825794}));
                    /*var*/ let maxCount = $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletToken, coins);
                    /*var*/ let currentCount = 0;
                    this.Denomination.TryGetValue(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), $.$ref(() => dcurrentCount, ($v) => dcurrentCount = $v, $.$$.S.Double));
                    currentCount = $.$cast(dcurrentCount, $.$$.S.Int32);
                    if (!this.EnforceWalletLimit || currentCount < maxCount)
                    {
                        currentCount++;
                        this.Denomination.set_Item(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), currentCount);
                    }
                    else 
                    {
                        _ = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Toast(maxCount === 0 ? `You don't have ${$.$strNN(coin.Name)}` : `You only have ${$.$strNN(maxCount)}pcs of ${$.$strNN(coin.Name)}`, null);
                    }
                    ($t8 = this.DenominationChanged.InvokeAsync$1(this.Denomination), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150325872391)
            
            //--TRIMMABLE-BOUNDARY-START(38656722695)
            /*Task *//*async*/  Down(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    /*var*/ let dcurrentCount;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656722695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let coins = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.SelectMany$2($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.Where($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.SL$IGrouping$$$$Key === issuer.LCFC$INamed$Name;
                    }, $EgxwJd ??= {"r":262145,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken)))().$ctor(this,  (/**/ w) =>
                    {
                        return w;
                    }, $HDqOVf ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,"p":[{"n":"w","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.LCFCW$IWalletToken$CoinIdentifier.Equals$1($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(coin)));
                    }, $YeAqae ??= {"r":262145,"p":[{"n":"c","p":1357005}],"n":"","d":2017031,"h":0,"f":17825794}));
                    /*var*/ let maxCount = $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletToken, coins);
                    /*var*/ let currentCount = 0;
                    /*var*/ let key = $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(coin));
                    this.Denomination.TryGetValue(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), $.$ref(() => dcurrentCount, ($v) => dcurrentCount = $v, $.$$.S.Double));
                    currentCount = $.$cast(dcurrentCount, $.$$.S.Int32);
                    if (currentCount > 0)
                    {
                        let $t10, $r10;
                        currentCount--;
                        this.Denomination.set_Item(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), currentCount);
                        ($t10 = this.DenominationChanged.InvokeAsync$1(this.Denomination), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                    else 
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38656722695)
            
            //--TRIMMABLE-BOUNDARY-START(25771820807)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771820807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let denominations = $.$sl.SL.Enumerable.OrderByDescending$1($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.String, this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.String))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.SL$IGrouping$$$$Key;
                }, $wZOEdb ??= {"r":1310721,"p":[{"n":"o","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794}));
                /*double*/ let total = 0;
                let $en11 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                while ($en11.SC$1$IEnumerator$MoveNext())
                {
                    let issuer = $en11.SCG$IEnumerator$$$Current;
                    {
                        let $en12 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                        while ($en12.SC$1$IEnumerator$MoveNext())
                        {
                            let coin = $en12.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let coins = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.SelectMany$2($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.Where($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                                {
                                    return t.SL$IGrouping$$$$Key === issuer.LCFC$INamed$Name;
                                }, $rLRRwj ??= {"r":262145,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken)))().$ctor(this,  (/*w*/ w) =>
                                {
                                    return w;
                                }, $AvVOBa ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,"p":[{"n":"w","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2017031,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                                {
                                    return c.LCFCW$IWalletToken$CoinIdentifier.Equals$1($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(coin)));
                                }, $OkxZpf ??= {"r":262145,"p":[{"n":"c","p":1357005}],"n":"","d":2017031,"h":0,"f":17825794}));
                                /*var*/ let maxCount = $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletToken, coins);
                                if (this.EnforceWalletLimit && maxCount === 0)
                                {
                                    continue;
                                }
                                /*int*/ let countDenomination = this.GetCount(issuer, $.$clone(coin));
                                /*double*/ let mtotal = this.GetEnteredAmount(issuer, $.$clone(coin));
                                __builder.OpenElement(0, "div");
                                __builder.AddAttribute$5(1, "class", "flex pdy-1 bdb");
                                __builder.OpenElement(2, "div");
                                __builder.AddAttribute$5(3, "class", "wx-1 flex mgy-a pos-rel");
                                __builder.OpenComponent$1($.$hDPm.LCFCCI.Icon, 4);
                                __builder.AddComponentParameter(5, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, coin.Icon));
                                __builder.AddComponentParameter(6, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                __builder.AddComponentParameter(7, "Class", "mawx-07 mgy-a mahx-07");
                                __builder.CloseComponent();
                                if (this.EnforceWalletLimit)
                                {
                                    __builder.OpenElement(8, "div");
                                    __builder.AddAttribute$5(9, "class", "pos-abs wx-02 hx-02 bg-success pos-abs r-0 t-0 round flex sd mg-1");
                                    __builder.OpenElement(10, "b");
                                    __builder.AddAttribute$5(11, "class", "mg-a");
                                    __builder.AddContent$3(12, $.$box(maxCount, $.$$.S.Int32));
                                    __builder.CloseElement();
                                    __builder.CloseElement();
                                }
                                __builder.CloseElement();
                                __builder.AddMarkupContent(13, "\r\n            ");
                                __builder.OpenElement(14, "b");
                                __builder.AddAttribute$5(15, "class", "mgy-a mgl fill");
                                __builder.AddContent$4(16, coin.Name);
                                __builder.AddContent$4(17, " x ");
                                __builder.AddContent$3(18, $.$box(countDenomination, $.$$.S.Int32));
                                __builder.AddContent$4(19, " pcs");
                                __builder.CloseElement();
                                __builder.AddMarkupContent(20, "\r\n            ");
                                __builder.OpenElement(21, "h3");
                                __builder.AddAttribute$5(22, "class", "mgy-a");
                                __builder.AddContent$4(23, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                __builder.AddContent$4(24, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(mtotal, "#,##0", false));
                                __builder.CloseElement();
                                __builder.AddMarkupContent(25, "\r\n            ");
                                __builder.OpenElement(26, "div");
                                __builder.AddAttribute$5(27, "class", "flex mgl mgy-a");
                                __builder.OpenElement(28, "button");
                                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 29, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Down(issuer, $.$clone(coin));
                                }, $tumydf ??= {"r":178454529,"n":"","d":2017031,"h":0,"f":17825794})));
                                __builder.AddAttribute$5(30, "class", "mdi mdi-minus hx-03 wx-03 bg-primary-01 flex mgc-a");
                                __builder.CloseElement();
                                __builder.AddMarkupContent(31, "\r\n                ");
                                __builder.OpenElement(32, "button");
                                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 33, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Up(issuer, $.$clone(coin));
                                }, $TETRYd ??= {"r":178454529,"n":"","d":2017031,"h":0,"f":17825794})));
                                __builder.AddAttribute$5(34, "class", "mdi mdi-plus hx-03 wx-03 bg-primary-01 flex mgc-a");
                                __builder.CloseElement();
                                __builder.CloseElement();
                                __builder.CloseElement();
                                total += mtotal;
                            }
                        }
                        __builder.OpenElement(35, "div");
                        __builder.AddAttribute$5(36, "class", "flex pdy-1 bdb");
                        __builder.AddMarkupContent(37, "<b class=\"mgy-a mgl fill\">Total</b>\r\n        ");
                        __builder.OpenElement(38, "h1");
                        __builder.AddAttribute$5(39, "class", "mgy-a");
                        __builder.AddContent$4(40, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                        __builder.AddContent$4(41, $.$$.S.Double.ToString$3.call(total, "#,##0"));
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771820807)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21476853511)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476853511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476853511)
            
            //--TRIMMABLE-BOUNDARY-START(21476853511)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476853511)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42951689991)
                this.EnforceWalletLimit = true;
                //--TRIMMABLE-BOUNDARY-END(42951689991)
                
                //--TRIMMABLE-BOUNDARY-START(154620839687)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(154620839687)
                
                //--TRIMMABLE-BOUNDARY-START(34361755399)
                this.DenominationChanged = $.$default($.$mac.MAC.EventCallback$$($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double)));
                //--TRIMMABLE-BOUNDARY-END(34361755399)
                
            }
            static $h = 2017031;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107376199431),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311428359,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2017031,
      "h": 107376199431,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107376199431),
//--TRIMMABLE-BOUNDARY-START(42951689991),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721493767,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133146003207,
        "f": 83886081
      },
      "n": "EnforceWalletLimit",
      "d": 2017031,
      "h": 42951689991,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951689991),
//--TRIMMABLE-BOUNDARY-START(154620839687),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901362951,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735937799,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 2017031,
      "h": 154620839687,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620839687),
//--TRIMMABLE-BOUNDARY-START(30066788103),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541624583,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115966134023,
        "f": 83886081
      },
      "n": "Denomination",
      "d": 2017031,
      "h": 30066788103,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066788103),
//--TRIMMABLE-BOUNDARY-START(34361755399),
    {
      "p": $.$mac.MAC.EventCallback$$($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131559175,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124556068615,
        "f": 83886081
      },
      "n": "DenominationChanged",
      "d": 2017031,
      "h": 34361755399,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361755399)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146030905095),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2017031,
      "h": 146030905095,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146030905095),
//--TRIMMABLE-BOUNDARY-START(103081232135),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 2017031,
      "h": 103081232135,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103081232135),
//--TRIMMABLE-BOUNDARY-START(94491297543),
    {
      "r": 1179649,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "GetEnteredAmount",
      "d": 2017031,
      "h": 94491297543,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94491297543),
//--TRIMMABLE-BOUNDARY-START(98786264839),
    {
      "r": 1179649,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "GetMaxAmount",
      "d": 2017031,
      "h": 98786264839,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98786264839),
//--TRIMMABLE-BOUNDARY-START(90196330247),
    {
      "r": 655361,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "coin",
          "p": 3257549
        }
      ],
      "n": "GetCount",
      "d": 2017031,
      "h": 90196330247,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90196330247),
//--TRIMMABLE-BOUNDARY-START(150325872391),
    {
      "r": 178454529,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "coin",
          "p": 3257549
        }
      ],
      "n": "Up",
      "d": 2017031,
      "h": 150325872391,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(150325872391),
//--TRIMMABLE-BOUNDARY-START(38656722695),
    {
      "r": 178454529,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "coin",
          "p": 3257549
        }
      ],
      "n": "Down",
      "d": 2017031,
      "h": 38656722695,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38656722695),
//--TRIMMABLE-BOUNDARY-START(25771820807),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2017031,
      "h": 25771820807,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25771820807)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476853511),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2017031,
      "h": 21476853511,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476853511)
  ],
  "h": 2017031
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletDenominate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletDenominate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2017031)
        
        

        //--TRIMMABLE-BOUNDARY-START(1951495)
        $asm.$cls(`$SeJP.LCWCS$1.WalletBuy`, ($self) => class WalletBuy extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(163210708743)
            /*string */ get OptimizedComponentName()
            {
                return "walletbuy";
            }
            //--TRIMMABLE-BOUNDARY-END(163210708743)
            
            //--TRIMMABLE-BOUNDARY-START(261994956551)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994956551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Issuer":
                    this.Issuer = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletIssuer);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(261994956551)
            
            //--TRIMMABLE-BOUNDARY-START(137440904967)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440904967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$SeJP.LCWCS.WalletService, serviceProvider);
                this.Issuers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer), serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Payment = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIPaymentProcessorProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(137440904967)
            
            //--TRIMMABLE-BOUNDARY-START(188980512519)
            /*WalletService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(188980512519)
            
            //--TRIMMABLE-BOUNDARY-START(146030839559)
            /*IEnumerable<IWalletIssuer>*/ Issuers = null;
            //--TRIMMABLE-BOUNDARY-END(146030839559)
            
            //--TRIMMABLE-BOUNDARY-START(266289923847)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(266289923847)
            
            //--TRIMMABLE-BOUNDARY-START(184685545223)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(184685545223)
            
            //--TRIMMABLE-BOUNDARY-START(167505676039)
            /*IUIPaymentProcessorProvider*/ Payment = null;
            //--TRIMMABLE-BOUNDARY-END(167505676039)
            
            //--TRIMMABLE-BOUNDARY-START(141735872263)
            /*IWalletIssuer?*/ Issuer = null;
            //--TRIMMABLE-BOUNDARY-END(141735872263)
            
            //--TRIMMABLE-BOUNDARY-START(158915741447)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(158915741447)
            
            //--TRIMMABLE-BOUNDARY-START(154620774151)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154620774151)
            
            //--TRIMMABLE-BOUNDARY-START(171800643335)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(171800643335)
            
            //--TRIMMABLE-BOUNDARY-START(171800643335)
            //--TRIMMABLE-BOUNDARY-START(47246591751)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246591751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(47246591751)
            
            //--TRIMMABLE-BOUNDARY-START(180390577927)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390577927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(180390577927)
            
            //--TRIMMABLE-BOUNDARY-END(171800643335)
            
            //--TRIMMABLE-BOUNDARY-START(150325806855)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325806855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(150325806855)
            
            //--TRIMMABLE-BOUNDARY-START(55836526343)
            /*Task */ Buy(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836526343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.FundAsync(null, issuer, $.$clone(token));
            }
            //--TRIMMABLE-BOUNDARY-END(55836526343)
            
            //--TRIMMABLE-BOUNDARY-START(51541559047)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541559047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(4, "<h2 class=\"mgt-0 mgb\">Please Select a Coin to Buy</h2>\r\n    ");
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "grid gap-1 colm-15");
                    let $en2 = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.Boolean))().$ctor(this,  (/**/ i) =>
                    {
                        return ((i.LCFCW$IWalletIssuer$Features & (1/*WalletFeatures.Purchasable*/)) == (1/*WalletFeatures.Purchasable*/));
                    }, $szyIha ??= {"r":262145,"p":[{"n":"i","p":636109}],"n":"","d":1951495,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let issuer = $en2.SCG$IEnumerator$$$Current;
                        {
                            let $en3 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let coin = $en3.SCG$IEnumerator$$$Current;
                                {
                                    __builder2.OpenElement(7, "div");
                                    __builder2.AddAttribute$5(8, "class", "bg-card pd corner shadow clip");
                                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 9, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                    {
                                        return this.Buy(issuer, $.$clone(coin));
                                    }, $psNFig ??= {"r":178454529,"n":"","d":1951495,"h":0,"f":17825794})));
                                    __builder2.OpenElement(10, "div");
                                    __builder2.AddAttribute$5(11, "class", "hx-1 clip flex");
                                    __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 12);
                                    __builder2.AddComponentParameter(13, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, coin.Icon));
                                    __builder2.AddComponentParameter(14, "IconSize", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                    __builder2.AddComponentParameter(15, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                    __builder2.CloseComponent();
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(16, "\r\n                    ");
                                    __builder2.OpenElement(17, "h4");
                                    __builder2.AddAttribute$5(18, "class", "mg-0");
                                    __builder2.AddContent$4(19, coin.Name);
                                    __builder2.AddContent$4(20, " (");
                                    __builder2.AddContent$4(21, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                    __builder2.AddContent$4(22, ")");
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(23, "\r\n                    ");
                                    __builder2.OpenElement(24, "p");
                                    __builder2.AddAttribute$5(25, "class", "mgy-2 fsz-12 nowrap-3");
                                    __builder2.AddContent$4(26, coin.Description ?? issuer.LCFC$IDescribable$Description);
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(27, "\r\n                    ");
                                    __builder2.OpenElement(28, "small");
                                    __builder2.AddAttribute$5(29, "class", "fsz-11");
                                    __builder2.AddContent$4(30, "Issuer: ");
                                    __builder2.AddContent$4(31, issuer.LCFC$INamed$Name);
                                    __builder2.AddContent$4(32, ", Exchange: 1:");
                                    __builder2.AddContent$3(33, $.$box(issuer.LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$Convert((() =>
                                    {
                                        //new $.$OJJQ.LCFCW.WalletToken()
                                        const $t4 = $.$OJJQ.LCFCW.WalletToken;
                                        const $i4 = new $t4();
                                        $i4.$ctor$2();
                                        $i4.Amount = 1;
                                        return $i4;
                                    })(), null).Value, $.$$.S.Double));
                                    __builder2.CloseElement();
                                    __builder2.CloseElement();
                                }
                            }
                        }
                    }
                    __builder2.CloseElement();
                }), $WmPgMj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1951495,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(51541559047)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(38656657159)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656657159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656657159)
            
            //--TRIMMABLE-BOUNDARY-START(38656657159)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(38656657159)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(188980512519)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(188980512519)
                
                //--TRIMMABLE-BOUNDARY-START(146030839559)
                this.Issuers = null;
                //--TRIMMABLE-BOUNDARY-END(146030839559)
                
                //--TRIMMABLE-BOUNDARY-START(266289923847)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(266289923847)
                
                //--TRIMMABLE-BOUNDARY-START(184685545223)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(184685545223)
                
                //--TRIMMABLE-BOUNDARY-START(167505676039)
                this.Payment = null;
                //--TRIMMABLE-BOUNDARY-END(167505676039)
                
                //--TRIMMABLE-BOUNDARY-START(158915741447)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(158915741447)
                
            }
            static $h = 1951495;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163210708743),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786199303,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1951495,
      "h": 163210708743,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163210708743),
//--TRIMMABLE-BOUNDARY-START(188980512519),
    {
      "p": 1558279,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556003079,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249110054663,
        "f": 83886081
      },
      "n": "Service",
      "d": 1951495,
      "h": 188980512519,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980512519),
//--TRIMMABLE-BOUNDARY-START(146030839559),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016395527,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206160381703,
        "f": 83886081
      },
      "n": "Issuers",
      "d": 1951495,
      "h": 146030839559,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030839559),
//--TRIMMABLE-BOUNDARY-START(266289923847),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145937671,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699989255,
        "f": 83886081
      },
      "n": "UI",
      "d": 1951495,
      "h": 266289923847,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266289923847),
//--TRIMMABLE-BOUNDARY-START(184685545223),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966068487,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240520120071,
        "f": 83886081
      },
      "n": "Server",
      "d": 1951495,
      "h": 184685545223,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685545223),
//--TRIMMABLE-BOUNDARY-START(167505676039),
    {
      "p": 65689258,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376133895,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930185479,
        "f": 83886081
      },
      "n": "Payment",
      "d": 1951495,
      "h": 167505676039,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167505676039),
//--TRIMMABLE-BOUNDARY-START(141735872263),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426460935,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197570447111,
        "f": 83886081
      },
      "n": "Issuer",
      "d": 1951495,
      "h": 141735872263,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141735872263),
//--TRIMMABLE-BOUNDARY-START(158915741447),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196264711,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340250887,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1951495,
      "h": 158915741447,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158915741447),
//--TRIMMABLE-BOUNDARY-START(154620774151),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606330119,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214750316295,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1951495,
      "h": 154620774151,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620774151)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(261994956551),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1951495,
      "h": 261994956551,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(261994956551),
//--TRIMMABLE-BOUNDARY-START(137440904967),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1951495,
      "h": 137440904967,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137440904967),
//--TRIMMABLE-BOUNDARY-START(150325806855),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1951495,
      "h": 150325806855,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150325806855),
//--TRIMMABLE-BOUNDARY-START(55836526343),
    {
      "r": 178454529,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "Buy",
      "d": 1951495,
      "h": 55836526343,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836526343),
//--TRIMMABLE-BOUNDARY-START(51541559047),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1951495,
      "h": 51541559047,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51541559047)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656657159),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1951495,
      "h": 38656657159,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656657159)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(171800643335),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1951495,
        "h": 47246591751,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1951495,
        "h": 180390577927,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1951495,
      "h": 171800643335,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(171800643335)
  ],
  "h": 1951495
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletBuy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletBuy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1951495)
        
        

        //--TRIMMABLE-BOUNDARY-START(2606855)
        $asm.$cls(`$SeJP.LCWCS$1.WalletSwap`, ($self) => class WalletSwap extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(274880513799)
            /*string */ get OptimizedComponentName()
            {
                return "walletswap";
            }
            //--TRIMMABLE-BOUNDARY-END(274880513799)
            
            //--TRIMMABLE-BOUNDARY-START(399434565383)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399434565383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Wallet1":
                    this.Wallet1 = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "Wallet2":
                    this.Wallet2 = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "Header":
                    this.Header = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "OnFinish":
                    this.OnFinish = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$SeJP.LCWCS$1.WalletSwapRequest));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(399434565383)
            
            //--TRIMMABLE-BOUNDARY-START(236225808135)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225808135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(236225808135)
            
            //--TRIMMABLE-BOUNDARY-START(253405677319)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(253405677319)
            
            //--TRIMMABLE-BOUNDARY-START(403729532679)
            /*IWalletSystem*/ Wallet1 = null;
            //--TRIMMABLE-BOUNDARY-END(403729532679)
            
            //--TRIMMABLE-BOUNDARY-START(408024499975)
            /*IWalletSystem*/ Wallet2 = null;
            //--TRIMMABLE-BOUNDARY-END(408024499975)
            
            //--TRIMMABLE-BOUNDARY-START(231930840839)
            /*RenderFragment?*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(231930840839)
            
            //--TRIMMABLE-BOUNDARY-START(266290579207)
            /*EventCallback<WalletSwapRequest>*/ OnFinish;
            //--TRIMMABLE-BOUNDARY-END(266290579207)
            
            //--TRIMMABLE-BOUNDARY-START(360779859719)
            /*IWalletSystem*/ source = null;
            //--TRIMMABLE-BOUNDARY-END(360779859719)
            
            //--TRIMMABLE-BOUNDARY-START(365074827015)
            /*double*/ sourceAmount = 0;
            //--TRIMMABLE-BOUNDARY-END(365074827015)
            
            //--TRIMMABLE-BOUNDARY-START(81606985479)
            /*double*/ destinationAmount = 0;
            //--TRIMMABLE-BOUNDARY-END(81606985479)
            
            //--TRIMMABLE-BOUNDARY-START(279175481095)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(279175481095)
            
            //--TRIMMABLE-BOUNDARY-START(279175481095)
            //--TRIMMABLE-BOUNDARY-START(60132148999)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132148999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(60132148999)
            
            //--TRIMMABLE-BOUNDARY-START(296355350279)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296355350279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(296355350279)
            
            //--TRIMMABLE-BOUNDARY-END(279175481095)
            
            //--TRIMMABLE-BOUNDARY-START(390844630791)
            /*int*/ sourceIssuerIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(390844630791)
            
            //--TRIMMABLE-BOUNDARY-START(377959728903)
            /*int*/ sourceCoinIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(377959728903)
            
            //--TRIMMABLE-BOUNDARY-START(107376789255)
            /*int*/ destinationIssuerIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(107376789255)
            
            //--TRIMMABLE-BOUNDARY-START(94491887367)
            /*int*/ destinationCoinIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(94491887367)
            
            //--TRIMMABLE-BOUNDARY-START(382254696199)
            /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>?*/ sourceDenomination = null;
            //--TRIMMABLE-BOUNDARY-END(382254696199)
            
            //--TRIMMABLE-BOUNDARY-START(98786854663)
            /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>?*/ destinationDenomination = null;
            //--TRIMMABLE-BOUNDARY-END(98786854663)
            
            //--TRIMMABLE-BOUNDARY-START(386549663495)
            /*IWalletIssuer? */ get SourceIssuer()
            {
                return $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$OJJQ.LCFCW.IWalletIssuer, this.source.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers, this.sourceIssuerIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(386549663495)
            
            //--TRIMMABLE-BOUNDARY-START(373664761607)
            /*WalletTokenDescriptor */ get SourceCoin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201866069767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer?*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor>*/ let __ca2__;
                return ((__ca1__ = this.SourceIssuer) !== null ? ((__ca2__ = __ca1__.LCFCW$IWalletIssuer$CoinDescriptors) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$OJJQ.LCFCW.WalletTokenDescriptor, __ca2__, this.sourceCoinIndex) : new $.$OJJQ.LCFCW.WalletTokenDescriptor()) : new $.$OJJQ.LCFCW.WalletTokenDescriptor());
            }
            //--TRIMMABLE-BOUNDARY-END(373664761607)
            
            //--TRIMMABLE-BOUNDARY-START(103081821959)
            /*IWalletIssuer? */ get DestinationIssuer()
            {
                return $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$OJJQ.LCFCW.IWalletIssuer, (this.source === this.Wallet1 ? this.Wallet2 : this.Wallet1).LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers, this.destinationIssuerIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(103081821959)
            
            //--TRIMMABLE-BOUNDARY-START(90196920071)
            /*WalletTokenDescriptor */ get DestinationCoin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556658439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer?*/ let __ca3__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor>*/ let __ca4__;
                return ((__ca3__ = this.DestinationIssuer) !== null ? ((__ca4__ = __ca3__.LCFCW$IWalletIssuer$CoinDescriptors) !== null ? $.$sl.SL.Enumerable.ElementAtOrDefault$1($.$OJJQ.LCFCW.WalletTokenDescriptor, __ca4__, this.destinationCoinIndex) : new $.$OJJQ.LCFCW.WalletTokenDescriptor()) : new $.$OJJQ.LCFCW.WalletTokenDescriptor());
            }
            //--TRIMMABLE-BOUNDARY-END(90196920071)
            
            //--TRIMMABLE-BOUNDARY-START(270585546503)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270585546503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.source = this.Wallet1;
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(270585546503)
            
            //--TRIMMABLE-BOUNDARY-START(261995611911)
            /*void */ NextSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995611911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.sourceCoinIndex++;
                if (this.SourceCoin.Name === null)
                {
                    this.sourceIssuerIndex++;
                    if (this.SourceIssuer === null)
                    {
                        this.sourceIssuerIndex = 0;
                        this.sourceCoinIndex = 0;
                    }
                }
                this.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(261995611911)
            
            //--TRIMMABLE-BOUNDARY-START(257700644615)
            /*void */ NextDestination()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700644615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.destinationCoinIndex++;
                if (this.DestinationCoin.Name === null)
                {
                    this.destinationIssuerIndex++;
                    if (this.DestinationIssuer === null)
                    {
                        this.destinationIssuerIndex = 0;
                        this.destinationCoinIndex = 0;
                    }
                }
                this.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(257700644615)
            
            //--TRIMMABLE-BOUNDARY-START(77312018183)
            /*Task *//*async*/  DenominateSourceWallet()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77312018183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let sourceWallet = this.source;
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletDenominate, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `${$.$strNN(sourceWallet.LCFCW$IWalletSystem$Name)} Denominations`, false), null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                    {
                        b.AddAttribute$4(i++, "Wallet", sourceWallet);
                        b.AddAttribute$2(i++, "EnforceWalletLimit", true);
                        b.AddAttribute$4(i++, "Denomination", this.sourceDenomination);
                        b.AddAttribute$7($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), i++, "DenominationChanged", $.$mac.MAC.EventCallback.Factory.Create$8($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), this, new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double)))().$ctor(this,  (/*e*/ e) =>
                        {
                            this.sourceDenomination = e;
                            /*var*/ let total = $.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), e, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Key.Item2.Amount * e.Value;
                            }, $OrAcxk ??= {"r":1179649,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":2606855,"h":0,"f":17825794}));
                            this.sourceAmount = total;
                            this.destinationAmount = total;
                        }, $xXiVuk ??= {"r":65537,"p":[{"n":"e","p":$.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":2606855,"h":0,"f":17825794})));
                    }, $AWfrre ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":2606855,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.BodyAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t4 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i4 = new $t4();
                            $i4.$ctor$1();
                            $i4.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "pd bg-card");
                            return $i4;
                        })();
                        $i3.ViewFeatures = 1/*ViewFeatures.OKToolBar*/ | 2/*ViewFeatures.CancelToolBar*/;
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.Refresh$1(false, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77312018183)
            
            //--TRIMMABLE-BOUNDARY-START(73017050887)
            /*Task *//*async*/  DenominatDestinationWallet()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73017050887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let destinationWallet = this.source === this.Wallet1 ? this.Wallet2 : this.Wallet1;
                    ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletDenominate, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `${$.$strNN(destinationWallet.LCFCW$IWalletSystem$Name)} Denominations`, false), null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                    {
                        b.AddAttribute$4(i++, "Wallet", destinationWallet);
                        b.AddAttribute$2(i++, "EnforceWalletLimit", false);
                        b.AddAttribute$4(i++, "Denomination", this.destinationDenomination);
                        b.AddAttribute$7($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), i++, "DenominationChanged", $.$mac.MAC.EventCallback.Factory.Create$8($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), this, new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double)))().$ctor(this,  (/**/ e) =>
                        {
                            this.destinationDenomination = e;
                            /*var*/ let total = $.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), e, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Key.Item2.Amount * e.Value;
                            }, $uayJzb ??= {"r":1179649,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":2606855,"h":0,"f":17825794}));
                            this.sourceAmount = total;
                            this.destinationAmount = total;
                        }, $Fybvkf ??= {"r":65537,"p":[{"n":"e","p":$.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":2606855,"h":0,"f":17825794})));
                    }, $OhUxWk ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":2606855,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t6 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i6 = new $t6();
                        $i6.$ctor$2();
                        $i6.BodyAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t7 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i7 = new $t7();
                            $i7.$ctor$1();
                            $i7.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "pd bg-card");
                            return $i7;
                        })();
                        $i6.ViewFeatures = 1/*ViewFeatures.OKToolBar*/ | 2/*ViewFeatures.CancelToolBar*/;
                        return $i6;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.Refresh$1(true, false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73017050887)
            
            //--TRIMMABLE-BOUNDARY-START(369369794311)
            /*double */ get SourceBalance()
            {
                return this.source === this.Wallet1 ? this.Wallet1.LCFCW$IWalletSystem$GetTotal() : this.Wallet2.LCFCW$IWalletSystem$GetTotal();
            }
            //--TRIMMABLE-BOUNDARY-END(369369794311)
            
            //--TRIMMABLE-BOUNDARY-START(85901952775)
            /*double */ get DestinationBalance()
            {
                return this.source === this.Wallet1 ? this.Wallet2.LCFCW$IWalletSystem$GetTotal() : this.Wallet1.LCFCW$IWalletSystem$GetTotal();
            }
            //--TRIMMABLE-BOUNDARY-END(85901952775)
            
            //--TRIMMABLE-BOUNDARY-START(249110710023)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(249110710023)
            
            //--TRIMMABLE-BOUNDARY-START(244815742727)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244815742727)
            
            //--TRIMMABLE-BOUNDARY-START(395139598087)
            /*void */ ToggleSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395139598087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.source = this.source === this.Wallet1 ? this.Wallet2 : this.Wallet1;
                this.sourceDenomination = null;
                this.destinationDenomination = null;
                this.sourceIssuerIndex = 0;
                this.sourceCoinIndex = 0;
                this.destinationIssuerIndex = 0;
                this.destinationCoinIndex = 0;
                this.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(395139598087)
            
            //--TRIMMABLE-BOUNDARY-START(287765415687)
            /*void */ Refresh$1(/*bool*/ denominateSource, /*bool*/ denominateDestination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287765415687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let destination = this.source === this.Wallet1 ? this.Wallet2 : this.Wallet1;
                /*var*/ let money = this.SourceIssuer.LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$Convert((() =>
                {
                    //new $.$OJJQ.LCFCW.WalletToken()
                    const $t8 = $.$OJJQ.LCFCW.WalletToken;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Amount = this.sourceAmount;
                    return $i8;
                })(), null);
                this.destinationAmount = $.$OJJQ.LCFCW.WalletToken.op_Implicit(this.DestinationIssuer.LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$Convert($.$clone(money), null));
                let den;
                if (denominateSource && $.$is(this.source, $.$OJJQ.LCFCW.IDenominatedWalletSystem, { set $v($v){ den = $v; } }))
                {
                    this.sourceDenomination = den.LCFCW$IDenominatedWalletSystem$Denominate(this.sourceAmount);
                }
                let den2;
                if (denominateDestination && $.$is(destination, $.$OJJQ.LCFCW.IDenominatedWalletSystem, { set $v($v){ den2 = $v; } }))
                {
                    this.destinationDenomination = den2.LCFCW$IDenominatedWalletSystem$Denominate(this.destinationAmount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287765415687)
            
            //--TRIMMABLE-BOUNDARY-START(283470448391)
            /*void */ Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283470448391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Refresh$1(true, true);
            }
            //--TRIMMABLE-BOUNDARY-END(283470448391)
            
            //--TRIMMABLE-BOUNDARY-START(8592541447)
            /*void */ _25_Percent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592541447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.sourceAmount = 0.25 * this.SourceBalance;
                this.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(8592541447)
            
            //--TRIMMABLE-BOUNDARY-START(12887508743)
            /*void */ _50_Percent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887508743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.sourceAmount = 0.5 * this.SourceBalance;
                this.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(12887508743)
            
            //--TRIMMABLE-BOUNDARY-START(17182476039)
            /*void */ _75_Percent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182476039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.sourceAmount = 0.75 * this.SourceBalance;
                this.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(17182476039)
            
            //--TRIMMABLE-BOUNDARY-START(4297574151)
            /*void */ _100_Percent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297574151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.sourceAmount = this.SourceBalance;
                this.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(4297574151)
            
            //--TRIMMABLE-BOUNDARY-START(68722083591)
            /*ValueTask *//*async*/  Confirm()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722083591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t9 = this.OnFinish.InvokeAsync$1((() =>
                    {
                        //new $.$SeJP.LCWCS$1.WalletSwapRequest()
                        const $t10 = $.$SeJP.LCWCS$1.WalletSwapRequest;
                        const $i10 = new $t10();
                        $i10.$ctor$1();
                        $i10.Source = this.source;
                        $i10.Destination = this.source === this.Wallet1 ? this.Wallet2 : this.Wallet1;
                        $i10.SourceAmount = this.sourceAmount;
                        $i10.SourceDenomination = this.sourceDenomination;
                        $i10.DestinationDenomination = this.destinationDenomination;
                        return $i10;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    this.sourceAmount = 0;
                    this.destinationAmount = 0;
                    this.sourceDenomination = null;
                    this.destinationDenomination = null;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68722083591)
            
            //--TRIMMABLE-BOUNDARY-START(240520775431)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520775431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(240520775431)
            
            //--TRIMMABLE-BOUNDARY-START(64427116295)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427116295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, (336/*LoadingFeatures.Default*/ & ~32/*LoadingFeatures.Retry*/) | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(4, "div");
                    __builder2.AddMultipleAttributes(5, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.OwnAttributes(null), "hf stack"))));
                    if (this.Header !== null)
                    {
                        __builder2.AddContent$1(6, this.Header);
                    }
                    else 
                    {
                        __builder2.OpenComponent$1($.$SeJP.LCWCS$1.WalletHeader, 7);
                        __builder2.AddComponentParameter(8, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Wallet1));
                        __builder2.CloseComponent();
                    }
                    __builder2.OpenElement(9, "div");
                    __builder2.AddAttribute$5(10, "class", "pd fill stack");
                    __builder2.OpenElement(11, "h3");
                    __builder2.AddAttribute$5(12, "class", "mgy");
                    __builder2.AddContent$4(13, "Currency Swap (");
                    __builder2.AddContent$4(14, (this.SourceIssuer?.LCFC$IDisplayable$Title ?? null));
                    __builder2.AddContent$4(15, " to ");
                    __builder2.AddContent$4(16, (this.DestinationIssuer?.LCFC$IDisplayable$Title ?? null));
                    __builder2.AddContent$4(17, ")");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(18, "\r\n            ");
                    __builder2.OpenElement(19, "div");
                    __builder2.AddMultipleAttributes(20, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.AttributesFor("swaparea"), "hf stack"))));
                    __builder2.OpenElement(21, "div");
                    __builder2.AddAttribute$5(22, "class", "row pdb");
                    __builder2.OpenElement(23, "div");
                    __builder2.AddAttribute$5(24, "class", "col-5 stack mgr");
                    __builder2.AddMarkupContent(25, "<small>You Pay</small>\r\n                        ");
                    __builder2.OpenElement(26, "input");
                    __builder2.AddAttribute$5(27, "type", "number");
                    __builder2.AddAttribute$5(28, "class", "bd-0 fsz-40 wf bg-primary-01");
                    __builder2.AddAttribute$5(29, "placeholder", "You pay");
                    __builder2.AddAttribute$5(30, "value", $.$mac.MAC.BindConverter.FormatValue$8(this.sourceAmount, $.$$.SG.CultureInfo.InvariantCulture));
                    __builder2.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 31, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$39($.$mac.MAC.EventCallback.Factory, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.Double, new ($.$$.S.Func$$$($.$$.S.Double, $.$$.STT.Task))().$ctor(this,  (/**/ __value) =>
                    {
                        this.sourceAmount = __value;
                        return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate(new $.$$.S.Action().$ctor(this, this.Refresh));
                    }, $rfoYIi ??= {"r":178454529,"p":[{"n":"__value","p":1179649}],"n":"","d":2606855,"h":0,"f":17825794}), this.sourceAmount), this.sourceAmount, $.$$.SG.CultureInfo.InvariantCulture));
                    __builder2.SetUpdatesAttributeName("value");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(32, "\r\n                        ");
                    __builder2.OpenElement(33, "small");
                    __builder2.AddContent$4(34, "Current Balance: ");
                    __builder2.AddContent$4(35, this.SourceIssuer.LCFCW$IWalletIssuer$CurrencyUnit);
                    __builder2.AddContent$4(36, $.$$.S.Double.ToString$3.call(this.SourceBalance, "0,###.##"));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(37, "\r\n                    ");
                    __builder2.OpenElement(38, "div");
                    __builder2.AddAttribute$5(39, "class", "col-a flex");
                    __builder2.OpenElement(40, "div");
                    __builder2.AddAttribute$5(41, "class", "mgy-a");
                    __builder2.OpenElement(42, "div");
                    __builder2.AddAttribute$5(43, "class", "wx-05 hx-05");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 44);
                    __builder2.AddComponentParameter(45, "Class", "fsz-40 mgy-a");
                    __builder2.AddComponentParameter(46, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                    __builder2.AddComponentParameter(47, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                    __builder2.AddComponentParameter(48, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, this.SourceIssuer.LCFC$IDisplayable$Icon));
                    __builder2.AddComponentParameter(49, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.NextSource)));
                    __builder2.SetKey(this.SourceIssuer);
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(50, "\r\n                        ");
                    __builder2.OpenElement(51, "h3");
                    __builder2.AddAttribute$5(52, "class", "mgl mgy-a");
                    __builder2.AddContent$4(53, this.SourceIssuer.LCFC$IDisplayable$Title);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.sourceDenomination !== null)
                    {
                        /*int*/ let i = 1;
                        __builder2.OpenElement(54, "div");
                        __builder2.AddAttribute$5(55, "class", "flex flow");
                        __builder2.OpenElement(56, "button");
                        __builder2.AddAttribute$5(57, "class", "bg-transparent mdi mdi-menu");
                        __builder2.AddAttribute$5(58, "title", "Redenominate");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 59, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.DenominateSourceWallet)));
                        __builder2.CloseElement();
                        let $en11 = this.sourceDenomination.GetEnumerator();
                        while ($en11.MoveNext())
                        {
                            let den = $en11.Current;
                            {
                                if (den.Value > 0)
                                {
                                    __builder2.OpenElement(60, "small");
                                    __builder2.AddAttribute$5(61, "class", `mg-1 corner-2 bg-chart${$.$strNN(i)}-02 pdx-3 pdy-1 fw-bold`);
                                    __builder2.AddContent$4(62, den.Key.Item2.Name);
                                    __builder2.AddContent$4(63, " x ");
                                    __builder2.AddContent$3(64, $.$box(den.Value, $.$$.S.Double));
                                    __builder2.CloseElement();
                                    i++;
                                }
                            }
                        }
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(65, "div");
                    __builder2.AddAttribute$5(66, "class", "row");
                    __builder2.AddMarkupContent(67, "<div class=\"bdt col-10 mgy-a\"></div>\r\n                    ");
                    __builder2.OpenElement(68, "div");
                    __builder2.AddAttribute$5(69, "class", "col-a");
                    __builder2.OpenElement(70, "i");
                    __builder2.AddAttribute$5(71, "class", "mdi mdi-swap-vertical fsz-25 hx-04 wx-04 round bg-primary-01 d-block flex mgc-a");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 72, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleSource)));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(73, "\r\n                ");
                    __builder2.OpenElement(74, "div");
                    __builder2.AddAttribute$5(75, "class", "row pdt");
                    __builder2.OpenElement(76, "div");
                    __builder2.AddAttribute$5(77, "class", "col-5 stack mgr");
                    __builder2.AddMarkupContent(78, "<small>You Get</small>\r\n                        ");
                    __builder2.OpenElement(79, "input");
                    __builder2.AddAttribute$5(80, "type", "number");
                    __builder2.AddAttribute$5(81, "class", "bd-0 fsz-40 wf");
                    __builder2.AddAttribute$5(82, "placeholder", "You get");
                    __builder2.AddAttribute$6(83, "disabled");
                    __builder2.AddAttribute$4(84, "value", $.$box(this.destinationAmount, $.$$.S.Double));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(85, "\r\n                        ");
                    __builder2.OpenElement(86, "small");
                    __builder2.AddContent$4(87, "Current Balance: ");
                    __builder2.AddContent$4(88, this.DestinationIssuer.LCFCW$IWalletIssuer$CurrencyUnit);
                    __builder2.AddContent$4(89, $.$$.S.Double.ToString$3.call(this.DestinationBalance, "0,###.##"));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(90, "\r\n                    ");
                    __builder2.OpenElement(91, "div");
                    __builder2.AddAttribute$5(92, "class", "col-a flex");
                    __builder2.OpenElement(93, "div");
                    __builder2.AddAttribute$5(94, "class", "mgy-a");
                    __builder2.OpenElement(95, "div");
                    __builder2.AddAttribute$5(96, "class", "wx-05 hx-05");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 97);
                    __builder2.AddComponentParameter(98, "Class", "fsz-40 mgy-a");
                    __builder2.AddComponentParameter(99, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                    __builder2.AddComponentParameter(100, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                    __builder2.AddComponentParameter(101, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, this.DestinationIssuer.LCFC$IDisplayable$Icon));
                    __builder2.AddComponentParameter(102, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.NextDestination)));
                    __builder2.SetKey(this.DestinationIssuer);
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(103, "\r\n                        ");
                    __builder2.OpenElement(104, "h3");
                    __builder2.AddAttribute$5(105, "class", "mgl mgy-a");
                    __builder2.AddContent$4(106, this.DestinationIssuer.LCFC$IDisplayable$Title);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.destinationDenomination !== null)
                    {
                        /*int*/ let i = 1;
                        __builder2.OpenElement(107, "div");
                        __builder2.AddAttribute$5(108, "class", "flex flow");
                        __builder2.OpenElement(109, "button");
                        __builder2.AddAttribute$5(110, "class", "bg-transparent mdi mdi-menu");
                        __builder2.AddAttribute$5(111, "title", "Redenominate");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 112, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.DenominatDestinationWallet)));
                        __builder2.CloseElement();
                        let $en12 = this.destinationDenomination.GetEnumerator();
                        while ($en12.MoveNext())
                        {
                            let den = $en12.Current;
                            {
                                if (den.Value > 0)
                                {
                                    __builder2.OpenElement(113, "small");
                                    __builder2.AddAttribute$5(114, "class", `mg-1 corner-2 bg-chart${$.$strNN(i)}-02 pdx-3 pdy-1 fw-bold`);
                                    __builder2.AddContent$4(115, den.Key.Item2.Name);
                                    __builder2.AddContent$4(116, " x ");
                                    __builder2.AddContent$3(117, $.$box(den.Value, $.$$.S.Double));
                                    __builder2.CloseElement();
                                    i++;
                                }
                            }
                        }
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(118, "\r\n            ");
                    __builder2.OpenElement(119, "div");
                    __builder2.AddAttribute$5(120, "class", "flex flex-spacearound mgt-10 mgb-10");
                    __builder2.OpenElement(121, "div");
                    __builder2.AddAttribute$5(122, "class", "pd-2 bg-primary-01 fw-bold bdb bd-primary bdw-2");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 123, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this._25_Percent)));
                    __builder2.AddContent$4(124, "25%");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(125, "\r\n                ");
                    __builder2.OpenElement(126, "div");
                    __builder2.AddAttribute$5(127, "class", "pd-2 bg-primary-01 fw-bold bdb bd-primary bdw-2");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 128, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this._50_Percent)));
                    __builder2.AddContent$4(129, "50%");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(130, "\r\n                ");
                    __builder2.OpenElement(131, "div");
                    __builder2.AddAttribute$5(132, "class", "pd-2 bg-primary-01 fw-bold bdb bd-primary bdw-2");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 133, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this._75_Percent)));
                    __builder2.AddContent$4(134, "75%");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(135, "\r\n                ");
                    __builder2.OpenElement(136, "div");
                    __builder2.AddAttribute$5(137, "class", "pd-2 bg-primary-01 fw-bold bdb bd-primary bdw-2");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 138, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this._100_Percent)));
                    __builder2.AddContent$4(139, "100%");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(140, "\r\n            <div></div>\r\n            ");
                    __builder2.OpenElement(141, "button");
                    __builder2.AddAttribute$5(142, "class", "wf mgt-a bg-primary pd corner fw-bold");
                    __builder2.AddAttribute$2(143, "disabled", this.sourceAmount === 0);
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 144, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Confirm)));
                    __builder2.AddContent$4(145, "CONFIRM");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $AdQrFb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2606855,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(64427116295)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(51542214407)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542214407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51542214407)
            
            //--TRIMMABLE-BOUNDARY-START(51542214407)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(51542214407)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(253405677319)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(253405677319)
                
                //--TRIMMABLE-BOUNDARY-START(403729532679)
                this.Wallet1 = null;
                //--TRIMMABLE-BOUNDARY-END(403729532679)
                
                //--TRIMMABLE-BOUNDARY-START(408024499975)
                this.Wallet2 = null;
                //--TRIMMABLE-BOUNDARY-END(408024499975)
                
                //--TRIMMABLE-BOUNDARY-START(266290579207)
                this.OnFinish = $.$default($.$mac.MAC.EventCallback$$($.$SeJP.LCWCS$1.WalletSwapRequest));
                //--TRIMMABLE-BOUNDARY-END(266290579207)
                
                //--TRIMMABLE-BOUNDARY-START(360779859719)
                this.source = null;
                //--TRIMMABLE-BOUNDARY-END(360779859719)
                
                //--TRIMMABLE-BOUNDARY-START(249110710023)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(249110710023)
                
            }
            static $h = 2606855;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(274880513799),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184686200583,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2606855,
      "h": 274880513799,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(274880513799),
//--TRIMMABLE-BOUNDARY-START(253405677319),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167506331399,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330715088647,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 2606855,
      "h": 253405677319,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253405677319),
//--TRIMMABLE-BOUNDARY-START(403729532679),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219045938951,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347894957831,
        "f": 83886081
      },
      "n": "Wallet1",
      "d": 2606855,
      "h": 403729532679,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403729532679),
//--TRIMMABLE-BOUNDARY-START(408024499975),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227635873543,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356484892423,
        "f": 83886081
      },
      "n": "Wallet2",
      "d": 2606855,
      "h": 408024499975,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(408024499975),
//--TRIMMABLE-BOUNDARY-START(231930840839),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736527623,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304945284871,
        "f": 83886081
      },
      "n": "Header",
      "d": 2606855,
      "h": 231930840839,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231930840839),
//--TRIMMABLE-BOUNDARY-START(266290579207),
    {
      "p": $.$mac.MAC.EventCallback$$($.$SeJP.LCWCS$1.WalletSwapRequest).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176096265991,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339305023239,
        "f": 83886081
      },
      "n": "OnFinish",
      "d": 2606855,
      "h": 266290579207,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266290579207),
//--TRIMMABLE-BOUNDARY-START(386549663495),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210456004359,
        "f": 50331650
      },
      "n": "SourceIssuer",
      "d": 2606855,
      "h": 386549663495,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(386549663495),
//--TRIMMABLE-BOUNDARY-START(373664761607),
    {
      "p": 3257549,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201866069767,
        "f": 50331650
      },
      "n": "SourceCoin",
      "d": 2606855,
      "h": 373664761607,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(373664761607),
//--TRIMMABLE-BOUNDARY-START(103081821959),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146593031,
        "f": 50331650
      },
      "n": "DestinationIssuer",
      "d": 2606855,
      "h": 103081821959,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(103081821959),
//--TRIMMABLE-BOUNDARY-START(90196920071),
    {
      "p": 3257549,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556658439,
        "f": 50331650
      },
      "n": "DestinationCoin",
      "d": 2606855,
      "h": 90196920071,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90196920071),
//--TRIMMABLE-BOUNDARY-START(369369794311),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193276135175,
        "f": 50331650
      },
      "n": "SourceBalance",
      "d": 2606855,
      "h": 369369794311,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(369369794311),
//--TRIMMABLE-BOUNDARY-START(85901952775),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966723847,
        "f": 50331650
      },
      "n": "DestinationBalance",
      "d": 2606855,
      "h": 85901952775,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85901952775),
//--TRIMMABLE-BOUNDARY-START(249110710023),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158916396807,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322125154055,
        "f": 83886081
      },
      "n": "Loading",
      "d": 2606855,
      "h": 249110710023,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249110710023),
//--TRIMMABLE-BOUNDARY-START(244815742727),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326462215,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313535219463,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 2606855,
      "h": 244815742727,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244815742727)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(399434565383),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2606855,
      "h": 399434565383,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(399434565383),
//--TRIMMABLE-BOUNDARY-START(236225808135),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2606855,
      "h": 236225808135,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(236225808135),
//--TRIMMABLE-BOUNDARY-START(270585546503),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 2606855,
      "h": 270585546503,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(270585546503),
//--TRIMMABLE-BOUNDARY-START(261995611911),
    {
      "r": 65537,
      "n": "NextSource",
      "d": 2606855,
      "h": 261995611911,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261995611911),
//--TRIMMABLE-BOUNDARY-START(257700644615),
    {
      "r": 65537,
      "n": "NextDestination",
      "d": 2606855,
      "h": 257700644615,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(257700644615),
//--TRIMMABLE-BOUNDARY-START(77312018183),
    {
      "r": 178454529,
      "n": "DenominateSourceWallet",
      "d": 2606855,
      "h": 77312018183,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(77312018183),
//--TRIMMABLE-BOUNDARY-START(73017050887),
    {
      "r": 178454529,
      "n": "DenominatDestinationWallet",
      "d": 2606855,
      "h": 73017050887,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73017050887),
//--TRIMMABLE-BOUNDARY-START(395139598087),
    {
      "r": 65537,
      "n": "ToggleSource",
      "d": 2606855,
      "h": 395139598087,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(395139598087),
//--TRIMMABLE-BOUNDARY-START(287765415687),
    {
      "r": 65537,
      "p": [
        {
          "n": "denominateSource",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "denominateDestination",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Refresh",
      "o": "@$1",
      "d": 2606855,
      "h": 287765415687,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(287765415687),
//--TRIMMABLE-BOUNDARY-START(283470448391),
    {
      "r": 65537,
      "n": "Refresh",
      "d": 2606855,
      "h": 283470448391,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283470448391),
//--TRIMMABLE-BOUNDARY-START(8592541447),
    {
      "r": 65537,
      "n": "_25_Percent",
      "d": 2606855,
      "h": 8592541447,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8592541447),
//--TRIMMABLE-BOUNDARY-START(12887508743),
    {
      "r": 65537,
      "n": "_50_Percent",
      "d": 2606855,
      "h": 12887508743,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887508743),
//--TRIMMABLE-BOUNDARY-START(17182476039),
    {
      "r": 65537,
      "n": "_75_Percent",
      "d": 2606855,
      "h": 17182476039,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17182476039),
//--TRIMMABLE-BOUNDARY-START(4297574151),
    {
      "r": 65537,
      "n": "_100_Percent",
      "d": 2606855,
      "h": 4297574151,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(4297574151),
//--TRIMMABLE-BOUNDARY-START(68722083591),
    {
      "r": 181338113,
      "n": "Confirm",
      "d": 2606855,
      "h": 68722083591,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68722083591),
//--TRIMMABLE-BOUNDARY-START(240520775431),
    {
      "r": 181338113,
      "n": "Load",
      "d": 2606855,
      "h": 240520775431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240520775431),
//--TRIMMABLE-BOUNDARY-START(64427116295),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2606855,
      "h": 64427116295,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64427116295)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(360779859719),
    {
      "t": 1291469,
      "n": "source",
      "d": 2606855,
      "h": 360779859719,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(360779859719),
//--TRIMMABLE-BOUNDARY-START(365074827015),
    {
      "t": 1179649,
      "n": "sourceAmount",
      "d": 2606855,
      "h": 365074827015,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(365074827015),
//--TRIMMABLE-BOUNDARY-START(81606985479),
    {
      "t": 1179649,
      "n": "destinationAmount",
      "d": 2606855,
      "h": 81606985479,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81606985479),
//--TRIMMABLE-BOUNDARY-START(390844630791),
    {
      "t": 655361,
      "n": "sourceIssuerIndex",
      "d": 2606855,
      "h": 390844630791,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(390844630791),
//--TRIMMABLE-BOUNDARY-START(377959728903),
    {
      "t": 655361,
      "n": "sourceCoinIndex",
      "d": 2606855,
      "h": 377959728903,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(377959728903),
//--TRIMMABLE-BOUNDARY-START(107376789255),
    {
      "t": 655361,
      "n": "destinationIssuerIndex",
      "d": 2606855,
      "h": 107376789255,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107376789255),
//--TRIMMABLE-BOUNDARY-START(94491887367),
    {
      "t": 655361,
      "n": "destinationCoinIndex",
      "d": 2606855,
      "h": 94491887367,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94491887367),
//--TRIMMABLE-BOUNDARY-START(382254696199),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "n": "sourceDenomination",
      "d": 2606855,
      "h": 382254696199,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(382254696199),
//--TRIMMABLE-BOUNDARY-START(98786854663),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "n": "destinationDenomination",
      "d": 2606855,
      "h": 98786854663,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98786854663)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51542214407),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2606855,
      "h": 51542214407,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542214407)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(279175481095),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2606855,
        "h": 60132148999,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2606855,
        "h": 296355350279,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2606855,
      "h": 279175481095,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(279175481095)
  ],
  "h": 2606855
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletSwap`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletSwap`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2606855)
        
        

        //--TRIMMABLE-BOUNDARY-START(2410247)
        $asm.$cls(`$SeJP.LCWCS$1.WalletPayment`, ($self) => class WalletPayment extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(257700448007)
            /*string */ get OptimizedComponentName()
            {
                return "walletpayment";
            }
            //--TRIMMABLE-BOUNDARY-END(257700448007)
            
            //--TRIMMABLE-BOUNDARY-START(425204172551)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425204172551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Payer":
                    this.Payer = $.$cast(parameter.Value, $.$fPer.LCFCC$2.IContact);
                    return true;
                    case "Payee":
                    this.Payee = $.$cast(parameter.Value, $.$$.SCG.Dictionary$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money));
                    return true;
                    case "Amount":
                    this.Amount = $.$cast(parameter.Value, $.$fPer.LCFCDM.Money);
                    return true;
                    case "ServiceName":
                    this.ServiceName = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "PaymentReference":
                    this.PaymentReference = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "TransactionDescription":
                    this.TransactionDescription = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "CreatePayment":
                    this.CreatePayment = $.$cast(parameter.Value, $.$Iaui.LCFCM.PaymentModel);
                    return true;
                    case "OnPaid":
                    this.OnPaid = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PaymentResult));
                    return true;
                    case "WalletSegment":
                    this.WalletSegment = $.$cast(parameter.Value, $.$OJJQ.LCFCW.WalletSegment);
                    return true;
                    case "UseIssuer":
                    this.UseIssuer = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletIssuer);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(425204172551)
            
            //--TRIMMABLE-BOUNDARY-START(219045742343)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045742343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Issuers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(219045742343)
            
            //--TRIMMABLE-BOUNDARY-START(292060186375)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(292060186375)
            
            //--TRIMMABLE-BOUNDARY-START(223340709639)
            /*IEnumerable<IWalletIssuer>*/ Issuers = null;
            //--TRIMMABLE-BOUNDARY-END(223340709639)
            
            //--TRIMMABLE-BOUNDARY-START(266290382599)
            /*IContact?*/ Payer = null;
            //--TRIMMABLE-BOUNDARY-END(266290382599)
            
            //--TRIMMABLE-BOUNDARY-START(261995415303)
            /*Dictionary<IContact, Money>?*/ Payee = null;
            //--TRIMMABLE-BOUNDARY-END(261995415303)
            
            //--TRIMMABLE-BOUNDARY-START(77311821575)
            /*Money*/ Amount;
            //--TRIMMABLE-BOUNDARY-END(77311821575)
            
            //--TRIMMABLE-BOUNDARY-START(296355153671)
            /*string?*/ ServiceName = null;
            //--TRIMMABLE-BOUNDARY-END(296355153671)
            
            //--TRIMMABLE-BOUNDARY-START(270585349895)
            /*string*/ PaymentReference = null;
            //--TRIMMABLE-BOUNDARY-END(270585349895)
            
            //--TRIMMABLE-BOUNDARY-START(420909205255)
            /*string?*/ TransactionDescription = null;
            //--TRIMMABLE-BOUNDARY-END(420909205255)
            
            //--TRIMMABLE-BOUNDARY-START(85901756167)
            /*PaymentModel?*/ CreatePayment = null;
            //--TRIMMABLE-BOUNDARY-END(85901756167)
            
            //--TRIMMABLE-BOUNDARY-START(253405480711)
            /*EventCallback<PaymentResult>*/ OnPaid;
            //--TRIMMABLE-BOUNDARY-END(253405480711)
            
            //--TRIMMABLE-BOUNDARY-START(433794107143)
            /*WalletSegment*/ WalletSegment = 0;
            //--TRIMMABLE-BOUNDARY-END(433794107143)
            
            //--TRIMMABLE-BOUNDARY-START(429499139847)
            /*IWalletIssuer?*/ UseIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(429499139847)
            
            //--TRIMMABLE-BOUNDARY-START(240520578823)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(240520578823)
            
            //--TRIMMABLE-BOUNDARY-START(236225611527)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(236225611527)
            
            //--TRIMMABLE-BOUNDARY-START(249110513415)
            /*IEnumerable<UserWalletDataModel>?*/ onlineWallets = null;
            //--TRIMMABLE-BOUNDARY-END(249110513415)
            
            //--TRIMMABLE-BOUNDARY-START(279175284487)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(279175284487)
            
            //--TRIMMABLE-BOUNDARY-START(279175284487)
            //--TRIMMABLE-BOUNDARY-START(73016854279)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016854279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(73016854279)
            
            //--TRIMMABLE-BOUNDARY-START(287765219079)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287765219079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(287765219079)
            
            //--TRIMMABLE-BOUNDARY-END(279175284487)
            
            //--TRIMMABLE-BOUNDARY-START(244815546119)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244815546119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.onlineWallets = (($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$OJJQ.LCFCW.UserWalletDataModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12((this.Payer?.LCFCC$2$IContact$Identifier ?? null) ?? new $.$fPer.LCFCD.DataId()), null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).AsEnumerable();
                    if (this.UseIssuer !== null && $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.WalletTokenDescriptor, this.UseIssuer.LCFCW$IWalletIssuer$CoinDescriptors) === 1)
                    {
                        let $t3, $r3;
                        ($t3 = this.PayWith(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(this.UseIssuer, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.WalletTokenDescriptor, this.UseIssuer.LCFCW$IWalletIssuer$CoinDescriptors))), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    else if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers) === 1 && $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers).LCFCW$IWalletIssuer$CoinDescriptors) === 1)
                    {
                        let $t4, $r4;
                        ($t4 = this.PayWith(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3($.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers), $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers).LCFCW$IWalletIssuer$CoinDescriptors))), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(244815546119)
            
            //--TRIMMABLE-BOUNDARY-START(227635676935)
            /*(IWalletIssuer issuer, WalletTokenDescriptor coin)?*/ lastPay = null;
            //--TRIMMABLE-BOUNDARY-END(227635676935)
            
            //--TRIMMABLE-BOUNDARY-START(274880317191)
            /*Task *//*async*/  PayWith(/*(IWalletIssuer issuer, WalletTokenDescriptor coin)*/ pay)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(274880317191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (pay.Item1.LCFCW$IWalletIssuer$CanPayForService(this.ServiceName))
                    {
                        let $t5, $r5;
                        let $t6, $r6;
                        this.lastPay = $.$clone(pay);
                        /*var*/ let pin = ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$$.S.String, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `${$.$strNN(pay.Item2.Name)} Wallet Pin`, false), null, null, 78n, null, 0, 4, 4131, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        ($t6 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                            {
                                /*var*/ let tokens = pay.Item1.LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$Convert($.$clone(this.Amount), null);
                                if (tokens.Amount > 0)
                                {
                                    let $t9, $r9;
                                    /*var*/ let walletName = $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(pay.Item1, pay.Item2);
                                    /*UserWalletTransactionModel?*/ let transaction;
                                    if (this.Payer !== null && this.Payee !== null && this.Payer.LCFCC$2$IContact$Identifier.HasValue && this.Payee.Count > 0)
                                    {
                                        let $t7, $r7;
                                        transaction = ($t7 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$OJJQ.LCFCW.IWalletRemoteService, $.$OJJQ.LCFCW.UserWalletTransactionModel, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)))().$ctor(this,  (/**/ server) =>
                                        {
                                            return server.LCFCW$IWalletRemoteService$MultipleTransferTo(walletName, this.Payer.LCFCC$2$IContact$Identifier, $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money), $.$$.S.String, $.$$.S.Double, this.Payee, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money), $.$$.S.String))().$ctor(this,  (/**/ p) =>
                                            {
                                                return $.$dspc(p.Key.LCFCC$2$IContact$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString);
                                            }, $RjxMze ??= {"r":1310721,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money).$h}],"n":"","d":2410247,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money), $.$$.S.Double))().$ctor(this,  (/*pay*/ pay) =>
                                            {
                                                return pay.Value.Value;
                                            }, $ivqFig ??= {"r":1179649,"p":[{"n":"pay","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money).$h}],"n":"","d":2410247,"h":0,"f":17825794})), tokens.Amount, this.PaymentReference, new $.$fPer.LCFCD.DataId().$ctor$2(), this.TransactionDescription, pin, false, false);
                                        }, $ZJjZik ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,"p":[{"n":"server","p":1029325}],"n":"","d":2410247,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                    }
                                    else 
                                    {
                                        let $t8, $r8;
                                        if (this.CreatePayment !== null)
                                        {
                                            this.CreatePayment.FromWallet = walletName;
                                        }
                                        transaction = ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$OJJQ.LCFCW.IWalletRemoteService, $.$OJJQ.LCFCW.UserWalletTransactionModel, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)))().$ctor(this,  (/*server*/ server) =>
                                        {
                                            return server.LCFCW$IWalletRemoteService$DeductCoins(walletName, (this.Payer?.LCFCC$2$IContact$Identifier ?? null) ?? new $.$fPer.LCFCD.DataId(), tokens.Amount, this.PaymentReference, new $.$fPer.LCFCD.DataId().$ctor$2(), this.TransactionDescription, pin, false, this.WalletSegment, 0, this.CreatePayment);
                                        }, $SThpaf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,"p":[{"n":"server","p":1029325}],"n":"","d":2410247,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                        if (this.CreatePayment !== null)
                                        {
                                            /*var*/ let payment = $.$sl.SL.Enumerable.Single$1($.$Iaui.LCFCM.PaymentModel, transaction.Payments);
                                            this.CreatePayment.Identifier = payment.Identifier;
                                            this.CreatePayment.Reference = payment.Reference;
                                            this.CreatePayment.Amount = payment.Amount;
                                            this.CreatePayment.Summary = payment.Summary;
                                            this.CreatePayment.Properties = payment.Properties;
                                            this.CreatePayment.PaidUsing = transaction;
                                        }
                                    }
                                    ($t9 = this.OnPaid.InvokeAsync$1((() =>
                                    {
                                        //new $.$hDPm.LCFCI.PaymentResult()
                                        const $t10 = $.$hDPm.LCFCI.PaymentResult;
                                        const $i10 = new $t10();
                                        $i10.$ctor$2();
                                        $i10.Reference = transaction.Reference;
                                        $i10.Amount = $.$clone(this.Amount);
                                        return $i10;
                                    })()), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                }
                            });
                        }, $wbCpFg ??= {"r":181338113,"n":"","d":2410247,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                        }, $gJhINd ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":2410247,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(274880317191)
            
            //--TRIMMABLE-BOUNDARY-START(231930644231)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930644231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(231930644231)
            
            //--TRIMMABLE-BOUNDARY-START(81606788871)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606788871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<h3>Please choose a Wallet to pay with</h3>");
                if (this.onlineWallets !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 1);
                    __builder.AddComponentParameter(2, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                    __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                    __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        /*int*/ let count = 0;
                        let $en11 = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.IWalletIssuer, this.Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                        {
                            return i.LCFCW$IWalletIssuer$CanPayForService(this.ServiceName);
                        }, $akuypg ??= {"r":262145,"p":[{"n":"i","p":636109}],"n":"","d":2410247,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                        while ($en11.SC$1$IEnumerator$MoveNext())
                        {
                            let _issuer = $en11.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let issuer = _issuer;
                                let $en12 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                                while ($en12.SC$1$IEnumerator$MoveNext())
                                {
                                    let __coin = $en12.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let coin = $.$clone(__coin);
                                        /*var*/ let _coins = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.UserWalletDataModel, this.onlineWallets, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                                        {
                                            return c.WalletName === $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(coin));
                                        }, $tXAyxe ??= {"r":262145,"p":[{"n":"c","p":1881293}],"n":"","d":2410247,"h":0,"f":17825794}));
                                        if ($.$sl.SL.Enumerable.Any$1($.$OJJQ.LCFCW.UserWalletDataModel, _coins))
                                        {
                                            count++;
                                            __builder2.OpenElement(5, "div");
                                            __builder2.AddAttribute$5(6, "class", "flex pdy bdb clickable");
                                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 7, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                            {
                                                return this.PayWith(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)));
                                            }, $XeltBi ??= {"r":178454529,"n":"","d":2410247,"h":0,"f":17825794})));
                                            __builder2.OpenElement(8, "div");
                                            __builder2.AddAttribute$5(9, "class", "miwx-05 mawx-05");
                                            __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 10);
                                            __builder2.AddComponentParameter(11, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, coin.Icon.Icon === null ? $.$fPer.LCFC.IconDescriptor.op_Implicit("_content/LivingThing.Core.Wallet.Client.Blazor/img/coin.png") : coin.Icon));
                                            __builder2.AddComponentParameter(12, "IconSize", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                                            __builder2.AddComponentParameter(13, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                                            __builder2.AddComponentParameter(14, "MediaWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                                            __builder2.AddComponentParameter(15, "Class", "hx-05 wx-05");
                                            __builder2.CloseComponent();
                                            __builder2.CloseElement();
                                            __builder2.AddMarkupContent(16, "\r\n                        ");
                                            __builder2.OpenElement(17, "div");
                                            __builder2.AddAttribute$5(18, "class", "mgl fill");
                                            __builder2.OpenElement(19, "div");
                                            __builder2.AddAttribute$5(20, "class", "flex");
                                            __builder2.OpenElement(21, "h3");
                                            __builder2.AddAttribute$5(22, "class", "mgt-0 mgr mgb fill");
                                            __builder2.AddContent$4(23, issuer.LCFC$IDisplayable$Title);
                                            __builder2.CloseElement();
                                            __builder2.AddMarkupContent(24, "\r\n                                ");
                                            __builder2.OpenElement(25, "h2");
                                            __builder2.AddAttribute$5(26, "class", "mgl-1 mgy-0 cl-secondary");
                                            __builder2.AddContent$4(27, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                            __builder2.AddContent$4(28, $.$$.S.Double.ToString$3.call($.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletDataModel, _coins, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletDataModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                return c.Amount + c.Cashback + c.FrozenAmount;
                                            }, $RZSIkf ??= {"r":1179649,"p":[{"n":"c","p":1881293}],"n":"","d":2410247,"h":0,"f":17825794})), "#,##0.00"));
                                            __builder2.CloseElement();
                                            __builder2.CloseElement();
                                            __builder2.AddMarkupContent(29, "\r\n                            ");
                                            __builder2.OpenElement(30, "p");
                                            __builder2.AddAttribute$5(31, "class", "mg-0");
                                            __builder2.AddContent$4(32, issuer.LCFC$IDescribable$Description);
                                            __builder2.CloseElement();
                                            __builder2.CloseElement();
                                            __builder2.CloseElement();
                                        }
                                    }
                                }
                            }
                        }
                        if (count === 0)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 33);
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(34, "\r\n            ");
                            __builder2.AddMarkupContent(35, "<h3>Seems there is no wallet capable of paying for this transaction.</h3>");
                        }
                    }), $MTAmke ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2410247,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    if (this.Loading.State === 1073741824/*LoadingState.LoadError*/ && this.lastPay !== null)
                    {
                        __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 36);
                        __builder.AddComponentParameter(37, "href", "/Coins/Purchase");
                        __builder.AddComponentParameter(38, "Class", "d-block bg-primary pd text-center mgt");
                        __builder.AddAttribute$3(39, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddMarkupContent(40, "<span class=\"cl-white\">Purchase Coins</span>");
                        }), $VNbWka ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2410247,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                    }
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 41);
                    __builder.AddComponentParameter(42, "Class", "mgx-a");
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606788871)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(64426919687)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426919687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64426919687)
            
            //--TRIMMABLE-BOUNDARY-START(64426919687)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(64426919687)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(292060186375)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(292060186375)
                
                //--TRIMMABLE-BOUNDARY-START(223340709639)
                this.Issuers = null;
                //--TRIMMABLE-BOUNDARY-END(223340709639)
                
                //--TRIMMABLE-BOUNDARY-START(77311821575)
                this.Amount = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(77311821575)
                
                //--TRIMMABLE-BOUNDARY-START(270585349895)
                this.PaymentReference = null;
                //--TRIMMABLE-BOUNDARY-END(270585349895)
                
                //--TRIMMABLE-BOUNDARY-START(253405480711)
                this.OnPaid = $.$default($.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PaymentResult));
                //--TRIMMABLE-BOUNDARY-END(253405480711)
                
                //--TRIMMABLE-BOUNDARY-START(240520578823)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(240520578823)
                
                //--TRIMMABLE-BOUNDARY-START(227635676935)
                this.lastPay = null;
                //--TRIMMABLE-BOUNDARY-END(227635676935)
                
            }
            static $h = 2410247;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(257700448007),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031298311,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2410247,
      "h": 257700448007,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(257700448007),
//--TRIMMABLE-BOUNDARY-START(292060186375),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180391036679,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382254499591,
        "f": 83886081
      },
      "n": "Server",
      "d": 2410247,
      "h": 292060186375,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(292060186375),
//--TRIMMABLE-BOUNDARY-START(223340709639),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671559943,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322124957447,
        "f": 83886081
      },
      "n": "Issuers",
      "d": 2410247,
      "h": 223340709639,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223340709639),
//--TRIMMABLE-BOUNDARY-START(266290382599),
    {
      "p": 5081430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211167495,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365074630407,
        "f": 83886081
      },
      "n": "Payer",
      "d": 2410247,
      "h": 266290382599,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266290382599),
//--TRIMMABLE-BOUNDARY-START(261995415303),
    {
      "p": $.$$.SCG.Dictionary$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621232903,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356484695815,
        "f": 83886081
      },
      "n": "Payee",
      "d": 2410247,
      "h": 261995415303,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261995415303),
//--TRIMMABLE-BOUNDARY-START(77311821575),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491690759,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304945088263,
        "f": 83886081
      },
      "n": "Amount",
      "d": 2410247,
      "h": 77311821575,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311821575),
//--TRIMMABLE-BOUNDARY-START(296355153671),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980971271,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390844434183,
        "f": 83886081
      },
      "n": "ServiceName",
      "d": 2410247,
      "h": 296355153671,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296355153671),
//--TRIMMABLE-BOUNDARY-START(270585349895),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171801102087,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373664564999,
        "f": 83886081
      },
      "n": "PaymentReference",
      "d": 2410247,
      "h": 270585349895,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270585349895),
//--TRIMMABLE-BOUNDARY-START(420909205255),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197570905863,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 399434368775,
        "f": 83886081
      },
      "n": "TransactionDescription",
      "d": 2410247,
      "h": 420909205255,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(420909205255),
//--TRIMMABLE-BOUNDARY-START(85901756167),
    {
      "p": 12592470,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081625351,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313535022855,
        "f": 83886081
      },
      "n": "CreatePayment",
      "d": 2410247,
      "h": 85901756167,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85901756167),
//--TRIMMABLE-BOUNDARY-START(253405480711),
    {
      "p": $.$mac.MAC.EventCallback$$($.$hDPm.LCFCI.PaymentResult).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441363719,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347894761223,
        "f": 83886081
      },
      "n": "OnPaid",
      "d": 2410247,
      "h": 253405480711,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253405480711),
//--TRIMMABLE-BOUNDARY-START(433794107143),
    {
      "p": 2995405,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214750775047,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 416614237959,
        "f": 83886081
      },
      "n": "WalletSegment",
      "d": 2410247,
      "h": 433794107143,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(433794107143),
//--TRIMMABLE-BOUNDARY-START(429499139847),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160840455,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 408024303367,
        "f": 83886081
      },
      "n": "UseIssuer",
      "d": 2410247,
      "h": 429499139847,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(429499139847),
//--TRIMMABLE-BOUNDARY-START(240520578823),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851429127,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339304826631,
        "f": 83886081
      },
      "n": "Loading",
      "d": 2410247,
      "h": 240520578823,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240520578823),
//--TRIMMABLE-BOUNDARY-START(236225611527),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261494535,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330714892039,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 2410247,
      "h": 236225611527,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236225611527)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(425204172551),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2410247,
      "h": 425204172551,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(425204172551),
//--TRIMMABLE-BOUNDARY-START(219045742343),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2410247,
      "h": 219045742343,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219045742343),
//--TRIMMABLE-BOUNDARY-START(244815546119),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2410247,
      "h": 244815546119,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(244815546119),
//--TRIMMABLE-BOUNDARY-START(274880317191),
    {
      "r": 178454529,
      "p": [
        {
          "n": "pay",
          "p": $.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor).$h
        }
      ],
      "n": "PayWith",
      "d": 2410247,
      "h": 274880317191,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(274880317191),
//--TRIMMABLE-BOUNDARY-START(231930644231),
    {
      "r": 181338113,
      "n": "Load",
      "d": 2410247,
      "h": 231930644231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231930644231),
//--TRIMMABLE-BOUNDARY-START(81606788871),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2410247,
      "h": 81606788871,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81606788871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(249110513415),
    {
      "t": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletDataModel).$h,
      "n": "onlineWallets",
      "d": 2410247,
      "h": 249110513415,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(249110513415),
//--TRIMMABLE-BOUNDARY-START(227635676935),
    {
      "t": $.$typeNullable($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor)).$h,
      "n": "lastPay",
      "d": 2410247,
      "h": 227635676935,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(227635676935)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(64426919687),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2410247,
      "h": 64426919687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426919687)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(279175284487),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2410247,
        "h": 73016854279,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2410247,
        "h": 287765219079,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2410247,
      "h": 279175284487,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(279175284487)
  ],
  "h": 2410247
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletPayment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletPayment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2410247)
        
        

        //--TRIMMABLE-BOUNDARY-START(2541319)
        $asm.$cls(`$SeJP.LCWCS$1.WalletSend`, ($self) => class WalletSend extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(210455938823)
            /*string */ get OptimizedComponentName()
            {
                return "walletsend";
            }
            //--TRIMMABLE-BOUNDARY-END(210455938823)
            
            //--TRIMMABLE-BOUNDARY-START(347894892295)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894892295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "WalletSendProvider":
                    this.WalletSendProvider = $.$cast(parameter.Value, $.$SeJP.LCWCS.IWalletSendProvider);
                    return true;
                    case "OnFinished":
                    this.OnFinished = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(347894892295)
            
            //--TRIMMABLE-BOUNDARY-START(176096200455)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096200455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Clipboard = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IClipboardAccessor, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(176096200455)
            
            //--TRIMMABLE-BOUNDARY-START(352189859591)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(352189859591)
            
            //--TRIMMABLE-BOUNDARY-START(356484826887)
            /*IWalletSendProvider*/ WalletSendProvider = null;
            //--TRIMMABLE-BOUNDARY-END(356484826887)
            
            //--TRIMMABLE-BOUNDARY-START(201866004231)
            /*EventCallback*/ OnFinished;
            //--TRIMMABLE-BOUNDARY-END(201866004231)
            
            //--TRIMMABLE-BOUNDARY-START(55837116167)
            /*IClipboardAccessor*/ Clipboard = null;
            //--TRIMMABLE-BOUNDARY-END(55837116167)
            
            //--TRIMMABLE-BOUNDARY-START(330715023111)
            /*int*/ step = 1;
            //--TRIMMABLE-BOUNDARY-END(330715023111)
            
            //--TRIMMABLE-BOUNDARY-START(257700579079)
            /*bool*/ sendSpecificTokens = false;
            //--TRIMMABLE-BOUNDARY-END(257700579079)
            
            //--TRIMMABLE-BOUNDARY-START(343599924999)
            /*string?*/ transactionDescription = null;
            //--TRIMMABLE-BOUNDARY-END(343599924999)
            
            //--TRIMMABLE-BOUNDARY-START(219045873415)
            /*IWalletHolder?*/ peer = null;
            //--TRIMMABLE-BOUNDARY-END(219045873415)
            
            //--TRIMMABLE-BOUNDARY-START(223340840711)
            /*string?*/ pin = null;
            //--TRIMMABLE-BOUNDARY-END(223340840711)
            
            //--TRIMMABLE-BOUNDARY-START(206160971527)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160971527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$sl.SL.Enumerable.SelectMany$2($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor, this.Wallet.LCFCW$IWalletSystem$Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor)))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.LCFCW$IWalletIssuer$CoinDescriptors;
                }, $oDRHCj ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,"p":[{"n":"i","p":636109}],"n":"","d":2541319,"h":0,"f":17825794}))) > 1)
                {
                    this.sendSpecificTokens = true;
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(206160971527)
            
            //--TRIMMABLE-BOUNDARY-START(60132083463)
            /*Dictionary<(IWalletIssuer, WalletTokenDescriptor), double>*/ denominations = null;
            //--TRIMMABLE-BOUNDARY-END(60132083463)
            
            //--TRIMMABLE-BOUNDARY-START(339304957703)
            /*void */ ToggleSendByTokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304957703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this.Wallet, $.$OJJQ.LCFCW.IDenominatedWalletSystem))
                {
                    this.sendSpecificTokens = !this.sendSpecificTokens;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339304957703)
            
            //--TRIMMABLE-BOUNDARY-START(68722018055)
            /*double */ get EnteredTotal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491821831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this.Wallet, $.$OJJQ.LCFCW.IDenominatedWalletSystem))
                {
                    return $.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), this.denominations, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.Key.Item2.Amount * d.Value;
                    }, $cqsObj ??= {"r":1179649,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794}));
                }
                /*double*/ let total = 0;
                let $en2 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let issuer = $en2.SCG$IEnumerator$$$Current;
                    {
                        let $en3 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let coin = $en3.SCG$IEnumerator$$$Current;
                            {
                                total += this.GetEnteredAmount(issuer, $.$clone(coin));
                            }
                        }
                    }
                }
                return total;
            }
            /*double */ set EnteredTotal(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274880448263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.denominations = ($.$cast(this.Wallet, $.$OJJQ.LCFCW.IDenominatedWalletSystem)).LCFCW$IDenominatedWalletSystem$Denominate(value);
            }
            //--TRIMMABLE-BOUNDARY-END(68722018055)
            
            //--TRIMMABLE-BOUNDARY-START(193276069639)
            /*double */ get MaxAmount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851560199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*double*/ let total = 0;
                let $en4 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                while ($en4.SC$1$IEnumerator$MoveNext())
                {
                    let issuer = $en4.SCG$IEnumerator$$$Current;
                    {
                        let $en5 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let coin = $en5.SCG$IEnumerator$$$Current;
                            {
                                total += this.GetMaxAmount(issuer, $.$clone(coin));
                            }
                        }
                    }
                }
                return total;
            }
            //--TRIMMABLE-BOUNDARY-END(193276069639)
            
            //--TRIMMABLE-BOUNDARY-START(335009990407)
            /*double*/ get_Item$1(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin)
            {
                /*var*/ let count;
                this.denominations.TryGetValue(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), $.$ref(() => count, ($v) => count = $v, $.$$.S.Double));
                return coin.Amount > 0 ? count * coin.Amount : count;
            }
            /*void*/ set_Item$1(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin, /*double*/ value)
            {
                let den;
                if ($.$is(this.Wallet, $.$OJJQ.LCFCW.IDenominatedWalletSystem, { set $v($v){ den = $v; } }))
                {
                    /*var*/ let dens = den.LCFCW$IDenominatedWalletSystem$Denominate(value);
                    this.denominations.Clear();
                    let $en7 = dens.GetEnumerator();
                    while ($en7.MoveNext())
                    {
                        let denom = $en7.Current;
                        {
                            this.denominations.set_Item(denom.Key, denom.Value);
                        }
                    }
                }
                else 
                {
                    this.denominations.set_Item(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), coin.Amount > 0 ? value / (coin.Amount) : value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(335009990407)
            
            //--TRIMMABLE-BOUNDARY-START(214750906119)
            /*object?*/ payReceipt = null;
            //--TRIMMABLE-BOUNDARY-END(214750906119)
            
            //--TRIMMABLE-BOUNDARY-START(51542148871)
            /*CancellationTokenSource*/ cancel = null;
            //--TRIMMABLE-BOUNDARY-END(51542148871)
            
            //--TRIMMABLE-BOUNDARY-START(77311952647)
            /*ValueTask *//*async*/  Forward()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311952647);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.step++;
                    if (this.step === 2)
                    {
                        let $t8, $r8;
                        this.peer = ($t8 = this.WalletSendProvider.LCWCS$IWalletSendProvider$GetPeer(this.cancel.Token), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        if (this.peer !== null)
                        {
                            let $t9, $r9;
                            ($t9 = this.Forward(), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                            this.StateHasChanged();
                        }
                    }
                    else if (this.step === 5 && this.peer !== null && this.pin !== null)
                    {
                        let $t10, $r10;
                        ($t10 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t11, $r11;
                                let $t12, $r12;
                                this.payReceipt = ($t11 = this.WalletSendProvider.LCWCS$IWalletSendProvider$Pay(this.Wallet.LCFCW$IWalletSystem$Holder, this.peer, this.denominations, this.pin, this.transactionDescription, this, this.cancel.Token), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                ($t12 = this.Forward(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                                this.StateHasChanged();
                            });
                        }, $OrsBWf ??= {"r":181338113,"n":"","d":2541319,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                        }, $EYMQHd ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":2541319,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77311952647)
            
            //--TRIMMABLE-BOUNDARY-START(42952214279)
            /*void */ Backward()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952214279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.step--;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952214279)
            
            //--TRIMMABLE-BOUNDARY-START(167506265863)
            /*double */ GetEnteredAmount(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin)
            {
                /*var*/ let a;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506265863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.denominations.TryGetValue(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor))().$ctor$3(issuer, $.$clone(coin)), $.$ref(() => a, ($v) => a = $v, $.$$.S.Double)))
                {
                    return coin.Amount > 0 ? a * coin.Amount : a;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(167506265863)
            
            //--TRIMMABLE-BOUNDARY-START(171801233159)
            /*double */ GetMaxAmount(/*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801233159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.SelectMany$2($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.Where($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.SL$IGrouping$$$$Key === issuer.LCFC$INamed$Name;
                }, $WDxvNi ??= {"r":262145,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2541319,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken)))().$ctor(this,  (/**/ w) =>
                {
                    return w;
                }, $ImTzli ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,"p":[{"n":"w","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2541319,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$OJJQ.LCFCW.CoinTokenExtension.GetAmount(a, issuer);
                }, $UbXDYc ??= {"r":1179649,"p":[{"n":"a","p":1357005}],"n":"","d":2541319,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(171801233159)
            
            //--TRIMMABLE-BOUNDARY-START(236225742599)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(236225742599)
            
            //--TRIMMABLE-BOUNDARY-START(236225742599)
            //--TRIMMABLE-BOUNDARY-START(38657246983)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657246983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38657246983)
            
            //--TRIMMABLE-BOUNDARY-START(244815677191)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815677191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(244815677191)
            
            //--TRIMMABLE-BOUNDARY-END(236225742599)
            
            //--TRIMMABLE-BOUNDARY-START(188981102343)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(188981102343)
            
            //--TRIMMABLE-BOUNDARY-START(184686135047)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(184686135047)
            
            //--TRIMMABLE-BOUNDARY-START(227635808007)
            /*void */ PinChanged(/*string*/ pin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635808007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.pin = pin;
            }
            //--TRIMMABLE-BOUNDARY-END(227635808007)
            
            //--TRIMMABLE-BOUNDARY-START(73016985351)
            /*Task */ Finish()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016985351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnFinished.InvokeAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(73016985351)
            
            //--TRIMMABLE-BOUNDARY-START(180391167751)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391167751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(180391167751)
            
            //--TRIMMABLE-BOUNDARY-START(197571036935)
            /*string?*/ messageReport = null;
            //--TRIMMABLE-BOUNDARY-END(197571036935)
            
            //--TRIMMABLE-BOUNDARY-START(231930775303)
            /*float*/ progressReport = 0;
            //--TRIMMABLE-BOUNDARY-END(231930775303)
            
            //--TRIMMABLE-BOUNDARY-START(249110644487)
            /*void */ ReportMessage(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110644487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.messageReport = message;
                this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(249110644487)
            
            //--TRIMMABLE-BOUNDARY-START(253405611783)
            /*void */ ReportProgress(/*float*/ progress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405611783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.progressReport = progress;
                this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(253405611783)
            
            //--TRIMMABLE-BOUNDARY-START(64427050759)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427050759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.cancel.Cancel();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(64427050759)
            
            //--TRIMMABLE-BOUNDARY-START(47247181575)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247181575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, (336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/) & ~32/*LoadingFeatures.Retry*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    var isValid;
                    var mtotal;
                    switch(this.step)
                    {
                        case 1:
                        __builder2.OpenElement(4, "div");
                        __builder2.AddAttribute$5(5, "class", "pd");
                        __builder2.OpenElement(6, "h1");
                        __builder2.AddAttribute$5(7, "class", "text-center mgt-0");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 8, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleSendByTokens)));
                        __builder2.AddContent$4(9, !this.sendSpecificTokens ? "How much are you sending?" : "Select denominations to send.");
                        __builder2.CloseElement();
                        if (!this.sendSpecificTokens)
                        {
                            if ($.$is(this.Wallet, $.$OJJQ.LCFCW.IDenominatedWalletSystem) && $.$sl.SL.Enumerable.Count$1($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletIssuer), $.$sl.SL.Enumerable.GroupBy$7($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.String, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.String))().$ctor(this,  (/*i*/ i) =>
                            {
                                return i.LCFCW$IWalletIssuer$CurrencyUnit;
                            }, $oYqGca ??= {"r":1310721,"p":[{"n":"i","p":636109}],"n":"","d":2541319,"h":0,"f":17825794}))) === 1)
                            {
                                /*var*/ let currencyUnit = $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers).LCFCW$IWalletIssuer$CurrencyUnit;
                                __builder2.OpenElement(10, "div");
                                __builder2.AddAttribute$5(11, "class", "flex");
                                __builder2.OpenElement(12, "span");
                                __builder2.AddAttribute$5(13, "class", "fsz-50 mgr");
                                __builder2.AddContent$4(14, currencyUnit);
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(15, "\r\n                                ");
                                __builder2.OpenElement(16, "div");
                                __builder2.AddAttribute$5(17, "class", "stack fill");
                                __builder2.OpenElement(18, "input");
                                __builder2.AddAttribute$5(19, "class", "pd-5 bg-primary-01 bd bdw-2 fsz-20");
                                __builder2.AddAttribute$5(20, "type", "number");
                                __builder2.AddAttribute$5(21, "value", $.$mac.MAC.BindConverter.FormatValue$8(this.EnteredTotal, $.$$.SG.CultureInfo.InvariantCulture));
                                __builder2.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 22, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$8($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.EnteredTotal = __value;
                                }, $nGZONe ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":2541319,"h":0,"f":17825794}), this.EnteredTotal, $.$$.SG.CultureInfo.InvariantCulture));
                                __builder2.SetUpdatesAttributeName("value");
                                __builder2.CloseElement();
                                /*var*/ let tFee = this.WalletSendProvider.LCWCS$IWalletSendProvider$GetTransactionFee(this.EnteredTotal);
                                /*System.Collections.Generic.Dictionary<string, double>?*/ let __ca1__;
                                /*var*/ let totalFee = ((__ca1__ = tFee) !== null ? $.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), __ca1__, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                                {
                                    return t.Value;
                                }, $hNdLof ??= {"r":1179649,"p":[{"n":"t","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794})) : 0);
                                if (tFee !== null)
                                {
                                    $.$SeJP._LCWCSW$1.TypeInference.CreatePropertySheet_0($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), __builder2, 23, 24, "mgt", 25, $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.String, $.$$.S.String, tFee, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                    {
                                        return c.Key;
                                    }, $gUGgZb ??= {"r":1310721,"p":[{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                    {
                                        return currencyUnit + c.Value;
                                    }, $HDctMe ??= {"r":1310721,"p":[{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794})), 26, $.$box(this.EnteredTotal, $.$$.S.Double));
                                }
                                if (this.EnteredTotal + totalFee > this.MaxAmount)
                                {
                                    __builder2.OpenElement(27, "span");
                                    __builder2.AddAttribute$5(28, "class", "cl-error");
                                    __builder2.AddMarkupContent(29, "\r\n                                            This amount is more than your current Balance of ");
                                    __builder2.AddContent$4(30, currencyUnit);
                                    __builder2.AddContent$3(31, $.$box(this.MaxAmount, $.$$.S.Double));
                                    __builder2.CloseElement();
                                }
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                            else 
                            {
                                let $en15 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                                while ($en15.SC$1$IEnumerator$MoveNext())
                                {
                                    let issuer = $en15.SCG$IEnumerator$$$Current;
                                    {
                                        let $en16 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                                        while ($en16.SC$1$IEnumerator$MoveNext())
                                        {
                                            let coin = $en16.SCG$IEnumerator$$$Current;
                                            {
                                                __builder2.OpenElement(32, "div");
                                                __builder2.AddAttribute$5(33, "class", "flex");
                                                __builder2.OpenElement(34, "span");
                                                __builder2.AddAttribute$5(35, "class", "fsz-50 mgr");
                                                __builder2.AddContent$4(36, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                                __builder2.CloseElement();
                                                __builder2.AddMarkupContent(37, "\r\n                                        ");
                                                __builder2.OpenElement(38, "div");
                                                __builder2.AddAttribute$5(39, "class", "stack fill");
                                                __builder2.OpenElement(40, "input");
                                                __builder2.AddAttribute$5(41, "class", "pd-5 bg-primary-01 bd bdw-2 fsz-20");
                                                __builder2.AddAttribute$5(42, "type", "number");
                                                __builder2.AddAttribute$5(43, "value", $.$mac.MAC.BindConverter.FormatValue$8(this.get_Item$1(issuer, $.$clone(coin)), $.$$.SG.CultureInfo.InvariantCulture));
                                                __builder2.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 44, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$8($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.set_Item$1(issuer, $.$clone(coin), __value);
                                                }, $HFfZdh ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":2541319,"h":0,"f":17825794}), this.get_Item$1(issuer, $.$clone(coin)), $.$$.SG.CultureInfo.InvariantCulture));
                                                __builder2.SetUpdatesAttributeName("value");
                                                __builder2.CloseElement();
                                                /*var*/ let tFee = this.WalletSendProvider.LCWCS$IWalletSendProvider$GetTransactionFee(this.GetEnteredAmount(issuer, $.$clone(coin)));
                                                /*System.Collections.Generic.Dictionary<string, double>?*/ let __ca2__;
                                                /*var*/ let totalFee = ((__ca2__ = tFee) !== null ? $.$sl.SL.Enumerable.Sum$16($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), __ca2__, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                                                {
                                                    return t.Value;
                                                }, $oRXlNh ??= {"r":1179649,"p":[{"n":"t","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794})) : 0);
                                                if (tFee !== null)
                                                {
                                                    $.$SeJP._LCWCSW$1.TypeInference.CreatePropertySheet_1($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), __builder2, 45, 46, "mgt", 47, $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.String, $.$$.S.String, tFee, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                                    {
                                                        return c.Key;
                                                    }, $FFaQDk ??= {"r":1310721,"p":[{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double), $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                                    {
                                                        return issuer.LCFCW$IWalletIssuer$CurrencyUnit + c.Value;
                                                    }, $ULjbha ??= {"r":1310721,"p":[{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794})), 48, $.$box(this.GetEnteredAmount(issuer, $.$clone(coin)), $.$$.S.Double));
                                                }
                                                if (this.GetEnteredAmount(issuer, $.$clone(coin)) + totalFee > this.GetMaxAmount(issuer, $.$clone(coin)))
                                                {
                                                    __builder2.OpenElement(49, "span");
                                                    __builder2.AddAttribute$5(50, "class", "cl-error");
                                                    __builder2.AddMarkupContent(51, "\r\n                                                    This amount is more than your current Balance of ");
                                                    __builder2.AddContent$4(52, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                                    __builder2.AddContent$3(53, $.$box(this.GetMaxAmount(issuer, $.$clone(coin)), $.$$.S.Double));
                                                    __builder2.CloseElement();
                                                }
                                                __builder2.CloseElement();
                                                __builder2.CloseElement();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else 
                        {
                            __builder2.OpenComponent$1($.$SeJP.LCWCS$1.WalletDenominate, 54);
                            __builder2.AddComponentParameter(55, "Wallet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Wallet));
                            __builder2.AddComponentParameter(56, "Denomination", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), this.denominations));
                            __builder2.AddComponentParameter(57, "DenominationChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double)), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double), this, new ($.$$.S.Action$$($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double)))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return this.denominations = __value;
                            }, $aobOLg ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h}],"n":"","d":2541319,"h":0,"f":17825794}), this.denominations))));
                            __builder2.CloseComponent();
                        }
                        __builder2.AddMarkupContent(58, "<small class=\"mgt d-block\">Transaction Description (required)</small>\r\n                    ");
                        __builder2.OpenElement(59, "input");
                        __builder2.AddAttribute$5(60, "class", "pd-5 bg-primary-01 bd bdw-2 fsz-20 d-block wf");
                        __builder2.AddAttribute$5(61, "placeholder", "Transaction Description");
                        __builder2.AddAttribute$5(62, "type", "text");
                        __builder2.AddAttribute$5(63, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.transactionDescription, null));
                        __builder2.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 64, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.transactionDescription = __value;
                        }, $IEKzYh ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2541319,"h":0,"f":17825794}), this.transactionDescription, null));
                        __builder2.SetUpdatesAttributeName("value");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(65, "\r\n                    ");
                        __builder2.OpenElement(66, "div");
                        __builder2.AddAttribute$5(67, "class", "flex mgt");
                        __builder2.AddMarkupContent(68, "<div class=\"fill\"></div>\r\n                        ");
                        __builder2.OpenElement(69, "div");
                        __builder2.AddAttribute$5(70, "class", "flex");
                        __builder2.AddMarkupContent(71, "<span class=\"mgy-a bg-primary pdx pdy-2 corner-l-5 hx-03 mgr--2\">Continue</span>");
                        isValid = true;
                        mtotal = 0;
                        let $en17 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                        while ($en17.SC$1$IEnumerator$MoveNext())
                        {
                            let issuer = $en17.SCG$IEnumerator$$$Current;
                            {
                                let $en18 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                                while ($en18.SC$1$IEnumerator$MoveNext())
                                {
                                    let coin = $en18.SCG$IEnumerator$$$Current;
                                    {
                                        mtotal += this.GetEnteredAmount(issuer, $.$clone(coin));
                                        if (this.GetEnteredAmount(issuer, $.$clone(coin)) > this.GetMaxAmount(issuer, $.$clone(coin)))
                                        {
                                            isValid = false;
                                            break;
                                        }
                                    }
                                }
                                if (!isValid)
                                {
                                    break;
                                }
                            }
                        }
                        __builder2.OpenElement(72, "button");
                        __builder2.AddAttribute$5(73, "class", "mdi mdi-chevron-right fsz-25 bg-primary wx-05 hx-05 round");
                        __builder2.AddAttribute$2(74, "disabled", !isValid || mtotal === 0 || $.$$.S.String.IsNullOrEmpty(this.transactionDescription));
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 75, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forward)));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        break;
                        case 2:
                        break;
                        case 3:
                        __builder2.OpenElement(76, "div");
                        __builder2.AddAttribute$5(77, "class", "text-center pd");
                        __builder2.AddMarkupContent(78, "<h1 class=\"mgt-0\">Receiver Info</h1>\r\n                    ");
                        __builder2.OpenElement(79, "div");
                        __builder2.AddAttribute$5(80, "class", "mgx-a");
                        __builder2.AddMarkupContent(81, "<i class=\"mdi mdi-account fsz-100 hx-12 wx-12 bd round d-block mgx-a flex mgc-a\"></i>\r\n                        ");
                        __builder2.OpenElement(82, "h2");
                        __builder2.AddContent$4(83, this.peer.LCFC$IDisplayable$Title);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(84, "\r\n                        ");
                        __builder2.OpenElement(85, "p");
                        __builder2.AddAttribute$5(86, "style", "word-break:break-all");
                        __builder2.AddContent$4(87, this.peer.LCFCW$IWalletHolder$NetworkAddress.Address);
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(88, "\r\n                    ");
                        $.$SeJP._LCWCSW$1.TypeInference.CreatePropertySheet_2($.$OJJQ.LCFCW.IWalletHolder, __builder2, 89, 90, this.peer, 91, "fw-bold", 92, 2, 93, 35184372092928n | 8388608n);
                        __builder2.AddMarkupContent(94, "\r\n                    ");
                        __builder2.OpenElement(95, "button");
                        __builder2.AddAttribute$5(96, "class", "bg-primary d-block pd corner miwx-2 mgx-a fw-bold fsz-25 mgt-10");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 97, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forward)));
                        __builder2.AddMarkupContent(98, "\r\n                        Pay ");
                        __builder2.AddContent$4(99, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers).LCFCW$IWalletIssuer$CurrencyUnit);
                        __builder2.AddContent$3(100, $.$box(this.EnteredTotal, $.$$.S.Double));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        break;
                        case 4:
                        __builder2.OpenComponent$1($.$macw.MACF.EditForm, 101);
                        __builder2.AddComponentParameter(102, "class", "pd text-center");
                        __builder2.AddComponentParameter(103, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                        __builder2.AddAttribute$3(104, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(105, "<h1 class=\"mgt-0\">Input Pin</h1>\r\n                    ");
                                __builder3.AddMarkupContent(106, "<p>Enter your transaction pin to continue</p>\r\n                    ");
                                $.$SeJP._LCWCSW$1.TypeInference.CreateInputEditor_3($.$$.S.String, __builder3, 107, 108, 78n, 109, this.pin, 110, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.pin = __value;
                                }, $aRrgSh ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2541319,"h":0,"f":17825794}), this.pin)), 111, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "pin"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $ilDuEi ??= {"r":38797349,"n":"","d":2541319,"h":0,"f":17825794})).Invoke()));
                                __builder3.AddMarkupContent(112, "\r\n                    ");
                                __builder3.OpenElement(113, "button");
                                __builder3.AddAttribute$5(114, "class", "bg-primary d-block pd corner miwx-2 mgx-a fw-bold fsz-25 mgt-10");
                                const $t19 = this.pin;
                                __builder3.AddAttribute$2(115, "disabled", !(($.$ifnn($t19, ($t) => $t.length) ?? 0) === 4));
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 116, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forward)));
                                __builder3.AddMarkupContent(117, "\r\n                        Pay ");
                                __builder3.AddContent$4(118, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers).LCFCW$IWalletIssuer$CurrencyUnit);
                                __builder3.AddContent$3(119, $.$box(this.EnteredTotal, $.$$.S.Double));
                                __builder3.CloseElement();
                            }, $Savhye ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2541319,"h":0,"f":17825794});
                        }), $qvhmLg ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":2541319,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        break;
                        case 5:
                        __builder2.OpenElement(120, "div");
                        __builder2.AddAttribute$5(121, "class", "pd text-center mihx-2");
                        __builder2.OpenElement(122, "h2");
                        __builder2.AddAttribute$5(123, "class", "mgt-0");
                        __builder2.AddMarkupContent(124, "\r\n                        Sending\r\n");
                        let $en20 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                        while ($en20.SC$1$IEnumerator$MoveNext())
                        {
                            let issuer = $en20.SCG$IEnumerator$$$Current;
                            {
                                let $en21 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                                while ($en21.SC$1$IEnumerator$MoveNext())
                                {
                                    let coin = $en21.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let amount = this.GetEnteredAmount(issuer, $.$clone(coin));
                                        if (amount > 0)
                                        {
                                            __builder2.AddContent$4(125, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                            __builder2.AddContent$4(126, $.$$.S.Double.ToString$3.call(amount, "#,###"));
                                        }
                                    }
                                }
                            }
                        }
                        __builder2.AddContent$4(127, "                        to ");
                        __builder2.AddContent$4(128, this.peer.LCFC$IDisplayable$Title);
                        __builder2.AddMarkupContent(129, "...\r\n                    ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(130, "\r\n                    ");
                        __builder2.OpenElement(131, "p");
                        __builder2.AddAttribute$5(132, "class", "text-center");
                        __builder2.AddContent$4(133, this.messageReport);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(134, "\r\n                    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 135);
                        __builder2.AddComponentParameter(136, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, ($.$cast((100 * this.progressReport), $.$$.S.Int32))), $.$$.S.Int32));
                        __builder2.AddComponentParameter(137, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                        __builder2.AddComponentParameter(138, "Class", "corner-5 clip");
                        __builder2.AddComponentParameter(139, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                        __builder2.AddComponentParameter(140, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        break;
                        case 6:
                        __builder2.OpenElement(141, "div");
                        __builder2.AddAttribute$5(142, "class", "pd");
                        __builder2.AddMarkupContent(143, "<div class=\"text-center\"><h2 class=\"mgt-0\">Transfer Successful</h2>\r\n                        <i class=\"mdi mdi-checkbox-marked-circle-outline fsz-100 cl-success\"></i></div>");
                        if ($.$sl.SL.Enumerable.Count$1($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletIssuer), $.$sl.SL.Enumerable.GroupBy$7($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.String, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.String))().$ctor(this,  (/*i*/ i) =>
                        {
                            return i.LCFCW$IWalletIssuer$CurrencyUnit;
                        }, $HkIvBb ??= {"r":1310721,"p":[{"n":"i","p":636109}],"n":"","d":2541319,"h":0,"f":17825794}))) === 1)
                        {
                            /*double*/ let total = 0;
                            let $en22 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                            while ($en22.SC$1$IEnumerator$MoveNext())
                            {
                                let issuer = $en22.SCG$IEnumerator$$$Current;
                                {
                                    let $en23 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en23.SC$1$IEnumerator$MoveNext())
                                    {
                                        let coin = $en23.SCG$IEnumerator$$$Current;
                                        {
                                            /*var*/ let amount = this.GetEnteredAmount(issuer, $.$clone(coin));
                                            if (amount > 0)
                                            {
                                                total += amount;
                                            }
                                        }
                                    }
                                }
                            }
                            __builder2.OpenElement(144, "div");
                            __builder2.AddAttribute$5(145, "class", "bg-card corner-3 pd text-center");
                            __builder2.OpenElement(146, "h1");
                            __builder2.AddAttribute$5(147, "class", "cl-primary fsz-50");
                            __builder2.AddContent$4(148, "-");
                            __builder2.AddContent$4(149, $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers).LCFCW$IWalletIssuer$CurrencyUnit);
                            __builder2.AddContent$3(150, $.$box(total, $.$$.S.Double));
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(151, "p");
                        __builder2.AddAttribute$5(152, "class", "text-center");
                        let $en24 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                        while ($en24.SC$1$IEnumerator$MoveNext())
                        {
                            let issuer = $en24.SCG$IEnumerator$$$Current;
                            {
                                let $en25 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                                while ($en25.SC$1$IEnumerator$MoveNext())
                                {
                                    let coin = $en25.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let amount = this.GetEnteredAmount(issuer, $.$clone(coin));
                                        if (amount > 0)
                                        {
                                            __builder2.AddContent$4(153, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                            __builder2.AddContent$4(154, $.$$.S.Double.ToString$3.call(amount, "#,###"));
                                        }
                                    }
                                }
                            }
                        }
                        __builder2.AddContent$4(155, "                        was sent to ");
                        __builder2.AddContent$4(156, this.peer.LCFC$IDisplayable$Title);
                        __builder2.AddMarkupContent(157, "!\r\n                    ");
                        __builder2.CloseElement();
                        if (this.payReceipt !== null)
                        {
                            __builder2.OpenElement(158, "div");
                            __builder2.AddAttribute$5(159, "class", "bg-card pd corner-3 mgt");
                            $.$SeJP._LCWCSW$1.TypeInference.CreatePropertySheet_4($.$$.S.Object, __builder2, 160, 161, this.payReceipt, 162, 2, 163, 35184372092928n | 8388608n);
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(164, "button");
                        __builder2.AddAttribute$5(165, "class", "bg-primary d-block pd corner miwx-2 mgx-a fw-bold fsz-25 mgt-10");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 166, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Finish)));
                        __builder2.AddContent$4(167, "Finish");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        break;
                    }
                }), $xxJSTb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2541319,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(47247181575)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8590832845)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator.ReportProgress(float)
            LCFCW$IWalletPaymentSendProgressReportIndicator$ReportProgress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590832845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReportProgress(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590832845)
            
            //--TRIMMABLE-BOUNDARY-START(4295865549)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator.ReportMessage(string)
            LCFCW$IWalletPaymentSendProgressReportIndicator$ReportMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295865549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReportMessage(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295865549)
            
            //--TRIMMABLE-BOUNDARY-START(30067312391)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067312391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067312391)
            
            //--TRIMMABLE-BOUNDARY-START(30067312391)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30067312391)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(352189859591)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(352189859591)
                
                //--TRIMMABLE-BOUNDARY-START(356484826887)
                this.WalletSendProvider = null;
                //--TRIMMABLE-BOUNDARY-END(356484826887)
                
                //--TRIMMABLE-BOUNDARY-START(201866004231)
                this.OnFinished = new $.$mac.MAC.EventCallback();
                //--TRIMMABLE-BOUNDARY-END(201866004231)
                
                //--TRIMMABLE-BOUNDARY-START(55837116167)
                this.Clipboard = null;
                //--TRIMMABLE-BOUNDARY-END(55837116167)
                
                //--TRIMMABLE-BOUNDARY-START(60132083463)
                this.denominations = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(60132083463)
                
                //--TRIMMABLE-BOUNDARY-START(51542148871)
                this.cancel = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(51542148871)
                
                //--TRIMMABLE-BOUNDARY-START(188981102343)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(188981102343)
                
            }
            static $h = 2541319;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(210455938823),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031429383,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2541319,
      "h": 210455938823,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(210455938823),
//--TRIMMABLE-BOUNDARY-START(352189859591),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621363975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317830121223,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 2541319,
      "h": 352189859591,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(352189859591),
//--TRIMMABLE-BOUNDARY-START(356484826887),
    {
      "p": 968455,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211298567,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326420055815,
        "f": 83886081
      },
      "n": "WalletSendProvider",
      "d": 2541319,
      "h": 356484826887,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(356484826887),
//--TRIMMABLE-BOUNDARY-START(201866004231),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441494791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309240186631,
        "f": 83886081
      },
      "n": "OnFinished",
      "d": 2541319,
      "h": 201866004231,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201866004231),
//--TRIMMABLE-BOUNDARY-START(55837116167),
    {
      "p": 2776488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901887239,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266290513671,
        "f": 83886081
      },
      "n": "Clipboard",
      "d": 2541319,
      "h": 55837116167,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55837116167),
//--TRIMMABLE-BOUNDARY-START(68722018055),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491821831,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274880448263,
        "f": 83886082
      },
      "n": "EnteredTotal",
      "d": 2541319,
      "h": 68722018055,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68722018055),
//--TRIMMABLE-BOUNDARY-START(193276069639),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851560199,
        "f": 50331650
      },
      "n": "MaxAmount",
      "d": 2541319,
      "h": 193276069639,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(193276069639),
//--TRIMMABLE-BOUNDARY-START(335009990407),
    {
      "p": 1179649,
      "i": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "coin",
          "p": 3257549
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081756423,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283470382855,
        "f": 83886082
      },
      "n": "Item",
      "o": "@$1",
      "d": 2541319,
      "h": 335009990407,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(335009990407),
//--TRIMMABLE-BOUNDARY-START(188981102343),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261625607,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300650252039,
        "f": 83886081
      },
      "n": "Loading",
      "d": 2541319,
      "h": 188981102343,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188981102343),
//--TRIMMABLE-BOUNDARY-START(184686135047),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671691015,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292060317447,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 2541319,
      "h": 184686135047,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184686135047)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(347894892295),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2541319,
      "h": 347894892295,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(347894892295),
//--TRIMMABLE-BOUNDARY-START(176096200455),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2541319,
      "h": 176096200455,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176096200455),
//--TRIMMABLE-BOUNDARY-START(206160971527),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 2541319,
      "h": 206160971527,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(206160971527),
//--TRIMMABLE-BOUNDARY-START(339304957703),
    {
      "r": 65537,
      "n": "ToggleSendByTokens",
      "d": 2541319,
      "h": 339304957703,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(339304957703),
//--TRIMMABLE-BOUNDARY-START(77311952647),
    {
      "r": 181338113,
      "n": "Forward",
      "d": 2541319,
      "h": 77311952647,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(77311952647),
//--TRIMMABLE-BOUNDARY-START(42952214279),
    {
      "r": 65537,
      "n": "Backward",
      "d": 2541319,
      "h": 42952214279,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42952214279),
//--TRIMMABLE-BOUNDARY-START(167506265863),
    {
      "r": 1179649,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "coin",
          "p": 3257549
        }
      ],
      "n": "GetEnteredAmount",
      "d": 2541319,
      "h": 167506265863,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167506265863),
//--TRIMMABLE-BOUNDARY-START(171801233159),
    {
      "r": 1179649,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "GetMaxAmount",
      "d": 2541319,
      "h": 171801233159,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171801233159),
//--TRIMMABLE-BOUNDARY-START(227635808007),
    {
      "r": 65537,
      "p": [
        {
          "n": "pin",
          "p": 1310721
        }
      ],
      "n": "PinChanged",
      "d": 2541319,
      "h": 227635808007,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227635808007),
//--TRIMMABLE-BOUNDARY-START(73016985351),
    {
      "r": 178454529,
      "n": "Finish",
      "d": 2541319,
      "h": 73016985351,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73016985351),
//--TRIMMABLE-BOUNDARY-START(180391167751),
    {
      "r": 181338113,
      "n": "Load",
      "d": 2541319,
      "h": 180391167751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180391167751),
//--TRIMMABLE-BOUNDARY-START(249110644487),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ReportMessage",
      "d": 2541319,
      "h": 249110644487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249110644487),
//--TRIMMABLE-BOUNDARY-START(253405611783),
    {
      "r": 65537,
      "p": [
        {
          "n": "progress",
          "p": 1114113
        }
      ],
      "n": "ReportProgress",
      "d": 2541319,
      "h": 253405611783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253405611783),
//--TRIMMABLE-BOUNDARY-START(64427050759),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2541319,
      "h": 64427050759,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64427050759),
//--TRIMMABLE-BOUNDARY-START(47247181575),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2541319,
      "h": 47247181575,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47247181575)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(330715023111),
    {
      "t": 655361,
      "n": "step",
      "d": 2541319,
      "h": 330715023111,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(330715023111),
//--TRIMMABLE-BOUNDARY-START(257700579079),
    {
      "t": 262145,
      "n": "sendSpecificTokens",
      "d": 2541319,
      "h": 257700579079,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(257700579079),
//--TRIMMABLE-BOUNDARY-START(343599924999),
    {
      "t": 1310721,
      "n": "transactionDescription",
      "d": 2541319,
      "h": 343599924999,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(343599924999),
//--TRIMMABLE-BOUNDARY-START(219045873415),
    {
      "t": 570573,
      "n": "peer",
      "d": 2541319,
      "h": 219045873415,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(219045873415),
//--TRIMMABLE-BOUNDARY-START(223340840711),
    {
      "t": 1310721,
      "n": "pin",
      "d": 2541319,
      "h": 223340840711,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(223340840711),
//--TRIMMABLE-BOUNDARY-START(60132083463),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "n": "denominations",
      "d": 2541319,
      "h": 60132083463,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60132083463),
//--TRIMMABLE-BOUNDARY-START(214750906119),
    {
      "t": 131073,
      "n": "payReceipt",
      "d": 2541319,
      "h": 214750906119,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(214750906119),
//--TRIMMABLE-BOUNDARY-START(51542148871),
    {
      "t": 170983425,
      "n": "cancel",
      "d": 2541319,
      "h": 51542148871,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51542148871),
//--TRIMMABLE-BOUNDARY-START(197571036935),
    {
      "t": 1310721,
      "n": "messageReport",
      "d": 2541319,
      "h": 197571036935,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(197571036935),
//--TRIMMABLE-BOUNDARY-START(231930775303),
    {
      "t": 1114113,
      "n": "progressReport",
      "d": 2541319,
      "h": 231930775303,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(231930775303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067312391),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2541319,
      "h": 30067312391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067312391)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(236225742599),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2541319,
        "h": 38657246983,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2541319,
        "h": 244815677191,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2541319,
      "h": 236225742599,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(236225742599)
  ],
  "h": 2541319
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$OJJQ.LCFCW.IWalletPaymentSendProgressReportIndicator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletSend`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletSend`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2541319)
        
        

        //--TRIMMABLE-BOUNDARY-START(2475783)
        $asm.$cls(`$SeJP.LCWCS$1.WalletReceive`, ($self) => class WalletReceive extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(300650186503)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(300650186503)
            
            //--TRIMMABLE-BOUNDARY-START(304945153799)
            /*IWalletReceiveProvider*/ WalletReceiveProvider = null;
            //--TRIMMABLE-BOUNDARY-END(304945153799)
            
            //--TRIMMABLE-BOUNDARY-START(167506200327)
            /*EventCallback*/ OnFinished;
            //--TRIMMABLE-BOUNDARY-END(167506200327)
            
            //--TRIMMABLE-BOUNDARY-START(55837050631)
            /*IClipboardAccessor*/ Clipboard = null;
            //--TRIMMABLE-BOUNDARY-END(55837050631)
            
            //--TRIMMABLE-BOUNDARY-START(296355219207)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(296355219207)
            
            //--TRIMMABLE-BOUNDARY-START(287765284615)
            /*int*/ step = 1;
            //--TRIMMABLE-BOUNDARY-END(287765284615)
            
            //--TRIMMABLE-BOUNDARY-START(223340775175)
            /*IWalletHolder?*/ sender = null;
            //--TRIMMABLE-BOUNDARY-END(223340775175)
            
            //--TRIMMABLE-BOUNDARY-START(197570971399)
            /*IEnumerable<IWalletToken>?*/ receivedTokens = null;
            //--TRIMMABLE-BOUNDARY-END(197570971399)
            
            //--TRIMMABLE-BOUNDARY-START(201865938695)
            /*IDisposable?*/ receiving = null;
            //--TRIMMABLE-BOUNDARY-END(201865938695)
            
            //--TRIMMABLE-BOUNDARY-START(171801167623)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171801167623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.step === 1)
                    {
                        let $t1, $r1;
                        this.receiving?.S$IDisposable$Dispose();
                        this.receiving = ($t1 = this.WalletReceiveProvider.LCWCS$IWalletReceiveProvider$Receive(this.Wallet.LCFCW$IWalletSystem$Holder, this), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171801167623)
            
            //--TRIMMABLE-BOUNDARY-START(73016919815)
            /*ValueTask *//*async*/  Forward()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016919815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.step++;
                    if (this.step === 1)
                    {
                        let $t3, $r3;
                        this.receiving?.S$IDisposable$Dispose();
                        this.receiving = ($t3 = this.WalletReceiveProvider.LCWCS$IWalletReceiveProvider$Receive(this.Wallet.LCFCW$IWalletSystem$Holder, this), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73016919815)
            
            //--TRIMMABLE-BOUNDARY-START(47247116039)
            /*void */ Backward()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47247116039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.step--;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247116039)
            
            //--TRIMMABLE-BOUNDARY-START(60132017927)
            /*ValueTask *//*async*/  CopyAddress()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60132017927);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.Clipboard.LCFCC$IClipboardAccessor$SetAsync(this.WalletReceiveProvider.LCWCS$IWalletReceiveProvider$SelfAddress.Address ?? $.$OJJQ.LCFCW.WalletAddress.op_Implicit(this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.Toast($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPage, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Address copied to clipboard", false), null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60132017927)
            
            //--TRIMMABLE-BOUNDARY-START(193276004103)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(193276004103)
            
            //--TRIMMABLE-BOUNDARY-START(193276004103)
            //--TRIMMABLE-BOUNDARY-START(42952148743)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952148743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(42952148743)
            
            //--TRIMMABLE-BOUNDARY-START(210455873287)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455873287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(210455873287)
            
            //--TRIMMABLE-BOUNDARY-END(193276004103)
            
            //--TRIMMABLE-BOUNDARY-START(158916265735)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(158916265735)
            
            //--TRIMMABLE-BOUNDARY-START(154621298439)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154621298439)
            
            //--TRIMMABLE-BOUNDARY-START(150326331143)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326331143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(150326331143)
            
            //--TRIMMABLE-BOUNDARY-START(176096134919)
            /*ValueTask *//*async*/  OnSenderPaired(/*IWalletHolder*/ sender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176096134919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.sender = sender;
                    ($t5 = this.Forward(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    ($t6 = this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176096134919)
            
            //--TRIMMABLE-BOUNDARY-START(180391102215)
            /*ValueTask *//*async*/  OnTokenReceived(/*IWalletHolder*/ $from, /*IEnumerable<IWalletToken>*/ tokens)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180391102215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.receivedTokens = tokens;
                    ($t7 = this.Forward(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    ($t8 = this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(180391102215)
            
            //--TRIMMABLE-BOUNDARY-START(68721952519)
            /*Task */ Finish()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721952519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.step = 1;
                return this.OnFinished.InvokeAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(68721952519)
            
            //--TRIMMABLE-BOUNDARY-START(64426985223)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426985223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.receiving?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(64426985223)
            
            //--TRIMMABLE-BOUNDARY-START(163211233031)
            /*string?*/ messageReport = null;
            //--TRIMMABLE-BOUNDARY-END(163211233031)
            
            //--TRIMMABLE-BOUNDARY-START(188981036807)
            /*float*/ progressReport = 0;
            //--TRIMMABLE-BOUNDARY-END(188981036807)
            
            //--TRIMMABLE-BOUNDARY-START(214750840583)
            /*void */ ReportMessage(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750840583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.messageReport = message;
                this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(214750840583)
            
            //--TRIMMABLE-BOUNDARY-START(219045807879)
            /*void */ ReportProgress(/*float*/ progress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045807879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.progressReport = progress;
                this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(219045807879)
            
            //--TRIMMABLE-BOUNDARY-START(184686069511)
            /*string */ get OptimizedComponentName()
            {
                return "walletreceive";
            }
            //--TRIMMABLE-BOUNDARY-END(184686069511)
            
            //--TRIMMABLE-BOUNDARY-START(292060251911)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292060251911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch9 = parameter.Name;
                switch($switch9)
                {
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "WalletReceiveProvider":
                    this.WalletReceiveProvider = $.$cast(parameter.Value, $.$SeJP.LCWCS.IWalletReceiveProvider);
                    return true;
                    case "OnFinished":
                    this.OnFinished = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(292060251911)
            
            //--TRIMMABLE-BOUNDARY-START(146031363847)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031363847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Clipboard = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IClipboardAccessor, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(146031363847)
            
            //--TRIMMABLE-BOUNDARY-START(51542083335)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542083335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, (336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/) & ~32/*LoadingFeatures.Retry*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.IWalletToken>?*/ let __ca1__;
                    switch(this.step)
                    {
                        case 1:
                        if (this.WalletReceiveProvider.LCWCS$IWalletReceiveProvider$SelfAddress.SVG !== null)
                        {
                            __builder2.OpenElement(4, "div");
                            __builder2.AddAttribute$5(5, "class", "pd");
                            __builder2.AddMarkupContent(6, "<h1 class=\"text-center mgt-0\">Let the Sender scan this QR code</h1>\r\n                        ");
                            __builder2.OpenElement(7, "div");
                            __builder2.AddAttribute$5(8, "class", "wf mawf-5 mgx-a mgt-10");
                            __builder2.AddContent$2(9, this.WalletReceiveProvider.LCWCS$IWalletReceiveProvider$SelfAddress.SVG);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        else 
                        {
                            __builder2.OpenElement(10, "div");
                            __builder2.AddAttribute$5(11, "class", "pd text-center");
                            __builder2.AddMarkupContent(12, "<h1 class=\"mgt-0\">Copy this code and share with the sender</h1>\r\n                        ");
                            __builder2.OpenElement(13, "p");
                            __builder2.AddAttribute$5(14, "class", "bg-gray pd mgx-a");
                            __builder2.AddAttribute$5(15, "style", "word-break:break-all");
                            __builder2.AddContent$4(16, this.WalletReceiveProvider.LCWCS$IWalletReceiveProvider$SelfAddress.Address);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(17, "\r\n                        ");
                            __builder2.OpenElement(18, "button");
                            __builder2.AddAttribute$5(19, "class", "bg-primary d-block pd corner miwx-2 mgx-a fw-bold fsz-25");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 20, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.CopyAddress)));
                            __builder2.AddContent$4(21, "Copy");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        break;
                        case 2:
                        __builder2.OpenElement(22, "div");
                        __builder2.AddAttribute$5(23, "class", "text-center pd");
                        __builder2.AddMarkupContent(24, "<h1 class=\"mgt-0\">Sender Info</h1>\r\n                    ");
                        __builder2.OpenElement(25, "div");
                        __builder2.AddAttribute$5(26, "class", "mgx-a");
                        __builder2.AddMarkupContent(27, "<i class=\"mdi mdi-account fsz-100 hx-12 wx-12 bd round d-block mgx-a flex mgc-a\"></i>\r\n                        ");
                        __builder2.OpenElement(28, "h2");
                        __builder2.AddContent$4(29, this.sender.LCFC$IDisplayable$Title);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(30, "\r\n                        ");
                        __builder2.OpenElement(31, "p");
                        __builder2.AddAttribute$5(32, "style", "word-break:break-all");
                        __builder2.AddContent$4(33, this.sender.LCFCW$IWalletHolder$NetworkAddress.Address);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(34, "\r\n                        ");
                        $.$SeJP._LCWCSW.TypeInference.CreatePropertySheet_0($.$OJJQ.LCFCW.IWalletHolder, __builder2, 35, 36, this.sender, 37, "fw-bold", 38, 2, 39, 35184372092928n | 8388608n);
                        __builder2.AddMarkupContent(40, "\r\n                        ");
                        __builder2.OpenElement(41, "p");
                        __builder2.AddAttribute$5(42, "class", "text-center");
                        __builder2.AddContent$4(43, this.messageReport);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(44, "\r\n                        ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 45);
                        __builder2.AddComponentParameter(46, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, ($.$cast((100 * this.progressReport), $.$$.S.Int32))), $.$$.S.Int32));
                        __builder2.AddComponentParameter(47, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                        __builder2.AddComponentParameter(48, "Class", "corner-5 clip");
                        __builder2.AddComponentParameter(49, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                        __builder2.AddComponentParameter(50, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        break;
                        case 3:
                        __builder2.OpenElement(51, "div");
                        __builder2.AddAttribute$5(52, "class", "pd text-center");
                        __builder2.AddMarkupContent(53, "<h1 class=\"mgt-0\">Transaction Successful</h1>\r\n                    <i class=\"mdi mdi-checkbox-marked-circle-outline fsz-100 cl-primary\"></i>\r\n                    ");
                        __builder2.OpenElement(54, "p");
                        __builder2.AddMarkupContent(55, "You have received \u20A6");
                        __builder2.AddContent$4(56, ((__ca1__ = this.receivedTokens) !== null ? $.$$.S.Double.ToString$3.call($.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, __ca1__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.LCFCW$IWalletToken$Amount;
                        }, $NreBnd ??= {"r":1179649,"p":[{"n":"t","p":1357005}],"n":"","d":2475783,"h":0,"f":17825794})), "#,###") : null));
                        __builder2.AddContent$4(57, " from ");
                        __builder2.AddContent$4(58, (this.sender?.LCFC$IDisplayable$Title ?? null));
                        __builder2.AddContent$4(59, "!");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(60, "\r\n                    ");
                        __builder2.OpenElement(61, "button");
                        __builder2.AddAttribute$5(62, "class", "bg-primary d-block pd corner miwx-2 mgx-a fw-bold fsz-25");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 63, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Finish)));
                        __builder2.AddContent$4(64, "Finish");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        break;
                    }
                }), $nWDfJd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2475783,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(51542083335)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(4295800013)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator.OnSenderPaired(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder)
            LCFCW$IWalletPaymentReceiveProgressReportIndicator$OnSenderPaired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295800013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSenderPaired(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295800013)
            
            //--TRIMMABLE-BOUNDARY-START(17180701901)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator.ReportProgress(float)
            LCFCW$IWalletPaymentReceiveProgressReportIndicator$ReportProgress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180701901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReportProgress(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180701901)
            
            //--TRIMMABLE-BOUNDARY-START(12885734605)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator.ReportMessage(string)
            LCFCW$IWalletPaymentReceiveProgressReportIndicator$ReportMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885734605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReportMessage(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885734605)
            
            //--TRIMMABLE-BOUNDARY-START(8590767309)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator.OnTokenReceived(LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.IWalletToken>)
            LCFCW$IWalletPaymentReceiveProgressReportIndicator$OnTokenReceived()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590767309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnTokenReceived(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590767309)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(34362214151)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362214151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362214151)
            
            //--TRIMMABLE-BOUNDARY-START(34362214151)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34362214151)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(300650186503)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(300650186503)
                
                //--TRIMMABLE-BOUNDARY-START(304945153799)
                this.WalletReceiveProvider = null;
                //--TRIMMABLE-BOUNDARY-END(304945153799)
                
                //--TRIMMABLE-BOUNDARY-START(167506200327)
                this.OnFinished = new $.$mac.MAC.EventCallback();
                //--TRIMMABLE-BOUNDARY-END(167506200327)
                
                //--TRIMMABLE-BOUNDARY-START(55837050631)
                this.Clipboard = null;
                //--TRIMMABLE-BOUNDARY-END(55837050631)
                
                //--TRIMMABLE-BOUNDARY-START(296355219207)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(296355219207)
                
                //--TRIMMABLE-BOUNDARY-START(158916265735)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(158916265735)
                
            }
            static $h = 2475783;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(300650186503),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146461959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274880382727,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 2475783,
      "h": 300650186503,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(300650186503),
//--TRIMMABLE-BOUNDARY-START(304945153799),
    {
      "p": 902919,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736396551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283470317319,
        "f": 83886081
      },
      "n": "WalletReceiveProvider",
      "d": 2475783,
      "h": 304945153799,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(304945153799),
//--TRIMMABLE-BOUNDARY-START(167506200327),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376658183,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257700513543,
        "f": 83886081
      },
      "n": "OnFinished",
      "d": 2475783,
      "h": 167506200327,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167506200327),
//--TRIMMABLE-BOUNDARY-START(55837050631),
    {
      "p": 2776488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606854407,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930709767,
        "f": 83886081
      },
      "n": "Clipboard",
      "d": 2475783,
      "h": 55837050631,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55837050631),
//--TRIMMABLE-BOUNDARY-START(296355219207),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556527367,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266290448135,
        "f": 83886081
      },
      "n": "UI",
      "d": 2475783,
      "h": 296355219207,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296355219207),
//--TRIMMABLE-BOUNDARY-START(158916265735),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786723591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249110578951,
        "f": 83886081
      },
      "n": "Loading",
      "d": 2475783,
      "h": 158916265735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158916265735),
//--TRIMMABLE-BOUNDARY-START(154621298439),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196788999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240520644359,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 2475783,
      "h": 154621298439,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154621298439),
//--TRIMMABLE-BOUNDARY-START(184686069511),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966592775,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2475783,
      "h": 184686069511,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184686069511)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171801167623),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2475783,
      "h": 171801167623,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(171801167623),
//--TRIMMABLE-BOUNDARY-START(73016919815),
    {
      "r": 181338113,
      "n": "Forward",
      "d": 2475783,
      "h": 73016919815,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73016919815),
//--TRIMMABLE-BOUNDARY-START(47247116039),
    {
      "r": 65537,
      "n": "Backward",
      "d": 2475783,
      "h": 47247116039,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47247116039),
//--TRIMMABLE-BOUNDARY-START(60132017927),
    {
      "r": 181338113,
      "n": "CopyAddress",
      "d": 2475783,
      "h": 60132017927,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(60132017927),
//--TRIMMABLE-BOUNDARY-START(150326331143),
    {
      "r": 181338113,
      "n": "Load",
      "d": 2475783,
      "h": 150326331143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150326331143),
//--TRIMMABLE-BOUNDARY-START(176096134919),
    {
      "r": 181338113,
      "p": [
        {
          "n": "sender",
          "p": 570573
        }
      ],
      "n": "OnSenderPaired",
      "d": 2475783,
      "h": 176096134919,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(176096134919),
//--TRIMMABLE-BOUNDARY-START(180391102215),
    {
      "r": 181338113,
      "p": [
        {
          "n": "from",
          "p": 570573
        },
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h
        }
      ],
      "n": "OnTokenReceived",
      "d": 2475783,
      "h": 180391102215,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(180391102215),
//--TRIMMABLE-BOUNDARY-START(68721952519),
    {
      "r": 178454529,
      "n": "Finish",
      "d": 2475783,
      "h": 68721952519,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68721952519),
//--TRIMMABLE-BOUNDARY-START(64426985223),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2475783,
      "h": 64426985223,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426985223),
//--TRIMMABLE-BOUNDARY-START(214750840583),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ReportMessage",
      "d": 2475783,
      "h": 214750840583,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214750840583),
//--TRIMMABLE-BOUNDARY-START(219045807879),
    {
      "r": 65537,
      "p": [
        {
          "n": "progress",
          "p": 1114113
        }
      ],
      "n": "ReportProgress",
      "d": 2475783,
      "h": 219045807879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219045807879),
//--TRIMMABLE-BOUNDARY-START(292060251911),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2475783,
      "h": 292060251911,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(292060251911),
//--TRIMMABLE-BOUNDARY-START(146031363847),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2475783,
      "h": 146031363847,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146031363847),
//--TRIMMABLE-BOUNDARY-START(51542083335),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2475783,
      "h": 51542083335,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51542083335)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(287765284615),
    {
      "t": 655361,
      "n": "step",
      "d": 2475783,
      "h": 287765284615,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(287765284615),
//--TRIMMABLE-BOUNDARY-START(223340775175),
    {
      "t": 570573,
      "n": "sender",
      "d": 2475783,
      "h": 223340775175,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(223340775175),
//--TRIMMABLE-BOUNDARY-START(197570971399),
    {
      "t": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,
      "n": "receivedTokens",
      "d": 2475783,
      "h": 197570971399,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(197570971399),
//--TRIMMABLE-BOUNDARY-START(201865938695),
    {
      "t": 91095041,
      "n": "receiving",
      "d": 2475783,
      "h": 201865938695,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(201865938695),
//--TRIMMABLE-BOUNDARY-START(163211233031),
    {
      "t": 1310721,
      "n": "messageReport",
      "d": 2475783,
      "h": 163211233031,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(163211233031),
//--TRIMMABLE-BOUNDARY-START(188981036807),
    {
      "t": 1114113,
      "n": "progressReport",
      "d": 2475783,
      "h": 188981036807,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(188981036807)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34362214151),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2475783,
      "h": 34362214151,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362214151)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(193276004103),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2475783,
        "h": 42952148743,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2475783,
        "h": 210455873287,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2475783,
      "h": 193276004103,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(193276004103)
  ],
  "h": 2475783
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$OJJQ.LCFCW.IWalletPaymentReceiveProgressReportIndicator, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletReceive`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletReceive`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2475783)
        
        

        //--TRIMMABLE-BOUNDARY-START(2344711)
        $asm.$cls(`$SeJP.LCWCS$1.WalletIO`, ($self) => class WalletIO extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(184685938439)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(184685938439)
            
            //--TRIMMABLE-BOUNDARY-START(47246984967)
            /*IClipboardAccessor*/ Clipboard = null;
            //--TRIMMABLE-BOUNDARY-END(47246984967)
            
            //--TRIMMABLE-BOUNDARY-START(120261428999)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(120261428999)
            
            //--TRIMMABLE-BOUNDARY-START(115966461703)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(115966461703)
            
            //--TRIMMABLE-BOUNDARY-START(51541952263)
            /*ValueTask *//*async*/  CopyAddress()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541952263);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Clipboard.LCFCC$IClipboardAccessor$SetAsync($.$OJJQ.LCFCW.WalletAddress.op_Implicit(this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.Toast($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Address copied to clipboard", false), null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51541952263)
            
            //--TRIMMABLE-BOUNDARY-START(55836919559)
            /*ValueTask *//*async*/  CopyBankAccountNumber()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836919559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.Clipboard.LCFCC$IClipboardAccessor$SetAsync(this.bank.AccountNumber), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.Toast($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Account number copied to clipboard", false), null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55836919559)
            
            //--TRIMMABLE-BOUNDARY-START(60131886855)
            /*Task *//*async*/  FundAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131886855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$FundPayment.LCFCW$IWalletFundPaymentProvider$FundAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60131886855)
            
            //--TRIMMABLE-BOUNDARY-START(34362083079)
            /*Money*/ amount;
            //--TRIMMABLE-BOUNDARY-END(34362083079)
            
            //--TRIMMABLE-BOUNDARY-START(38657050375)
            /*BankAccount*/ bank;
            //--TRIMMABLE-BOUNDARY-END(38657050375)
            
            //--TRIMMABLE-BOUNDARY-START(128851363591)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(128851363591)
            
            //--TRIMMABLE-BOUNDARY-START(128851363591)
            //--TRIMMABLE-BOUNDARY-START(30067115783)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067115783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30067115783)
            
            //--TRIMMABLE-BOUNDARY-START(141736265479)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736265479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(141736265479)
            
            //--TRIMMABLE-BOUNDARY-END(128851363591)
            
            //--TRIMMABLE-BOUNDARY-START(133146330887)
            /*Task *//*async*/  ReceiveFundTransfer()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146330887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t5, $r5;
                            let $t6, $r6;
                            this.amount = ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$fPer.LCFCDM.Money, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Fund with Amount", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Please enter how much you want to fund your wallet with", false), new $.$fPer.LCFCDM.Money(), 0n, null, 0, 4, 4131, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            this.bank = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.BankAccount, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)))().$ctor(this,  (/*service*/ service) =>
                            {
                                return service.LCFCP$IBankingRemoteService$BeginReceiveFund($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId($.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers), $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers).LCFCW$IWalletIssuer$CoinDescriptors)), $.$fPer.LCFCDM.Money.op_Implicit(this.amount));
                            }, $WiCHTa ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)).$h,"p":[{"n":"service","p":411416}],"n":"","d":2344711,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        });
                    }, $gJeDWd ??= {"r":181338113,"n":"","d":2344711,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $FiqAnd ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":2344711,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133146330887)
            
            //--TRIMMABLE-BOUNDARY-START(111671494407)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671494407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111671494407)
            
            //--TRIMMABLE-BOUNDARY-START(124556396295)
            /*string */ get OptimizedComponentName()
            {
                return "walletio";
            }
            //--TRIMMABLE-BOUNDARY-END(124556396295)
            
            //--TRIMMABLE-BOUNDARY-START(180390971143)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390971143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch7 = parameter.Name;
                switch($switch7)
                {
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(180390971143)
            
            //--TRIMMABLE-BOUNDARY-START(107376527111)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376527111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Clipboard = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IClipboardAccessor, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(107376527111)
            
            //--TRIMMABLE-BOUNDARY-START(42952017671)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952017671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", $.$strNN($.$strNN($.$strNN($.$strNN((this.Wallet.LCFCW$IWalletSystem$Theme.ToString$1("bg-", null))) + " pdt") + " pdb-10") + " pdx-7") + " text-center");
                    __builder2.AddAttribute$5(6, "style", this.Wallet.LCFCW$IWalletSystem$Theme.ToStyle());
                    __builder2.AddMarkupContent(7, "<i class=\"d-block mgx-a mdi mdi-wallet fsz-40 flex mgc-a bd round wx-05 hx-05\"></i>\r\n        ");
                    __builder2.OpenElement(8, "h2");
                    __builder2.AddContent$4(9, this.Wallet.LCFCW$IWalletSystem$Holder.LCFC$IDisplayable$Title);
                    __builder2.CloseElement();
                    if (this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$FundPayment !== null)
                    {
                        __builder2.OpenElement(10, "div");
                        __builder2.AddAttribute$5(11, "class", "stack");
                        __builder2.OpenElement(12, "button");
                        __builder2.AddAttribute$5(13, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mgx-a" + " wx-05") + " hx-05") + " round") + " bd") + " bdw-2") + " bg-transparent") + " fsz-30") + " ") + $.$strNN(("mdi mdi-plus"/*MaterialDesignIconNames.Plus*/)));
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 14, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.FundAsync)));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(15, "\r\n                ");
                        __builder2.AddMarkupContent(16, "<h4 class=\"mgt-1 mgb-0 mgx-a\">Fund Wallet</h4>");
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(17, "div");
                    __builder2.AddAttribute$5(18, "class", "flex mgt");
                    __builder2.OpenElement(19, "div");
                    __builder2.AddAttribute$5(20, "class", "stack clip mgr text-left");
                    __builder2.OpenElement(21, "span");
                    __builder2.AddMarkupContent(22, "\r\n                    Wallet Address\r\n                    ");
                    __builder2.OpenElement(23, "button");
                    __builder2.AddAttribute$5(24, "class", "mdi mdi-content-copy bg-transparent");
                    __builder2.AddAttribute$5(25, "title", "copy");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 26, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.CopyAddress)));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(27, "\r\n                ");
                    __builder2.OpenElement(28, "b");
                    __builder2.AddContent$4(29, $.$fPer.LCFCS$6.StringExtension.LimitLength(this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress.ToString(), 32, true));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(30, "\r\n            <div class=\"fill\"></div>\r\n            ");
                    __builder2.OpenElement(31, "div");
                    __builder2.AddAttribute$5(32, "class", "mgy-a");
                    __builder2.OpenElement(33, "h2");
                    __builder2.AddAttribute$5(34, "class", "mg-0");
                    __builder2.AddContent$4(35, $.$strNN($.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers).LCFCW$IWalletIssuer$CurrencyUnit) + $.$strNN($.$$.S.Double.ToString$3.call(this.Wallet.LCFCW$IWalletSystem$GetTotal(), "#,##0.##")));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(36, "\r\n    ");
                    __builder2.OpenElement(37, "div");
                    __builder2.AddAttribute$5(38, "class", "pd");
                    __builder2.AddMarkupContent(39, "<h2 class=\"mgt-0\">Wallet Funding</h2>\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 40);
                    __builder2.AddComponentParameter(41, "Exclusive", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                    __builder2.AddAttribute$3(42, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers) === 1 && $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers).LCFCW$IWalletIssuer$CoinDescriptors) === 1)
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 43);
                            __builder3.AddComponentParameter(44, "Class", "bg-card pd shadow mgb-10 corner-3");
                            __builder3.AddAttribute$3(45, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*selected*/ selected) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(46, "div");
                                    __builder4.AddAttribute$5(47, "class", "row");
                                    __builder4.AddMarkupContent(48, "<div class=\"col-a\"><i class=\"mdi mdi-bank fsz-20\"></i></div>\r\n                            ");
                                    __builder4.AddMarkupContent(49, "<div class=\"pdl col-10 stack\"><h3 class=\"mgy-a\">Bank Transfer</h3></div>\r\n                            ");
                                    __builder4.OpenElement(50, "div");
                                    __builder4.AddAttribute$5(51, "class", "col-a");
                                    __builder4.OpenElement(52, "i");
                                    __builder4.AddAttribute$5(53, "class", $.$strNN($.$strNN("mdi" + " mdi-chevron-") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(selected) ? "down" : "up"))) + " fsz-20");
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                }, $pHkfZa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794});
                            }), $pdpbQh ??= {"r":6881395,"p":[{"n":"selected","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2344711,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(54, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    if (this.bank.Bank.Name === null)
                                    {
                                        __builder4.AddMarkupContent(55, "<p>\r\n                                To fund your account via bank transfer, click <b>Create Account</b>\r\n                                and we will generate an account number for you to transfer to.\r\n                            </p>\r\n                            ");
                                        __builder4.OpenElement(56, "button");
                                        __builder4.AddAttribute$5(57, "class", "bg-primary corner pd wf fw-bold");
                                        __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 58, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ReceiveFundTransfer)));
                                        __builder4.AddContent$4(59, "Create Account");
                                        __builder4.CloseElement();
                                    }
                                    else 
                                    {
                                        __builder4.OpenElement(60, "p");
                                        __builder4.AddContent$4(61, "Make a ");
                                        __builder4.OpenElement(62, "b");
                                        __builder4.AddAttribute$5(63, "class", "cl-primary");
                                        __builder4.AddContent$3(64, $.$clone(this.amount));
                                        __builder4.CloseElement();
                                        __builder4.AddContent$4(65, " bank transfer to ");
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(66, "\r\n                            ");
                                        __builder4.OpenElement(67, "p");
                                        __builder4.AddAttribute$5(68, "class", "fw-bold fsz-20 mgb-0");
                                        __builder4.AddMarkupContent(69, "\r\n                                Bank Name: ");
                                        __builder4.OpenElement(70, "span");
                                        __builder4.AddAttribute$5(71, "class", "cl-primary");
                                        __builder4.AddContent$4(72, this.bank.Bank.Name);
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(73, "\r\n                            ");
                                        __builder4.OpenElement(74, "p");
                                        __builder4.AddAttribute$5(75, "class", "fw-bold fsz-20 mg-0");
                                        __builder4.AddMarkupContent(76, "\r\n                                Account Number: ");
                                        __builder4.OpenElement(77, "span");
                                        __builder4.AddAttribute$5(78, "class", "cl-primary");
                                        __builder4.AddContent$4(79, this.bank.AccountNumber);
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(80, "\r\n                            ");
                                        __builder4.OpenElement(81, "p");
                                        __builder4.AddAttribute$5(82, "class", "fw-bold fsz-20 mgt-0");
                                        __builder4.AddMarkupContent(83, "\r\n                                Account Name: ");
                                        __builder4.OpenElement(84, "span");
                                        __builder4.AddAttribute$5(85, "class", "cl-primary");
                                        __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 86, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.CopyBankAccountNumber)));
                                        __builder4.AddContent$4(87, this.bank.AccountName);
                                        __builder4.AddMarkupContent(88, " <i class=\"mdi mdi-content-copy\"></i>");
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                        if (this.bank.Validity !== null)
                                        {
                                            __builder4.OpenElement(89, "p");
                                            __builder4.AddMarkupContent(90, "\r\n                                    This is a ");
                                            __builder4.AddMarkupContent(91, "<b>one time usage account</b> and it expires in\r\n                                    ");
                                            __builder4.OpenElement(92, "b");
                                            __builder4.AddContent$4(93, $.$fPer.LCFCDC.DateTimeExtension.DHMS($.$$.S.Nullable$$($.$$.S.TimeSpan).Value$get.call(this.bank.Validity), 2147483647/*DateTimeMask.All*/ & ~1/*DateTimeMask.Second*/));
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(94, ".\r\n                                ");
                                            __builder4.CloseElement();
                                        }
                                        __builder4.AddMarkupContent(95, "<p>\r\n                                The amount transfered will be added to your wallet automatically.\r\n                            </p>");
                                    }
                                }, $aNYoyb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794});
                            }), $sMeBAd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2344711,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                        __builder3.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 96);
                        __builder3.AddComponentParameter(97, "Class", "bg-card pd shadow mgb-10 corner-3");
                        __builder3.AddAttribute$3(98, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*selected*/ selected) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(99, "div");
                                __builder4.AddAttribute$5(100, "class", "row");
                                __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 101, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.FundAsync)));
                                __builder4.AddMarkupContent(102, "<div class=\"col-a\"><i class=\"mdi mdi-smart-card fsz-20\"></i></div>\r\n                        ");
                                __builder4.AddMarkupContent(103, "<div class=\"pdl col-10 stack\"><h3 class=\"mgy-a\">Others</h3></div>\r\n                        ");
                                __builder4.OpenElement(104, "div");
                                __builder4.AddAttribute$5(105, "class", "col-a");
                                __builder4.OpenElement(106, "i");
                                __builder4.AddAttribute$5(107, "class", $.$strNN($.$strNN("mdi" + " mdi-chevron-") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(selected) ? "down" : "up"))) + " fsz-20");
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }, $lvFkJf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794});
                        }), $ymLWil ??= {"r":6881395,"p":[{"n":"selected","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2344711,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(108, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                            }, $IKZOFi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794});
                        }), $iMCsol ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2344711,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $LaTaqk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(109, "\r\n\r\n        ");
                    __builder2.AddMarkupContent(110, "<h2>Recent Transactions</h2>\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$OJJQ.LCFCW.IWalletTransaction), 111);
                    __builder2.AddComponentParameter(112, "Pager", new ($.$fPer.LCFCD.Pager$$($.$OJJQ.LCFCW.IWalletTransaction))().$ctor(this, (this.Wallet.LCFCW$IWalletSystem$GetTransactions)));
                    __builder2.AddComponentParameter(113, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddAttribute$3(114, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OJJQ.LCFCW.IWalletTransaction))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$SeJP.LCWCS$1.WalletTransactionListItem, 115);
                            __builder3.AddComponentParameter(116, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletTransaction, context.Data));
                            __builder3.AddComponentParameter(117, "Wallet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Wallet));
                            __builder3.CloseComponent();
                        }, $VAgUJa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794});
                    }), $kJVCUb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OJJQ.LCFCW.IWalletTransaction)).$h}],"n":"","d":2344711,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(118, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 119);
                        __builder3.AddComponentParameter(120, "Message", "You transaction will appear here");
                        __builder3.CloseComponent();
                    }), $QDaWRi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                }), $vvxcPd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2344711,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(42952017671)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21477181191)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477181191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477181191)
            
            //--TRIMMABLE-BOUNDARY-START(21477181191)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21477181191)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(184685938439)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(184685938439)
                
                //--TRIMMABLE-BOUNDARY-START(47246984967)
                this.Clipboard = null;
                //--TRIMMABLE-BOUNDARY-END(47246984967)
                
                //--TRIMMABLE-BOUNDARY-START(120261428999)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(120261428999)
                
                //--TRIMMABLE-BOUNDARY-START(34362083079)
                this.amount = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(34362083079)
                
                //--TRIMMABLE-BOUNDARY-START(38657050375)
                this.bank = $.$default($.$fPer.LCFCD.BankAccount);
                //--TRIMMABLE-BOUNDARY-END(38657050375)
                
            }
            static $h = 2344711;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(184685938439),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081559815,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176096003847,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 2344711,
      "h": 184685938439,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685938439),
//--TRIMMABLE-BOUNDARY-START(47246984967),
    {
      "p": 2776488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721821447,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150326200071,
        "f": 83886081
      },
      "n": "Clipboard",
      "d": 2344711,
      "h": 47246984967,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246984967),
//--TRIMMABLE-BOUNDARY-START(120261428999),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901690631,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167506069255,
        "f": 83886081
      },
      "n": "Loading",
      "d": 2344711,
      "h": 120261428999,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261428999),
//--TRIMMABLE-BOUNDARY-START(115966461703),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311756039,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158916134663,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 2344711,
      "h": 115966461703,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966461703),
//--TRIMMABLE-BOUNDARY-START(124556396295),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491625223,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2344711,
      "h": 124556396295,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124556396295)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541952263),
    {
      "r": 181338113,
      "n": "CopyAddress",
      "d": 2344711,
      "h": 51541952263,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(51541952263),
//--TRIMMABLE-BOUNDARY-START(55836919559),
    {
      "r": 181338113,
      "n": "CopyBankAccountNumber",
      "d": 2344711,
      "h": 55836919559,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(55836919559),
//--TRIMMABLE-BOUNDARY-START(60131886855),
    {
      "r": 178454529,
      "n": "FundAsync",
      "d": 2344711,
      "h": 60131886855,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(60131886855),
//--TRIMMABLE-BOUNDARY-START(133146330887),
    {
      "r": 178454529,
      "n": "ReceiveFundTransfer",
      "d": 2344711,
      "h": 133146330887,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(133146330887),
//--TRIMMABLE-BOUNDARY-START(111671494407),
    {
      "r": 181338113,
      "n": "Load",
      "d": 2344711,
      "h": 111671494407,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111671494407),
//--TRIMMABLE-BOUNDARY-START(180390971143),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2344711,
      "h": 180390971143,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180390971143),
//--TRIMMABLE-BOUNDARY-START(107376527111),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2344711,
      "h": 107376527111,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107376527111),
//--TRIMMABLE-BOUNDARY-START(42952017671),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2344711,
      "h": 42952017671,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42952017671)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34362083079),
    {
      "t": 27822422,
      "n": "amount",
      "d": 2344711,
      "h": 34362083079,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34362083079),
//--TRIMMABLE-BOUNDARY-START(38657050375),
    {
      "t": 5474646,
      "n": "bank",
      "d": 2344711,
      "h": 38657050375,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38657050375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477181191),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2344711,
      "h": 21477181191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477181191)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(128851363591),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2344711,
        "h": 30067115783,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2344711,
        "h": 141736265479,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2344711,
      "h": 128851363591,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(128851363591)
  ],
  "h": 2344711
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletIO`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletIO`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2344711)
        
        

        //--TRIMMABLE-BOUNDARY-START(1099527)
        $asm.$cls(`$SeJP.LCWCS.WalletApplication`, ($self) => class WalletApplication extends $.$sZVd.LCFCA.BaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(124555151111)
            /*Theme*/ static GlobalTheme;
            //--TRIMMABLE-BOUNDARY-END(124555151111)
            
            //--TRIMMABLE-BOUNDARY-START(17180968711)
            $ctor$3(/*WalletService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180968711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180968711)
            
            //--TRIMMABLE-BOUNDARY-START(133145085703)
            /*string */ get Name()
            {
                return "Coins";
            }
            //--TRIMMABLE-BOUNDARY-END(133145085703)
            
            //--TRIMMABLE-BOUNDARY-START(154619922183)
            /*string */ get Title()
            {
                return "Coins";
            }
            //--TRIMMABLE-BOUNDARY-END(154619922183)
            
            //--TRIMMABLE-BOUNDARY-START(25770903303)
            /*string */ get Description()
            {
                return "Zoey Coins are store of values, a virtual wallet system of Zoey";
            }
            //--TRIMMABLE-BOUNDARY-END(25770903303)
            
            //--TRIMMABLE-BOUNDARY-START(128850118407)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-hand-coin"/*MaterialDesignIconNames.HandCoin*/);
            }
            //--TRIMMABLE-BOUNDARY-END(128850118407)
            
            //--TRIMMABLE-BOUNDARY-START(150324954887)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$SeJP.LCWCS.WalletApplication.GlobalTheme);
            }
            //--TRIMMABLE-BOUNDARY-END(150324954887)
            
            //--TRIMMABLE-BOUNDARY-START(34360837895)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360837895)
            
            //--TRIMMABLE-BOUNDARY-START(21475936007)
            /*Type? */ get ApplicationViewType()
            {
                return $.$SeJP.LCWCP.WalletApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475936007)
            
            //--TRIMMABLE-BOUNDARY-START(30065870599)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065870599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(30065870599)
            
            //--TRIMMABLE-BOUNDARY-START(141735020295)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735020295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(141735020295)
            
            //--TRIMMABLE-BOUNDARY-START(137440052999)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(137440052999)
            
            //--TRIMMABLE-BOUNDARY-START(4296066823)
            /*WalletService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4296066823)
            
            //--TRIMMABLE-BOUNDARY-START(146029987591)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(146029987591)
            
            //--TRIMMABLE-BOUNDARY-START(12886001415)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886001415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(124555151111)
                    this.GlobalTheme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t1 = $.$fPer.LCFC.Theme;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.BackgroundColor = "#00AEFF";
                        $i1.ForegroundColor = "#FFF";
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(124555151111)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886001415)
            
            static $h = 1099527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.BaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133145085703),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900445447,
        "f": 50364417
      },
      "n": "Name",
      "d": 1099527,
      "h": 133145085703,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145085703),
//--TRIMMABLE-BOUNDARY-START(154619922183),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260183815,
        "f": 50364417
      },
      "n": "Title",
      "d": 1099527,
      "h": 154619922183,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619922183),
//--TRIMMABLE-BOUNDARY-START(25770903303),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130641671,
        "f": 50364417
      },
      "n": "Description",
      "d": 1099527,
      "h": 25770903303,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770903303),
//--TRIMMABLE-BOUNDARY-START(128850118407),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310510855,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1099527,
      "h": 128850118407,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128850118407),
//--TRIMMABLE-BOUNDARY-START(150324954887),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670249223,
        "f": 50364417
      },
      "n": "Theme",
      "d": 1099527,
      "h": 150324954887,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324954887),
//--TRIMMABLE-BOUNDARY-START(34360837895),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720576263,
        "f": 50364417
      },
      "n": "Features",
      "d": 1099527,
      "h": 34360837895,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360837895),
//--TRIMMABLE-BOUNDARY-START(21475936007),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540707079,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 1099527,
      "h": 21475936007,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475936007),
//--TRIMMABLE-BOUNDARY-START(137440052999),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490380039,
        "f": 50364417
      },
      "n": "Order",
      "d": 1099527,
      "h": 137440052999,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137440052999),
//--TRIMMABLE-BOUNDARY-START(4296066823),
    {
      "p": 1558279,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950772487,
        "f": 50331650
      },
      "n": "_Service",
      "d": 1099527,
      "h": 4296066823,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4296066823),
//--TRIMMABLE-BOUNDARY-START(146029987591),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080314631,
        "f": 50364417
      },
      "n": "Service",
      "d": 1099527,
      "h": 146029987591,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029987591)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065870599),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 1099527,
      "h": 30065870599,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065870599),
//--TRIMMABLE-BOUNDARY-START(141735020295),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 1099527,
      "h": 141735020295,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735020295)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124555151111),
    {
      "t": 65309014,
      "n": "GlobalTheme",
      "d": 1099527,
      "h": 124555151111,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555151111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180968711),
    {
      "p": [
        {
          "n": "service",
          "p": 1558279
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1099527,
      "h": 17180968711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180968711)
  ],
  "h": 1099527
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$GfYa.LCFCA.IAuthenticationClient, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1099527)
        
        

        //--TRIMMABLE-BOUNDARY-START(2148103)
        $asm.$cls(`$SeJP.LCWCS$1.WalletHome`, ($self) => class WalletHome extends $.$hDPm.LCFCC$1.BaseContainer
        {
            //--TRIMMABLE-BOUNDARY-START(223340447495)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(223340447495)
            
            //--TRIMMABLE-BOUNDARY-START(124556199687)
            /*RenderFragment?*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(124556199687)
            
            //--TRIMMABLE-BOUNDARY-START(128851166983)
            /*RenderFragment?*/ HeaderControls = null;
            //--TRIMMABLE-BOUNDARY-END(128851166983)
            
            //--TRIMMABLE-BOUNDARY-START(133146134279)
            /*RenderFragment?*/ NoTransactions = null;
            //--TRIMMABLE-BOUNDARY-END(133146134279)
            
            //--TRIMMABLE-BOUNDARY-START(210455545607)
            /*RenderFragment<(IWalletTransaction, PaymentModel?)>?*/ TransactionDetailView = null;
            //--TRIMMABLE-BOUNDARY-END(210455545607)
            
            //--TRIMMABLE-BOUNDARY-START(47246788359)
            /*WalletHomeFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(47246788359)
            
            //--TRIMMABLE-BOUNDARY-START(214750512903)
            /*PagingForEach<IWalletTransaction>?*/ TransactionsPager = null;
            //--TRIMMABLE-BOUNDARY-END(214750512903)
            
            //--TRIMMABLE-BOUNDARY-START(146031036167)
            /*ValueTask */ Send()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031036167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this.Wallet, $.$SeJP.LCWCS.IWalletSendProvider))
                {
                    return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletSend, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                    {
                        b.AddAttribute$4(1, "Wallet", this.Wallet);
                        b.AddAttribute$4(2, "WalletSendProvider", this.Wallet);
                    }, $PwWOXa ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":2148103,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t1 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.BodyAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t2 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bg-card");
                            return $i2;
                        })();
                        return $i1;
                    })());
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(146031036167)
            
            //--TRIMMABLE-BOUNDARY-START(141736068871)
            /*ValueTask */ Receive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736068871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this.Wallet, $.$SeJP.LCWCS.IWalletReceiveProvider))
                {
                    return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletReceive, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                    {
                        b.AddAttribute$4(1, "Wallet", this.Wallet);
                        b.AddAttribute$4(2, "WalletReceiveProvider", this.Wallet);
                    }, $mqLSii ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":2148103,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.BodyAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t4 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i4 = new $t4();
                            $i4.$ctor$1();
                            $i4.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bg-card");
                            return $i4;
                        })();
                        return $i3;
                    })());
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(141736068871)
            
            //--TRIMMABLE-BOUNDARY-START(227635414791)
            /*ValueTask *//*async*/  WithdrawToBank()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227635414791);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers) === 1 && $.$is(this.Wallet, $.$SeJP.LCWCS.IWalletSendProvider))
                    {
                        let $t5, $r5;
                        ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletSend, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ b, /*i*/ i) =>
                        {
                            b.AddAttribute$4(1, "Wallet", this.Wallet);
                            b.AddAttribute$4(2, "WalletSendProvider", new $.$SeJP.LCFCS.WithdrawToBankWalletSendProvider().$ctor$1($.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers), this.UnitOfWork));
                        }, $KFqMtf ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":2148103,"h":0,"f":17825794}), null, (() =>
                        {
                            //new $.$hDPm.LCFCI.ViewConfiguration()
                            const $t6 = $.$hDPm.LCFCI.ViewConfiguration;
                            const $i6 = new $t6();
                            $i6.$ctor$2();
                            $i6.BodyAttributes = (() =>
                            {
                                //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                                const $t7 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                                const $i7 = new $t7();
                                $i7.$ctor$1();
                                $i7.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bg-card");
                                return $i7;
                            })();
                            $i6.ViewFeatures = 63203/*ViewFeatures.DrawerDefault*/ & ~1/*ViewFeatures.OKToolBar*/ & ~2/*ViewFeatures.CancelToolBar*/;
                            return $i6;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        let system;
                        if ($.$is(this.Wallet, $.$SeJP.LCWCS.WalletSystem, { set $v($v){ system = $v; } }))
                        {
                            let $t8, $r8;
                            ($t8 = system.Load(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(227635414791)
            
            //--TRIMMABLE-BOUNDARY-START(137441101575)
            /*string */ get OptimizedComponentName()
            {
                return "wallethome";
            }
            //--TRIMMABLE-BOUNDARY-END(137441101575)
            
            //--TRIMMABLE-BOUNDARY-START(219045480199)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045480199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch9 = parameter.Name;
                switch($switch9)
                {
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "Header":
                    this.Header = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "HeaderControls":
                    this.HeaderControls = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "NoTransactions":
                    this.NoTransactions = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "TransactionDetailView":
                    this.TransactionDetailView = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel)));
                    return true;
                    case "Features":
                    this.Features = $.$cast(parameter.Value, $.$SeJP.LCWCS$1.WalletHomeFeatures);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(219045480199)
            
            //--TRIMMABLE-BOUNDARY-START(42951821063)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951821063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.OwnAttributes(null), "stack pos-rel"))));
                if (this.Header !== null)
                {
                    __builder.AddContent$1(2, this.Header);
                }
                else 
                {
                    __builder.OpenComponent$1($.$SeJP.LCWCS$1.WalletHeader, 3);
                    __builder.AddComponentParameter(4, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Wallet));
                    __builder.AddComponentParameter(5, "Controls", (this.HeaderControls));
                    __builder.CloseComponent();
                }
                __builder.OpenElement(6, "div");
                __builder.AddMultipleAttributes(7, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.AttributesFor("body"), `pos-rel fill scroll ${$.$strNN((this.ChildContent === null ? "mgt--15 corner-t-10" : ""))}  z-2 ${$.$strNN(($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Issuers) === 1 ? "pd" : ""))}`))));
                __builder.AddContent$1(8, this.ChildContent);
                __builder.AddMarkupContent(9, "\r\n        ");
                __builder.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 10);
                __builder.AddComponentParameter(11, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, this.Wallet.LCFCW$IWalletSystem$Theme));
                __builder.AddComponentParameter(12, "tabshead-class", `${$.$strNN(this.Wallet.LCFCW$IWalletSystem$Theme.WithOpacity(0.2).ToString$1("bg-", null))} fw-bold`);
                __builder.AddComponentParameter(13, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 15);
                    __builder2.AddComponentParameter(16, "Class", "pdt");
                    __builder2.AddAttribute$3(17, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(18, "Recent Transactions");
                        }, $pHukBb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
                    }), $wDqAWc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2148103,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(20, this.GetTransactions());
                        }, $vUqtvk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
                    }), $DVvBHe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2148103,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(21, "\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 22);
                    __builder2.AddComponentParameter(23, "Class", "pdt");
                    __builder2.AddAttribute$3(24, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(25, "Denominations");
                        }, $aIoBWg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
                    }), $RZMSnd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2148103,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(26, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            /*var*/ let count = 0;
                            let $en10 = this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers.SCG$IEnumerable$$$GetEnumerator();
                            while ($en10.SC$1$IEnumerator$MoveNext())
                            {
                                let issuer = $en10.SCG$IEnumerator$$$Current;
                                {
                                    let $en11 = issuer.LCFCW$IWalletIssuer$CoinDescriptors.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en11.SC$1$IEnumerator$MoveNext())
                                    {
                                        let coin = $en11.SCG$IEnumerator$$$Current;
                                        {
                                            /*var*/ let tokens = $.$sl.SL.Enumerable.SingleOrDefault$1($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.Wallet.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                                            {
                                                return t.SL$IGrouping$$$$Key === issuer.LCFC$INamed$Name;
                                            }, $KrIvab ??= {"r":262145,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":2148103,"h":0,"f":17825794}));
                                            /*System.Linq.IGrouping<string, LivingThing.Core.Frameworks.Common.Wallet.IWalletToken>?*/ let __ca1__;
                                            /*var*/ let mtokens = ((__ca1__ = tokens) !== null ? $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.IWalletToken, __ca1__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                                            {
                                                return t.LCFCW$IWalletToken$Amount <= 0 || (coin.Amount > 0 && t.LCFCW$IWalletToken$Amount === coin.Amount);
                                            }, $xzjFka ??= {"r":262145,"p":[{"n":"t","p":1357005}],"n":"","d":2148103,"h":0,"f":17825794})) : null);
                                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.IWalletToken>?*/ let __ca2__;
                                            /*var*/ let amount = ((__ca2__ = mtokens) !== null ? $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, __ca2__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                                            {
                                                return $.$OJJQ.LCFCW.CoinTokenExtension.GetAmount(t, issuer);
                                            }, $ZOIvPf ??= {"r":1179649,"p":[{"n":"t","p":1357005}],"n":"","d":2148103,"h":0,"f":17825794})) : 0);
                                            if (amount > 0)
                                            {
                                                count++;
                                                __builder3.OpenElement(27, "div");
                                                __builder3.AddAttribute$5(28, "class", "flex pdy-1 bdb");
                                                __builder3.OpenElement(29, "div");
                                                __builder3.AddAttribute$5(30, "class", "wx-1 flex mgy-a");
                                                __builder3.OpenComponent$1($.$hDPm.LCFCCI.Icon, 31);
                                                __builder3.AddComponentParameter(32, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, coin.Icon));
                                                __builder3.AddComponentParameter(33, "Class", "mawx-07 mgy-a mahx-07");
                                                __builder3.CloseComponent();
                                                __builder3.CloseElement();
                                                __builder3.AddMarkupContent(34, "\r\n                                    ");
                                                __builder3.OpenElement(35, "div");
                                                __builder3.AddAttribute$5(36, "class", "stack mgy-a mgl fill fsz-15");
                                                __builder3.OpenElement(37, "b");
                                                __builder3.AddContent$4(38, coin.Name);
                                                __builder3.AddContent$4(39, " x ");
                                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.IWalletToken>?*/ let __ca3__;
                                                __builder3.AddContent$3(40, $.$box(($.$box((__ca3__ = mtokens) !== null ? $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletToken, __ca3__) : 0, $.$$.S.Int32)), $.$$.S.Int32));
                                                __builder3.AddContent$4(41, " pcs");
                                                __builder3.CloseElement();
                                                __builder3.CloseElement();
                                                __builder3.AddMarkupContent(42, "\r\n                                    ");
                                                __builder3.OpenElement(43, "h3");
                                                __builder3.AddAttribute$5(44, "class", "mgy-a fsz-20");
                                                __builder3.AddContent$4(45, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                                __builder3.AddContent$3(46, $.$box(amount, $.$$.S.Double));
                                                __builder3.CloseElement();
                                                __builder3.CloseElement();
                                            }
                                        }
                                    }
                                }
                            }
                            if (count === 0)
                            {
                                __builder3.AddMarkupContent(47, "<i class=\"mgy-5 mdi mdi-flask-empty fsz-100 d-block flex mgc-a cl-primary op-4\"></i>\r\n                        ");
                                __builder3.OpenElement(48, "p");
                                __builder3.AddAttribute$5(49, "class", "text-center");
                                __builder3.AddContent$4(50, "Your ");
                                __builder3.AddContent$4(51, this.Wallet.LCFCW$IWalletSystem$Name);
                                __builder3.AddContent$4(52, " denominations will appear here");
                                __builder3.CloseElement();
                            }
                            else 
                            {
                            }
                        }, $nIXtsj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
                    }), $zXDtak ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":2148103,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $NvgWlf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                if (((this.Features & (1/*WalletHomeFeatures.ToolBarControls*/)) == (1/*WalletHomeFeatures.ToolBarControls*/)))
                {
                    __builder.AddContent$1(53, this.BottomToolBarControls(true));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951821063)
            
            //--TRIMMABLE-BOUNDARY-START(38656853767)
            /*RenderFragment? */ BottomToolBarControls(/*bool*/ _internal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656853767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this.Wallet, $.$SeJP.LCWCS.IWalletSendProvider) || $.$is(this.Wallet, $.$SeJP.LCWCS.IWalletReceiveProvider))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(54, "div");
                        __builder2.AddAttribute$5(55, "class", $.$strNN("flex" + " ") + $.$strNN((_internal ? "pos-abs l-0 b-0 r-0 z-2 mgb-20" : "pd")));
                        __builder2.OpenElement(56, "div");
                        __builder2.AddAttribute$5(57, "class", "mgx-a");
                        __builder2.OpenElement(58, "popup");
                        __builder2.AddAttribute$5(59, "class", "pos-rel");
                        __builder2.AddMarkupContent(60, "<button class=\"mdi mdi-swap-horizontal bg-primary fsz-25 corner-5 miwx-06\"></button>\r\n                        ");
                        __builder2.OpenElement(61, "pop");
                        __builder2.AddAttribute$5(62, "class", "at bottomtobottom centerx");
                        __builder2.OpenElement(63, "div");
                        __builder2.AddAttribute$5(64, "class", "flex");
                        __builder2.OpenElement(65, "button");
                        __builder2.AddAttribute$5(66, "class", "bg-primary corner-5 pdx-4 pdy-2 miwx-07");
                        __builder2.AddAttribute$5(67, "style", "position:relative;top:-30px;left:20px");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 68, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Send)));
                        __builder2.AddMarkupContent(69, "\r\n                                    Send\r\n                                ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(70, "\r\n                                <i class=\"mdi mdi-arrow-up-left\"></i>\r\n                                ");
                        __builder2.OpenElement(71, "button");
                        __builder2.AddAttribute$5(72, "class", "bg-primary corner-5 pdx-4 pdy-2 miwx-07 mgx-5");
                        __builder2.AddAttribute$5(73, "style", "position:relative;top:-40px;");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 74, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.WithdrawToBank)));
                        __builder2.AddMarkupContent(75, "\r\n                                    Withdraw\r\n                                ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(76, "\r\n                                <i class=\"mdi mdi-arrow-up-right\"></i>\r\n                                ");
                        __builder2.OpenElement(77, "button");
                        __builder2.AddAttribute$5(78, "class", "bg-primary corner-5 pdx-4 pdy-2 miwx-07");
                        __builder2.AddAttribute$5(79, "style", "position:relative;top:-30px;left:-20px");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 80, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Receive)));
                        __builder2.AddMarkupContent(81, "\r\n                                    Receive\r\n                                ");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $UYcQke ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(38656853767)
            
            //--TRIMMABLE-BOUNDARY-START(120261232391)
            /*RenderFragment */ GetTransactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261232391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let seq = (($.$as(this.Wallet, $.$SeJP.LCWCS.WalletSystem))?.RecentTransactionSequenceNumber ?? null) ?? 0;
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(82, "\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCP$2.PagingForEach$$($.$OJJQ.LCFCW.IWalletTransaction), 83);
                    __builder2.AddComponentParameter(84, "Pager", (this.Wallet.LCFCW$IWalletSystem$RecentTransactions));
                    __builder2.AddComponentParameter(85, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddAttribute$3(86, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OJJQ.LCFCW.IWalletTransaction))))().$ctor(this, ( (/*transaction*/ transaction) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$SeJP.LCWCS$1.WalletTransactionListItem, 87);
                            __builder3.AddComponentParameter(88, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletTransaction, transaction.Data));
                            __builder3.AddComponentParameter(89, "Wallet", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OJJQ.LCFCW.IWalletSystem, this.Wallet));
                            __builder3.AddComponentParameter(90, "TransactionDetailView", (this.TransactionDetailView));
                            __builder3.CloseComponent();
                        }, $tbXHgb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
                    }), $TOCxSk ??= {"r":6881395,"p":[{"n":"transaction","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OJJQ.LCFCW.IWalletTransaction)).$h}],"n":"","d":2148103,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(91, "Empty", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListDataManager$$($.$OJJQ.LCFCW.IWalletTransaction)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (this.NoTransactions !== null)
                            {
                                __builder3.AddContent$1(92, this.NoTransactions);
                            }
                            else 
                            {
                                __builder3.AddMarkupContent(93, "<i class=\"mgy-5 mdi mdi-flask-empty fsz-100 d-block flex mgc-a cl-primary op-4\"></i>\r\n                        ");
                                __builder3.OpenElement(94, "p");
                                __builder3.AddAttribute$5(95, "class", "text-center");
                                __builder3.AddContent$4(96, "Your ");
                                __builder3.AddContent$4(97, this.Wallet.LCFCW$IWalletSystem$Name);
                                __builder3.AddContent$4(98, " transactions will appear here");
                                __builder3.CloseElement();
                            }
                        }, $iZQUrg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
                    }), $chOAOb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListDataManager$$($.$OJJQ.LCFCW.IWalletTransaction).$h}],"n":"","d":2148103,"h":0,"f":17825794}));
                    __builder2.SetKey($.$box(seq, $.$$.S.Int32));
                    __builder2.AddComponentReferenceCapture(99, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/**/ __value) =>
                    {
                        this.TransactionsPager = $.$cast(__value, $.$hDPm.LCFCCP$2.PagingForEach$$($.$OJJQ.LCFCW.IWalletTransaction));
                    }, $pMFRJi ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":2148103,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(100, "\r\n        ");
                }, $VAvvXd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2148103,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(120261232391)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(34361886471)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361886471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361886471)
            
            //--TRIMMABLE-BOUNDARY-START(34361886471)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(34361886471)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(223340447495)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(223340447495)
                
                //--TRIMMABLE-BOUNDARY-START(47246788359)
                this.Features = 1;
                //--TRIMMABLE-BOUNDARY-END(47246788359)
                
            }
            static $h = 2148103;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseContainer; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(223340447495),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966265095,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206160578311,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 2148103,
      "h": 223340447495,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223340447495),
//--TRIMMABLE-BOUNDARY-START(124556199687),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426657543,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210905351,
        "f": 83886081
      },
      "n": "Header",
      "d": 2148103,
      "h": 124556199687,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124556199687),
//--TRIMMABLE-BOUNDARY-START(128851166983),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016592135,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800839943,
        "f": 83886081
      },
      "n": "HeaderControls",
      "d": 2148103,
      "h": 128851166983,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128851166983),
//--TRIMMABLE-BOUNDARY-START(133146134279),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606526727,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390774535,
        "f": 83886081
      },
      "n": "NoTransactions",
      "d": 2148103,
      "h": 133146134279,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133146134279),
//--TRIMMABLE-BOUNDARY-START(210455545607),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786395911,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188980709127,
        "f": 83886081
      },
      "n": "TransactionDetailView",
      "d": 2148103,
      "h": 210455545607,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210455545607),
//--TRIMMABLE-BOUNDARY-START(47246788359),
    {
      "p": 2213639,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836722951,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620970759,
        "f": 83886081
      },
      "n": "Features",
      "d": 2148103,
      "h": 47246788359,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246788359),
//--TRIMMABLE-BOUNDARY-START(214750512903),
    {
      "p": $.$hDPm.LCFCCP$2.PagingForEach$$($.$OJJQ.LCFCW.IWalletTransaction).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376330503,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197570643719,
        "f": 83886082
      },
      "n": "TransactionsPager",
      "d": 2148103,
      "h": 214750512903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214750512903),
//--TRIMMABLE-BOUNDARY-START(137441101575),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196461319,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2148103,
      "h": 137441101575,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137441101575)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146031036167),
    {
      "r": 181338113,
      "n": "Send",
      "d": 2148103,
      "h": 146031036167,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146031036167),
//--TRIMMABLE-BOUNDARY-START(141736068871),
    {
      "r": 181338113,
      "n": "Receive",
      "d": 2148103,
      "h": 141736068871,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141736068871),
//--TRIMMABLE-BOUNDARY-START(227635414791),
    {
      "r": 181338113,
      "n": "WithdrawToBank",
      "d": 2148103,
      "h": 227635414791,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(227635414791),
//--TRIMMABLE-BOUNDARY-START(219045480199),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2148103,
      "h": 219045480199,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219045480199),
//--TRIMMABLE-BOUNDARY-START(42951821063),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2148103,
      "h": 42951821063,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42951821063),
//--TRIMMABLE-BOUNDARY-START(38656853767),
    {
      "r": 6881395,
      "p": [
        {
          "n": "_internal",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "BottomToolBarControls",
      "d": 2148103,
      "h": 38656853767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656853767),
//--TRIMMABLE-BOUNDARY-START(120261232391),
    {
      "r": 6881395,
      "n": "GetTransactions",
      "d": 2148103,
      "h": 120261232391,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120261232391)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361886471),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2148103,
      "h": 34361886471,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361886471)
  ],
  "h": 2148103
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletHome`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletHome`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2148103)
        
        

        //--TRIMMABLE-BOUNDARY-START(2082567)
        $asm.$cls(`$SeJP.LCWCS$1.WalletHeader`, ($self) => class WalletHeader extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OJJQ.LCFCW.IWalletSystem)
        {
            //--TRIMMABLE-BOUNDARY-START(17181951751)
            /*RenderFragment?*/ Controls = null;
            //--TRIMMABLE-BOUNDARY-END(17181951751)
            
            //--TRIMMABLE-BOUNDARY-START(21476919047)
            /*Task *//*async*/  FundAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476919047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.ViewModel.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$FundPayment.LCFCW$IWalletFundPaymentProvider$FundAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476919047)
            
            //--TRIMMABLE-BOUNDARY-START(42951755527)
            /*string */ get OptimizedComponentName()
            {
                return "walletheader";
            }
            //--TRIMMABLE-BOUNDARY-END(42951755527)
            
            //--TRIMMABLE-BOUNDARY-START(55836657415)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836657415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "Controls":
                    this.Controls = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(55836657415)
            
            //--TRIMMABLE-BOUNDARY-START(12886984455)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886984455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", $.$strNN($.$strNN($.$strNN((this.ViewModel.LCFCW$IWalletSystem$Theme.ToString$1("bg-", null))) + " pdt-5") + " pdx-7") + " pdb-20");
                __builder.AddAttribute$5(2, "style", this.ViewModel.LCFCW$IWalletSystem$Theme.ToStyle());
                if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.ViewModel.LCFCW$IWalletSystem$Issuers) > 1)
                {
                    __builder.OpenElement(3, "div");
                    __builder.AddAttribute$5(4, "class", "flex");
                    __builder.AddMarkupContent(5, "<i class=\"mdi mdi-account fsz-40 flex mgc-a bd round wx-05 hx-05\"></i>\r\n            ");
                    __builder.OpenElement(6, "h3");
                    __builder.AddAttribute$5(7, "class", "mgl mgy-a");
                    __builder.AddContent$4(8, "Welcome ");
                    __builder.AddContent$4(9, this.ViewModel.LCFCW$IWalletSystem$Holder.LCFC$IDisplayable$Title);
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.OpenElement(10, "h2");
                __builder.AddAttribute$5(11, "class", "text-center mg-0");
                __builder.AddContent$4(12, this.ViewModel.LCFCW$IWalletSystem$Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n    ");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$5(15, "class", "mgt stack pd-5 bg-dark-01 text-center corner-5");
                __builder.AddMarkupContent(16, "<h3 class=\"mg-0\">Current Balance</h3>\r\n        ");
                __builder.OpenElement(17, "div");
                __builder.AddAttribute$5(18, "class", "mgt flex flex-spacearound-x lh-1");
                let $en3 = $.$sl.SL.Enumerable.Take($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), this.ViewModel.LCFCW$IWalletSystem$Tokens, 3).SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let group = $en3.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let issuer = $.$OJJQ.LCFCW.WalletServiceExtension.GetIssuer(this.ViewModel.LCFCW$IWalletSystem$Services, group.SL$IGrouping$$$$Key);
                        if (issuer !== null)
                        {
                            __builder.OpenElement(19, "div");
                            __builder.AddAttribute$5(20, "class", "stack mgy-a mgl-2");
                            if ($.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.ViewModel.LCFCW$IWalletSystem$Issuers) > 1)
                            {
                                __builder.OpenElement(21, "span");
                                __builder.AddAttribute$6(22, "class");
                                __builder.AddContent$4(23, issuer.LCFC$INamed$Name);
                                __builder.CloseElement();
                            }
                            /*var*/ let sum = $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, group, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/**/ s) =>
                            {
                                return s.LCFCW$IWalletToken$Amount;
                            }, $WHmYti ??= {"r":1179649,"p":[{"n":"s","p":1357005}],"n":"","d":2082567,"h":0,"f":17825794}));
                            __builder.OpenElement(24, "span");
                            __builder.AddAttribute$5(25, "class", $.$strNN($.$strNN($.$strNN("fw-bold" + " text-center") + " ") + $.$strNN((sum < 0 ? "cl-warning" : ""))) + " fsz-" + ($.$box($.trunc(40 / $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.ViewModel.LCFCW$IWalletSystem$Issuers)), $.$$.S.Int32)));
                            __builder.AddContent$4(26, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                            __builder.AddContent$4(27, $.$$.S.Double.ToString$3.call(sum, "#,##0"));
                            __builder.CloseElement();
                            /*var*/ let frozen = $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, group, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/**/ s) =>
                            {
                                return s.LCFCW$IWalletToken$FrozenAmount;
                            }, $qIeVgc ??= {"r":1179649,"p":[{"n":"s","p":1357005}],"n":"","d":2082567,"h":0,"f":17825794}));
                            /*var*/ let cashback = $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, group, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/*s*/ s) =>
                            {
                                return s.LCFCW$IWalletToken$Cashback;
                            }, $GyoxBg ??= {"r":1179649,"p":[{"n":"s","p":1357005}],"n":"","d":2082567,"h":0,"f":17825794}));
                            if (frozen > 0 || cashback > 0)
                            {
                                __builder.OpenElement(28, "span");
                                __builder.AddAttribute$5(29, "class", $.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-lock") + " fw-bold") + " text-center") + " op-8") + " fsz-" + ($.$box($.trunc(20 / $.$sl.SL.Enumerable.Count$1($.$OJJQ.LCFCW.IWalletIssuer, this.ViewModel.LCFCW$IWalletSystem$Issuers)), $.$$.S.Int32)));
                                __builder.AddAttribute$5(30, "title", "Fund is locked against withdrawal, but can be used to purchase utility service like airtime/data");
                                if (cashback > 0)
                                {
                                    __builder.AddContent$4(31, "+");
                                    __builder.AddContent$4(32, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                    __builder.AddContent$4(33, $.$$.S.Double.ToString$3.call(cashback, "#,###"));
                                }
                                if (cashback > 0 && frozen > 0)
                                {
                                    __builder.AddContent$4(34, ", ");
                                }
                                if (frozen > 0)
                                {
                                    __builder.AddContent$4(35, "~");
                                    __builder.AddContent$4(36, issuer.LCFCW$IWalletIssuer$CurrencyUnit);
                                    __builder.AddContent$4(37, $.$$.S.Double.ToString$3.call(frozen, "#,###"));
                                }
                                __builder.CloseElement();
                            }
                            __builder.CloseElement();
                        }
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(38, "\r\n    ");
                __builder.OpenElement(39, "div");
                __builder.AddAttribute$5(40, "class", "mgt-5 flex flex-spacearound-x");
                if (this.ViewModel.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$FundPayment !== null)
                {
                    __builder.OpenElement(41, "div");
                    __builder.AddAttribute$5(42, "class", "stack");
                    __builder.OpenElement(43, "button");
                    __builder.AddAttribute$5(44, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mgx-a" + " wx-05") + " hx-05") + " round") + " bd") + " bdw-2") + " bg-transparent") + " fsz-30") + " ") + $.$strNN(("mdi mdi-plus"/*MaterialDesignIconNames.Plus*/)));
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 45, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.FundAsync)));
                    __builder.CloseElement();
                    __builder.AddMarkupContent(46, "\r\n                ");
                    __builder.AddMarkupContent(47, "<h4 class=\"mgt-1 mgb-0 mgx-a\">Fund Wallet</h4>");
                    __builder.CloseElement();
                }
                __builder.AddContent$1(48, this.Controls);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12886984455)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592017159)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592017159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592017159)
            
            //--TRIMMABLE-BOUNDARY-START(8592017159)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592017159)
            
            static $h = 2082567;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OJJQ.LCFCW.IWalletSystem); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181951751),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066853639,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541690119,
        "f": 83886081
      },
      "n": "Controls",
      "d": 2082567,
      "h": 17181951751,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181951751),
//--TRIMMABLE-BOUNDARY-START(42951755527),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656788231,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2082567,
      "h": 42951755527,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42951755527)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476919047),
    {
      "r": 178454529,
      "n": "FundAsync",
      "d": 2082567,
      "h": 21476919047,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476919047),
//--TRIMMABLE-BOUNDARY-START(55836657415),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2082567,
      "h": 55836657415,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55836657415),
//--TRIMMABLE-BOUNDARY-START(12886984455),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2082567,
      "h": 12886984455,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886984455)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592017159),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2082567,
      "h": 8592017159,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592017159)
  ],
  "h": 2082567
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletHeader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2082567)
        
        

        //--TRIMMABLE-BOUNDARY-START(2868999)
        $asm.$cls(`$SeJP.LCWCS$1.WalletTransactionDetail`, ($self) => class WalletTransactionDetail extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OJJQ.LCFCW.IWalletTransaction)
        {
            //--TRIMMABLE-BOUNDARY-START(90197182215)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(90197182215)
            
            //--TRIMMABLE-BOUNDARY-START(81607247623)
            /*RenderFragment<(IWalletTransaction, PaymentModel?)>?*/ TransactionDetailView = null;
            //--TRIMMABLE-BOUNDARY-END(81607247623)
            
            //--TRIMMABLE-BOUNDARY-START(55837443847)
            /*IWalletIssuer? */ get Issuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772672775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.Boolean))().$ctor(this,  (/**/ i) =>
                {
                    return i.LCFC$INamed$Name === this.ViewModel.LCFCW$IWalletTransaction$Coin.IssuerName;
                }, $ppXkxd ??= {"r":262145,"p":[{"n":"i","p":636109}],"n":"","d":2868999,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55837443847)
            
            //--TRIMMABLE-BOUNDARY-START(60132411143)
            /*string */ get OptimizedComponentName()
            {
                return "wallettransactiondetail";
            }
            //--TRIMMABLE-BOUNDARY-END(60132411143)
            
            //--TRIMMABLE-BOUNDARY-START(85902214919)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902214919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "TransactionDetailView":
                    this.TransactionDetailView = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel)));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(85902214919)
            
            //--TRIMMABLE-BOUNDARY-START(17182738183)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182738183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "text-center");
                __builder.OpenElement(4, "h1");
                __builder.AddAttribute$5(5, "class", "mgy-a fsz-50");
                __builder.OpenElement(6, "span");
                __builder.AddAttribute$5(7, "class", $.$strNN("nowrap" + " ") + $.$strNN(($.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress) ? "cl-error" : "cl-primary")));
                __builder.OpenElement(8, "text");
                __builder.AddContent$4(9, $.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress) ? "-" : "+");
                __builder.CloseElement();
                __builder.AddContent$4(10, (this.Issuer?.LCFCW$IWalletIssuer$CurrencyUnit ?? null));
                __builder.AddContent$4(11, $.$$.S.Double.ToString$3.call(this.ViewModel.LCFCW$IWalletTransaction$Amount, "#,##0.##"));
                __builder.CloseElement();
                __builder.CloseElement();
                if ($.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress))
                {
                    if (this.ViewModel.LCFCW$IWalletTransaction$Receiver.Address !== "system")
                    {
                        __builder.OpenElement(12, "h3");
                        __builder.AddContent$4(13, "Sent to ");
                        __builder.AddContent$4(14, $.$OJJQ.LCFCW.WalletAddress.op_Implicit(this.ViewModel.LCFCW$IWalletTransaction$Receiver));
                        __builder.CloseElement();
                    }
                }
                else 
                {
                    if (this.ViewModel.LCFCW$IWalletTransaction$Sender.Address !== "system")
                    {
                        __builder.OpenElement(15, "h3");
                        __builder.AddContent$4(16, "Received from ");
                        __builder.AddContent$4(17, $.$OJJQ.LCFCW.WalletAddress.op_Implicit(this.ViewModel.LCFCW$IWalletTransaction$Sender));
                        __builder.CloseElement();
                    }
                }
                __builder.OpenElement(18, "p");
                __builder.AddContent$4(19, this.ViewModel.LCFCW$IWalletTransaction$Reference);
                __builder.CloseElement();
                if (!$.$$.S.String.IsNullOrEmpty(this.ViewModel.LCFCW$IWalletTransaction$Description))
                {
                    __builder.OpenElement(20, "h3");
                    __builder.AddContent$4(21, this.ViewModel.LCFCW$IWalletTransaction$Description);
                    __builder.CloseElement();
                }
                __builder.OpenElement(22, "p");
                __builder.AddAttribute$5(23, "class", "op-8");
                __builder.AddContent$3(24, this.ToLocalTime(this.ViewModel.LCFCW$IWalletTransaction$Date));
                __builder.CloseElement();
                __builder.CloseElement();
                if ($.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress))
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteDataDetail$$($.$Iaui.LCFCM.PaymentModel), 25);
                    __builder.AddComponentParameter(26, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$24(this.ViewModel.LCFCW$IWalletTransaction$Reference, null)));
                    __builder.AddAttribute$3(27, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$Iaui.LCFCM.PaymentModel)))().$ctor(this, ( (/*payment*/ payment) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            if (payment.Data !== null)
                            {
                                __builder2.OpenComponent$1($.$wtdm.LCFCPS.PaymentDetails, 28);
                                __builder2.AddComponentParameter(29, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.PaymentModel, payment.Data));
                                __builder2.CloseComponent();
                                __builder2.AddContent$1(30, (this.TransactionDetailView?.Invoke(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel))().$ctor$3(this.ViewModel, payment.Data)) ?? null));
                            }
                        }, $ICZJCc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2868999,"h":0,"f":17825794});
                    }), $dklMbh ??= {"r":6881395,"p":[{"n":"payment","p":$.$hDPm.LCFCI.ContainerContext$$($.$Iaui.LCFCM.PaymentModel).$h}],"n":"","d":2868999,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.AddContent$1(31, (this.TransactionDetailView?.Invoke(new ($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel))().$ctor$3(this.ViewModel, null)) ?? null));
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17182738183)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887770887)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887770887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887770887)
            
            //--TRIMMABLE-BOUNDARY-START(12887770887)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12887770887)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90197182215)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(90197182215)
                
            }
            static $h = 2868999;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OJJQ.LCFCW.IWalletTransaction); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90197182215),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542476551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312280327,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 2868999,
      "h": 90197182215,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90197182215),
//--TRIMMABLE-BOUNDARY-START(81607247623),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952541959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722345735,
        "f": 83886081
      },
      "n": "TransactionDetailView",
      "d": 2868999,
      "h": 81607247623,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607247623),
//--TRIMMABLE-BOUNDARY-START(55837443847),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772672775,
        "f": 50331650
      },
      "n": "Issuer",
      "d": 2868999,
      "h": 55837443847,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55837443847),
//--TRIMMABLE-BOUNDARY-START(60132411143),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362607367,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2868999,
      "h": 60132411143,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60132411143)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85902214919),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2868999,
      "h": 85902214919,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85902214919),
//--TRIMMABLE-BOUNDARY-START(17182738183),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2868999,
      "h": 17182738183,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182738183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887770887),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2868999,
      "h": 12887770887,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887770887)
  ],
  "h": 2868999
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletTransactionDetail`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletTransactionDetail`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2868999)
        
        

        //--TRIMMABLE-BOUNDARY-START(2934535)
        $asm.$cls(`$SeJP.LCWCS$1.WalletTransactionListItem`, ($self) => class WalletTransactionListItem extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OJJQ.LCFCW.IWalletTransaction)
        {
            //--TRIMMABLE-BOUNDARY-START(94492215047)
            /*IWalletSystem*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(94492215047)
            
            //--TRIMMABLE-BOUNDARY-START(85902280455)
            /*RenderFragment<(IWalletTransaction, PaymentModel?)>?*/ TransactionDetailView = null;
            //--TRIMMABLE-BOUNDARY-END(85902280455)
            
            //--TRIMMABLE-BOUNDARY-START(60132476679)
            /*IWalletIssuer? */ get Issuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067705607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$OJJQ.LCFCW.IWalletIssuer, this.Wallet.LCFCW$IWalletSystem$Services.LCFCW$IWalletServices$Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.Boolean))().$ctor(this,  (/**/ i) =>
                {
                    return i.LCFC$INamed$Name === this.ViewModel.LCFCW$IWalletTransaction$Coin.IssuerName;
                }, $qqTpRb ??= {"r":262145,"p":[{"n":"i","p":636109}],"n":"","d":2934535,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(60132476679)
            
            //--TRIMMABLE-BOUNDARY-START(21477771015)
            /*ValueTask */ Details()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477771015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS$1.WalletTransactionDetail, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*b*/ b, /*i*/ i) =>
                {
                    b.AddAttribute$4(i++, "ViewModel", this.ViewModel);
                    b.AddAttribute$4(i++, "Wallet", this.Wallet);
                    b.AddAttribute$3(i++, "TransactionDetailView", this.TransactionDetailView);
                }, $XXQgIk ??= {"r":65537,"p":[{"n":"b","p":7536755},{"n":"i","p":655361}],"n":"","d":2934535,"h":0,"f":17825794}), null, (() =>
                {
                    //new $.$hDPm.LCFCI.ViewConfiguration()
                    const $t1 = $.$hDPm.LCFCI.ViewConfiguration;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.PageBackgroundTheme = $.$fPer.LCFC.Theme.Card;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(21477771015)
            
            //--TRIMMABLE-BOUNDARY-START(64427443975)
            /*string */ get OptimizedComponentName()
            {
                return "wallettransactionlistitem";
            }
            //--TRIMMABLE-BOUNDARY-END(64427443975)
            
            //--TRIMMABLE-BOUNDARY-START(90197247751)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197247751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "Wallet":
                    this.Wallet = $.$cast(parameter.Value, $.$OJJQ.LCFCW.IWalletSystem);
                    return true;
                    case "TransactionDetailView":
                    this.TransactionDetailView = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel)));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(90197247751)
            
            //--TRIMMABLE-BOUNDARY-START(17182803719)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182803719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex pdy-1 bdb clickable bg-card pd-2 mgy-2");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 2, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Details)));
                if ($.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress))
                {
                    __builder.AddMarkupContent(3, "<i class=\"mdi mdi-arrow-left-bold-box fsz-40 cl-error\"></i>");
                }
                else 
                {
                    __builder.AddMarkupContent(4, "<i class=\"mdi mdi-arrow-right-bold-box fsz-40 cl-primary\"></i>");
                }
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "mgl stack mgy-a fill clip");
                if (!$.$$.S.String.IsNullOrEmpty(this.ViewModel.LCFCW$IWalletTransaction$Description))
                {
                    __builder.OpenElement(7, "b");
                    __builder.AddAttribute$5(8, "class", "nowrap");
                    __builder.AddContent$4(9, this.ViewModel.LCFCW$IWalletTransaction$Description);
                    __builder.CloseElement();
                }
                __builder.OpenElement(10, "p");
                __builder.AddAttribute$5(11, "class", "mg-0 nowrap");
                if ($.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress))
                {
                    __builder.AddContent$4(12, "Sent to ");
                    __builder.OpenElement(13, "b");
                    __builder.AddAttribute$5(14, "title", this.ViewModel.LCFCW$IWalletTransaction$Receiver.Address);
                    __builder.AddContent$4(15, this.ViewModel.LCFCW$IWalletTransaction$Receiver.ToString());
                    __builder.CloseElement();
                    __builder.AddContent$4(16, ", ");
                }
                else 
                {
                    __builder.AddContent$4(17, "Received from ");
                    __builder.OpenElement(18, "b");
                    __builder.AddAttribute$5(19, "title", this.ViewModel.LCFCW$IWalletTransaction$Sender.Address);
                    __builder.AddContent$4(20, this.ViewModel.LCFCW$IWalletTransaction$Sender.ToString());
                    __builder.CloseElement();
                    __builder.AddContent$4(21, ", ");
                }
                __builder.AddContent$4(22, $.$fPer.LCFCDC.DateTimeExtension.Ago(this.ViewModel.LCFCW$IWalletTransaction$Date, 1/*DateTimeMask.Any*/));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(23, "\r\n    ");
                __builder.OpenElement(24, "h3");
                __builder.AddAttribute$5(25, "class", "mgy-a");
                __builder.OpenElement(26, "span");
                __builder.AddAttribute$5(27, "class", $.$strNN("nowrap" + " ") + $.$strNN(($.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress) ? "cl-error" : "cl-primary")));
                __builder.OpenElement(28, "text");
                __builder.AddContent$4(29, $.$OJJQ.LCFCW.WalletAddress.op_Equality(this.ViewModel.LCFCW$IWalletTransaction$Sender, this.Wallet.LCFCW$IWalletSystem$Holder.LCFCW$IWalletHolder$NetworkAddress) ? "-" : "+");
                __builder.CloseElement();
                __builder.AddContent$4(30, (this.Issuer?.LCFCW$IWalletIssuer$CurrencyUnit ?? null));
                __builder.AddContent$4(31, $.$$.S.Double.ToString$3.call(this.ViewModel.LCFCW$IWalletTransaction$Amount, "#,###.##"));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17182803719)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887836423)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887836423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887836423)
            
            //--TRIMMABLE-BOUNDARY-START(12887836423)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12887836423)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94492215047)
                this.Wallet = null;
                //--TRIMMABLE-BOUNDARY-END(94492215047)
                
            }
            static $h = 2934535;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OJJQ.LCFCW.IWalletTransaction); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94492215047),
    {
      "p": 1291469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837509383,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607313159,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 2934535,
      "h": 94492215047,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94492215047),
//--TRIMMABLE-BOUNDARY-START(85902280455),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletTransaction, $.$Iaui.LCFCM.PaymentModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247574791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017378567,
        "f": 83886081
      },
      "n": "TransactionDetailView",
      "d": 2934535,
      "h": 85902280455,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85902280455),
//--TRIMMABLE-BOUNDARY-START(60132476679),
    {
      "p": 636109,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067705607,
        "f": 50331650
      },
      "n": "Issuer",
      "d": 2934535,
      "h": 60132476679,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60132476679),
//--TRIMMABLE-BOUNDARY-START(64427443975),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657640199,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2934535,
      "h": 64427443975,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64427443975)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477771015),
    {
      "r": 181338113,
      "n": "Details",
      "d": 2934535,
      "h": 21477771015,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21477771015),
//--TRIMMABLE-BOUNDARY-START(90197247751),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2934535,
      "h": 90197247751,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90197247751),
//--TRIMMABLE-BOUNDARY-START(17182803719),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2934535,
      "h": 17182803719,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182803719)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887836423),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2934535,
      "h": 12887836423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887836423)
  ],
  "h": 2934535
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.WalletTransactionListItem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}WalletTransactionListItem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2934535)
        
        

        //--TRIMMABLE-BOUNDARY-START(1754887)
        $asm.$cls(`$SeJP.LCWCS$1.BankGetBeneficiary`, ($self) => class BankGetBeneficiary extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(77311166215)
            /*string */ get OptimizedComponentName()
            {
                return "bankgetbeneficiary";
            }
            //--TRIMMABLE-BOUNDARY-END(77311166215)
            
            //--TRIMMABLE-BOUNDARY-START(1820423)
            static $_WalletHolder;
            static get WalletHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1820423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$SeJP.LCWCS$1.BankGetBeneficiary;
                return $cls.$_WalletHolder ??= $asm.$ncls(`$SeJP.LCWCS$1.BankGetBeneficiary.WalletHolder`, ($self) => class WalletHolder extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(38656526087)
                    /*BankAccount*/ Account;
                    //--TRIMMABLE-BOUNDARY-END(38656526087)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361558791)
                    $ctor$1(/*BankAccount*/ account)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361558791);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Account = $.$clone(account);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361558791)
                    
                    //--TRIMMABLE-BOUNDARY-START(163210577671)
                    /*WalletAddress */ get NetworkAddress()
                    {
                        return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1($.$strNN($.$strNN(this.Account.Bank.Name) + " ") + $.$strNN(this.Account.AccountNumber));
                    }
                    //--TRIMMABLE-BOUNDARY-END(163210577671)
                    
                    //--TRIMMABLE-BOUNDARY-START(150325675783)
                    /*DataId*/ Identifier;
                    //--TRIMMABLE-BOUNDARY-END(150325675783)
                    
                    //--TRIMMABLE-BOUNDARY-START(171800512263)
                    /*string?*/ PhoneNumber = null;
                    //--TRIMMABLE-BOUNDARY-END(171800512263)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246460679)
                    /*string?*/ Email = null;
                    //--TRIMMABLE-BOUNDARY-END(47246460679)
                    
                    //--TRIMMABLE-BOUNDARY-START(154620643079)
                    /*GeoLocation?*/ Location = null;
                    //--TRIMMABLE-BOUNDARY-END(154620643079)
                    
                    //--TRIMMABLE-BOUNDARY-START(176095479559)
                    /*string? */ get Title()
                    {
                        return $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN(this.Account.AccountName) + "(") + $.$strNN(this.Account.Bank.Name)) + " ") + $.$strNN(this.Account.AccountNumber)) + ")";
                    }
                    //--TRIMMABLE-BOUNDARY-END(176095479559)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951493383)
                    /*string?*/ Description = null;
                    //--TRIMMABLE-BOUNDARY-END(42951493383)
                    
                    //--TRIMMABLE-BOUNDARY-START(146030708487)
                    /*IconDescriptor*/ Icon;
                    //--TRIMMABLE-BOUNDARY-END(146030708487)
                    
                    //--TRIMMABLE-BOUNDARY-START(167505544967)
                    /*string? */ get Number()
                    {
                        return this.Account.AccountNumber;
                    }
                    //--TRIMMABLE-BOUNDARY-END(167505544967)
                    
                    //--TRIMMABLE-BOUNDARY-START(158915610375)
                    /*string? */ get Name()
                    {
                        return this.Account.AccountName;
                    }
                    //--TRIMMABLE-BOUNDARY-END(158915610375)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590505165)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder.NetworkAddress.get
                    get LCFCW$IWalletHolder$NetworkAddress()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885472461);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.NetworkAddress;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590505165)
                    
                    //--TRIMMABLE-BOUNDARY-START(21479917910)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Identifier.get
                    get LCFCC$2$IContact$Identifier()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51544688982);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Identifier;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21479917910)
                    
                    //--TRIMMABLE-BOUNDARY-START(47249721686)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.PhoneNumber.get
                    get LCFCC$2$IContact$PhoneNumber()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64429590870);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.PhoneNumber;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47249721686)
                    
                    //--TRIMMABLE-BOUNDARY-START(12889983318)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Email.get
                    get LCFCC$2$IContact$Email()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300048726);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Email;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12889983318)
                    
                    //--TRIMMABLE-BOUNDARY-START(38659787094)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Location.get
                    get LCFCC$2$IContact$Location()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60134623574);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Location;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38659787094)
                    
                    //--TRIMMABLE-BOUNDARY-START(17226762582)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
                    get LCFC$IDisplayable$Title()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25816697174);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Title;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17226762582)
                    
                    //--TRIMMABLE-BOUNDARY-START(8636827990)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
                    get LCFC$IDisplayable$Icon()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21521729878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Icon;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8636827990)
                    
                    //--TRIMMABLE-BOUNDARY-START(12931729750)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
                    get LCFC$IDescribable$Description()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4341795158);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Description;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12931729750)
                    
                    //--TRIMMABLE-BOUNDARY-START(8637417814)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
                    get LCFC$INamed$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12932385110);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8637417814)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(38656526087)
                        this.Account = $.$default($.$fPer.LCFCD.BankAccount);
                        //--TRIMMABLE-BOUNDARY-END(38656526087)
                        
                        //--TRIMMABLE-BOUNDARY-START(150325675783)
                        this.Identifier = $.$default($.$fPer.LCFCD.DataId);
                        //--TRIMMABLE-BOUNDARY-END(150325675783)
                        
                        //--TRIMMABLE-BOUNDARY-START(146030708487)
                        this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                        //--TRIMMABLE-BOUNDARY-END(146030708487)
                        
                    }
                    static $h = 1820423;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656526087),
    {
      "p": 5474646,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836395271,
        "f": 50331649
      },
      "n": "Account",
      "d": 1820423,
      "h": 38656526087,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656526087),
//--TRIMMABLE-BOUNDARY-START(163210577671),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965937415,
        "f": 50331649
      },
      "n": "NetworkAddress",
      "d": 1820423,
      "h": 163210577671,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210577671),
//--TRIMMABLE-BOUNDARY-START(150325675783),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196133639,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 1820423,
      "h": 150325675783,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150325675783),
//--TRIMMABLE-BOUNDARY-START(171800512263),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145806599,
        "f": 50331649
      },
      "n": "PhoneNumber",
      "d": 1820423,
      "h": 171800512263,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171800512263),
//--TRIMMABLE-BOUNDARY-START(47246460679),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016264455,
        "f": 50331649
      },
      "n": "Email",
      "d": 1820423,
      "h": 47246460679,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246460679),
//--TRIMMABLE-BOUNDARY-START(154620643079),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786068231,
        "f": 50331649
      },
      "n": "Location",
      "d": 1820423,
      "h": 154620643079,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620643079),
//--TRIMMABLE-BOUNDARY-START(176095479559),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735741191,
        "f": 50331649
      },
      "n": "Title",
      "d": 1820423,
      "h": 176095479559,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176095479559),
//--TRIMMABLE-BOUNDARY-START(42951493383),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426329863,
        "f": 50331649
      },
      "n": "Description",
      "d": 1820423,
      "h": 42951493383,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951493383),
//--TRIMMABLE-BOUNDARY-START(146030708487),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606199047,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1820423,
      "h": 146030708487,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030708487),
//--TRIMMABLE-BOUNDARY-START(167505544967),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555872007,
        "f": 50331649
      },
      "n": "Number",
      "d": 1820423,
      "h": 167505544967,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167505544967),
//--TRIMMABLE-BOUNDARY-START(158915610375),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376002823,
        "f": 50331649
      },
      "n": "Name",
      "d": 1820423,
      "h": 158915610375,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158915610375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361558791),
    {
      "p": [
        {
          "n": "account",
          "p": 5474646
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1820423,
      "h": 34361558791,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361558791)
  ],
  "d": 1754887,
  "h": 1820423
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletHolder, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.BankGetBeneficiary+WalletHolder`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}BankGetBeneficiary${separator}WalletHolder`; }
                }, $cls, ($v) => $cls.$_WalletHolder = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1820423)
            
            //--TRIMMABLE-BOUNDARY-START(17181624071)
            /*string?*/ accountNumber = null;
            //--TRIMMABLE-BOUNDARY-END(17181624071)
            
            //--TRIMMABLE-BOUNDARY-START(25771558663)
            /*IEnumerable<Bank>?*/ static banks = null;
            //--TRIMMABLE-BOUNDARY-END(25771558663)
            
            //--TRIMMABLE-BOUNDARY-START(30066525959)
            /*IEnumerable<BankAccount>?*/ beneficiaries = null;
            //--TRIMMABLE-BOUNDARY-END(30066525959)
            
            //--TRIMMABLE-BOUNDARY-START(21476591367)
            /*Bank*/ bank;
            //--TRIMMABLE-BOUNDARY-END(21476591367)
            
            //--TRIMMABLE-BOUNDARY-START(12886656775)
            /*BankAccount*/ account;
            //--TRIMMABLE-BOUNDARY-END(12886656775)
            
            //--TRIMMABLE-BOUNDARY-START(64426264327)
            /*IHostView?*/ Host = null;
            //--TRIMMABLE-BOUNDARY-END(64426264327)
            
            //--TRIMMABLE-BOUNDARY-START(81606133511)
            /*bool*/ resolvingBank = false;
            //--TRIMMABLE-BOUNDARY-END(81606133511)
            
            //--TRIMMABLE-BOUNDARY-START(38656460551)
            /*Task *//*async*/  CheckAccount()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656460551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.accountNumber !== null && this.bank.Name !== null)
                    {
                        this.account = new $.$fPer.LCFCD.BankAccount();
                        this.resolvingBank = true;
                        try
                        {
                            let $t1, $r1;
                            this.account = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.BankAccount, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)))().$ctor(this,  (/*server*/ server) =>
                            {
                                return server.LCFCP$IBankingRemoteService$ResolveAccount($.$clone(this.bank), this.accountNumber);
                            }, $fiytRj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)).$h,"p":[{"n":"server","p":411416}],"n":"","d":1754887,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        }
                        finally
                        {
                            {
                                this.resolvingBank = false;
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38656460551)
            
            //--TRIMMABLE-BOUNDARY-START(85901100807)
            /*Task *//*async*/  SelectBank()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901100807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$SeJP.LCWCS$1.BankGetBeneficiary.banks !== null)
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        this.bank = $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCD.Bank, (($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select$1($.$hDPm.LCFCI.ViewConfiguration, $.$fPer.LCFCD.Bank, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD.Bank, $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank), $.$SeJP.LCWCS$1.BankGetBeneficiary.banks, new ($.$$.S.Func$$$($.$fPer.LCFCD.Bank, $.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank)))().$ctor(this,  (/*b*/ b) =>
                        {
                            return new ($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank))().$ctor$3($.$clone(b));
                        }, $aBxxBg ??= {"r":$.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank).$h,"p":[{"n":"b","p":5409110}],"n":"","d":1754887,"h":0,"f":17825794})), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.SelectOption$$($.$fPer.LCFCD.Bank)), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.Bank))), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Select Bank", false), null, 0, 1, 35184372092928n | 65536n | 8n | 8192n, null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))));
                        ($t3 = this.CheckAccount(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85901100807)
            
            //--TRIMMABLE-BOUNDARY-START(68721231623)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721231623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$SeJP.LCWCS$1.BankGetBeneficiary.banks ??= ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute($.$nYKj.LCFCP.IBankingRemoteService, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank), this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank))))().$ctor(this, /*async*/  (/**/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank))), $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank)), async ($asnycContext) => 
                        {
                            let $t5, $r5;
                            return ($t5 = server.LCFCP$IBankingRemoteService$GetBanks($.$fPer.LCFCD.DataFilter.Default), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        });
                    }, $BlkCFb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank))).$h,"p":[{"n":"server","p":411416}],"n":"","d":1754887,"h":0,"f":17829890}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    this.beneficiaries = ($t6 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage.LCFCS$5$IPersistentStorageService$GetItem($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.BankAccount), "beneficiary"), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68721231623)
            
            //--TRIMMABLE-BOUNDARY-START(73016198919)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<BankAccount>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016198919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = this.Host.LCFCC$IHostView$Complete(true, new $.$SeJP.LCWCS$1.BankGetBeneficiary.WalletHolder().$ctor$1(selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73016198919)
            
            //--TRIMMABLE-BOUNDARY-START(42951427847)
            /*Task *//*async*/  Continue()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951427847);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.account.AccountName !== null)
                    {
                        let $t9, $r9;
                        let $t10, $r10;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.BankAccount>?*/ let __ca1__;
                        this.beneficiaries = ((__ca1__ = this.beneficiaries) !== null ? ($.$sl.SL.Enumerable.Reverse($.$fPer.LCFCD.BankAccount, $.$sl.SL.Enumerable.Distinct$1($.$fPer.LCFCD.BankAccount, $.$sl.SL.Enumerable.Concat($.$fPer.LCFCD.BankAccount, __ca1__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.BankAccount), [this.account], null, null)))) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.BankAccount), [this.account], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.BankAccount), [this.account], null, null));
                        ($t9 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage.LCFCS$5$IPersistentStorageService$SetItem($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.BankAccount), "beneficiary", this.beneficiaries), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        ($t10 = this.Host.LCFCC$IHostView$Complete(true, new $.$SeJP.LCWCS$1.BankGetBeneficiary.WalletHolder().$ctor$1($.$clone(this.account))), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42951427847)
            
            //--TRIMMABLE-BOUNDARY-START(34361493255)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361493255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd");
                __builder.OpenComponent$1($.$macw.MACF.EditForm, 2);
                __builder.AddComponentParameter(3, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                __builder.AddComponentParameter(4, "class", "corner pd bg-card");
                __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(6, "<div class=\"bdb pdb\"><h2 class=\"mgy-0 mgl-5\">Recipient Account</h2></div>\r\n        ");
                        $.$SeJP._LCWCSB.TypeInference.CreateInputEditor_0($.$$.S.String, __builder2, 7, 8, "mgt", 9, "Enter 10 digit Account Number", 10, this.accountNumber, 11, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this.accountNumber = __value;
                            return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.CheckAccount));
                        }, $rrsBja ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":1754887,"h":0,"f":17825794}), this.accountNumber), this.accountNumber)), 12, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "accountNumber"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $UaVsei ??= {"r":38797349,"n":"","d":1754887,"h":0,"f":17825794})).Invoke()));
                        __builder2.AddMarkupContent(13, "\r\n        ");
                        __builder2.OpenElement(14, "div");
                        __builder2.AddAttribute$5(15, "class", "mgt flex pd clip wf");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 16, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.SelectBank)));
                        if (this.bank.Name === null)
                        {
                            __builder2.AddMarkupContent(17, "<span class=\"op-8 fill\">Select Bank</span>");
                        }
                        else 
                        {
                            __builder2.OpenElement(18, "b");
                            __builder2.AddAttribute$5(19, "class", "nowrap fill");
                            __builder2.AddContent$4(20, this.bank.Name);
                            __builder2.CloseElement();
                        }
                        __builder2.AddMarkupContent(21, "<i class=\"mdi mdi-chevron-right\"></i>");
                        __builder2.CloseElement();
                        if (this.account.AccountName !== null)
                        {
                            __builder2.OpenElement(22, "div");
                            __builder2.AddAttribute$5(23, "class", "pd bg-success-01 mgt");
                            __builder2.OpenElement(24, "b");
                            __builder2.AddContent$4(25, this.account.AccountName);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        if (this.resolvingBank)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 26);
                            __builder2.AddComponentParameter(27, "Class", "fsz-30");
                            __builder2.CloseComponent();
                        }
                        else 
                        {
                            __builder2.OpenElement(28, "button");
                            __builder2.AddAttribute$5(29, "class", "bg-primary pd wf mgt-10 corner");
                            __builder2.AddAttribute$2(30, "disabled", this.account.AccountName === null);
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 31, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Continue)));
                            __builder2.AddContent$4(32, "Continue");
                            __builder2.CloseElement();
                        }
                    }, $TyUZEh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1754887,"h":0,"f":17825794});
                }), $yLtSfg ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1754887,"h":0,"f":17825794}));
                __builder.CloseComponent();
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.BankAccount>?*/ let __ca1__;
                if ((__ca1__ = this.beneficiaries) !== null ? $.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD.BankAccount, __ca1__) : false)
                {
                    __builder.OpenElement(33, "div");
                    __builder.AddAttribute$5(34, "class", "bg-card corner mgt-10 pd");
                    __builder.AddMarkupContent(35, "<div class=\"bdb pdb\"><h2 class=\"mg-0\">Past Beneficiaries</h2></div>\r\n            ");
                    $.$SeJP._LCWCSB.TypeInference.CreateDataList_1($.$fPer.LCFCD.BankAccount, __builder, 36, 37, this.beneficiaries, 38, this, 39, 35184372092928n | 65536n, 40, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.BankAccount, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.BankAccount))))().$ctor(this,  (/*b*/ b) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(41, "div");
                            __builder2.AddAttribute$5(42, "class", "flex pdy");
                            __builder2.OpenElement(43, "div");
                            __builder2.AddAttribute$5(44, "class", "stack");
                            __builder2.OpenElement(45, "b");
                            __builder2.AddContent$4(46, b.Data.AccountName);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(47, "\r\n                        ");
                            __builder2.OpenElement(48, "small");
                            __builder2.AddContent$4(49, b.Data.Bank.Name);
                            __builder2.AddContent$4(50, " ");
                            __builder2.AddContent$4(51, b.Data.AccountNumber);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }, $ZOkZfb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1754887,"h":0,"f":17825794});
                    }, $lgcoac ??= {"r":6881395,"p":[{"n":"b","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD.BankAccount, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD.BankAccount)).$h}],"n":"","d":1754887,"h":0,"f":17825794}));
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(34361493255)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12888661416)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IPushResultComponent<LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder>.Host.set
            set LCFCC$IPushResultComponent$$$Host(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298726824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Host = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12888661416)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Data.BankAccount>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Data.BankAccount>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Data$BankAccount$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(8591689479)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591689479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591689479)
            
            //--TRIMMABLE-BOUNDARY-START(8591689479)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591689479)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21476591367)
                this.bank = $.$default($.$fPer.LCFCD.Bank);
                //--TRIMMABLE-BOUNDARY-END(21476591367)
                
                //--TRIMMABLE-BOUNDARY-START(12886656775)
                this.account = $.$default($.$fPer.LCFCD.BankAccount);
                //--TRIMMABLE-BOUNDARY-END(12886656775)
                
            }
            static $h = 1754887;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311166215),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131297031,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1754887,
      "h": 77311166215,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77311166215),
//--TRIMMABLE-BOUNDARY-START(64426264327),
    {
      "p": 3300776,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541362439,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491035399,
        "f": 83886081
      },
      "n": "Host",
      "d": 1754887,
      "h": 64426264327,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426264327)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656460551),
    {
      "r": 178454529,
      "n": "CheckAccount",
      "d": 1754887,
      "h": 38656460551,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38656460551),
//--TRIMMABLE-BOUNDARY-START(85901100807),
    {
      "r": 178454529,
      "n": "SelectBank",
      "d": 1754887,
      "h": 85901100807,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85901100807),
//--TRIMMABLE-BOUNDARY-START(68721231623),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1754887,
      "h": 68721231623,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(68721231623),
//--TRIMMABLE-BOUNDARY-START(73016198919),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$fPer.LCFCD.BankAccount).$h
        }
      ],
      "n": "OnSelected",
      "d": 1754887,
      "h": 73016198919,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(73016198919),
//--TRIMMABLE-BOUNDARY-START(42951427847),
    {
      "r": 178454529,
      "n": "Continue",
      "d": 1754887,
      "h": 42951427847,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42951427847),
//--TRIMMABLE-BOUNDARY-START(34361493255),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1754887,
      "h": 34361493255,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361493255)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181624071),
    {
      "t": 1310721,
      "n": "accountNumber",
      "d": 1754887,
      "h": 17181624071,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181624071),
//--TRIMMABLE-BOUNDARY-START(25771558663),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.Bank).$h,
      "n": "banks",
      "d": 1754887,
      "h": 25771558663,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771558663),
//--TRIMMABLE-BOUNDARY-START(30066525959),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.BankAccount).$h,
      "n": "beneficiaries",
      "d": 1754887,
      "h": 30066525959,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066525959),
//--TRIMMABLE-BOUNDARY-START(21476591367),
    {
      "t": 5409110,
      "n": "bank",
      "d": 1754887,
      "h": 21476591367,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476591367),
//--TRIMMABLE-BOUNDARY-START(12886656775),
    {
      "t": 5474646,
      "n": "account",
      "d": 1754887,
      "h": 12886656775,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886656775),
//--TRIMMABLE-BOUNDARY-START(81606133511),
    {
      "t": 262145,
      "n": "resolvingBank",
      "d": 1754887,
      "h": 81606133511,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81606133511)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591689479),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1754887,
      "h": 8591689479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591689479)
  ],
  "h": 1754887
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.IPushResultComponent$$($.$OJJQ.LCFCW.IWalletHolder), $.$vWqU.LCFCC.IResultComponent$$($.$OJJQ.LCFCW.IWalletHolder), $.$vWqU.LCFCC.IResultComponent, $.$vWqU.LCFCC.IHostedView, $.$vWqU.LCFCC.IViewBase, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFCD.BankAccount), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFCD.BankAccount), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$SeJP.LCWCS$1.BankGetBeneficiary.WalletHolder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Shared.BankGetBeneficiary`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Shared${separator}BankGetBeneficiary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1754887)
        
        

        //--TRIMMABLE-BOUNDARY-START(1296135)
        $asm.$cls(`$SeJP.LCWCS.WalletFundFormModelTypeDescriptor`, ($self) => class WalletFundFormModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$SeJP.LCWCS.WalletFundFormModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296263431)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296263431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$SeJP.LCWCS.WalletFundFormModelTypeDescriptor.GenerateProperties($.$SeJP.LCWCS.WalletFundFormModel, this, factory);
                    }, $EzVcSj ??= {"r":65537,"n":"","d":1296135,"h":0,"f":17825794}), 0, "WalletFundFormModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Wallet.Client.Blazor\\Services_WalletFundFormModel_LivingThing.Core.Wallet.Client.Services.WalletFundFormModelTypeDescriptorBuilder.g.cs", "WalletFundFormModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296263431)
            
            //--TRIMMABLE-BOUNDARY-START(12886198023)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886198023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$SeJP.LCWCS.WalletFundFormModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Amount";
                        $i1.DelaredOn = "LivingThing.Core.Wallet.Client.Services.WalletFundFormModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$SeJP.LCWCS.WalletFundFormModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$SeJP.LCWCS.WalletFundFormModel)).Amount);
                        }, $BcVtad ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1296135,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$SeJP.LCWCS.WalletFundFormModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Amount = value.AsInt();
                        }, $dpVWId ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1296135,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Coins"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$SeJP.LCWCS.WalletFundFormModel.$type, $.$discardRef(), "Coins", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Coins")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletToken, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Coins";
                        $i3.DelaredOn = "LivingThing.Core.Wallet.Client.Services.WalletFundFormModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$SeJP.LCWCS.WalletFundFormModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletToken, ($.$cast(target, $.$SeJP.LCWCS.WalletFundFormModel)).Coins);
                        }, $slCbdg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1296135,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886198023)
            
            //--TRIMMABLE-BOUNDARY-START(17181165319)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Wallet.Client.Services.WalletFundFormModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181165319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Amount, ($v) => _Amount = $v, $.$$.S.Int32)))
                    {
                        _target.Amount = _Amount;
                    }
                }
                {
                    /*var*/ let _Coins = _target.Coins;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Coins"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletToken));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletToken, () => _Coins, ($v) => _Coins = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181165319)
            
            //--TRIMMABLE-BOUNDARY-START(8591230727)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Wallet.Client.Services.WalletFundFormModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591230727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$SeJP.LCWCS.WalletFundFormModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$SeJP.LCWCS.WalletFundFormModel)))
                {
                    /*var*/ let result = $.$SeJP.LCWCS.WalletFundFormModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$SeJP.LCWCS.WalletFundFormModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$SeJP.LCWCS.WalletFundFormModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$SeJP.LCWCS.WalletFundFormModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591230727)
            
            static $h = 1296135;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$SeJP.LCWCS.WalletFundFormModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886198023),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1296135,
      "h": 12886198023,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886198023),
//--TRIMMABLE-BOUNDARY-START(17181165319),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1165063,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1296135,
      "h": 17181165319,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181165319),
//--TRIMMABLE-BOUNDARY-START(8591230727),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1165063,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1296135,
      "h": 8591230727,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591230727)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296263431),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1296135,
      "h": 4296263431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296263431)
  ],
  "h": 1296135
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$SeJP.LCWCS.WalletFundFormModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletFundFormModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletFundFormModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1296135)
        
        

        //--TRIMMABLE-BOUNDARY-START(1558279)
        $asm.$cls(`$SeJP.LCWCS.WalletService`, ($self) => class WalletService extends $.$sZVd.LCFCA.ApplicationBaseService
        {
            //--TRIMMABLE-BOUNDARY-START(12886460167)
            $ctor$5(/*IClientUnitOfWork*/ unitOfWork, /*IEnumerable<IWalletIssuer>*/ issuers)
            {
                super.$ctor$4(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886460167);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Issuers = issuers;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886460167)
            
            //--TRIMMABLE-BOUNDARY-START(38656263943)
            /*IEnumerable<IWalletIssuer>*/ Issuers = null;
            //--TRIMMABLE-BOUNDARY-END(38656263943)
            
            //--TRIMMABLE-BOUNDARY-START(55836133127)
            /*WalletSystem?*/ System = null;
            //--TRIMMABLE-BOUNDARY-END(55836133127)
            
            //--TRIMMABLE-BOUNDARY-START(17181427463)
            /*Task<Money> *//*async*/  FundAsync(/*IWalletSystem*/ wallet, /*IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCDM.Money), $.$fPer.LCFCDM.Money, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181427463);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let name = $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinName(issuer, $.$clone(token));
                    /*var*/ let buy = ($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$SeJP.LCWCS.WalletFundFormModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Fund ${$.$strNN(name)}`, false), null, new $.$SeJP.LCWCS.WalletFundFormModel().$ctor$1(issuer, $.$clone(token)), null, null, 0, 4131/*InputEditorFeatures.Default*/, null, null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t2 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Theme = $.$fPer.LCFC.Theme.Primary;
                        $i2.ViewFeatures = 5667/*ViewFeatures.FormDefault*/;
                        $i2.ContentAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t3 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i3 = new $t3();
                            $i3.$ctor$1();
                            $i3.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "pd");
                            $i3.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("field-input-class"), "fsz-50");
                            return $i3;
                        })();
                        return $i2;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let tokenId = $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(issuer, $.$clone(token));
                    /*var*/ let paymentResult = ($t4 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment(new $.$fPer.LCFCDM.Money().$ctor$3(buy.Amount, 1/*MoneyUnitTypes.Naira*/), `Fund ${$.$strNN(name)} Wallet`, `${$.$strNN(tokenId)}/${$.$strNN(wallet.LCFCW$IWalletSystem$Holder.LCFCC$2$IContact$Email)}/${$.$strNN($.$$.S.DateTime.UtcNow.ToString())}`, `Fund ${$.$strNN(name)}`, null, "Wallet/" + $.$strNN(tokenId), null, wallet.LCFCW$IWalletSystem$Holder, null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    ($t5 = this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            do
                            {
                                let $t7, $r7;
                                try
                                {
                                    let $t6, $r6;
                                    /*var*/ let transaction = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$OJJQ.LCFCW.IWalletRemoteService, $.$OJJQ.LCFCW.UserWalletTransactionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)))().$ctor(this,  (/*server*/ server) =>
                                    {
                                        return server.LCFCW$IWalletRemoteService$FundAsync(tokenId, wallet.LCFCW$IWalletSystem$Holder.LCFCC$2$IContact$Identifier, buy.Coins.Amount, paymentResult.Reference, `Fund ${$.$strNN(name)}`);
                                    }, $aBzcfh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,"p":[{"n":"server","p":1029325}],"n":"","d":1558279,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                }
                                catch(e)
                                {
                                    continue;
                                }
                                ($t7 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Message("Success", `You have been creditted with ${$.$strNN(issuer.LCFCW$IWalletIssuer$CurrencyUnit)}${$.$strNN(buy.Coins.ToString())}`, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                break;
                            }
                            while(true);
                        });
                    }, $hhYBDd ??= {"r":181338113,"n":"","d":1558279,"h":0,"f":17829890}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    let system;
                    if ($.$is(wallet, $.$SeJP.LCWCS.WalletSystem, { set $v($v){ system = $v; } }))
                    {
                        let $t8, $r8;
                        ($t8 = system.Load(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCDM.Money.op_Implicit$1(buy.Amount));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181427463)
            
            //--TRIMMABLE-BOUNDARY-START(42951231239)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951231239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadOnce(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t9, $r9;
                        let $t10, $r10;
                        ($t9 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        /*var*/ let ticket = ($t10 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        if (ticket.IsValid())
                        {
                            let $t11, $r11;
                            this.System = new $.$SeJP.LCWCS.WalletSystem().$ctor$2(this, new $.$SeJP.LCWCS.WalletHolderFromTicket().$ctor$1(ticket), null);
                            ($t11 = this.System.Load(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        }
                    });
                }, $WGDESc ??= {"r":181338113,"n":"","d":1558279,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(42951231239)
            
            static $h = 1558279;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.ApplicationBaseService; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656263943),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771362055,
        "f": 50331649
      },
      "n": "Issuers",
      "d": 1558279,
      "h": 38656263943,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656263943),
//--TRIMMABLE-BOUNDARY-START(55836133127),
    {
      "p": 1623815,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361296647,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541165831,
        "f": 83886082
      },
      "n": "System",
      "d": 1558279,
      "h": 55836133127,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836133127)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181427463),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "wallet",
          "p": 1291469
        },
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "FundAsync",
      "d": 1558279,
      "h": 17181427463,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17181427463),
//--TRIMMABLE-BOUNDARY-START(42951231239),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1558279,
      "h": 42951231239,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951231239)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886460167),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "issuers",
          "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1558279,
      "h": 12886460167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886460167)
  ],
  "h": 1558279
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Client.Services.WalletService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Client${separator}Services${separator}WalletService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1558279)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet"));
})();
//--TRIMMABLE-BOUNDARY-END(50951)
