
//--TRIMMABLE-BOUNDARY-START(54230)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $nYKj, $mskq) {
    "use strict";
    let _;
    let $hpkRie;
    let $NYxHnl;
    let $jHEIkg;
    let $aZaUPi;
    let $tgEhZc;
    let $cjNWDh;
    let $upQcQe;
    let $oowTGc;
    let $IbVEeg;
    let $AmKKte;
    let $hCPvzj;
    let $acaQDg;
    let $ZBKTRg;
    let $amjnoe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.VTU.Client.Blazor", 
    {
  "h": 54230,
  "f": "LivingThing.VTU.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.VTU.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.VTU.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(185302)
        $asm.$cls(`$ySWu.LVC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295152598)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295152598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$ySWu.LVC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295152598)
            
            static $h = 185302;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295152598),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 185302,
      "h": 4295152598,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295152598)
  ],
  "h": 185302
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(185302)
        
        

        //--TRIMMABLE-BOUNDARY-START(316374)
        $asm.$cls(`$ySWu.LVC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885218262)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885218262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885218262)
            
            //--TRIMMABLE-BOUNDARY-START(8590250966)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590250966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ySWu.LVC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$hDPm.LCFCI.InputEditorProviderExtension.AddInputEditor$1($.$mskq.LVCM.VTUSelectPackage, $.$ySWu.LVC.VTUSelectPackageInput, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590250966)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ySWu.LVC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295283670)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295283670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295283670)
            
            //--TRIMMABLE-BOUNDARY-START(4295283670)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295283670)
            
            static $h = 316374;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885218262),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 316374,
      "h": 12885218262,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885218262),
//--TRIMMABLE-BOUNDARY-START(8590250966),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 316374,
      "h": 8590250966,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590250966)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295283670),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 316374,
      "h": 4295283670,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295283670)
  ],
  "h": 316374
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(316374)
        
        

        //--TRIMMABLE-BOUNDARY-START(250838)
        $asm.$cls(`$ySWu.LVC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180120022)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ySWu.LVC.VTUSelectPackageInput.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ySWu.LVC.VTUSelectPackageInput().$ctor$5();
                    }, $hpkRie ??= {"r":2752627,"n":"","d":250838,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180120022)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295218134)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295218134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295218134)
            
            //--TRIMMABLE-BOUNDARY-START(4295218134)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295218134)
            
            static $h = 250838;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180120022),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885152726,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 250838,
      "h": 17180120022,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180120022)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295218134),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 250838,
      "h": 4295218134,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295218134)
  ],
  "h": 250838
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(250838)
        
        

        //--TRIMMABLE-BOUNDARY-START(512982)
        $asm.$cls(`$ySWu.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295480278)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295480278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295480278)
            
            //--TRIMMABLE-BOUNDARY-START(4295480278)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295480278)
            
            static $h = 512982;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295480278),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 512982,
      "h": 4295480278,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295480278)
  ],
  "h": 512982,
  "a": [
    {
      "t": 447446,
      "c": 4295414742
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(512982)
        
        

        //--TRIMMABLE-BOUNDARY-START(447446)
        $asm.$cls(`$ySWu.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295414742)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295414742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295414742)
            
            //--TRIMMABLE-BOUNDARY-START(4295414742)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295414742)
            
            static $h = 447446;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295414742),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 447446,
      "h": 4295414742,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295414742)
  ],
  "h": 447446
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(447446)
        
        

        //--TRIMMABLE-BOUNDARY-START(119766)
        $asm.$cls(`$ySWu.LVC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590054358)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590054358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590054358)
            
            //--TRIMMABLE-BOUNDARY-START(4295087062)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295087062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295087062)
            
            //--TRIMMABLE-BOUNDARY-START(4295087062)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295087062)
            
            static $h = 119766;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590054358),
    {
      "r": 65537,
      "n": "Execute",
      "d": 119766,
      "h": 8590054358,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590054358)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295087062),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 119766,
      "h": 4295087062,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295087062)
  ],
  "h": 119766
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(119766)
        
        

        //--TRIMMABLE-BOUNDARY-START(381910)
        $asm.$cls(`$ySWu.LVC.VTUSelectPackageInput`, ($self) => class VTUSelectPackageInput extends $.$hDPm.LCFCI.BaseInputEditor$$($.$mskq.LVCM.VTUSelectPackage)
        {
            //--TRIMMABLE-BOUNDARY-START(34360120278)
            /*string */ get OptimizedComponentName()
            {
                return "vtuselectpackageinput";
            }
            //--TRIMMABLE-BOUNDARY-END(34360120278)
            
            //--TRIMMABLE-BOUNDARY-START(47245022166)
            /*VTUPackages?*/ static sPackages = null;
            //--TRIMMABLE-BOUNDARY-END(47245022166)
            
            //--TRIMMABLE-BOUNDARY-START(51539989462)
            /*VTUGlobalSettings*/ static sSettings = null;
            //--TRIMMABLE-BOUNDARY-END(51539989462)
            
            //--TRIMMABLE-BOUNDARY-START(38655087574)
            /*Dictionary<string, VTUPackage[]>?*/ packages = null;
            //--TRIMMABLE-BOUNDARY-END(38655087574)
            
            //--TRIMMABLE-BOUNDARY-START(55834956758)
            /*int*/ surcharge = 0;
            //--TRIMMABLE-BOUNDARY-END(55834956758)
            
            //--TRIMMABLE-BOUNDARY-START(42950054870)
            /*IEnumerable<VTUPricing>?*/ pricing = null;
            //--TRIMMABLE-BOUNDARY-END(42950054870)
            
            //--TRIMMABLE-BOUNDARY-START(30065152982)
            /*ValueTask<bool> *//*async*/  OnSelected$2(/*DataListSelection<VTUPackage>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065152982);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = (() =>
                    {
                        //new $.$mskq.LVCM.VTUSelectPackage()
                        const $t1 = $.$mskq.LVCM.VTUSelectPackage;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Code = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Code;
                        $i1.Title = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Title;
                        return $i1;
                    })();
                    ($t2 = this.ValueChanged.InvokeAsync$1($.$clone(this.Value)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.StateChanged(false, false, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Client.Blazor\\VTUSelectPackageInput.razor.cs", "OnSelected", 27), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065152982)
            
            //--TRIMMABLE-BOUNDARY-START(25770185686)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770185686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$ySWu.LVC.VTUSelectPackageInput.sPackages ??= ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$mskq.LVCM.VTUPackages, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LVCS$IVTURemoteService$GetPackages();
                    }, $NYxHnl ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages)).$h,"p":[{"n":"s","p":2157251}],"n":"","d":381910,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    $.$ySWu.LVC.VTUSelectPackageInput.sSettings ??= (($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$mskq.LVCS$1.VTUGlobalSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LVCS$IVTURemoteService$GetGlobalSettings();
                    }, $jHEIkg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings)).$h,"p":[{"n":"s","p":2157251}],"n":"","d":381910,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5))) ?? (() =>
                    {
                        //new $.$mskq.LVCS$1.VTUGlobalSettings()
                        const $t6 = $.$mskq.LVCS$1.VTUGlobalSettings;
                        const $i6 = new $t6();
                        $i6.$ctor$3();
                        return $i6;
                    })());
                    /*var*/ let model = (this.Input.FormField?.LCFCI$IFormField$Form.LCFCI$IFormBuilder$ModelValue ?? null);
                    let internetData;
                    if ($.$is(model, $.$mskq.LVCM.VTUInternetDataUserInfo, { set $v($v){ internetData = $v; } }))
                    {
                        this.packages = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$mskq.LVCM.VTUMobileNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$ySWu.LVC.VTUSelectPackageInput.sPackages.InternetData, internetData.MobileNetwork);
                        this.pricing = $.$ySWu.LVC.VTUSelectPackageInput.sSettings.get_Item$1(internetData.MobileNetwork);
                        this.surcharge = $.$ySWu.LVC.VTUSelectPackageInput.sSettings.InternetSurCharge;
                        this.SubscribeFormField("MobileNetwork", new ($.$$.S.Action$$$($.$fPer.LCFCR.IReactiveObservable, $.$fPer.LCFCR.IReactiveObservableChanges))().$ctor(this,  (/*o*/ o, /*c*/ c) =>
                        {
                            this.packages = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$mskq.LVCM.VTUMobileNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$ySWu.LVC.VTUSelectPackageInput.sPackages.InternetData, internetData.MobileNetwork);
                            this.pricing = $.$ySWu.LVC.VTUSelectPackageInput.sSettings.get_Item$1(internetData.MobileNetwork);
                            _ = this.StateChanged(false, false, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Client.Blazor\\VTUSelectPackageInput.razor.cs", "OnInitializedAsync", 48);
                        }, $aZaUPi ??= {"r":65537,"p":[{"n":"o","p":54167894},{"n":"c","p":54298966}],"n":"","d":381910,"h":0,"f":17825794}));
                    }
                    let tvData;
                    if ($.$is(model, $.$mskq.LVCM.VTUTVUserInfo, { set $v($v){ tvData = $v; } }))
                    {
                        this.packages = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$mskq.LVCM.VTUTVNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$ySWu.LVC.VTUSelectPackageInput.sPackages.TV, tvData.Provider);
                        this.pricing = $.$ySWu.LVC.VTUSelectPackageInput.sSettings.get_Item$2(tvData.Provider);
                        this.surcharge = $.$ySWu.LVC.VTUSelectPackageInput.sSettings.TVSurCharge;
                        this.SubscribeFormField("Provider", new ($.$$.S.Action$$$($.$fPer.LCFCR.IReactiveObservable, $.$fPer.LCFCR.IReactiveObservableChanges))().$ctor(this,  (/*o*/ o, /*c*/ c) =>
                        {
                            this.packages = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$mskq.LVCM.VTUTVNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$ySWu.LVC.VTUSelectPackageInput.sPackages.TV, tvData.Provider);
                            this.pricing = $.$ySWu.LVC.VTUSelectPackageInput.sSettings.get_Item$2(tvData.Provider);
                            _ = this.StateChanged(false, false, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Client.Blazor\\VTUSelectPackageInput.razor.cs", "OnInitializedAsync", 60);
                        }, $tgEhZc ??= {"r":65537,"p":[{"n":"o","p":54167894},{"n":"c","p":54298966}],"n":"","d":381910,"h":0,"f":17825794}));
                    }
                    ($t7 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770185686)
            
            //--TRIMMABLE-BOUNDARY-START(12885283798)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885283798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.packages !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 0);
                    __builder.AddComponentParameter(1, "MultiViewFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$6.MultiViewFeatures, 68/*MultiViewFeatures.Default*/), $.$hDPm.LCFCCM$6.MultiViewFeatures));
                    __builder.AddComponentParameter(2, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ & ~(this.packages.Count < 2 ? 1/*TabsFeatures.ShowTabs*/ : 0/*TabsFeatures.None*/)), $.$hDPm.LCFCCT$1.TabsFeatures));
                    __builder.AddComponentParameter(3, "MenuFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 65536/*MenuFeatures.Scroll*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                    __builder.AddComponentParameter(4, "head-class", "bg-primary-01");
                    __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        let $en8 = $.$sl.SL.Enumerable.OrderBy$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$$.S.Int32, this.packages, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$$.S.Int32))().$ctor(this,  (/*o*/ o) =>
                        {
                            return $.$$.S.String.StartsWith$2.call(o.Key, "Def", 3/*StringComparison.InvariantCultureIgnoreCase*/) ? 0 : $.$$.S.String.StartsWith$2.call(o.Key, "Da", 3/*StringComparison.InvariantCultureIgnoreCase*/) ? 1 : $.$$.S.String.StartsWith$2.call(o.Key, "We", 3/*StringComparison.InvariantCultureIgnoreCase*/) ? 2 : $.$$.S.String.StartsWith$2.call(o.Key, "Mo", 3/*StringComparison.InvariantCultureIgnoreCase*/) ? 3 : 4;
                        }, $cjNWDh ??= {"r":655361,"p":[{"n":"o","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)).$h}],"n":"","d":381910,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                        while ($en8.SC$1$IEnumerator$MoveNext())
                        {
                            let _kv = $en8.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let kv = _kv;
                                __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 6);
                                __builder2.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ViewFeatures, 5632/*ViewFeatures.Default*/ & ~512/*ViewFeatures.DeferRendering*/), $.$vWqU.LCFCC.ViewFeatures));
                                __builder2.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenElement(9, "b");
                                        __builder3.AddAttribute$5(10, "class", "nowrap");
                                        __builder3.AddContent$4(11, $.$$.S.String.IsNullOrEmpty(kv.Key) ? "Default" : kv.Key);
                                        __builder3.CloseElement();
                                    }, $upQcQe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":381910,"h":0,"f":17825794});
                                }), $oowTGc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":381910,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(12, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$mskq.LVCM.VTUPackage), 13);
                                        __builder3.AddComponentParameter(14, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$mskq.LVCM.VTUPackage), kv.Value));
                                        __builder3.AddComponentParameter(15, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                        __builder3.AddComponentParameter(16, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 2), $.$$.S.Int32));
                                        __builder3.AddComponentParameter(17, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                        __builder3.AddComponentParameter(18, "Class", "mgt");
                                        __builder3.AddComponentParameter(19, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                        __builder3.AddAttribute$3(20, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mskq.LVCM.VTUPackage, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$mskq.LVCM.VTUPackage))))().$ctor(this, ( (/*package*/ $package) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                            {
                                                /*System.Collections.Generic.IEnumerable<LivingThing.VTU.Common.Settings.VTUPricing>?*/ let __ca1__;
                                                /*LivingThing.VTU.Common.Settings.VTUPricing?*/ let __ca2__;
                                                /*var*/ let prc = ((__ca1__ = this.pricing) !== null ? ((__ca2__ = $.$sl.SL.Enumerable.FirstOrDefault$1($.$mskq.LVCS$1.VTUPricing, __ca1__, new ($.$$.S.Func$$$($.$mskq.LVCS$1.VTUPricing, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                                                {
                                                    return p.Package === $package.Data.Code;
                                                }, $IbVEeg ??= {"r":262145,"p":[{"n":"p","p":2812611}],"n":"","d":381910,"h":0,"f":17825794}))) !== null ? __ca2__.Amount : null) : null);
                                                __builder4.OpenElement(21, "div");
                                                __builder4.AddAttribute$5(22, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bd" + $.$strNN((this.Value.Code === $package.Data.Code ? " bg-primary-01" : " bg-card"))) + " corner") + " pd") + " text-center") + " hf") + " pos-rel") + " clip") + " stack");
                                                __builder4.AddAttribute$5(23, "title", $package.Data.Title);
                                                __builder4.OpenElement(24, "div");
                                                __builder4.AddAttribute$5(25, "class", "hx-06 mgx-a mgb flex round");
                                                __builder4.OpenElement(26, "h3");
                                                __builder4.AddAttribute$5(27, "class", "mg-a text-center cl-primary");
                                                __builder4.AddContent$4(28, $package.Data.Cost !== null || prc !== null ? `${$.$strNN((prc ?? $package.Data.GetSaleCost(this.surcharge)).ToString())}` : "");
                                                __builder4.CloseElement();
                                                __builder4.CloseElement();
                                                __builder4.AddMarkupContent(29, "\r\n                                ");
                                                __builder4.OpenElement(30, "span");
                                                __builder4.AddAttribute$5(31, "class", "mgy-a nowrap-2");
                                                __builder4.AddContent$4(32, $package.Data.Title);
                                                __builder4.CloseElement();
                                                __builder4.CloseElement();
                                            }, $AmKKte ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":381910,"h":0,"f":17825794});
                                        }), $hCPvzj ??= {"r":6881395,"p":[{"n":"package","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mskq.LVCM.VTUPackage, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$mskq.LVCM.VTUPackage)).$h}],"n":"","d":381910,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                    }, $acaQDg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":381910,"h":0,"f":17825794});
                                }), $ZBKTRg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":381910,"h":0,"f":17825794}));
                                __builder2.SetKey(kv.Key);
                                __builder2.CloseComponent();
                            }
                        }
                    }), $amjnoe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":381910,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 33);
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885283798)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.VTU.Common.Models.VTUPackage>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.VTU.Common.Models.VTUPackage>)
            LCFCCD$1$IDataListSelectableController$LivingThing$VTU$Common$Models$VTUPackage$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(8590316502)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590316502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590316502)
            
            //--TRIMMABLE-BOUNDARY-START(8590316502)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590316502)
            
            //--TRIMMABLE-BOUNDARY-START(4295349206)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295349206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(51539989462)
                    this.sSettings = null;
                    //--TRIMMABLE-BOUNDARY-END(51539989462)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295349206)
            
            static $h = 381910;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCI.BaseInputEditor$$($.$mskq.LVCM.VTUSelectPackage); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360120278),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475218390,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 381910,
      "h": 34360120278,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360120278)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065152982),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$mskq.LVCM.VTUPackage).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$2",
      "d": 381910,
      "h": 30065152982,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30065152982),
//--TRIMMABLE-BOUNDARY-START(25770185686),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 381910,
      "h": 25770185686,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(25770185686),
//--TRIMMABLE-BOUNDARY-START(12885283798),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 381910,
      "h": 12885283798,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885283798)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245022166),
    {
      "t": 1239747,
      "n": "sPackages",
      "d": 381910,
      "h": 47245022166,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245022166),
//--TRIMMABLE-BOUNDARY-START(51539989462),
    {
      "t": 2550467,
      "n": "sSettings",
      "d": 381910,
      "h": 51539989462,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539989462),
//--TRIMMABLE-BOUNDARY-START(38655087574),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)).$h,
      "n": "packages",
      "d": 381910,
      "h": 38655087574,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655087574),
//--TRIMMABLE-BOUNDARY-START(55834956758),
    {
      "t": 655361,
      "n": "surcharge",
      "d": 381910,
      "h": 55834956758,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834956758),
//--TRIMMABLE-BOUNDARY-START(42950054870),
    {
      "t": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "n": "pricing",
      "d": 381910,
      "h": 42950054870,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950054870)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590316502),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 381910,
      "h": 8590316502,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590316502)
  ],
  "h": 381910
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$$.S.IDisposable, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUSelectPackage)), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$mskq.LVCM.VTUSelectPackage), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUSelectPackage)), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUSelectPackage)), $.$hDPm.LCFCCD$1.IDataListPostFilterController$$($.$mskq.LVCM.VTUSelectPackage), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$mskq.LVCM.VTUSelectPackage), $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$mskq.LVCM.VTUPackage), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$mskq.LVCM.VTUPackage), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Client.VTUSelectPackageInput`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Client${separator}VTUSelectPackageInput`; }
        });
        //--TRIMMABLE-BOUNDARY-END(381910)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.VTU.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(54230)
