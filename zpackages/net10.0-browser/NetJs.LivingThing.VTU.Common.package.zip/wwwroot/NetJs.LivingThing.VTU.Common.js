
//--TRIMMABLE-BOUNDARY-START(60099)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $nYKj) {
    "use strict";
    let _;
    let $RZqXHk;
    let $XAahff;
    let $HszFYd;
    let $fwyjkj;
    let $mIxWmg;
    let $UOFkAa;
    let $bIlAck;
    let $HUtAUh;
    let $ZzuRBk;
    let $KqfjCa;
    let $iHBHpj;
    let $LDBHOj;
    let $cCBhNa;
    let $mAtzdk;
    let $dCOomk;
    let $euTkJj;
    let $oqeZng;
    let $YJIRMk;
    let $Acdxck;
    let $VWvDje;
    let $BCjjob;
    let $VxMsue;
    let $VXdMpf;
    let $wnraFj;
    let $HOFpzd;
    let $RHppWg;
    let $dPVzwc;
    let $bknpWj;
    let $KQjooc;
    let $rJBFTk;
    let $oiJXyi;
    let $fiPmXc;
    let $AhzmNj;
    let $OILoEh;
    let $zuOXDa;
    let $bdCylj;
    let $zNmTsg;
    let $bpBzMa;
    let $QPsBEh;
    let $BAosvj;
    let $Gfaael;
    let $gNQbVk;
    let $nXaGZk;
    let $Ppauzg;
    let $uJJBil;
    let $csuQnl;
    let $GMcHxh;
    let $XmQmHc;
    let $hqbzHd;
    let $FCrQlj;
    let $nsHDCi;
    let $ZIqfQg;
    let $SDwxnj;
    let $ZjZhwk;
    let $jQoacc;
    let $IzJHAe;
    let $LegTRh;
    let $sjFpsb;
    let $jvyusc;
    let $gYIePh;
    let $UOCODj;
    let $LPYcVi;
    let $ATWEIj;
    let $NqLwgf;
    let $YHXLdh;
    let $bIFNxk;
    let $dJEZCc;
    let $lPBdhc;
    let $cLWPlb;
    let $vrYsWi;
    let $kKacGa;
    let $GlHidc;
    let $obTIrh;
    let $NvvnVj;
    let $wYtQjj;
    let $DWVeUg;
    let $BZyQXe;
    let $SxPOik;
    let $IpEjpi;
    let $gYLIwc;
    let $hFJKCf;
    let $VWZoee;
    let $MgvPGg;
    let $snWnab;
    let $HToeHk;
    let $JFHABg;
    let $ekSzld;
    let $dsxaJj;
    let $XxoKSh;
    let $TlSIPc;
    let $aBXOxb;
    let $sFKiih;
    let $wvgGVa;
    let $DQOJhh;
    let $pTyfOb;
    let $YkCvRh;
    let $gsocff;
    let $fQNGke;
    let $PjcUbj;
    let $NftbSg;
    let $qZZCSd;
    let $JSyuTd;
    let $VihUef;
    let $beFjTc;
    let $pcjXzg;
    let $hnPHJg;
    let $mjGFwa;
    let $xDsCYc;
    let $ZdTTfd;
    let $iiUYbl;
    let $SNOvhk;
    let $mtYSDa;
    let $uuLxXk;
    let $DRICwe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.VTU.Common", 
    {
  "h": 60099,
  "f": "LivingThing.VTU.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.VTU.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.VTU.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2091715)
        $asm.$cls(`$mskq.LVCS.IVTUMobileAirtimeProvider`, ($self) => class IVTUMobileAirtimeProvider
        {
            static $h = 2091715;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297059011),
    {
      "r": 178454529,
      "p": [
        {
          "n": "phoneNumber",
          "p": 1310721
        },
        {
          "n": "network",
          "p": 1043139
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "referenceId",
          "p": 1310721
        }
      ],
      "n": "SendAirtime",
      "o": "LVCS$IVTUMobileAirtimeProvider$SendAirtime",
      "d": 2091715,
      "h": 4297059011,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297059011)
  ],
  "h": 2091715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Services.IVTUMobileAirtimeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Services${separator}IVTUMobileAirtimeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2091715)
        
        

        //--TRIMMABLE-BOUNDARY-START(2157251)
        $asm.$cls(`$mskq.LVCS.IVTURemoteService`, ($self) => class IVTURemoteService
        {
            static $h = 2157251;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182026435),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages)).$h,
      "n": "GetPackages",
      "o": "LVCS$IVTURemoteService$GetPackages",
      "d": 2157251,
      "h": 17182026435,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17182026435),
//--TRIMMABLE-BOUNDARY-START(8592091843),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings)).$h,
      "n": "GetGlobalSettings",
      "o": "LVCS$IVTURemoteService$GetGlobalSettings",
      "d": 2157251,
      "h": 8592091843,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592091843),
//--TRIMMABLE-BOUNDARY-START(21476993731),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))).$h,
      "p": [
        {
          "n": "tierName",
          "p": 1310721
        },
        {
          "n": "userParameter",
          "p": 1310721
        }
      ],
      "n": "Verify",
      "o": "LVCS$IVTURemoteService$Verify",
      "d": 2157251,
      "h": 21476993731,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476993731),
//--TRIMMABLE-BOUNDARY-START(4297124547),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)).$h,
      "p": [
        {
          "n": "tierName",
          "p": 1310721
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "userParameter",
          "p": 1310721
        },
        {
          "n": "referenceId",
          "p": 1310721
        }
      ],
      "n": "BuyVTU",
      "o": "LVCS$IVTURemoteService$BuyVTU",
      "d": 2157251,
      "h": 4297124547,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297124547),
//--TRIMMABLE-BOUNDARY-START(12887059139),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))).$h,
      "p": [
        {
          "n": "referenceId",
          "p": 1310721
        }
      ],
      "n": "GetOrderStatus",
      "o": "LVCS$IVTURemoteService$GetOrderStatus",
      "d": 2157251,
      "h": 12887059139,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887059139)
  ],
  "h": 2157251,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Services.IVTURemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Services${separator}IVTURemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2157251)
        
        

        //--TRIMMABLE-BOUNDARY-START(1239747)
        $asm.$cls(`$mskq.LVCM.VTUPackages`, ($self) => class VTUPackages extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360978115)
            /*Dictionary<VTUMobileNetwork, Dictionary<string, VTUPackage[]>>*/ InternetData = null;
            //--TRIMMABLE-BOUNDARY-END(34360978115)
            
            //--TRIMMABLE-BOUNDARY-START(55835814595)
            /*Dictionary<VTUTVNetwork, Dictionary<string, VTUPackage[]>>*/ TV = null;
            //--TRIMMABLE-BOUNDARY-END(55835814595)
            
            //--TRIMMABLE-BOUNDARY-START(12886141635)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886141635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886141635)
            
            //--TRIMMABLE-BOUNDARY-START(12886141635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886141635)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360978115)
                this.InternetData = null;
                //--TRIMMABLE-BOUNDARY-END(34360978115)
                
                //--TRIMMABLE-BOUNDARY-START(55835814595)
                this.TV = null;
                //--TRIMMABLE-BOUNDARY-END(55835814595)
                
            }
            static $h = 1239747;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360978115),
    {
      "p": $.$$.SCG.Dictionary$$$($.$mskq.LVCM.VTUMobileNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage))).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476076227,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950912707,
        "f": 83886081
      },
      "n": "InternetData",
      "d": 1239747,
      "h": 34360978115,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360978115),
//--TRIMMABLE-BOUNDARY-START(55835814595),
    {
      "p": $.$$.SCG.Dictionary$$$($.$mskq.LVCM.VTUTVNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage))).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066010819,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540847299,
        "f": 83886081
      },
      "n": "TV",
      "d": 1239747,
      "h": 55835814595,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835814595)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886141635),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1239747,
      "h": 12886141635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886141635)
  ],
  "h": 1239747
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUPackages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUPackages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1239747)
        
        

        //--TRIMMABLE-BOUNDARY-START(977603)
        $asm.$cls(`$mskq.LVCM.VTUMeterTypeCustomAttributesProvider`, ($self) => class VTUMeterTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295944899)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295944899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295944899)
            
            static $h = 977603;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295944899),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 977603,
      "h": 4295944899,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295944899)
  ],
  "h": 977603
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUMeterTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUMeterTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(977603)
        
        

        //--TRIMMABLE-BOUNDARY-START(1174211)
        $asm.$cls(`$mskq.LVCM.VTUPackage`, ($self) => class VTUPackage extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111670323907)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(111670323907)
            
            //--TRIMMABLE-BOUNDARY-START(25770977987)
            /*string*/ Code = null;
            //--TRIMMABLE-BOUNDARY-END(25770977987)
            
            //--TRIMMABLE-BOUNDARY-START(30065945283)
            /*Money?*/ Cost = null;
            //--TRIMMABLE-BOUNDARY-END(30065945283)
            
            //--TRIMMABLE-BOUNDARY-START(34360912579)
            /*double*/ Discount = 0;
            //--TRIMMABLE-BOUNDARY-END(34360912579)
            
            //--TRIMMABLE-BOUNDARY-START(73015618243)
            /*Money? */ GetSaleCost(/*int*/ surChargeIfNoDiscount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015618243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Cost + $.$fPer.LCFCDM.Money.op_Implicit$1(this.Discount === 0 ? surChargeIfNoDiscount : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(73015618243)
            
            //--TRIMMABLE-BOUNDARY-START(21476010691)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476010691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476010691)
            
            //--TRIMMABLE-BOUNDARY-START(21476010691)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476010691)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065945283)
                this.Cost = null;
                //--TRIMMABLE-BOUNDARY-END(30065945283)
                
            }
            static $h = 1174211;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670323907),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720650947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375356611,
        "f": 83886081
      },
      "n": "Title",
      "d": 1174211,
      "h": 111670323907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670323907),
//--TRIMMABLE-BOUNDARY-START(25770977987),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950847171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605552835,
        "f": 83886081
      },
      "n": "Code",
      "d": 1174211,
      "h": 25770977987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770977987),
//--TRIMMABLE-BOUNDARY-START(30065945283),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540781763,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195487427,
        "f": 83886081
      },
      "n": "Cost",
      "d": 1174211,
      "h": 30065945283,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065945283),
//--TRIMMABLE-BOUNDARY-START(34360912579),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130716355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785422019,
        "f": 83886081
      },
      "n": "Discount",
      "d": 1174211,
      "h": 34360912579,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360912579)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015618243),
    {
      "r": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "surChargeIfNoDiscount",
          "p": 655361
        }
      ],
      "n": "GetSaleCost",
      "d": 1174211,
      "h": 73015618243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015618243)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476010691),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1174211,
      "h": 21476010691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476010691)
  ],
  "h": 1174211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUPackage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUPackage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1174211)
        
        

        //--TRIMMABLE-BOUNDARY-START(2812611)
        $asm.$cls(`$mskq.LVCS$1.VTUPricing`, ($self) => class VTUPricing extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51542420163)
            /*string*/ Package = null;
            //--TRIMMABLE-BOUNDARY-END(51542420163)
            
            //--TRIMMABLE-BOUNDARY-START(81607191235)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(81607191235)
            
            //--TRIMMABLE-BOUNDARY-START(21477649091)
            /*Money*/ Amount;
            //--TRIMMABLE-BOUNDARY-END(21477649091)
            
            //--TRIMMABLE-BOUNDARY-START(85902158531)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902158531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$strNN((this.Title ?? $.$$.S.String.ToString.call(this.Package))) + $.$strNN(($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Amount) ? ", " + $.$strNN(this.Amount.ToString()) : ""));
            }
            //--TRIMMABLE-BOUNDARY-END(85902158531)
            
            //--TRIMMABLE-BOUNDARY-START(17182681795)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182681795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182681795)
            
            //--TRIMMABLE-BOUNDARY-START(17182681795)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182681795)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51542420163)
                this.Package = null;
                //--TRIMMABLE-BOUNDARY-END(51542420163)
                
                //--TRIMMABLE-BOUNDARY-START(81607191235)
                this.Title = null;
                //--TRIMMABLE-BOUNDARY-END(81607191235)
                
                //--TRIMMABLE-BOUNDARY-START(21477649091)
                this.Amount = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(21477649091)
                
            }
            static $h = 2812611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542420163),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657518275,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722289347,
        "f": 83886081
      },
      "n": "Package",
      "d": 2812611,
      "h": 51542420163,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542420163),
//--TRIMMABLE-BOUNDARY-START(81607191235),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247452867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312223939,
        "f": 83886081
      },
      "n": "Title",
      "d": 2812611,
      "h": 81607191235,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 3,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607191235),
//--TRIMMABLE-BOUNDARY-START(21477649091),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067583683,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132354755,
        "f": 83886081
      },
      "n": "Amount",
      "d": 2812611,
      "h": 21477649091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477649091)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85902158531),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2812611,
      "h": 85902158531,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85902158531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182681795),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2812611,
      "h": 17182681795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182681795)
  ],
  "h": 2812611
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Settings.VTUPricing`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Settings${separator}VTUPricing`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2812611)
        
        

        //--TRIMMABLE-BOUNDARY-START(1764035)
        $asm.$cls(`$mskq.LVCM.VTUTVNetworkCustomAttributesProvider`, ($self) => class VTUTVNetworkCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296731331)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296731331)
            
            //--TRIMMABLE-BOUNDARY-START(8591698627)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591698627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$mskq.LVCM.VTUTVNetworkCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(5, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("None", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DSTV", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/dstv.png"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("GOTV", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/gotv.png"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StarTimes", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/startimes.png"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Showmax", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/showmax.png"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$mskq.LVCM.VTUTVNetworkCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $HszFYd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1764035,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $fwyjkj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1764035,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591698627)
            
            static $h = 1764035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591698627),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1764035,
      "h": 8591698627,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591698627)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296731331),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1764035,
      "h": 4296731331,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296731331)
  ],
  "h": 1764035
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUTVNetworkCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUTVNetworkCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1764035)
        
        

        //--TRIMMABLE-BOUNDARY-START(1108675)
        $asm.$cls(`$mskq.LVCM.VTUMobileNetworkCustomAttributesProvider`, ($self) => class VTUMobileNetworkCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296075971)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296075971)
            
            //--TRIMMABLE-BOUNDARY-START(8591043267)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591043267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$mskq.LVCM.VTUMobileNetworkCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("None", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MTN", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/mtn.png"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Glo", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/glo.png"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Etisalat", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/9mobile.png"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Airtel", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/airtel.png"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Smile", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Key = "smile-direct";
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/smile.png"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Spectranet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/spectranet.png"], [-1], null);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$mskq.LVCM.VTUMobileNetworkCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UOFkAa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1108675,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $bIlAck ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1108675,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591043267)
            
            static $h = 1108675;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591043267),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1108675,
      "h": 8591043267,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591043267)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296075971),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1108675,
      "h": 4296075971,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296075971)
  ],
  "h": 1108675
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUMobileNetworkCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUMobileNetworkCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1108675)
        
        

        //--TRIMMABLE-BOUNDARY-START(649923)
        $asm.$cls(`$mskq.LVCM.VTUBettingCompanyCustomAttributesProvider`, ($self) => class VTUBettingCompanyCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295617219)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295617219)
            
            //--TRIMMABLE-BOUNDARY-START(8590584515)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590584515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$mskq.LVCM.VTUBettingCompanyCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(16, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("bet9ja", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Title = "Bet9ja";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("bangbet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Title = "BangBet";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("betking", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Title = "BetKing";
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_1xbet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Title = "1xBet";
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("betway", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Title = "BetWay";
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("merrybet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Title = "merrybet";
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("naijabet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Title = "naijabet";
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("nairabet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Title = "nairabet";
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("bet9ja_agent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Title = "Bet9ja Agent";
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("mlotto", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Title = "Mlotto";
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("western_lotto", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Title = "Western Lotto";
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("hallabet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Title = "HallaBet";
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("green_lotto", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Title = "Green Lotto";
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("betland", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t16 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i16 = new $t16();
                            $i16.$ctor$4();
                            $i16.Title = "Bet Land";
                            return $i16;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("betlion", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t17 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i17 = new $t17();
                            $i17.$ctor$4();
                            $i17.Title = "Bet Lion";
                            return $i17;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("supabet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t18 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i18 = new $t18();
                            $i18.$ctor$4();
                            $i18.Title = "Supa Bet";
                            return $i18;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$mskq.LVCM.VTUBettingCompanyCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KqfjCa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":649923,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $iHBHpj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":649923,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590584515)
            
            static $h = 649923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590584515),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 649923,
      "h": 8590584515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590584515)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295617219),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 649923,
      "h": 4295617219,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295617219)
  ],
  "h": 649923
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUBettingCompanyCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUBettingCompanyCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(649923)
        
        

        //--TRIMMABLE-BOUNDARY-START(256707)
        $asm.$cls(`$mskq.LVC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295224003)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295224003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$mskq.LVCS.IVTURemoteService, $.$mskq.LVCS.IVTURemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$mskq.LVCS.IVTURemoteService_Mocking().$ctor$3(impl);
                }, $RZqXHk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":256707,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295224003)
            
            static $h = 256707;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295224003),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 256707,
      "h": 4295224003,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295224003)
  ],
  "h": 256707
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(256707)
        
        

        //--TRIMMABLE-BOUNDARY-START(2616003)
        $asm.$cls(`$mskq.LVCS$1.VTUGlobalSettingsCustomAttributesProvider`, ($self) => class VTUGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297583299)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297583299)
            
            //--TRIMMABLE-BOUNDARY-START(8592550595)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592550595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$mskq.LVCS$1.VTUGlobalSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("MTNInternetPricing", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.InputType = $.$cast((-9223372036854775773n), $.$fPer.LCFC.InputType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("GloInternetPricing", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.InputType = $.$cast((-9223372036854775773n), $.$fPer.LCFC.InputType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AirtelInternetPricing", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.InputType = $.$cast((-9223372036854775773n), $.$fPer.LCFC.InputType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EtisalatInternetPricing", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.InputType = $.$cast((-9223372036854775773n), $.$fPer.LCFC.InputType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DSTVPricing", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.InputType = $.$cast((-9223372036854775773n), $.$fPer.LCFC.InputType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("GOTVPricing", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.InputType = $.$cast((-9223372036854775773n), $.$fPer.LCFC.InputType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StarTimesPricing", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.InputType = $.$cast((-9223372036854775773n), $.$fPer.LCFC.InputType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$mskq.LVCS$1.VTUGlobalSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $HUtAUh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2616003,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ZzuRBk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2616003,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$Iaui.LCFCMS.ComponentGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592550595)
            
            static $h = 2616003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592550595),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2616003,
      "h": 8592550595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592550595)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297583299),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2616003,
      "h": 4297583299,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297583299)
  ],
  "h": 2616003
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Settings.VTUGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Settings${separator}VTUGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2616003)
        
        

        //--TRIMMABLE-BOUNDARY-START(125635)
        $asm.$cls(`$mskq.LVC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295092931)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295092931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mskq.LVCM.VTUBettingCompany.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mskq.LVCM.VTUBettingCompanyCustomAttributesProvider, $.$mskq.LVCM.VTUBettingCompanyCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mskq.LVCM.VTUMeterType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mskq.LVCM.VTUMeterTypeCustomAttributesProvider, $.$mskq.LVCM.VTUMeterTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mskq.LVCM.VTUMobileNetwork.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mskq.LVCM.VTUMobileNetworkCustomAttributesProvider, $.$mskq.LVCM.VTUMobileNetworkCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mskq.LVCM.VTUPowerDisco.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mskq.LVCM.VTUPowerDiscoCustomAttributesProvider, $.$mskq.LVCM.VTUPowerDiscoCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mskq.LVCM.VTUTVNetwork.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mskq.LVCM.VTUTVNetworkCustomAttributesProvider, $.$mskq.LVCM.VTUTVNetworkCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$mskq.LVCS$1.VTUGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsCustomAttributesProvider, $.$mskq.LVCS$1.VTUGlobalSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295092931)
            
            static $h = 125635;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295092931),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 125635,
      "h": 4295092931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295092931)
  ],
  "h": 125635
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125635)
        
        

        //--TRIMMABLE-BOUNDARY-START(518851)
        $asm.$cls(`$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptorBuilder`, ($self) => class VTUAirtimeUserInfoTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590453443)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590453443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor()
                        const $t1 = $.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.VTU.Common.Models.VTUAirtimeUserInfo");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FCrQlj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":518851,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mskq.LVCM.VTUAirtimeUserInfo.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590453443)
            
            //--TRIMMABLE-BOUNDARY-START(4295486147)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295486147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295486147)
            
            //--TRIMMABLE-BOUNDARY-START(4295486147)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295486147)
            
            static $h = 518851;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590453443),
    {
      "r": 65537,
      "n": "Register",
      "d": 518851,
      "h": 8590453443,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590453443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295486147),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 518851,
      "h": 4295486147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295486147)
  ],
  "h": 518851
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUAirtimeUserInfoTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUAirtimeUserInfoTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(518851)
        
        

        //--TRIMMABLE-BOUNDARY-START(191171)
        $asm.$cls(`$mskq.LVC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295158467)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295158467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295158467)
            
            static $h = 191171;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295158467),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 191171,
      "h": 4295158467,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295158467)
  ],
  "h": 191171
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(191171)
        
        

        //--TRIMMABLE-BOUNDARY-START(1960643)
        $asm.$cls(`$mskq.LVCM.VTUTVUserInfoTypeDescriptorBuilder`, ($self) => class VTUTVUserInfoTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591895235)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591895235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mskq.LVCM.VTUTVUserInfoTypeDescriptor()
                        const $t1 = $.$mskq.LVCM.VTUTVUserInfoTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.VTU.Common.Models.VTUTVUserInfo");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NqLwgf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1960643,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mskq.LVCM.VTUTVUserInfo.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591895235)
            
            //--TRIMMABLE-BOUNDARY-START(4296927939)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296927939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296927939)
            
            //--TRIMMABLE-BOUNDARY-START(4296927939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296927939)
            
            static $h = 1960643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591895235),
    {
      "r": 65537,
      "n": "Register",
      "d": 1960643,
      "h": 8591895235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591895235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296927939),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1960643,
      "h": 4296927939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296927939)
  ],
  "h": 1960643
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUTVUserInfoTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUTVUserInfoTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1960643)
        
        

        //--TRIMMABLE-BOUNDARY-START(2747075)
        $asm.$cls(`$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptorBuilder`, ($self) => class VTUGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592681667)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592681667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor()
                        const $t1 = $.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.VTU.Common.Settings.VTUGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JFHABg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2747075,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mskq.LVCS$1.VTUGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592681667)
            
            //--TRIMMABLE-BOUNDARY-START(4297714371)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297714371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297714371)
            
            //--TRIMMABLE-BOUNDARY-START(4297714371)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297714371)
            
            static $h = 2747075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592681667),
    {
      "r": 65537,
      "n": "Register",
      "d": 2747075,
      "h": 8592681667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592681667)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297714371),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2747075,
      "h": 4297714371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297714371)
  ],
  "h": 2747075
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Settings.VTUGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Settings${separator}VTUGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2747075)
        
        

        //--TRIMMABLE-BOUNDARY-START(1567427)
        $asm.$cls(`$mskq.LVCM.VTUPowerUserInfoTypeDescriptorBuilder`, ($self) => class VTUPowerUserInfoTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591502019)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591502019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor()
                        const $t1 = $.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.VTU.Common.Models.VTUPowerUserInfo");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $wYtQjj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1567427,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mskq.LVCM.VTUPowerUserInfo.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591502019)
            
            //--TRIMMABLE-BOUNDARY-START(4296534723)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296534723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296534723)
            
            //--TRIMMABLE-BOUNDARY-START(4296534723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296534723)
            
            static $h = 1567427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591502019),
    {
      "r": 65537,
      "n": "Register",
      "d": 1567427,
      "h": 8591502019,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591502019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296534723),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1567427,
      "h": 4296534723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296534723)
  ],
  "h": 1567427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUPowerUserInfoTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUPowerUserInfoTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1567427)
        
        

        //--TRIMMABLE-BOUNDARY-START(1370819)
        $asm.$cls(`$mskq.LVCM.VTUPowerDiscoCustomAttributesProvider`, ($self) => class VTUPowerDiscoCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296338115)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296338115)
            
            //--TRIMMABLE-BOUNDARY-START(8591305411)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591305411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$mskq.LVCM.VTUPowerDiscoCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(13, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("None", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EkoElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Key = "eko-electric";
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/ekedc.png"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IkejaElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Key = "ikeja-electric";
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/ikedc.png"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AbujaElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Key = "abuja-electric";
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/aedc.png"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("KanoElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Key = "kano-electric";
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/kanedc.png"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PorthacourtElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Key = "porthacourt-electric";
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/phedc.png"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("JosElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Key = "jos-electric";
                            $i9.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/jedc.png"], [-1], null);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IbadanElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Key = "ibadan-electric";
                            $i10.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/ibedc.png"], [-1], null);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("KadunaElecdtric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Key = "kaduna-electric";
                            $i11.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/kadedc.png"], [-1], null);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EnuguElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Key = "enugu-electric";
                            $i12.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/enedc.png"], [-1], null);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BeninElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Key = "benin-electric";
                            $i13.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/benedc.png"], [-1], null);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("YolaElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Key = "yola-electric";
                            $i14.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/yoledc.png"], [-1], null);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AbaElectric", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Key = "aba-electric";
                            $i15.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=_content/LivingThing.VTU.Resources/img/abedc.png"], [-1], null);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$mskq.LVCM.VTUPowerDiscoCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $XmQmHc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1370819,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $hqbzHd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1370819,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591305411)
            
            static $h = 1370819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591305411),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1370819,
      "h": 8591305411,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591305411)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296338115),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1370819,
      "h": 4296338115,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296338115)
  ],
  "h": 1370819
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUPowerDiscoCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUPowerDiscoCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1370819)
        
        

        //--TRIMMABLE-BOUNDARY-START(2878147)
        $asm.$cls(`$mskq.LVC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297845443)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297845443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptorBuilder.Register();
                $.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptorBuilder.Register();
                $.$mskq.LVCM.VTUPowerUserInfoTypeDescriptorBuilder.Register();
                $.$mskq.LVCM.VTUTVUserInfoTypeDescriptorBuilder.Register();
                $.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297845443)
            
            static $h = 2878147;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297845443),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2878147,
      "h": 4297845443,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297845443)
  ],
  "h": 2878147
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2878147)
        
        

        //--TRIMMABLE-BOUNDARY-START(846531)
        $asm.$cls(`$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptorBuilder`, ($self) => class VTUInternetDataUserInfoTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590781123)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590781123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor()
                        const $t1 = $.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.VTU.Common.Models.VTUInternetDataUserInfo");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hnPHJg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":846531,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$mskq.LVCM.VTUInternetDataUserInfo.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590781123)
            
            //--TRIMMABLE-BOUNDARY-START(4295813827)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295813827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295813827)
            
            //--TRIMMABLE-BOUNDARY-START(4295813827)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295813827)
            
            static $h = 846531;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590781123),
    {
      "r": 65537,
      "n": "Register",
      "d": 846531,
      "h": 8590781123,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590781123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295813827),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 846531,
      "h": 4295813827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295813827)
  ],
  "h": 846531
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUInternetDataUserInfoTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUInternetDataUserInfoTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(846531)
        
        

        //--TRIMMABLE-BOUNDARY-START(1829571)
        $asm.$cls(`$mskq.LVCM.VTUTVUserInfo`, ($self) => class VTUTVUserInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606208195)
            /*VTUTVNetwork*/ Provider = 0;
            //--TRIMMABLE-BOUNDARY-END(81606208195)
            
            //--TRIMMABLE-BOUNDARY-START(73016273603)
            /*VTUSelectPackage*/ Package;
            //--TRIMMABLE-BOUNDARY-END(73016273603)
            
            //--TRIMMABLE-BOUNDARY-START(120260913859)
            /*string*/ SmartCardNumber = null;
            //--TRIMMABLE-BOUNDARY-END(120260913859)
            
            //--TRIMMABLE-BOUNDARY-START(77311240899)
            /*string*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(77311240899)
            
            //--TRIMMABLE-BOUNDARY-START(25771633347)
            /*string? */ get Description()
            {
                return this.Provider !== 0/*VTUTVNetwork.None*/ ? `${$.$strNN($.$$.S.Enum.ToStringT($.$mskq.LVCM.VTUTVNetwork, $.$$.S.UInt32, this.Provider))} subscription to ${$.$strNN(this.SmartCardNumber)} (${$.$strNN(this.Package.Title)})` : null;
            }
            //--TRIMMABLE-BOUNDARY-END(25771633347)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(21476666051)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476666051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476666051)
            
            //--TRIMMABLE-BOUNDARY-START(21476666051)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476666051)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73016273603)
                this.Package = new $.$mskq.LVCM.VTUSelectPackage();
                //--TRIMMABLE-BOUNDARY-END(73016273603)
                
                //--TRIMMABLE-BOUNDARY-START(120260913859)
                this.SmartCardNumber = null;
                //--TRIMMABLE-BOUNDARY-END(120260913859)
                
                //--TRIMMABLE-BOUNDARY-START(77311240899)
                this.PhoneNumber = null;
                //--TRIMMABLE-BOUNDARY-END(77311240899)
                
            }
            static $h = 1829571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81606208195),
    {
      "p": 1698499,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131371715,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376011971,
        "f": 83886081
      },
      "n": "Provider",
      "d": 1829571,
      "h": 81606208195,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 25,
              "t": 47614294
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606208195),
//--TRIMMABLE-BOUNDARY-START(73016273603),
    {
      "p": 1632963,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951502531,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196142787,
        "f": 83886081
      },
      "n": "Package",
      "d": 1829571,
      "h": 73016273603,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//DependsOn=Provider"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016273603),
//--TRIMMABLE-BOUNDARY-START(120260913859),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721306307,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965946563,
        "f": 83886081
      },
      "n": "SmartCardNumber",
      "d": 1829571,
      "h": 120260913859,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260913859),
//--TRIMMABLE-BOUNDARY-START(77311240899),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541437123,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786077379,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 1829571,
      "h": 77311240899,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 66,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//input-class=fsz-25"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311240899),
//--TRIMMABLE-BOUNDARY-START(25771633347),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361567939,
        "f": 50331649
      },
      "n": "Description",
      "d": 1829571,
      "h": 25771633347,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771633347)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476666051),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1829571,
      "h": 21476666051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476666051)
  ],
  "h": 1829571,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUTVUserInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUTVUserInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1829571)
        
        

        //--TRIMMABLE-BOUNDARY-START(715459)
        $asm.$cls(`$mskq.LVCM.VTUInternetDataUserInfo`, ($self) => class VTUInternetDataUserInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60130257603)
            /*VTUMobileNetwork*/ MobileNetwork = 0;
            //--TRIMMABLE-BOUNDARY-END(60130257603)
            
            //--TRIMMABLE-BOUNDARY-START(64425224899)
            /*VTUSelectPackage*/ Package;
            //--TRIMMABLE-BOUNDARY-END(64425224899)
            
            //--TRIMMABLE-BOUNDARY-START(68720192195)
            /*string*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(68720192195)
            
            //--TRIMMABLE-BOUNDARY-START(21475551939)
            /*string? */ get Description()
            {
                return this.MobileNetwork !== 0/*VTUMobileNetwork.None*/ ? `${$.$strNN($.$$.S.Enum.ToStringT($.$mskq.LVCM.VTUMobileNetwork, $.$$.S.UInt32, this.MobileNetwork))} data to ${$.$strNN(this.PhoneNumber)} (${$.$strNN(this.Package.Title)})` : null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475551939)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(17180584643)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180584643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180584643)
            
            //--TRIMMABLE-BOUNDARY-START(17180584643)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180584643)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425224899)
                this.Package = new $.$mskq.LVCM.VTUSelectPackage();
                //--TRIMMABLE-BOUNDARY-END(64425224899)
                
                //--TRIMMABLE-BOUNDARY-START(68720192195)
                this.PhoneNumber = null;
                //--TRIMMABLE-BOUNDARY-END(68720192195)
                
            }
            static $h = 715459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130257603),
    {
      "p": 1043139,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655421123,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310126787,
        "f": 83886081
      },
      "n": "MobileNetwork",
      "d": 715459,
      "h": 60130257603,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 25,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130257603),
//--TRIMMABLE-BOUNDARY-START(64425224899),
    {
      "p": 1632963,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245355715,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900061379,
        "f": 83886081
      },
      "n": "Package",
      "d": 715459,
      "h": 64425224899,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//DependsOn=MobileNetwork"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425224899),
//--TRIMMABLE-BOUNDARY-START(68720192195),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835290307,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489995971,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 715459,
      "h": 68720192195,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 66,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//input-class=fsz-25"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720192195),
//--TRIMMABLE-BOUNDARY-START(21475551939),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065486531,
        "f": 50331649
      },
      "n": "Description",
      "d": 715459,
      "h": 21475551939,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475551939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180584643),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 715459,
      "h": 17180584643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180584643)
  ],
  "h": 715459,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUInternetDataUserInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUInternetDataUserInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(715459)
        
        

        //--TRIMMABLE-BOUNDARY-START(2026179)
        $asm.$cls(`$mskq.LVC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591960771)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591960771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mskq.LVC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mskq.LVCS.VTUAirtimeRechargeServiceProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUAirtimeRechargeServiceProvider, x);
                }, $VWvDje ??= {"r":1001240,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUAirtimeRechargeServiceProvider, x);
                }, $BCjjob ??= {"r":$.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mskq.LVCS.VTUInternetDataServiceProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUInternetDataServiceProvider, x);
                }, $VxMsue ??= {"r":1001240,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUInternetDataServiceProvider, x);
                }, $VXdMpf ??= {"r":$.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mskq.LVCS.VTUPowerServiceProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUPowerServiceProvider, x);
                }, $wnraFj ??= {"r":1001240,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUPowerServiceProvider, x);
                }, $HOFpzd ??= {"r":$.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$mskq.LVCS.VTUTVServiceProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUTVServiceProvider, x);
                }, $RHppWg ??= {"r":1001240,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUTVServiceProvider, x);
                }, $dPVzwc ??= {"r":$.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794}));
                $.$mskq.LVC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$mskq.LVC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
                $.$mskq.LVC.FastEnumStartupExtension.AddGeneratedFastEnums(services);
                $.$mskq.LVC.MockingFactoryExtension.AddGeneratedMockedServices(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591960771)
            
            //--TRIMMABLE-BOUNDARY-START(12886928067)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886928067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_VTUAirtimeRechargeServiceProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$mskq.LVCS.VTUAirtimeRechargeServiceProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$mskq.LVCS.VTUAirtimeRechargeServiceProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_VTUAirtimeRechargeServiceProvider, $bknpWj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_VTUAirtimeRechargeServiceProvider","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUAirtimeRechargeServiceProvider, x);
                    }), $KQjooc ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider, $rJBFTk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider_PaymentCategoryType_(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUAirtimeRechargeServiceProvider, x);
                    }), $oiJXyi ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider_PaymentCategoryType_, $fiPmXc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider_PaymentCategoryType_","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_VTUInternetDataServiceProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$mskq.LVCS.VTUInternetDataServiceProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$mskq.LVCS.VTUInternetDataServiceProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_VTUInternetDataServiceProvider, $AhzmNj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_VTUInternetDataServiceProvider","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider_1(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUInternetDataServiceProvider, x);
                    }), $OILoEh ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider_1, $zuOXDa ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider_1","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider_PaymentCategoryType__1(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUInternetDataServiceProvider, x);
                    }), $bdCylj ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider_PaymentCategoryType__1, $zNmTsg ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider_PaymentCategoryType__1","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_VTUPowerServiceProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$mskq.LVCS.VTUPowerServiceProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$mskq.LVCS.VTUPowerServiceProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_VTUPowerServiceProvider, $bpBzMa ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_VTUPowerServiceProvider","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider_2(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUPowerServiceProvider, x);
                    }), $QPsBEh ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider_2, $BAosvj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider_2","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider_PaymentCategoryType__2(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUPowerServiceProvider, x);
                    }), $Gfaael ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider_PaymentCategoryType__2, $gNQbVk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider_PaymentCategoryType__2","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_VTUTVServiceProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$mskq.LVCS.VTUTVServiceProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$mskq.LVCS.VTUTVServiceProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_VTUTVServiceProvider, $nXaGZk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_VTUTVServiceProvider","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider_3(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUTVServiceProvider, x);
                    }), $Ppauzg ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider_3, $uJJBil ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider_3","d":2026179,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider_PaymentCategoryType__3(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mskq.LVCS.VTUTVServiceProvider, x);
                    }), $csuQnl ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2026179,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType).$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mskq.LVC.ServiceRegistrar, Get_IPaymentTierProvider_PaymentCategoryType__3, $GMcHxh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider_PaymentCategoryType__3","d":2026179,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12886928067)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mskq.LVC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296993475)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296993475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296993475)
            
            //--TRIMMABLE-BOUNDARY-START(4296993475)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296993475)
            
            static $h = 2026179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591960771),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2026179,
      "h": 8591960771,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591960771),
//--TRIMMABLE-BOUNDARY-START(12886928067),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 2026179,
      "h": 12886928067,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886928067)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296993475),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2026179,
      "h": 4296993475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296993475)
  ],
  "h": 2026179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2026179)
        
        

        //--TRIMMABLE-BOUNDARY-START(387779)
        $asm.$cls(`$mskq.LVCM.VTUAirtimeUserInfo`, ($self) => class VTUAirtimeUserInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245028035)
            /*VTUMobileNetwork*/ MobileNetwork = 0;
            //--TRIMMABLE-BOUNDARY-END(47245028035)
            
            //--TRIMMABLE-BOUNDARY-START(51539995331)
            /*string*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(51539995331)
            
            //--TRIMMABLE-BOUNDARY-START(17180256963)
            /*string? */ get Description()
            {
                return this.MobileNetwork !== 0/*VTUMobileNetwork.None*/ ? `${$.$strNN($.$$.S.Enum.ToStringT($.$mskq.LVCM.VTUMobileNetwork, $.$$.S.UInt32, this.MobileNetwork))} airtime to ${$.$strNN(this.PhoneNumber)}` : null;
            }
            //--TRIMMABLE-BOUNDARY-END(17180256963)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(12885289667)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885289667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885289667)
            
            //--TRIMMABLE-BOUNDARY-START(12885289667)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885289667)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51539995331)
                this.PhoneNumber = null;
                //--TRIMMABLE-BOUNDARY-END(51539995331)
                
            }
            static $h = 387779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245028035),
    {
      "p": 1043139,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360126147,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129929923,
        "f": 83886081
      },
      "n": "MobileNetwork",
      "d": 387779,
      "h": 47245028035,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 25,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 322243,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245028035),
//--TRIMMABLE-BOUNDARY-START(51539995331),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950060739,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719864515,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 387779,
      "h": 51539995331,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 66,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//input-class=fsz-25"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539995331),
//--TRIMMABLE-BOUNDARY-START(17180256963),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770191555,
        "f": 50331649
      },
      "n": "Description",
      "d": 387779,
      "h": 17180256963,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180256963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885289667),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 387779,
      "h": 12885289667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885289667)
  ],
  "h": 387779,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUAirtimeUserInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUAirtimeUserInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(387779)
        
        

        //--TRIMMABLE-BOUNDARY-START(1436355)
        $asm.$cls(`$mskq.LVCM.VTUPowerUserInfo`, ($self) => class VTUPowerUserInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066207427)
            /*VTUPowerDisco*/ Disco = 0;
            //--TRIMMABLE-BOUNDARY-END(30066207427)
            
            //--TRIMMABLE-BOUNDARY-START(81605814979)
            /*VTUMeterType*/ MeterType = 0;
            //--TRIMMABLE-BOUNDARY-END(81605814979)
            
            //--TRIMMABLE-BOUNDARY-START(77310847683)
            /*string*/ MeterNumber = null;
            //--TRIMMABLE-BOUNDARY-END(77310847683)
            
            //--TRIMMABLE-BOUNDARY-START(85900782275)
            /*string*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(85900782275)
            
            //--TRIMMABLE-BOUNDARY-START(25771240131)
            /*string? */ get Description()
            {
                return this.Disco !== 0/*VTUPowerDisco.None*/ ? `${$.$strNN($.$$.S.Enum.ToStringT($.$mskq.LVCM.VTUPowerDisco, $.$$.S.UInt32, this.Disco))} energy purchase to ${$.$strNN($.$$.S.Enum.ToStringT($.$mskq.LVCM.VTUMeterType, $.$$.S.UInt32, this.MeterType))} ${$.$strNN(this.MeterNumber)}` : null;
            }
            //--TRIMMABLE-BOUNDARY-END(25771240131)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(21476272835)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476272835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476272835)
            
            //--TRIMMABLE-BOUNDARY-START(21476272835)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476272835)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77310847683)
                this.MeterNumber = null;
                //--TRIMMABLE-BOUNDARY-END(77310847683)
                
                //--TRIMMABLE-BOUNDARY-START(85900782275)
                this.PhoneNumber = null;
                //--TRIMMABLE-BOUNDARY-END(85900782275)
                
            }
            static $h = 1436355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066207427),
    {
      "p": 1305283,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246076611,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490716867,
        "f": 83886081
      },
      "n": "Disco",
      "d": 1436355,
      "h": 30066207427,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 25,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066207427),
//--TRIMMABLE-BOUNDARY-START(81605814979),
    {
      "p": 912067,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425945795,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670586051,
        "f": 83886081
      },
      "n": "MeterType",
      "d": 1436355,
      "h": 81605814979,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 41,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605814979),
//--TRIMMABLE-BOUNDARY-START(77310847683),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836011203,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080651459,
        "f": 83886081
      },
      "n": "MeterNumber",
      "d": 1436355,
      "h": 77310847683,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310847683),
//--TRIMMABLE-BOUNDARY-START(85900782275),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015880387,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260520643,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 1436355,
      "h": 85900782275,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 66,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//input-class=fsz-25"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900782275),
//--TRIMMABLE-BOUNDARY-START(25771240131),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656142019,
        "f": 50331649
      },
      "n": "Description",
      "d": 1436355,
      "h": 25771240131,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771240131)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476272835),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1436355,
      "h": 21476272835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476272835)
  ],
  "h": 1436355,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUPowerUserInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUPowerUserInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1436355)
        
        

        //--TRIMMABLE-BOUNDARY-START(1632963)
        $asm.$str(`$mskq.LVCM.VTUSelectPackage`, ($self) => class VTUSelectPackage extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17181502147)
            /*string*/ Code = null;
            //--TRIMMABLE-BOUNDARY-END(17181502147)
            
            //--TRIMMABLE-BOUNDARY-START(55836207811)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(55836207811)
            
            //--TRIMMABLE-BOUNDARY-START(12886534851)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886534851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886534851)
            
            //--TRIMMABLE-BOUNDARY-START(12886534851)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886534851)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Code = this.Code;
                copy.Title = this.Title;
                return copy;
            }
            static $h = 1632963;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181502147),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771436739,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951305923,
        "f": 83886081
      },
      "n": "Code",
      "d": 1632963,
      "h": 17181502147,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181502147),
//--TRIMMABLE-BOUNDARY-START(55836207811),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361371331,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541240515,
        "f": 83886081
      },
      "n": "Title",
      "d": 1632963,
      "h": 55836207811,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836207811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886534851),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1632963,
      "h": 12886534851,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886534851)
  ],
  "h": 1632963
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUSelectPackage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUSelectPackage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1632963)
        
        

        //--TRIMMABLE-BOUNDARY-START(2222787)
        $asm.$cls(`$mskq.LVCS.IVTURemoteService_Mocking`, ($self) => class IVTURemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297190083)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297190083);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297190083)
            
            //--TRIMMABLE-BOUNDARY-START(21477059267)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.VTU.Common.Models.VTUPackages>> */ LVCS$IVTURemoteService$GetPackages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477059267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$mskq.LVCS.IVTURemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages).$type;
                    $i1.MethodName = "GetPackages";
                    return $i1;
                })();
                return this.InvokeAsync($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477059267)
            
            //--TRIMMABLE-BOUNDARY-START(12887124675)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.VTU.Common.Settings.VTUGlobalSettings>> */ LVCS$IVTURemoteService$GetGlobalSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887124675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$mskq.LVCS.IVTURemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings).$type;
                    $i2.MethodName = "GetGlobalSettings";
                    return $i2;
                })();
                return this.InvokeAsync($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887124675)
            
            //--TRIMMABLE-BOUNDARY-START(25772026563)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<System.Collections.Generic.Dictionary<string, string?>>> */ LVCS$IVTURemoteService$Verify(/*string*/ tierName, /*string*/ userParameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772026563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$mskq.LVCS.IVTURemoteService.$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$type;
                    $i3.MethodName = "Verify";
                    return $i3;
                })();
                return this.InvokeAsync($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, tierName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, userParameter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772026563)
            
            //--TRIMMABLE-BOUNDARY-START(8592157379)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.PaymentOrderTransactionModel>> */ LVCS$IVTURemoteService$BuyVTU(/*string*/ tierName, /*double*/ amount, /*string*/ userParameter, /*string*/ referenceId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592157379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$mskq.LVCS.IVTURemoteService.$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel).$type;
                    $i4.MethodName = "BuyVTU";
                    return $i4;
                })();
                return this.InvokeAsync($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, tierName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, userParameter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, referenceId) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592157379)
            
            //--TRIMMABLE-BOUNDARY-START(17182091971)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<System.Collections.Generic.Dictionary<string, string?>>> */ LVCS$IVTURemoteService$GetOrderStatus(/*string*/ referenceId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182091971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$mskq.LVCS.IVTURemoteService.$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$type;
                    $i5.MethodName = "GetOrderStatus";
                    return $i5;
                })();
                return this.InvokeAsync($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, referenceId) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182091971)
            
            static $h = 2222787;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297190083),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2222787,
      "h": 4297190083,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297190083)
  ],
  "h": 2222787
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Services.IVTURemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Services${separator}IVTURemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2222787)
        
        

        //--TRIMMABLE-BOUNDARY-START(912067)
        $asm.$str(`$mskq.LVCM.VTUMeterType`, ($self) => class VTUMeterType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Prepaid = 1;
            static PostPaid = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(912067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Prepaid": 1n,
                    "PostPaid": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295879363)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295879363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295879363)
            
            //--TRIMMABLE-BOUNDARY-START(4295879363)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295879363)
            
            static $h = 912067;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885813955),
    {
      "t": 912067,
      "n": "Prepaid",
      "d": 912067,
      "h": 12885813955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885813955),
//--TRIMMABLE-BOUNDARY-START(8590846659),
    {
      "t": 912067,
      "n": "PostPaid",
      "d": 912067,
      "h": 8590846659,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590846659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295879363),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 912067,
      "h": 4295879363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295879363)
  ],
  "h": 912067,
  "a": [
    {
      "t": 13631572,
      "c": 12898533460,
      "a": [
        {
          "v": 15335508,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUMeterType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUMeterType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(912067)
        
        

        //--TRIMMABLE-BOUNDARY-START(584387)
        $asm.$str(`$mskq.LVCM.VTUBettingCompany`, ($self) => class VTUBettingCompany extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static bet9ja = 0;
            static bangbet = 1;
            static betking = 2;
            static _1xbet = 3;
            static betway = 4;
            static merrybet = 5;
            static naijabet = 6;
            static nairabet = 7;
            static bet9ja_agent = 8;
            static mlotto = 9;
            static western_lotto = 10;
            static hallabet = 11;
            static green_lotto = 12;
            static betland = 13;
            static betlion = 14;
            static supabet = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "bet9ja": 0n,
                    "bangbet": 1n,
                    "betking": 2n,
                    "_1xbet": 3n,
                    "betway": 4n,
                    "merrybet": 5n,
                    "naijabet": 6n,
                    "nairabet": 7n,
                    "bet9ja_agent": 8n,
                    "mlotto": 9n,
                    "western_lotto": 10n,
                    "hallabet": 11n,
                    "green_lotto": 12n,
                    "betland": 13n,
                    "betlion": 14n,
                    "supabet": 15n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(8590518979)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590518979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590518979)
            
            //--TRIMMABLE-BOUNDARY-START(8590518979)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590518979)
            
            static $h = 584387;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180453571),
    {
      "t": 584387,
      "n": "bet9ja",
      "d": 584387,
      "h": 17180453571,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Bet9ja",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180453571),
//--TRIMMABLE-BOUNDARY-START(12885486275),
    {
      "t": 584387,
      "n": "bangbet",
      "d": 584387,
      "h": 12885486275,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "BangBet",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885486275),
//--TRIMMABLE-BOUNDARY-START(25770388163),
    {
      "t": 584387,
      "n": "betking",
      "d": 584387,
      "h": 25770388163,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "BetKing",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770388163),
//--TRIMMABLE-BOUNDARY-START(4295551683),
    {
      "t": 584387,
      "n": "_1xbet",
      "d": 584387,
      "h": 4295551683,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "1xBet",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295551683),
//--TRIMMABLE-BOUNDARY-START(38655290051),
    {
      "t": 584387,
      "n": "betway",
      "d": 584387,
      "h": 38655290051,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "BetWay",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655290051),
//--TRIMMABLE-BOUNDARY-START(51540191939),
    {
      "t": 584387,
      "n": "merrybet",
      "d": 584387,
      "h": 51540191939,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "merrybet",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540191939),
//--TRIMMABLE-BOUNDARY-START(60130126531),
    {
      "t": 584387,
      "n": "naijabet",
      "d": 584387,
      "h": 60130126531,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "naijabet",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130126531),
//--TRIMMABLE-BOUNDARY-START(64425093827),
    {
      "t": 584387,
      "n": "nairabet",
      "d": 584387,
      "h": 64425093827,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "nairabet",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425093827),
//--TRIMMABLE-BOUNDARY-START(21475420867),
    {
      "t": 584387,
      "n": "bet9ja_agent",
      "d": 584387,
      "h": 21475420867,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Bet9ja Agent",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475420867),
//--TRIMMABLE-BOUNDARY-START(55835159235),
    {
      "t": 584387,
      "n": "mlotto",
      "d": 584387,
      "h": 55835159235,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Mlotto",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835159235),
//--TRIMMABLE-BOUNDARY-START(73015028419),
    {
      "t": 584387,
      "n": "western_lotto",
      "d": 584387,
      "h": 73015028419,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Western Lotto",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015028419),
//--TRIMMABLE-BOUNDARY-START(47245224643),
    {
      "t": 584387,
      "n": "hallabet",
      "d": 584387,
      "h": 47245224643,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "HallaBet",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245224643),
//--TRIMMABLE-BOUNDARY-START(42950257347),
    {
      "t": 584387,
      "n": "green_lotto",
      "d": 584387,
      "h": 42950257347,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Green Lotto",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950257347),
//--TRIMMABLE-BOUNDARY-START(30065355459),
    {
      "t": 584387,
      "n": "betland",
      "d": 584387,
      "h": 30065355459,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Bet Land",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065355459),
//--TRIMMABLE-BOUNDARY-START(34360322755),
    {
      "t": 584387,
      "n": "betlion",
      "d": 584387,
      "h": 34360322755,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Bet Lion",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360322755),
//--TRIMMABLE-BOUNDARY-START(68720061123),
    {
      "t": 584387,
      "n": "supabet",
      "d": 584387,
      "h": 68720061123,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Supa Bet",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720061123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590518979),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 584387,
      "h": 8590518979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590518979)
  ],
  "h": 584387,
  "a": [
    {
      "t": 13631572,
      "c": 12898533460,
      "a": [
        {
          "v": 15335508,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUBettingCompany`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUBettingCompany`; }
        });
        //--TRIMMABLE-BOUNDARY-END(584387)
        
        

        //--TRIMMABLE-BOUNDARY-START(1043139)
        $asm.$str(`$mskq.LVCM.VTUMobileNetwork`, ($self) => class VTUMobileNetwork extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static MTN = 1;
            static Glo = 2;
            static Etisalat = 3;
            static Airtel = 4;
            static Smile = 5;
            static Spectranet = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1043139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "MTN": 1n,
                    "Glo": 2n,
                    "Etisalat": 3n,
                    "Airtel": 4n,
                    "Smile": 5n,
                    "Spectranet": 6n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296010435)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296010435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296010435)
            
            //--TRIMMABLE-BOUNDARY-START(4296010435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296010435)
            
            static $h = 1043139;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770846915),
    {
      "t": 1043139,
      "n": "None",
      "d": 1043139,
      "h": 25770846915,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770846915),
//--TRIMMABLE-BOUNDARY-START(21475879619),
    {
      "t": 1043139,
      "n": "MTN",
      "d": 1043139,
      "h": 21475879619,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/mtn.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475879619),
//--TRIMMABLE-BOUNDARY-START(17180912323),
    {
      "t": 1043139,
      "n": "Glo",
      "d": 1043139,
      "h": 17180912323,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/glo.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180912323),
//--TRIMMABLE-BOUNDARY-START(12885945027),
    {
      "t": 1043139,
      "n": "Etisalat",
      "d": 1043139,
      "h": 12885945027,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/9mobile.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885945027),
//--TRIMMABLE-BOUNDARY-START(8590977731),
    {
      "t": 1043139,
      "n": "Airtel",
      "d": 1043139,
      "h": 8590977731,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/airtel.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590977731),
//--TRIMMABLE-BOUNDARY-START(30065814211),
    {
      "t": 1043139,
      "n": "Smile",
      "d": 1043139,
      "h": 30065814211,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "smile-direct",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/smile.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065814211),
//--TRIMMABLE-BOUNDARY-START(34360781507),
    {
      "t": 1043139,
      "n": "Spectranet",
      "d": 1043139,
      "h": 34360781507,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/spectranet.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360781507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296010435),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1043139,
      "h": 4296010435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296010435)
  ],
  "h": 1043139,
  "a": [
    {
      "t": 13631572,
      "c": 12898533460,
      "a": [
        {
          "v": 15335508,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUMobileNetwork`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUMobileNetwork`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1043139)
        
        

        //--TRIMMABLE-BOUNDARY-START(1305283)
        $asm.$str(`$mskq.LVCM.VTUPowerDisco`, ($self) => class VTUPowerDisco extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static EkoElectric = 1;
            static IkejaElectric = 2;
            static AbujaElectric = 3;
            static KanoElectric = 4;
            static PorthacourtElectric = 5;
            static JosElectric = 6;
            static IbadanElectric = 7;
            static KadunaElecdtric = 8;
            static EnuguElectric = 9;
            static BeninElectric = 10;
            static YolaElectric = 11;
            static AbaElectric = 12;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1305283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "EkoElectric": 1n,
                    "IkejaElectric": 2n,
                    "AbujaElectric": 3n,
                    "KanoElectric": 4n,
                    "PorthacourtElectric": 5n,
                    "JosElectric": 6n,
                    "IbadanElectric": 7n,
                    "KadunaElecdtric": 8n,
                    "EnuguElectric": 9n,
                    "BeninElectric": 10n,
                    "YolaElectric": 11n,
                    "AbaElectric": 12n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296272579)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296272579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296272579)
            
            //--TRIMMABLE-BOUNDARY-START(4296272579)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296272579)
            
            static $h = 1305283;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540912835),
    {
      "t": 1305283,
      "n": "None",
      "d": 1305283,
      "h": 51540912835,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540912835),
//--TRIMMABLE-BOUNDARY-START(21476141763),
    {
      "t": 1305283,
      "n": "EkoElectric",
      "d": 1305283,
      "h": 21476141763,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "eko-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/ekedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476141763),
//--TRIMMABLE-BOUNDARY-START(34361043651),
    {
      "t": 1305283,
      "n": "IkejaElectric",
      "d": 1305283,
      "h": 34361043651,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "ikeja-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/ikedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361043651),
//--TRIMMABLE-BOUNDARY-START(12886207171),
    {
      "t": 1305283,
      "n": "AbujaElectric",
      "d": 1305283,
      "h": 12886207171,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "abuja-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/aedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886207171),
//--TRIMMABLE-BOUNDARY-START(47245945539),
    {
      "t": 1305283,
      "n": "KanoElectric",
      "d": 1305283,
      "h": 47245945539,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "kano-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/kanedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245945539),
//--TRIMMABLE-BOUNDARY-START(55835880131),
    {
      "t": 1305283,
      "n": "PorthacourtElectric",
      "d": 1305283,
      "h": 55835880131,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "porthacourt-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/phedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835880131),
//--TRIMMABLE-BOUNDARY-START(38656010947),
    {
      "t": 1305283,
      "n": "JosElectric",
      "d": 1305283,
      "h": 38656010947,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "jos-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/jedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656010947),
//--TRIMMABLE-BOUNDARY-START(30066076355),
    {
      "t": 1305283,
      "n": "IbadanElectric",
      "d": 1305283,
      "h": 30066076355,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "ibadan-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/ibedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066076355),
//--TRIMMABLE-BOUNDARY-START(42950978243),
    {
      "t": 1305283,
      "n": "KadunaElecdtric",
      "d": 1305283,
      "h": 42950978243,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "kaduna-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/kadedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950978243),
//--TRIMMABLE-BOUNDARY-START(25771109059),
    {
      "t": 1305283,
      "n": "EnuguElectric",
      "d": 1305283,
      "h": 25771109059,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "enugu-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/enedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771109059),
//--TRIMMABLE-BOUNDARY-START(17181174467),
    {
      "t": 1305283,
      "n": "BeninElectric",
      "d": 1305283,
      "h": 17181174467,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "benin-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/benedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181174467),
//--TRIMMABLE-BOUNDARY-START(60130847427),
    {
      "t": 1305283,
      "n": "YolaElectric",
      "d": 1305283,
      "h": 60130847427,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "yola-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/yoledc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130847427),
//--TRIMMABLE-BOUNDARY-START(8591239875),
    {
      "t": 1305283,
      "n": "AbaElectric",
      "d": 1305283,
      "h": 8591239875,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "aba-electric",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/abedc.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591239875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296272579),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1305283,
      "h": 4296272579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296272579)
  ],
  "h": 1305283,
  "a": [
    {
      "t": 13631572,
      "c": 12898533460,
      "a": [
        {
          "v": 15335508,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUPowerDisco`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUPowerDisco`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1305283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1698499)
        $asm.$str(`$mskq.LVCM.VTUTVNetwork`, ($self) => class VTUTVNetwork extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static DSTV = 1;
            static GOTV = 2;
            static StarTimes = 3;
            static Showmax = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1698499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "DSTV": 1n,
                    "GOTV": 2n,
                    "StarTimes": 3n,
                    "Showmax": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296665795)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296665795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296665795)
            
            //--TRIMMABLE-BOUNDARY-START(4296665795)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296665795)
            
            static $h = 1698499;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181567683),
    {
      "t": 1698499,
      "n": "None",
      "d": 1698499,
      "h": 17181567683,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181567683),
//--TRIMMABLE-BOUNDARY-START(8591633091),
    {
      "t": 1698499,
      "n": "DSTV",
      "d": 1698499,
      "h": 8591633091,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/dstv.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591633091),
//--TRIMMABLE-BOUNDARY-START(12886600387),
    {
      "t": 1698499,
      "n": "GOTV",
      "d": 1698499,
      "h": 12886600387,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/gotv.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886600387),
//--TRIMMABLE-BOUNDARY-START(25771502275),
    {
      "t": 1698499,
      "n": "StarTimes",
      "d": 1698499,
      "h": 25771502275,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/startimes.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771502275),
//--TRIMMABLE-BOUNDARY-START(21476534979),
    {
      "t": 1698499,
      "n": "Showmax",
      "d": 1698499,
      "h": 21476534979,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=_content/LivingThing.VTU.Resources/img/showmax.png"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476534979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296665795),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1698499,
      "h": 4296665795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296665795)
  ],
  "h": 1698499,
  "a": [
    {
      "t": 13631572,
      "c": 12898533460,
      "a": [
        {
          "v": 15335508,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUTVNetwork`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUTVNetwork`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1698499)
        
        

        //--TRIMMABLE-BOUNDARY-START(322243)
        $asm.$cls(`$mskq.LVCM.ClubCKonnectMobileNetworkOptionReader`, ($self) => class ClubCKonnectMobileNetworkOptionReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590256835)
            /*Pager<ISelectOption<VTUMobileNetwork>>? */ GetOptions(/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schemaContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590256835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let networks = $.$sl.SL.Enumerable.Except$1($.$mskq.LVCM.VTUMobileNetwork, $.$$.S.Enum.GetValues$1($.$mskq.LVCM.VTUMobileNetwork), $.$$.SRC.RuntimeHelpers.CreateArray($.$mskq.LVCM.VTUMobileNetwork.$type, [ 0/*VTUMobileNetwork.None*/, 5/*VTUMobileNetwork.Smile*/, 6/*VTUMobileNetwork.Spectranet*/ ], null, null));
                return $.$fPer.LCFCD.Paging.GetPager($.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUMobileNetwork), $.$sl.SL.Enumerable.Select$1($.$mskq.LVCM.VTUMobileNetwork, $.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUMobileNetwork), networks, new ($.$$.S.Func$$$($.$mskq.LVCM.VTUMobileNetwork, $.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUMobileNetwork)))().$ctor(this,  (/*n*/ n) =>
                {
                    return (() =>
                    {
                        //new $.$fPer.LCFC.SelectOption$$($.$mskq.LVCM.VTUMobileNetwork)()
                        const $t1 = $.$fPer.LCFC.SelectOption$$($.$mskq.LVCM.VTUMobileNetwork);
                        const $i1 = new $t1();
                        $i1.$ctor$3(n);
                        return $i1;
                    })();
                }, $XAahff ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUMobileNetwork).$h,"p":[{"n":"n","p":1043139}],"n":"","d":322243,"h":0,"f":17825794})), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590256835)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.VTU.Common.Models.VTUMobileNetwork>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaOptionReader$LivingThing$VTU$Common$Models$VTUMobileNetwork$GetOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4295289539)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295289539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295289539)
            
            //--TRIMMABLE-BOUNDARY-START(4295289539)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295289539)
            
            static $h = 322243;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590256835),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$mskq.LVCM.VTUMobileNetwork)).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schemaContext",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 322243,
      "h": 8590256835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590256835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295289539),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 322243,
      "h": 4295289539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295289539)
  ],
  "h": 322243
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$mskq.LVCM.VTUMobileNetwork) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.ClubCKonnectMobileNetworkOptionReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}ClubCKonnectMobileNetworkOptionReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(322243)
        
        

        //--TRIMMABLE-BOUNDARY-START(2353859)
        $asm.$cls(`$mskq.LVCS.VTUInternetDataServiceProvider`, ($self) => class VTUInternetDataServiceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297321155)
            /*IServerRemoteService*/ _server = null;
            //--TRIMMABLE-BOUNDARY-END(4297321155)
            
            //--TRIMMABLE-BOUNDARY-START(17182223043)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182223043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182223043)
            
            //--TRIMMABLE-BOUNDARY-START(120261438147)
            /*VTUPackages?*/ packages = null;
            //--TRIMMABLE-BOUNDARY-END(120261438147)
            
            //--TRIMMABLE-BOUNDARY-START(128851372739)
            /*VTUGlobalSettings?*/ settings = null;
            //--TRIMMABLE-BOUNDARY-END(128851372739)
            
            //--TRIMMABLE-BOUNDARY-START(141736274627)
            /*Type? */ get UserInformation()
            {
                return $.$mskq.LVCM.VTUInternetDataUserInfo.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(141736274627)
            
            //--TRIMMABLE-BOUNDARY-START(25772157635)
            /*string */ get Description()
            {
                return "Topup your internet connectivity";
            }
            //--TRIMMABLE-BOUNDARY-END(25772157635)
            
            //--TRIMMABLE-BOUNDARY-START(111671503555)
            /*IconDescriptor */ get Icon()
            {
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = "mdi mdi-network"/*MaterialDesignIconNames.Network*/;
                    $i1.Theme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#146752";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(111671503555)
            
            //--TRIMMABLE-BOUNDARY-START(115966470851)
            /*string */ get Name()
            {
                return "InternetData";
            }
            //--TRIMMABLE-BOUNDARY-END(115966470851)
            
            //--TRIMMABLE-BOUNDARY-START(137441307331)
            /*string */ get Title()
            {
                return "Internet Data";
            }
            //--TRIMMABLE-BOUNDARY-END(137441307331)
            
            //--TRIMMABLE-BOUNDARY-START(21477190339)
            /*PaymentCategoryType */ get Category()
            {
                return 3/*PaymentCategoryType.VTU*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21477190339)
            
            //--TRIMMABLE-BOUNDARY-START(133146340035)
            /*ThemePack?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(133146340035)
            
            //--TRIMMABLE-BOUNDARY-START(124556405443)
            /*Pager<IPaymentTier<PaymentCategoryType>>?*/ ServiceTiers = null;
            //--TRIMMABLE-BOUNDARY-END(124556405443)
            
            //--TRIMMABLE-BOUNDARY-START(146031241923)
            /*Task */ Validate(/*PaymentTierReceiptContext*/ receipt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031241923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (receipt.ServiceUserInformation === null || $.$$.S.String.IsNullOrEmpty(($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUInternetDataUserInfo)).PhoneNumber) || ($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUInternetDataUserInfo)).MobileNetwork === 0/*VTUMobileNetwork.None*/)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Please enter all fields");
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(146031241923)
            
            //--TRIMMABLE-BOUNDARY-START(30067124931)
            /*Task<IPaymentOrderTransactionModel?> *//*async*/  Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel), $.$fPer.LCFC.IPaymentOrderTransactionModel, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067124931);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.Validate($.$clone(receipt)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    if (receipt.IsClient)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    /*var*/ let order = ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFC.PaymentOrderTransactionModel, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LVCS$IVTURemoteService$BuyVTU(`data`, $.$fPer.LCFCDM.Money.op_Implicit(receipt.AmountPaid), $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, receipt.ServiceUserInformation, true, false, true, false, false, false, false, "Execute", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\VTUInternetDataServiceProvider.cs", "Execute", 66).Json, receipt.PaymentReference);
                    }, $LDBHOj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)).$h,"p":[{"n":"server","p":2157251}],"n":"","d":2353859,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, order);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30067124931)
            
            //--TRIMMABLE-BOUNDARY-START(107376536259)
            /*ValueTask<ValueRange<Money>> *//*async*/  GetCost(/*IPaymentTier?*/ tier, /*object?*/ tierUserInfomation, /*object?*/ serviceUserInfomation)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)), $.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money), async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376536259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.packages ??= ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$mskq.LVCM.VTUPackages, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LVCS$IVTURemoteService$GetPackages();
                    }, $cCBhNa ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages)).$h,"p":[{"n":"s","p":2157251}],"n":"","d":2353859,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.settings ??= (($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$mskq.LVCS$1.VTUGlobalSettings, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LVCS$IVTURemoteService$GetGlobalSettings();
                    }, $mAtzdk ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings)).$h,"p":[{"n":"s","p":2157251}],"n":"","d":2353859,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))) ?? (() =>
                    {
                        //new $.$mskq.LVCS$1.VTUGlobalSettings()
                        const $t7 = $.$mskq.LVCS$1.VTUGlobalSettings;
                        const $i7 = new $t7();
                        $i7.$ctor$3();
                        return $i7;
                    })());
                    /*Money*/ let cost = new $.$fPer.LCFCDM.Money();
                    let uInfo;
                    if ($.$is(serviceUserInfomation, $.$mskq.LVCM.VTUInternetDataUserInfo, { set $v($v){ uInfo = $v; } }))
                    {
                        /*System.Collections.Generic.Dictionary<string, LivingThing.VTU.Common.Models.VTUPackage[]>?*/ let __ca1__;
                        /*var*/ let $package = ((__ca1__ = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$mskq.LVCM.VTUMobileNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), this.packages.InternetData, uInfo.MobileNetwork)) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$1($.$mskq.LVCM.VTUPackage, $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$mskq.LVCM.VTUPackage, __ca1__, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$$.SCG.IEnumerable$$($.$mskq.LVCM.VTUPackage)))().$ctor(this,  (/*e*/ e) =>
                        {
                            return e.Value;
                        }, $dCOomk ??= {"r":$.$$.SCG.IEnumerable$$($.$mskq.LVCM.VTUPackage).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)).$h}],"n":"","d":2353859,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$mskq.LVCM.VTUPackage, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Code === uInfo.Package.Code;
                        }, $euTkJj ??= {"r":262145,"p":[{"n":"s","p":1174211}],"n":"","d":2353859,"h":0,"f":17825794})) : null);
                        /*System.Collections.Generic.IEnumerable<LivingThing.VTU.Common.Settings.VTUPricing>?*/ let __ca2__;
                        /*LivingThing.VTU.Common.Settings.VTUPricing?*/ let __ca3__;
                        cost = ((__ca2__ = this.settings.get_Item$1(uInfo.MobileNetwork)) !== null ? ((__ca3__ = $.$sl.SL.Enumerable.FirstOrDefault$1($.$mskq.LVCS$1.VTUPricing, __ca2__, new ($.$$.S.Func$$$($.$mskq.LVCS$1.VTUPricing, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                        {
                            return s.Package === uInfo.Package.Code;
                        }, $oqeZng ??= {"r":262145,"p":[{"n":"s","p":2812611}],"n":"","d":2353859,"h":0,"f":17825794}))) !== null ? __ca3__.Amount : ($package?.GetSaleCost(this.settings.InternetSurCharge) ?? null) ?? new $.$fPer.LCFCDM.Money()) : ($package?.GetSaleCost(this.settings.InternetSurCharge) ?? null) ?? new $.$fPer.LCFCDM.Money());
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))().$ctor$3($.$clone(cost), $.$clone(cost)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107376536259)
            
            //--TRIMMABLE-BOUNDARY-START(103081568963)
            /*ValueTask<Money> */ GetCashback(/*Money*/ amount, /*IPaymentTier?*/ tier, /*object?*/ tierUserInfomation, /*object?*/ serviceUserInfomation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081568963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCDM.Money, new $.$fPer.LCFCDM.Money().$ctor$3(10, amount.Unit));
            }
            //--TRIMMABLE-BOUNDARY-END(103081568963)
            
            //--TRIMMABLE-BOUNDARY-START(12885968664)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.Category.get
            get LCFCP$IPaymentTierProvider$$$Category()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296034072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(12885968664)
            
            //--TRIMMABLE-BOUNDARY-START(21475903256)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.ServiceTiers.get
            get LCFCP$IPaymentTierProvider$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540674328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(21475903256)
            
            //--TRIMMABLE-BOUNDARY-START(51540608792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.UserInformation.get
            get LCFCP$IPaymentTierProvider$UserInformation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720477976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UserInformation;
            }
            //--TRIMMABLE-BOUNDARY-END(51540608792)
            
            //--TRIMMABLE-BOUNDARY-START(73015445272)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Validate(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015445272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73015445272)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Execute(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590935832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4295837464)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierCostProvider.GetCost(LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentTierCostProvider$GetCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295837464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCost(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295837464)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(4295640856)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentCashbackProvider.GetCashback(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentCashbackProvider$GetCashback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295640856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCashback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295640856)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133146340035)
                this.Theme = (() =>
                {
                    //new $.$vWqU.LCFCC.ThemePack()
                    const $t8 = $.$vWqU.LCFCC.ThemePack;
                    const $i8 = new $t8();
                    $i8.$ctor$1();
                    $i8.Primary = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t9 = $.$fPer.LCFC.Theme;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.BackgroundColor = "#FF6712";
                        $i9.ForegroundColor = "#FFF";
                        return $i9;
                    })();
                    return $i8;
                })();
                //--TRIMMABLE-BOUNDARY-END(133146340035)
                
            }
            static $h = 2353859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141736274627),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786601667,
        "f": 50331649
      },
      "n": "UserInformation",
      "d": 2353859,
      "h": 141736274627,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141736274627),
//--TRIMMABLE-BOUNDARY-START(25772157635),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246994115,
        "f": 50331649
      },
      "n": "Description",
      "d": 2353859,
      "h": 25772157635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772157635),
//--TRIMMABLE-BOUNDARY-START(111671503555),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836928707,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2353859,
      "h": 111671503555,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671503555),
//--TRIMMABLE-BOUNDARY-START(115966470851),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426863299,
        "f": 50331649
      },
      "n": "Name",
      "d": 2353859,
      "h": 115966470851,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966470851),
//--TRIMMABLE-BOUNDARY-START(137441307331),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196667075,
        "f": 50331649
      },
      "n": "Title",
      "d": 2353859,
      "h": 137441307331,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441307331),
//--TRIMMABLE-BOUNDARY-START(21477190339),
    {
      "p": 1328920,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657059523,
        "f": 50331649
      },
      "n": "Category",
      "d": 2353859,
      "h": 21477190339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477190339),
//--TRIMMABLE-BOUNDARY-START(133146340035),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606732483,
        "f": 50331649
      },
      "n": "Theme",
      "d": 2353859,
      "h": 133146340035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146340035),
//--TRIMMABLE-BOUNDARY-START(124556405443),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016797891,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 2353859,
      "h": 124556405443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124556405443)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146031241923),
    {
      "r": 178454529,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Validate",
      "d": 2353859,
      "h": 146031241923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146031241923),
//--TRIMMABLE-BOUNDARY-START(30067124931),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "d": 2353859,
      "h": 30067124931,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30067124931),
//--TRIMMABLE-BOUNDARY-START(107376536259),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCost",
      "d": 2353859,
      "h": 107376536259,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(107376536259),
//--TRIMMABLE-BOUNDARY-START(103081568963),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "amount",
          "p": 27822422
        },
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCashback",
      "d": 2353859,
      "h": 103081568963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103081568963)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297321155),
    {
      "t": 1309651,
      "n": "_server",
      "d": 2353859,
      "h": 4297321155,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297321155),
//--TRIMMABLE-BOUNDARY-START(120261438147),
    {
      "t": 1239747,
      "n": "packages",
      "d": 2353859,
      "h": 120261438147,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120261438147),
//--TRIMMABLE-BOUNDARY-START(128851372739),
    {
      "t": 2550467,
      "n": "settings",
      "d": 2353859,
      "h": 128851372739,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128851372739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182223043),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2353859,
      "h": 17182223043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182223043)
  ],
  "h": 2353859
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$nYKj.LCFCP.IPaymentTierCostProvider, $.$vWqU.LCFCC.IThemable, $.$nYKj.LCFCP.IPaymentCashbackProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Services.VTUInternetDataServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Services${separator}VTUInternetDataServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2353859)
        
        

        //--TRIMMABLE-BOUNDARY-START(2288323)
        $asm.$cls(`$mskq.LVCS.VTUAirtimeRechargeServiceProvider`, ($self) => class VTUAirtimeRechargeServiceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297255619)
            /*IServerRemoteService*/ _server = null;
            //--TRIMMABLE-BOUNDARY-END(4297255619)
            
            //--TRIMMABLE-BOUNDARY-START(17182157507)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182157507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182157507)
            
            //--TRIMMABLE-BOUNDARY-START(133146274499)
            /*Type? */ get UserInformation()
            {
                return $.$mskq.LVCM.VTUAirtimeUserInfo.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(133146274499)
            
            //--TRIMMABLE-BOUNDARY-START(25772092099)
            /*string */ get Description()
            {
                return "Topup your mobile line";
            }
            //--TRIMMABLE-BOUNDARY-END(25772092099)
            
            //--TRIMMABLE-BOUNDARY-START(111671438019)
            /*IconDescriptor */ get Icon()
            {
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = "mdi mdi-phone"/*MaterialDesignIconNames.Phone*/;
                    $i1.Theme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#146752";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(111671438019)
            
            //--TRIMMABLE-BOUNDARY-START(115966405315)
            /*string */ get Name()
            {
                return "AirtimeTopup";
            }
            //--TRIMMABLE-BOUNDARY-END(115966405315)
            
            //--TRIMMABLE-BOUNDARY-START(128851307203)
            /*string */ get Title()
            {
                return "Airtime Topup";
            }
            //--TRIMMABLE-BOUNDARY-END(128851307203)
            
            //--TRIMMABLE-BOUNDARY-START(21477124803)
            /*PaymentCategoryType */ get Category()
            {
                return 3/*PaymentCategoryType.VTU*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21477124803)
            
            //--TRIMMABLE-BOUNDARY-START(124556339907)
            /*ThemePack?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(124556339907)
            
            //--TRIMMABLE-BOUNDARY-START(120261372611)
            /*Pager<IPaymentTier<PaymentCategoryType>>?*/ ServiceTiers = null;
            //--TRIMMABLE-BOUNDARY-END(120261372611)
            
            //--TRIMMABLE-BOUNDARY-START(137441241795)
            /*Task */ Validate(/*PaymentTierReceiptContext*/ receipt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441241795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (receipt.ServiceUserInformation === null || $.$$.S.String.IsNullOrEmpty(($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUAirtimeUserInfo)).PhoneNumber) || ($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUAirtimeUserInfo)).MobileNetwork === 0/*VTUMobileNetwork.None*/)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Please enter all fields");
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(137441241795)
            
            //--TRIMMABLE-BOUNDARY-START(30067059395)
            /*Task<IPaymentOrderTransactionModel?> *//*async*/  Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel), $.$fPer.LCFC.IPaymentOrderTransactionModel, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067059395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.Validate($.$clone(receipt)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    if (receipt.IsClient)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    /*var*/ let order = ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFC.PaymentOrderTransactionModel, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LVCS$IVTURemoteService$BuyVTU(`airtime`, $.$fPer.LCFCDM.Money.op_Implicit(receipt.AmountPaid), $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, receipt.ServiceUserInformation, true, false, true, false, false, false, false, "Execute", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\VTUAirtimeRechargeServiceProvider.cs", "Execute", 68).Json, receipt.PaymentReference);
                    }, $mIxWmg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)).$h,"p":[{"n":"server","p":2157251}],"n":"","d":2288323,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, order);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30067059395)
            
            //--TRIMMABLE-BOUNDARY-START(107376470723)
            /*ValueTask<ValueRange<Money>> */ GetCost(/*IPaymentTier?*/ tier, /*object?*/ tierUserInfomation, /*object?*/ serviceUserInfomation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376470723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money), new ($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))().$ctor$3(new $.$fPer.LCFCDM.Money().$ctor$3(50, 1/*MoneyUnitTypes.Naira*/), new $.$fPer.LCFCDM.Money()));
            }
            //--TRIMMABLE-BOUNDARY-END(107376470723)
            
            //--TRIMMABLE-BOUNDARY-START(103081503427)
            /*ValueTask<Money> */ GetCashback(/*Money*/ amount, /*IPaymentTier?*/ tier, /*object?*/ tierUserInfomation, /*object?*/ serviceUserInfomation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081503427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCDM.Money, new $.$fPer.LCFCDM.Money().$ctor$3(amount.Value * (0.5 / 100), amount.Unit));
            }
            //--TRIMMABLE-BOUNDARY-END(103081503427)
            
            //--TRIMMABLE-BOUNDARY-START(12885968664)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.Category.get
            get LCFCP$IPaymentTierProvider$$$Category()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296034072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(12885968664)
            
            //--TRIMMABLE-BOUNDARY-START(21475903256)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.ServiceTiers.get
            get LCFCP$IPaymentTierProvider$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540674328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(21475903256)
            
            //--TRIMMABLE-BOUNDARY-START(51540608792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.UserInformation.get
            get LCFCP$IPaymentTierProvider$UserInformation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720477976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UserInformation;
            }
            //--TRIMMABLE-BOUNDARY-END(51540608792)
            
            //--TRIMMABLE-BOUNDARY-START(73015445272)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Validate(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015445272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73015445272)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Execute(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590935832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(4295837464)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierCostProvider.GetCost(LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentTierCostProvider$GetCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295837464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCost(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295837464)
            
            //--TRIMMABLE-BOUNDARY-START(4295640856)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentCashbackProvider.GetCashback(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentCashbackProvider$GetCashback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295640856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCashback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295640856)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(124556339907)
                this.Theme = (() =>
                {
                    //new $.$vWqU.LCFCC.ThemePack()
                    const $t5 = $.$vWqU.LCFCC.ThemePack;
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.Primary = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t6 = $.$fPer.LCFC.Theme;
                        const $i6 = new $t6();
                        $i6.$ctor$2();
                        $i6.BackgroundColor = "#FF6712";
                        $i6.ForegroundColor = "#FFF";
                        return $i6;
                    })();
                    return $i5;
                })();
                //--TRIMMABLE-BOUNDARY-END(124556339907)
                
            }
            static $h = 2288323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133146274499),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786536131,
        "f": 50331649
      },
      "n": "UserInformation",
      "d": 2288323,
      "h": 133146274499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146274499),
//--TRIMMABLE-BOUNDARY-START(25772092099),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246928579,
        "f": 50331649
      },
      "n": "Description",
      "d": 2288323,
      "h": 25772092099,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772092099),
//--TRIMMABLE-BOUNDARY-START(111671438019),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836863171,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2288323,
      "h": 111671438019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671438019),
//--TRIMMABLE-BOUNDARY-START(115966405315),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426797763,
        "f": 50331649
      },
      "n": "Name",
      "d": 2288323,
      "h": 115966405315,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966405315),
//--TRIMMABLE-BOUNDARY-START(128851307203),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196601539,
        "f": 50331649
      },
      "n": "Title",
      "d": 2288323,
      "h": 128851307203,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128851307203),
//--TRIMMABLE-BOUNDARY-START(21477124803),
    {
      "p": 1328920,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656993987,
        "f": 50331649
      },
      "n": "Category",
      "d": 2288323,
      "h": 21477124803,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477124803),
//--TRIMMABLE-BOUNDARY-START(124556339907),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606666947,
        "f": 50331649
      },
      "n": "Theme",
      "d": 2288323,
      "h": 124556339907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124556339907),
//--TRIMMABLE-BOUNDARY-START(120261372611),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016732355,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 2288323,
      "h": 120261372611,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261372611)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137441241795),
    {
      "r": 178454529,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Validate",
      "d": 2288323,
      "h": 137441241795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137441241795),
//--TRIMMABLE-BOUNDARY-START(30067059395),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "d": 2288323,
      "h": 30067059395,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30067059395),
//--TRIMMABLE-BOUNDARY-START(107376470723),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCost",
      "d": 2288323,
      "h": 107376470723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376470723),
//--TRIMMABLE-BOUNDARY-START(103081503427),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "amount",
          "p": 27822422
        },
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCashback",
      "d": 2288323,
      "h": 103081503427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103081503427)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297255619),
    {
      "t": 1309651,
      "n": "_server",
      "d": 2288323,
      "h": 4297255619,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297255619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182157507),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2288323,
      "h": 17182157507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182157507)
  ],
  "h": 2288323
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$vWqU.LCFCC.IThemable, $.$nYKj.LCFCP.IPaymentTierCostProvider, $.$nYKj.LCFCP.IPaymentCashbackProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Services.VTUAirtimeRechargeServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Services${separator}VTUAirtimeRechargeServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2288323)
        
        

        //--TRIMMABLE-BOUNDARY-START(2419395)
        $asm.$cls(`$mskq.LVCS.VTUPowerServiceProvider`, ($self) => class VTUPowerServiceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115966536387)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(115966536387)
            
            //--TRIMMABLE-BOUNDARY-START(12887321283)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887321283);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887321283)
            
            //--TRIMMABLE-BOUNDARY-START(124556470979)
            /*VTUGlobalSettings?*/ settings = null;
            //--TRIMMABLE-BOUNDARY-END(124556470979)
            
            //--TRIMMABLE-BOUNDARY-START(137441372867)
            /*Type? */ get UserInformation()
            {
                return $.$mskq.LVCM.VTUPowerUserInfo.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(137441372867)
            
            //--TRIMMABLE-BOUNDARY-START(21477255875)
            /*string */ get Description()
            {
                return "Buy Energy tariff";
            }
            //--TRIMMABLE-BOUNDARY-END(21477255875)
            
            //--TRIMMABLE-BOUNDARY-START(107376601795)
            /*IconDescriptor */ get Icon()
            {
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = "mdi mdi-lightbulb"/*MaterialDesignIconNames.Lightbulb*/;
                    $i1.Theme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#146752";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(107376601795)
            
            //--TRIMMABLE-BOUNDARY-START(111671569091)
            /*string */ get Name()
            {
                return "EnergyTariff";
            }
            //--TRIMMABLE-BOUNDARY-END(111671569091)
            
            //--TRIMMABLE-BOUNDARY-START(133146405571)
            /*string */ get Title()
            {
                return "Energy Tariff";
            }
            //--TRIMMABLE-BOUNDARY-END(133146405571)
            
            //--TRIMMABLE-BOUNDARY-START(17182288579)
            /*PaymentCategoryType */ get Category()
            {
                return 3/*PaymentCategoryType.VTU*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17182288579)
            
            //--TRIMMABLE-BOUNDARY-START(128851438275)
            /*ThemePack?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(128851438275)
            
            //--TRIMMABLE-BOUNDARY-START(120261503683)
            /*Pager<IPaymentTier<PaymentCategoryType>>?*/ ServiceTiers = null;
            //--TRIMMABLE-BOUNDARY-END(120261503683)
            
            //--TRIMMABLE-BOUNDARY-START(103081634499)
            /*ValueTask<Dictionary<string, string?>> *//*async*/  GetInfo(/*IPaymentTier?*/ tier, /*object?*/ serviceUserInformation, /*object?*/ tierUserInformation)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)), $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081634499);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let info = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LVCS$IVTURemoteService$Verify(`energy`, $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, serviceUserInformation, true, false, true, false, false, false, false, "GetInfo", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\VTUPowerServiceProvider.cs", "GetInfo", 47).Json);
                    }, $YJIRMk ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))).$h,"p":[{"n":"server","p":2157251}],"n":"","d":2419395,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, info);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103081634499)
            
            //--TRIMMABLE-BOUNDARY-START(141736340163)
            /*Task */ Validate(/*PaymentTierReceiptContext*/ receipt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736340163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (receipt.ServiceUserInformation === null || $.$$.S.String.IsNullOrEmpty(($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUPowerUserInfo)).PhoneNumber) || ($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUPowerUserInfo)).Disco === 0/*VTUPowerDisco.None*/)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Please enter all fields");
                }
                if ($.$fPer.LCFCDM.Money.op_Implicit(receipt.AmountPaid) < 1000)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Amount must be at least ${$.$strNN("\u20A6"/*Money.NairaSymbol*/)}1000`);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(141736340163)
            
            //--TRIMMABLE-BOUNDARY-START(25772223171)
            /*Task<IPaymentOrderTransactionModel?> *//*async*/  Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel), $.$fPer.LCFC.IPaymentOrderTransactionModel, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772223171);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.Validate($.$clone(receipt)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    if (receipt.IsClient)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    /*var*/ let order = ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFC.PaymentOrderTransactionModel, this.server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)))().$ctor(this,  (/**/ server) =>
                    {
                        return server.LVCS$IVTURemoteService$BuyVTU(`energy`, $.$fPer.LCFCDM.Money.op_Implicit(receipt.AmountPaid), $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, receipt.ServiceUserInformation, true, false, true, false, false, false, false, "Execute", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\VTUPowerServiceProvider.cs", "Execute", 78).Json, receipt.PaymentReference);
                    }, $Acdxck ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)).$h,"p":[{"n":"server","p":2157251}],"n":"","d":2419395,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, order);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25772223171)
            
            //--TRIMMABLE-BOUNDARY-START(98786667203)
            /*ValueTask<ValueRange<Money>> */ GetCost(/*IPaymentTier?*/ tier, /*object?*/ tierUserInfomation, /*object?*/ serviceUserInfomation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786667203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money), new ($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))().$ctor$3(new $.$fPer.LCFCDM.Money().$ctor$3(1000, 1/*MoneyUnitTypes.Naira*/), new $.$fPer.LCFCDM.Money()));
            }
            //--TRIMMABLE-BOUNDARY-END(98786667203)
            
            //--TRIMMABLE-BOUNDARY-START(12885968664)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.Category.get
            get LCFCP$IPaymentTierProvider$$$Category()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296034072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(12885968664)
            
            //--TRIMMABLE-BOUNDARY-START(21475903256)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.ServiceTiers.get
            get LCFCP$IPaymentTierProvider$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540674328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(21475903256)
            
            //--TRIMMABLE-BOUNDARY-START(51540608792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.UserInformation.get
            get LCFCP$IPaymentTierProvider$UserInformation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720477976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UserInformation;
            }
            //--TRIMMABLE-BOUNDARY-END(51540608792)
            
            //--TRIMMABLE-BOUNDARY-START(73015445272)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Validate(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015445272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73015445272)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Execute(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590935832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4295903000)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierInfoProvider.GetInfo(LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentTierInfoProvider$GetInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295903000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295903000)
            
            //--TRIMMABLE-BOUNDARY-START(4295837464)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierCostProvider.GetCost(LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentTierCostProvider$GetCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295837464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCost(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295837464)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(128851438275)
                this.Theme = (() =>
                {
                    //new $.$vWqU.LCFCC.ThemePack()
                    const $t6 = $.$vWqU.LCFCC.ThemePack;
                    const $i6 = new $t6();
                    $i6.$ctor$1();
                    $i6.Primary = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t7 = $.$fPer.LCFC.Theme;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.BackgroundColor = "#FF6712";
                        $i7.ForegroundColor = "#FFF";
                        return $i7;
                    })();
                    return $i6;
                })();
                //--TRIMMABLE-BOUNDARY-END(128851438275)
                
            }
            static $h = 2419395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137441372867),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491699907,
        "f": 50331649
      },
      "n": "UserInformation",
      "d": 2419395,
      "h": 137441372867,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441372867),
//--TRIMMABLE-BOUNDARY-START(21477255875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952092355,
        "f": 50331649
      },
      "n": "Description",
      "d": 2419395,
      "h": 21477255875,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477255875),
//--TRIMMABLE-BOUNDARY-START(107376601795),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542026947,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2419395,
      "h": 107376601795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376601795),
//--TRIMMABLE-BOUNDARY-START(111671569091),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131961539,
        "f": 50331649
      },
      "n": "Name",
      "d": 2419395,
      "h": 111671569091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671569091),
//--TRIMMABLE-BOUNDARY-START(133146405571),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901765315,
        "f": 50331649
      },
      "n": "Title",
      "d": 2419395,
      "h": 133146405571,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146405571),
//--TRIMMABLE-BOUNDARY-START(17182288579),
    {
      "p": 1328920,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362157763,
        "f": 50331649
      },
      "n": "Category",
      "d": 2419395,
      "h": 17182288579,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182288579),
//--TRIMMABLE-BOUNDARY-START(128851438275),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311830723,
        "f": 50331649
      },
      "n": "Theme",
      "d": 2419395,
      "h": 128851438275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128851438275),
//--TRIMMABLE-BOUNDARY-START(120261503683),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721896131,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 2419395,
      "h": 120261503683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261503683)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103081634499),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "serviceUserInformation",
          "p": 131073
        },
        {
          "n": "tierUserInformation",
          "p": 131073
        }
      ],
      "n": "GetInfo",
      "d": 2419395,
      "h": 103081634499,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(103081634499),
//--TRIMMABLE-BOUNDARY-START(141736340163),
    {
      "r": 178454529,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Validate",
      "d": 2419395,
      "h": 141736340163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141736340163),
//--TRIMMABLE-BOUNDARY-START(25772223171),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "d": 2419395,
      "h": 25772223171,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25772223171),
//--TRIMMABLE-BOUNDARY-START(98786667203),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCost",
      "d": 2419395,
      "h": 98786667203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98786667203)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115966536387),
    {
      "t": 1309651,
      "n": "server",
      "d": 2419395,
      "h": 115966536387,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115966536387),
//--TRIMMABLE-BOUNDARY-START(124556470979),
    {
      "t": 2550467,
      "n": "settings",
      "d": 2419395,
      "h": 124556470979,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124556470979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887321283),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2419395,
      "h": 12887321283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887321283)
  ],
  "h": 2419395
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$nYKj.LCFCP.IPaymentTierInfoProvider, $.$nYKj.LCFCP.IPaymentTierCostProvider, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Services.VTUPowerServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Services${separator}VTUPowerServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2419395)
        
        

        //--TRIMMABLE-BOUNDARY-START(2484931)
        $asm.$cls(`$mskq.LVCS.VTUTVServiceProvider`, ($self) => class VTUTVServiceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297452227)
            /*IServerRemoteService*/ _server = null;
            //--TRIMMABLE-BOUNDARY-END(4297452227)
            
            //--TRIMMABLE-BOUNDARY-START(17182354115)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182354115);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182354115)
            
            //--TRIMMABLE-BOUNDARY-START(120261569219)
            /*VTUPackages?*/ packages = null;
            //--TRIMMABLE-BOUNDARY-END(120261569219)
            
            //--TRIMMABLE-BOUNDARY-START(128851503811)
            /*VTUGlobalSettings?*/ settings = null;
            //--TRIMMABLE-BOUNDARY-END(128851503811)
            
            //--TRIMMABLE-BOUNDARY-START(141736405699)
            /*Type? */ get UserInformation()
            {
                return $.$mskq.LVCM.VTUTVUserInfo.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(141736405699)
            
            //--TRIMMABLE-BOUNDARY-START(25772288707)
            /*string */ get Description()
            {
                return "Buy TV subscription";
            }
            //--TRIMMABLE-BOUNDARY-END(25772288707)
            
            //--TRIMMABLE-BOUNDARY-START(111671634627)
            /*IconDescriptor */ get Icon()
            {
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = "mdi mdi-youtube-tv"/*MaterialDesignIconNames.YoutubeTv*/;
                    $i1.Theme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#146752";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(111671634627)
            
            //--TRIMMABLE-BOUNDARY-START(115966601923)
            /*string */ get Name()
            {
                return "TVSubscription";
            }
            //--TRIMMABLE-BOUNDARY-END(115966601923)
            
            //--TRIMMABLE-BOUNDARY-START(137441438403)
            /*string */ get Title()
            {
                return "TV Subscription";
            }
            //--TRIMMABLE-BOUNDARY-END(137441438403)
            
            //--TRIMMABLE-BOUNDARY-START(21477321411)
            /*PaymentCategoryType */ get Category()
            {
                return 3/*PaymentCategoryType.VTU*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21477321411)
            
            //--TRIMMABLE-BOUNDARY-START(133146471107)
            /*ThemePack?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(133146471107)
            
            //--TRIMMABLE-BOUNDARY-START(124556536515)
            /*Pager<IPaymentTier<PaymentCategoryType>>?*/ ServiceTiers = null;
            //--TRIMMABLE-BOUNDARY-END(124556536515)
            
            //--TRIMMABLE-BOUNDARY-START(107376667331)
            /*ValueTask<Dictionary<string, string?>> *//*async*/  GetInfo(/*IPaymentTier?*/ tier, /*object?*/ serviceUserInformation, /*object?*/ tierUserInformation)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)), $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376667331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let info = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LVCS$IVTURemoteService$Verify(`tv`, $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, serviceUserInformation, true, false, true, false, false, false, false, "GetInfo", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\VTUTVServiceProvider.cs", "GetInfo", 46).Json);
                    }, $LegTRh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))).$h,"p":[{"n":"server","p":2157251}],"n":"","d":2484931,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, info);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107376667331)
            
            //--TRIMMABLE-BOUNDARY-START(146031372995)
            /*Task */ Validate(/*PaymentTierReceiptContext*/ receipt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031372995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (receipt.ServiceUserInformation === null || $.$$.S.String.IsNullOrEmpty(($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUTVUserInfo)).PhoneNumber) || ($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUTVUserInfo)).Provider === 0/*VTUTVNetwork.None*/)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Please enter all fields");
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(146031372995)
            
            //--TRIMMABLE-BOUNDARY-START(30067256003)
            /*Task<IPaymentOrderTransactionModel?> *//*async*/  Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel), $.$fPer.LCFC.IPaymentOrderTransactionModel, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067256003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (receipt.ServiceUserInformation === null || $.$$.S.String.IsNullOrEmpty(($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUTVUserInfo)).PhoneNumber) || ($.$cast(receipt.ServiceUserInformation, $.$mskq.LVCM.VTUTVUserInfo)).Provider === 0/*VTUTVNetwork.None*/)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Please enter all fields");
                    }
                    if (receipt.IsClient)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    /*var*/ let order = ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFC.PaymentOrderTransactionModel, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LVCS$IVTURemoteService$BuyVTU(`tv`, $.$fPer.LCFCDM.Money.op_Implicit(receipt.AmountPaid), $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, receipt.ServiceUserInformation, true, false, true, false, false, false, false, "Execute", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\VTUTVServiceProvider.cs", "Execute", 79).Json, receipt.PaymentReference);
                    }, $sjFpsb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFC.PaymentOrderTransactionModel)).$h,"p":[{"n":"server","p":2157251}],"n":"","d":2484931,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, order);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30067256003)
            
            //--TRIMMABLE-BOUNDARY-START(103081700035)
            /*ValueTask<ValueRange<Money>> *//*async*/  GetCost(/*IPaymentTier?*/ tier, /*object?*/ tierUserInfomation, /*object?*/ serviceUserInfomation)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)), $.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money), async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081700035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.packages ??= ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$mskq.LVCM.VTUPackages, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LVCS$IVTURemoteService$GetPackages();
                    }, $jvyusc ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCM.VTUPackages)).$h,"p":[{"n":"s","p":2157251}],"n":"","d":2484931,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.settings ??= (($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$mskq.LVCS.IVTURemoteService, $.$mskq.LVCS$1.VTUGlobalSettings, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$mskq.LVCS.IVTURemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings)))().$ctor(this,  (/**/ s) =>
                    {
                        return s.LVCS$IVTURemoteService$GetGlobalSettings();
                    }, $gYIePh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$mskq.LVCS$1.VTUGlobalSettings)).$h,"p":[{"n":"s","p":2157251}],"n":"","d":2484931,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))) ?? (() =>
                    {
                        //new $.$mskq.LVCS$1.VTUGlobalSettings()
                        const $t7 = $.$mskq.LVCS$1.VTUGlobalSettings;
                        const $i7 = new $t7();
                        $i7.$ctor$3();
                        return $i7;
                    })());
                    /*Money*/ let cost = new $.$fPer.LCFCDM.Money();
                    let uInfo;
                    if ($.$is(serviceUserInfomation, $.$mskq.LVCM.VTUTVUserInfo, { set $v($v){ uInfo = $v; } }))
                    {
                        /*System.Collections.Generic.Dictionary<string, LivingThing.VTU.Common.Models.VTUPackage[]>?*/ let __ca1__;
                        /*var*/ let $package = ((__ca1__ = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$mskq.LVCM.VTUTVNetwork, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), this.packages.TV, uInfo.Provider)) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$1($.$mskq.LVCM.VTUPackage, $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$mskq.LVCM.VTUPackage, __ca1__, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)), $.$$.SCG.IEnumerable$$($.$mskq.LVCM.VTUPackage)))().$ctor(this,  (/*e*/ e) =>
                        {
                            return e.Value;
                        }, $UOCODj ??= {"r":$.$$.SCG.IEnumerable$$($.$mskq.LVCM.VTUPackage).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$typeArray($.$mskq.LVCM.VTUPackage)).$h}],"n":"","d":2484931,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$mskq.LVCM.VTUPackage, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Code === uInfo.Package.Code;
                        }, $LPYcVi ??= {"r":262145,"p":[{"n":"s","p":1174211}],"n":"","d":2484931,"h":0,"f":17825794})) : null);
                        /*System.Collections.Generic.IEnumerable<LivingThing.VTU.Common.Settings.VTUPricing>?*/ let __ca2__;
                        /*LivingThing.VTU.Common.Settings.VTUPricing?*/ let __ca3__;
                        cost = ((__ca2__ = this.settings.get_Item$2(uInfo.Provider)) !== null ? ((__ca3__ = $.$sl.SL.Enumerable.FirstOrDefault$1($.$mskq.LVCS$1.VTUPricing, __ca2__, new ($.$$.S.Func$$$($.$mskq.LVCS$1.VTUPricing, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Package === uInfo.Package.Code;
                        }, $ATWEIj ??= {"r":262145,"p":[{"n":"s","p":2812611}],"n":"","d":2484931,"h":0,"f":17825794}))) !== null ? __ca3__.Amount : ($package?.GetSaleCost(this.settings.TVSurCharge) ?? null) ?? new $.$fPer.LCFCDM.Money()) : ($package?.GetSaleCost(this.settings.TVSurCharge) ?? null) ?? new $.$fPer.LCFCDM.Money());
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))().$ctor$3($.$clone(cost), $.$clone(cost)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103081700035)
            
            //--TRIMMABLE-BOUNDARY-START(12885968664)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.Category.get
            get LCFCP$IPaymentTierProvider$$$Category()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296034072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(12885968664)
            
            //--TRIMMABLE-BOUNDARY-START(21475903256)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.ServiceTiers.get
            get LCFCP$IPaymentTierProvider$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540674328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(21475903256)
            
            //--TRIMMABLE-BOUNDARY-START(51540608792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.UserInformation.get
            get LCFCP$IPaymentTierProvider$UserInformation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720477976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UserInformation;
            }
            //--TRIMMABLE-BOUNDARY-END(51540608792)
            
            //--TRIMMABLE-BOUNDARY-START(73015445272)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Validate(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015445272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73015445272)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Execute(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590935832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4295903000)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierInfoProvider.GetInfo(LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentTierInfoProvider$GetInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295903000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295903000)
            
            //--TRIMMABLE-BOUNDARY-START(4295837464)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierCostProvider.GetCost(LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?, object?, object?)
            LCFCP$IPaymentTierCostProvider$GetCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295837464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCost(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295837464)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133146471107)
                this.Theme = (() =>
                {
                    //new $.$vWqU.LCFCC.ThemePack()
                    const $t8 = $.$vWqU.LCFCC.ThemePack;
                    const $i8 = new $t8();
                    $i8.$ctor$1();
                    $i8.Primary = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t9 = $.$fPer.LCFC.Theme;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.BackgroundColor = "#FF6712";
                        $i9.ForegroundColor = "#FFF";
                        return $i9;
                    })();
                    return $i8;
                })();
                //--TRIMMABLE-BOUNDARY-END(133146471107)
                
            }
            static $h = 2484931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141736405699),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786732739,
        "f": 50331649
      },
      "n": "UserInformation",
      "d": 2484931,
      "h": 141736405699,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141736405699),
//--TRIMMABLE-BOUNDARY-START(25772288707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247125187,
        "f": 50331649
      },
      "n": "Description",
      "d": 2484931,
      "h": 25772288707,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772288707),
//--TRIMMABLE-BOUNDARY-START(111671634627),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837059779,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2484931,
      "h": 111671634627,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671634627),
//--TRIMMABLE-BOUNDARY-START(115966601923),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426994371,
        "f": 50331649
      },
      "n": "Name",
      "d": 2484931,
      "h": 115966601923,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966601923),
//--TRIMMABLE-BOUNDARY-START(137441438403),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196798147,
        "f": 50331649
      },
      "n": "Title",
      "d": 2484931,
      "h": 137441438403,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441438403),
//--TRIMMABLE-BOUNDARY-START(21477321411),
    {
      "p": 1328920,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657190595,
        "f": 50331649
      },
      "n": "Category",
      "d": 2484931,
      "h": 21477321411,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477321411),
//--TRIMMABLE-BOUNDARY-START(133146471107),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606863555,
        "f": 50331649
      },
      "n": "Theme",
      "d": 2484931,
      "h": 133146471107,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146471107),
//--TRIMMABLE-BOUNDARY-START(124556536515),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016928963,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 2484931,
      "h": 124556536515,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124556536515)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107376667331),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "serviceUserInformation",
          "p": 131073
        },
        {
          "n": "tierUserInformation",
          "p": 131073
        }
      ],
      "n": "GetInfo",
      "d": 2484931,
      "h": 107376667331,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(107376667331),
//--TRIMMABLE-BOUNDARY-START(146031372995),
    {
      "r": 178454529,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Validate",
      "d": 2484931,
      "h": 146031372995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146031372995),
//--TRIMMABLE-BOUNDARY-START(30067256003),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "d": 2484931,
      "h": 30067256003,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30067256003),
//--TRIMMABLE-BOUNDARY-START(103081700035),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCost",
      "d": 2484931,
      "h": 103081700035,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(103081700035)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297452227),
    {
      "t": 1309651,
      "n": "_server",
      "d": 2484931,
      "h": 4297452227,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297452227),
//--TRIMMABLE-BOUNDARY-START(120261569219),
    {
      "t": 1239747,
      "n": "packages",
      "d": 2484931,
      "h": 120261569219,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120261569219),
//--TRIMMABLE-BOUNDARY-START(128851503811),
    {
      "t": 2550467,
      "n": "settings",
      "d": 2484931,
      "h": 128851503811,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128851503811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182354115),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2484931,
      "h": 17182354115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182354115)
  ],
  "h": 2484931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$nYKj.LCFCP.IPaymentTierInfoProvider, $.$nYKj.LCFCP.IPaymentTierCostProvider, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Services.VTUTVServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Services${separator}VTUTVServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2484931)
        
        

        //--TRIMMABLE-BOUNDARY-START(2550467)
        $asm.$cls(`$mskq.LVCS$1.VTUGlobalSettings`, ($self) => class VTUGlobalSettings extends $.$Iaui.LCFCMS.ComponentGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(163211307715)
            /*int*/ InternetSurCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(163211307715)
            
            //--TRIMMABLE-BOUNDARY-START(266290522819)
            /*int*/ TVSurCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(266290522819)
            
            //--TRIMMABLE-BOUNDARY-START(167506275011)
            /*IEnumerable<VTUPricing>?*/ mtnInternetPricing = null;
            //--TRIMMABLE-BOUNDARY-END(167506275011)
            
            //--TRIMMABLE-BOUNDARY-START(171801242307)
            /*IEnumerable<VTUPricing>?*/ MTNInternetPricing = null;
            //--TRIMMABLE-BOUNDARY-END(171801242307)
            
            //--TRIMMABLE-BOUNDARY-START(154621373123)
            /*IEnumerable<VTUPricing>?*/ GloInternetPricing = null;
            //--TRIMMABLE-BOUNDARY-END(154621373123)
            
            //--TRIMMABLE-BOUNDARY-START(47247190723)
            /*IEnumerable<VTUPricing>?*/ AirtelInternetPricing = null;
            //--TRIMMABLE-BOUNDARY-END(47247190723)
            
            //--TRIMMABLE-BOUNDARY-START(55837125315)
            /*IEnumerable<VTUPricing>?*/ EtisalatInternetPricing = null;
            //--TRIMMABLE-BOUNDARY-END(55837125315)
            
            //--TRIMMABLE-BOUNDARY-START(51542158019)
            /*IEnumerable<VTUPricing>?*/ DSTVPricing = null;
            //--TRIMMABLE-BOUNDARY-END(51542158019)
            
            //--TRIMMABLE-BOUNDARY-START(158916340419)
            /*IEnumerable<VTUPricing>?*/ GOTVPricing = null;
            //--TRIMMABLE-BOUNDARY-END(158916340419)
            
            //--TRIMMABLE-BOUNDARY-START(253405620931)
            /*IEnumerable<VTUPricing>?*/ StarTimesPricing = null;
            //--TRIMMABLE-BOUNDARY-END(253405620931)
            
            //--TRIMMABLE-BOUNDARY-START(257700588227)
            /*IEnumerable<VTUPricing>?*/ get_Item$1(/*VTUMobileNetwork*/ network)
            {
                switch(network)
                {
                    case 1/*VTUMobileNetwork.MTN*/:
                    return this.MTNInternetPricing;
                    case 4/*VTUMobileNetwork.Airtel*/:
                    return this.AirtelInternetPricing;
                    case 2/*VTUMobileNetwork.Glo*/:
                    return this.GloInternetPricing;
                    case 3/*VTUMobileNetwork.Etisalat*/:
                    return this.EtisalatInternetPricing;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(257700588227)
            
            //--TRIMMABLE-BOUNDARY-START(261995555523)
            /*IEnumerable<VTUPricing>?*/ get_Item$2(/*VTUTVNetwork*/ network)
            {
                switch(network)
                {
                    case 2/*VTUTVNetwork.GOTV*/:
                    return this.GOTVPricing;
                    case 1/*VTUTVNetwork.DSTV*/:
                    return this.DSTVPricing;
                    case 3/*VTUTVNetwork.StarTimes*/:
                    return this.StarTimesPricing;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(261995555523)
            
            //--TRIMMABLE-BOUNDARY-START(42952223427)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952223427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952223427)
            
            //--TRIMMABLE-BOUNDARY-START(42952223427)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(42952223427)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(163211307715)
                this.InternetSurCharge = 50;
                //--TRIMMABLE-BOUNDARY-END(163211307715)
                
                //--TRIMMABLE-BOUNDARY-START(266290522819)
                this.TVSurCharge = 50;
                //--TRIMMABLE-BOUNDARY-END(266290522819)
                
            }
            static $h = 2550467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163211307715),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376732867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340849859,
        "f": 83886081
      },
      "n": "InternetSurCharge",
      "d": 2550467,
      "h": 163211307715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163211307715),
//--TRIMMABLE-BOUNDARY-START(266290522819),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326405827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249110653635,
        "f": 83886081
      },
      "n": "TVSurCharge",
      "d": 2550467,
      "h": 266290522819,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266290522819),
//--TRIMMABLE-BOUNDARY-START(171801242307),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146536643,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930784451,
        "f": 83886081
      },
      "n": "MTNInternetPricing",
      "d": 2550467,
      "h": 171801242307,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": -9223372036854775773,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171801242307),
//--TRIMMABLE-BOUNDARY-START(154621373123),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196863683,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206160980675,
        "f": 83886081
      },
      "n": "GloInternetPricing",
      "d": 2550467,
      "h": 154621373123,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": -9223372036854775773,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154621373123),
//--TRIMMABLE-BOUNDARY-START(47247190723),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427059907,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180391176899,
        "f": 83886081
      },
      "n": "AirtelInternetPricing",
      "d": 2550467,
      "h": 47247190723,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": -9223372036854775773,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247190723),
//--TRIMMABLE-BOUNDARY-START(55837125315),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606929091,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197571046083,
        "f": 83886081
      },
      "n": "EtisalatInternetPricing",
      "d": 2550467,
      "h": 55837125315,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": -9223372036854775773,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55837125315),
//--TRIMMABLE-BOUNDARY-START(51542158019),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016994499,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188981111491,
        "f": 83886081
      },
      "n": "DSTVPricing",
      "d": 2550467,
      "h": 51542158019,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": -9223372036854775773,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542158019),
//--TRIMMABLE-BOUNDARY-START(158916340419),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786798275,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214750915267,
        "f": 83886081
      },
      "n": "GOTVPricing",
      "d": 2550467,
      "h": 158916340419,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": -9223372036854775773,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158916340419),
//--TRIMMABLE-BOUNDARY-START(253405620931),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736471235,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240520719043,
        "f": 83886081
      },
      "n": "StarTimesPricing",
      "d": 2550467,
      "h": 253405620931,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": -9223372036854775773,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253405620931),
//--TRIMMABLE-BOUNDARY-START(257700588227),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "i": [
        {
          "n": "network",
          "p": 1043139
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966667459,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 2550467,
      "h": 257700588227,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257700588227),
//--TRIMMABLE-BOUNDARY-START(261995555523),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "i": [
        {
          "n": "network",
          "p": 1698499
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556602051,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 2550467,
      "h": 261995555523,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261995555523)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167506275011),
    {
      "t": $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing).$h,
      "n": "mtnInternetPricing",
      "d": 2550467,
      "h": 167506275011,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(167506275011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42952223427),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2550467,
      "h": 42952223427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952223427)
  ],
  "h": 2550467
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Settings.VTUGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Settings${separator}VTUGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2550467)
        
        

        //--TRIMMABLE-BOUNDARY-START(453315)
        $asm.$cls(`$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor`, ($self) => class VTUAirtimeUserInfoTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUAirtimeUserInfo)
        {
            //--TRIMMABLE-BOUNDARY-START(4295420611)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295420611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor.GenerateProperties($.$mskq.LVCM.VTUAirtimeUserInfo, this, factory);
                    }, $nsHDCi ??= {"r":65537,"n":"","d":453315,"h":0,"f":17825794}), 0, "VTUAirtimeUserInfoTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\Models_VTUAirtimeUserInfo_LivingThing.VTU.Common.Models.VTUAirtimeUserInfoTypeDescriptorBuilder.g.cs", "VTUAirtimeUserInfoTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295420611)
            
            //--TRIMMABLE-BOUNDARY-START(12885355203)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885355203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MobileNetwork"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUAirtimeUserInfo.$type, $.$discardRef(), "MobileNetwork", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MobileNetwork")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mskq.LVCM.VTUMobileNetwork, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "MobileNetwork";
                        $i1.DelaredOn = "LivingThing.VTU.Common.Models.VTUAirtimeUserInfo";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$mskq.LVCM.VTUMobileNetwork, ($.$cast(target, $.$mskq.LVCM.VTUAirtimeUserInfo)).MobileNetwork);
                        }, $ZIqfQg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453315,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.MobileNetwork = value.AsEnumValue($.$mskq.LVCM.VTUMobileNetwork);
                        }, $SDwxnj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453315,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUAirtimeUserInfo.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "PhoneNumber";
                        $i3.DelaredOn = "LivingThing.VTU.Common.Models.VTUAirtimeUserInfo";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUAirtimeUserInfo)).PhoneNumber);
                        }, $ZjZhwk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453315,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsReference($.$$.S.String);
                        }, $jQoacc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":453315,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUAirtimeUserInfo.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Description";
                        $i5.DelaredOn = "LivingThing.VTU.Common.Models.VTUAirtimeUserInfo";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUAirtimeUserInfo)).Description);
                        }, $IzJHAe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":453315,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885355203)
            
            //--TRIMMABLE-BOUNDARY-START(17180322499)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUAirtimeUserInfo*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180322499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _MobileNetwork = _target.MobileNetwork;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MobileNetwork"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mskq.LVCM.VTUMobileNetwork));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mskq.LVCM.VTUMobileNetwork, () => _MobileNetwork, ($v) => _MobileNetwork = $v, null, true)))
                    {
                        _target.MobileNetwork = _MobileNetwork;
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PhoneNumber, ($v) => _PhoneNumber = $v, $.$$.S.String)))
                    {
                        _target.PhoneNumber = _PhoneNumber;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180322499)
            
            //--TRIMMABLE-BOUNDARY-START(8590387907)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUAirtimeUserInfo?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590387907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mskq.LVCM.VTUAirtimeUserInfo().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mskq.LVCM.VTUAirtimeUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUAirtimeUserInfo)))
                {
                    /*var*/ let result = $.$mskq.LVCM.VTUAirtimeUserInfoTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUAirtimeUserInfo));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mskq.LVCM.VTUAirtimeUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUAirtimeUserInfo));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590387907)
            
            static $h = 453315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUAirtimeUserInfo); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885355203),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 453315,
      "h": 12885355203,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885355203),
//--TRIMMABLE-BOUNDARY-START(17180322499),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 387779,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 453315,
      "h": 17180322499,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180322499),
//--TRIMMABLE-BOUNDARY-START(8590387907),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 387779,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 453315,
      "h": 8590387907,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590387907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295420611),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 453315,
      "h": 4295420611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295420611)
  ],
  "h": 453315
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mskq.LVCM.VTUAirtimeUserInfo), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUAirtimeUserInfoTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUAirtimeUserInfoTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(453315)
        
        

        //--TRIMMABLE-BOUNDARY-START(1895107)
        $asm.$cls(`$mskq.LVCM.VTUTVUserInfoTypeDescriptor`, ($self) => class VTUTVUserInfoTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUTVUserInfo)
        {
            //--TRIMMABLE-BOUNDARY-START(4296862403)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296862403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mskq.LVCM.VTUTVUserInfoTypeDescriptor.GenerateProperties($.$mskq.LVCM.VTUTVUserInfo, this, factory);
                    }, $YHXLdh ??= {"r":65537,"n":"","d":1895107,"h":0,"f":17825794}), 0, "VTUTVUserInfoTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\Models_VTUTVUserInfo_LivingThing.VTU.Common.Models.VTUTVUserInfoTypeDescriptorBuilder.g.cs", "VTUTVUserInfoTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296862403)
            
            //--TRIMMABLE-BOUNDARY-START(12886796995)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886796995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Provider"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUTVUserInfo.$type, $.$discardRef(), "Provider", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Provider")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mskq.LVCM.VTUTVNetwork, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Provider";
                        $i1.DelaredOn = "LivingThing.VTU.Common.Models.VTUTVUserInfo";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$mskq.LVCM.VTUTVNetwork, ($.$cast(target, $.$mskq.LVCM.VTUTVUserInfo)).Provider);
                        }, $bIFNxk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1895107,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Provider = value.AsEnumValue($.$mskq.LVCM.VTUTVNetwork);
                        }, $dJEZCc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1895107,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Package"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUTVUserInfo.$type, $.$discardRef(), "Package", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Package")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mskq.LVCM.VTUSelectPackage, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Package";
                        $i3.DelaredOn = "LivingThing.VTU.Common.Models.VTUTVUserInfo";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$mskq.LVCM.VTUSelectPackage, ($.$cast(target, $.$mskq.LVCM.VTUTVUserInfo)).Package);
                        }, $lPBdhc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1895107,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Package = value.AsValue($.$mskq.LVCM.VTUSelectPackage);
                        }, $cLWPlb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1895107,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SmartCardNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUTVUserInfo.$type, $.$discardRef(), "SmartCardNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SmartCardNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "SmartCardNumber";
                        $i5.DelaredOn = "LivingThing.VTU.Common.Models.VTUTVUserInfo";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUTVUserInfo)).SmartCardNumber);
                        }, $vrYsWi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1895107,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SmartCardNumber = value.AsReference($.$$.S.String);
                        }, $kKacGa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1895107,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUTVUserInfo.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PhoneNumber";
                        $i7.DelaredOn = "LivingThing.VTU.Common.Models.VTUTVUserInfo";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUTVUserInfo)).PhoneNumber);
                        }, $GlHidc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1895107,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.PhoneNumber = value.AsReference($.$$.S.String);
                        }, $obTIrh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1895107,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUTVUserInfo.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Description";
                        $i9.DelaredOn = "LivingThing.VTU.Common.Models.VTUTVUserInfo";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUTVUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUTVUserInfo)).Description);
                        }, $NvvnVj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1895107,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886796995)
            
            //--TRIMMABLE-BOUNDARY-START(17181764291)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUTVUserInfo*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181764291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Provider = _target.Provider;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Provider"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mskq.LVCM.VTUTVNetwork));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mskq.LVCM.VTUTVNetwork, () => _Provider, ($v) => _Provider = $v, null, true)))
                    {
                        _target.Provider = _Provider;
                    }
                }
                {
                    /*var*/ let _Package = _target.Package;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Package"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mskq.LVCM.VTUSelectPackage));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mskq.LVCM.VTUSelectPackage, () => _Package, ($v) => _Package = $v, null, true)))
                    {
                        _target.Package = $.$clone(_Package);
                    }
                }
                {
                    /*var*/ let _SmartCardNumber = _target.SmartCardNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SmartCardNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SmartCardNumber, ($v) => _SmartCardNumber = $v, $.$$.S.String)))
                    {
                        _target.SmartCardNumber = _SmartCardNumber;
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PhoneNumber, ($v) => _PhoneNumber = $v, $.$$.S.String)))
                    {
                        _target.PhoneNumber = _PhoneNumber;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181764291)
            
            //--TRIMMABLE-BOUNDARY-START(8591829699)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUTVUserInfo?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591829699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mskq.LVCM.VTUTVUserInfo().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mskq.LVCM.VTUTVUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUTVUserInfo)))
                {
                    /*var*/ let result = $.$mskq.LVCM.VTUTVUserInfoTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUTVUserInfo));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mskq.LVCM.VTUTVUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUTVUserInfo));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591829699)
            
            static $h = 1895107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUTVUserInfo); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886796995),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1895107,
      "h": 12886796995,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886796995),
//--TRIMMABLE-BOUNDARY-START(17181764291),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1829571,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1895107,
      "h": 17181764291,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181764291),
//--TRIMMABLE-BOUNDARY-START(8591829699),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1829571,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1895107,
      "h": 8591829699,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591829699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296862403),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1895107,
      "h": 4296862403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296862403)
  ],
  "h": 1895107
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mskq.LVCM.VTUTVUserInfo), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUTVUserInfoTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUTVUserInfoTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1895107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1501891)
        $asm.$cls(`$mskq.LVCM.VTUPowerUserInfoTypeDescriptor`, ($self) => class VTUPowerUserInfoTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUPowerUserInfo)
        {
            //--TRIMMABLE-BOUNDARY-START(4296469187)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296469187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor.GenerateProperties($.$mskq.LVCM.VTUPowerUserInfo, this, factory);
                    }, $DWVeUg ??= {"r":65537,"n":"","d":1501891,"h":0,"f":17825794}), 0, "VTUPowerUserInfoTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\Models_VTUPowerUserInfo_LivingThing.VTU.Common.Models.VTUPowerUserInfoTypeDescriptorBuilder.g.cs", "VTUPowerUserInfoTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296469187)
            
            //--TRIMMABLE-BOUNDARY-START(12886403779)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886403779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Disco"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUPowerUserInfo.$type, $.$discardRef(), "Disco", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Disco")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mskq.LVCM.VTUPowerDisco, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Disco";
                        $i1.DelaredOn = "LivingThing.VTU.Common.Models.VTUPowerUserInfo";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$mskq.LVCM.VTUPowerDisco, ($.$cast(target, $.$mskq.LVCM.VTUPowerUserInfo)).Disco);
                        }, $BZyQXe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501891,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Disco = value.AsEnumValue($.$mskq.LVCM.VTUPowerDisco);
                        }, $SxPOik ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1501891,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MeterType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUPowerUserInfo.$type, $.$discardRef(), "MeterType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MeterType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mskq.LVCM.VTUMeterType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "MeterType";
                        $i3.DelaredOn = "LivingThing.VTU.Common.Models.VTUPowerUserInfo";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$mskq.LVCM.VTUMeterType, ($.$cast(target, $.$mskq.LVCM.VTUPowerUserInfo)).MeterType);
                        }, $IpEjpi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501891,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.MeterType = value.AsEnumValue($.$mskq.LVCM.VTUMeterType);
                        }, $gYLIwc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1501891,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MeterNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUPowerUserInfo.$type, $.$discardRef(), "MeterNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MeterNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "MeterNumber";
                        $i5.DelaredOn = "LivingThing.VTU.Common.Models.VTUPowerUserInfo";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUPowerUserInfo)).MeterNumber);
                        }, $hFJKCf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501891,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MeterNumber = value.AsReference($.$$.S.String);
                        }, $VWZoee ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1501891,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUPowerUserInfo.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PhoneNumber";
                        $i7.DelaredOn = "LivingThing.VTU.Common.Models.VTUPowerUserInfo";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUPowerUserInfo)).PhoneNumber);
                        }, $MgvPGg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501891,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsReference($.$$.S.String);
                        }, $snWnab ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1501891,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUPowerUserInfo.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Description";
                        $i9.DelaredOn = "LivingThing.VTU.Common.Models.VTUPowerUserInfo";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUPowerUserInfo)).Description);
                        }, $HToeHk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1501891,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886403779)
            
            //--TRIMMABLE-BOUNDARY-START(17181371075)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUPowerUserInfo*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181371075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Disco = _target.Disco;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Disco"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mskq.LVCM.VTUPowerDisco));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mskq.LVCM.VTUPowerDisco, () => _Disco, ($v) => _Disco = $v, null, true)))
                    {
                        _target.Disco = _Disco;
                    }
                }
                {
                    /*var*/ let _MeterType = _target.MeterType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MeterType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mskq.LVCM.VTUMeterType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mskq.LVCM.VTUMeterType, () => _MeterType, ($v) => _MeterType = $v, null, true)))
                    {
                        _target.MeterType = _MeterType;
                    }
                }
                {
                    /*var*/ let _MeterNumber = _target.MeterNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MeterNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _MeterNumber, ($v) => _MeterNumber = $v, $.$$.S.String)))
                    {
                        _target.MeterNumber = _MeterNumber;
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PhoneNumber, ($v) => _PhoneNumber = $v, $.$$.S.String)))
                    {
                        _target.PhoneNumber = _PhoneNumber;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181371075)
            
            //--TRIMMABLE-BOUNDARY-START(8591436483)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUPowerUserInfo?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591436483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mskq.LVCM.VTUPowerUserInfo().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mskq.LVCM.VTUPowerUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUPowerUserInfo)))
                {
                    /*var*/ let result = $.$mskq.LVCM.VTUPowerUserInfoTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUPowerUserInfo));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mskq.LVCM.VTUPowerUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUPowerUserInfo));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591436483)
            
            static $h = 1501891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUPowerUserInfo); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886403779),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1501891,
      "h": 12886403779,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886403779),
//--TRIMMABLE-BOUNDARY-START(17181371075),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1436355,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1501891,
      "h": 17181371075,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181371075),
//--TRIMMABLE-BOUNDARY-START(8591436483),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1436355,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1501891,
      "h": 8591436483,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591436483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296469187),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1501891,
      "h": 4296469187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296469187)
  ],
  "h": 1501891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mskq.LVCM.VTUPowerUserInfo), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUPowerUserInfoTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUPowerUserInfoTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1501891)
        
        

        //--TRIMMABLE-BOUNDARY-START(780995)
        $asm.$cls(`$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor`, ($self) => class VTUInternetDataUserInfoTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUInternetDataUserInfo)
        {
            //--TRIMMABLE-BOUNDARY-START(4295748291)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295748291);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor.GenerateProperties($.$mskq.LVCM.VTUInternetDataUserInfo, this, factory);
                    }, $mjGFwa ??= {"r":65537,"n":"","d":780995,"h":0,"f":17825794}), 0, "VTUInternetDataUserInfoTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\Models_VTUInternetDataUserInfo_LivingThing.VTU.Common.Models.VTUInternetDataUserInfoTypeDescriptorBuilder.g.cs", "VTUInternetDataUserInfoTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295748291)
            
            //--TRIMMABLE-BOUNDARY-START(12885682883)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885682883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MobileNetwork"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUInternetDataUserInfo.$type, $.$discardRef(), "MobileNetwork", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MobileNetwork")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mskq.LVCM.VTUMobileNetwork, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "MobileNetwork";
                        $i1.DelaredOn = "LivingThing.VTU.Common.Models.VTUInternetDataUserInfo";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$mskq.LVCM.VTUMobileNetwork, ($.$cast(target, $.$mskq.LVCM.VTUInternetDataUserInfo)).MobileNetwork);
                        }, $xDsCYc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":780995,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MobileNetwork = value.AsEnumValue($.$mskq.LVCM.VTUMobileNetwork);
                        }, $ZdTTfd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":780995,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Package"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUInternetDataUserInfo.$type, $.$discardRef(), "Package", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Package")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mskq.LVCM.VTUSelectPackage, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Package";
                        $i3.DelaredOn = "LivingThing.VTU.Common.Models.VTUInternetDataUserInfo";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$mskq.LVCM.VTUSelectPackage, ($.$cast(target, $.$mskq.LVCM.VTUInternetDataUserInfo)).Package);
                        }, $iiUYbl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":780995,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Package = value.AsValue($.$mskq.LVCM.VTUSelectPackage);
                        }, $SNOvhk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":780995,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUInternetDataUserInfo.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PhoneNumber";
                        $i5.DelaredOn = "LivingThing.VTU.Common.Models.VTUInternetDataUserInfo";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUInternetDataUserInfo)).PhoneNumber);
                        }, $mtYSDa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":780995,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsReference($.$$.S.String);
                        }, $uuLxXk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":780995,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCM.VTUInternetDataUserInfo.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Description";
                        $i7.DelaredOn = "LivingThing.VTU.Common.Models.VTUInternetDataUserInfo";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$mskq.LVCM.VTUInternetDataUserInfo)).Description);
                        }, $DRICwe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":780995,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885682883)
            
            //--TRIMMABLE-BOUNDARY-START(17180650179)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUInternetDataUserInfo*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180650179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _MobileNetwork = _target.MobileNetwork;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MobileNetwork"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mskq.LVCM.VTUMobileNetwork));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mskq.LVCM.VTUMobileNetwork, () => _MobileNetwork, ($v) => _MobileNetwork = $v, null, true)))
                    {
                        _target.MobileNetwork = _MobileNetwork;
                    }
                }
                {
                    /*var*/ let _Package = _target.Package;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Package"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mskq.LVCM.VTUSelectPackage));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mskq.LVCM.VTUSelectPackage, () => _Package, ($v) => _Package = $v, null, true)))
                    {
                        _target.Package = $.$clone(_Package);
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PhoneNumber, ($v) => _PhoneNumber = $v, $.$$.S.String)))
                    {
                        _target.PhoneNumber = _PhoneNumber;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180650179)
            
            //--TRIMMABLE-BOUNDARY-START(8590715587)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Models.VTUInternetDataUserInfo?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590715587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mskq.LVCM.VTUInternetDataUserInfo().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mskq.LVCM.VTUInternetDataUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUInternetDataUserInfo)))
                {
                    /*var*/ let result = $.$mskq.LVCM.VTUInternetDataUserInfoTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUInternetDataUserInfo));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mskq.LVCM.VTUInternetDataUserInfo, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCM.VTUInternetDataUserInfo));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590715587)
            
            static $h = 780995;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCM.VTUInternetDataUserInfo); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885682883),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 780995,
      "h": 12885682883,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885682883),
//--TRIMMABLE-BOUNDARY-START(17180650179),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 715459,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 780995,
      "h": 17180650179,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180650179),
//--TRIMMABLE-BOUNDARY-START(8590715587),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 715459,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 780995,
      "h": 8590715587,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590715587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295748291),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 780995,
      "h": 4295748291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295748291)
  ],
  "h": 780995
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mskq.LVCM.VTUInternetDataUserInfo), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Models.VTUInternetDataUserInfoTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Models${separator}VTUInternetDataUserInfoTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(780995)
        
        

        //--TRIMMABLE-BOUNDARY-START(2681539)
        $asm.$cls(`$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor`, ($self) => class VTUGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCS$1.VTUGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297648835)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297648835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor.GenerateProperties($.$mskq.LVCS$1.VTUGlobalSettings, this, factory);
                    }, $ekSzld ??= {"r":65537,"n":"","d":2681539,"h":0,"f":17825794}), 0, "VTUGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.VTU.Common\\Settings_VTUGlobalSettings_LivingThing.VTU.Common.Settings.VTUGlobalSettingsTypeDescriptorBuilder.g.cs", "VTUGlobalSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297648835)
            
            //--TRIMMABLE-BOUNDARY-START(12887583427)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887583427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InternetSurCharge"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "InternetSurCharge", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InternetSurCharge")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "InternetSurCharge";
                        $i1.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).InternetSurCharge);
                        }, $dsxaJj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.InternetSurCharge = value.AsInt();
                        }, $XxoKSh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TVSurCharge"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "TVSurCharge", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TVSurCharge")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "TVSurCharge";
                        $i3.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).TVSurCharge);
                        }, $TlSIPc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TVSurCharge = value.AsInt();
                        }, $aBXOxb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MTNInternetPricing"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "MTNInternetPricing", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MTNInternetPricing")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "MTNInternetPricing";
                        $i5.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), ($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).MTNInternetPricing);
                        }, $sFKiih ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MTNInternetPricing = value.AsReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing));
                        }, $wvgGVa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GloInternetPricing"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "GloInternetPricing", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GloInternetPricing")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "GloInternetPricing";
                        $i7.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), ($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).GloInternetPricing);
                        }, $DQOJhh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.GloInternetPricing = value.AsReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing));
                        }, $pTyfOb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AirtelInternetPricing"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "AirtelInternetPricing", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AirtelInternetPricing")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "AirtelInternetPricing";
                        $i9.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), ($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).AirtelInternetPricing);
                        }, $YkCvRh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.AirtelInternetPricing = value.AsReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing));
                        }, $gsocff ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EtisalatInternetPricing"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "EtisalatInternetPricing", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EtisalatInternetPricing")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "EtisalatInternetPricing";
                        $i11.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), ($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).EtisalatInternetPricing);
                        }, $fQNGke ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.EtisalatInternetPricing = value.AsReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing));
                        }, $PjcUbj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DSTVPricing"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "DSTVPricing", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DSTVPricing")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "DSTVPricing";
                        $i13.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), ($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).DSTVPricing);
                        }, $NftbSg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.DSTVPricing = value.AsReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing));
                        }, $qZZCSd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GOTVPricing"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "GOTVPricing", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GOTVPricing")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "GOTVPricing";
                        $i15.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), ($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).GOTVPricing);
                        }, $JSyuTd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.GOTVPricing = value.AsReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing));
                        }, $VihUef ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StarTimesPricing"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$mskq.LVCS$1.VTUGlobalSettings.$type, $.$discardRef(), "StarTimesPricing", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StarTimesPricing")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "StarTimesPricing";
                        $i17.DelaredOn = "LivingThing.VTU.Common.Settings.VTUGlobalSettings";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), ($.$cast(target, $.$mskq.LVCS$1.VTUGlobalSettings)).StarTimesPricing);
                        }, $beFjTc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2681539,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StarTimesPricing = value.AsReference($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing));
                        }, $pcjXzg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2681539,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887583427)
            
            //--TRIMMABLE-BOUNDARY-START(17182550723)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Settings.VTUGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182550723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentGlobalSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentGlobalSettings));
                {
                    /*var*/ let _InternetSurCharge = _target.InternetSurCharge;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InternetSurCharge"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _InternetSurCharge, ($v) => _InternetSurCharge = $v, $.$$.S.Int32)))
                    {
                        _target.InternetSurCharge = _InternetSurCharge;
                    }
                }
                {
                    /*var*/ let _TVSurCharge = _target.TVSurCharge;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TVSurCharge"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TVSurCharge, ($v) => _TVSurCharge = $v, $.$$.S.Int32)))
                    {
                        _target.TVSurCharge = _TVSurCharge;
                    }
                }
                {
                    /*var*/ let _MTNInternetPricing = _target.MTNInternetPricing;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MTNInternetPricing"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _MTNInternetPricing, ($v) => _MTNInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing))))
                    {
                        _target.MTNInternetPricing = _MTNInternetPricing;
                        if (_MTNInternetPricing !== null)
                        {
                            let $en24 = _MTNInternetPricing.SCG$IEnumerable$$$GetEnumerator();
                            while ($en24.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en24.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$mskq.LVCS$1.VTUPricing)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _MTNInternetPricing, ($v) => _MTNInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    }
                }
                {
                    /*var*/ let _GloInternetPricing = _target.GloInternetPricing;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GloInternetPricing"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _GloInternetPricing, ($v) => _GloInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing))))
                    {
                        _target.GloInternetPricing = _GloInternetPricing;
                        if (_GloInternetPricing !== null)
                        {
                            let $en29 = _GloInternetPricing.SCG$IEnumerable$$$GetEnumerator();
                            while ($en29.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en29.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$mskq.LVCS$1.VTUPricing)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _GloInternetPricing, ($v) => _GloInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    }
                }
                {
                    /*var*/ let _AirtelInternetPricing = _target.AirtelInternetPricing;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AirtelInternetPricing"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _AirtelInternetPricing, ($v) => _AirtelInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing))))
                    {
                        _target.AirtelInternetPricing = _AirtelInternetPricing;
                        if (_AirtelInternetPricing !== null)
                        {
                            let $en34 = _AirtelInternetPricing.SCG$IEnumerable$$$GetEnumerator();
                            while ($en34.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en34.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$mskq.LVCS$1.VTUPricing)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _AirtelInternetPricing, ($v) => _AirtelInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    }
                }
                {
                    /*var*/ let _EtisalatInternetPricing = _target.EtisalatInternetPricing;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EtisalatInternetPricing"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _EtisalatInternetPricing, ($v) => _EtisalatInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing))))
                    {
                        _target.EtisalatInternetPricing = _EtisalatInternetPricing;
                        if (_EtisalatInternetPricing !== null)
                        {
                            let $en39 = _EtisalatInternetPricing.SCG$IEnumerable$$$GetEnumerator();
                            while ($en39.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en39.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$mskq.LVCS$1.VTUPricing)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _EtisalatInternetPricing, ($v) => _EtisalatInternetPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    }
                }
                {
                    /*var*/ let _DSTVPricing = _target.DSTVPricing;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DSTVPricing"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _DSTVPricing, ($v) => _DSTVPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing))))
                    {
                        _target.DSTVPricing = _DSTVPricing;
                        if (_DSTVPricing !== null)
                        {
                            let $en44 = _DSTVPricing.SCG$IEnumerable$$$GetEnumerator();
                            while ($en44.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en44.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$mskq.LVCS$1.VTUPricing)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _DSTVPricing, ($v) => _DSTVPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    }
                }
                {
                    /*var*/ let _GOTVPricing = _target.GOTVPricing;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GOTVPricing"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _GOTVPricing, ($v) => _GOTVPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing))))
                    {
                        _target.GOTVPricing = _GOTVPricing;
                        if (_GOTVPricing !== null)
                        {
                            let $en49 = _GOTVPricing.SCG$IEnumerable$$$GetEnumerator();
                            while ($en49.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en49.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$mskq.LVCS$1.VTUPricing)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _GOTVPricing, ($v) => _GOTVPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    }
                }
                {
                    /*var*/ let _StarTimesPricing = _target.StarTimesPricing;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StarTimesPricing"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _StarTimesPricing, ($v) => _StarTimesPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing))))
                    {
                        _target.StarTimesPricing = _StarTimesPricing;
                        if (_StarTimesPricing !== null)
                        {
                            let $en54 = _StarTimesPricing.SCG$IEnumerable$$$GetEnumerator();
                            while ($en54.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en54.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$mskq.LVCS$1.VTUPricing)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing), $.$mskq.LVCS$1.VTUPricing, property, $.$ref(() => _StarTimesPricing, ($v) => _StarTimesPricing = $v, $.$$.SCG.IEnumerable$$($.$mskq.LVCS$1.VTUPricing)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182550723)
            
            //--TRIMMABLE-BOUNDARY-START(8592616131)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.VTU.Common.Settings.VTUGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592616131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$mskq.LVCS$1.VTUGlobalSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$mskq.LVCS$1.VTUGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCS$1.VTUGlobalSettings)))
                {
                    /*var*/ let result = $.$mskq.LVCS$1.VTUGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCS$1.VTUGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$mskq.LVCS$1.VTUGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$mskq.LVCS$1.VTUGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592616131)
            
            static $h = 2681539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$mskq.LVCS$1.VTUGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887583427),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2681539,
      "h": 12887583427,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887583427),
//--TRIMMABLE-BOUNDARY-START(17182550723),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2550467,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2681539,
      "h": 17182550723,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182550723),
//--TRIMMABLE-BOUNDARY-START(8592616131),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2550467,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2681539,
      "h": 8592616131,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592616131)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297648835),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2681539,
      "h": 4297648835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297648835)
  ],
  "h": 2681539
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$mskq.LVCS$1.VTUGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.VTU.Common.Settings.VTUGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}VTU${separator}Common${separator}Settings${separator}VTUGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2681539)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Payment"));
})();
//--TRIMMABLE-BOUNDARY-END(60099)
