
//--TRIMMABLE-BOUNDARY-START(52179)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $mexl, $mj, $mjw, $macwa, $mnhh, $maw, $mbc, $meca, $mecm, $mia, $mil, $mit, $mij, $sih, $wZnq, $fnTP, $hqRR, $sitj, $Xjnw, $AWhY, $fPer, $zHIt, $kVHt, $Iaui, $uvJL, $ajwi, $GfYa, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $lJUR, $WRsM, $DZqk, $uVBI, $yJPN, $xPgy, $wtdm, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $GYJg, $xrPB, $BrCm, $OkRL, $wQhY, $oUrI, $tjSj, $RffN, $jfJD, $OnVo, $Filo, $bTOs, $tUzp, $Bykq, $qbhX, $PZCj, $yCMk, $PIIp, $cDXw, $pGPn, $IHYd, $ZaYa, $OUNt, $aImc, $dRCs, $UcdF, $JRhp, $bRsy, $Gjye, $SXZI, $TLvC, $TBFc, $Jsis, $lAxY, $gUjM, $WcGF, $QcZy, $tCiC, $uERE, $XtuU, $wmbl, $RoTr, $vOBI, $xvUV, $sQJD, $sUMr, $GETr, $Gokg, $fMQq, $ftPx, $Qqwn, $mMXL, $IUsF, $Fjop, $JkHl, $AEuu, $fXpo, $KuVO, $MICX, $OSmP, $QxAa, $hkBT, $Vfzz, $anJf, $GeIp, $fbjj, $UQAj, $irDD, $Mstz, $lmlW, $izAa, $FuXl, $aAgx, $dXSd, $dqzR, $OCet, $fycR, $awPs, $DiFq, $bMcF, $rfUg, $aElv, $yyXP, $eFOo, $lOHy, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $ntej, $MCAB, $Urjw, $fJEF, $oAeB, $MXzz, $BHhH, $dRBU, $uXRA, $MDmQ, $sAEu, $SWDz, $Bnua, $ehcb, $OfMV, $mpgO, $qgEF, $SAWq, $bfaB, $rAPp, $Cdtc, $AutK, $bHuH, $IDVm, $XvXV, $lmWW, $TvJd, $NzWm, $cCKL, $HTiB, $Gtji, $rwTP, $jjuN, $ezfM, $LiyH, $QPfZ, $WYlj, $qYTe, $bweh, $MmZc, $CgOi, $HGGn, $PkgL, $CACm, $LGQP, $IhzR, $tKtD, $ASam, $PSrA, $uUnI, $mXnX, $LnxK, $wDws, $dRGn, $gKEB, $nGxw, $pgHg, $OHIm, $MZKr, $hmEn, $ivxN, $fsgt, $CFEL, $XBnD, $Gfla, $eHSC, $zxUu, $qqCA, $qKfs, $OgAC, $QoDz, $tAAp, $UqSD, $UlXD, $HSAN, $gGJx, $cHnS, $NFcu) {
    "use strict";
    let _;
    let $ESPjFh;
    let $HmCDYe;
    let $HdnWpi;
    let $UNcPpd;
    let $asNYAk;
    let $aVvHMe;
    let $YcHsLi;
    let $eRaHlj;
    let $uCSEPa;
    let $erjwCh;
    let $OvDuOb;
    let $SyYpmc;
    let $ZLxyqh;
    let $fHsXTf;
    let $JjOHrg;
    let $zVpJLk;
    let $nVpkve;
    let $tynJQa;
    let $TXNswi;
    let $eAQVRk;
    let $yIdPVb;
    let $oUEzUc;
    let $rhUqPd;
    let $aShzrf;
    let $OcLmkd;
    let $FXaCcd;
    let $ooRIRd;
    let $OtITyb;
    let $nRCENj;
    let $cwJpAa;
    let $zWJTPj;
    let $zIPXed;
    let $ykpxAb;
    let $OtPFvh;
    let $XgWzYj;
    let $QXuUgh;
    let $fwqTnc;
    let $KnxkQh;
    let $mibrJb;
    let $yYtEsa;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Web.Client.Wasm", 
    {
  "g": 1,
  "h": 52179,
  "f": "LivingThing.Web.Client.Wasm",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.Routing.RegexConstraintSupport",
          "t": 1310721
        },
        {
          "v": "true",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Web.Client.Wasm",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Web.Client.Wasm",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.Development.json",
      "d": "ew0KICAiU2VydmVyIjogew0KICAgIC8vIlVybCI6ICIuIg0KICAgIC8vIlVybCI6ICJsb2NhbGhvc3Q6NTAwMSINCiAgICAiVXJsIjogInpvZXkuYWZyaWNhIg0KICB9DQp9DQo="
    },
    {
      "n": "appsettings.json",
      "d": "ew0KICAiU2VydmVyIjogew0KICAgIC8vIlVybCI6ICJsb2NhbGhvc3Q6NTAwMSINCiAgICAiVXJsIjogImh0dHBzOi8vem9leS5hZnJpY2EiDQogIH0sDQogICJHb29nbGUiOiB7DQogICAgIk9BdXRoMiI6IHsNCiAgICAgICJDbGllbnRJZCI6ICI5NzUzNjA2Mzc5ODItdHIyNGU5dGwwOGQ5NzY0dmZwY2I5bHZmZTEwZjJlNmguYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iDQogICAgfSwNCiAgICAiTWFwcyI6IHsNCiAgICAgICJBUElLZXkiOiAiQUl6YVN5QmM0NHRjbHJPSjVaTGxHWEV6dC11RDM1X3BBZ1QwQkFJIg0KICAgIH0NCiAgfSwNCiAgIkxvY2F0aW9uSVEiOiB7DQogICAgIkFQSUtleSI6ICJway41MjIwNmI5Njg3YjQ4MDI4OGU4MDkzNGY3OTVmOTdmYSINCiAgfQ0KfQ0K"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(576467)
        $asm.$cls(`$RywK.LWCW.DynamicRegistrar`, ($self) => class DynamicRegistrar
        {
            //--TRIMMABLE-BOUNDARY-START(4295543763)
            static /*void */ LivingThing_Core_Admin_Client_Startup_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295543763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$WRsM.LCACS$2.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(4295543763)
            
            //--TRIMMABLE-BOUNDARY-START(12885478355)
            static /*void */ LivingThing_Core_Authentication_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885478355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uVBI.LCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(12885478355)
            
            //--TRIMMABLE-BOUNDARY-START(8590511059)
            static /*void */ LivingThing_Core_Authentication_Client_OAuth_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590511059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yJPN.LCACO.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(8590511059)
            
            //--TRIMMABLE-BOUNDARY-START(17180445651)
            static /*void */ LivingThing_Core_Authentication_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180445651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$DZqk.LCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(17180445651)
            
            //--TRIMMABLE-BOUNDARY-START(21475412947)
            static /*void */ LivingThing_Core_Bills_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475412947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$cnlM.LCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(21475412947)
            
            //--TRIMMABLE-BOUNDARY-START(25770380243)
            static /*void */ LivingThing_Core_Bills_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770380243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xPgy.LCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(25770380243)
            
            //--TRIMMABLE-BOUNDARY-START(30065347539)
            static /*void */ LivingThing_Core_Community_Account_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065347539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$GYJg.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(30065347539)
            
            //--TRIMMABLE-BOUNDARY-START(34360314835)
            static /*void */ LivingThing_Core_Community_Account_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360314835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$jlvo.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(34360314835)
            
            //--TRIMMABLE-BOUNDARY-START(38655282131)
            static /*void */ LivingThing_Core_Community_Article_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655282131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$BrCm.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(38655282131)
            
            //--TRIMMABLE-BOUNDARY-START(42950249427)
            static /*void */ LivingThing_Core_Community_Article_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950249427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xrPB.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(42950249427)
            
            //--TRIMMABLE-BOUNDARY-START(47245216723)
            static /*void */ LivingThing_Core_Community_Barter_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245216723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wQhY.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(47245216723)
            
            //--TRIMMABLE-BOUNDARY-START(51540184019)
            static /*void */ LivingThing_Core_Community_Barter_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540184019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OkRL.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(51540184019)
            
            //--TRIMMABLE-BOUNDARY-START(55835151315)
            static /*void */ LivingThing_Core_Community_BuyLink_Client_Admin_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835151315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ehcb.LCCBCA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(55835151315)
            
            //--TRIMMABLE-BOUNDARY-START(60130118611)
            static /*void */ LivingThing_Core_Community_BuyLink_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130118611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$jfJD.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(60130118611)
            
            //--TRIMMABLE-BOUNDARY-START(64425085907)
            static /*void */ LivingThing_Core_Community_BuyLink_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425085907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$RffN.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(64425085907)
            
            //--TRIMMABLE-BOUNDARY-START(68720053203)
            static /*void */ LivingThing_Core_Community_Calendar_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720053203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Filo.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(68720053203)
            
            //--TRIMMABLE-BOUNDARY-START(73015020499)
            static /*void */ LivingThing_Core_Community_Calendar_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015020499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OnVo.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(73015020499)
            
            //--TRIMMABLE-BOUNDARY-START(77309987795)
            static /*void */ LivingThing_Core_Community_CampaignBot_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309987795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tUzp.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(77309987795)
            
            //--TRIMMABLE-BOUNDARY-START(81604955091)
            static /*void */ LivingThing_Core_Community_CampaignBot_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604955091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bTOs.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(81604955091)
            
            //--TRIMMABLE-BOUNDARY-START(85899922387)
            static /*void */ LivingThing_Core_Community_Chat_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899922387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$qbhX.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(85899922387)
            
            //--TRIMMABLE-BOUNDARY-START(90194889683)
            static /*void */ LivingThing_Core_Community_Chat_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194889683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Bykq.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(90194889683)
            
            //--TRIMMABLE-BOUNDARY-START(94489856979)
            static /*void */ LivingThing_Core_Community_Church_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489856979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$pGPn.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(94489856979)
            
            //--TRIMMABLE-BOUNDARY-START(98784824275)
            static /*void */ LivingThing_Core_Community_Church_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784824275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yCMk.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(98784824275)
            
            //--TRIMMABLE-BOUNDARY-START(103079791571)
            static /*void */ LivingThing_Core_Community_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079791571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(103079791571)
            
            //--TRIMMABLE-BOUNDARY-START(107374758867)
            static /*void */ LivingThing_Core_Community_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374758867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ydCm.LCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(107374758867)
            
            //--TRIMMABLE-BOUNDARY-START(111669726163)
            static /*void */ LivingThing_Core_Community_DIPTV_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669726163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dRCs.LCCD.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(111669726163)
            
            //--TRIMMABLE-BOUNDARY-START(115964693459)
            static /*void */ LivingThing_Core_Community_Dispatch_Client_Admin_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964693459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OfMV.LCCDCA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(115964693459)
            
            //--TRIMMABLE-BOUNDARY-START(120259660755)
            static /*void */ LivingThing_Core_Community_Dispatch_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259660755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$TLvC.LCCDC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(120259660755)
            
            //--TRIMMABLE-BOUNDARY-START(124554628051)
            static /*void */ LivingThing_Core_Community_Dispatch_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554628051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bRsy.LCCDC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(124554628051)
            
            //--TRIMMABLE-BOUNDARY-START(128849595347)
            static /*void */ LivingThing_Core_Community_Dispatch_Schemes_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849595347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Gjye.LCCDS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(128849595347)
            
            //--TRIMMABLE-BOUNDARY-START(133144562643)
            static /*void */ LivingThing_Core_Community_Election_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144562643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Jsis.LCCEC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(133144562643)
            
            //--TRIMMABLE-BOUNDARY-START(137439529939)
            static /*void */ LivingThing_Core_Community_Election_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439529939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$TBFc.LCCEC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(137439529939)
            
            //--TRIMMABLE-BOUNDARY-START(141734497235)
            static /*void */ LivingThing_Core_Community_Forum_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734497235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$gUjM.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(141734497235)
            
            //--TRIMMABLE-BOUNDARY-START(146029464531)
            static /*void */ LivingThing_Core_Community_Forum_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029464531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$lAxY.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(146029464531)
            
            //--TRIMMABLE-BOUNDARY-START(150324431827)
            static /*void */ LivingThing_Core_Community_FundMe_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324431827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$QcZy.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(150324431827)
            
            //--TRIMMABLE-BOUNDARY-START(154619399123)
            static /*void */ LivingThing_Core_Community_FundMe_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619399123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$WcGF.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(154619399123)
            
            //--TRIMMABLE-BOUNDARY-START(158914366419)
            static /*void */ LivingThing_Core_Community_Games_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914366419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uERE.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(158914366419)
            
            //--TRIMMABLE-BOUNDARY-START(163209333715)
            static /*void */ LivingThing_Core_Community_Games_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209333715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tCiC.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(163209333715)
            
            //--TRIMMABLE-BOUNDARY-START(167504301011)
            static /*void */ LivingThing_Core_Community_Gift_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504301011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wmbl.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(167504301011)
            
            //--TRIMMABLE-BOUNDARY-START(171799268307)
            static /*void */ LivingThing_Core_Community_Gift_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799268307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XtuU.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(171799268307)
            
            //--TRIMMABLE-BOUNDARY-START(176094235603)
            static /*void */ LivingThing_Core_Community_Group_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094235603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PIIp.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(176094235603)
            
            //--TRIMMABLE-BOUNDARY-START(180389202899)
            static /*void */ LivingThing_Core_Community_Group_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389202899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(180389202899)
            
            //--TRIMMABLE-BOUNDARY-START(184684170195)
            static /*void */ LivingThing_Core_Community_Group_User_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684170195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$vOBI.LCCGUC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(184684170195)
            
            //--TRIMMABLE-BOUNDARY-START(188979137491)
            static /*void */ LivingThing_Core_Community_Group_User_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979137491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$RoTr.LCCGUC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(188979137491)
            
            //--TRIMMABLE-BOUNDARY-START(193274104787)
            static /*void */ LivingThing_Core_Community_Handyman_Client_Admin_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274104787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mpgO.LCCHCA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(193274104787)
            
            //--TRIMMABLE-BOUNDARY-START(197569072083)
            static /*void */ LivingThing_Core_Community_Handyman_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569072083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$SXZI.LCCHC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(197569072083)
            
            //--TRIMMABLE-BOUNDARY-START(201864039379)
            static /*void */ LivingThing_Core_Community_Handyman_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864039379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UcdF.LCCHC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(201864039379)
            
            //--TRIMMABLE-BOUNDARY-START(206159006675)
            static /*void */ LivingThing_Core_Community_Job_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159006675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sQJD.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(206159006675)
            
            //--TRIMMABLE-BOUNDARY-START(210453973971)
            static /*void */ LivingThing_Core_Community_Job_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453973971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xvUV.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(210453973971)
            
            //--TRIMMABLE-BOUNDARY-START(214748941267)
            static /*void */ LivingThing_Core_Community_Journal_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748941267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$GETr.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(214748941267)
            
            //--TRIMMABLE-BOUNDARY-START(219043908563)
            static /*void */ LivingThing_Core_Community_Journal_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043908563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sUMr.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(219043908563)
            
            //--TRIMMABLE-BOUNDARY-START(223338875859)
            static /*void */ LivingThing_Core_Community_Loan_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338875859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fMQq.LCCLC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(223338875859)
            
            //--TRIMMABLE-BOUNDARY-START(227633843155)
            static /*void */ LivingThing_Core_Community_Loan_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633843155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Gokg.LCCLC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(227633843155)
            
            //--TRIMMABLE-BOUNDARY-START(231928810451)
            static /*void */ LivingThing_Core_Community_LoanManagement_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928810451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Qqwn.LCCLC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(231928810451)
            
            //--TRIMMABLE-BOUNDARY-START(236223777747)
            static /*void */ LivingThing_Core_Community_LoanManagement_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223777747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ftPx.LCCLC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(236223777747)
            
            //--TRIMMABLE-BOUNDARY-START(240518745043)
            static /*void */ LivingThing_Core_Community_Make_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518745043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$IUsF.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(240518745043)
            
            //--TRIMMABLE-BOUNDARY-START(244813712339)
            static /*void */ LivingThing_Core_Community_Make_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813712339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mMXL.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(244813712339)
            
            //--TRIMMABLE-BOUNDARY-START(249108679635)
            static /*void */ LivingThing_Core_Community_Market_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108679635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MICX.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(249108679635)
            
            //--TRIMMABLE-BOUNDARY-START(253403646931)
            static /*void */ LivingThing_Core_Community_Market_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403646931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Fjop.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(253403646931)
            
            //--TRIMMABLE-BOUNDARY-START(257698614227)
            static /*void */ LivingThing_Core_Community_Market_StorePaymentTier_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698614227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$JkHl.LCCMS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(257698614227)
            
            //--TRIMMABLE-BOUNDARY-START(261993581523)
            static /*void */ LivingThing_Core_Community_Media_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993581523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$QxAa.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(261993581523)
            
            //--TRIMMABLE-BOUNDARY-START(266288548819)
            static /*void */ LivingThing_Core_Community_Media_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288548819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OSmP.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(266288548819)
            
            //--TRIMMABLE-BOUNDARY-START(270583516115)
            static /*void */ LivingThing_Core_Community_NairalandForum_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583516115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Vfzz.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(270583516115)
            
            //--TRIMMABLE-BOUNDARY-START(274878483411)
            static /*void */ LivingThing_Core_Community_NairalandForum_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878483411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hkBT.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(274878483411)
            
            //--TRIMMABLE-BOUNDARY-START(279173450707)
            static /*void */ LivingThing_Core_Community_NewsAggregator_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173450707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$GeIp.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(279173450707)
            
            //--TRIMMABLE-BOUNDARY-START(283468418003)
            static /*void */ LivingThing_Core_Community_NewsAggregator_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468418003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$anJf.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(283468418003)
            
            //--TRIMMABLE-BOUNDARY-START(287763385299)
            static /*void */ LivingThing_Core_Community_Note_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763385299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UQAj.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(287763385299)
            
            //--TRIMMABLE-BOUNDARY-START(292058352595)
            static /*void */ LivingThing_Core_Community_Note_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058352595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fbjj.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(292058352595)
            
            //--TRIMMABLE-BOUNDARY-START(296353319891)
            static /*void */ LivingThing_Core_Community_Organization_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353319891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Mstz.LCCOC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(296353319891)
            
            //--TRIMMABLE-BOUNDARY-START(300648287187)
            static /*void */ LivingThing_Core_Community_Organization_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648287187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$irDD.LCCOC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(300648287187)
            
            //--TRIMMABLE-BOUNDARY-START(304943254483)
            static /*void */ LivingThing_Core_Community_Pay_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943254483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$izAa.LCCPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(304943254483)
            
            //--TRIMMABLE-BOUNDARY-START(309238221779)
            static /*void */ LivingThing_Core_Community_Pay_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238221779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$lmlW.LCCPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(309238221779)
            
            //--TRIMMABLE-BOUNDARY-START(313533189075)
            static /*void */ LivingThing_Core_Community_Reply_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533189075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$aAgx.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(313533189075)
            
            //--TRIMMABLE-BOUNDARY-START(317828156371)
            static /*void */ LivingThing_Core_Community_Reply_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828156371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$FuXl.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(317828156371)
            
            //--TRIMMABLE-BOUNDARY-START(322123123667)
            static /*void */ LivingThing_Core_Community_Review_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123123667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dqzR.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(322123123667)
            
            //--TRIMMABLE-BOUNDARY-START(326418090963)
            static /*void */ LivingThing_Core_Community_Review_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418090963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dXSd.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(326418090963)
            
            //--TRIMMABLE-BOUNDARY-START(330713058259)
            static /*void */ LivingThing_Core_Community_School_Client_Admin_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713058259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bfaB.LCCSCA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(330713058259)
            
            //--TRIMMABLE-BOUNDARY-START(335008025555)
            static /*void */ LivingThing_Core_Community_School_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008025555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$awPs.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(335008025555)
            
            //--TRIMMABLE-BOUNDARY-START(339302992851)
            static /*void */ LivingThing_Core_Community_School_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302992851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OCet.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(339302992851)
            
            //--TRIMMABLE-BOUNDARY-START(343597960147)
            static /*void */ LivingThing_Core_Community_SchoolPortal_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597960147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Urjw.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(343597960147)
            
            //--TRIMMABLE-BOUNDARY-START(347892927443)
            static /*void */ LivingThing_Core_Community_SchoolPortal_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892927443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$DiFq.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(347892927443)
            
            //--TRIMMABLE-BOUNDARY-START(352187894739)
            static /*void */ LivingThing_Core_Community_Short_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187894739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$oAeB.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(352187894739)
            
            //--TRIMMABLE-BOUNDARY-START(356482862035)
            static /*void */ LivingThing_Core_Community_Short_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482862035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fJEF.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(356482862035)
            
            //--TRIMMABLE-BOUNDARY-START(360777829331)
            static /*void */ LivingThing_Core_Community_Sticky_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777829331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$BHhH.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(360777829331)
            
            //--TRIMMABLE-BOUNDARY-START(365072796627)
            static /*void */ LivingThing_Core_Community_Sticky_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072796627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MXzz.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(365072796627)
            
            //--TRIMMABLE-BOUNDARY-START(369367763923)
            static /*void */ LivingThing_Core_Community_Thrift_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367763923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uXRA.LCCTC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(369367763923)
            
            //--TRIMMABLE-BOUNDARY-START(373662731219)
            static /*void */ LivingThing_Core_Community_Thrift_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662731219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dRBU.LCCTC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(373662731219)
            
            //--TRIMMABLE-BOUNDARY-START(382252665811)
            static /*void */ LivingThing_Core_Community_TV_App_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252665811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OUNt.LCCTA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(382252665811)
            
            //--TRIMMABLE-BOUNDARY-START(377957698515)
            static /*void */ LivingThing_Core_Community_TV_Admin_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957698515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Cdtc.LCCTA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(377957698515)
            
            //--TRIMMABLE-BOUNDARY-START(386547633107)
            static /*void */ LivingThing_Core_Community_TV_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547633107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$aImc.LCCTC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(386547633107)
            
            //--TRIMMABLE-BOUNDARY-START(390842600403)
            static /*void */ LivingThing_Core_Community_TV_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842600403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ZaYa.LCCTC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(390842600403)
            
            //--TRIMMABLE-BOUNDARY-START(395137567699)
            static /*void */ LivingThing_Core_Community_TV_Free_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137567699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rAPp.LCCTF.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(395137567699)
            
            //--TRIMMABLE-BOUNDARY-START(399432534995)
            static /*void */ LivingThing_Core_Community_Website_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432534995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MDmQ.LCCWC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(399432534995)
            
            //--TRIMMABLE-BOUNDARY-START(403727502291)
            static /*void */ LivingThing_Core_Community_Website_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727502291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$AEuu.LCCWC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(403727502291)
            
            //--TRIMMABLE-BOUNDARY-START(408022469587)
            static /*void */ LivingThing_Core_Frameworks_Client_Application_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022469587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sZVd.LCFCA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(408022469587)
            
            //--TRIMMABLE-BOUNDARY-START(433792273363)
            static /*void */ LivingThing_Core_Frameworks_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792273363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(433792273363)
            
            //--TRIMMABLE-BOUNDARY-START(412317436883)
            static /*void */ LivingThing_Core_Frameworks_Client_FluentUI_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317436883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rfUg.LCFCF.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(412317436883)
            
            //--TRIMMABLE-BOUNDARY-START(416612404179)
            static /*void */ LivingThing_Core_Frameworks_Client_MarkdownPlus_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612404179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MdeX.LCFCM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(416612404179)
            
            //--TRIMMABLE-BOUNDARY-START(420907371475)
            static /*void */ LivingThing_Core_Frameworks_Client_PageBuilder_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907371475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yyXP.LCFCP.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(420907371475)
            
            //--TRIMMABLE-BOUNDARY-START(425202338771)
            static /*void */ LivingThing_Core_Frameworks_Client_Payment_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202338771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wtdm.LCFCP.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(425202338771)
            
            //--TRIMMABLE-BOUNDARY-START(429497306067)
            static /*void */ LivingThing_Core_Frameworks_Client_Posts_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497306067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Jxyt.LCFCP.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(429497306067)
            
            //--TRIMMABLE-BOUNDARY-START(438087240659)
            static /*void */ LivingThing_Core_Frameworks_Client_SPA_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087240659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$lJUR.LCFCS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(438087240659)
            
            //--TRIMMABLE-BOUNDARY-START(442382207955)
            static /*void */ LivingThing_Core_Frameworks_Client_TelegramMiniApp_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382207955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fycR.LCFCT.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(442382207955)
            
            //--TRIMMABLE-BOUNDARY-START(446677175251)
            static /*void */ LivingThing_Core_Frameworks_Common_Application_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677175251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yleQ.LCFCA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(446677175251)
            
            //--TRIMMABLE-BOUNDARY-START(450972142547)
            static /*void */ LivingThing_Core_Frameworks_Common_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972142547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$vWqU.LCFCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(450972142547)
            
            //--TRIMMABLE-BOUNDARY-START(455267109843)
            static /*void */ LivingThing_Core_Frameworks_Common_Connection_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267109843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$KuVO.LCFCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(455267109843)
            
            //--TRIMMABLE-BOUNDARY-START(515396651987)
            static /*void */ LivingThing_Core_Frameworks_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396651987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(515396651987)
            
            //--TRIMMABLE-BOUNDARY-START(459562077139)
            static /*void */ LivingThing_Core_Frameworks_Common_Hub_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562077139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$kVHt.LCFCH.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(459562077139)
            
            //--TRIMMABLE-BOUNDARY-START(463857044435)
            static /*void */ LivingThing_Core_Frameworks_Common_Local_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857044435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$IHYd.LCFCL.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(463857044435)
            
            //--TRIMMABLE-BOUNDARY-START(468152011731)
            static /*void */ LivingThing_Core_Frameworks_Common_Mapping_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152011731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$AutK.LCFCM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(468152011731)
            
            //--TRIMMABLE-BOUNDARY-START(472446979027)
            static /*void */ LivingThing_Core_Frameworks_Common_MarkdownPlus_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446979027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$EVvT.LCFCM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(472446979027)
            
            //--TRIMMABLE-BOUNDARY-START(476741946323)
            static /*void */ LivingThing_Core_Frameworks_Common_Mediator_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476741946323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tUcV.LCFCM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(476741946323)
            
            //--TRIMMABLE-BOUNDARY-START(481036913619)
            static /*void */ LivingThing_Core_Frameworks_Common_Messaging_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036913619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UrvY.LCFCM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(481036913619)
            
            //--TRIMMABLE-BOUNDARY-START(485331880915)
            static /*void */ LivingThing_Core_Frameworks_Common_Models_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485331880915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(485331880915)
            
            //--TRIMMABLE-BOUNDARY-START(489626848211)
            static /*void */ LivingThing_Core_Frameworks_Common_MotionJPEG_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489626848211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bHuH.LCFCM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(489626848211)
            
            //--TRIMMABLE-BOUNDARY-START(493921815507)
            static /*void */ LivingThing_Core_Frameworks_Common_Payment_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921815507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$nYKj.LCFCP.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(493921815507)
            
            //--TRIMMABLE-BOUNDARY-START(498216782803)
            static /*void */ LivingThing_Core_Frameworks_Common_Posts_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216782803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCP.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(498216782803)
            
            //--TRIMMABLE-BOUNDARY-START(506806717395)
            static /*void */ LivingThing_Core_Frameworks_Common_RPC_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806717395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uvJL.LCFCR.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(506806717395)
            
            //--TRIMMABLE-BOUNDARY-START(502511750099)
            static /*void */ LivingThing_Core_Frameworks_Common_RPC_Http_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511750099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$IDVm.LCFCRH.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(502511750099)
            
            //--TRIMMABLE-BOUNDARY-START(511101684691)
            static /*void */ LivingThing_Core_Frameworks_Common_RPC_WebSocket_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101684691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XvXV.LCFCRW.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(511101684691)
            
            //--TRIMMABLE-BOUNDARY-START(519691619283)
            static /*void */ LivingThing_Core_Frameworks_Common_Wallet_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691619283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OJJQ.LCFCW.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(519691619283)
            
            //--TRIMMABLE-BOUNDARY-START(523986586579)
            static /*void */ LivingThing_Core_Frameworks_Common_Web_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523986586579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ljzt.LCFCW.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(523986586579)
            
            //--TRIMMABLE-BOUNDARY-START(528281553875)
            static /*void */ LivingThing_Core_IOT_Automation_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281553875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xIHr.LCIA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(528281553875)
            
            //--TRIMMABLE-BOUNDARY-START(532576521171)
            static /*void */ LivingThing_Core_IOT_AutoTracks_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576521171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$rwTP.LCIAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(532576521171)
            
            //--TRIMMABLE-BOUNDARY-START(536871488467)
            static /*void */ LivingThing_Core_IOT_AutoTracks_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871488467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HTiB.LCIAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(536871488467)
            
            //--TRIMMABLE-BOUNDARY-START(541166455763)
            static /*void */ LivingThing_Core_IOT_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541166455763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ntej.LCIC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(541166455763)
            
            //--TRIMMABLE-BOUNDARY-START(545461423059)
            static /*void */ LivingThing_Core_IOT_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461423059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(545461423059)
            
            //--TRIMMABLE-BOUNDARY-START(549756390355)
            static /*void */ LivingThing_Core_IOT_Devices_All_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549756390355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Gfla.LCIDA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(549756390355)
            
            //--TRIMMABLE-BOUNDARY-START(554051357651)
            static /*void */ LivingThing_Core_IOT_Devices_Attendant_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051357651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MCAB.LCIDA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(554051357651)
            
            //--TRIMMABLE-BOUNDARY-START(558346324947)
            static /*void */ LivingThing_Core_IOT_Devices_AutoTracks_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558346324947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Gtji.LCIDA.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(558346324947)
            
            //--TRIMMABLE-BOUNDARY-START(562641292243)
            static /*void */ LivingThing_Core_IOT_Devices_Beacon_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562641292243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$jjuN.LCIDB.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(562641292243)
            
            //--TRIMMABLE-BOUNDARY-START(566936259539)
            static /*void */ LivingThing_Core_IOT_Devices_CowVitals_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566936259539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ezfM.LCIDC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(566936259539)
            
            //--TRIMMABLE-BOUNDARY-START(571231226835)
            static /*void */ LivingThing_Core_IOT_Devices_Custom_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571231226835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LiyH.LCIDC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(571231226835)
            
            //--TRIMMABLE-BOUNDARY-START(657130572755)
            static /*void */ LivingThing_Core_IOT_Devices_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657130572755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$NXre.LCID.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(657130572755)
            
            //--TRIMMABLE-BOUNDARY-START(575526194131)
            static /*void */ LivingThing_Core_IOT_Devices_EagleEye_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575526194131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$QPfZ.LCIDE.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(575526194131)
            
            //--TRIMMABLE-BOUNDARY-START(579821161427)
            static /*void */ LivingThing_Core_IOT_Devices_EventCounter_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579821161427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$WYlj.LCIDE.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(579821161427)
            
            //--TRIMMABLE-BOUNDARY-START(584116128723)
            static /*void */ LivingThing_Core_IOT_Devices_Forecourt_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584116128723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bweh.LCIDF.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(584116128723)
            
            //--TRIMMABLE-BOUNDARY-START(588411096019)
            static /*void */ LivingThing_Core_IOT_Devices_GasGauge_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588411096019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MmZc.LCIDG.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(588411096019)
            
            //--TRIMMABLE-BOUNDARY-START(592706063315)
            static /*void */ LivingThing_Core_IOT_Devices_Gateway_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592706063315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$NzWm.LCIDG.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(592706063315)
            
            //--TRIMMABLE-BOUNDARY-START(597001030611)
            static /*void */ LivingThing_Core_IOT_Devices_GreenHouseLogger_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597001030611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$CgOi.LCIDG.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(597001030611)
            
            //--TRIMMABLE-BOUNDARY-START(601295997907)
            static /*void */ LivingThing_Core_IOT_Devices_IRBlaster_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601295997907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HGGn.LCIDI.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(601295997907)
            
            //--TRIMMABLE-BOUNDARY-START(605590965203)
            static /*void */ LivingThing_Core_IOT_Devices_LEDMatrix_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605590965203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PkgL.LCIDL.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(605590965203)
            
            //--TRIMMABLE-BOUNDARY-START(609885932499)
            static /*void */ LivingThing_Core_IOT_Devices_LEDStrip_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609885932499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$CACm.LCIDL$1.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(609885932499)
            
            //--TRIMMABLE-BOUNDARY-START(614180899795)
            static /*void */ LivingThing_Core_IOT_Devices_LoadCell_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614180899795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LGQP.LCIDL.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(614180899795)
            
            //--TRIMMABLE-BOUNDARY-START(618475867091)
            static /*void */ LivingThing_Core_IOT_Devices_Logger_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618475867091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$IhzR.LCIDL$1.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(618475867091)
            
            //--TRIMMABLE-BOUNDARY-START(622770834387)
            static /*void */ LivingThing_Core_IOT_Devices_MultiVoltmeter_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(622770834387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ASam.LCIDM.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(622770834387)
            
            //--TRIMMABLE-BOUNDARY-START(627065801683)
            static /*void */ LivingThing_Core_IOT_Devices_PowerBeacon_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627065801683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PSrA.LCIDP.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(627065801683)
            
            //--TRIMMABLE-BOUNDARY-START(631360768979)
            static /*void */ LivingThing_Core_IOT_Devices_PowerHouse_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(631360768979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LnxK.LCIDP.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(631360768979)
            
            //--TRIMMABLE-BOUNDARY-START(635655736275)
            static /*void */ LivingThing_Core_IOT_Devices_Ranger_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635655736275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wDws.LCIDR.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(635655736275)
            
            //--TRIMMABLE-BOUNDARY-START(639950703571)
            static /*void */ LivingThing_Core_IOT_Devices_SenseAir_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639950703571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dRGn.LCIDS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(639950703571)
            
            //--TRIMMABLE-BOUNDARY-START(644245670867)
            static /*void */ LivingThing_Core_IOT_Devices_SerialBridge_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644245670867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(644245670867)
            
            //--TRIMMABLE-BOUNDARY-START(648540638163)
            static /*void */ LivingThing_Core_IOT_Devices_SerialBridgeChangeOver_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(648540638163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$gKEB.LCIDS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(648540638163)
            
            //--TRIMMABLE-BOUNDARY-START(652835605459)
            static /*void */ LivingThing_Core_IOT_Devices_SerialBridgeVoltmeter_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652835605459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$nGxw.LCIDS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(652835605459)
            
            //--TRIMMABLE-BOUNDARY-START(661425540051)
            static /*void */ LivingThing_Core_IOT_Devices_SmartPark_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661425540051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$pgHg.LCIDS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(661425540051)
            
            //--TRIMMABLE-BOUNDARY-START(670015474643)
            static /*void */ LivingThing_Core_IOT_Devices_SmartPoint_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670015474643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OHIm.LCIDS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(670015474643)
            
            //--TRIMMABLE-BOUNDARY-START(665720507347)
            static /*void */ LivingThing_Core_IOT_Devices_SmartPoint_ReMeterPlus_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(665720507347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OHIm.LCIDSR.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(665720507347)
            
            //--TRIMMABLE-BOUNDARY-START(674310441939)
            static /*void */ LivingThing_Core_IOT_Devices_TankTalks_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674310441939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MZKr.LCIDT.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(674310441939)
            
            //--TRIMMABLE-BOUNDARY-START(678605409235)
            static /*void */ LivingThing_Core_IOT_Devices_TemperatureHumidity_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678605409235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hmEn.LCIDT.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(678605409235)
            
            //--TRIMMABLE-BOUNDARY-START(682900376531)
            static /*void */ LivingThing_Core_IOT_Devices_Template_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(682900376531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ivxN.LCIDT.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(682900376531)
            
            //--TRIMMABLE-BOUNDARY-START(687195343827)
            static /*void */ LivingThing_Core_IOT_Devices_Terrameter_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687195343827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fsgt.LCIDT.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(687195343827)
            
            //--TRIMMABLE-BOUNDARY-START(691490311123)
            static /*void */ LivingThing_Core_IOT_Devices_TrafficControl_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(691490311123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$CFEL.LCIDT.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(691490311123)
            
            //--TRIMMABLE-BOUNDARY-START(695785278419)
            static /*void */ LivingThing_Core_IOT_Devices_WasteBin_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695785278419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBnD.LCIDW.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(695785278419)
            
            //--TRIMMABLE-BOUNDARY-START(700080245715)
            static /*void */ LivingThing_Core_IOT_EnergyMeter_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(700080245715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$eHSC.LCIEC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(700080245715)
            
            //--TRIMMABLE-BOUNDARY-START(704375213011)
            static /*void */ LivingThing_Core_IOT_EnergyMeter_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704375213011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uUnI.LCIEC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(704375213011)
            
            //--TRIMMABLE-BOUNDARY-START(708670180307)
            static /*void */ LivingThing_Core_IOT_Forecourt_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(708670180307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$qqCA.LCIFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(708670180307)
            
            //--TRIMMABLE-BOUNDARY-START(712965147603)
            static /*void */ LivingThing_Core_IOT_Forecourt_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712965147603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$qYTe.LCIFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(712965147603)
            
            //--TRIMMABLE-BOUNDARY-START(717260114899)
            static /*void */ LivingThing_Core_IOT_PowerHouse_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(717260114899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$qKfs.LCIPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(717260114899)
            
            //--TRIMMABLE-BOUNDARY-START(721555082195)
            static /*void */ LivingThing_Core_IOT_PowerHouse_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721555082195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mXnX.LCIPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(721555082195)
            
            //--TRIMMABLE-BOUNDARY-START(725850049491)
            static /*void */ LivingThing_Core_IOT_RMS_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(725850049491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$QoDz.LCIRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(725850049491)
            
            //--TRIMMABLE-BOUNDARY-START(730145016787)
            static /*void */ LivingThing_Core_IOT_RMS_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730145016787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OgAC.LCIRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(730145016787)
            
            //--TRIMMABLE-BOUNDARY-START(734439984083)
            static /*void */ LivingThing_Core_IOT_Services_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734439984083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mVyz.LCISC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(734439984083)
            
            //--TRIMMABLE-BOUNDARY-START(738734951379)
            static /*void */ LivingThing_Core_IOT_Services_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738734951379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$cDvV.LCIS.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(738734951379)
            
            //--TRIMMABLE-BOUNDARY-START(743029918675)
            static /*void */ LivingThing_Core_IOT_TankTalks_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(743029918675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zxUu.LCITC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(743029918675)
            
            //--TRIMMABLE-BOUNDARY-START(747324885971)
            static /*void */ LivingThing_Core_IOT_TankTalks_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747324885971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$cCKL.LCITC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(747324885971)
            
            //--TRIMMABLE-BOUNDARY-START(751619853267)
            static /*void */ LivingThing_Core_PayCowry_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751619853267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HSAN.LCPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(751619853267)
            
            //--TRIMMABLE-BOUNDARY-START(755914820563)
            static /*void */ LivingThing_Core_PayCowry_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755914820563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UlXD.LCPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(755914820563)
            
            //--TRIMMABLE-BOUNDARY-START(760209787859)
            static /*void */ LivingThing_Core_ProductsServices_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(760209787859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dgLE.LCPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(760209787859)
            
            //--TRIMMABLE-BOUNDARY-START(764504755155)
            static /*void */ LivingThing_Core_Shipping_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764504755155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$oUrI.LCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(764504755155)
            
            //--TRIMMABLE-BOUNDARY-START(768799722451)
            static /*void */ LivingThing_Core_Shipping_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768799722451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$YUlm.LCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(768799722451)
            
            //--TRIMMABLE-BOUNDARY-START(773094689747)
            static /*void */ LivingThing_Core_Uri_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773094689747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$cHnS.LCUC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(773094689747)
            
            //--TRIMMABLE-BOUNDARY-START(777389657043)
            static /*void */ LivingThing_Core_Wallet_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777389657043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$SeJP.LCWC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(777389657043)
            
            //--TRIMMABLE-BOUNDARY-START(781684624339)
            static /*void */ LivingThing_FluentUI_Core_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781684624339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(781684624339)
            
            //--TRIMMABLE-BOUNDARY-START(785979591635)
            static /*void */ LivingThing_TSCS_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(785979591635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$TLYN.LT.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(785979591635)
            
            //--TRIMMABLE-BOUNDARY-START(790274558931)
            static /*void */ LivingThing_VTU_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790274558931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ySWu.LVC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(790274558931)
            
            //--TRIMMABLE-BOUNDARY-START(794569526227)
            static /*void */ LivingThing_VTU_Common_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794569526227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mskq.LVC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(794569526227)
            
            //--TRIMMABLE-BOUNDARY-START(803159460819)
            static /*void */ Zoey_Client_ServiceRegistrar(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(803159460819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$NFcu.ZC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(803159460819)
            
            //--TRIMMABLE-BOUNDARY-START(798864493523)
            static /*void */ Register(/*string*/ fullName, /*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798864493523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(fullName)
                {
                    case "LivingThing.Core.Admin.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Admin_Client_Startup_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Authentication.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Authentication_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Authentication.Client.OAuth.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Authentication_Client_OAuth_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Authentication.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Authentication_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Bills.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Bills_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Bills.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Bills_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Account.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Account_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Account.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Account_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Article.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Article_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Article.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Article_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Barter.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Barter_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Barter.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Barter_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.BuyLink.Client.Admin.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_BuyLink_Client_Admin_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.BuyLink.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_BuyLink_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.BuyLink.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_BuyLink_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Calendar.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Calendar_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Calendar.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Calendar_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.CampaignBot.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_CampaignBot_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.CampaignBot.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_CampaignBot_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Chat.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Chat_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Chat.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Chat_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Church.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Church_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Church.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Church_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.DIPTV":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_DIPTV_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Dispatch.Client.Admin.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Dispatch_Client_Admin_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Dispatch.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Dispatch_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Dispatch.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Dispatch_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Dispatch.Schemes.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Dispatch_Schemes_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Election.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Election_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Election.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Election_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Forum.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Forum_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Forum.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Forum_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.FundMe.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_FundMe_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.FundMe.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_FundMe_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Games.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Games_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Games.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Games_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Gift.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Gift_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Gift.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Gift_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Group.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Group_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Group.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Group_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Group.User.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Group_User_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Group.User.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Group_User_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Handyman.Client.Admin.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Handyman_Client_Admin_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Handyman.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Handyman_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Handyman.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Handyman_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Job.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Job_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Job.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Job_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Journal.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Journal_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Journal.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Journal_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Loan.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Loan_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Loan.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Loan_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.LoanManagement.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_LoanManagement_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.LoanManagement.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_LoanManagement_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Make.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Make_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Make.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Make_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Market.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Market_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Market.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Market_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Market.StorePaymentTier.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Market_StorePaymentTier_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Media.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Media_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Media.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Media_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.NairalandForum.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_NairalandForum_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.NairalandForum.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_NairalandForum_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.NewsAggregator.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_NewsAggregator_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.NewsAggregator.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_NewsAggregator_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Note.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Note_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Note.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Note_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Organization.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Organization_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Organization.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Organization_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Pay.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Pay_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Pay.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Pay_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Reply.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Reply_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Reply.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Reply_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Review.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Review_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Review.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Review_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.School.Client.Admin.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_School_Client_Admin_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.School.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_School_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.School.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_School_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.SchoolPortal.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_SchoolPortal_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.SchoolPortal.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_SchoolPortal_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Short.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Short_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Short.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Short_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Sticky.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Sticky_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Sticky.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Sticky_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Thrift.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Thrift_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Thrift.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Thrift_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.TV.App.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_TV_App_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.TV.Client.Admin.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_TV_Admin_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.TV.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_TV_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.TV.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_TV_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.TV.Free":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_TV_Free_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Website.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Website_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Community.Website.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Community_Website_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.Application.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_Application_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.FluentUI.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_FluentUI_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_MarkdownPlus_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.PageBuilder.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_PageBuilder_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.Payment.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_Payment_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.Posts.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_Posts_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.SPA.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_SPA_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Client_TelegramMiniApp_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Application":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Application_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Client":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Connection":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Connection_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Hub":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Hub_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Local":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Local_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Mapping":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Mapping_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.MarkdownPlus":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_MarkdownPlus_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Mediator":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Mediator_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Messaging":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Messaging_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Models":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Models_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.MotionJPEG":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_MotionJPEG_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Payment":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Payment_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Posts":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Posts_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.RPC":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_RPC_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.RPC.Http":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_RPC_Http_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.RPC.WebSocket":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_RPC_WebSocket_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Wallet":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Wallet_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Frameworks.Common.Web":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Frameworks_Common_Web_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Automation":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Automation_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.AutoTracks.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_AutoTracks_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.AutoTracks.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_AutoTracks_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.All":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_All_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Attendant":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Attendant_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.AutoTracks":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_AutoTracks_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Beacon":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Beacon_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.CowVitals":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_CowVitals_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Custom":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Custom_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.EagleEye":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_EagleEye_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.EventCounter":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_EventCounter_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Forecourt":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Forecourt_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.GasGauge":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_GasGauge_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Gateway":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Gateway_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.GreenHouseLogger":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_GreenHouseLogger_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.IRBlaster":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_IRBlaster_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.LEDMatrix":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_LEDMatrix_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.LEDStrip":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_LEDStrip_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.LoadCell":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_LoadCell_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Logger":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Logger_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.MultiVoltmeter":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_MultiVoltmeter_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.PowerBeacon":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_PowerBeacon_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.PowerHouse":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_PowerHouse_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Ranger":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Ranger_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.SenseAir":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_SenseAir_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.SerialBridge":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_SerialBridge_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_SerialBridgeChangeOver_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_SerialBridgeVoltmeter_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.SmartPark":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_SmartPark_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.SmartPoint":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_SmartPoint_ServiceRegistrar(services, configuration, $.$clone(options));
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_SmartPoint_ReMeterPlus_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.TankTalks":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_TankTalks_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.TemperatureHumidity":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_TemperatureHumidity_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Template":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Template_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.Terrameter":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_Terrameter_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.TrafficControl":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_TrafficControl_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Devices.WasteBin":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Devices_WasteBin_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.EnergyMeter.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_EnergyMeter_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.EnergyMeter.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_EnergyMeter_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Forecourt.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Forecourt_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Forecourt.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Forecourt_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.PowerHouse.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_PowerHouse_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.PowerHouse.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_PowerHouse_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.RMS.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_RMS_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.RMS.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_RMS_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Services.Client":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Services_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.Services":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_Services_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.TankTalks.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_TankTalks_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.IOT.TankTalks.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_IOT_TankTalks_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.PayCowry.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_PayCowry_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.PayCowry.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_PayCowry_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.ProductsServices.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_ProductsServices_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Shipping.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Shipping_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Shipping.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Shipping_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Uri.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Uri_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.Core.Wallet.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_Core_Wallet_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.FluentUI.Core":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_FluentUI_Core_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.TSCS":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_TSCS_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.VTU.Client.Blazor":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_VTU_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "LivingThing.VTU.Common":
                    $.$RywK.LWCW.DynamicRegistrar.LivingThing_VTU_Common_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                    case "Zoey.Client":
                    $.$RywK.LWCW.DynamicRegistrar.Zoey_Client_ServiceRegistrar(services, configuration, $.$clone(options));
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(798864493523)
            
            static $h = 576467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295543763),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Admin_Client_Startup_ServiceRegistrar",
      "d": 576467,
      "h": 4295543763,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295543763),
//--TRIMMABLE-BOUNDARY-START(12885478355),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Authentication_Client_ServiceRegistrar",
      "d": 576467,
      "h": 12885478355,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885478355),
//--TRIMMABLE-BOUNDARY-START(8590511059),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Authentication_Client_OAuth_ServiceRegistrar",
      "d": 576467,
      "h": 8590511059,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590511059),
//--TRIMMABLE-BOUNDARY-START(17180445651),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Authentication_Common_ServiceRegistrar",
      "d": 576467,
      "h": 17180445651,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180445651),
//--TRIMMABLE-BOUNDARY-START(21475412947),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Bills_Client_ServiceRegistrar",
      "d": 576467,
      "h": 21475412947,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475412947),
//--TRIMMABLE-BOUNDARY-START(25770380243),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Bills_Common_ServiceRegistrar",
      "d": 576467,
      "h": 25770380243,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770380243),
//--TRIMMABLE-BOUNDARY-START(30065347539),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Account_Client_ServiceRegistrar",
      "d": 576467,
      "h": 30065347539,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065347539),
//--TRIMMABLE-BOUNDARY-START(34360314835),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Account_Common_ServiceRegistrar",
      "d": 576467,
      "h": 34360314835,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360314835),
//--TRIMMABLE-BOUNDARY-START(38655282131),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Article_Client_ServiceRegistrar",
      "d": 576467,
      "h": 38655282131,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655282131),
//--TRIMMABLE-BOUNDARY-START(42950249427),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Article_Common_ServiceRegistrar",
      "d": 576467,
      "h": 42950249427,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950249427),
//--TRIMMABLE-BOUNDARY-START(47245216723),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Barter_Client_ServiceRegistrar",
      "d": 576467,
      "h": 47245216723,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47245216723),
//--TRIMMABLE-BOUNDARY-START(51540184019),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Barter_Common_ServiceRegistrar",
      "d": 576467,
      "h": 51540184019,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540184019),
//--TRIMMABLE-BOUNDARY-START(55835151315),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_BuyLink_Client_Admin_ServiceRegistrar",
      "d": 576467,
      "h": 55835151315,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835151315),
//--TRIMMABLE-BOUNDARY-START(60130118611),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_BuyLink_Client_ServiceRegistrar",
      "d": 576467,
      "h": 60130118611,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(60130118611),
//--TRIMMABLE-BOUNDARY-START(64425085907),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_BuyLink_Common_ServiceRegistrar",
      "d": 576467,
      "h": 64425085907,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64425085907),
//--TRIMMABLE-BOUNDARY-START(68720053203),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Calendar_Client_ServiceRegistrar",
      "d": 576467,
      "h": 68720053203,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68720053203),
//--TRIMMABLE-BOUNDARY-START(73015020499),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Calendar_Common_ServiceRegistrar",
      "d": 576467,
      "h": 73015020499,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73015020499),
//--TRIMMABLE-BOUNDARY-START(77309987795),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_CampaignBot_Client_ServiceRegistrar",
      "d": 576467,
      "h": 77309987795,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77309987795),
//--TRIMMABLE-BOUNDARY-START(81604955091),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_CampaignBot_Common_ServiceRegistrar",
      "d": 576467,
      "h": 81604955091,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(81604955091),
//--TRIMMABLE-BOUNDARY-START(85899922387),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Chat_Client_ServiceRegistrar",
      "d": 576467,
      "h": 85899922387,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85899922387),
//--TRIMMABLE-BOUNDARY-START(90194889683),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Chat_Common_ServiceRegistrar",
      "d": 576467,
      "h": 90194889683,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90194889683),
//--TRIMMABLE-BOUNDARY-START(94489856979),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Church_Client_ServiceRegistrar",
      "d": 576467,
      "h": 94489856979,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(94489856979),
//--TRIMMABLE-BOUNDARY-START(98784824275),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Church_Common_ServiceRegistrar",
      "d": 576467,
      "h": 98784824275,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(98784824275),
//--TRIMMABLE-BOUNDARY-START(103079791571),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Client_ServiceRegistrar",
      "d": 576467,
      "h": 103079791571,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103079791571),
//--TRIMMABLE-BOUNDARY-START(107374758867),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Common_ServiceRegistrar",
      "d": 576467,
      "h": 107374758867,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107374758867),
//--TRIMMABLE-BOUNDARY-START(111669726163),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_DIPTV_ServiceRegistrar",
      "d": 576467,
      "h": 111669726163,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(111669726163),
//--TRIMMABLE-BOUNDARY-START(115964693459),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Dispatch_Client_Admin_ServiceRegistrar",
      "d": 576467,
      "h": 115964693459,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(115964693459),
//--TRIMMABLE-BOUNDARY-START(120259660755),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Dispatch_Client_ServiceRegistrar",
      "d": 576467,
      "h": 120259660755,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(120259660755),
//--TRIMMABLE-BOUNDARY-START(124554628051),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Dispatch_Common_ServiceRegistrar",
      "d": 576467,
      "h": 124554628051,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(124554628051),
//--TRIMMABLE-BOUNDARY-START(128849595347),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Dispatch_Schemes_ServiceRegistrar",
      "d": 576467,
      "h": 128849595347,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(128849595347),
//--TRIMMABLE-BOUNDARY-START(133144562643),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Election_Client_ServiceRegistrar",
      "d": 576467,
      "h": 133144562643,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(133144562643),
//--TRIMMABLE-BOUNDARY-START(137439529939),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Election_Common_ServiceRegistrar",
      "d": 576467,
      "h": 137439529939,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(137439529939),
//--TRIMMABLE-BOUNDARY-START(141734497235),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Forum_Client_ServiceRegistrar",
      "d": 576467,
      "h": 141734497235,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(141734497235),
//--TRIMMABLE-BOUNDARY-START(146029464531),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Forum_Common_ServiceRegistrar",
      "d": 576467,
      "h": 146029464531,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(146029464531),
//--TRIMMABLE-BOUNDARY-START(150324431827),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_FundMe_Client_ServiceRegistrar",
      "d": 576467,
      "h": 150324431827,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(150324431827),
//--TRIMMABLE-BOUNDARY-START(154619399123),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_FundMe_Common_ServiceRegistrar",
      "d": 576467,
      "h": 154619399123,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(154619399123),
//--TRIMMABLE-BOUNDARY-START(158914366419),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Games_Client_ServiceRegistrar",
      "d": 576467,
      "h": 158914366419,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(158914366419),
//--TRIMMABLE-BOUNDARY-START(163209333715),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Games_Common_ServiceRegistrar",
      "d": 576467,
      "h": 163209333715,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(163209333715),
//--TRIMMABLE-BOUNDARY-START(167504301011),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Gift_Client_ServiceRegistrar",
      "d": 576467,
      "h": 167504301011,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167504301011),
//--TRIMMABLE-BOUNDARY-START(171799268307),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Gift_Common_ServiceRegistrar",
      "d": 576467,
      "h": 171799268307,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(171799268307),
//--TRIMMABLE-BOUNDARY-START(176094235603),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Group_Client_ServiceRegistrar",
      "d": 576467,
      "h": 176094235603,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(176094235603),
//--TRIMMABLE-BOUNDARY-START(180389202899),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Group_Common_ServiceRegistrar",
      "d": 576467,
      "h": 180389202899,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(180389202899),
//--TRIMMABLE-BOUNDARY-START(184684170195),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Group_User_Client_ServiceRegistrar",
      "d": 576467,
      "h": 184684170195,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(184684170195),
//--TRIMMABLE-BOUNDARY-START(188979137491),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Group_User_Common_ServiceRegistrar",
      "d": 576467,
      "h": 188979137491,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(188979137491),
//--TRIMMABLE-BOUNDARY-START(193274104787),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Handyman_Client_Admin_ServiceRegistrar",
      "d": 576467,
      "h": 193274104787,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(193274104787),
//--TRIMMABLE-BOUNDARY-START(197569072083),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Handyman_Client_ServiceRegistrar",
      "d": 576467,
      "h": 197569072083,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(197569072083),
//--TRIMMABLE-BOUNDARY-START(201864039379),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Handyman_Common_ServiceRegistrar",
      "d": 576467,
      "h": 201864039379,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(201864039379),
//--TRIMMABLE-BOUNDARY-START(206159006675),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Job_Client_ServiceRegistrar",
      "d": 576467,
      "h": 206159006675,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(206159006675),
//--TRIMMABLE-BOUNDARY-START(210453973971),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Job_Common_ServiceRegistrar",
      "d": 576467,
      "h": 210453973971,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(210453973971),
//--TRIMMABLE-BOUNDARY-START(214748941267),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Journal_Client_ServiceRegistrar",
      "d": 576467,
      "h": 214748941267,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(214748941267),
//--TRIMMABLE-BOUNDARY-START(219043908563),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Journal_Common_ServiceRegistrar",
      "d": 576467,
      "h": 219043908563,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(219043908563),
//--TRIMMABLE-BOUNDARY-START(223338875859),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Loan_Client_ServiceRegistrar",
      "d": 576467,
      "h": 223338875859,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(223338875859),
//--TRIMMABLE-BOUNDARY-START(227633843155),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Loan_Common_ServiceRegistrar",
      "d": 576467,
      "h": 227633843155,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(227633843155),
//--TRIMMABLE-BOUNDARY-START(231928810451),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_LoanManagement_Client_ServiceRegistrar",
      "d": 576467,
      "h": 231928810451,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(231928810451),
//--TRIMMABLE-BOUNDARY-START(236223777747),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_LoanManagement_Common_ServiceRegistrar",
      "d": 576467,
      "h": 236223777747,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(236223777747),
//--TRIMMABLE-BOUNDARY-START(240518745043),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Make_Client_ServiceRegistrar",
      "d": 576467,
      "h": 240518745043,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(240518745043),
//--TRIMMABLE-BOUNDARY-START(244813712339),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Make_Common_ServiceRegistrar",
      "d": 576467,
      "h": 244813712339,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(244813712339),
//--TRIMMABLE-BOUNDARY-START(249108679635),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Market_Client_ServiceRegistrar",
      "d": 576467,
      "h": 249108679635,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(249108679635),
//--TRIMMABLE-BOUNDARY-START(253403646931),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Market_Common_ServiceRegistrar",
      "d": 576467,
      "h": 253403646931,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(253403646931),
//--TRIMMABLE-BOUNDARY-START(257698614227),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Market_StorePaymentTier_ServiceRegistrar",
      "d": 576467,
      "h": 257698614227,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(257698614227),
//--TRIMMABLE-BOUNDARY-START(261993581523),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Media_Client_ServiceRegistrar",
      "d": 576467,
      "h": 261993581523,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(261993581523),
//--TRIMMABLE-BOUNDARY-START(266288548819),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Media_Common_ServiceRegistrar",
      "d": 576467,
      "h": 266288548819,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(266288548819),
//--TRIMMABLE-BOUNDARY-START(270583516115),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_NairalandForum_Client_ServiceRegistrar",
      "d": 576467,
      "h": 270583516115,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(270583516115),
//--TRIMMABLE-BOUNDARY-START(274878483411),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_NairalandForum_Common_ServiceRegistrar",
      "d": 576467,
      "h": 274878483411,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(274878483411),
//--TRIMMABLE-BOUNDARY-START(279173450707),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_NewsAggregator_Client_ServiceRegistrar",
      "d": 576467,
      "h": 279173450707,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(279173450707),
//--TRIMMABLE-BOUNDARY-START(283468418003),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_NewsAggregator_Common_ServiceRegistrar",
      "d": 576467,
      "h": 283468418003,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(283468418003),
//--TRIMMABLE-BOUNDARY-START(287763385299),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Note_Client_ServiceRegistrar",
      "d": 576467,
      "h": 287763385299,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(287763385299),
//--TRIMMABLE-BOUNDARY-START(292058352595),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Note_Common_ServiceRegistrar",
      "d": 576467,
      "h": 292058352595,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(292058352595),
//--TRIMMABLE-BOUNDARY-START(296353319891),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Organization_Client_ServiceRegistrar",
      "d": 576467,
      "h": 296353319891,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(296353319891),
//--TRIMMABLE-BOUNDARY-START(300648287187),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Organization_Common_ServiceRegistrar",
      "d": 576467,
      "h": 300648287187,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(300648287187),
//--TRIMMABLE-BOUNDARY-START(304943254483),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Pay_Client_ServiceRegistrar",
      "d": 576467,
      "h": 304943254483,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(304943254483),
//--TRIMMABLE-BOUNDARY-START(309238221779),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Pay_Common_ServiceRegistrar",
      "d": 576467,
      "h": 309238221779,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(309238221779),
//--TRIMMABLE-BOUNDARY-START(313533189075),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Reply_Client_ServiceRegistrar",
      "d": 576467,
      "h": 313533189075,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(313533189075),
//--TRIMMABLE-BOUNDARY-START(317828156371),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Reply_Common_ServiceRegistrar",
      "d": 576467,
      "h": 317828156371,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(317828156371),
//--TRIMMABLE-BOUNDARY-START(322123123667),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Review_Client_ServiceRegistrar",
      "d": 576467,
      "h": 322123123667,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(322123123667),
//--TRIMMABLE-BOUNDARY-START(326418090963),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Review_Common_ServiceRegistrar",
      "d": 576467,
      "h": 326418090963,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(326418090963),
//--TRIMMABLE-BOUNDARY-START(330713058259),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_School_Client_Admin_ServiceRegistrar",
      "d": 576467,
      "h": 330713058259,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(330713058259),
//--TRIMMABLE-BOUNDARY-START(335008025555),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_School_Client_ServiceRegistrar",
      "d": 576467,
      "h": 335008025555,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(335008025555),
//--TRIMMABLE-BOUNDARY-START(339302992851),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_School_Common_ServiceRegistrar",
      "d": 576467,
      "h": 339302992851,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(339302992851),
//--TRIMMABLE-BOUNDARY-START(343597960147),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_SchoolPortal_Client_ServiceRegistrar",
      "d": 576467,
      "h": 343597960147,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(343597960147),
//--TRIMMABLE-BOUNDARY-START(347892927443),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_SchoolPortal_Common_ServiceRegistrar",
      "d": 576467,
      "h": 347892927443,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(347892927443),
//--TRIMMABLE-BOUNDARY-START(352187894739),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Short_Client_ServiceRegistrar",
      "d": 576467,
      "h": 352187894739,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(352187894739),
//--TRIMMABLE-BOUNDARY-START(356482862035),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Short_Common_ServiceRegistrar",
      "d": 576467,
      "h": 356482862035,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(356482862035),
//--TRIMMABLE-BOUNDARY-START(360777829331),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Sticky_Client_ServiceRegistrar",
      "d": 576467,
      "h": 360777829331,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(360777829331),
//--TRIMMABLE-BOUNDARY-START(365072796627),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Sticky_Common_ServiceRegistrar",
      "d": 576467,
      "h": 365072796627,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(365072796627),
//--TRIMMABLE-BOUNDARY-START(369367763923),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Thrift_Client_ServiceRegistrar",
      "d": 576467,
      "h": 369367763923,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(369367763923),
//--TRIMMABLE-BOUNDARY-START(373662731219),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Thrift_Common_ServiceRegistrar",
      "d": 576467,
      "h": 373662731219,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(373662731219),
//--TRIMMABLE-BOUNDARY-START(382252665811),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_TV_App_ServiceRegistrar",
      "d": 576467,
      "h": 382252665811,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(382252665811),
//--TRIMMABLE-BOUNDARY-START(377957698515),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_TV_Admin_ServiceRegistrar",
      "d": 576467,
      "h": 377957698515,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(377957698515),
//--TRIMMABLE-BOUNDARY-START(386547633107),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_TV_Client_ServiceRegistrar",
      "d": 576467,
      "h": 386547633107,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(386547633107),
//--TRIMMABLE-BOUNDARY-START(390842600403),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_TV_Common_ServiceRegistrar",
      "d": 576467,
      "h": 390842600403,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(390842600403),
//--TRIMMABLE-BOUNDARY-START(395137567699),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_TV_Free_ServiceRegistrar",
      "d": 576467,
      "h": 395137567699,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(395137567699),
//--TRIMMABLE-BOUNDARY-START(399432534995),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Website_Client_ServiceRegistrar",
      "d": 576467,
      "h": 399432534995,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(399432534995),
//--TRIMMABLE-BOUNDARY-START(403727502291),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Community_Website_Common_ServiceRegistrar",
      "d": 576467,
      "h": 403727502291,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(403727502291),
//--TRIMMABLE-BOUNDARY-START(408022469587),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_Application_ServiceRegistrar",
      "d": 576467,
      "h": 408022469587,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(408022469587),
//--TRIMMABLE-BOUNDARY-START(433792273363),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_ServiceRegistrar",
      "d": 576467,
      "h": 433792273363,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(433792273363),
//--TRIMMABLE-BOUNDARY-START(412317436883),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_FluentUI_ServiceRegistrar",
      "d": 576467,
      "h": 412317436883,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(412317436883),
//--TRIMMABLE-BOUNDARY-START(416612404179),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_MarkdownPlus_ServiceRegistrar",
      "d": 576467,
      "h": 416612404179,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(416612404179),
//--TRIMMABLE-BOUNDARY-START(420907371475),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_PageBuilder_ServiceRegistrar",
      "d": 576467,
      "h": 420907371475,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(420907371475),
//--TRIMMABLE-BOUNDARY-START(425202338771),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_Payment_ServiceRegistrar",
      "d": 576467,
      "h": 425202338771,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(425202338771),
//--TRIMMABLE-BOUNDARY-START(429497306067),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_Posts_ServiceRegistrar",
      "d": 576467,
      "h": 429497306067,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(429497306067),
//--TRIMMABLE-BOUNDARY-START(438087240659),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_SPA_ServiceRegistrar",
      "d": 576467,
      "h": 438087240659,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(438087240659),
//--TRIMMABLE-BOUNDARY-START(442382207955),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Client_TelegramMiniApp_ServiceRegistrar",
      "d": 576467,
      "h": 442382207955,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(442382207955),
//--TRIMMABLE-BOUNDARY-START(446677175251),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Application_ServiceRegistrar",
      "d": 576467,
      "h": 446677175251,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(446677175251),
//--TRIMMABLE-BOUNDARY-START(450972142547),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Client_ServiceRegistrar",
      "d": 576467,
      "h": 450972142547,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(450972142547),
//--TRIMMABLE-BOUNDARY-START(455267109843),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Connection_ServiceRegistrar",
      "d": 576467,
      "h": 455267109843,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(455267109843),
//--TRIMMABLE-BOUNDARY-START(515396651987),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_ServiceRegistrar",
      "d": 576467,
      "h": 515396651987,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(515396651987),
//--TRIMMABLE-BOUNDARY-START(459562077139),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Hub_ServiceRegistrar",
      "d": 576467,
      "h": 459562077139,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(459562077139),
//--TRIMMABLE-BOUNDARY-START(463857044435),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Local_ServiceRegistrar",
      "d": 576467,
      "h": 463857044435,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(463857044435),
//--TRIMMABLE-BOUNDARY-START(468152011731),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Mapping_ServiceRegistrar",
      "d": 576467,
      "h": 468152011731,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(468152011731),
//--TRIMMABLE-BOUNDARY-START(472446979027),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_MarkdownPlus_ServiceRegistrar",
      "d": 576467,
      "h": 472446979027,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(472446979027),
//--TRIMMABLE-BOUNDARY-START(476741946323),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Mediator_ServiceRegistrar",
      "d": 576467,
      "h": 476741946323,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(476741946323),
//--TRIMMABLE-BOUNDARY-START(481036913619),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Messaging_ServiceRegistrar",
      "d": 576467,
      "h": 481036913619,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(481036913619),
//--TRIMMABLE-BOUNDARY-START(485331880915),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Models_ServiceRegistrar",
      "d": 576467,
      "h": 485331880915,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(485331880915),
//--TRIMMABLE-BOUNDARY-START(489626848211),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_MotionJPEG_ServiceRegistrar",
      "d": 576467,
      "h": 489626848211,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(489626848211),
//--TRIMMABLE-BOUNDARY-START(493921815507),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Payment_ServiceRegistrar",
      "d": 576467,
      "h": 493921815507,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(493921815507),
//--TRIMMABLE-BOUNDARY-START(498216782803),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Posts_ServiceRegistrar",
      "d": 576467,
      "h": 498216782803,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(498216782803),
//--TRIMMABLE-BOUNDARY-START(506806717395),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_RPC_ServiceRegistrar",
      "d": 576467,
      "h": 506806717395,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(506806717395),
//--TRIMMABLE-BOUNDARY-START(502511750099),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_RPC_Http_ServiceRegistrar",
      "d": 576467,
      "h": 502511750099,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(502511750099),
//--TRIMMABLE-BOUNDARY-START(511101684691),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_RPC_WebSocket_ServiceRegistrar",
      "d": 576467,
      "h": 511101684691,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(511101684691),
//--TRIMMABLE-BOUNDARY-START(519691619283),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Wallet_ServiceRegistrar",
      "d": 576467,
      "h": 519691619283,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(519691619283),
//--TRIMMABLE-BOUNDARY-START(523986586579),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Frameworks_Common_Web_ServiceRegistrar",
      "d": 576467,
      "h": 523986586579,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(523986586579),
//--TRIMMABLE-BOUNDARY-START(528281553875),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Automation_ServiceRegistrar",
      "d": 576467,
      "h": 528281553875,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(528281553875),
//--TRIMMABLE-BOUNDARY-START(532576521171),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_AutoTracks_Client_ServiceRegistrar",
      "d": 576467,
      "h": 532576521171,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(532576521171),
//--TRIMMABLE-BOUNDARY-START(536871488467),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_AutoTracks_Common_ServiceRegistrar",
      "d": 576467,
      "h": 536871488467,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(536871488467),
//--TRIMMABLE-BOUNDARY-START(541166455763),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Client_ServiceRegistrar",
      "d": 576467,
      "h": 541166455763,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(541166455763),
//--TRIMMABLE-BOUNDARY-START(545461423059),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Common_ServiceRegistrar",
      "d": 576467,
      "h": 545461423059,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(545461423059),
//--TRIMMABLE-BOUNDARY-START(549756390355),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_All_ServiceRegistrar",
      "d": 576467,
      "h": 549756390355,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(549756390355),
//--TRIMMABLE-BOUNDARY-START(554051357651),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Attendant_ServiceRegistrar",
      "d": 576467,
      "h": 554051357651,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(554051357651),
//--TRIMMABLE-BOUNDARY-START(558346324947),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_AutoTracks_ServiceRegistrar",
      "d": 576467,
      "h": 558346324947,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(558346324947),
//--TRIMMABLE-BOUNDARY-START(562641292243),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Beacon_ServiceRegistrar",
      "d": 576467,
      "h": 562641292243,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(562641292243),
//--TRIMMABLE-BOUNDARY-START(566936259539),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_CowVitals_ServiceRegistrar",
      "d": 576467,
      "h": 566936259539,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(566936259539),
//--TRIMMABLE-BOUNDARY-START(571231226835),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Custom_ServiceRegistrar",
      "d": 576467,
      "h": 571231226835,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(571231226835),
//--TRIMMABLE-BOUNDARY-START(657130572755),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_ServiceRegistrar",
      "d": 576467,
      "h": 657130572755,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(657130572755),
//--TRIMMABLE-BOUNDARY-START(575526194131),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_EagleEye_ServiceRegistrar",
      "d": 576467,
      "h": 575526194131,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(575526194131),
//--TRIMMABLE-BOUNDARY-START(579821161427),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_EventCounter_ServiceRegistrar",
      "d": 576467,
      "h": 579821161427,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(579821161427),
//--TRIMMABLE-BOUNDARY-START(584116128723),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Forecourt_ServiceRegistrar",
      "d": 576467,
      "h": 584116128723,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(584116128723),
//--TRIMMABLE-BOUNDARY-START(588411096019),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_GasGauge_ServiceRegistrar",
      "d": 576467,
      "h": 588411096019,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(588411096019),
//--TRIMMABLE-BOUNDARY-START(592706063315),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Gateway_ServiceRegistrar",
      "d": 576467,
      "h": 592706063315,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(592706063315),
//--TRIMMABLE-BOUNDARY-START(597001030611),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_GreenHouseLogger_ServiceRegistrar",
      "d": 576467,
      "h": 597001030611,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(597001030611),
//--TRIMMABLE-BOUNDARY-START(601295997907),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_IRBlaster_ServiceRegistrar",
      "d": 576467,
      "h": 601295997907,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(601295997907),
//--TRIMMABLE-BOUNDARY-START(605590965203),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_LEDMatrix_ServiceRegistrar",
      "d": 576467,
      "h": 605590965203,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(605590965203),
//--TRIMMABLE-BOUNDARY-START(609885932499),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_LEDStrip_ServiceRegistrar",
      "d": 576467,
      "h": 609885932499,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(609885932499),
//--TRIMMABLE-BOUNDARY-START(614180899795),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_LoadCell_ServiceRegistrar",
      "d": 576467,
      "h": 614180899795,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(614180899795),
//--TRIMMABLE-BOUNDARY-START(618475867091),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Logger_ServiceRegistrar",
      "d": 576467,
      "h": 618475867091,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(618475867091),
//--TRIMMABLE-BOUNDARY-START(622770834387),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_MultiVoltmeter_ServiceRegistrar",
      "d": 576467,
      "h": 622770834387,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(622770834387),
//--TRIMMABLE-BOUNDARY-START(627065801683),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_PowerBeacon_ServiceRegistrar",
      "d": 576467,
      "h": 627065801683,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(627065801683),
//--TRIMMABLE-BOUNDARY-START(631360768979),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_PowerHouse_ServiceRegistrar",
      "d": 576467,
      "h": 631360768979,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(631360768979),
//--TRIMMABLE-BOUNDARY-START(635655736275),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Ranger_ServiceRegistrar",
      "d": 576467,
      "h": 635655736275,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(635655736275),
//--TRIMMABLE-BOUNDARY-START(639950703571),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_SenseAir_ServiceRegistrar",
      "d": 576467,
      "h": 639950703571,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(639950703571),
//--TRIMMABLE-BOUNDARY-START(644245670867),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_SerialBridge_ServiceRegistrar",
      "d": 576467,
      "h": 644245670867,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(644245670867),
//--TRIMMABLE-BOUNDARY-START(648540638163),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_SerialBridgeChangeOver_ServiceRegistrar",
      "d": 576467,
      "h": 648540638163,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(648540638163),
//--TRIMMABLE-BOUNDARY-START(652835605459),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_SerialBridgeVoltmeter_ServiceRegistrar",
      "d": 576467,
      "h": 652835605459,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(652835605459),
//--TRIMMABLE-BOUNDARY-START(661425540051),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_SmartPark_ServiceRegistrar",
      "d": 576467,
      "h": 661425540051,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(661425540051),
//--TRIMMABLE-BOUNDARY-START(670015474643),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_SmartPoint_ServiceRegistrar",
      "d": 576467,
      "h": 670015474643,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(670015474643),
//--TRIMMABLE-BOUNDARY-START(665720507347),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_SmartPoint_ReMeterPlus_ServiceRegistrar",
      "d": 576467,
      "h": 665720507347,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(665720507347),
//--TRIMMABLE-BOUNDARY-START(674310441939),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_TankTalks_ServiceRegistrar",
      "d": 576467,
      "h": 674310441939,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(674310441939),
//--TRIMMABLE-BOUNDARY-START(678605409235),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_TemperatureHumidity_ServiceRegistrar",
      "d": 576467,
      "h": 678605409235,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(678605409235),
//--TRIMMABLE-BOUNDARY-START(682900376531),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Template_ServiceRegistrar",
      "d": 576467,
      "h": 682900376531,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(682900376531),
//--TRIMMABLE-BOUNDARY-START(687195343827),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_Terrameter_ServiceRegistrar",
      "d": 576467,
      "h": 687195343827,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(687195343827),
//--TRIMMABLE-BOUNDARY-START(691490311123),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_TrafficControl_ServiceRegistrar",
      "d": 576467,
      "h": 691490311123,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(691490311123),
//--TRIMMABLE-BOUNDARY-START(695785278419),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Devices_WasteBin_ServiceRegistrar",
      "d": 576467,
      "h": 695785278419,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(695785278419),
//--TRIMMABLE-BOUNDARY-START(700080245715),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_EnergyMeter_Client_ServiceRegistrar",
      "d": 576467,
      "h": 700080245715,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(700080245715),
//--TRIMMABLE-BOUNDARY-START(704375213011),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_EnergyMeter_Common_ServiceRegistrar",
      "d": 576467,
      "h": 704375213011,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(704375213011),
//--TRIMMABLE-BOUNDARY-START(708670180307),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Forecourt_Client_ServiceRegistrar",
      "d": 576467,
      "h": 708670180307,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(708670180307),
//--TRIMMABLE-BOUNDARY-START(712965147603),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Forecourt_Common_ServiceRegistrar",
      "d": 576467,
      "h": 712965147603,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(712965147603),
//--TRIMMABLE-BOUNDARY-START(717260114899),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_PowerHouse_Client_ServiceRegistrar",
      "d": 576467,
      "h": 717260114899,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(717260114899),
//--TRIMMABLE-BOUNDARY-START(721555082195),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_PowerHouse_Common_ServiceRegistrar",
      "d": 576467,
      "h": 721555082195,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(721555082195),
//--TRIMMABLE-BOUNDARY-START(725850049491),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_RMS_Client_ServiceRegistrar",
      "d": 576467,
      "h": 725850049491,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(725850049491),
//--TRIMMABLE-BOUNDARY-START(730145016787),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_RMS_Common_ServiceRegistrar",
      "d": 576467,
      "h": 730145016787,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(730145016787),
//--TRIMMABLE-BOUNDARY-START(734439984083),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Services_Client_ServiceRegistrar",
      "d": 576467,
      "h": 734439984083,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(734439984083),
//--TRIMMABLE-BOUNDARY-START(738734951379),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_Services_ServiceRegistrar",
      "d": 576467,
      "h": 738734951379,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(738734951379),
//--TRIMMABLE-BOUNDARY-START(743029918675),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_TankTalks_Client_ServiceRegistrar",
      "d": 576467,
      "h": 743029918675,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(743029918675),
//--TRIMMABLE-BOUNDARY-START(747324885971),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_IOT_TankTalks_Common_ServiceRegistrar",
      "d": 576467,
      "h": 747324885971,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(747324885971),
//--TRIMMABLE-BOUNDARY-START(751619853267),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_PayCowry_Client_ServiceRegistrar",
      "d": 576467,
      "h": 751619853267,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(751619853267),
//--TRIMMABLE-BOUNDARY-START(755914820563),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_PayCowry_Common_ServiceRegistrar",
      "d": 576467,
      "h": 755914820563,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(755914820563),
//--TRIMMABLE-BOUNDARY-START(760209787859),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_ProductsServices_Client_ServiceRegistrar",
      "d": 576467,
      "h": 760209787859,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(760209787859),
//--TRIMMABLE-BOUNDARY-START(764504755155),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Shipping_Client_ServiceRegistrar",
      "d": 576467,
      "h": 764504755155,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(764504755155),
//--TRIMMABLE-BOUNDARY-START(768799722451),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Shipping_Common_ServiceRegistrar",
      "d": 576467,
      "h": 768799722451,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(768799722451),
//--TRIMMABLE-BOUNDARY-START(773094689747),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Uri_Client_ServiceRegistrar",
      "d": 576467,
      "h": 773094689747,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(773094689747),
//--TRIMMABLE-BOUNDARY-START(777389657043),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_Core_Wallet_Client_ServiceRegistrar",
      "d": 576467,
      "h": 777389657043,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(777389657043),
//--TRIMMABLE-BOUNDARY-START(781684624339),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_FluentUI_Core_ServiceRegistrar",
      "d": 576467,
      "h": 781684624339,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(781684624339),
//--TRIMMABLE-BOUNDARY-START(785979591635),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_TSCS_ServiceRegistrar",
      "d": 576467,
      "h": 785979591635,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(785979591635),
//--TRIMMABLE-BOUNDARY-START(790274558931),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_VTU_Client_ServiceRegistrar",
      "d": 576467,
      "h": 790274558931,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(790274558931),
//--TRIMMABLE-BOUNDARY-START(794569526227),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LivingThing_VTU_Common_ServiceRegistrar",
      "d": 576467,
      "h": 794569526227,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(794569526227),
//--TRIMMABLE-BOUNDARY-START(803159460819),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Zoey_Client_ServiceRegistrar",
      "d": 576467,
      "h": 803159460819,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(803159460819),
//--TRIMMABLE-BOUNDARY-START(798864493523),
    {
      "r": 65537,
      "p": [
        {
          "n": "fullName",
          "p": 1310721
        },
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Register",
      "d": 576467,
      "h": 798864493523,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(798864493523)
  ],
  "h": 576467,
  "a": [
    {
      "t": 510931,
      "c": 4295478227
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.DynamicRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}DynamicRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(576467)
        
        

        //--TRIMMABLE-BOUNDARY-START(1362899)
        $asm.$cls(`$RywK.LWCW.WebAssemblyJavascript`, ($self) => class WebAssemblyJavascript extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181232083)
            static /*string */ GetStartupParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181232083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$RywK.LWCW.WebAssemblyJavascript.__signature_GetStartupParameter_1310674786 === null)
                {
                    $.$RywK.LWCW.WebAssemblyJavascript.__signature_GetStartupParameter_1310674786 = $.$srij.SRIJ.JSFunctionBinding.BindJSFunction("globalThis.startupParameters", null, $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerType), [$.$srij.SRIJ.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, $.$clone(____arg_exception_native), $.$clone(____arg_return_native));
                    }
                    __retVal_native.ToManaged$37($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.S.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.SRIJ.JSFunctionBinding.InvokeJS($.$RywK.LWCW.WebAssemblyJavascript.__signature_GetStartupParameter_1310674786, __arguments_buffer);
                    return __arguments_buffer._reference.GetAt(1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181232083)
            
            //--TRIMMABLE-BOUNDARY-START(4296330195)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetStartupParameter_1310674786 = null;
            //--TRIMMABLE-BOUNDARY-END(4296330195)
            
            //--TRIMMABLE-BOUNDARY-START(21476199379)
            static /*void */ WasmReady()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476199379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$RywK.LWCW.WebAssemblyJavascript.__signature_WasmReady_19325221 === null)
                {
                    $.$RywK.LWCW.WebAssemblyJavascript.__signature_WasmReady_19325221 = $.$srij.SRIJ.JSFunctionBinding.BindJSFunction("globalThis.wasmReady", null, $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerType), [$.$srij.SRIJ.JSMarshalerType.Discard], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __InvokeJSFunction.call(this, $.$clone(____arg_exception_native), $.$clone(____arg_return_native));
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    $.$srij.SRIJ.JSFunctionBinding.InvokeJS($.$RywK.LWCW.WebAssemblyJavascript.__signature_WasmReady_19325221, $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476199379)
            
            //--TRIMMABLE-BOUNDARY-START(8591297491)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_WasmReady_19325221 = null;
            //--TRIMMABLE-BOUNDARY-END(8591297491)
            
            //--TRIMMABLE-BOUNDARY-START(12886264787)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886264787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886264787)
            
            //--TRIMMABLE-BOUNDARY-START(12886264787)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886264787)
            
            static $h = 1362899;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181232083),
    {
      "r": 1310721,
      "n": "GetStartupParameter",
      "d": 1362899,
      "h": 17181232083,
      "f": 16777256,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.startupParameters",
              "t": 1310721
            }
          ]
        },
        {
          "t": 71237633,
          "c": 4366204929
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181232083),
//--TRIMMABLE-BOUNDARY-START(21476199379),
    {
      "r": 65537,
      "n": "WasmReady",
      "d": 1362899,
      "h": 21476199379,
      "f": 16777256,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.wasmReady",
              "t": 1310721
            }
          ]
        },
        {
          "t": 71237633,
          "c": 4366204929
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476199379)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296330195),
    {
      "t": 524299,
      "n": "__signature_GetStartupParameter_1310674786",
      "d": 1362899,
      "h": 4296330195,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296330195),
//--TRIMMABLE-BOUNDARY-START(8591297491),
    {
      "t": 524299,
      "n": "__signature_WasmReady_19325221",
      "d": 1362899,
      "h": 8591297491,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591297491)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886264787),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1362899,
      "h": 12886264787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886264787)
  ],
  "h": 1362899,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.WebAssemblyJavascript`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}WebAssemblyJavascript`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1362899)
        
        

        //--TRIMMABLE-BOUNDARY-START(379859)
        $asm.$cls(`$RywK.LWCW._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295347155)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295347155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$RywK.LWCW.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295347155)
            
            static $h = 379859;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295347155),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 379859,
      "h": 4295347155,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295347155)
  ],
  "h": 379859
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(379859)
        
        

        //--TRIMMABLE-BOUNDARY-START(248787)
        $asm.$cls(`$RywK.GCLog`, ($self) => class GCLog extends $.$$.S.Object
        {
            $dtor()
            {
                /*var*/ let heap = $.$$.S.GC.GetGCMemoryInfo();
                $.$scsl.S.Console.WriteLine$17(`GCRun : Total:${$.$strNN($.$$.S.GC.GetTotalMemory(false))} TotalAlloc:${$.$strNN($.$$.S.GC.GetTotalAllocatedBytes(false))} TotalPause:${$.$strNN($.$$.S.GC.GetTotalPauseDuration().ToString())} Size:${$.$strNN(heap.HeapSizeBytes)}`);
                new $.$RywK.GCLog().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-START(4295216083)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295216083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295216083)
            
            //--TRIMMABLE-BOUNDARY-START(4295216083)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295216083)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 248787;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295216083),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 248787,
      "h": 4295216083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295216083)
  ],
  "h": 248787
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `GCLog`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `GCLog`; }
        });
        //--TRIMMABLE-BOUNDARY-END(248787)
        
        

        //--TRIMMABLE-BOUNDARY-START(445395)
        $asm.$cls(`$RywK.LWCW.DynamicConfiguration`, ($self) => class DynamicConfiguration
        {
            //--TRIMMABLE-BOUNDARY-START(12885347283)
            static /*void */ OAuth2(/*WebAssemblyHostBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885347283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure$1($.$DZqk.LCACO.OAuth2ClientConfiguration, builder.Services, "Google", new ($.$$.S.Action$$($.$DZqk.LCACO.OAuth2ClientConfiguration))().$ctor(this,  (/*options*/ options) =>
                {
                    /*var*/ let o = $.$mecb.MEC.ConfigurationBinder.Get$3($.$DZqk.LCACO.OAuth2ClientConfiguration, builder.Configuration.GetSection("Google:OAuth2"));
                    options.ClientId = o.ClientId;
                    options.ClientSecret = o.ClientSecret;
                }, $rhUqPd ??= {"r":65537,"p":[{"n":"options","p":6603773}],"n":"","d":445395,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885347283)
            
            //--TRIMMABLE-BOUNDARY-START(4295412691)
            static /*void */ GoogleCloudMap(/*WebAssemblyHostBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295412691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$AutK.LCFCMG$1.GoogleCloudMapConfiguration, builder.Services, new ($.$$.S.Action$$($.$AutK.LCFCMG$1.GoogleCloudMapConfiguration))().$ctor(this,  (/*options*/ options) =>
                {
                    /*var*/ let o = $.$mecb.MEC.ConfigurationBinder.Get$3($.$AutK.LCFCMG$1.GoogleCloudMapConfiguration, builder.Configuration.GetSection("Google:Maps"));
                    options.APIKey = o.APIKey;
                }, $aShzrf ??= {"r":65537,"p":[{"n":"options","p":1095918}],"n":"","d":445395,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295412691)
            
            //--TRIMMABLE-BOUNDARY-START(8590379987)
            static /*void */ LocationIQ(/*WebAssemblyHostBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590379987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$AutK.LCFCML.LocationIQConfiguration, builder.Services, new ($.$$.S.Action$$($.$AutK.LCFCML.LocationIQConfiguration))().$ctor(this,  (/*options*/ options) =>
                {
                    /*var*/ let o = $.$mecb.MEC.ConfigurationBinder.Get$3($.$AutK.LCFCML.LocationIQConfiguration, builder.Configuration.GetSection("LocationIQ"));
                    options.APIKey = o.APIKey;
                }, $OcLmkd ??= {"r":65537,"p":[{"n":"options","p":1685742}],"n":"","d":445395,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590379987)
            
            static $h = 445395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885347283),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 2031736
        }
      ],
      "n": "OAuth2",
      "d": 445395,
      "h": 12885347283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885347283),
//--TRIMMABLE-BOUNDARY-START(4295412691),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 2031736
        }
      ],
      "n": "GoogleCloudMap",
      "d": 445395,
      "h": 4295412691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295412691),
//--TRIMMABLE-BOUNDARY-START(8590379987),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 2031736
        }
      ],
      "n": "LocationIQ",
      "d": 445395,
      "h": 8590379987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590379987)
  ],
  "h": 445395
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.DynamicConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}DynamicConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(445395)
        
        

        //--TRIMMABLE-BOUNDARY-START(117715)
        $asm.$cls(`$RywK._LWCWL.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295085011)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg1, /*int*/ __seq2, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295085011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ValueChanged", __arg1);
                __builder.AddComponentParameter(__seq2, "ValueExpression", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295085011)
            
            static $h = 117715;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295085011),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 117715,
      "h": 4295085011,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295085011)
  ],
  "h": 117715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Web.Client.Wasm.LivingThingAppSelector.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Web${separator}Client${separator}Wasm${separator}LivingThingAppSelector${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(117715)
        
        

        $asm.$cls("$RywK.Program", ($self) => class Program
        {
            static /*async*/ $$$(args)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    /*var*/ let href;
                    new $.$RywK.GCLog().$ctor$1();
                    /*var*/ let _out = new $.$RywK.ConsoleTimeStampWriter().$ctor$4($.$scsl.S.Console.Out);
                    $.$scsl.S.Console.SetOut(_out);
                    $.$fPer.LCFCL.LoggingFactory.Register(new $.$fPer.LCFCL.ConsoleLogger().$ctor$1());
                    $.$scsl.S.Console.WriteLine$17(`LivingThing`);
                    /*var*/ let builder = $.$macwa.MACWH.WebAssemblyHostBuilder.CreateDefault(args);
                    $.$scsl.S.Console.WriteLine$17(`Environment: ${$.$strNN(builder.HostEnvironment.MACWH$IWebAssemblyHostEnvironment$Environment)}`);
                    $.$hDPm.LCFC.StaticComponentServiceRegistrar.AddFixedComponents(builder.Services, null);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCS$3.IApplicationDeploymentProvider, $.$RywK.LWCW.WasmApplicationDeployment, builder.Services);
                    $.$fPer.LCFCC$1.ConfigurationBuilderExtension.AddAssembly(builder.Configuration, $.$RywK.LWCW._Imports.$type.Assembly, "Development");
                    /*LazyAssemblyLoader*/ let lazyLoader = new $.$macwa.MACWS.LazyAssemblyLoader().$ctor$1(null);
                    $.$scsl.S.Console.WriteLine$17(`Getting Startup Parameter`);
                    /*var*/ let sappParam = globalThis.startupParameters();
                    $.$scsl.S.Console.WriteLine$17(`Deserialize Startup Parameter ${$.$strNN(sappParam)}`);
                    /*ApplicationRuntimeConfiguration?*/ let appParam = null;
                    if (sappParam !== null)
                    {
                        $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fPer.LCFCA.ApplicationRuntimeConfiguration.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fPer.LCFCA.ApplicationRuntimeConfigurationCustomAttributesProvider, $.$fPer.LCFCA.ApplicationRuntimeConfigurationCustomAttributesProvider.GetAttributes));
                        $.$fPer.LCFCA.ApplicationRuntimeConfigurationTypeDescriptorBuilder.Register();
                        $.$fPer.LCFCA.ApplicationAssemblyTypeDescriptorBuilder.Register();
                        $.$fPer.LCFCS$3.StartupOptionsTypeDescriptorBuilder.Register();
                        $.$scsl.S.Console.WriteLine$17(`Start deserialize Startup Parameter`);
                        appParam = $.$fPer.LCFCST.TypeDescriptorJsonSerializer.Deserialize$5($.$fPer.LCFCA.ApplicationRuntimeConfiguration, $.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$fPer.LCFCST.TypeDescriptorJsonSerializerJsonDocument).op_Implicit(sappParam));
                        $.$scsl.S.Console.WriteLine$17(`End deserialize Startup Parameter`);
                        $.$fPer.LCFCD$1.SystemTypeDescriptor.TryRemove($.$fPer.LCFCA.ApplicationRuntimeConfiguration.$type);
                        $.$fPer.LCFCD$1.SystemTypeDescriptor.TryRemove($.$fPer.LCFCS$3.StartupOptions.$type);
                        $.$fPer.LCFCD$1.SystemTypeDescriptor.TryRemove($.$fPer.LCFCA.ApplicationAssembly.$type);
                    }
                    if (appParam !== null && appParam.StartupOptions.Runtime === 0/*RuntimeType.Unknown*/)
                    {
                        /*string?*/ let __ca1__;
                        /*var*/ let rt = (((__ca1__ = appParam.StartUrl) !== null ? $.$$.S.String.Contains$3.call(__ca1__, "wasmhost") : false)) ? 4/*RuntimeType.WasmMobileApp*/ : 3/*RuntimeType.Wasm*/;
                        appParam.StartupOptions = (() =>
                        {
                            //new $.$fPer.LCFCS$3.StartupOptions()
                            const $t1 = $.$fPer.LCFCS$3.StartupOptions;
                            const $i1 = new $t1();
                            $i1.$ctor$2();
                            $i1.Runtime = rt;
                            return $i1;
                        })();
                    }
                    $.$scsl.S.Console.WriteLine$17(`Got Startup Parameter`);
                    /*LivingThing.Core.Frameworks.Common.Application.ApplicationRuntimeConfiguration?*/ let __ca2__;
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca3__;
                    /*bool*/ let hasExplicitBootRequired = ((__ca2__ = appParam) !== null ? ((__ca3__ = __ca2__.Dependencies) !== null ? $.$sl.SL.Enumerable.Any($.$fPer.LCFCA.ApplicationAssembly, __ca3__, new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a.Boot;
                    }, $FXaCcd ??= {"r":262145,"p":[{"n":"a","p":690518}],"n":"","d":1559507,"h":0,"f":17825794})) : false) : false);
                    builder.ConfigureContainer($.$mxdi.MED.IServiceCollection, new $.$lmWW.LCFCS.ExtensibleServiceProviderFactory().$ctor$1(builder.Configuration, appParam.StartupOptions), null);
                    /*LivingThing.Core.Frameworks.Common.Application.ApplicationRuntimeConfiguration?*/ let __ca4__;
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca5__;
                    /*var*/ let appPackageToRun = (appParam?.AppId ?? null) ?? $.$fPer.LCFCA.ApplicationAssembly.op_Implicit((__ca4__ = appParam) !== null ? ((__ca5__ = __ca4__.AppsPackages) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca5__) : null) : null);
                    if ((appParam?.Variables?.TryGetValue("href", $.$ref(() => href, ($v) => href = $v, $.$$.S.String)) ?? null) ?? false)
                    {
                        $.$scsl.S.Console.WriteLine$17(`Trying to route to app from ${$.$strNN(href)}`);
                        /*var*/ let startUri = new $.$spu.S.Uri().$ctor$5(href);
                        /*var*/ let guessAppName = $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call($.$$.S.String.Trim$1.call(startUri.AbsolutePath, /*/*/ 47), /*/*/ 47, 0), 0);
                        if (!$.$$.S.String.IsNullOrEmpty(guessAppName))
                        {
                            if (guessAppName !== appParam.AppName)
                            {
                                $.$scsl.S.Console.WriteLine$17(`Guessed app: ${$.$strNN(guessAppName)}`);
                                /*HttpClient*/ let client = new $.$snh.SNH.HttpClient().$ctor$3();
                                try
                                {
                                    let $t3, $r3;
                                    /*var*/ let appDescriptor = ($t3 = $.$snhj.SNHJ.HttpClientJsonExtensions.GetFromJsonAsync$8($.$fPer.LCFCA.ApplicationRuntimeConfiguration, client, `${$.$strNN(startUri.Scheme)}://${$.$strNN(startUri.Authority)}/app.json?href=${$.$strNN($.$swh.SW.HttpUtility.UrlEncode$3(href))}&runtime=${$.$strNN($.$$.S.Enum.ToStringT($.$fPer.LCFC.RuntimeType, $.$$.S.UInt32, appParam.StartupOptions.Runtime))}&appName=${$.$strNN($.$swh.SW.HttpUtility.UrlEncode$3(guessAppName))}`, new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                    if ((appDescriptor?.AppName ?? null) !== null)
                                    {
                                        appParam = appDescriptor ?? appParam;
                                        $.$scsl.S.Console.WriteLine$17(`Using AppParam: ${$.$strNN($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$fPer.LCFCA.ApplicationRuntimeConfiguration, appParam, true, false, true, false, false, false, false, "", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Web.Client.Wasm\\Program.cs", "", 182).Json)}`);
                                    }
                                }
                                catch(e)
                                {
                                    $.$scsl.S.Console.WriteLine$17(e.Message);
                                }
                            }
                        }
                    }
                    appParam ??= (() =>
                    {
                        //new $.$fPer.LCFCA.ApplicationRuntimeConfiguration()
                        const $t4 = $.$fPer.LCFCA.ApplicationRuntimeConfiguration;
                        const $i4 = new $t4();
                        $i4.$ctor$1();
                        $i4.StartupOptions = (() =>
                        {
                            //new $.$fPer.LCFCS$3.StartupOptions()
                            const $t5 = $.$fPer.LCFCS$3.StartupOptions;
                            const $i5 = new $t5();
                            $i5.$ctor$2();
                            $i5.Runtime = 3/*RuntimeType.Wasm*/;
                            return $i5;
                        })();
                        return $i4;
                    })();
                    builder.RootComponents.Clear();
                    builder.RootComponents.Add$3($.$macw.MACW.HeadOutlet, "head::after");
                    /*IEnumerable<string>*/ let loadedPackages;
                    /*string*/ let extension = ".wasm";
                    if (appParam.AppsPackages !== null && appParam.AppType !== null)
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca6__;
                        /*var*/ let lazyDeps = ((__ca6__ = appParam.Dependencies) !== null ? ($.$sl.SL.Enumerable.Where($.$fPer.LCFCA.ApplicationAssembly, __ca6__, new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                        {
                            if (a.Lazy)
                            {
                                if (hasExplicitBootRequired)
                                {
                                    return a.Boot;
                                }
                                return true;
                            }
                            return false;
                        }, $ooRIRd ??= {"r":262145,"p":[{"n":"a","p":690518}],"n":"","d":1559507,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$fPer.LCFCA.ApplicationAssembly)) : $.$sl.SL.Enumerable.Empty($.$fPer.LCFCA.ApplicationAssembly));
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca7__;
                        /*var*/ let toLoad = $.$sl.SL.Enumerable.ToList($.$$.S.String, $.$sl.SL.Enumerable.Distinct$1($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.String, $.$sl.SL.Enumerable.Concat($.$fPer.LCFCA.ApplicationAssembly, (((__ca7__ = appParam.MainAssemblies) !== null ? ($.$sl.SL.Enumerable.Where($.$fPer.LCFCA.ApplicationAssembly, __ca7__, new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                        {
                            return e.Lazy;
                        }, $OtITyb ??= {"r":262145,"p":[{"n":"e","p":690518}],"n":"","d":1559507,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$fPer.LCFCA.ApplicationAssembly)) : $.$sl.SL.Enumerable.Empty($.$fPer.LCFCA.ApplicationAssembly))), lazyDeps), new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationAssembly, $.$$.S.String))().$ctor(this,  (/*a*/ a) =>
                        {
                            return a.Name;
                        }, $nRCENj ??= {"r":1310721,"p":[{"n":"a","p":690518}],"n":"","d":1559507,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                        {
                            return e !== null;
                        }, $cwJpAa ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":1559507,"h":0,"f":17825794}))));
                        if (toLoad.Count > 0)
                        {
                            let $t6, $r6;
                            $.$scsl.S.Console.WriteLine$17(`Lazy loading ${$.$strNN($.$$.S.String.Join$5(",", toLoad))}`);
                            ($t6 = lazyLoader.LoadAssembliesAsync($.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, toLoad, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*a*/ a) =>
                            {
                                return $.$strNN(a) + $.$strNN(extension);
                            }, $zWJTPj ??= {"r":1310721,"p":[{"n":"a","p":1310721}],"n":"","d":1559507,"h":0,"f":17825794}))), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                            $.$scsl.S.Console.WriteLine$17(`Registering ${$.$strNN(toLoad.Count)} dynamic services...`);
                            let $en7 = toLoad.GetEnumerator();
                            while ($en7.MoveNext())
                            {
                                let packageName = $en7.Current;
                                {
                                    $.$RywK.LWCW.DynamicRegistrar.Register(packageName, builder.Services, builder.Configuration, appParam.StartupOptions);
                                }
                            }
                            $.$scsl.S.Console.WriteLine$17("Registered dynamic services!");
                        }
                        loadedPackages = toLoad;
                        $.$fPer.LCFCA.ApplicationAssembly.LazyLoadedApplications.Add(appParam.AppId);
                        $.$scsl.S.Console.WriteLine$17(`Registering package services...`);
                        let $en8 = appParam.AppsPackages.SCG$IEnumerable$$$GetEnumerator();
                        while ($en8.SC$1$IEnumerator$MoveNext())
                        {
                            let $package = $en8.SCG$IEnumerator$$$Current;
                            {
                                if ($package.IsOwnRuntime && !$package.Lazy)
                                {
                                    $.$RywK.LWCW.DynamicRegistrar.Register($package.Name, builder.Services, builder.Configuration, appParam.StartupOptions);
                                }
                            }
                        }
                        $.$scsl.S.Console.WriteLine$17("Registered dynamic services!");
                        /*void*/  function LoadApp()
                        {
                            /*var*/ let appTypeName = appParam.AppType;
                            /*var*/ let clientAppModelPattern = $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call($.$sZVd.LCFCA.ClientApplicationModel$$().$type.FullName, /*[*/ 91, 0), 0);
                            /*bool*/ let isClientAppModel = false;
                            if ($.$$.S.String.StartsWith$3.call(appTypeName, clientAppModelPattern))
                            {
                                /*var*/ let tp = $.$$.S.String.Substring$1.call(appTypeName, clientAppModelPattern.length);
                                appTypeName = $.$$.S.String.Trim$3.call(tp, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*[*/ 91, /*]*/ 93 ]));
                                isClientAppModel = true;
                            }
                            $.$scsl.S.Console.WriteLine$17(`Getting app type: ${$.$strNN(appParam.AppType)} =>  ${$.$strNN(($.$strNN(appTypeName) + ", " + $.$strNN($.$sl.SL.Enumerable.ElementAt$1($.$fPer.LCFCA.ApplicationAssembly, appParam.AppsPackages, 0).Name)))}`);
                            /*var*/ let appType = $.$$.S.Type.GetType$8(appTypeName) ?? $.$$.S.Type.GetType$8($.$strNN(appTypeName) + ", " + $.$strNN($.$sl.SL.Enumerable.ElementAt$1($.$fPer.LCFCA.ApplicationAssembly, appParam.AppsPackages, 0).Name));
                            $.$scsl.S.Console.WriteLine$17(`Got app type!`);
                            if (appType === null)
                            {
                                $.$scsl.S.Console.WriteLine$17(`Cannot Resolve Type: ${$.$strNN(($.$strNN(appParam.AppType) + ", " + $.$strNN($.$sl.SL.Enumerable.ElementAt$1($.$fPer.LCFCA.ApplicationAssembly, appParam.AppsPackages, 0).Name)))}`);
                            }
                            else 
                            {
                                if ($.$hDPm.LCFCA$1.IAppRouterBase.$type.IsAssignableFrom(appType))
                                {
                                    $.$scsl.S.Console.WriteLine$17(`Adding routable root app: ${$.$strNN(appType.FullName)}`);
                                    builder.RootComponents.Add$2(appType, "#app");
                                }
                                else 
                                {
                                    if (appParam.UseRouter)
                                    {
                                        appParam.RouterAssemblies = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.SR.Assembly.$type, [ ...(appParam.RouterAssemblies ?? $.$sl.SL.Enumerable.Empty($.$$.SR.Assembly)), appType.Assembly ], null, null);
                                    }
                                    if (isClientAppModel)
                                    {
                                        appType = $.$sZVd.LCFCA.ClientApplicationModel$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ appType ], null, null));
                                    }
                                    /*var*/ let loader = $.$sZVd.LCFCA.ApplicationLoaderT$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ appType ], null, null));
                                    if (appParam.PreRendered !== loader.FullName)
                                    {
                                        $.$scsl.S.Console.WriteLine$17(`Adding Root App: ${$.$strNN(loader.FullName)}`);
                                        builder.RootComponents.Add$2($.$RywK.LWCW.LivingThingApp$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ loader ], null, null)), "#app");
                                    }
                                }
                            }
                        }
                        LoadApp.call(this);
                    }
                    else 
                    {
                        let $t9, $r9;
                        /*var*/ let toLoad = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["LivingThing.Core.Frameworks.Common.RPC.Http"], [-1], null);
                        ($t9 = lazyLoader.LoadAssembliesAsync($.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, toLoad, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*l*/ l) =>
                        {
                            return $.$strNN(l) + $.$strNN(extension);
                        }, $zIPXed ??= {"r":1310721,"p":[{"n":"l","p":1310721}],"n":"","d":1559507,"h":0,"f":17825794}))), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        $.$TLYN.LT.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        $.$fPer.LCFC.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        $.$Iaui.LCFCM.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        $.$vWqU.LCFCC.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        $.$yleQ.LCFCA.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        $.$uvJL.LCFCR.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        $.$ljzt.LCFCW.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        $.$hDPm.LCFC.ServiceRegistrar.Configure(builder.Services, builder.Configuration, appParam.StartupOptions);
                        let $i10 = 0;
                        let $arr10 = toLoad;
                        while ($i10 < $arr10.length)
                        {
                            let $package = $arr10[$i10++];
                            $.$RywK.LWCW.DynamicRegistrar.Register($package, builder.Services, builder.Configuration, appParam.StartupOptions);
                        }
                        loadedPackages = toLoad;
                        builder.RootComponents.Add$3($.$RywK.LWCW.LivingThingApp$$($.$RywK.LWCW.LivingThingAppSelector), "#app");
                    }
                    if ($.$sl.SL.Enumerable.Any($.$$.S.String, loadedPackages, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a === "LivingThing.Core.Authentication.Client.OAuth.Blazor";
                    }, $ykpxAb ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":1559507,"h":0,"f":17825794})))
                    {
                        $.$RywK.LWCW.DynamicConfiguration.OAuth2(builder);
                    }
                    if ($.$sl.SL.Enumerable.Any($.$$.S.String, loadedPackages, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a === "LivingThing.Core.Frameworks.Common.Mapping";
                    }, $OtPFvh ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":1559507,"h":0,"f":17825794})))
                    {
                        $.$RywK.LWCW.DynamicConfiguration.GoogleCloudMap(builder);
                        $.$RywK.LWCW.DynamicConfiguration.LocationIQ(builder);
                    }
                    $.$RywK.LWCW._Startup.AddGeneratedComponentOptimizers(builder.Services);
                    $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$fPer.LCFCA.ApplicationRuntimeConfiguration, builder.Services, new ($.$$.S.Action$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration))().$ctor(this,  (/*app*/ app) =>
                    {
                        app.AppId = appParam.AppId;
                        app.Version = appParam.Version;
                        app.AppHttpScheme = appParam.AppHttpScheme;
                        app.MainAssemblies = appParam.MainAssemblies;
                        app.Dependencies = appParam.Dependencies;
                        app.PluginsPackages = appParam.PluginsPackages;
                        app.Authorize = appParam.Authorize;
                        app.UseRouter = appParam.UseRouter;
                        app.UseAuthentication = appParam.UseAuthentication;
                        app.UseServer = appParam.UseServer;
                        app.UseWebSocket = appParam.UseWebSocket;
                        app.StartupOptions = appParam.StartupOptions;
                        app.RouterAssemblies = appParam.RouterAssemblies;
                        app.StartUrl = appParam.StartUrl;
                        app.RemoteUrl = appParam.RemoteUrl;
                        app.Variables = appParam.Variables;
                        app.UsingOptimizedWasmLoading = appParam.UsingOptimizedWasmLoading;
                    }, $XgWzYj ??= {"r":65537,"p":[{"n":"app","p":1083734}],"n":"","d":1559507,"h":0,"f":17825794}));
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$mecga.MEC.IConfiguration, builder.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$mecga.MEC.IConfiguration))().$ctor(this,  (/*x*/ x) =>
                    {
                        return builder.Configuration;
                    }, $QXuUgh ??= {"r":393310,"p":[{"n":"x","p":327718}],"n":"","d":1559507,"h":0,"f":17825794}));
                    $.$mecm.MED.MemoryCacheServiceCollectionExtensions.AddMemoryCache$1(builder.Services);
                    $.$TvJd.LCFW.Startup.AddBlazorWebAssemblyLibraries(builder.Services);
                    $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$hDPm.LCFCH.PageHeadOptions, builder.Services, new ($.$$.S.Action$$($.$hDPm.LCFCH.PageHeadOptions))().$ctor(this,  (/*o*/ o) =>
                    {
                        o.FrameworksAlreadyAdded = true;
                        o.SPAFrameworksAlreadyAdded = true;
                    }, $fwqTnc ??= {"r":65537,"p":[{"n":"o","p":62019242}],"n":"","d":1559507,"h":0,"f":17825794}));
                    if (appParam.StartupOptions.Runtime === 4/*RuntimeType.WasmMobileApp*/)
                    {
                        $.$TvJd.LCFWN.Startup.AddNativeInterop(builder.Services);
                    }
                    $.$hDPm.LCFC.StaticComponentServiceRegistrar.AddFixedCommandButton(builder.Services, new ($.$$.S.Func$$$$($.$hDPm.LCFCI.IClientUnitOfWork, $.$hDPm.LCFCS.IFixedComponentControl, $.$$.STT.Task))().$ctor($.$RywK.LWCW.LivingThingAppSwitch, $.$RywK.LWCW.LivingThingAppSwitch.Switch), $.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$$.S.Func$$$$($.$hDPm.LCFCI.IClientUnitOfWork, $.$hDPm.LCFCS.IFixedComponentControl, $.$mac.MAC.RenderFragment)).op_Implicit("mdi mdi-swap-horizontal"/*MaterialDesignIconNames.SwapHorizontal*/), $.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$$.S.Func$$$$($.$hDPm.LCFCI.IClientUnitOfWork, $.$hDPm.LCFCS.IFixedComponentControl, $.$mac.MAC.RenderFragment)).op_Implicit("Switch App"), new ($.$$.S.Action$$($.$hDPm.LCFCS.FixedComponentConfiguration))().$ctor(this,  (/*options*/ options) =>
                    {
                        options.Order = -2147483648/*int.MinValue*/;
                    }, $KnxkQh ??= {"r":65537,"p":[{"n":"options","p":69359274}],"n":"","d":1559507,"h":0,"f":17825794}));
                    $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddScoped$3($.$uvJL.LCFCR.IServerRemoteService, $.$RywK.LWCWS.NoServerRemoteService, builder.Services);
                    $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddScoped$5($.$RywK.LWCWS.NoAuthenticationService, builder.Services);
                    $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddScoped$4($.$GfYa.LCFCA.IAuthenticationService, builder.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$GfYa.LCFCA.IAuthenticationService))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$RywK.LWCWS.NoAuthenticationService, x);
                    }, $mibrJb ??= {"r":1655170,"p":[{"n":"x","p":327718}],"n":"","d":1559507,"h":0,"f":17825794}));
                    $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddScoped$4($.$hDPm.LCFCI.IClientAuthenticationService, builder.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IClientAuthenticationService))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$RywK.LWCWS.NoAuthenticationService, x);
                    }, $yYtEsa ??= {"r":63592106,"p":[{"n":"x","p":327718}],"n":"","d":1559507,"h":0,"f":17825794}));
                    $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddScoped$3($.$maca.MACA.AuthenticationStateProvider, $.$RywK.LWCWS.NoAuthenticationStateProvider, builder.Services);
                    $.$scsl.S.Console.WriteLine$17(`Building application => Root:${$.$strNN(builder.RootComponents.Count)}...`);
                    /*var*/ let host = builder.Build();
                    /*var*/ let trace = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmProfileTrace, host.Services);
                    globalThis.wasmReady();
                    $.$scsl.S.Console.WriteLine$17(`Running application...`);
                    try
                    {
                        let $t11, $r11;
                        ($t11 = host.RunAsync(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    }
                    catch(e)
                    {
                        while(e !== null)
                        {
                            $.$scsl.S.Console.WriteLine$17(`Application Error: ${$.$strNN(e.Message)} => ${$.$strNN(e.StackTrace)}`);
                            e = e.InnerException;
                        }
                        throw e;
                    }
        ;
                })    }
            static $h = 1559507;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296526803),
    {
      "r": 178454529,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "\u003CMain\u003E$",
      "o": "$$$",
      "d": 1559507,
      "h": 4296526803,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(4296526803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591494099),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1559507,
      "h": 8591494099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591494099)
  ],
  "h": 1559507
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Program`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Program`; }
        });
        

        //--TRIMMABLE-BOUNDARY-START(1166291)
        $asm.$cls(`$RywK.LWCWS.NoServerRemoteService`, ($self) => class NoServerRemoteService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591100883)
            /*void */ AddServiceRequestHeader(/*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591100883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(8591100883)
            
            //--TRIMMABLE-BOUNDARY-START(12886068179)
            /*IServiceProxy<TService> */ LCFCR$IServerRemoteService$GetRemoteService(TService, /*RemoteProxyExecutionContext?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886068179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12886068179)
            
            //--TRIMMABLE-BOUNDARY-START(4296276947)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService.AddServiceRequestHeader(string, string?)
            LCFCR$IServerRemoteService$AddServiceRequestHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296276947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddServiceRequestHeader(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296276947)
            
            //--TRIMMABLE-BOUNDARY-START(4296133587)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296133587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296133587)
            
            //--TRIMMABLE-BOUNDARY-START(4296133587)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296133587)
            
            static $h = 1166291;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591100883),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddServiceRequestHeader",
      "d": 1166291,
      "h": 8591100883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591100883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296133587),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1166291,
      "h": 4296133587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296133587)
  ],
  "h": 1166291
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IServerRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.Services.NoServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}Services${separator}NoServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1166291)
        
        

        //--TRIMMABLE-BOUNDARY-START(1100755)
        $asm.$cls(`$RywK.LWCWS.NoPlatformPropertyProvider`, ($self) => class NoPlatformPropertyProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591035347)
            /*ValueTask<bool> */ EnableGPS()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591035347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(8591035347)
            
            //--TRIMMABLE-BOUNDARY-START(12886002643)
            /*DeviceBattery */ GetBattery()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886002643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12886002643)
            
            //--TRIMMABLE-BOUNDARY-START(17180969939)
            /*ValueTask<string> */ GetDeviceIdAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180969939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.String, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180969939)
            
            //--TRIMMABLE-BOUNDARY-START(21475937235)
            /*Size */ GetDisplayWindowSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475937235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sdp.SD.Size();
            }
            //--TRIMMABLE-BOUNDARY-END(21475937235)
            
            //--TRIMMABLE-BOUNDARY-START(12938479958)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Platforms.IPlatformPropertyProvider.GetDeviceIdAsync()
            LCFCP$IPlatformPropertyProvider$GetDeviceIdAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12938479958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDeviceIdAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12938479958)
            
            //--TRIMMABLE-BOUNDARY-START(17233447254)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Platforms.IPlatformPropertyProvider.GetDisplayWindowSize()
            LCFCP$IPlatformPropertyProvider$GetDisplayWindowSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17233447254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDisplayWindowSize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17233447254)
            
            //--TRIMMABLE-BOUNDARY-START(4348545366)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Platforms.IPlatformPropertyProvider.EnableGPS()
            LCFCP$IPlatformPropertyProvider$EnableGPS()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4348545366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EnableGPS(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4348545366)
            
            //--TRIMMABLE-BOUNDARY-START(8643512662)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Platforms.IPlatformPropertyProvider.GetBattery()
            LCFCP$IPlatformPropertyProvider$GetBattery()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8643512662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBattery(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8643512662)
            
            //--TRIMMABLE-BOUNDARY-START(4296068051)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296068051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296068051)
            
            //--TRIMMABLE-BOUNDARY-START(4296068051)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296068051)
            
            static $h = 1100755;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591035347),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "n": "EnableGPS",
      "d": 1100755,
      "h": 8591035347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591035347),
//--TRIMMABLE-BOUNDARY-START(12886002643),
    {
      "r": 53381462,
      "n": "GetBattery",
      "d": 1100755,
      "h": 12886002643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886002643),
//--TRIMMABLE-BOUNDARY-START(17180969939),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.String).$h,
      "n": "GetDeviceIdAsync",
      "d": 1100755,
      "h": 17180969939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180969939),
//--TRIMMABLE-BOUNDARY-START(21475937235),
    {
      "r": 786457,
      "n": "GetDisplayWindowSize",
      "d": 1100755,
      "h": 21475937235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475937235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296068051),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1100755,
      "h": 4296068051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296068051)
  ],
  "h": 1100755
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCP.IPlatformPropertyProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.Services.NoPlatformPropertyProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}Services${separator}NoPlatformPropertyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1100755)
        
        

        //--TRIMMABLE-BOUNDARY-START(838611)
        $asm.$cls(`$RywK.LWCW.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180707795)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$RywK.LWCW.LivingThingAppSelector.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$RywK.LWCW.LivingThingAppSelector().$ctor$3();
                    }, $yIdPVb ??= {"r":2752627,"n":"","d":838611,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$RywK.LWCW.LivingThingAppSwitch.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$RywK.LWCW.LivingThingAppSwitch().$ctor$3();
                    }, $oUEzUc ??= {"r":2752627,"n":"","d":838611,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180707795)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295805907)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295805907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295805907)
            
            //--TRIMMABLE-BOUNDARY-START(4295805907)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295805907)
            
            static $h = 838611;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180707795),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885740499,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 838611,
      "h": 17180707795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180707795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295805907),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 838611,
      "h": 4295805907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295805907)
  ],
  "h": 838611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(838611)
        
        

        //--TRIMMABLE-BOUNDARY-START(1297363)
        $asm.$cls(`$RywK.LWCW.WasmApplicationDeployment`, ($self) => class WasmApplicationDeployment extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425806803)
            /*string?*/ MediaPlaceholderPath = null;
            //--TRIMMABLE-BOUNDARY-END(64425806803)
            
            //--TRIMMABLE-BOUNDARY-START(68720774099)
            /*string? */ get Title()
            {
                return "LivingThing";
            }
            //--TRIMMABLE-BOUNDARY-END(68720774099)
            
            //--TRIMMABLE-BOUNDARY-START(21476133843)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(21476133843)
            
            //--TRIMMABLE-BOUNDARY-START(60130839507)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(60130839507)
            
            //--TRIMMABLE-BOUNDARY-START(25831049558)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IApplicationDeploymentProvider.MediaPlaceholderPath.get
            get LCFCS$3$IApplicationDeploymentProvider$MediaPlaceholderPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38715951446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MediaPlaceholderPath;
            }
            //--TRIMMABLE-BOUNDARY-END(25831049558)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(17181166547)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181166547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181166547)
            
            //--TRIMMABLE-BOUNDARY-START(17181166547)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181166547)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130839507)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(60130839507)
                
            }
            static $h = 1297363;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425806803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245937619,
        "f": 50331649
      },
      "n": "MediaPlaceholderPath",
      "d": 1297363,
      "h": 64425806803,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425806803),
//--TRIMMABLE-BOUNDARY-START(68720774099),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835872211,
        "f": 50331649
      },
      "n": "Title",
      "d": 1297363,
      "h": 68720774099,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720774099),
//--TRIMMABLE-BOUNDARY-START(21476133843),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066068435,
        "f": 50331649
      },
      "n": "Description",
      "d": 1297363,
      "h": 21476133843,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476133843),
//--TRIMMABLE-BOUNDARY-START(60130839507),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656003027,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1297363,
      "h": 60130839507,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130839507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181166547),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1297363,
      "h": 17181166547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181166547)
  ],
  "h": 1297363
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IApplicationDeploymentProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.WasmApplicationDeployment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}WasmApplicationDeployment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1297363)
        
        

        //--TRIMMABLE-BOUNDARY-START(969683)
        $asm.$cls(`$RywK.LWCWS.NoAuthenticationService`, ($self) => class NoAuthenticationService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(90195282899)
            /*EventHandler<AuthenticationEventArgs>?*/ OnAuthenticationChanged = null;
            //--TRIMMABLE-BOUNDARY-END(90195282899)
            
            //--TRIMMABLE-BOUNDARY-START(90195282899)
            //--TRIMMABLE-BOUNDARY-START(12885871571)
            add_OnAuthenticationChanged(/*EventHandler<AuthenticationEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885871571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnAuthenticationChanged = $.$$.S.Delegate.Combine$2(this.OnAuthenticationChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12885871571)
            
            //--TRIMMABLE-BOUNDARY-START(107375152083)
            remove_OnAuthenticationChanged(/*EventHandler<AuthenticationEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375152083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnAuthenticationChanged = $.$$.S.Delegate.Remove(this.OnAuthenticationChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(107375152083)
            
            //--TRIMMABLE-BOUNDARY-END(90195282899)
            
            //--TRIMMABLE-BOUNDARY-START(17180838867)
            /*ValueTask<DecodedAuthenticationTicket> */ AnonymousLogIn(/*IAuthenticationClient?*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180838867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(17180838867)
            
            //--TRIMMABLE-BOUNDARY-START(21475806163)
            /*RenderFragment */ Authenticate(/*AuthenticationParameter?*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475806163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(21475806163)
            
            //--TRIMMABLE-BOUNDARY-START(30065740755)
            /*ValueTask<DecodedAuthenticationTicket> */ AuthenticateAsync$1(TViewConfiguration, /*IViewStackPresenter<TViewConfiguration>*/ presenter, /*IAuthenticationClient?*/ client, /*string?*/ message, /*bool*/ allowLogin, /*bool*/ allowRegister, /*bool*/ allowReset, /*bool*/ allowDemoLogin, /*bool*/ allowAnonymousLogin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065740755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(30065740755)
            
            //--TRIMMABLE-BOUNDARY-START(25770773459)
            /*ValueTask<DecodedAuthenticationTicket> */ AuthenticateAsync(/*IAuthenticationClient?*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770773459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(25770773459)
            
            //--TRIMMABLE-BOUNDARY-START(34360708051)
            /*ValueTask<bool> */ BeginPasswordReset(/*string*/ userNameOrEmail)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360708051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(34360708051)
            
            //--TRIMMABLE-BOUNDARY-START(38655675347)
            /*ValueTask<bool> */ BeginRegistration(/*string*/ email)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655675347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(38655675347)
            
            //--TRIMMABLE-BOUNDARY-START(42950642643)
            /*ValueTask<bool> */ CompletePasswordReset(/*string*/ email, /*string*/ token, /*string*/ newPassword, /*string*/ confirmPassword)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950642643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(42950642643)
            
            //--TRIMMABLE-BOUNDARY-START(51540577235)
            /*ValueTask<DecodedAuthenticationTicket> */ CreateUser$1(/*string*/ userName, /*string*/ password, /*string?*/ email, /*string?*/ firstName, /*string?*/ lastName, /*string?*/ phoneNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540577235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(51540577235)
            
            //--TRIMMABLE-BOUNDARY-START(47245609939)
            /*ValueTask<DecodedAuthenticationTicket> */ CreateUser(/*string*/ userName, /*string*/ password, /*string?*/ email, /*string?*/ token, /*string?*/ firstName, /*string?*/ lastName, /*string?*/ phoneNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245609939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(47245609939)
            
            //--TRIMMABLE-BOUNDARY-START(55835544531)
            /*ValueTask<DecodedAuthenticationTicket> */ DemoLogIn(/*IAuthenticationClient?*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835544531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(55835544531)
            
            //--TRIMMABLE-BOUNDARY-START(60130511827)
            /*ValueTask<bool> */ ExternalLogIn(/*string*/ provider, /*string*/ providerKey, /*IAuthenticationClient?*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130511827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(60130511827)
            
            //--TRIMMABLE-BOUNDARY-START(64425479123)
            /*ValueTask<string?> */ GetAuthenticationToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425479123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.String, null);
            }
            //--TRIMMABLE-BOUNDARY-END(64425479123)
            
            //--TRIMMABLE-BOUNDARY-START(68720446419)
            /*ValueTask<ClaimsPrincipal> */ GetClaimsPrincipal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720446419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(68720446419)
            
            //--TRIMMABLE-BOUNDARY-START(73015413715)
            /*ValueTask<bool> */ GetIsLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015413715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(73015413715)
            
            //--TRIMMABLE-BOUNDARY-START(77310381011)
            /*ValueTask<DecodedAuthenticationTicket> */ GetTicket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310381011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$GfYa.LCFCA.DecodedAuthenticationTicket.Default);
            }
            //--TRIMMABLE-BOUNDARY-END(77310381011)
            
            //--TRIMMABLE-BOUNDARY-START(81605348307)
            /*ValueTask<DecodedAuthenticationTicket> */ LogIn(/*string*/ userName, /*string*/ password, /*IAuthenticationClient?*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605348307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(81605348307)
            
            //--TRIMMABLE-BOUNDARY-START(85900315603)
            /*ValueTask */ LogOut(/*IAuthenticationClient?*/ caller)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900315603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(85900315603)
            
            //--TRIMMABLE-BOUNDARY-START(94490250195)
            /*RenderFragment */ ProfileView(/*IAuthenticationClient?*/ client, /*RenderFragment?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490250195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(94490250195)
            
            //--TRIMMABLE-BOUNDARY-START(98785217491)
            /*ValueTask<DecodedAuthenticationTicket> */ RefreshLoginToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785217491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(98785217491)
            
            //--TRIMMABLE-BOUNDARY-START(111670119379)
            /*ValueTask */ SetTicket(/*DecodedAuthenticationTicket*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670119379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111670119379)
            
            //--TRIMMABLE-BOUNDARY-START(4358559402)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IClientAuthenticationService.Authenticate(LivingThing.Core.Frameworks.Client.Interface.AuthenticationParameter?)
            LCFCI$IClientAuthenticationService$Authenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358559402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Authenticate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358559402)
            
            //--TRIMMABLE-BOUNDARY-START(12948493994)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IClientAuthenticationService.ProfileView(LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?, Microsoft.AspNetCore.Components.RenderFragment?)
            LCFCI$IClientAuthenticationService$ProfileView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12948493994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProfileView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12948493994)
            
            //--TRIMMABLE-BOUNDARY-START(8653526698)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IClientAuthenticationService.AuthenticateAsync<TViewConfiguration>(LivingThing.Core.Frameworks.Common.Client.IViewStackPresenter<TViewConfiguration>, LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?, string?, bool, bool, bool, bool, bool)
            LCFCI$IClientAuthenticationService$AuthenticateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653526698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticateAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653526698)
            
            //--TRIMMABLE-BOUNDARY-START(73016099202)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.SetTicket(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket)
            LCFCA$IAuthenticationService$SetTicket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016099202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetTicket(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73016099202)
            
            //--TRIMMABLE-BOUNDARY-START(47246295426)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.LogIn(string, string, LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?)
            LCFCA$IAuthenticationService$LogIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246295426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LogIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47246295426)
            
            //--TRIMMABLE-BOUNDARY-START(21476491650)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.BeginPasswordReset(string)
            LCFCA$IAuthenticationService$BeginPasswordReset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476491650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginPasswordReset(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476491650)
            
            //--TRIMMABLE-BOUNDARY-START(30066426242)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.CompletePasswordReset(string, string, string, string)
            LCFCA$IAuthenticationService$CompletePasswordReset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066426242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompletePasswordReset(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30066426242)
            
            //--TRIMMABLE-BOUNDARY-START(42951328130)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.ExternalLogIn(string, string, LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?)
            LCFCA$IAuthenticationService$ExternalLogIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951328130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ExternalLogIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42951328130)
            
            //--TRIMMABLE-BOUNDARY-START(25771458946)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.BeginRegistration(string)
            LCFCA$IAuthenticationService$BeginRegistration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771458946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginRegistration(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771458946)
            
            //--TRIMMABLE-BOUNDARY-START(34361393538)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.CreateUser(string, string, string?, string?, string?, string?, string?)
            LCFCA$IAuthenticationService$CreateUser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361393538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateUser(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34361393538)
            
            //--TRIMMABLE-BOUNDARY-START(38656360834)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.DemoLogIn(LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?)
            LCFCA$IAuthenticationService$DemoLogIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656360834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DemoLogIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38656360834)
            
            //--TRIMMABLE-BOUNDARY-START(12886557058)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.AnonymousLogIn(LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?)
            LCFCA$IAuthenticationService$AnonymousLogIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886557058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AnonymousLogIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886557058)
            
            //--TRIMMABLE-BOUNDARY-START(17181524354)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.AuthenticateAsync(LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?)
            LCFCA$IAuthenticationService$AuthenticateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181524354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181524354)
            
            //--TRIMMABLE-BOUNDARY-START(51541262722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.LogOut(LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?)
            LCFCA$IAuthenticationService$LogOut()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541262722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LogOut(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51541262722)
            
            //--TRIMMABLE-BOUNDARY-START(60131197314)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.RefreshLoginToken()
            LCFCA$IAuthenticationService$RefreshLoginToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131197314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RefreshLoginToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60131197314)
            
            //--TRIMMABLE-BOUNDARY-START(8591589762)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.OnAuthenticationChanged.add
            LCFCA$IAuthenticationService$add_OnAuthenticationChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591589762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_OnAuthenticationChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591589762)
            
            //--TRIMMABLE-BOUNDARY-START(68721131906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.OnAuthenticationChanged.remove
            LCFCA$IAuthenticationService$remove_OnAuthenticationChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721131906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_OnAuthenticationChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(68721131906)
            
            //--TRIMMABLE-BOUNDARY-START(55836230018)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService.OnAuthenticationChanged
            LivingThing$Core$Frameworks$Common$Authentication$IAuthenticationService$OnAuthenticationChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836230018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnAuthenticationChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(55836230018)
            
            //--TRIMMABLE-BOUNDARY-START(4296753538)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IReadOnlyAuthenticationService.GetAuthenticationToken()
            LCFCA$IReadOnlyAuthenticationService$GetAuthenticationToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296753538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAuthenticationToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296753538)
            
            //--TRIMMABLE-BOUNDARY-START(12886688130)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IReadOnlyAuthenticationService.GetIsLoggedIn()
            LCFCA$IReadOnlyAuthenticationService$GetIsLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886688130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIsLoggedIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886688130)
            
            //--TRIMMABLE-BOUNDARY-START(8591720834)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IReadOnlyAuthenticationService.GetClaimsPrincipal()
            LCFCA$IReadOnlyAuthenticationService$GetClaimsPrincipal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591720834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetClaimsPrincipal(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591720834)
            
            //--TRIMMABLE-BOUNDARY-START(17181655426)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IReadOnlyAuthenticationService.GetTicket()
            LCFCA$IReadOnlyAuthenticationService$GetTicket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181655426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetTicket(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181655426)
            
            //--TRIMMABLE-BOUNDARY-START(4295936979)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295936979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295936979)
            
            //--TRIMMABLE-BOUNDARY-START(4295936979)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295936979)
            
            static $h = 969683;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180838867),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "AnonymousLogIn",
      "d": 969683,
      "h": 17180838867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180838867),
//--TRIMMABLE-BOUNDARY-START(21475806163),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parameter",
          "p": 62215850
        }
      ],
      "n": "Authenticate",
      "d": 969683,
      "h": 21475806163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475806163),
//--TRIMMABLE-BOUNDARY-START(30065740755),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "presenter",
          "p": (TViewConfiguration) => $.$vWqU.LCFCC.IViewStackPresenter$$(TViewConfiguration).$h
        },
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        },
        {
          "n": "message",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "allowLogin",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "allowRegister",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "allowReset",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "allowDemoLogin",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "allowAnonymousLogin",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "g": [
        "TViewConfiguration"
      ],
      "n": "AuthenticateAsync",
      "o": "@$1",
      "d": 969683,
      "h": 30065740755,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(30065740755),
//--TRIMMABLE-BOUNDARY-START(25770773459),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "AuthenticateAsync",
      "d": 969683,
      "h": 25770773459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770773459),
//--TRIMMABLE-BOUNDARY-START(34360708051),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "userNameOrEmail",
          "p": 1310721
        }
      ],
      "n": "BeginPasswordReset",
      "d": 969683,
      "h": 34360708051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360708051),
//--TRIMMABLE-BOUNDARY-START(38655675347),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "email",
          "p": 1310721
        }
      ],
      "n": "BeginRegistration",
      "d": 969683,
      "h": 38655675347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655675347),
//--TRIMMABLE-BOUNDARY-START(42950642643),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "email",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "newPassword",
          "p": 1310721
        },
        {
          "n": "confirmPassword",
          "p": 1310721
        }
      ],
      "n": "CompletePasswordReset",
      "d": 969683,
      "h": 42950642643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950642643),
//--TRIMMABLE-BOUNDARY-START(51540577235),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "email",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "firstName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "lastName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "phoneNumber",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "CreateUser",
      "o": "@$1",
      "d": 969683,
      "h": 51540577235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540577235),
//--TRIMMABLE-BOUNDARY-START(47245609939),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "email",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "token",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "firstName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "lastName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "phoneNumber",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "CreateUser",
      "d": 969683,
      "h": 47245609939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245609939),
//--TRIMMABLE-BOUNDARY-START(55835544531),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "DemoLogIn",
      "d": 969683,
      "h": 55835544531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835544531),
//--TRIMMABLE-BOUNDARY-START(60130511827),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "provider",
          "p": 1310721
        },
        {
          "n": "providerKey",
          "p": 1310721
        },
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "ExternalLogIn",
      "d": 969683,
      "h": 60130511827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130511827),
//--TRIMMABLE-BOUNDARY-START(64425479123),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.String).$h,
      "n": "GetAuthenticationToken",
      "d": 969683,
      "h": 64425479123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425479123),
//--TRIMMABLE-BOUNDARY-START(68720446419),
    {
      "r": $.$$.STT.ValueTask$$($.$ssc.SSC.ClaimsPrincipal).$h,
      "n": "GetClaimsPrincipal",
      "d": 969683,
      "h": 68720446419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720446419),
//--TRIMMABLE-BOUNDARY-START(73015413715),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "n": "GetIsLoggedIn",
      "d": 969683,
      "h": 73015413715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015413715),
//--TRIMMABLE-BOUNDARY-START(77310381011),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "n": "GetTicket",
      "d": 969683,
      "h": 77310381011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310381011),
//--TRIMMABLE-BOUNDARY-START(81605348307),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "LogIn",
      "d": 969683,
      "h": 81605348307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605348307),
//--TRIMMABLE-BOUNDARY-START(85900315603),
    {
      "r": 181338113,
      "p": [
        {
          "n": "caller",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "LogOut",
      "d": 969683,
      "h": 85900315603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900315603),
//--TRIMMABLE-BOUNDARY-START(94490250195),
    {
      "r": 6881395,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        },
        {
          "n": "content",
          "p": 6881395,
          "f": 65
        }
      ],
      "n": "ProfileView",
      "d": 969683,
      "h": 94490250195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490250195),
//--TRIMMABLE-BOUNDARY-START(98785217491),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "n": "RefreshLoginToken",
      "d": 969683,
      "h": 98785217491,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785217491),
//--TRIMMABLE-BOUNDARY-START(111670119379),
    {
      "r": 181338113,
      "p": [
        {
          "n": "token",
          "p": 1130882
        }
      ],
      "n": "SetTicket",
      "d": 969683,
      "h": 111670119379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670119379)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295936979),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 969683,
      "h": 4295936979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295936979)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(90195282899),
    {
      "e": $.$$.S.EventHandler$$($.$GfYa.LCFCA.AuthenticationEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$GfYa.LCFCA.AuthenticationEventArgs).$h
          }
        ],
        "n": "add_OnAuthenticationChanged",
        "d": 969683,
        "h": 12885871571,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$GfYa.LCFCA.AuthenticationEventArgs).$h
          }
        ],
        "n": "remove_OnAuthenticationChanged",
        "d": 969683,
        "h": 107375152083,
        "f": 285212673
      },
      "n": "OnAuthenticationChanged",
      "d": 969683,
      "h": 90195282899,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(90195282899)
  ],
  "h": 969683
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IClientAuthenticationService, $.$GfYa.LCFCA.IAuthenticationService, $.$GfYa.LCFCA.IReadOnlyAuthenticationService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.Services.NoAuthenticationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}Services${separator}NoAuthenticationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(969683)
        
        

        //--TRIMMABLE-BOUNDARY-START(1428435)
        $asm.$cls(`$RywK.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296395731)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296395731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296395731)
            
            //--TRIMMABLE-BOUNDARY-START(4296395731)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296395731)
            
            static $h = 1428435;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296395731),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1428435,
      "h": 4296395731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296395731)
  ],
  "h": 1428435
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1428435)
        
        

        //--TRIMMABLE-BOUNDARY-START(1493971)
        $asm.$cls(`$RywK.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296461267)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296461267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296461267)
            
            //--TRIMMABLE-BOUNDARY-START(4296461267)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296461267)
            
            static $h = 1493971;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296461267),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1493971,
      "h": 4296461267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296461267)
  ],
  "h": 1493971,
  "a": [
    {
      "t": 1428435,
      "c": 4296395731
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1493971)
        
        

        //--TRIMMABLE-BOUNDARY-START(510931)
        $asm.$cls(`$RywK.LWCW.DynamicRegisterAttribute`, ($self) => class DynamicRegisterAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295478227)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295478227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295478227)
            
            //--TRIMMABLE-BOUNDARY-START(4295478227)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295478227)
            
            static $h = 510931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295478227),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 510931,
      "h": 4295478227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295478227)
  ],
  "h": 510931
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.DynamicRegisterAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}DynamicRegisterAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(510931)
        
        

        //--TRIMMABLE-BOUNDARY-START(1035219)
        $asm.$cls(`$RywK.LWCWS.NoAuthenticationStateProvider`, ($self) => class NoAuthenticationStateProvider extends $.$maca.MACA.AuthenticationStateProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296002515)
            /*AuthenticationState*/ _state = null;
            //--TRIMMABLE-BOUNDARY-END(4296002515)
            
            //--TRIMMABLE-BOUNDARY-START(12885937107)
            /*Task<AuthenticationState> */ GetAuthenticationStateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885937107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$maca.MACA.AuthenticationState, this._state);
            }
            //--TRIMMABLE-BOUNDARY-END(12885937107)
            
            //--TRIMMABLE-BOUNDARY-START(8590969811)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590969811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590969811)
            
            //--TRIMMABLE-BOUNDARY-START(8590969811)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590969811)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296002515)
                this._state = new $.$maca.MACA.AuthenticationState().$ctor$1(new $.$ssc.SSC.ClaimsPrincipal().$ctor$1());
                //--TRIMMABLE-BOUNDARY-END(4296002515)
                
            }
            static $h = 1035219;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maca.MACA.AuthenticationStateProvider; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885937107),
    {
      "r": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h,
      "n": "GetAuthenticationStateAsync",
      "d": 1035219,
      "h": 12885937107,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885937107)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296002515),
    {
      "t": 131193,
      "n": "_state",
      "d": 1035219,
      "h": 4296002515,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296002515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590969811),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1035219,
      "h": 8590969811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590969811)
  ],
  "h": 1035219
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.Services.NoAuthenticationStateProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}Services${separator}NoAuthenticationStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1035219)
        
        

        //--TRIMMABLE-BOUNDARY-START(904147)
        $asm.$cls(`$RywK.LWCW.Registrar`, ($self) => class Registrar extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ services, /**/ configuration, /**/ options)
            {
                return this.$nativeFunction.call(this.$target, services, configuration, options);
            }
            static $h = 904147;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180773331),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Invoke",
      "d": 904147,
      "h": 17180773331,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180773331),
//--TRIMMABLE-BOUNDARY-START(8590838739),
    {
      "r": 90570753,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 904147,
      "h": 8590838739,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590838739),
//--TRIMMABLE-BOUNDARY-START(12885806035),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 904147,
      "h": 12885806035,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885806035)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295871443),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 904147,
      "h": 4295871443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295871443)
  ],
  "h": 904147
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.Registrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}Registrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(904147)
        
        

        //--TRIMMABLE-BOUNDARY-START(183251)
        $asm.$cls(`$RywK.ConsoleTimeStampWriter`, ($self) => class ConsoleTimeStampWriter extends $.$$.SI.TextWriter
        {
            //--TRIMMABLE-BOUNDARY-START(21475019731)
            /*TextWriter*/ originalWriter = null;
            //--TRIMMABLE-BOUNDARY-END(21475019731)
            
            //--TRIMMABLE-BOUNDARY-START(4295150547)
            $ctor$4(/*TextWriter*/ originalWriter)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295150547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.originalWriter = originalWriter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295150547)
            
            //--TRIMMABLE-BOUNDARY-START(8590117843)
            /*Encoding */ get Encoding()
            {
                return this.originalWriter.Encoding;
            }
            //--TRIMMABLE-BOUNDARY-END(8590117843)
            
            //--TRIMMABLE-BOUNDARY-START(30064954323)
            /*void */ WriteLine$17(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064954323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.originalWriter.WriteLine$17(`${$.$strNN($.$$.S.Environment.TickCount64)}: ${$.$strNN(message)}`);
            }
            //--TRIMMABLE-BOUNDARY-END(30064954323)
            
            //--TRIMMABLE-BOUNDARY-START(25769987027)
            /*void */ Write$16(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769987027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.originalWriter.Write$16(`${$.$strNN($.$$.S.Environment.TickCount64)}: ${$.$strNN(message)}`);
            }
            //--TRIMMABLE-BOUNDARY-END(25769987027)
            
            static $h = 183251;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.TextWriter; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590117843),
    {
      "p": 166723585,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180052435,
        "f": 50364417
      },
      "n": "Encoding",
      "d": 183251,
      "h": 8590117843,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590117843)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064954323),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$17",
      "d": 183251,
      "h": 30064954323,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30064954323),
//--TRIMMABLE-BOUNDARY-START(25769987027),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$16",
      "d": 183251,
      "h": 25769987027,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25769987027)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475019731),
    {
      "t": 96600065,
      "n": "originalWriter",
      "d": 183251,
      "h": 21475019731,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475019731)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295150547),
    {
      "p": [
        {
          "n": "originalWriter",
          "p": 96600065
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 183251,
      "h": 4295150547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295150547)
  ],
  "h": 183251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `ConsoleTimeStampWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `ConsoleTimeStampWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(183251)
        
        

        //--TRIMMABLE-BOUNDARY-START(1231827)
        $asm.$cls(`$RywK.LWCWS$1.MainLayout`, ($self) => class MainLayout extends $.$mac.MAC.LayoutComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8591166419)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591166419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.Body);
            }
            //--TRIMMABLE-BOUNDARY-END(8591166419)
            
            //--TRIMMABLE-BOUNDARY-START(4296199123)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296199123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296199123)
            
            //--TRIMMABLE-BOUNDARY-START(4296199123)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296199123)
            
            static $h = 1231827;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.LayoutComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591166419),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1231827,
      "h": 8591166419,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591166419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296199123),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1231827,
      "h": 4296199123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296199123)
  ],
  "h": 1231827
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.Shared.MainLayout`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}Shared${separator}MainLayout`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1231827)
        
        

        //--TRIMMABLE-BOUNDARY-START(314323)
        $asm.$cls(`$RywK.LWCW._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590248915)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590248915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590248915)
            
            //--TRIMMABLE-BOUNDARY-START(4295281619)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295281619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295281619)
            
            //--TRIMMABLE-BOUNDARY-START(4295281619)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295281619)
            
            static $h = 314323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590248915),
    {
      "r": 65537,
      "n": "Execute",
      "d": 314323,
      "h": 8590248915,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590248915)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295281619),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 314323,
      "h": 4295281619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295281619)
  ],
  "h": 314323
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(314323)
        
        

        //--TRIMMABLE-BOUNDARY-START(773075)
        $asm.$cls(`$RywK.LWCW.LivingThingAppSwitch`, ($self) => class LivingThingAppSwitch extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475609555)
            /*string */ get OptimizedComponentName()
            {
                return "livingthingappswitch";
            }
            //--TRIMMABLE-BOUNDARY-END(21475609555)
            
            //--TRIMMABLE-BOUNDARY-START(8590707667)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590707667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590707667)
            
            //--TRIMMABLE-BOUNDARY-START(25770576851)
            static /*Task *//*async*/  Switch(/*IClientUnitOfWork*/ unitOfWork, /*IFixedComponentControl*/ fixedComponent)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770576851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = fixedComponent.LCFCS$IFixedComponentControl$Close(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$RywK.LWCW.LivingThingAppSelector, unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.ViewFeatures = (5632/*ViewFeatures.Default*/ & ~1/*ViewFeatures.OKToolBar*/ & ~2/*ViewFeatures.CancelToolBar*/) | 128/*ViewFeatures.Closable*/;
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770576851)
            
            //--TRIMMABLE-BOUNDARY-START(30065544147)
            static /*RenderFragment */ Title(/*IClientUnitOfWork*/ unitOfWork, /*IFixedComponentControl*/ fixedComponent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065544147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let att = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick$1($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "mdi mdi-swap-horizontal bg-transparent"), new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t4, $r4;
                        ($t4 = $.$RywK.LWCW.LivingThingAppSwitch.Switch(unitOfWork, fixedComponent), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    });
                }, $ESPjFh ??= {"r":178454529,"n":"","d":773075,"h":0,"f":17829890}), null, false, null, null, null, null, null, null);
                /*var*/ let att2 = $.$hDPm.LCFCC$1.ComponentExtension.AddOnClick$1($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "fill"), new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t5, $r5;
                        ($t5 = $.$RywK.LWCW.LivingThingAppSwitch.Switch(unitOfWork, fixedComponent), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    });
                }, $HmCDYe ??= {"r":178454529,"n":"","d":773075,"h":0,"f":17829890}), null, false, null, null, null, null, null, null);
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(0, "\r\n        ");
                    __builder2.OpenElement(1, "span");
                    __builder2.AddMultipleAttributes(2, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build(att2)));
                    __builder2.AddContent$4(3, "Switch App");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(4, "\r\n        ");
                    __builder2.OpenElement(5, "button");
                    __builder2.AddMultipleAttributes(6, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build(att)));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(7, "\r\n    ");
                }, $HdnWpi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":773075,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(30065544147)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295740371)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295740371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295740371)
            
            //--TRIMMABLE-BOUNDARY-START(4295740371)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295740371)
            
            static $h = 773075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475609555),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180642259,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 773075,
      "h": 21475609555,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475609555)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590707667),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 773075,
      "h": 8590707667,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590707667),
//--TRIMMABLE-BOUNDARY-START(25770576851),
    {
      "r": 178454529,
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "fixedComponent",
          "p": 69621418
        }
      ],
      "n": "Switch",
      "d": 773075,
      "h": 25770576851,
      "f": 16781352
    },
//--TRIMMABLE-BOUNDARY-END(25770576851),
//--TRIMMABLE-BOUNDARY-START(30065544147),
    {
      "r": 6881395,
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        },
        {
          "n": "fixedComponent",
          "p": 69621418
        }
      ],
      "n": "Title",
      "d": 773075,
      "h": 30065544147,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065544147)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295740371),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 773075,
      "h": 4295740371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295740371)
  ],
  "h": 773075
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.LivingThingAppSwitch`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}LivingThingAppSwitch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(773075)
        
        

        //--TRIMMABLE-BOUNDARY-START(707539)
        $asm.$cls(`$RywK.LWCW.LivingThingAppSelector`, ($self) => class LivingThingAppSelector extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(85900053459)
            /*string */ get OptimizedComponentName()
            {
                return "livingthingappselector";
            }
            //--TRIMMABLE-BOUNDARY-END(85900053459)
            
            //--TRIMMABLE-BOUNDARY-START(73015151571)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015151571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.JS = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mj.MJ.IJSRuntime, serviceProvider);
                this.Runtime = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), serviceProvider);
                this.Configuration = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73015151571)
            
            //--TRIMMABLE-BOUNDARY-START(77310118867)
            /*IJSRuntime*/ JS = null;
            //--TRIMMABLE-BOUNDARY-END(77310118867)
            
            //--TRIMMABLE-BOUNDARY-START(90195020755)
            /*IOptions<ApplicationRuntimeConfiguration>*/ Runtime = null;
            //--TRIMMABLE-BOUNDARY-END(90195020755)
            
            //--TRIMMABLE-BOUNDARY-START(34360445907)
            /*IOptions<ApplicationRuntimeConfiguration>*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(34360445907)
            
            //--TRIMMABLE-BOUNDARY-START(30065478611)
            /*string?*/ categoryFilter = null;
            //--TRIMMABLE-BOUNDARY-END(30065478611)
            
            //--TRIMMABLE-BOUNDARY-START(124554759123)
            /*bool*/ showAll = false;
            //--TRIMMABLE-BOUNDARY-END(124554759123)
            
            //--TRIMMABLE-BOUNDARY-START(81605086163)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605086163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.String.IsNullOrEmpty(this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.RemoteUrl))
                {
                    ($.$cast(this.UnitOfWork.LCFCI$IClientUnitOfWork$Context, $.$TvJd.LCFWS.WasmApplicationContextProvider)).RemoteHost = this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.RemoteUrl;
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(81605086163)
            
            //--TRIMMABLE-BOUNDARY-START(94489988051)
            /*void */ Select(/*ApplicationDescriptor*/ app)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489988051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let startup = $.$yleQ.LCFCA.ApplicationServiceProxyExtension.ToRuntime(app, (this.Runtime.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value?.StartupOptions.Runtime ?? null) ?? 3/*RuntimeType.Wasm*/);
                $.$mj.MJ.JSInProcessRuntimeExtensions.InvokeVoid(($.$cast(this.JS, $.$mj.MJ.IJSInProcessRuntime)), "localStorage.setItem", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "startupParameters", $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$fPer.LCFCA.ApplicationRuntimeConfiguration, startup, true, false, true, false, false, false, false, "Select", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Web.Client.Wasm\\LivingThingAppSelector.razor.cs", "Select", 34).Json ], null, null));
                $.$mj.MJ.JSInProcessRuntimeExtensions.InvokeVoid(($.$cast(this.JS, $.$mj.MJ.IJSInProcessRuntime)), "location.reload", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(94489988051)
            
            //--TRIMMABLE-BOUNDARY-START(21475544019)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475544019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACF.EditForm, 0);
                __builder.AddComponentParameter(1, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                __builder.AddComponentParameter(2, "class", "pd hf scroll bg-card");
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(4, "div");
                        __builder2.AddAttribute$5(5, "class", "flex");
                        __builder2.AddMarkupContent(6, "<h2 class=\"mg-0 fill\">Select App</h2>\r\n        ");
                        __builder2.OpenElement(7, "div");
                        __builder2.AddAttribute$5(8, "class", "stack");
                        $.$RywK._LWCWL.TypeInference.CreateInputEditor_0($.$$.S.Boolean, __builder2, 9, 10, this.showAll, 11, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.showAll = __value;
                        }, $UNcPpd ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":707539,"h":0,"f":17825794}), this.showAll)), 12, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "showAll"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $asNYAk ??= {"r":38797349,"n":"","d":707539,"h":0,"f":17825794})).Invoke()));
                        __builder2.AddMarkupContent(13, "\r\n            ");
                        __builder2.AddMarkupContent(14, "<small>Show All</small>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(15, "\r\n    ");
                        __builder2.AddMarkupContent(16, "<p>\r\n        Select which of the following <b>LivingThing (LT)</b> App to load into this installation.\r\n        The selected app will be automatically loaded on subsequent run.\r\n    </p>\r\n    ");
                        __builder2.AddMarkupContent(17, "<p>\r\n        You can also load another app later on by clicking the arrow on the right\uD83D\uDC49 and then Switch App\r\n        <i class=\"mdi mdi-swap-horizontal\"></i> to select a new application\r\n    </p>\r\n    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteServiceCall$$$($.$yleQ.LCFCA.IApplicationRemoteService, $.$yleQ.LCFCA.ApplicationsDescriptor), 18);
                        __builder2.AddComponentParameter(19, "ServiceMethod", new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$yleQ.LCFCA.IApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$yleQ.LCFCA.ApplicationsDescriptor)))().$ctor(this, ( (/*s*/ s) =>
                        {
                            return s.LCFCA$IApplicationRemoteService$GetApplicationsDescriptor(3/*RuntimeType.Wasm*/, this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.UsingOptimizedWasmLoading, null);
                        }), $aVvHMe ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$yleQ.LCFCA.ApplicationsDescriptor)).$h,"p":[{"n":"s","p":1547744}],"n":"","d":707539,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(20, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$yleQ.LCFCA.ApplicationsDescriptor)))().$ctor(this, ( (/*apps*/ apps) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                if (apps.Data.Applications !== null)
                                {
                                    /*var*/ let categories = $.$sl.SL.Enumerable.Distinct$1($.$$.S.String, $.$sl.SL.Enumerable.SelectMany$2($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.String, apps.Data.Applications, new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.SCG.IEnumerable$$($.$$.S.String)))().$ctor(this,  (/*a*/ a) =>
                                    {
                                        return a.Categories ?? $.$sl.SL.Enumerable.Empty($.$$.S.String);
                                    }, $YcHsLi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.String).$h,"p":[{"n":"a","p":368096}],"n":"","d":707539,"h":0,"f":17825794})));
                                    __builder3.OpenElement(21, "div");
                                    __builder3.AddAttribute$5(22, "class", "scroll");
                                    __builder3.OpenElement(23, "div");
                                    __builder3.AddAttribute$5(24, "class", "flex");
                                    __builder3.OpenElement(25, "div");
                                    __builder3.AddAttribute$5(26, "class", "mgr bg-success-01 corner-5 pdx-3 pdy-1 fsz-10 fw-bold");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 27, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                    {
                                        return this.categoryFilter = null;
                                    }, $eRaHlj ??= {"r":65537,"n":"","d":707539,"h":0,"f":17825794})));
                                    __builder3.AddContent$4(28, "All");
                                    __builder3.CloseElement();
                                    let $en1 = categories.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en1.SC$1$IEnumerator$MoveNext())
                                    {
                                        let c = $en1.SCG$IEnumerator$$$Current;
                                        {
                                            /*var*/ let cat = c;
                                            __builder3.OpenElement(29, "div");
                                            __builder3.AddAttribute$5(30, "class", "mgr bg-success-01 corner-5 pdx-3 pdy-1 fsz-10 fw-bold");
                                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 31, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                return this.categoryFilter = cat;
                                            }, $uCSEPa ??= {"r":65537,"n":"","d":707539,"h":0,"f":17825794})));
                                            __builder3.AddContent$4(32, c);
                                            __builder3.CloseElement();
                                        }
                                    }
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(33, "\r\n            ");
                                    __builder3.OpenElement(34, "div");
                                    __builder3.AddAttribute$5(35, "class", "mgt-10 grid gap-1 colm-15");
                                    let $en2 = $.$sl.SL.Enumerable.OrderBy$1($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.Int32, $.$sl.SL.Enumerable.OrderBy$1($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$yleQ.LCFCA.ApplicationDescriptor, $.$sl.SL.Enumerable.Where($.$yleQ.LCFCA.ApplicationDescriptor, apps.Data.Applications, new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                                    {
                                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                                        return this.categoryFilter === null || (((__ca1__ = a.Categories) !== null ? $.$sl.SL.Enumerable.Contains$1($.$$.S.String, __ca1__, this.categoryFilter) : false));
                                    }, $erjwCh ??= {"r":262145,"p":[{"n":"a","p":368096}],"n":"","d":707539,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                                    {
                                        return this.showAll || !((a.Features & (1/*ApplicationServiceFeatures.InDevelopment*/)) == (1/*ApplicationServiceFeatures.InDevelopment*/));
                                    }, $OvDuOb ??= {"r":262145,"p":[{"n":"a","p":368096}],"n":"","d":707539,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.String))().$ctor(this,  (/*o*/ o) =>
                                    {
                                        return o.Title;
                                    }, $SyYpmc ??= {"r":1310721,"p":[{"n":"o","p":368096}],"n":"","d":707539,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.Int32))().$ctor(this,  (/*o*/ o) =>
                                    {
                                        return o.Name === "Zoey" ? 1 : 2;
                                    }, $ZLxyqh ??= {"r":655361,"p":[{"n":"o","p":368096}],"n":"","d":707539,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                                    while ($en2.SC$1$IEnumerator$MoveNext())
                                    {
                                        let app = $en2.SCG$IEnumerator$$$Current;
                                        {
                                            __builder3.AddContent$1(36, this.Card(apps.Data, app));
                                        }
                                    }
                                    __builder3.CloseElement();
                                }
                            }, $fHsXTf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":707539,"h":0,"f":17825794});
                        }), $JjOHrg ??= {"r":6881395,"p":[{"n":"apps","p":$.$hDPm.LCFCI.ContainerContext$$($.$yleQ.LCFCA.ApplicationsDescriptor).$h}],"n":"","d":707539,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $zVpJLk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":707539,"h":0,"f":17825794});
                }), $nVpkve ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":707539,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(37, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCU.StaticComponents, 38);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475544019)
            
            //--TRIMMABLE-BOUNDARY-START(25770511315)
            /*RenderFragment */ Card(/*ApplicationsDescriptor*/ apps, /*ApplicationDescriptor*/ app)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770511315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(39, "div");
                    __builder2.AddAttribute$5(40, "class", "bg-card bd corner clickable stack");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 41, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return this.Select(app);
                    }, $tynJQa ??= {"r":65537,"n":"","d":707539,"h":0,"f":17825794})));
                    __builder2.OpenElement(42, "div");
                    __builder2.AddMultipleAttributes(43, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass((((app.Theme?.Primary ?? null) ?? $.$fPer.LCFC.Theme.Primary).WithOpacity(0.1).ToHtmlAttributes("bg-") ?? $.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty()), "hx-1 bdb flex"))));
                    if (app.Icon.IsImage)
                    {
                        __builder2.OpenElement(44, "img");
                        __builder2.AddAttribute$5(45, "src", $.$strNN((this.ResolvePath(app.Icon.Icon, true, false, false))) + "?height=200");
                        __builder2.AddAttribute$5(46, "class", "mgx-a mgy mahf");
                        __builder2.CloseElement();
                    }
                    else 
                    {
                        __builder2.OpenElement(47, "i");
                        __builder2.AddMultipleAttributes(48, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(((app.Theme?.Primary ?? null) ?? $.$fPer.LCFC.Theme.Primary).SwapColors().WithBackground(null).ToHtmlAttributes("cl-"), `${$.$strNN(app.Icon.ToString())} fsz-70 mg-a`))));
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(49, "\r\n        ");
                    __builder2.OpenElement(50, "div");
                    __builder2.AddAttribute$5(51, "class", "pd fill stack");
                    __builder2.OpenElement(52, "h3");
                    __builder2.AddAttribute$5(53, "class", "mg-0");
                    __builder2.AddContent$4(54, app.Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(55, "\r\n            ");
                    __builder2.OpenElement(56, "small");
                    __builder2.AddAttribute$5(57, "class", "nowrap-2");
                    __builder2.AddContent$4(58, app.Description);
                    __builder2.CloseElement();
                    if (app.Categories !== null)
                    {
                        __builder2.OpenElement(59, "div");
                        __builder2.AddAttribute$5(60, "class", "scroll mgt-a");
                        __builder2.OpenElement(61, "div");
                        __builder2.AddAttribute$5(62, "class", "flex");
                        let $en3 = app.Categories.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let c = $en3.SCG$IEnumerator$$$Current;
                            {
                                __builder2.OpenElement(63, "div");
                                __builder2.AddAttribute$5(64, "class", "mgr bg-success-01 corner-5 pdx-3 pdy-1 fsz-10 fw-bold");
                                __builder2.AddContent$4(65, c);
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }, $TXNswi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":707539,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(25770511315)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180576723)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180576723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180576723)
            
            //--TRIMMABLE-BOUNDARY-START(17180576723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180576723)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77310118867)
                this.JS = null;
                //--TRIMMABLE-BOUNDARY-END(77310118867)
                
                //--TRIMMABLE-BOUNDARY-START(90195020755)
                this.Runtime = null;
                //--TRIMMABLE-BOUNDARY-END(90195020755)
                
                //--TRIMMABLE-BOUNDARY-START(34360445907)
                this.Configuration = null;
                //--TRIMMABLE-BOUNDARY-END(34360445907)
                
            }
            static $h = 707539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900053459),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130249683,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 707539,
      "h": 85900053459,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85900053459),
//--TRIMMABLE-BOUNDARY-START(77310118867),
    {
      "p": 524402,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540315091,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669857235,
        "f": 83886081
      },
      "n": "JS",
      "d": 707539,
      "h": 77310118867,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310118867),
//--TRIMMABLE-BOUNDARY-START(90195020755),
    {
      "p": $.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720184275,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259791827,
        "f": 83886081
      },
      "n": "Runtime",
      "d": 707539,
      "h": 90195020755,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195020755),
//--TRIMMABLE-BOUNDARY-START(34360445907),
    {
      "p": $.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950380499,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079922643,
        "f": 83886081
      },
      "n": "Configuration",
      "d": 707539,
      "h": 34360445907,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360445907)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015151571),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 707539,
      "h": 73015151571,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015151571),
//--TRIMMABLE-BOUNDARY-START(81605086163),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 707539,
      "h": 81605086163,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81605086163),
//--TRIMMABLE-BOUNDARY-START(94489988051),
    {
      "r": 65537,
      "p": [
        {
          "n": "app",
          "p": 368096
        }
      ],
      "n": "Select",
      "d": 707539,
      "h": 94489988051,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489988051),
//--TRIMMABLE-BOUNDARY-START(21475544019),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 707539,
      "h": 21475544019,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475544019),
//--TRIMMABLE-BOUNDARY-START(25770511315),
    {
      "r": 6881395,
      "p": [
        {
          "n": "apps",
          "p": 630240
        },
        {
          "n": "app",
          "p": 368096
        }
      ],
      "n": "Card",
      "d": 707539,
      "h": 25770511315,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770511315)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065478611),
    {
      "t": 1310721,
      "n": "categoryFilter",
      "d": 707539,
      "h": 30065478611,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065478611),
//--TRIMMABLE-BOUNDARY-START(124554759123),
    {
      "t": 262145,
      "n": "showAll",
      "d": 707539,
      "h": 124554759123,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124554759123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180576723),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 707539,
      "h": 17180576723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180576723)
  ],
  "h": 707539
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.LivingThingAppSelector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}LivingThingAppSelector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(707539)
        
        

        //--TRIMMABLE-BOUNDARY-START(642003)
        $asm.$cls(`$RywK.LWCW.LivingThingApp<>`, (TPageEntry) => $asm.$gt(`$RywK.LWCW.LivingThingApp<>`, [TPageEntry], ($self) => class LivingThingApp$$ extends $.$hDPm.LCFCA$1.AppRouterBase$$$(TPageEntry, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(94489922515)
            /*string */ get OptimizedComponentName()
            {
                return "livingthingapp";
            }
            //--TRIMMABLE-BOUNDARY-END(94489922515)
            
            //--TRIMMABLE-BOUNDARY-START(81605020627)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605020627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Configuration = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(81605020627)
            
            //--TRIMMABLE-BOUNDARY-START(17180511187)
            /*bool */ get Authorize()
            {
                return (this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value?.Authorize ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180511187)
            
            //--TRIMMABLE-BOUNDARY-START(111669791699)
            /*bool */ get UseRouter()
            {
                return (this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value?.UseRouter ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(111669791699)
            
            //--TRIMMABLE-BOUNDARY-START(12885543891)
            /*IEnumerable<Assembly> */ get AdditionalAssemblies()
            {
                return (this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value?.RouterAssemblies ?? null) ?? $.$sl.SL.Enumerable.Empty($.$$.SR.Assembly);
            }
            //--TRIMMABLE-BOUNDARY-END(12885543891)
            
            //--TRIMMABLE-BOUNDARY-START(25770445779)
            /*IOptions<ApplicationRuntimeConfiguration>*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(25770445779)
            
            //--TRIMMABLE-BOUNDARY-START(90194955219)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194955219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
                if (!$.$$.S.String.IsNullOrEmpty(this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.RemoteUrl))
                {
                    ($.$cast(this.UnitOfWork.LCFCI$IClientUnitOfWork$Context, $.$TvJd.LCFWS.WasmApplicationContextProvider)).RemoteHost = this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.RemoteUrl;
                }
                if (!$.$$.S.String.IsNullOrEmpty(this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.StartUrl))
                {
                    /*var*/ let uri;
                    /*var*/ let currentPath = new $.$spu.S.Uri().$ctor$5(this.Navigation.Uri).AbsolutePath;
                    /*string?*/ let startPath = null;
                    if ($.$spu.S.Uri.TryCreate(this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.StartUrl, $.$ref(() => (() =>
                    {
                        //new $.$spu.S.UriCreationOptions()
                        const $t1 = $.$spu.S.UriCreationOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        return $i1;
                    })(), ), $.$ref(() => uri, ($v) => uri = $v, $.$spu.S.Uri)))
                    {
                        startPath = uri.AbsolutePath;
                    }
                    else 
                    {
                        startPath = $.$$.S.String.StartsWith$3.call(this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.StartUrl, "/") ? this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.StartUrl : "/" + $.$strNN(this.Configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value.StartUrl);
                    }
                    if (!$.$$.S.String.StartsWith$3.call(currentPath, startPath))
                    {
                        $.$scsl.S.Console.WriteLine$17(`Navigate to \"${$.$strNN(startPath)}\"`);
                        this.Navigation.NavigateTo$1(startPath, false, false);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194955219)
            
            //--TRIMMABLE-BOUNDARY-START(85899987923)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899987923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899987923)
            
            //--TRIMMABLE-BOUNDARY-START(21475478483)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475478483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let renderingStart = this.BeginRender(null);
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                __builder.AddContent$1(0, view);
                this.EndRender(renderingStart, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475478483)
            
            //--TRIMMABLE-BOUNDARY-START(107374824403)
            /*RenderFragment? */ get SplashScreen()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 1);
                    __builder2.CloseComponent();
                }, $eAQVRk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(107374824403)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590576595)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590576595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590576595)
            
            //--TRIMMABLE-BOUNDARY-START(8590576595)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590576595)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770445779)
                this.Configuration = null;
                //--TRIMMABLE-BOUNDARY-END(25770445779)
                
            }
            static $H = 642003;
            static $h = 642003;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCA$1.AppRouterBase$$$(TPageEntry, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489922515),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60130184147,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 94489922515,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94489922515),
//--TRIMMABLE-BOUNDARY-START(17180511187),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950314963,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50364420
      },
      "n": "Authorize",
      "d": this.$h,
      "H": 17180511187,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180511187),
//--TRIMMABLE-BOUNDARY-START(111669791699),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77310053331,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50364420
      },
      "n": "UseRouter",
      "d": this.$h,
      "H": 111669791699,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(111669791699),
//--TRIMMABLE-BOUNDARY-START(12885543891),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SR.Assembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360380371,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50364417
      },
      "n": "AdditionalAssemblies",
      "d": this.$h,
      "H": 12885543891,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885543891),
//--TRIMMABLE-BOUNDARY-START(25770445779),
    {
      "p": $.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540249555,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 103079857107,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 83886081
      },
      "n": "Configuration",
      "d": this.$h,
      "H": 25770445779,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770445779),
//--TRIMMABLE-BOUNDARY-START(107374824403),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68720118739,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50364420
      },
      "n": "SplashScreen",
      "d": this.$h,
      "H": 107374824403,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(107374824403)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605020627),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 81605020627,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605020627),
//--TRIMMABLE-BOUNDARY-START(90194955219),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": this.$h,
      "H": 90194955219,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(90194955219),
//--TRIMMABLE-BOUNDARY-START(85899987923),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": this.$h,
      "H": 85899987923,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(85899987923),
//--TRIMMABLE-BOUNDARY-START(21475478483),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 21475478483,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475478483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590576595),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8590576595,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590576595)
  ],
  "s": [
    {
      "h": TPageEntry?.$h??1572864,
      "n": "TPageEntry"
    }
  ],
  "r": 1,
  "H": 642003,
  "h": this.$h,
  "a": [
    {
      "t": 61560490,
      "c": 4356527786
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCA$1.IAppRouterBase, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$vWqU.LCFCC.IViewStackPresenter$$($.$hDPm.LCFCI.ViewConfiguration), $.$vWqU.LCFCC.IViewStackPresenter, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Web.Client.Wasm.LivingThingApp<${TPageEntry?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Web${separator}Client${separator}Wasm${separator}LivingThingApp$${TPageEntry?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(642003)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.Net.Http.Headers", "NetJs.Microsoft.AspNetCore.WebUtilities", "NetJs.Microsoft.Bcl.Cryptography", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.Newtonsoft.Json", "NetJs.ReverseMarkdown", "NetJs.System.IdentityModel.Tokens.Jwt", "NetJs.TMDbLib", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Admin.Common", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Admin.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Authentication.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Client.OAuth.Blazor", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Account.Client.Blazor", "NetJs.LivingThing.Core.Community.Article.Common", "NetJs.LivingThing.Core.Community.Article.Client.Blazor", "NetJs.LivingThing.Core.Community.Barter.Common", "NetJs.LivingThing.Core.Community.Barter.Client.Blazor", "NetJs.LivingThing.Core.Shipping.Client.Blazor", "NetJs.LivingThing.Core.Community.Base.Client.Blazor", "NetJs.LivingThing.Core.Community.BuyLink.Common", "NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor", "NetJs.LivingThing.Core.Community.Calendar.Common", "NetJs.LivingThing.Core.Community.Calendar.Client.Blazor", "NetJs.LivingThing.Core.Community.CampaignBot.Common", "NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor", "NetJs.LivingThing.Core.Community.Chat.Common", "NetJs.LivingThing.Core.Community.Chat.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.Common", "NetJs.LivingThing.Core.Community.Church.Common", "NetJs.LivingThing.Core.Community.Group.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Messaging.Blazor", "NetJs.LivingThing.Core.Community.Church.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Local", "NetJs.LivingThing.Core.Community.TV.Common", "NetJs.LivingThing.Core.Community.TV.App.Blazor", "NetJs.LivingThing.Core.Community.TV.Client.Blazor", "NetJs.LivingThing.Core.Community.DIPTV", "NetJs.LivingThing.Core.Community.Handyman.Common", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Community.Dispatch.Common", "NetJs.LivingThing.Core.Community.Dispatch.Schemes.Blazor", "NetJs.LivingThing.Core.Community.Handyman.Client.Blazor", "NetJs.LivingThing.Core.Community.Dispatch.Client.Blazor", "NetJs.LivingThing.Core.Community.Election.Common", "NetJs.LivingThing.Core.Community.Election.Client.Blazor", "NetJs.LivingThing.Core.Community.Forum.Common", "NetJs.LivingThing.Core.Community.Forum.Client.Blazor", "NetJs.LivingThing.Core.Community.FundMe.Common", "NetJs.LivingThing.Core.Community.FundMe.Client.Blazor", "NetJs.LivingThing.Core.Community.Games.Common", "NetJs.LivingThing.Core.Community.Games.Client.Blazor", "NetJs.LivingThing.Core.Community.Gift.Common", "NetJs.LivingThing.Core.Community.Gift.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.User.Common", "NetJs.LivingThing.Core.Community.Group.User.Client.Blazor", "NetJs.LivingThing.Core.Community.Job.Common", "NetJs.LivingThing.Core.Community.Job.Client.Blazor", "NetJs.LivingThing.Core.Community.Journal.Common", "NetJs.LivingThing.Core.Community.Journal.Client.Blazor", "NetJs.LivingThing.Core.Community.Loan.Common", "NetJs.LivingThing.Core.Community.Loan.Client.Blazor", "NetJs.LivingThing.Core.Community.LoanManagement.Common", "NetJs.LivingThing.Core.Community.LoanManagement.Client.Blazor", "NetJs.LivingThing.Core.Community.Make.Common", "NetJs.LivingThing.Core.Community.Make.Client.Blazor", "NetJs.LivingThing.Core.Community.Market.Common", "NetJs.LivingThing.Core.Community.Market.StorePaymentTier.Blazor", "NetJs.LivingThing.Core.Community.Website.Common", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Community.Market.Client.Blazor", "NetJs.LivingThing.Core.Community.Media.Common", "NetJs.LivingThing.Core.Community.Media.Client.Blazor", "NetJs.LivingThing.Core.Community.NairalandForum.Common", "NetJs.LivingThing.Core.Community.NairalandForum.Client.Blazor", "NetJs.LivingThing.Core.Community.NewsAggregator.Common", "NetJs.LivingThing.Core.Community.NewsAggregator.Client.Blazor", "NetJs.LivingThing.Core.Community.Note.Common", "NetJs.LivingThing.Core.Community.Note.Client.Blazor", "NetJs.LivingThing.Core.Community.Organization.Common", "NetJs.LivingThing.Core.Community.Organization.Client.Blazor", "NetJs.LivingThing.Core.Community.Pay.Common", "NetJs.LivingThing.Core.Community.Pay.Client.Blazor", "NetJs.LivingThing.Core.Community.Reply.Common", "NetJs.LivingThing.Core.Community.Reply.Client.Blazor", "NetJs.LivingThing.Core.Community.Review.Common", "NetJs.LivingThing.Core.Community.Review.Client.Blazor", "NetJs.LivingThing.Core.Community.School.Common", "NetJs.LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor", "NetJs.LivingThing.Core.Community.School.Client.Blazor", "NetJs.LivingThing.Core.Community.SchoolPortal.Common", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Attendant", "NetJs.LivingThing.Core.Community.SchoolPortal.Client.Blazor", "NetJs.LivingThing.Core.Community.Short.Common", "NetJs.LivingThing.Core.Community.Short.Client.Blazor", "NetJs.LivingThing.Core.Community.Sticky.Common", "NetJs.LivingThing.Core.Community.Sticky.Client.Blazor", "NetJs.LivingThing.Core.Community.Thrift.Common", "NetJs.LivingThing.Core.Community.Thrift.Client.Blazor", "NetJs.LivingThing.Core.Community.Website.Client.Blazor", "NetJs.LivingThing.Core.Community.All.Client.Blazor", "NetJs.LivingThing.Core.Community.All.Common", "NetJs.LivingThing.Core.Community.Client.Admin.Blazor", "NetJs.LivingThing.Core.Community.BuyLink.Client.Admin.Blazor", "NetJs.LivingThing.Core.Community.Dispatch.Client.Admin.Blazor", "NetJs.LivingThing.Core.Community.Handyman.Client.Admin.Blazor", "NetJs.LivingThing.Core.Gallery.Common", "NetJs.LivingThing.Core.Gallery.Client.Blazor", "NetJs.LivingThing.Core.Community.School.Client.Admin.Blazor", "NetJs.LivingThing.Core.Community.TV.Free", "NetJs.LivingThing.Core.Community.TV.Client.Admin.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Mapping", "NetJs.LivingThing.Core.Frameworks.Common.MotionJPEG", "NetJs.LivingThing.Core.Frameworks.Common.RPC.Http", "NetJs.LivingThing.Core.Frameworks.Common.RPC.WebSocket", "NetJs.LivingThing.Core.Frameworks.Common.ServiceProvider", "NetJs.LivingThing.Core.Frameworks.WebAssembly", "NetJs.LivingThing.Core.IOT.Devices.Gateway", "NetJs.LivingThing.Core.IOT.TankTalks.Common", "NetJs.LivingThing.Core.IOT.AutoTracks.Common", "NetJs.LivingThing.Core.IOT.Devices.AutoTracks", "NetJs.LivingThing.Core.IOT.AutoTracks.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Beacon", "NetJs.LivingThing.Core.IOT.Devices.CowVitals", "NetJs.LivingThing.Core.IOT.Devices.Custom", "NetJs.LivingThing.Core.IOT.Devices.EagleEye", "NetJs.LivingThing.Core.IOT.Devices.EventCounter", "NetJs.LivingThing.Core.IOT.Forecourt.Common", "NetJs.LivingThing.Core.IOT.Devices.Forecourt", "NetJs.LivingThing.Core.IOT.Devices.GasGauge", "NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger", "NetJs.LivingThing.Core.IOT.Devices.IRBlaster", "NetJs.LivingThing.Core.IOT.Devices.LEDMatrix", "NetJs.LivingThing.Core.IOT.Devices.LEDStrip", "NetJs.LivingThing.Core.IOT.Devices.LoadCell", "NetJs.LivingThing.Core.IOT.Devices.Logger", "NetJs.LivingThing.Core.IOT.Devices.SerialBridge", "NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter", "NetJs.LivingThing.Core.IOT.Devices.PowerBeacon", "NetJs.LivingThing.Core.IOT.EnergyMeter.Common", "NetJs.LivingThing.Core.IOT.PowerHouse.Common", "NetJs.LivingThing.Core.IOT.Devices.PowerHouse", "NetJs.LivingThing.Core.IOT.Devices.Ranger", "NetJs.LivingThing.Core.IOT.Devices.SenseAir", "NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver", "NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter", "NetJs.LivingThing.Core.IOT.Devices.SmartPark", "NetJs.LivingThing.Core.IOT.Devices.SmartPoint", "NetJs.LivingThing.Core.IOT.Devices.TankTalks", "NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity", "NetJs.LivingThing.Core.IOT.Devices.Template", "NetJs.LivingThing.Core.IOT.Devices.Terrameter", "NetJs.LivingThing.Core.IOT.Devices.TrafficControl", "NetJs.LivingThing.Core.IOT.Devices.WasteBin", "NetJs.LivingThing.Core.IOT.Devices.All", "NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor", "NetJs.LivingThing.Core.IOT.TankTalks.Client.Blazor", "NetJs.LivingThing.Core.IOT.Forecourt.Client.Blazor", "NetJs.LivingThing.Core.IOT.PowerHouse.Client.Blazor", "NetJs.LivingThing.Core.IOT.RMS.Common", "NetJs.LivingThing.Core.IOT.RMS.Client.Blazor", "NetJs.LivingThing.Core.IOT.All.Client", "NetJs.LivingThing.Core.Localizer.Common", "NetJs.LivingThing.Core.PayCowry.Common", "NetJs.LivingThing.Core.PayCowry.Client.Blazor", "NetJs.LivingThing.Core.Uri.Common", "NetJs.LivingThing.Core.Uri.Client.Blazor", "NetJs.Zoey.Client"));
})();
//--TRIMMABLE-BOUNDARY-END(52179)
