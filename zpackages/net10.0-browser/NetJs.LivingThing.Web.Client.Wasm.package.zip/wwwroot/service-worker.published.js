// Caution! Be sure you understand the caveats before publishing an application with
// offline support. See https://aka.ms/blazor-offline-considerations

const CACHE_VERSION = 1.1;

self.importScripts('./service-worker-assets.js');
self.addEventListener('install', event => event.waitUntil(onInstall(event)));
self.addEventListener('activate', event => event.waitUntil(onActivate(event)));
self.addEventListener('fetch', event => event.respondWith(onFetch(event)));

const cacheNamePrefix = 'offline-cache-';
const cacheName = `${cacheNamePrefix}${self.assetsManifest.version}`;
const offlineAssetsInclude = [
    /\.dll$/, /\.pdb$/, /\.wasm/,
    /\.html/, /\.js$/, /\.json$/, /\.css$/,
    /\.woff$/, /\.woff2$/, /\.ttf$/,
    /\.svg$/,
    /\.png$/, /\.jpe?g$/, /\.gif$/,
    /\.ico$/, /\.blat$/, /\.dat$/
];
const offlineAssetsExclude = [/^service-worker\.js$/];

async function onInstall(event) {
    console.info('Service worker: Install');

    // Fetch and cache all matching items from the assets manifest
    const assetsRequests = self.assetsManifest.assets
        .filter(asset => offlineAssetsInclude.some(pattern => pattern.test(asset.url)))
        .filter(asset => !offlineAssetsExclude.some(pattern => pattern.test(asset.url)))
        .map(asset => new Request(asset.url, { integrity: asset.hash, cache: 'no-cache' }));
    await caches.open(cacheName).then(cache => cache.addAll(assetsRequests));
}

async function onActivate(event) {
    console.info('Service worker: Activate');

    // Delete unused caches
    const cacheKeys = await caches.keys();
    await Promise.all(cacheKeys
        .filter(key => key.startsWith(cacheNamePrefix) && key !== cacheName)
        .map(key => caches.delete(key)));
}

async function onFetch(event) {
    let cachedResponse = null;
    if (event.request.method === 'GET') {
        // For all navigation requests, try to serve index.html from cache
        // If you need some URLs to be server-rendered, edit the following check to exclude those URLs
        const uri = new URL(event.request.url);
        let request;
        //if (uri.pathname == "/_framework/dotnet.opt.js") {
        //    request = "/_framework/dotnet.js";
        //} else {
            const hostPaths = uri.host.split('.');
            const isStaging = hostPaths.some(p => p == "staging");
            const autoRequested = uri.searchParams.get("auto") !== null;
            const clientRequested = uri.searchParams.get("client") !== null;
            const hasSubDomain = hostPaths.length == (isStaging ? 4 : 3);
            const paths = uri.pathname.split('/');
            const lastPath = paths[paths.length - 1];
            const hasFileExtension = lastPath.split('.').length > 1;
            let shouldServeIndexHtml;
            if (clientRequested || autoRequested) {
                shouldServeIndexHtml = !hasFileExtension && event.request.mode === 'navigate';
            } else {
                shouldServeIndexHtml = hasSubDomain && !hasFileExtension && event.request.mode === 'navigate';
            }
            request = shouldServeIndexHtml ? 'index.html' : event.request;
        //}
        const cache = await caches.open(cacheName);
        cachedResponse = await cache.match(request);
    }

    return cachedResponse || fetch(event.request);
}
