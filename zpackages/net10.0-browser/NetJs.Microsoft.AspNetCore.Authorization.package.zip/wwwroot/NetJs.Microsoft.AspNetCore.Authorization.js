
//--TRIMMABLE-BOUNDARY-START(105)
(function ($global, $, $$, $mam, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mexla) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Authorization", 
    {
  "h": 105,
  "f": "Microsoft.AspNetCore.Authorization",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 131176,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 65640,
          "t": 187760641
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "ASP.NET Core authorization classes.\nCommonly used types:\nMicrosoft.AspNetCore.Authorization.AllowAnonymousAttribute\nMicrosoft.AspNetCore.Authorization.AuthorizeAttribute",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Authorization.Test",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1376361)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator", ($self) => class IAuthorizationEvaluator
        {
            static $h = 1376361;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296343657),
    {
      "r": 786537,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "Evaluate",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate",
      "d": 1376361,
      "h": 4296343657,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296343657)
  ],
  "h": 1376361
}; }
            static get $fullName() { return `IAuthorizationEvaluator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376361)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638505)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider", ($self) => class IAuthorizationPolicyProvider
        {
            static $h = 1638505;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886540393),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "GetPolicyAsync",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync",
      "d": 1638505,
      "h": 12886540393,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886540393),
//--TRIMMABLE-BOUNDARY-START(4296605801),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "n": "GetDefaultPolicyAsync",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync",
      "d": 1638505,
      "h": 4296605801,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296605801),
//--TRIMMABLE-BOUNDARY-START(8591573097),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "n": "GetFallbackPolicyAsync",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync",
      "d": 1638505,
      "h": 8591573097,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591573097)
  ],
  "h": 1638505
}; }
            static get $fullName() { return `IAuthorizationPolicyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638505)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507433)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory", ($self) => class IAuthorizationHandlerContextFactory
        {
            static $h = 1507433;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296474729),
    {
      "r": 458857,
      "p": [
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        }
      ],
      "n": "CreateContext",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext",
      "d": 1507433,
      "h": 4296474729,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296474729)
  ],
  "h": 1507433
}; }
            static get $fullName() { return `IAuthorizationHandlerContextFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507433)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704041)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement", ($self) => class IAuthorizationRequirement
        {
            static $h = 1704041;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1704041
}; }
            static get $fullName() { return `IAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704041)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835113)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService", ($self) => class IAuthorizationService
        {
            static $h = 1835113;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296802409),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        }
      ],
      "n": "AuthorizeAsync",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync",
      "d": 1835113,
      "h": 4296802409,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296802409),
//--TRIMMABLE-BOUNDARY-START(8591769705),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1",
      "d": 1835113,
      "h": 8591769705,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591769705)
  ],
  "h": 1835113
}; }
            static get $fullName() { return `IAuthorizationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835113)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441897)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler", ($self) => class IAuthorizationHandler
        {
            static $h = 1441897;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296409193),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "HandleAsync",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync",
      "d": 1441897,
      "h": 4296409193,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296409193)
  ],
  "h": 1441897
}; }
            static get $fullName() { return `IAuthorizationHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441897)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572969)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider", ($self) => class IAuthorizationHandlerProvider
        {
            static $h = 1572969;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296540265),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "GetHandlersAsync",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync",
      "d": 1572969,
      "h": 4296540265,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296540265)
  ],
  "h": 1572969
}; }
            static get $fullName() { return `IAuthorizationHandlerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572969)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769577)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirementData", ($self) => class IAuthorizationRequirementData
        {
            static $h = 1769577;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296736873),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
      "n": "GetRequirements",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizationRequirementData$GetRequirements",
      "d": 1769577,
      "h": 4296736873,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296736873)
  ],
  "h": 1769577
}; }
            static get $fullName() { return `IAuthorizationRequirementData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769577)
        
        
        //--TRIMMABLE-BOUNDARY-START(393321)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<>", (TRequirement) => $asm.$gt("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<>", [TRequirement], ($self) => class AuthorizationHandler$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590327913)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327913);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    var $en3 = $.$sl.System.Linq.Enumerable.OfType(TRequirement, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var req = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await this.HandleRequirementAsync(context, req).ConfigureAwait(false);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590327913)
            
            //--TRIMMABLE-BOUNDARY-START(4296409193)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409193)
            
            //--TRIMMABLE-BOUNDARY-START(4295360617)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360617)
            
            static $h = 393321;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327913),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "HandleAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(8590327913),
//--TRIMMABLE-BOUNDARY-START(12885295209),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        },
        {
          "n": "requirement",
          "p": TRequirement?.$h??1507328
        }
      ],
      "n": "HandleRequirementAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(12885295209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360617),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295360617)
  ],
  "i": [1441897
  ],
  "g": [TRequirement?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `AuthorizationHandler<${TRequirement?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393321)
        
        
        //--TRIMMABLE-BOUNDARY-START(327785)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<,>", (TRequirement, TResource) => $asm.$gt("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<,>", [TRequirement, TResource], ($self) => class AuthorizationHandler$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590262377)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let resource;
                    if ($.$is(context.Resource, TResource, { set $v(v){ resource = v; } }))
                    {
                        var $en4 = $.$sl.System.Linq.Enumerable.OfType(TRequirement, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var req = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                await this.HandleRequirementAsync(context, req, resource).ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590262377)
            
            //--TRIMMABLE-BOUNDARY-START(4296409193)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409193)
            
            //--TRIMMABLE-BOUNDARY-START(4295295081)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295081)
            
            static $h = 327785;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262377),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "HandleAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(8590262377),
//--TRIMMABLE-BOUNDARY-START(12885229673),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        },
        {
          "n": "requirement",
          "p": TRequirement?.$h??1507328
        },
        {
          "n": "resource",
          "p": TResource?.$h??1572864
        }
      ],
      "n": "HandleRequirementAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(12885229673)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295081),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295295081)
  ],
  "i": [1441897
  ],
  "g": [TRequirement?.$h??1507328,TResource?.$h??1572864
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `AuthorizationHandler<${TRequirement?.$fullName},${TResource?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327785)
        
        
        //--TRIMMABLE-BOUNDARY-START(589929)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions", ($self) => class AuthorizationOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557225)
            /*Task<AuthorizationPolicy?>*/ static _nullPolicyTask = null;
            //--TRIMMABLE-BOUNDARY-END(4295557225)
            
            //--TRIMMABLE-BOUNDARY-START(98784837737)
            /*Dictionary<string, Task<AuthorizationPolicy?>>*/ PolicyMap = null;
            //--TRIMMABLE-BOUNDARY-END(98784837737)
            
            //--TRIMMABLE-BOUNDARY-START(94489870441)
            /*bool*/ InvokeHandlersAfterFailure = false;
            //--TRIMMABLE-BOUNDARY-END(94489870441)
            
            //--TRIMMABLE-BOUNDARY-START(42950262889)
            /*AuthorizationPolicy*/ DefaultPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(42950262889)
            
            //--TRIMMABLE-BOUNDARY-START(47245230185)
            /*AuthorizationPolicy?*/ FallbackPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(47245230185)
            
            //--TRIMMABLE-BOUNDARY-START(38655295593)
            /*void */ AddPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.PolicyMap.set_Item(name, $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policy));
            }
            //--TRIMMABLE-BOUNDARY-END(38655295593)
            
            //--TRIMMABLE-BOUNDARY-START(34360328297)
            /*void */ AddPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                this.PolicyMap.set_Item(name, $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policyBuilder.Build()));
            }
            //--TRIMMABLE-BOUNDARY-END(34360328297)
            
            //--TRIMMABLE-BOUNDARY-START(85899935849)
            /*AuthorizationPolicy? */ GetPolicy(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value;
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy))))
                {
                    return value.Result;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935849)
            
            //--TRIMMABLE-BOUNDARY-START(90194903145)
            /*Task<AuthorizationPolicy?> */ GetPolicyTask(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value;
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy))))
                {
                    return value;
                }
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions._nullPolicyTask;
            }
            //--TRIMMABLE-BOUNDARY-END(90194903145)
            
            //--TRIMMABLE-BOUNDARY-START(30065361001)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065361001)
            
            //default member initializer
            constructor()
            {
                super();
                this.PolicyMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy)))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                this.InvokeHandlersAfterFailure = true;
                this.DefaultPolicy = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null)).RequireAuthenticatedUser().Build();
            }
            //--TRIMMABLE-BOUNDARY-START(25770393705)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557225)
                    this._nullPolicyTask = $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, null);
                    //--TRIMMABLE-BOUNDARY-END(4295557225)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770393705)
            
            static $h = 589929;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784837737),
    {
      "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604968553,
        "f": 50331650
      },
      "n": "PolicyMap",
      "d": 589929,
      "h": 98784837737,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98784837737),
//--TRIMMABLE-BOUNDARY-START(94489870441),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015033961,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554641513,
        "f": 83886081
      },
      "n": "InvokeHandlersAfterFailure",
      "d": 589929,
      "h": 94489870441,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489870441),
//--TRIMMABLE-BOUNDARY-START(42950262889),
    {
      "p": 655465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835164777,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374772329,
        "f": 83886081
      },
      "n": "DefaultPolicy",
      "d": 589929,
      "h": 42950262889,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950262889),
//--TRIMMABLE-BOUNDARY-START(47245230185),
    {
      "p": 655465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425099369,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964706921,
        "f": 83886081
      },
      "n": "FallbackPolicy",
      "d": 589929,
      "h": 47245230185,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230185)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655295593),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "AddPolicy",
      "o": "@$1",
      "d": 589929,
      "h": 38655295593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295593),
//--TRIMMABLE-BOUNDARY-START(34360328297),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddPolicy",
      "d": 589929,
      "h": 34360328297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360328297),
//--TRIMMABLE-BOUNDARY-START(85899935849),
    {
      "r": 655465,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetPolicy",
      "d": 589929,
      "h": 85899935849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899935849),
//--TRIMMABLE-BOUNDARY-START(90194903145),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetPolicyTask",
      "d": 589929,
      "h": 90194903145,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194903145)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557225),
    {
      "t": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "n": "_nullPolicyTask",
      "d": 589929,
      "h": 4295557225,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295557225)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065361001),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589929,
      "h": 30065361001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065361001)
  ],
  "h": 589929
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589929)
        
        
        //--TRIMMABLE-BOUNDARY-START(786537)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult", ($self) => class AuthorizationResult extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590721129)
            /*AuthorizationResult*/ static _succeededResult = null;
            //--TRIMMABLE-BOUNDARY-END(8590721129)
            
            //--TRIMMABLE-BOUNDARY-START(4295753833)
            /*AuthorizationResult*/ static _failedResult = null;
            //--TRIMMABLE-BOUNDARY-END(4295753833)
            
            //--TRIMMABLE-BOUNDARY-START(25770590313)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590313)
            
            //--TRIMMABLE-BOUNDARY-START(77310197865)
            /*bool*/ Succeeded = false;
            //--TRIMMABLE-BOUNDARY-END(77310197865)
            
            //--TRIMMABLE-BOUNDARY-START(38655492201)
            /*AuthorizationFailure?*/ Failure = null;
            //--TRIMMABLE-BOUNDARY-END(38655492201)
            
            //--TRIMMABLE-BOUNDARY-START(81605165161)
            static /*AuthorizationResult */ Success()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605165161);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult._succeededResult;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605165161)
            
            //--TRIMMABLE-BOUNDARY-START(34360524905)
            static /*AuthorizationResult */ Failed$1(/*AuthorizationFailure*/ failure)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524905);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Failure = failure;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360524905)
            
            //--TRIMMABLE-BOUNDARY-START(30065557609)
            static /*AuthorizationResult */ Failed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557609);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult._failedResult;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065557609)
            
            //--TRIMMABLE-BOUNDARY-START(21475623017)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721129)
                    this._succeededResult = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Succeeded = true;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(8590721129)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753833)
                    this._failedResult = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Failure = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.ExplicitFail();
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(4295753833)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475623017)
            
            static $h = 786537;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310197865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361385,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015230569,
        "f": 83886082
      },
      "n": "Succeeded",
      "d": 786537,
      "h": 77310197865,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310197865),
//--TRIMMABLE-BOUNDARY-START(38655492201),
    {
      "p": 196713,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426793,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425295977,
        "f": 83886082
      },
      "n": "Failure",
      "d": 786537,
      "h": 38655492201,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655492201)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605165161),
    {
      "r": 786537,
      "n": "Success",
      "d": 786537,
      "h": 81605165161,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605165161),
//--TRIMMABLE-BOUNDARY-START(34360524905),
    {
      "r": 786537,
      "p": [
        {
          "n": "failure",
          "p": 196713
        }
      ],
      "n": "Failed",
      "o": "@$1",
      "d": 786537,
      "h": 34360524905,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360524905),
//--TRIMMABLE-BOUNDARY-START(30065557609),
    {
      "r": 786537,
      "n": "Failed",
      "d": 786537,
      "h": 30065557609,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065557609)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721129),
    {
      "t": 786537,
      "n": "_succeededResult",
      "d": 786537,
      "h": 8590721129,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590721129),
//--TRIMMABLE-BOUNDARY-START(4295753833),
    {
      "t": 786537,
      "n": "_failedResult",
      "d": 786537,
      "h": 4295753833,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295753833)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590313),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786537,
      "h": 25770590313,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770590313)
  ],
  "h": 786537
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786537)
        
        
        //--TRIMMABLE-BOUNDARY-START(524393)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics", ($self) => class AuthorizationMetrics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770328169)
            /*string*/ static MeterName = null;
            //--TRIMMABLE-BOUNDARY-END(25770328169)
            
            //--TRIMMABLE-BOUNDARY-START(8590458985)
            /*Meter*/ _meter = null;
            //--TRIMMABLE-BOUNDARY-END(8590458985)
            
            //--TRIMMABLE-BOUNDARY-START(4295491689)
            /*Counter<long>*/ _authorizedCount = null;
            //--TRIMMABLE-BOUNDARY-END(4295491689)
            
            //--TRIMMABLE-BOUNDARY-START(12885426281)
            $ctor$1(/*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._meter = $.$sdd.System.Diagnostics.Metrics.MeterFactoryExtensions.Create(meterFactory, "Microsoft.AspNetCore.Authorization"/*MeterName*/, null, null);
                    this._authorizedCount = this._meter.CreateCounter$1($.$$.System.Int64, "aspnetcore.authorization.attempts", "{attempt}", "The total number of authorization attempts.");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426281)
            
            //--TRIMMABLE-BOUNDARY-START(17180393577)
            /*void */ AuthorizeAttemptCompleted(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (_authorizedCount.Enabled) { ... }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393577)
            
            //--TRIMMABLE-BOUNDARY-START(21475360873)
            /*void */ AuthorizeAttemptCore(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tags = new $.$sdd.System.Diagnostics.TagList().$ctor$3($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("aspnetcore.user.is_authenticated", $.$box((user.Identity?.System$Security$Principal$IIdentity$IsAuthenticated ?? null) ?? false, $.$$.System.Boolean))], null, null)));
                if (!(policyName === null))
                {
                    tags.Add$1("aspnetcore.authorization.policy", policyName);
                }
                if (!(result === null))
                {
                    /*var*/ let resultTagValue = result.Succeeded ? "success" : "failure";
                    tags.Add$1("aspnetcore.authorization.result", resultTagValue);
                }
                if (!(exception === null))
                {
                    tags.Add$1("error.type", exception.GetType$1().FullName);
                }
                this._authorizedCount.Add$5(1n, $.$ref(() => tags, ));
            }
            //--TRIMMABLE-BOUNDARY-END(21475360873)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328169)
                    this.MeterName = "Microsoft.AspNetCore.Authorization";
                    //--TRIMMABLE-BOUNDARY-END(25770328169)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524393;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393577),
    {
      "r": 65537,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policyName",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 786537
        },
        {
          "n": "exception",
          "p": 80019457
        }
      ],
      "n": "AuthorizeAttemptCompleted",
      "d": 524393,
      "h": 17180393577,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393577),
//--TRIMMABLE-BOUNDARY-START(21475360873),
    {
      "r": 65537,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policyName",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 786537
        },
        {
          "n": "exception",
          "p": 80019457
        }
      ],
      "n": "AuthorizeAttemptCore",
      "d": 524393,
      "h": 21475360873,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475360873)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770328169),
    {
      "t": 1310721,
      "n": "MeterName",
      "d": 524393,
      "h": 25770328169,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328169),
//--TRIMMABLE-BOUNDARY-START(8590458985),
    {
      "t": 6553646,
      "n": "_meter",
      "d": 524393,
      "h": 8590458985,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458985),
//--TRIMMABLE-BOUNDARY-START(4295491689),
    {
      "t": $.$sdd.System.Diagnostics.Metrics.Counter$$($.$$.System.Int64).$h,
      "n": "_authorizedCount",
      "d": 524393,
      "h": 4295491689,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491689)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426281),
    {
      "p": [
        {
          "n": "meterFactory",
          "p": 5439534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524393,
      "h": 12885426281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426281)
  ],
  "h": 524393
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationMetrics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524393)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621545)
        $asm.$cls("$maa.Resources", ($self) => class Resources
        {
            //--TRIMMABLE-BOUNDARY-START(77312032873)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(77312032873)
            
            //--TRIMMABLE-BOUNDARY-START(68722098281)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(68722098281)
            
            //--TRIMMABLE-BOUNDARY-START(73017065577)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427130985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$maa.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.AspNetCore.Authorization", $.$maa.Resources.$type.Assembly);
                    $.$maa.Resources.s_resourceManager = temp;
                }
                return $.$maa.Resources.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(73017065577)
            
            //--TRIMMABLE-BOUNDARY-START(4297588841)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067392617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901967465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Resources.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4297588841)
            
            //--TRIMMABLE-BOUNDARY-START(8592556137)
            static /*string */ get Exception_AuthorizationPolicyEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657327209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "AuthorizationPolicy must have at least one requirement.";
            }
            //--TRIMMABLE-BOUNDARY-END(8592556137)
            
            //--TRIMMABLE-BOUNDARY-START(12887523433)
            static /*string */ get Exception_AuthorizationPolicyNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247261801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The AuthorizationPolicy named: '{0}' was not found.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887523433)
            
            //--TRIMMABLE-BOUNDARY-START(21477458025)
            static /*string */ FormatException_AuthorizationPolicyNotFound(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477458025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The AuthorizationPolicy named: '{0}' was not found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(21477458025)
            
            //--TRIMMABLE-BOUNDARY-START(17182490729)
            static /*string */ get Exception_RoleRequirementEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837196393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "At least one role must be specified.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182490729)
            
            static $h = 2621545;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73017065577),
    {
      "p": 122814465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427130985,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 2621545,
      "h": 73017065577,
      "f": 2097192,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 2,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73017065577),
//--TRIMMABLE-BOUNDARY-START(4297588841),
    {
      "p": 83951617,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067392617,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901967465,
        "f": 83886120
      },
      "n": "Culture",
      "d": 2621545,
      "h": 4297588841,
      "f": 2097192,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 2,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297588841),
//--TRIMMABLE-BOUNDARY-START(8592556137),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657327209,
        "f": 50331688
      },
      "n": "Exception_AuthorizationPolicyEmpty",
      "d": 2621545,
      "h": 8592556137,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(8592556137),
//--TRIMMABLE-BOUNDARY-START(12887523433),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247261801,
        "f": 50331688
      },
      "n": "Exception_AuthorizationPolicyNotFound",
      "d": 2621545,
      "h": 12887523433,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(12887523433),
//--TRIMMABLE-BOUNDARY-START(17182490729),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837196393,
        "f": 50331688
      },
      "n": "Exception_RoleRequirementEmpty",
      "d": 2621545,
      "h": 17182490729,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(17182490729)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477458025),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatException_AuthorizationPolicyNotFound",
      "d": 2621545,
      "h": 21477458025,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21477458025)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77312032873),
    {
      "t": 122814465,
      "n": "s_resourceManager",
      "d": 2621545,
      "h": 77312032873,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77312032873),
//--TRIMMABLE-BOUNDARY-START(68722098281),
    {
      "t": 83951617,
      "n": "resourceCulture",
      "d": 2621545,
      "h": 68722098281,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68722098281)
  ],
  "h": 2621545,
  "a": [
    {
      "t": 54329345,
      "c": 12939231233,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "17.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70516737,
      "c": 4365484033
    },
    {
      "t": 125829121,
      "c": 4420796417
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621545)
        
        
        //--TRIMMABLE-BOUNDARY-START(458857)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext", ($self) => class AuthorizationHandlerContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885360745)
            /*HashSet<IAuthorizationRequirement>*/ _pendingRequirements = null;
            //--TRIMMABLE-BOUNDARY-END(12885360745)
            
            //--TRIMMABLE-BOUNDARY-START(8590393449)
            /*List<AuthorizationFailureReason>?*/ _failedReasons = null;
            //--TRIMMABLE-BOUNDARY-END(8590393449)
            
            //--TRIMMABLE-BOUNDARY-START(4295426153)
            /*bool*/ _failCalled = false;
            //--TRIMMABLE-BOUNDARY-END(4295426153)
            
            //--TRIMMABLE-BOUNDARY-START(17180328041)
            /*bool*/ _succeedCalled = false;
            //--TRIMMABLE-BOUNDARY-END(17180328041)
            
            //--TRIMMABLE-BOUNDARY-START(34360197225)
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    this.Requirements = requirements;
                    this.User = user;
                    this.Resource = resource;
                    this._pendingRequirements = new ($.$$.System.Collections.Generic.HashSet$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$3(requirements);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197225)
            
            //--TRIMMABLE-BOUNDARY-START(124554510441)
            /*IEnumerable<IAuthorizationRequirement>*/ Requirements = null;
            //--TRIMMABLE-BOUNDARY-END(124554510441)
            
            //--TRIMMABLE-BOUNDARY-START(137439412329)
            /*ClaimsPrincipal*/ User = null;
            //--TRIMMABLE-BOUNDARY-END(137439412329)
            
            //--TRIMMABLE-BOUNDARY-START(128849477737)
            /*object?*/ Resource = null;
            //--TRIMMABLE-BOUNDARY-END(128849477737)
            
            //--TRIMMABLE-BOUNDARY-START(120259543145)
            /*IEnumerable<IAuthorizationRequirement> */ get PendingRequirements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pendingRequirements;
            }
            //--TRIMMABLE-BOUNDARY-END(120259543145)
            
            //--TRIMMABLE-BOUNDARY-START(47245099113)
            /*IEnumerable<AuthorizationFailureReason> */ get FailureReasons()
            {
                return this._failedReasons ?? $.$$.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason);
            }
            //--TRIMMABLE-BOUNDARY-END(47245099113)
            
            //--TRIMMABLE-BOUNDARY-START(111669608553)
            /*bool */ get HasFailed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._failCalled;
            }
            //--TRIMMABLE-BOUNDARY-END(111669608553)
            
            //--TRIMMABLE-BOUNDARY-START(115964575849)
            /*bool */ get HasSucceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._failCalled && this._succeedCalled && !$.$sl.System.Linq.Enumerable.Any$1($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, this.PendingRequirements);
            }
            //--TRIMMABLE-BOUNDARY-END(115964575849)
            
            //--TRIMMABLE-BOUNDARY-START(38655164521)
            /*void */ Fail()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._failCalled = true;
            }
            //--TRIMMABLE-BOUNDARY-END(38655164521)
            
            //--TRIMMABLE-BOUNDARY-START(42950131817)
            /*void */ Fail$1(/*AuthorizationFailureReason*/ reason)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Fail();
                if (reason !== null)
                {
                    if (this._failedReasons === null)
                    {
                        this._failedReasons = new ($.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason))().$ctor$1();
                    }
                    this._failedReasons.Add(reason);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950131817)
            
            //--TRIMMABLE-BOUNDARY-START(133144445033)
            /*void */ Succeed(/*IAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144445033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._succeedCalled = true;
                this._pendingRequirements.Remove(requirement);
            }
            //--TRIMMABLE-BOUNDARY-END(133144445033)
            
            static $h = 458857;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554510441),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194772073,
        "f": 50331777
      },
      "n": "Requirements",
      "d": 458857,
      "h": 124554510441,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124554510441),
//--TRIMMABLE-BOUNDARY-START(137439412329),
    {
      "p": 393285,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374641257,
        "f": 50331777
      },
      "n": "User",
      "d": 458857,
      "h": 137439412329,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(137439412329),
//--TRIMMABLE-BOUNDARY-START(128849477737),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784706665,
        "f": 50331777
      },
      "n": "Resource",
      "d": 458857,
      "h": 128849477737,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(128849477737),
//--TRIMMABLE-BOUNDARY-START(120259543145),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604837481,
        "f": 50331777
      },
      "n": "PendingRequirements",
      "d": 458857,
      "h": 120259543145,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(120259543145),
//--TRIMMABLE-BOUNDARY-START(47245099113),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033705,
        "f": 50331777
      },
      "n": "FailureReasons",
      "d": 458857,
      "h": 47245099113,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47245099113),
//--TRIMMABLE-BOUNDARY-START(111669608553),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424968297,
        "f": 50331777
      },
      "n": "HasFailed",
      "d": 458857,
      "h": 111669608553,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111669608553),
//--TRIMMABLE-BOUNDARY-START(115964575849),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014902889,
        "f": 50331777
      },
      "n": "HasSucceeded",
      "d": 458857,
      "h": 115964575849,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(115964575849)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655164521),
    {
      "r": 65537,
      "n": "Fail",
      "d": 458857,
      "h": 38655164521,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38655164521),
//--TRIMMABLE-BOUNDARY-START(42950131817),
    {
      "r": 65537,
      "p": [
        {
          "n": "reason",
          "p": 262249
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 458857,
      "h": 42950131817,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950131817),
//--TRIMMABLE-BOUNDARY-START(133144445033),
    {
      "r": 65537,
      "p": [
        {
          "n": "requirement",
          "p": 1704041
        }
      ],
      "n": "Succeed",
      "d": 458857,
      "h": 133144445033,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(133144445033)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885360745),
    {
      "t": $.$$.System.Collections.Generic.HashSet$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
      "n": "_pendingRequirements",
      "d": 458857,
      "h": 12885360745,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360745),
//--TRIMMABLE-BOUNDARY-START(8590393449),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,
      "n": "_failedReasons",
      "d": 458857,
      "h": 8590393449,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393449),
//--TRIMMABLE-BOUNDARY-START(4295426153),
    {
      "t": 262145,
      "n": "_failCalled",
      "d": 458857,
      "h": 4295426153,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426153),
//--TRIMMABLE-BOUNDARY-START(17180328041),
    {
      "t": 262145,
      "n": "_succeedCalled",
      "d": 458857,
      "h": 17180328041,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180328041)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360197225),
    {
      "p": [
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458857,
      "h": 34360197225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197225)
  ],
  "h": 458857
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationHandlerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458857)
        
        
        //--TRIMMABLE-BOUNDARY-START(262249)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason", ($self) => class AuthorizationFailureReason extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885164137)
            $ctor$1(/*IAuthorizationHandler*/ handler, /*string*/ message)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164137);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Handler = handler;
                    this.Message = message;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164137)
            
            //--TRIMMABLE-BOUNDARY-START(38654967913)
            /*string*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(38654967913)
            
            //--TRIMMABLE-BOUNDARY-START(34360000617)
            /*IAuthorizationHandler*/ Handler = null;
            //--TRIMMABLE-BOUNDARY-END(34360000617)
            
            static $h = 262249;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654967913),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033321,
        "f": 50331649
      },
      "n": "Message",
      "d": 262249,
      "h": 38654967913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654967913),
//--TRIMMABLE-BOUNDARY-START(34360000617),
    {
      "p": 1441897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475098729,
        "f": 50331649
      },
      "n": "Handler",
      "d": 262249,
      "h": 34360000617,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000617)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885164137),
    {
      "p": [
        {
          "n": "handler",
          "p": 1441897
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262249,
      "h": 12885164137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164137)
  ],
  "h": 262249
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationFailureReason`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262249)
        
        
        //--TRIMMABLE-BOUNDARY-START(196713)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure", ($self) => class AuthorizationFailure extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295164009)
            /*AuthorizationFailure*/ static _explicitFailure = null;
            //--TRIMMABLE-BOUNDARY-END(4295164009)
            
            //--TRIMMABLE-BOUNDARY-START(25770000489)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770000489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000489)
            
            //--TRIMMABLE-BOUNDARY-START(34359935081)
            /*bool*/ FailCalled = false;
            //--TRIMMABLE-BOUNDARY-END(34359935081)
            
            //--TRIMMABLE-BOUNDARY-START(47244836969)
            /*IEnumerable<IAuthorizationRequirement>*/ FailedRequirements = null;
            //--TRIMMABLE-BOUNDARY-END(47244836969)
            
            //--TRIMMABLE-BOUNDARY-START(51539804265)
            /*IEnumerable<AuthorizationFailureReason>*/ FailureReasons = null;
            //--TRIMMABLE-BOUNDARY-END(51539804265)
            
            //--TRIMMABLE-BOUNDARY-START(30064967785)
            static /*AuthorizationFailure */ ExplicitFail()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064967785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure._explicitFailure;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064967785)
            
            //--TRIMMABLE-BOUNDARY-START(38654902377)
            static /*AuthorizationFailure */ Failed(/*IEnumerable<AuthorizationFailureReason>*/ reasons)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654902377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.FailCalled = true;
                        $i1.FailureReasons = reasons;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654902377)
            
            //--TRIMMABLE-BOUNDARY-START(42949869673)
            static /*AuthorizationFailure */ Failed$1(/*IEnumerable<IAuthorizationRequirement>*/ failed)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949869673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.FailedRequirements = failed;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949869673)
            
            //default member initializer
            constructor()
            {
                super();
                this.FailedRequirements = $.$$.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement);
                this.FailureReasons = $.$$.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason);
            }
            //--TRIMMABLE-BOUNDARY-START(21475033193)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295164009)
                    this._explicitFailure = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.FailCalled = true;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(4295164009)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033193)
            
            static $h = 196713;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359935081),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129738857,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899542633,
        "f": 83886082
      },
      "n": "FailCalled",
      "d": 196713,
      "h": 34359935081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359935081),
//--TRIMMABLE-BOUNDARY-START(47244836969),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719673449,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489477225,
        "f": 83886082
      },
      "n": "FailedRequirements",
      "d": 196713,
      "h": 47244836969,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244836969),
//--TRIMMABLE-BOUNDARY-START(51539804265),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309608041,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079411817,
        "f": 83886082
      },
      "n": "FailureReasons",
      "d": 196713,
      "h": 51539804265,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539804265)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064967785),
    {
      "r": 196713,
      "n": "ExplicitFail",
      "d": 196713,
      "h": 30064967785,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064967785),
//--TRIMMABLE-BOUNDARY-START(38654902377),
    {
      "r": 196713,
      "p": [
        {
          "n": "reasons",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h
        }
      ],
      "n": "Failed",
      "d": 196713,
      "h": 38654902377,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654902377),
//--TRIMMABLE-BOUNDARY-START(42949869673),
    {
      "r": 196713,
      "p": [
        {
          "n": "failed",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        }
      ],
      "n": "Failed",
      "o": "@$1",
      "d": 196713,
      "h": 42949869673,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949869673)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295164009),
    {
      "t": 196713,
      "n": "_explicitFailure",
      "d": 196713,
      "h": 4295164009,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295164009)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770000489),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196713,
      "h": 25770000489,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770000489)
  ],
  "h": 196713
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationFailure`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196713)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490473)
        $asm.$cls("$maa.Microsoft.Extensions.DependencyInjection.AuthorizationServiceCollectionExtensions", ($self) => class AuthorizationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8592425065)
            static /*IServiceCollection */ AddAuthorizationCore$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592425065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.AddMetrics$1(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$3($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics, $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationServiceImpl));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationPolicyProvider));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerProvider));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationEvaluator));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerContextFactory));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.PassThroughAuthorizationHandler));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(8592425065)
            
            //--TRIMMABLE-BOUNDARY-START(4297457769)
            static /*IServiceCollection */ AddAuthorizationCore(/*this IServiceCollection*/ services, /*Action<AuthorizationOptions>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297457769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configure, "configure");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, services, configure);
                return $.$maa.Microsoft.Extensions.DependencyInjection.AuthorizationServiceCollectionExtensions.AddAuthorizationCore$1(services);
            }
            //--TRIMMABLE-BOUNDARY-END(4297457769)
            
            static $h = 2490473;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592425065),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddAuthorizationCore",
      "o": "@$1",
      "d": 2490473,
      "h": 8592425065,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592425065),
//--TRIMMABLE-BOUNDARY-START(4297457769),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configure",
          "p": $.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h
        }
      ],
      "n": "AddAuthorizationCore",
      "d": 2490473,
      "h": 4297457769,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297457769)
  ],
  "h": 2490473
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490473)
        
        
        //--TRIMMABLE-BOUNDARY-START(852073)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions", ($self) => class AuthorizationServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590786665)
            static /*Task<AuthorizationResult> */ AuthorizeAsync$1(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*IAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirement, "requirement");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync(user, resource, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement), [requirement], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590786665)
            
            //--TRIMMABLE-BOUNDARY-START(4295819369)
            static /*Task<AuthorizationResult> */ AuthorizeAsync(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync(user, resource, policy.Requirements);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819369)
            
            //--TRIMMABLE-BOUNDARY-START(17180721257)
            static /*Task<AuthorizationResult> */ AuthorizeAsync$3(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync(service, user, null, policy);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721257)
            
            //--TRIMMABLE-BOUNDARY-START(12885753961)
            static /*Task<AuthorizationResult> */ AuthorizeAsync$2(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*string*/ policyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1(user, null, policyName);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753961)
            
            static $h = 852073;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590786665),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835113
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirement",
          "p": 1704041
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$1",
      "d": 852073,
      "h": 8590786665,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590786665),
//--TRIMMABLE-BOUNDARY-START(4295819369),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835113
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "AuthorizeAsync",
      "d": 852073,
      "h": 4295819369,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295819369),
//--TRIMMABLE-BOUNDARY-START(17180721257),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835113
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$3",
      "d": 852073,
      "h": 17180721257,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180721257),
//--TRIMMABLE-BOUNDARY-START(12885753961),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835113
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$2",
      "d": 852073,
      "h": 12885753961,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885753961)
  ],
  "h": 852073
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852073)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359401)
        $asm.$cls("$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4297326697)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297326697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4297326697)
            
            //--TRIMMABLE-BOUNDARY-START(8592293993)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592293993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8592293993)
            
            static $h = 2359401;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297326697),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2687081,
              "c": 8592621673,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 2359401,
      "h": 4297326697,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297326697),
//--TRIMMABLE-BOUNDARY-START(8592293993),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2687081,
              "c": 8592621673,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 2359401,
      "h": 8592293993,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592293993)
  ],
  "h": 2359401
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359401)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424937)
        $asm.$cls("$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers", ($self) => class DebuggerHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(12887326825)
            static /*string */ GetDebugText$1(/*string*/ key1, /*object?*/ value1, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1)], [-1], null)), includeNullValues, prefix);
            }
            //--TRIMMABLE-BOUNDARY-END(12887326825)
            
            //--TRIMMABLE-BOUNDARY-START(17182294121)
            static /*string */ GetDebugText$2(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182294121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key2, value2)], [-1], null)), includeNullValues, prefix);
            }
            //--TRIMMABLE-BOUNDARY-END(17182294121)
            
            //--TRIMMABLE-BOUNDARY-START(21477261417)
            static /*string */ GetDebugText$3(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*string*/ key3, /*object?*/ value3, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477261417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key2, value2), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key3, value3)], [-1], null)), includeNullValues, prefix);
            }
            //--TRIMMABLE-BOUNDARY-END(21477261417)
            
            //--TRIMMABLE-BOUNDARY-START(8592359529)
            static /*string */ GetDebugText(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ values, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592359529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (values.Length === 0)
                {
                    return prefix ?? $.$$.System.String.Empty;
                }
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    sb.Append$19(prefix);
                }
                /*var*/ let first = true;
                for(/*var*/ let i = 0; i < values.Length; i++)
                {
                    /*var*/ let kvp = values.get_Item(i).$v;
                    if ($.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.HasValue(kvp.Value) || includeNullValues)
                    {
                        if (first)
                        {
                            if ($.$$.System.String.op_Inequality(prefix, null))
                            {
                                sb.Append$3(/* */ 32);
                            }
                            first = false;
                        }
                        else 
                        {
                            sb.Append$19(", ");
                        }
                        sb.Append$19(kvp.Key);
                        sb.Append$19(": ");
                        let s;
                        let enumerable;
                        if (kvp.Value === null)
                        {
                            sb.Append$19("(null)");
                        }
                        else if ($.$is(kvp.Value, $.$$.System.String, { set $v(v){ s = v; } }))
                        {
                            sb.Append$19(s);
                        }
                        else if ($.$is(kvp.Value, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                        {
                            /*var*/ let firstItem = true;
                            var $en5 = enumerable.System$Collections$IEnumerable$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$IEnumerator$Current;
                                {
                                    if (firstItem)
                                    {
                                        firstItem = false;
                                    }
                                    else 
                                    {
                                        sb.Append$3(/*,*/ 44);
                                    }
                                    sb.Append$13(item);
                                }
                            }
                        }
                        else 
                        {
                            sb.Append$13(kvp.Value);
                        }
                    }
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //--TRIMMABLE-BOUNDARY-END(8592359529)
            
            //--TRIMMABLE-BOUNDARY-START(25772228713)
            static /*bool */ HasValue(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772228713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return false;
                }
                let enumerable;
                if (!(value !== null && ($.$is(value, $.$$.System.String))) && $.$is(value, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }) && !enumerable.System$Collections$IEnumerable$GetEnumerator().System$Collections$IEnumerator$MoveNext())
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25772228713)
            
            //--TRIMMABLE-BOUNDARY-START(4297392233)
            static /*KeyValuePair<string, object?> */ Create(/*string*/ key, /*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297392233);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(key, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297392233)
            
            static $h = 2424937;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887326825),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key1",
          "p": 1310721
        },
        {
          "n": "value1",
          "p": 131073
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "o": "@$1",
      "d": 2424937,
      "h": 12887326825,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887326825),
//--TRIMMABLE-BOUNDARY-START(17182294121),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key1",
          "p": 1310721
        },
        {
          "n": "value1",
          "p": 131073
        },
        {
          "n": "key2",
          "p": 1310721
        },
        {
          "n": "value2",
          "p": 131073
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "o": "@$2",
      "d": 2424937,
      "h": 17182294121,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182294121),
//--TRIMMABLE-BOUNDARY-START(21477261417),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key1",
          "p": 1310721
        },
        {
          "n": "value1",
          "p": 131073
        },
        {
          "n": "key2",
          "p": 1310721
        },
        {
          "n": "value2",
          "p": 131073
        },
        {
          "n": "key3",
          "p": 1310721
        },
        {
          "n": "value3",
          "p": 131073
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "o": "@$3",
      "d": 2424937,
      "h": 21477261417,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477261417),
//--TRIMMABLE-BOUNDARY-START(8592359529),
    {
      "r": 1310721,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "d": 2424937,
      "h": 8592359529,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592359529),
//--TRIMMABLE-BOUNDARY-START(25772228713),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "HasValue",
      "d": 2424937,
      "h": 25772228713,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25772228713),
//--TRIMMABLE-BOUNDARY-START(4297392233),
    {
      "r": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Create",
      "d": 2424937,
      "h": 4297392233,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297392233)
  ],
  "h": 2424937
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DebuggerHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424937)
        
        
        //--TRIMMABLE-BOUNDARY-START(721001)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder", ($self) => class AuthorizationPolicyBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688297)
            /*DenyAnonymousAuthorizationRequirement*/ static _denyAnonymousAuthorizationRequirement = null;
            //--TRIMMABLE-BOUNDARY-END(4295688297)
            
            //--TRIMMABLE-BOUNDARY-START(21475557481)
            $ctor$1(/*params string[]*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557481);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AddAuthenticationSchemes(authenticationSchemes);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557481)
            
            //--TRIMMABLE-BOUNDARY-START(25770524777)
            $ctor$2(/*AuthorizationPolicy*/ policy)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524777);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Combine(policy);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524777)
            
            //--TRIMMABLE-BOUNDARY-START(103079936105)
            /*IList<IAuthorizationRequirement>*/ Requirements = null;
            //--TRIMMABLE-BOUNDARY-END(103079936105)
            
            //--TRIMMABLE-BOUNDARY-START(47245361257)
            /*IList<string>*/ AuthenticationSchemes = null;
            //--TRIMMABLE-BOUNDARY-END(47245361257)
            
            //--TRIMMABLE-BOUNDARY-START(30065492073)
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemes(/*params string[]*/ schemes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065492073);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AddAuthenticationSchemesCore(schemes);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065492073)
            
            //--TRIMMABLE-BOUNDARY-START(34360459369)
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemesCore(/*IEnumerable<string>*/ schemes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = schemes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var authType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.AuthenticationSchemes.System$Collections$Generic$ICollection$$$Add(authType, [$.$$.System.String]);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360459369)
            
            //--TRIMMABLE-BOUNDARY-START(38655426665)
            /*AuthorizationPolicyBuilder */ AddRequirements(/*params IAuthorizationRequirement[]*/ requirements)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426665);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AddRequirementsCore(requirements);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655426665)
            
            //--TRIMMABLE-BOUNDARY-START(42950393961)
            /*AuthorizationPolicyBuilder */ AddRequirementsCore(/*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = requirements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var req = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.Requirements.System$Collections$Generic$ICollection$$$Add(req, [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393961)
            
            //--TRIMMABLE-BOUNDARY-START(55835295849)
            /*AuthorizationPolicyBuilder */ Combine(/*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.AddAuthenticationSchemesCore(policy.AuthenticationSchemes);
                this.AddRequirementsCore(policy.Requirements);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295849)
            
            //--TRIMMABLE-BOUNDARY-START(94490001513)
            /*AuthorizationPolicyBuilder */ RequireClaim$1(/*string*/ claimType, /*params string[]*/ allowedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                return this.RequireClaim(claimType, allowedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(94490001513)
            
            //--TRIMMABLE-BOUNDARY-START(90195034217)
            /*AuthorizationPolicyBuilder */ RequireClaim(/*string*/ claimType, /*IEnumerable<string>*/ allowedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement().$ctor$2(claimType, allowedValues), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90195034217)
            
            //--TRIMMABLE-BOUNDARY-START(98784968809)
            /*AuthorizationPolicyBuilder */ RequireClaim$2(/*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement().$ctor$2(claimType, null), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(98784968809)
            
            //--TRIMMABLE-BOUNDARY-START(111669870697)
            /*AuthorizationPolicyBuilder */ RequireRole$1(/*params string[]*/ roles)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                return this.RequireRole(roles);
            }
            //--TRIMMABLE-BOUNDARY-END(111669870697)
            
            //--TRIMMABLE-BOUNDARY-START(107374903401)
            /*AuthorizationPolicyBuilder */ RequireRole(/*IEnumerable<string>*/ roles)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement().$ctor$2(roles), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(107374903401)
            
            //--TRIMMABLE-BOUNDARY-START(115964837993)
            /*AuthorizationPolicyBuilder */ RequireUserName(/*string*/ userName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(userName, "userName");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement().$ctor$2(userName), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115964837993)
            
            //--TRIMMABLE-BOUNDARY-START(85900066921)
            /*AuthorizationPolicyBuilder */ RequireAuthenticatedUser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Requirements.System$Collections$Generic$ICollection$$$Add($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder._denyAnonymousAuthorizationRequirement, [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066921)
            
            //--TRIMMABLE-BOUNDARY-START(77310132329)
            /*AuthorizationPolicyBuilder */ RequireAssertion(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement().$ctor$1(handler), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310132329)
            
            //--TRIMMABLE-BOUNDARY-START(81605099625)
            /*AuthorizationPolicyBuilder */ RequireAssertion$1(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement().$ctor$2(handler), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605099625)
            
            //--TRIMMABLE-BOUNDARY-START(51540328553)
            /*AuthorizationPolicy */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy().$ctor$1(this.Requirements, $.$sl.System.Linq.Enumerable.Distinct$1($.$$.System.String, this.AuthenticationSchemes));
            }
            //--TRIMMABLE-BOUNDARY-END(51540328553)
            
            //default member initializer
            constructor()
            {
                super();
                this.Requirements = new ($.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$1();
                this.AuthenticationSchemes = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-START(17180590185)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688297)
                    this._denyAnonymousAuthorizationRequirement = new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(4295688297)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180590185)
            
            static $h = 721001;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079936105),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015165033,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144707177,
        "f": 83886081
      },
      "n": "Requirements",
      "d": 721001,
      "h": 103079936105,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079936105),
//--TRIMMABLE-BOUNDARY-START(47245361257),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425230441,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554772585,
        "f": 83886081
      },
      "n": "AuthenticationSchemes",
      "d": 721001,
      "h": 47245361257,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245361257)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065492073),
    {
      "r": 721001,
      "p": [
        {
          "n": "schemes",
          "p": $.$typeArray($.$$.System.String).$h,
          "f": 16
        }
      ],
      "n": "AddAuthenticationSchemes",
      "d": 721001,
      "h": 30065492073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065492073),
//--TRIMMABLE-BOUNDARY-START(34360459369),
    {
      "r": 721001,
      "p": [
        {
          "n": "schemes",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "AddAuthenticationSchemesCore",
      "d": 721001,
      "h": 34360459369,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360459369),
//--TRIMMABLE-BOUNDARY-START(38655426665),
    {
      "r": 721001,
      "p": [
        {
          "n": "requirements",
          "p": $.$typeArray($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
          "f": 16
        }
      ],
      "n": "AddRequirements",
      "d": 721001,
      "h": 38655426665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426665),
//--TRIMMABLE-BOUNDARY-START(42950393961),
    {
      "r": 721001,
      "p": [
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        }
      ],
      "n": "AddRequirementsCore",
      "d": 721001,
      "h": 42950393961,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393961),
//--TRIMMABLE-BOUNDARY-START(55835295849),
    {
      "r": 721001,
      "p": [
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "Combine",
      "d": 721001,
      "h": 55835295849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835295849),
//--TRIMMABLE-BOUNDARY-START(94490001513),
    {
      "r": 721001,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "allowedValues",
          "p": $.$typeArray($.$$.System.String).$h,
          "f": 16
        }
      ],
      "n": "RequireClaim",
      "o": "@$1",
      "d": 721001,
      "h": 94490001513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490001513),
//--TRIMMABLE-BOUNDARY-START(90195034217),
    {
      "r": 721001,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "allowedValues",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "RequireClaim",
      "d": 721001,
      "h": 90195034217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195034217),
//--TRIMMABLE-BOUNDARY-START(98784968809),
    {
      "r": 721001,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "RequireClaim",
      "o": "@$2",
      "d": 721001,
      "h": 98784968809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784968809),
//--TRIMMABLE-BOUNDARY-START(111669870697),
    {
      "r": 721001,
      "p": [
        {
          "n": "roles",
          "p": $.$typeArray($.$$.System.String).$h,
          "f": 16
        }
      ],
      "n": "RequireRole",
      "o": "@$1",
      "d": 721001,
      "h": 111669870697,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669870697),
//--TRIMMABLE-BOUNDARY-START(107374903401),
    {
      "r": 721001,
      "p": [
        {
          "n": "roles",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "RequireRole",
      "d": 721001,
      "h": 107374903401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374903401),
//--TRIMMABLE-BOUNDARY-START(115964837993),
    {
      "r": 721001,
      "p": [
        {
          "n": "userName",
          "p": 1310721
        }
      ],
      "n": "RequireUserName",
      "d": 721001,
      "h": 115964837993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964837993),
//--TRIMMABLE-BOUNDARY-START(85900066921),
    {
      "r": 721001,
      "n": "RequireAuthenticatedUser",
      "d": 721001,
      "h": 85900066921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900066921),
//--TRIMMABLE-BOUNDARY-START(77310132329),
    {
      "r": 721001,
      "p": [
        {
          "n": "handler",
          "p": $.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Boolean).$h
        }
      ],
      "n": "RequireAssertion",
      "d": 721001,
      "h": 77310132329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310132329),
//--TRIMMABLE-BOUNDARY-START(81605099625),
    {
      "r": 721001,
      "p": [
        {
          "n": "handler",
          "p": $.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)).$h
        }
      ],
      "n": "RequireAssertion",
      "o": "@$1",
      "d": 721001,
      "h": 81605099625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605099625),
//--TRIMMABLE-BOUNDARY-START(51540328553),
    {
      "r": 655465,
      "n": "Build",
      "d": 721001,
      "h": 51540328553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328553)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688297),
    {
      "t": 2031721,
      "n": "_denyAnonymousAuthorizationRequirement",
      "d": 721001,
      "h": 4295688297,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295688297)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557481),
    {
      "p": [
        {
          "n": "authenticationSchemes",
          "p": $.$typeArray($.$$.System.String).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721001,
      "h": 21475557481,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557481),
//--TRIMMABLE-BOUNDARY-START(25770524777),
    {
      "p": [
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721001,
      "h": 25770524777,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524777)
  ],
  "h": 721001
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationPolicyBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721001)
        
        
        //--TRIMMABLE-BOUNDARY-START(2556009)
        $asm.$cls("$maa.Microsoft.Extensions.Logging.LoggingExtensions", ($self) => class LoggingExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8592490601)
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.Exception?>*/ static __UserAuthorizationSucceededCallback = null;
            //--TRIMMABLE-BOUNDARY-END(8592490601)
            
            //--TRIMMABLE-BOUNDARY-START(25772359785)
            static /*void */ UserAuthorizationSucceeded(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772359785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                {
                    $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.__UserAuthorizationSucceededCallback.Invoke(logger, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772359785)
            
            //--TRIMMABLE-BOUNDARY-START(4297523305)
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __UserAuthorizationFailedCallback = null;
            //--TRIMMABLE-BOUNDARY-END(4297523305)
            
            //--TRIMMABLE-BOUNDARY-START(17182425193)
            static /*void */ UserAuthorizationFailed(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ reason)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182425193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/))
                {
                    $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.__UserAuthorizationFailedCallback.Invoke(logger, reason, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182425193)
            
            //--TRIMMABLE-BOUNDARY-START(21477392489)
            static /*void */ UserAuthorizationFailed$1(/*this ILogger*/ logger, /*AuthorizationFailure*/ failure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477392489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let reason = failure.FailCalled ? "Fail() was explicitly called." : "These requirements were not met:" + $.$$.System.Environment.NewLine + $.$$.System.String.Join$12($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, $.$$.System.Environment.NewLine, failure.FailedRequirements);
                $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationFailed(logger, reason);
            }
            //--TRIMMABLE-BOUNDARY-END(21477392489)
            
            //--TRIMMABLE-BOUNDARY-START(12887457897)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8592490601)
                    this.__UserAuthorizationSucceededCallback = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mexla.Microsoft.Extensions.Logging.EventId().$ctor$3(1, "UserAuthorizationSucceeded"), "Authorization was successful.", (() =>
                    {
                        //new $.$mexla.Microsoft.Extensions.Logging.LogDefineOptions()
                        const $t1 = $.$mexla.Microsoft.Extensions.Logging.LogDefineOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SkipEnabledCheck = true;
                        return $i1;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(8592490601)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4297523305)
                    this.__UserAuthorizationFailedCallback = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$12($.$$.System.String, 2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/, new $.$mexla.Microsoft.Extensions.Logging.EventId().$ctor$3(2, "UserAuthorizationFailed"), "Authorization failed. {Reason}", (() =>
                    {
                        //new $.$mexla.Microsoft.Extensions.Logging.LogDefineOptions()
                        const $t1 = $.$mexla.Microsoft.Extensions.Logging.LogDefineOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SkipEnabledCheck = true;
                        return $i1;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(4297523305)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887457897)
            
            static $h = 2556009;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772359785),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "UserAuthorizationSucceeded",
      "d": 2556009,
      "h": 25772359785,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 30066999384,
          "a": [
            {
              "v": 1,
              "t": 655361
            },
            {
              "v": 1,
              "t": 2293848
            },
            {
              "v": "Authorization was successful.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "UserAuthorizationSucceeded",
              "t": 1310721
            }
          ]
        },
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772359785),
//--TRIMMABLE-BOUNDARY-START(17182425193),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "reason",
          "p": 1310721
        }
      ],
      "n": "UserAuthorizationFailed",
      "d": 2556009,
      "h": 17182425193,
      "f": 16777250,
      "a": [
        {
          "t": 2228312,
          "c": 30066999384,
          "a": [
            {
              "v": 2,
              "t": 655361
            },
            {
              "v": 2,
              "t": 2293848
            },
            {
              "v": "Authorization failed. {Reason}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "UserAuthorizationFailed",
              "t": 1310721
            }
          ]
        },
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182425193),
//--TRIMMABLE-BOUNDARY-START(21477392489),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "failure",
          "p": 196713
        }
      ],
      "n": "UserAuthorizationFailed",
      "o": "@$1",
      "d": 2556009,
      "h": 21477392489,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477392489)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592490601),
    {
      "t": $.$$.System.Action$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.Exception).$h,
      "n": "__UserAuthorizationSucceededCallback",
      "d": 2556009,
      "h": 8592490601,
      "f": 4194338,
      "a": [
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592490601),
//--TRIMMABLE-BOUNDARY-START(4297523305),
    {
      "t": $.$$.System.Action$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.String, $.$$.System.Exception).$h,
      "n": "__UserAuthorizationFailedCallback",
      "d": 2556009,
      "h": 4297523305,
      "f": 4194338,
      "a": [
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297523305)
  ],
  "h": 2556009
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggingExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2556009)
        
        
        //--TRIMMABLE-BOUNDARY-START(131177)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationBuilder", ($self) => class AuthorizationBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590065769)
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065769);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065769)
            
            //--TRIMMABLE-BOUNDARY-START(47244771433)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(47244771433)
            
            //--TRIMMABLE-BOUNDARY-START(60129673321)
            /*AuthorizationBuilder */ SetInvokeHandlersAfterFailure(/*bool*/ invoke)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.InvokeHandlersAfterFailure = invoke;
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 589929
    }
  ],
  "n": "",
  "d": 131177,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673321)
            
            //--TRIMMABLE-BOUNDARY-START(51539738729)
            /*AuthorizationBuilder */ SetDefaultPolicy(/*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.DefaultPolicy = policy;
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 589929
    }
  ],
  "n": "",
  "d": 131177,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738729)
            
            //--TRIMMABLE-BOUNDARY-START(55834706025)
            /*AuthorizationBuilder */ SetFallbackPolicy(/*AuthorizationPolicy?*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.FallbackPolicy = policy;
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 589929
    }
  ],
  "n": "",
  "d": 131177,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706025)
            
            //--TRIMMABLE-BOUNDARY-START(34359869545)
            /*AuthorizationBuilder */ AddPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy$1(name, policy);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 589929
    }
  ],
  "n": "",
  "d": 131177,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359869545)
            
            //--TRIMMABLE-BOUNDARY-START(30064902249)
            /*AuthorizationBuilder */ AddPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy(name, configurePolicy);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 589929
    }
  ],
  "n": "",
  "d": 131177,
  "h": 0,
  "f": 17825794
}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902249)
            
            //--TRIMMABLE-BOUNDARY-START(17180000361)
            /*AuthorizationBuilder */ AddDefaultPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDefaultPolicy(policy);
                return this.AddPolicy$1(name, policy);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000361)
            
            //--TRIMMABLE-BOUNDARY-START(12885033065)
            /*AuthorizationBuilder */ AddDefaultPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddDefaultPolicy$1(name, policyBuilder.Build());
            }
            //--TRIMMABLE-BOUNDARY-END(12885033065)
            
            //--TRIMMABLE-BOUNDARY-START(25769934953)
            /*AuthorizationBuilder */ AddFallbackPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetFallbackPolicy(policy);
                return this.AddPolicy$1(name, policy);
            }
            //--TRIMMABLE-BOUNDARY-END(25769934953)
            
            //--TRIMMABLE-BOUNDARY-START(21474967657)
            /*AuthorizationBuilder */ AddFallbackPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddFallbackPolicy$1(name, policyBuilder.Build());
            }
            //--TRIMMABLE-BOUNDARY-END(21474967657)
            
            static $h = 131177;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244771433),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949804137,
        "f": 50331777
      },
      "n": "Services",
      "d": 131177,
      "h": 47244771433,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47244771433)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129673321),
    {
      "r": 131177,
      "p": [
        {
          "n": "invoke",
          "p": 262145
        }
      ],
      "n": "SetInvokeHandlersAfterFailure",
      "d": 131177,
      "h": 60129673321,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60129673321),
//--TRIMMABLE-BOUNDARY-START(51539738729),
    {
      "r": 131177,
      "p": [
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "SetDefaultPolicy",
      "d": 131177,
      "h": 51539738729,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51539738729),
//--TRIMMABLE-BOUNDARY-START(55834706025),
    {
      "r": 131177,
      "p": [
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "SetFallbackPolicy",
      "d": 131177,
      "h": 55834706025,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55834706025),
//--TRIMMABLE-BOUNDARY-START(34359869545),
    {
      "r": 131177,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "AddPolicy",
      "o": "@$1",
      "d": 131177,
      "h": 34359869545,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34359869545),
//--TRIMMABLE-BOUNDARY-START(30064902249),
    {
      "r": 131177,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddPolicy",
      "d": 131177,
      "h": 30064902249,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30064902249),
//--TRIMMABLE-BOUNDARY-START(17180000361),
    {
      "r": 131177,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "AddDefaultPolicy",
      "o": "@$1",
      "d": 131177,
      "h": 17180000361,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180000361),
//--TRIMMABLE-BOUNDARY-START(12885033065),
    {
      "r": 131177,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddDefaultPolicy",
      "d": 131177,
      "h": 12885033065,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885033065),
//--TRIMMABLE-BOUNDARY-START(25769934953),
    {
      "r": 131177,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655465
        }
      ],
      "n": "AddFallbackPolicy",
      "o": "@$1",
      "d": 131177,
      "h": 25769934953,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25769934953),
//--TRIMMABLE-BOUNDARY-START(21474967657),
    {
      "r": 131177,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddFallbackPolicy",
      "d": 131177,
      "h": 21474967657,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21474967657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065769),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131177,
      "h": 8590065769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065769)
  ],
  "h": 131177
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131177)
        
        
        //--TRIMMABLE-BOUNDARY-START(655465)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy", ($self) => class AuthorizationPolicy extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885557353)
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*IEnumerable<string>*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(authenticationSchemes, "authenticationSchemes");
                    if (!$.$sl.System.Linq.Enumerable.Any$1($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, requirements))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$maa.Resources.Exception_AuthorizationPolicyEmpty);
                    }
                    this.Requirements = new ($.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$2(requirements).AsReadOnly();
                    this.AuthenticationSchemes = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$2(authenticationSchemes).AsReadOnly();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557353)
            
            //--TRIMMABLE-BOUNDARY-START(55835230313)
            /*IReadOnlyList<IAuthorizationRequirement>*/ Requirements = null;
            //--TRIMMABLE-BOUNDARY-END(55835230313)
            
            //--TRIMMABLE-BOUNDARY-START(17180524649)
            /*IReadOnlyList<string>*/ AuthenticationSchemes = null;
            //--TRIMMABLE-BOUNDARY-END(17180524649)
            
            //--TRIMMABLE-BOUNDARY-START(25770459241)
            static /*AuthorizationPolicy */ Combine$1(/*params AuthorizationPolicy[]*/ policies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.Combine(policies);
            }
            //--TRIMMABLE-BOUNDARY-END(25770459241)
            
            //--TRIMMABLE-BOUNDARY-START(21475491945)
            static /*AuthorizationPolicy */ Combine(/*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                /*var*/ let builder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                var $en2 = policies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var policy = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        builder.Combine(policy);
                    }
                }
                return builder.Build();
            }
            //--TRIMMABLE-BOUNDARY-END(21475491945)
            
            //--TRIMMABLE-BOUNDARY-START(34360393833)
            static /*Task<AuthorizationPolicy?> */ CombineAsync$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360393833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.CombineAsync(policyProvider, authorizeData, $.$sl.System.Linq.Enumerable.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360393833)
            
            //--TRIMMABLE-BOUNDARY-START(30065426537)
            static /*Task<AuthorizationPolicy?> *//*async*/  CombineAsync(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData, /*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065426537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(authorizeData, "authorizeData");
                    /*var*/ let anyPolicies = $.$sl.System.Linq.Enumerable.Any$1($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policies);
                    /*var*/ let skipEnumeratingData = false;
                    let dataList;
                    if ($.$is(authorizeData, $.$$.System.Collections.Generic.IList$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData), { set $v(v){ dataList = v; } }))
                    {
                        skipEnumeratingData = dataList.System$Collections$Generic$ICollection$$$Count === 0;
                    }
                    /*AuthorizationPolicyBuilder?*/ let policyBuilder = null;
                    if (!skipEnumeratingData)
                    {
                        var $en4 = authorizeData.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var authorizeDatum = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (policyBuilder === null)
                                {
                                    policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                                }
                                /*var*/ let useDefaultPolicy = !(anyPolicies);
                                if (!$.$$.System.String.IsNullOrWhiteSpace(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy))
                                {
                                    /*var*/ let policy = await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy).ConfigureAwait$2(false);
                                    if (policy === null)
                                    {
                                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$maa.Resources.FormatException_AuthorizationPolicyNotFound(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy));
                                    }
                                    policyBuilder.Combine(policy);
                                    useDefaultPolicy = false;
                                }
                                const $t1 = () => authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles;
                                /*var*/ let rolesSplit = $.$ifnn($t1, ($t) => $.$$.System.String.Split$1.call($t, /*,*/ 44, 0));
                                const $t2 = rolesSplit;
                                if ($.$$.System.Int32.op_GreaterThan$1($.$ifnn($t2, ($t) => $t.length), 0))
                                {
                                    /*var*/ let trimmedRolesSplit = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.String, $.$$.System.String, $.$sl.System.Linq.Enumerable.Where($.$$.System.String, rolesSplit, new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.Boolean))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return !$.$$.System.String.IsNullOrWhiteSpace(r);
                                    }, {
  "r": 262145,
  "p": [
    {
      "n": "r",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 655465,
  "h": 0,
  "f": 17825794
})), new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.String))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return $.$$.System.String.Trim.call(r);
                                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "r",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 655465,
  "h": 0,
  "f": 17825794
}));
                                    policyBuilder.RequireRole(trimmedRolesSplit);
                                    useDefaultPolicy = false;
                                }
                                const $t3 = () => authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes;
                                /*var*/ let authTypesSplit = $.$ifnn($t3, ($t) => $.$$.System.String.Split$1.call($t, /*,*/ 44, 0));
                                const $t4 = authTypesSplit;
                                if ($.$$.System.Int32.op_GreaterThan$1($.$ifnn($t4, ($t) => $t.length), 0))
                                {
                                    let $i5 = 0;
                                    let $arr5 = authTypesSplit;
                                    while ($i5 < $arr5.length)
                                    {
                                        let authType = $arr5[$i5++];
                                        if (!$.$$.System.String.IsNullOrWhiteSpace(authType))
                                        {
                                            policyBuilder.AuthenticationSchemes.System$Collections$Generic$ICollection$$$Add($.$$.System.String.Trim.call(authType), [$.$$.System.String]);
                                        }
                                    }
                                }
                                if (useDefaultPolicy)
                                {
                                    policyBuilder.Combine(await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync().ConfigureAwait$2(false));
                                }
                            }
                        }
                    }
                    if (anyPolicies)
                    {
                        policyBuilder ??= new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                        var $en4 = policies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var policy = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                policyBuilder.Combine(policy);
                            }
                        }
                    }
                    if (policyBuilder === null)
                    {
                        /*var*/ let fallbackPolicy = await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync().ConfigureAwait$2(false);
                        if (fallbackPolicy !== null)
                        {
                            return fallbackPolicy;
                        }
                    }
                    return policyBuilder?.Build() ?? null;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065426537)
            
            static $h = 655465;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835230313),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540263017,
        "f": 50331649
      },
      "n": "Requirements",
      "d": 655465,
      "h": 55835230313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835230313),
//--TRIMMABLE-BOUNDARY-START(17180524649),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950328425,
        "f": 50331649
      },
      "n": "AuthenticationSchemes",
      "d": 655465,
      "h": 17180524649,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524649)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770459241),
    {
      "r": 655465,
      "p": [
        {
          "n": "policies",
          "p": $.$typeArray($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
          "f": 16
        }
      ],
      "n": "Combine",
      "o": "@$1",
      "d": 655465,
      "h": 25770459241,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770459241),
//--TRIMMABLE-BOUNDARY-START(21475491945),
    {
      "r": 655465,
      "p": [
        {
          "n": "policies",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h
        }
      ],
      "n": "Combine",
      "d": 655465,
      "h": 21475491945,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475491945),
//--TRIMMABLE-BOUNDARY-START(34360393833),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyProvider",
          "p": 1638505
        },
        {
          "n": "authorizeData",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h
        }
      ],
      "n": "CombineAsync",
      "o": "@$1",
      "d": 655465,
      "h": 34360393833,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360393833),
//--TRIMMABLE-BOUNDARY-START(30065426537),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyProvider",
          "p": 1638505
        },
        {
          "n": "authorizeData",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h
        },
        {
          "n": "policies",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h
        }
      ],
      "n": "CombineAsync",
      "d": 655465,
      "h": 30065426537,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(30065426537)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557353),
    {
      "p": [
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        },
        {
          "n": "authenticationSchemes",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655465,
      "h": 12885557353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557353)
  ],
  "h": 655465
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationPolicy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655465)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048681)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerContextFactory", ($self) => class DefaultAuthorizationHandlerContextFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590983273)
            /*AuthorizationHandlerContext */ CreateContext(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext().$ctor$1(requirements, user, resource);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983273)
            
            //--TRIMMABLE-BOUNDARY-START(4296474729)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory.CreateContext(System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>, System.Security.Claims.ClaimsPrincipal, object?)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296474729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateContext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296474729)
            
            //--TRIMMABLE-BOUNDARY-START(4296015977)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015977)
            
            static $h = 1048681;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983273),
    {
      "r": 458857,
      "p": [
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        }
      ],
      "n": "CreateContext",
      "d": 1048681,
      "h": 8590983273,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590983273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015977),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048681,
      "h": 4296015977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015977)
  ],
  "i": [1507433
  ],
  "h": 1048681
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory ]; }
            static get $fullName() { return `DefaultAuthorizationHandlerContextFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048681)
        
        
        //--TRIMMABLE-BOUNDARY-START(983145)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationEvaluator", ($self) => class DefaultAuthorizationEvaluator extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590917737)
            /*AuthorizationResult */ Evaluate(/*AuthorizationHandlerContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917737);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return context.HasSucceeded ? $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult.Success() : $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult.Failed$1(context.HasFailed ? $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.Failed(context.FailureReasons) : $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.Failed$1(context.PendingRequirements));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590917737)
            
            //--TRIMMABLE-BOUNDARY-START(4296343657)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator.Evaluate(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Evaluate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296343657)
            
            //--TRIMMABLE-BOUNDARY-START(4295950441)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950441)
            
            static $h = 983145;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917737),
    {
      "r": 786537,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "Evaluate",
      "d": 983145,
      "h": 8590917737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917737)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950441),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983145,
      "h": 4295950441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950441)
  ],
  "i": [1376361
  ],
  "h": 983145
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator ]; }
            static get $fullName() { return `DefaultAuthorizationEvaluator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983145)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179753)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationPolicyProvider", ($self) => class DefaultAuthorizationPolicyProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886081641)
            /*AuthorizationOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(12886081641)
            
            //--TRIMMABLE-BOUNDARY-START(4296147049)
            /*Task<AuthorizationPolicy>?*/ _cachedDefaultPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(4296147049)
            
            //--TRIMMABLE-BOUNDARY-START(8591114345)
            /*Task<AuthorizationPolicy?>?*/ _cachedFallbackPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(8591114345)
            
            //--TRIMMABLE-BOUNDARY-START(17181048937)
            $ctor$1(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181048937);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048937)
            
            //--TRIMMABLE-BOUNDARY-START(21476016233)
            /*Task<AuthorizationPolicy> */ GetDefaultPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._cachedDefaultPolicy === null || this._cachedDefaultPolicy.Result !== this._options.DefaultPolicy)
                {
                    this._cachedDefaultPolicy = $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, this._options.DefaultPolicy);
                }
                return this._cachedDefaultPolicy;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016233)
            
            //--TRIMMABLE-BOUNDARY-START(25770983529)
            /*Task<AuthorizationPolicy?> */ GetFallbackPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._cachedFallbackPolicy === null || this._cachedFallbackPolicy.Result !== this._options.FallbackPolicy)
                {
                    this._cachedFallbackPolicy = $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, this._options.FallbackPolicy);
                }
                return this._cachedFallbackPolicy;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983529)
            
            //--TRIMMABLE-BOUNDARY-START(30065950825)
            /*Task<AuthorizationPolicy?> */ GetPolicyAsync(/*string*/ policyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._options.GetPolicyTask(policyName);
            }
            //--TRIMMABLE-BOUNDARY-END(30065950825)
            
            //--TRIMMABLE-BOUNDARY-START(12886540393)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetPolicyAsync(string)
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886540393)
            
            //--TRIMMABLE-BOUNDARY-START(4296605801)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetDefaultPolicyAsync()
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDefaultPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296605801)
            
            //--TRIMMABLE-BOUNDARY-START(8591573097)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetFallbackPolicyAsync()
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFallbackPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591573097)
            
            static $h = 1179753;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476016233),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "n": "GetDefaultPolicyAsync",
      "d": 1179753,
      "h": 21476016233,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016233),
//--TRIMMABLE-BOUNDARY-START(25770983529),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "n": "GetFallbackPolicyAsync",
      "d": 1179753,
      "h": 25770983529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770983529),
//--TRIMMABLE-BOUNDARY-START(30065950825),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "GetPolicyAsync",
      "d": 1179753,
      "h": 30065950825,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065950825)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886081641),
    {
      "t": 589929,
      "n": "_options",
      "d": 1179753,
      "h": 12886081641,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081641),
//--TRIMMABLE-BOUNDARY-START(4296147049),
    {
      "t": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "n": "_cachedDefaultPolicy",
      "d": 1179753,
      "h": 4296147049,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147049),
//--TRIMMABLE-BOUNDARY-START(8591114345),
    {
      "t": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "n": "_cachedFallbackPolicy",
      "d": 1179753,
      "h": 8591114345,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114345)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048937),
    {
      "p": [
        {
          "n": "options",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179753,
      "h": 17181048937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048937)
  ],
  "i": [1638505
  ],
  "h": 1179753
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider ]; }
            static get $fullName() { return `DefaultAuthorizationPolicyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179753)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245289)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService", ($self) => class DefaultAuthorizationService extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476081769)
            /*AuthorizationOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(21476081769)
            
            //--TRIMMABLE-BOUNDARY-START(4296212585)
            /*IAuthorizationHandlerContextFactory*/ _contextFactory = null;
            //--TRIMMABLE-BOUNDARY-END(4296212585)
            
            //--TRIMMABLE-BOUNDARY-START(12886147177)
            /*IAuthorizationHandlerProvider*/ _handlers = null;
            //--TRIMMABLE-BOUNDARY-END(12886147177)
            
            //--TRIMMABLE-BOUNDARY-START(8591179881)
            /*IAuthorizationEvaluator*/ _evaluator = null;
            //--TRIMMABLE-BOUNDARY-END(8591179881)
            
            //--TRIMMABLE-BOUNDARY-START(25771049065)
            /*IAuthorizationPolicyProvider*/ _policyProvider = null;
            //--TRIMMABLE-BOUNDARY-END(25771049065)
            
            //--TRIMMABLE-BOUNDARY-START(17181114473)
            /*ILogger*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(17181114473)
            
            //--TRIMMABLE-BOUNDARY-START(30066016361)
            $ctor$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IAuthorizationHandlerProvider*/ handlers, /*ILogger<DefaultAuthorizationService>*/ logger, /*IAuthorizationHandlerContextFactory*/ contextFactory, /*IAuthorizationEvaluator*/ evaluator, /*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066016361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(contextFactory, "contextFactory");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(evaluator, "evaluator");
                    this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                    this._handlers = handlers;
                    this._policyProvider = policyProvider;
                    this._logger = logger;
                    this._evaluator = evaluator;
                    this._contextFactory = contextFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066016361)
            
            //--TRIMMABLE-BOUNDARY-START(34360983657)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360983657);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    /*var*/ let authContext = this._contextFactory.Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext(requirements, user, resource);
                    /*var*/ let handlers = await this._handlers.Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync(authContext).ConfigureAwait$2(false);
                    var $en3 = handlers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var handler = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await handler.Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync(authContext).ConfigureAwait(false);
                            if (!this._options.InvokeHandlersAfterFailure && authContext.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                    /*var*/ let result = this._evaluator.Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate(authContext);
                    if (result.Succeeded)
                    {
                        $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationSucceeded(this._logger);
                    }
                    else 
                    {
                        $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationFailed$1(this._logger, result.Failure);
                    }
                    return result;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360983657)
            
            //--TRIMMABLE-BOUNDARY-START(38655950953)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655950953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let policy = await this.GetPolicyAsync(policyName).ConfigureAwait$2(false);
                    return await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync(this, user, resource, policy).ConfigureAwait$2(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655950953)
            
            //--TRIMMABLE-BOUNDARY-START(42950918249)
            /*Task<AuthorizationPolicy> *//*async*/  GetPolicyAsync(/*string*/ policyName)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950918249);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                    return $.$firstOf(await this._policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync(policyName).ConfigureAwait$2(false), () => { throw new $.$$.System.InvalidOperationException().$ctor$12(`No policy found: ${policyName}.`) });
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950918249)
            
            //--TRIMMABLE-BOUNDARY-START(4296802409)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>)
            Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthorizeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296802409)
            
            //--TRIMMABLE-BOUNDARY-START(8591769705)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, string)
            Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthorizeAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591769705)
            
            static $h = 1245289;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360983657),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        }
      ],
      "n": "AuthorizeAsync",
      "d": 1245289,
      "h": 34360983657,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(34360983657),
//--TRIMMABLE-BOUNDARY-START(38655950953),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$1",
      "d": 1245289,
      "h": 38655950953,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(38655950953),
//--TRIMMABLE-BOUNDARY-START(42950918249),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "GetPolicyAsync",
      "d": 1245289,
      "h": 42950918249,
      "f": 16781312
    },
//--TRIMMABLE-BOUNDARY-END(42950918249)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476081769),
    {
      "t": 589929,
      "n": "_options",
      "d": 1245289,
      "h": 21476081769,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476081769),
//--TRIMMABLE-BOUNDARY-START(4296212585),
    {
      "t": 1507433,
      "n": "_contextFactory",
      "d": 1245289,
      "h": 4296212585,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212585),
//--TRIMMABLE-BOUNDARY-START(12886147177),
    {
      "t": 1572969,
      "n": "_handlers",
      "d": 1245289,
      "h": 12886147177,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147177),
//--TRIMMABLE-BOUNDARY-START(8591179881),
    {
      "t": 1376361,
      "n": "_evaluator",
      "d": 1245289,
      "h": 8591179881,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179881),
//--TRIMMABLE-BOUNDARY-START(25771049065),
    {
      "t": 1638505,
      "n": "_policyProvider",
      "d": 1245289,
      "h": 25771049065,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771049065),
//--TRIMMABLE-BOUNDARY-START(17181114473),
    {
      "t": 917592,
      "n": "_logger",
      "d": 1245289,
      "h": 17181114473,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181114473)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066016361),
    {
      "p": [
        {
          "n": "policyProvider",
          "p": 1638505
        },
        {
          "n": "handlers",
          "p": 1572969
        },
        {
          "n": "logger",
          "p": $.$mexla.Microsoft.Extensions.Logging.ILogger$$($.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService).$h
        },
        {
          "n": "contextFactory",
          "p": 1507433
        },
        {
          "n": "evaluator",
          "p": 1376361
        },
        {
          "n": "options",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245289,
      "h": 30066016361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066016361)
  ],
  "i": [1835113
  ],
  "h": 1245289
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService ]; }
            static get $fullName() { return `DefaultAuthorizationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245289)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162793)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.OperationAuthorizationRequirement", ($self) => class OperationAuthorizationRequirement extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476999273)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(21476999273)
            
            //--TRIMMABLE-BOUNDARY-START(34361901161)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${"OperationAuthorizationRequirement"}:Name=${this.Name}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.OperationAuthorizationRequirement.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34361901161)
            
            //--TRIMMABLE-BOUNDARY-START(8592097385)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592097385)
            
            //default member initializer
            constructor()
            {
                super();
                this.Name = null;
            }
            static $h = 2162793;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476999273),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182031977,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066933865,
        "f": 83886081
      },
      "n": "Name",
      "d": 2162793,
      "h": 21476999273,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476999273)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361901161),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2162793,
      "h": 34361901161,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361901161)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592097385),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162793,
      "h": 8592097385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592097385)
  ],
  "i": [1704041
  ],
  "h": 2162793
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `OperationAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162793)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228329)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.PassThroughAuthorizationHandler", ($self) => class PassThroughAuthorizationHandler extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297195625)
            /*AuthorizationOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(4297195625)
            
            //--TRIMMABLE-BOUNDARY-START(8592162921)
            $ctor$1()
            {
                this.$ctor$2($.$meo.Microsoft.Extensions.Options.Options.Create($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions().$ctor$1()));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592162921);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592162921)
            
            //--TRIMMABLE-BOUNDARY-START(12887130217)
            $ctor$2(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887130217);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887130217)
            
            //--TRIMMABLE-BOUNDARY-START(17182097513)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182097513);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    var $en3 = $.$sl.System.Linq.Enumerable.OfType($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var handler = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await handler.Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync(context).ConfigureAwait(false);
                            if (!this._options.InvokeHandlersAfterFailure && context.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182097513)
            
            //--TRIMMABLE-BOUNDARY-START(4296409193)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409193)
            
            static $h = 2228329;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182097513),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "HandleAsync",
      "d": 2228329,
      "h": 17182097513,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17182097513)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297195625),
    {
      "t": 589929,
      "n": "_options",
      "d": 2228329,
      "h": 4297195625,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297195625)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592162921),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228329,
      "h": 8592162921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592162921),
//--TRIMMABLE-BOUNDARY-START(12887130217),
    {
      "p": [
        {
          "n": "options",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228329,
      "h": 12887130217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887130217)
  ],
  "i": [1441897
  ],
  "h": 2228329
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `PassThroughAuthorizationHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228329)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114217)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerProvider", ($self) => class DefaultAuthorizationHandlerProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296081513)
            /*Task<IEnumerable<IAuthorizationHandler>>*/ _handlersTask = null;
            //--TRIMMABLE-BOUNDARY-END(4296081513)
            
            //--TRIMMABLE-BOUNDARY-START(8591048809)
            $ctor$1(/*IEnumerable<IAuthorizationHandler>*/ handlers)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591048809);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    this._handlersTask = $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler), handlers);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591048809)
            
            //--TRIMMABLE-BOUNDARY-START(12886016105)
            /*Task<IEnumerable<IAuthorizationHandler>> */ GetHandlersAsync(/*AuthorizationHandlerContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886016105);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._handlersTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886016105)
            
            //--TRIMMABLE-BOUNDARY-START(4296540265)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider.GetHandlersAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHandlersAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296540265)
            
            static $h = 1114217;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886016105),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "GetHandlersAsync",
      "d": 1114217,
      "h": 12886016105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016105)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081513),
    {
      "t": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,
      "n": "_handlersTask",
      "d": 1114217,
      "h": 4296081513,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081513)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048809),
    {
      "p": [
        {
          "n": "handlers",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114217,
      "h": 8591048809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048809)
  ],
  "i": [1572969
  ],
  "h": 1114217
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider ]; }
            static get $fullName() { return `DefaultAuthorizationHandlerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114217)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900649)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement", ($self) => class AssertionRequirement extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066671721)
            /*Func<AuthorizationHandlerContext, Task<bool>>*/ Handler = null;
            //--TRIMMABLE-BOUNDARY-END(30066671721)
            
            //--TRIMMABLE-BOUNDARY-START(8591835241)
            $ctor$1(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591835241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = new ($.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)))().$ctor(this,  (/**/ context) =>
                    {
                        return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Boolean, handler.Invoke(context));
                    }, {
  "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,
  "p": [
    {
      "n": "context",
      "p": 458857
    }
  ],
  "n": "",
  "d": 1900649,
  "h": 0,
  "f": 17825794
});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591835241)
            
            //--TRIMMABLE-BOUNDARY-START(12886802537)
            $ctor$2(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886802537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = handler;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886802537)
            
            //--TRIMMABLE-BOUNDARY-START(25771704425)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771704425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (await this.Handler.Invoke(context).ConfigureAwait$2(false))
                    {
                        context.Succeed(this);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25771704425)
            
            //--TRIMMABLE-BOUNDARY-START(34361639017)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361639017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${"Handler"} assertion should evaluate to true.`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34361639017)
            
            //--TRIMMABLE-BOUNDARY-START(4296409193)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409193)
            
            static $h = 1900649;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066671721),
    {
      "p": $.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476737129,
        "f": 50331649
      },
      "n": "Handler",
      "d": 1900649,
      "h": 30066671721,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066671721)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771704425),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        }
      ],
      "n": "HandleAsync",
      "d": 1900649,
      "h": 25771704425,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25771704425),
//--TRIMMABLE-BOUNDARY-START(34361639017),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1900649,
      "h": 34361639017,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361639017)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591835241),
    {
      "p": [
        {
          "n": "handler",
          "p": $.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900649,
      "h": 8591835241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591835241),
//--TRIMMABLE-BOUNDARY-START(12886802537),
    {
      "p": [
        {
          "n": "handler",
          "p": $.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900649,
      "h": 12886802537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802537)
  ],
  "i": [1441897,1704041
  ],
  "h": 1900649
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `AssertionRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900649)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687081)
        $asm.$cls("$maa.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592621673)
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592621673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ParameterName = parameterName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592621673)
            
            //--TRIMMABLE-BOUNDARY-START(21477523561)
            /*string*/ ParameterName = null;
            //--TRIMMABLE-BOUNDARY-END(21477523561)
            
            static $h = 2687081;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477523561),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182556265,
        "f": 50331649
      },
      "n": "ParameterName",
      "d": 2687081,
      "h": 21477523561,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477523561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592621673),
    {
      "p": [
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687081,
      "h": 8592621673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592621673)
  ],
  "h": 2687081,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2048,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687081)
        
        
        //--TRIMMABLE-BOUNDARY-START(65641)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute", ($self) => class AllowAnonymousAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590000233)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "AllowAnonymous";
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(8590000233)
            
            //--TRIMMABLE-BOUNDARY-START(4295032937)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032937)
            
            static $h = 65641;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000233),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 65641,
      "h": 8590000233,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590000233)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032937),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65641,
      "h": 4295032937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032937)
  ],
  "i": [65640
  ],
  "h": 65641,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 68,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{ToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous ]; }
            static get $fullName() { return `AllowAnonymousAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65641)
        
        
        //--TRIMMABLE-BOUNDARY-START(917609)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizeAttribute", ($self) => class AuthorizeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(17180786793)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786793);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786793)
            
            //--TRIMMABLE-BOUNDARY-START(21475754089)
            $ctor$3(/*string*/ policy)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754089);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Policy = policy;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754089)
            
            //--TRIMMABLE-BOUNDARY-START(55835492457)
            /*string?*/ Policy = null;
            //--TRIMMABLE-BOUNDARY-END(55835492457)
            
            //--TRIMMABLE-BOUNDARY-START(60130459753)
            /*string?*/ Roles = null;
            //--TRIMMABLE-BOUNDARY-END(60130459753)
            
            //--TRIMMABLE-BOUNDARY-START(25770721385)
            /*string?*/ AuthenticationSchemes = null;
            //--TRIMMABLE-BOUNDARY-END(25770721385)
            
            //--TRIMMABLE-BOUNDARY-START(90195230825)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195230825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText$3("Policy", this.Policy, "Roles", this.Roles, "AuthenticationSchemes", this.AuthenticationSchemes, false, "Authorize");
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizeAttribute.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(90195230825)
            
            //--TRIMMABLE-BOUNDARY-START(21474967656)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Policy;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967656)
            
            //--TRIMMABLE-BOUNDARY-START(55834706024)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Policy = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706024)
            
            //--TRIMMABLE-BOUNDARY-START(30064902248)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Roles;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902248)
            
            //--TRIMMABLE-BOUNDARY-START(64424640616)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Roles = value;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640616)
            
            //--TRIMMABLE-BOUNDARY-START(12885033064)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticationSchemes;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033064)
            
            //--TRIMMABLE-BOUNDARY-START(47244771432)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationSchemes = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771432)
            
            static $h = 917609;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835492457),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590569,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310328937,
        "f": 83886081
      },
      "n": "Policy",
      "d": 917609,
      "h": 55835492457,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835492457),
//--TRIMMABLE-BOUNDARY-START(60130459753),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540525161,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900263529,
        "f": 83886081
      },
      "n": "Roles",
      "d": 917609,
      "h": 60130459753,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459753),
//--TRIMMABLE-BOUNDARY-START(25770721385),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655977,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720394345,
        "f": 83886081
      },
      "n": "AuthenticationSchemes",
      "d": 917609,
      "h": 25770721385,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770721385)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195230825),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 917609,
      "h": 90195230825,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195230825)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786793),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917609,
      "h": 17180786793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786793),
//--TRIMMABLE-BOUNDARY-START(21475754089),
    {
      "p": [
        {
          "n": "policy",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917609,
      "h": 21475754089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754089)
  ],
  "i": [131176
  ],
  "h": 917609,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 68,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{ToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData ]; }
            static get $fullName() { return `AuthorizeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917609)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097257)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement", ($self) => class NameAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8592031849)
            $ctor$2(/*string*/ requiredName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592031849);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requiredName, "requiredName");
                    this.RequiredName = requiredName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592031849)
            
            //--TRIMMABLE-BOUNDARY-START(25771901033)
            /*string*/ RequiredName = null;
            //--TRIMMABLE-BOUNDARY-END(25771901033)
            
            //--TRIMMABLE-BOUNDARY-START(21476933737)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*NameAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476933737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context.User !== null)
                {
                    /*var*/ let succeed = false;
                    var $en3 = context.User.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var identity = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.Equals$2(identity.Name, requirement.RequiredName, 4/*StringComparison.Ordinal*/))
                            {
                                succeed = true;
                                break;
                            }
                        }
                    }
                    if (succeed)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(21476933737)
            
            //--TRIMMABLE-BOUNDARY-START(30066868329)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066868329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${"NameAuthorizationRequirement"}:Requires a user identity with Name equal to ${this.RequiredName}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(30066868329)
            
            static $h = 2097257;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771901033),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181966441,
        "f": 50331649
      },
      "n": "RequiredName",
      "d": 2097257,
      "h": 25771901033,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771901033)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476933737),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        },
        {
          "n": "requirement",
          "p": 2097257
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 2097257,
      "h": 21476933737,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476933737),
//--TRIMMABLE-BOUNDARY-START(30066868329),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2097257,
      "h": 30066868329,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066868329)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592031849),
    {
      "p": [
        {
          "n": "requiredName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097257,
      "h": 8592031849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592031849)
  ],
  "i": [1441897,1704041
  ],
  "h": 2097257
}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `NameAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097257)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966185)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement", ($self) => class ClaimsAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(4296933481)
            /*bool*/ _emptyAllowedValues = false;
            //--TRIMMABLE-BOUNDARY-END(4296933481)
            
            //--TRIMMABLE-BOUNDARY-START(17181835369)
            $ctor$2(/*string*/ claimType, /*IEnumerable<string>?*/ allowedValues)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181835369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                    this.ClaimType = claimType;
                    this.AllowedValues = allowedValues;
                    this._emptyAllowedValues = this.AllowedValues === null || !$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, this.AllowedValues);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181835369)
            
            //--TRIMMABLE-BOUNDARY-START(25771769961)
            /*string*/ ClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(25771769961)
            
            //--TRIMMABLE-BOUNDARY-START(21476802665)
            /*IEnumerable<string>?*/ AllowedValues = null;
            //--TRIMMABLE-BOUNDARY-END(21476802665)
            
            //--TRIMMABLE-BOUNDARY-START(47246606441)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*ClaimsAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246606441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    if (requirement._emptyAllowedValues)
                    {
                        var $en4 = context.User.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$$.System.String.Equals$2(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    else 
                    {
                        var $en4 = context.User.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$$.System.String.Equals$2(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$sl.System.Linq.Enumerable.Contains($.$$.System.String, requirement.AllowedValues, claim.Value, $.$$.System.StringComparer.Ordinal))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47246606441)
            
            //--TRIMMABLE-BOUNDARY-START(51541573737)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541573737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let value = (this._emptyAllowedValues) ? $.$$.System.String.Empty : ` and Claim.Value is one of the following values: (${$.$$.System.String.Join$5("|", this.AllowedValues)})`;
                return `${"ClaimsAuthorizationRequirement"}:Claim.Type=${this.ClaimType}${value}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(51541573737)
            
            static $h = 1966185;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771769961),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951639145,
        "f": 50331649
      },
      "n": "ClaimType",
      "d": 1966185,
      "h": 25771769961,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771769961),
//--TRIMMABLE-BOUNDARY-START(21476802665),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361704553,
        "f": 50331649
      },
      "n": "AllowedValues",
      "d": 1966185,
      "h": 21476802665,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476802665)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246606441),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        },
        {
          "n": "requirement",
          "p": 1966185
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 1966185,
      "h": 47246606441,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246606441),
//--TRIMMABLE-BOUNDARY-START(51541573737),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1966185,
      "h": 51541573737,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541573737)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296933481),
    {
      "t": 262145,
      "n": "_emptyAllowedValues",
      "d": 1966185,
      "h": 4296933481,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933481)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181835369),
    {
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "allowedValues",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966185,
      "h": 17181835369,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181835369)
  ],
  "i": [1441897,1704041
  ],
  "h": 1966185
}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `ClaimsAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966185)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293865)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement", ($self) => class RolesAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8592228457)
            $ctor$2(/*IEnumerable<string>*/ allowedRoles)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592228457);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(allowedRoles, "allowedRoles");
                    if (!$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, allowedRoles))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$maa.Resources.Exception_RoleRequirementEmpty);
                    }
                    this.AllowedRoles = allowedRoles;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592228457)
            
            //--TRIMMABLE-BOUNDARY-START(12887195753)
            /*IEnumerable<string>*/ AllowedRoles = null;
            //--TRIMMABLE-BOUNDARY-END(12887195753)
            
            //--TRIMMABLE-BOUNDARY-START(25772097641)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*RolesAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772097641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    var $en3 = requirement.AllowedRoles.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var role = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (context.User.IsInRole(role))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(25772097641)
            
            //--TRIMMABLE-BOUNDARY-START(30067064937)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067064937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let roles = `User.IsInRole must be true for one of the following roles: (${$.$$.System.String.Join$5("|", this.AllowedRoles)})`;
                return `${"RolesAuthorizationRequirement"}:${roles}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(30067064937)
            
            static $h = 2293865;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887195753),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477130345,
        "f": 50331649
      },
      "n": "AllowedRoles",
      "d": 2293865,
      "h": 12887195753,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887195753)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772097641),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        },
        {
          "n": "requirement",
          "p": 2293865
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 2293865,
      "h": 25772097641,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25772097641),
//--TRIMMABLE-BOUNDARY-START(30067064937),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2293865,
      "h": 30067064937,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067064937)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592228457),
    {
      "p": [
        {
          "n": "allowedRoles",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293865,
      "h": 8592228457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592228457)
  ],
  "i": [1441897,1704041
  ],
  "h": 2293865
}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `RolesAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293865)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031721)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement", ($self) => class DenyAnonymousAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8591966313)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*DenyAnonymousAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let user = context.User;
                /*var*/ let userIsAnonymous = (user?.Identity ?? null) === null || !$.$sl.System.Linq.Enumerable.Any($.$ssc.System.Security.Claims.ClaimsIdentity, user.Identities, new ($.$$.System.Func$$$($.$ssc.System.Security.Claims.ClaimsIdentity, $.$$.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.IsAuthenticated;
                }, {
  "r": 262145,
  "p": [
    {
      "n": "i",
      "p": 262213
    }
  ],
  "n": "",
  "d": 2031721,
  "h": 0,
  "f": 17825794
}));
                if (!userIsAnonymous)
                {
                    context.Succeed(requirement);
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8591966313)
            
            //--TRIMMABLE-BOUNDARY-START(12886933609)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${"DenyAnonymousAuthorizationRequirement"}: Requires an authenticated user.`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(12886933609)
            
            //--TRIMMABLE-BOUNDARY-START(4296999017)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296999017)
            
            static $h = 2031721;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591966313),
    {
      "r": 177668097,
      "p": [
        {
          "n": "context",
          "p": 458857
        },
        {
          "n": "requirement",
          "p": 2031721
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 2031721,
      "h": 8591966313,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591966313),
//--TRIMMABLE-BOUNDARY-START(12886933609),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2031721,
      "h": 12886933609,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886933609)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296999017),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031721,
      "h": 4296999017,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296999017)
  ],
  "i": [1441897,1704041
  ],
  "h": 2031721
}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `DenyAnonymousAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031721)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310825)
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationServiceImpl", ($self) => class DefaultAuthorizationServiceImpl extends $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService
        {
            //--TRIMMABLE-BOUNDARY-START(12886212713)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886212713);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        result = await super.AuthorizeAsync(user, resource, requirements).ConfigureAwait$2(false);
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, null, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, null, result, null);
                    return result;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12886212713)
            
            //--TRIMMABLE-BOUNDARY-START(17181180009)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181180009);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        /*var*/ let policy = await this.GetPolicyAsync(policyName).ConfigureAwait$2(false);
                        result = await super.AuthorizeAsync(user, resource, policy.Requirements).ConfigureAwait$2(false);
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, policyName, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, policyName, result, null);
                    return result;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181180009)
            
            //Begin primary constructor
            /*IAuthorizationPolicyProvider*/ policyProvider = null;
            /*IAuthorizationHandlerProvider*/ handlers = null;
            /*ILogger<DefaultAuthorizationService>*/ logger = null;
            /*IAuthorizationHandlerContextFactory*/ contextFactory = null;
            /*IAuthorizationEvaluator*/ evaluator = null;
            /*IOptions<AuthorizationOptions>*/ options = null;
            /*AuthorizationMetrics*/ metrics = null;
            $ctor$2(/*IAuthorizationPolicyProvider*/policyProvider, /*IAuthorizationHandlerProvider*/handlers, /*ILogger<DefaultAuthorizationService>*/logger, /*IAuthorizationHandlerContextFactory*/contextFactory, /*IAuthorizationEvaluator*/evaluator, /*IOptions<AuthorizationOptions>*/options, /*AuthorizationMetrics*/metrics)
            {
                this.policyProvider = policyProvider;
                this.handlers = handlers;
                this.logger = logger;
                this.contextFactory = contextFactory;
                this.evaluator = evaluator;
                this.options = options;
                this.metrics = metrics;
                super.$ctor$1(this.policyProvider, this.handlers, this.logger, this.contextFactory, this.evaluator, this.options);
                return this
            }
            //End primary constructor
            static $h = 1310825;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886212713),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirements",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h
        }
      ],
      "n": "AuthorizeAsync",
      "d": 1310825,
      "h": 12886212713,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(12886212713),
//--TRIMMABLE-BOUNDARY-START(17181180009),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$1",
      "d": 1310825,
      "h": 17181180009,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(17181180009)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296278121),
    {
      "t": 524393,
      "n": "\u003Cmetrics\u003EP",
      "d": 1310825,
      "h": 4296278121,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278121)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245417),
    {
      "p": [
        {
          "n": "policyProvider",
          "p": 1638505
        },
        {
          "n": "handlers",
          "p": 1572969
        },
        {
          "n": "logger",
          "p": $.$mexla.Microsoft.Extensions.Logging.ILogger$$($.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService).$h
        },
        {
          "n": "contextFactory",
          "p": 1507433
        },
        {
          "n": "evaluator",
          "p": 1376361
        },
        {
          "n": "options",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h
        },
        {
          "n": "metrics",
          "p": 524393
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310825,
      "h": 8591245417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591245417)
  ],
  "i": [1835113
  ],
  "h": 1310825
}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService ]; }
            static get $fullName() { return `DefaultAuthorizationServiceImpl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310825)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions"))
//--TRIMMABLE-BOUNDARY-END(105)
