
//--TRIMMABLE-BOUNDARY-START(112)
(async function () {
(function ($global, $, $$, $mam, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mecga, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mexla) {
    "use strict";
    let _;
    let $YCHyXk;
    let $gFDWVi;
    let $Egoach;
    let $NUsoFb;
    let $tWMQVk;
    let $pQKivc;
    let $ErxJrf;
    let $MArwui;
    let $dHPlvb;
    let $ObNBuf;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Authorization", 
    {
  "h": 112,
  "f": "Microsoft.AspNetCore.Authorization",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 131183,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 65647,
          "t": 188547073
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "ASP.NET Core authorization classes.\nCommonly used types:\nMicrosoft.AspNetCore.Authorization.AllowAnonymousAttribute\nMicrosoft.AspNetCore.Authorization.AuthorizeAttribute",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Authorization.Test",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1441904)
        $asm.$cls(`$maa.MAA.IAuthorizationHandler`, ($self) => class IAuthorizationHandler
        {
            static $h = 1441904;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296409200),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "HandleAsync",
      "o": "MAA$IAuthorizationHandler$HandleAsync",
      "d": 1441904,
      "h": 4296409200,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296409200)
  ],
  "h": 1441904
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441904)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704048)
        $asm.$cls(`$maa.MAA.IAuthorizationRequirement`, ($self) => class IAuthorizationRequirement
        {
            static $h = 1704048;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1704048
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704048)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507440)
        $asm.$cls(`$maa.MAA.IAuthorizationHandlerContextFactory`, ($self) => class IAuthorizationHandlerContextFactory
        {
            static $h = 1507440;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296474736),
    {
      "r": 458864,
      "p": [
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        }
      ],
      "n": "CreateContext",
      "o": "MAA$IAuthorizationHandlerContextFactory$CreateContext",
      "d": 1507440,
      "h": 4296474736,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296474736)
  ],
  "h": 1507440
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationHandlerContextFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507440)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769584)
        $asm.$cls(`$maa.MAA.IAuthorizationRequirementData`, ($self) => class IAuthorizationRequirementData
        {
            static $h = 1769584;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296736880),
    {
      "r": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h,
      "n": "GetRequirements",
      "o": "MAA$IAuthorizationRequirementData$GetRequirements",
      "d": 1769584,
      "h": 4296736880,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296736880)
  ],
  "h": 1769584
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationRequirementData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationRequirementData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769584)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376368)
        $asm.$cls(`$maa.MAA.IAuthorizationEvaluator`, ($self) => class IAuthorizationEvaluator
        {
            static $h = 1376368;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296343664),
    {
      "r": 786544,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "Evaluate",
      "o": "MAA$IAuthorizationEvaluator$Evaluate",
      "d": 1376368,
      "h": 4296343664,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296343664)
  ],
  "h": 1376368
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationEvaluator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376368)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638512)
        $asm.$cls(`$maa.MAA.IAuthorizationPolicyProvider`, ($self) => class IAuthorizationPolicyProvider
        {
            static $h = 1638512;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886540400),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "GetPolicyAsync",
      "o": "MAA$IAuthorizationPolicyProvider$GetPolicyAsync",
      "d": 1638512,
      "h": 12886540400,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886540400),
//--TRIMMABLE-BOUNDARY-START(4296605808),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "GetDefaultPolicyAsync",
      "o": "MAA$IAuthorizationPolicyProvider$GetDefaultPolicyAsync",
      "d": 1638512,
      "h": 4296605808,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296605808),
//--TRIMMABLE-BOUNDARY-START(8591573104),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "GetFallbackPolicyAsync",
      "o": "MAA$IAuthorizationPolicyProvider$GetFallbackPolicyAsync",
      "d": 1638512,
      "h": 8591573104,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591573104)
  ],
  "h": 1638512
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationPolicyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638512)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572976)
        $asm.$cls(`$maa.MAA.IAuthorizationHandlerProvider`, ($self) => class IAuthorizationHandlerProvider
        {
            static $h = 1572976;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296540272),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationHandler)).$h,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "GetHandlersAsync",
      "o": "MAA$IAuthorizationHandlerProvider$GetHandlersAsync",
      "d": 1572976,
      "h": 4296540272,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296540272)
  ],
  "h": 1572976
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationHandlerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572976)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835120)
        $asm.$cls(`$maa.MAA.IAuthorizationService`, ($self) => class IAuthorizationService
        {
            static $h = 1835120;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296802416),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        }
      ],
      "n": "AuthorizeAsync",
      "o": "MAA$IAuthorizationService$AuthorizeAsync",
      "d": 1835120,
      "h": 4296802416,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296802416),
//--TRIMMABLE-BOUNDARY-START(8591769712),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "MAA$IAuthorizationService$AuthorizeAsync$1",
      "d": 1835120,
      "h": 8591769712,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591769712)
  ],
  "h": 1835120
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835120)
        
        

        //--TRIMMABLE-BOUNDARY-START(393328)
        $asm.$cls(`$maa.MAA.AuthorizationHandler<>`, (TRequirement) => $asm.$gt(`$maa.MAA.AuthorizationHandler<>`, [TRequirement], ($self) => class AuthorizationHandler$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590327920)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327920);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = $.$sl.SL.Enumerable.OfType(TRequirement, context.Requirements).SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let req = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            ($t2 = this.HandleRequirementAsync(context, req).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590327920)
            
            //--TRIMMABLE-BOUNDARY-START(4296409200)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            MAA$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409200)
            
            //--TRIMMABLE-BOUNDARY-START(4295360624)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360624)
            
            //--TRIMMABLE-BOUNDARY-START(4295360624)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360624)
            
            static $H = 393328;
            static $h = 393328;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327920),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "HandleAsync",
      "d": this.$h,
      "H": 8590327920,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(8590327920),
//--TRIMMABLE-BOUNDARY-START(12885295216),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        },
        {
          "n": "requirement",
          "p": TRequirement?.$h??1572864
        }
      ],
      "n": "HandleRequirementAsync",
      "d": this.$h,
      "H": 12885295216,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(12885295216)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360624),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295360624,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295360624)
  ],
  "s": [
    {
      "h": TRequirement?.$h??1572864,
      "n": "TRequirement",
      "c": [1704048
      ]
    }
  ],
  "r": 1,
  "H": 393328,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationHandler<${TRequirement?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationHandler$${TRequirement?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393328)
        
        

        //--TRIMMABLE-BOUNDARY-START(327792)
        $asm.$cls(`$maa.MAA.AuthorizationHandler<,>`, (TRequirement, TResource) => $asm.$gt(`$maa.MAA.AuthorizationHandler<,>`, [TRequirement, TResource], ($self) => class AuthorizationHandler$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590262384)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262384);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let resource;
                    if ($.$is(context.Resource, TResource, { set $v($v){ resource = $v; } }))
                    {
                        let $en1 = $.$sl.SL.Enumerable.OfType(TRequirement, context.Requirements).SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let req = $en1.SCG$IEnumerator$$$Current;
                            {
                                let $t2, $r2;
                                ($t2 = this.HandleRequirementAsync(context, req, resource).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590262384)
            
            //--TRIMMABLE-BOUNDARY-START(4296409200)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            MAA$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409200)
            
            //--TRIMMABLE-BOUNDARY-START(4295295088)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295088)
            
            //--TRIMMABLE-BOUNDARY-START(4295295088)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295088)
            
            static $H = 327792;
            static $h = 327792;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262384),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "HandleAsync",
      "d": this.$h,
      "H": 8590262384,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(8590262384),
//--TRIMMABLE-BOUNDARY-START(12885229680),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        },
        {
          "n": "requirement",
          "p": TRequirement?.$h??1572864
        },
        {
          "n": "resource",
          "p": TResource?.$h??1638400
        }
      ],
      "n": "HandleRequirementAsync",
      "d": this.$h,
      "H": 12885229680,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(12885229680)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295088),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295295088,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295295088)
  ],
  "s": [
    {
      "h": TRequirement?.$h??1572864,
      "n": "TRequirement",
      "c": [1704048
      ]
    },
    {
      "h": TResource?.$h??1638400,
      "n": "TResource"
    }
  ],
  "r": 2,
  "H": 327792,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationHandler<${TRequirement?.$fullName},${TResource?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationHandler$${TRequirement?.$getFullName(separator)}$${TResource?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327792)
        
        

        //--TRIMMABLE-BOUNDARY-START(2621552)
        $asm.$cls(`$maa.MEL.LoggingExtensions`, ($self) => class LoggingExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(17182490736)
            static /*void */ UserAuthorizationFailed(/*this ILogger*/ logger, /*AuthorizationFailure*/ failure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182490736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let reason = failure.FailCalled ? "Fail() was explicitly called." : $.$strNN("These requirements were not met:" + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN($.$$.S.String.Join$12($.$maa.MAA.IAuthorizationRequirement, $.$$.S.Environment.NewLine, failure.FailedRequirements));
                $.$maa.MEL.LoggingExtensions.UserAuthorizationFailed$1(logger, reason);
            }
            //--TRIMMABLE-BOUNDARY-END(17182490736)
            
            //--TRIMMABLE-BOUNDARY-START(8592556144)
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.Exception?>*/ static __UserAuthorizationSucceededCallback = null;
            //--TRIMMABLE-BOUNDARY-END(8592556144)
            
            //--TRIMMABLE-BOUNDARY-START(25772425328)
            static /*void */ UserAuthorizationSucceeded(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772425328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (logger.MEL$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                {
                    $.$maa.MEL.LoggingExtensions.__UserAuthorizationSucceededCallback.Invoke(logger, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772425328)
            
            //--TRIMMABLE-BOUNDARY-START(4297588848)
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __UserAuthorizationFailedCallback = null;
            //--TRIMMABLE-BOUNDARY-END(4297588848)
            
            //--TRIMMABLE-BOUNDARY-START(21477458032)
            static /*void */ UserAuthorizationFailed$1(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ reason)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477458032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (logger.MEL$ILogger$IsEnabled(2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/))
                {
                    $.$maa.MEL.LoggingExtensions.__UserAuthorizationFailedCallback.Invoke(logger, reason, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477458032)
            
            //--TRIMMABLE-BOUNDARY-START(12887523440)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887523440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8592556144)
                    this.__UserAuthorizationSucceededCallback = $.$mexla.MEL.LoggerMessage.Define(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mexla.MEL.EventId().$ctor$3(1, "UserAuthorizationSucceeded"), "Authorization was successful.", (() =>
                    {
                        //new $.$mexla.MEL.LogDefineOptions()
                        const $t1 = $.$mexla.MEL.LogDefineOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SkipEnabledCheck = true;
                        return $i1;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(8592556144)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4297588848)
                    this.__UserAuthorizationFailedCallback = $.$mexla.MEL.LoggerMessage.Define$12($.$$.S.String, 2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/, new $.$mexla.MEL.EventId().$ctor$3(2, "UserAuthorizationFailed"), "Authorization failed. {Reason}", (() =>
                    {
                        //new $.$mexla.MEL.LogDefineOptions()
                        const $t2 = $.$mexla.MEL.LogDefineOptions;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.SkipEnabledCheck = true;
                        return $i2;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(4297588848)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887523440)
            
            static $h = 2621552;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772425328),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "UserAuthorizationSucceeded",
      "d": 2621552,
      "h": 25772425328,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 38656933976,
          "a": [
            {
              "v": 1,
              "t": 655361
            },
            {
              "v": 1,
              "t": 2293848
            },
            {
              "v": "Authorization was successful.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "UserAuthorizationSucceeded",
              "t": 1310721
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772425328),
//--TRIMMABLE-BOUNDARY-START(21477458032),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "reason",
          "p": 1310721
        }
      ],
      "n": "UserAuthorizationFailed",
      "o": "@$1",
      "d": 2621552,
      "h": 21477458032,
      "f": 16777250,
      "a": [
        {
          "t": 2228312,
          "c": 38656933976,
          "a": [
            {
              "v": 2,
              "t": 655361
            },
            {
              "v": 2,
              "t": 2293848
            },
            {
              "v": "Authorization failed. {Reason}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "UserAuthorizationFailed",
              "t": 1310721
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477458032),
//--TRIMMABLE-BOUNDARY-START(17182490736),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "failure",
          "p": 196720
        }
      ],
      "n": "UserAuthorizationFailed",
      "d": 2621552,
      "h": 17182490736,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182490736)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592556144),
    {
      "t": $.$$.S.Action$$$($.$mexla.MEL.ILogger, $.$$.S.Exception).$h,
      "n": "__UserAuthorizationSucceededCallback",
      "d": 2621552,
      "h": 8592556144,
      "f": 4194338,
      "a": [
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592556144),
//--TRIMMABLE-BOUNDARY-START(4297588848),
    {
      "t": $.$$.S.Action$$$$($.$mexla.MEL.ILogger, $.$$.S.String, $.$$.S.Exception).$h,
      "n": "__UserAuthorizationFailedCallback",
      "d": 2621552,
      "h": 4297588848,
      "f": 4194338,
      "a": [
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297588848)
  ],
  "h": 2621552
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Logging.LoggingExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Logging${separator}LoggingExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621552)
        
        

        //--TRIMMABLE-BOUNDARY-START(262256)
        $asm.$cls(`$maa.MAA.AuthorizationFailureReason`, ($self) => class AuthorizationFailureReason extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885164144)
            $ctor$1(/*IAuthorizationHandler*/ handler, /*string*/ message)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164144);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Handler = handler;
                    this.Message = message;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164144)
            
            //--TRIMMABLE-BOUNDARY-START(38654967920)
            /*string*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(38654967920)
            
            //--TRIMMABLE-BOUNDARY-START(34360000624)
            /*IAuthorizationHandler*/ Handler = null;
            //--TRIMMABLE-BOUNDARY-END(34360000624)
            
            static $h = 262256;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654967920),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033328,
        "f": 50331649
      },
      "n": "Message",
      "d": 262256,
      "h": 38654967920,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654967920),
//--TRIMMABLE-BOUNDARY-START(34360000624),
    {
      "p": 1441904,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475098736,
        "f": 50331649
      },
      "n": "Handler",
      "d": 262256,
      "h": 34360000624,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000624)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885164144),
    {
      "p": [
        {
          "n": "handler",
          "p": 1441904
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262256,
      "h": 12885164144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164144)
  ],
  "h": 262256
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationFailureReason`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationFailureReason`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262256)
        
        

        //--TRIMMABLE-BOUNDARY-START(2687088)
        $asm.$cls(`$maa.Resources`, ($self) => class Resources
        {
            //--TRIMMABLE-BOUNDARY-START(77312098416)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(77312098416)
            
            //--TRIMMABLE-BOUNDARY-START(68722163824)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(68722163824)
            
            //--TRIMMABLE-BOUNDARY-START(73017131120)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427196528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$maa.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.AspNetCore.Authorization", $.$maa.Resources.$type.Assembly);
                    $.$maa.Resources.s_resourceManager = temp;
                }
                return $.$maa.Resources.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(73017131120)
            
            //--TRIMMABLE-BOUNDARY-START(4297654384)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067458160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902033008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.Resources.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4297654384)
            
            //--TRIMMABLE-BOUNDARY-START(8592621680)
            static /*string */ get Exception_AuthorizationPolicyEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657392752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "AuthorizationPolicy must have at least one requirement.";
            }
            //--TRIMMABLE-BOUNDARY-END(8592621680)
            
            //--TRIMMABLE-BOUNDARY-START(12887588976)
            static /*string */ get Exception_AuthorizationPolicyNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247327344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The AuthorizationPolicy named: '{0}' was not found.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887588976)
            
            //--TRIMMABLE-BOUNDARY-START(21477523568)
            static /*string */ FormatException_AuthorizationPolicyNotFound(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477523568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The AuthorizationPolicy named: '{0}' was not found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(21477523568)
            
            //--TRIMMABLE-BOUNDARY-START(17182556272)
            static /*string */ get Exception_RoleRequirementEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837261936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "At least one role must be specified.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182556272)
            
            static $h = 2687088;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73017131120),
    {
      "p": 123535361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427196528,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 2687088,
      "h": 73017131120,
      "f": 2097192,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 2,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73017131120),
//--TRIMMABLE-BOUNDARY-START(4297654384),
    {
      "p": 84738049,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067458160,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902033008,
        "f": 83886120
      },
      "n": "Culture",
      "d": 2687088,
      "h": 4297654384,
      "f": 2097192,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 2,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297654384),
//--TRIMMABLE-BOUNDARY-START(8592621680),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657392752,
        "f": 50331688
      },
      "n": "Exception_AuthorizationPolicyEmpty",
      "d": 2687088,
      "h": 8592621680,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(8592621680),
//--TRIMMABLE-BOUNDARY-START(12887588976),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247327344,
        "f": 50331688
      },
      "n": "Exception_AuthorizationPolicyNotFound",
      "d": 2687088,
      "h": 12887588976,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(12887588976),
//--TRIMMABLE-BOUNDARY-START(17182556272),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837261936,
        "f": 50331688
      },
      "n": "Exception_RoleRequirementEmpty",
      "d": 2687088,
      "h": 17182556272,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(17182556272)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477523568),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatException_AuthorizationPolicyNotFound",
      "d": 2687088,
      "h": 21477523568,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21477523568)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77312098416),
    {
      "t": 123535361,
      "n": "s_resourceManager",
      "d": 2687088,
      "h": 77312098416,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77312098416),
//--TRIMMABLE-BOUNDARY-START(68722163824),
    {
      "t": 84738049,
      "n": "resourceCulture",
      "d": 2687088,
      "h": 68722163824,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68722163824)
  ],
  "h": 2687088,
  "a": [
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "17.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71237633,
      "c": 4366204929
    },
    {
      "t": 126550017,
      "c": 4421517313
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Resources`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Resources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687088)
        
        

        //--TRIMMABLE-BOUNDARY-START(786544)
        $asm.$cls(`$maa.MAA.AuthorizationResult`, ($self) => class AuthorizationResult extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590721136)
            /*AuthorizationResult*/ static _succeededResult = null;
            //--TRIMMABLE-BOUNDARY-END(8590721136)
            
            //--TRIMMABLE-BOUNDARY-START(4295753840)
            /*AuthorizationResult*/ static _failedResult = null;
            //--TRIMMABLE-BOUNDARY-END(4295753840)
            
            //--TRIMMABLE-BOUNDARY-START(25770590320)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590320)
            
            //--TRIMMABLE-BOUNDARY-START(77310197872)
            /*bool*/ Succeeded = false;
            //--TRIMMABLE-BOUNDARY-END(77310197872)
            
            //--TRIMMABLE-BOUNDARY-START(38655492208)
            /*AuthorizationFailure?*/ Failure = null;
            //--TRIMMABLE-BOUNDARY-END(38655492208)
            
            //--TRIMMABLE-BOUNDARY-START(81605165168)
            static /*AuthorizationResult */ Success()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605165168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.MAA.AuthorizationResult._succeededResult;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605165168)
            
            //--TRIMMABLE-BOUNDARY-START(34360524912)
            static /*AuthorizationResult */ Failed$1(/*AuthorizationFailure*/ failure)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$maa.MAA.AuthorizationResult()
                        const $t1 = $.$maa.MAA.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Failure = failure;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360524912)
            
            //--TRIMMABLE-BOUNDARY-START(30065557616)
            static /*AuthorizationResult */ Failed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557616);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.MAA.AuthorizationResult._failedResult;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065557616)
            
            //--TRIMMABLE-BOUNDARY-START(25770590320)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770590320)
            
            //--TRIMMABLE-BOUNDARY-START(21475623024)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475623024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721136)
                    this._succeededResult = (() =>
                    {
                        //new $.$maa.MAA.AuthorizationResult()
                        const $t2 = $.$maa.MAA.AuthorizationResult;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Succeeded = true;
                        return $i2;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(8590721136)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753840)
                    this._failedResult = (() =>
                    {
                        //new $.$maa.MAA.AuthorizationResult()
                        const $t3 = $.$maa.MAA.AuthorizationResult;
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.Failure = $.$maa.MAA.AuthorizationFailure.ExplicitFail();
                        return $i3;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(4295753840)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475623024)
            
            static $h = 786544;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310197872),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361392,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015230576,
        "f": 83886082
      },
      "n": "Succeeded",
      "d": 786544,
      "h": 77310197872,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310197872),
//--TRIMMABLE-BOUNDARY-START(38655492208),
    {
      "p": 196720,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426800,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425295984,
        "f": 83886082
      },
      "n": "Failure",
      "d": 786544,
      "h": 38655492208,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655492208)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605165168),
    {
      "r": 786544,
      "n": "Success",
      "d": 786544,
      "h": 81605165168,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605165168),
//--TRIMMABLE-BOUNDARY-START(34360524912),
    {
      "r": 786544,
      "p": [
        {
          "n": "failure",
          "p": 196720
        }
      ],
      "n": "Failed",
      "o": "@$1",
      "d": 786544,
      "h": 34360524912,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360524912),
//--TRIMMABLE-BOUNDARY-START(30065557616),
    {
      "r": 786544,
      "n": "Failed",
      "d": 786544,
      "h": 30065557616,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065557616)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721136),
    {
      "t": 786544,
      "n": "_succeededResult",
      "d": 786544,
      "h": 8590721136,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590721136),
//--TRIMMABLE-BOUNDARY-START(4295753840),
    {
      "t": 786544,
      "n": "_failedResult",
      "d": 786544,
      "h": 4295753840,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295753840)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590320),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786544,
      "h": 25770590320,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770590320)
  ],
  "h": 786544
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786544)
        
        

        //--TRIMMABLE-BOUNDARY-START(2490480)
        $asm.$cls(`$maa.MED.AuthorizationServiceCollectionExtensions`, ($self) => class AuthorizationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8592425072)
            static /*IServiceCollection */ AddAuthorizationCore$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592425072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdg.MED.MetricsServiceExtensions.AddMetrics$1(services);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$3($.$maa.MAA.AuthorizationMetrics, $.$maa.MAA.AuthorizationMetrics));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Transient$2($.$maa.MAA.IAuthorizationService, $.$maa.MAA.DefaultAuthorizationServiceImpl));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Transient$2($.$maa.MAA.IAuthorizationPolicyProvider, $.$maa.MAA.DefaultAuthorizationPolicyProvider));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Transient$2($.$maa.MAA.IAuthorizationHandlerProvider, $.$maa.MAA.DefaultAuthorizationHandlerProvider));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Transient$2($.$maa.MAA.IAuthorizationEvaluator, $.$maa.MAA.DefaultAuthorizationEvaluator));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Transient$2($.$maa.MAA.IAuthorizationHandlerContextFactory, $.$maa.MAA.DefaultAuthorizationHandlerContextFactory));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddEnumerable(services, $.$mxdi.MED.ServiceDescriptor.Transient$2($.$maa.MAA.IAuthorizationHandler, $.$maa.MAAI.PassThroughAuthorizationHandler));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(8592425072)
            
            //--TRIMMABLE-BOUNDARY-START(4297457776)
            static /*IServiceCollection */ AddAuthorizationCore(/*this IServiceCollection*/ services, /*Action<AuthorizationOptions>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297457776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(configure, "configure");
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$maa.MAA.AuthorizationOptions, services, configure);
                return $.$maa.MED.AuthorizationServiceCollectionExtensions.AddAuthorizationCore$1(services);
            }
            //--TRIMMABLE-BOUNDARY-END(4297457776)
            
            static $h = 2490480;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592425072),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddAuthorizationCore",
      "o": "@$1",
      "d": 2490480,
      "h": 8592425072,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592425072),
//--TRIMMABLE-BOUNDARY-START(4297457776),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configure",
          "p": $.$$.S.Action$$($.$maa.MAA.AuthorizationOptions).$h
        }
      ],
      "n": "AddAuthorizationCore",
      "d": 2490480,
      "h": 4297457776,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297457776)
  ],
  "h": 2490480
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.AuthorizationServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}AuthorizationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490480)
        
        

        //--TRIMMABLE-BOUNDARY-START(589936)
        $asm.$cls(`$maa.MAA.AuthorizationOptions`, ($self) => class AuthorizationOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557232)
            /*Task<AuthorizationPolicy?>*/ static _nullPolicyTask = null;
            //--TRIMMABLE-BOUNDARY-END(4295557232)
            
            //--TRIMMABLE-BOUNDARY-START(98784837744)
            /*Dictionary<string, Task<AuthorizationPolicy?>>*/ PolicyMap = null;
            //--TRIMMABLE-BOUNDARY-END(98784837744)
            
            //--TRIMMABLE-BOUNDARY-START(94489870448)
            /*bool*/ InvokeHandlersAfterFailure = false;
            //--TRIMMABLE-BOUNDARY-END(94489870448)
            
            //--TRIMMABLE-BOUNDARY-START(42950262896)
            /*AuthorizationPolicy*/ DefaultPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(42950262896)
            
            //--TRIMMABLE-BOUNDARY-START(47245230192)
            /*AuthorizationPolicy?*/ FallbackPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(47245230192)
            
            //--TRIMMABLE-BOUNDARY-START(34360328304)
            /*void */ AddPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.PolicyMap.set_Item(name, $.$$.STT.Task.FromResult($.$maa.MAA.AuthorizationPolicy, policy));
            }
            //--TRIMMABLE-BOUNDARY-END(34360328304)
            
            //--TRIMMABLE-BOUNDARY-START(38655295600)
            /*void */ AddPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.MAA.AuthorizationPolicyBuilder().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                this.PolicyMap.set_Item(name, $.$$.STT.Task.FromResult($.$maa.MAA.AuthorizationPolicy, policyBuilder.Build()));
            }
            //--TRIMMABLE-BOUNDARY-END(38655295600)
            
            //--TRIMMABLE-BOUNDARY-START(85899935856)
            /*AuthorizationPolicy? */ GetPolicy(/*string*/ name)
            {
                /*var*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy))))
                {
                    return value.Result;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935856)
            
            //--TRIMMABLE-BOUNDARY-START(90194903152)
            /*Task<AuthorizationPolicy?> */ GetPolicyTask(/*string*/ name)
            {
                /*var*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy))))
                {
                    return value;
                }
                return $.$maa.MAA.AuthorizationOptions._nullPolicyTask;
            }
            //--TRIMMABLE-BOUNDARY-END(90194903152)
            
            //--TRIMMABLE-BOUNDARY-START(30065361008)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065361008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065361008)
            
            //--TRIMMABLE-BOUNDARY-START(30065361008)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30065361008)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98784837744)
                this.PolicyMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy)))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                //--TRIMMABLE-BOUNDARY-END(98784837744)
                
                //--TRIMMABLE-BOUNDARY-START(94489870448)
                this.InvokeHandlersAfterFailure = true;
                //--TRIMMABLE-BOUNDARY-END(94489870448)
                
                //--TRIMMABLE-BOUNDARY-START(42950262896)
                this.DefaultPolicy = new $.$maa.MAA.AuthorizationPolicyBuilder().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)).RequireAuthenticatedUser().Build();
                //--TRIMMABLE-BOUNDARY-END(42950262896)
                
            }
            //--TRIMMABLE-BOUNDARY-START(25770393712)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557232)
                    this._nullPolicyTask = $.$$.STT.Task.FromResult($.$maa.MAA.AuthorizationPolicy, null);
                    //--TRIMMABLE-BOUNDARY-END(4295557232)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770393712)
            
            static $h = 589936;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784837744),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604968560,
        "f": 50331650
      },
      "n": "PolicyMap",
      "d": 589936,
      "h": 98784837744,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98784837744),
//--TRIMMABLE-BOUNDARY-START(94489870448),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015033968,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554641520,
        "f": 83886081
      },
      "n": "InvokeHandlersAfterFailure",
      "d": 589936,
      "h": 94489870448,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489870448),
//--TRIMMABLE-BOUNDARY-START(42950262896),
    {
      "p": 655472,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835164784,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374772336,
        "f": 83886081
      },
      "n": "DefaultPolicy",
      "d": 589936,
      "h": 42950262896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950262896),
//--TRIMMABLE-BOUNDARY-START(47245230192),
    {
      "p": 655472,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425099376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964706928,
        "f": 83886081
      },
      "n": "FallbackPolicy",
      "d": 589936,
      "h": 47245230192,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230192)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360328304),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "AddPolicy",
      "d": 589936,
      "h": 34360328304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360328304),
//--TRIMMABLE-BOUNDARY-START(38655295600),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.S.Action$$($.$maa.MAA.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddPolicy",
      "o": "@$1",
      "d": 589936,
      "h": 38655295600,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295600),
//--TRIMMABLE-BOUNDARY-START(85899935856),
    {
      "r": 655472,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetPolicy",
      "d": 589936,
      "h": 85899935856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899935856),
//--TRIMMABLE-BOUNDARY-START(90194903152),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetPolicyTask",
      "d": 589936,
      "h": 90194903152,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194903152)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557232),
    {
      "t": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "_nullPolicyTask",
      "d": 589936,
      "h": 4295557232,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295557232)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065361008),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589936,
      "h": 30065361008,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065361008)
  ],
  "h": 589936
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589936)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359408)
        $asm.$cls(`$maa.MAS.ArgumentNullThrowHelper`, ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4297326704)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297326704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4297326704)
            
            //--TRIMMABLE-BOUNDARY-START(8592294000)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592294000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8592294000)
            
            static $h = 2359408;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297326704),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 2359408,
      "h": 4297326704,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297326704),
//--TRIMMABLE-BOUNDARY-START(8592294000),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 2359408,
      "h": 8592294000,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592294000)
  ],
  "h": 2359408
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Shared${separator}ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359408)
        
        

        //--TRIMMABLE-BOUNDARY-START(196720)
        $asm.$cls(`$maa.MAA.AuthorizationFailure`, ($self) => class AuthorizationFailure extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295164016)
            /*AuthorizationFailure*/ static _explicitFailure = null;
            //--TRIMMABLE-BOUNDARY-END(4295164016)
            
            //--TRIMMABLE-BOUNDARY-START(25770000496)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770000496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000496)
            
            //--TRIMMABLE-BOUNDARY-START(34359935088)
            /*bool*/ FailCalled = false;
            //--TRIMMABLE-BOUNDARY-END(34359935088)
            
            //--TRIMMABLE-BOUNDARY-START(47244836976)
            /*IEnumerable<IAuthorizationRequirement>*/ FailedRequirements = null;
            //--TRIMMABLE-BOUNDARY-END(47244836976)
            
            //--TRIMMABLE-BOUNDARY-START(51539804272)
            /*IEnumerable<AuthorizationFailureReason>*/ FailureReasons = null;
            //--TRIMMABLE-BOUNDARY-END(51539804272)
            
            //--TRIMMABLE-BOUNDARY-START(30064967792)
            static /*AuthorizationFailure */ ExplicitFail()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064967792);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.MAA.AuthorizationFailure._explicitFailure;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064967792)
            
            //--TRIMMABLE-BOUNDARY-START(38654902384)
            static /*AuthorizationFailure */ Failed(/*IEnumerable<AuthorizationFailureReason>*/ reasons)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654902384);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$maa.MAA.AuthorizationFailure()
                        const $t1 = $.$maa.MAA.AuthorizationFailure;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.FailCalled = true;
                        $i1.FailureReasons = reasons;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654902384)
            
            //--TRIMMABLE-BOUNDARY-START(42949869680)
            static /*AuthorizationFailure */ Failed$1(/*IEnumerable<IAuthorizationRequirement>*/ failed)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949869680);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$maa.MAA.AuthorizationFailure()
                        const $t2 = $.$maa.MAA.AuthorizationFailure;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.FailedRequirements = failed;
                        return $i2;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949869680)
            
            //--TRIMMABLE-BOUNDARY-START(25770000496)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770000496)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47244836976)
                this.FailedRequirements = $.$$.S.Array.Empty($.$maa.MAA.IAuthorizationRequirement);
                //--TRIMMABLE-BOUNDARY-END(47244836976)
                
                //--TRIMMABLE-BOUNDARY-START(51539804272)
                this.FailureReasons = $.$$.S.Array.Empty($.$maa.MAA.AuthorizationFailureReason);
                //--TRIMMABLE-BOUNDARY-END(51539804272)
                
            }
            //--TRIMMABLE-BOUNDARY-START(21475033200)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295164016)
                    this._explicitFailure = (() =>
                    {
                        //new $.$maa.MAA.AuthorizationFailure()
                        const $t3 = $.$maa.MAA.AuthorizationFailure;
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.FailCalled = true;
                        return $i3;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(4295164016)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033200)
            
            static $h = 196720;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359935088),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129738864,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899542640,
        "f": 83886082
      },
      "n": "FailCalled",
      "d": 196720,
      "h": 34359935088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359935088),
//--TRIMMABLE-BOUNDARY-START(47244836976),
    {
      "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719673456,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489477232,
        "f": 83886082
      },
      "n": "FailedRequirements",
      "d": 196720,
      "h": 47244836976,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244836976),
//--TRIMMABLE-BOUNDARY-START(51539804272),
    {
      "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.AuthorizationFailureReason).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309608048,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079411824,
        "f": 83886082
      },
      "n": "FailureReasons",
      "d": 196720,
      "h": 51539804272,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539804272)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064967792),
    {
      "r": 196720,
      "n": "ExplicitFail",
      "d": 196720,
      "h": 30064967792,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064967792),
//--TRIMMABLE-BOUNDARY-START(38654902384),
    {
      "r": 196720,
      "p": [
        {
          "n": "reasons",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.AuthorizationFailureReason).$h
        }
      ],
      "n": "Failed",
      "d": 196720,
      "h": 38654902384,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654902384),
//--TRIMMABLE-BOUNDARY-START(42949869680),
    {
      "r": 196720,
      "p": [
        {
          "n": "failed",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        }
      ],
      "n": "Failed",
      "o": "@$1",
      "d": 196720,
      "h": 42949869680,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949869680)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295164016),
    {
      "t": 196720,
      "n": "_explicitFailure",
      "d": 196720,
      "h": 4295164016,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295164016)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770000496),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196720,
      "h": 25770000496,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770000496)
  ],
  "h": 196720
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationFailure`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationFailure`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196720)
        
        

        //--TRIMMABLE-BOUNDARY-START(458864)
        $asm.$cls(`$maa.MAA.AuthorizationHandlerContext`, ($self) => class AuthorizationHandlerContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885360752)
            /*HashSet<IAuthorizationRequirement>*/ _pendingRequirements = null;
            //--TRIMMABLE-BOUNDARY-END(12885360752)
            
            //--TRIMMABLE-BOUNDARY-START(8590393456)
            /*List<AuthorizationFailureReason>?*/ _failedReasons = null;
            //--TRIMMABLE-BOUNDARY-END(8590393456)
            
            //--TRIMMABLE-BOUNDARY-START(4295426160)
            /*bool*/ _failCalled = false;
            //--TRIMMABLE-BOUNDARY-END(4295426160)
            
            //--TRIMMABLE-BOUNDARY-START(17180328048)
            /*bool*/ _succeedCalled = false;
            //--TRIMMABLE-BOUNDARY-END(17180328048)
            
            //--TRIMMABLE-BOUNDARY-START(34360197232)
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    this.Requirements = requirements;
                    this.User = user;
                    this.Resource = resource;
                    this._pendingRequirements = new ($.$$.SCG.HashSet$$($.$maa.MAA.IAuthorizationRequirement))().$ctor$3(requirements);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197232)
            
            //--TRIMMABLE-BOUNDARY-START(124554510448)
            /*IEnumerable<IAuthorizationRequirement>*/ $Requirements = null;
            /*IEnumerable<IAuthorizationRequirement> */ get Requirements()
            {
                return this.$Requirements;
            }
             /*IEnumerable<IAuthorizationRequirement> */ set Requirements(value)
            {
                this.$Requirements = value;
            }
            //--TRIMMABLE-BOUNDARY-END(124554510448)
            
            //--TRIMMABLE-BOUNDARY-START(137439412336)
            /*ClaimsPrincipal*/ $User = null;
            /*ClaimsPrincipal */ get User()
            {
                return this.$User;
            }
             /*ClaimsPrincipal */ set User(value)
            {
                this.$User = value;
            }
            //--TRIMMABLE-BOUNDARY-END(137439412336)
            
            //--TRIMMABLE-BOUNDARY-START(128849477744)
            /*object?*/ $Resource = null;
            /*object? */ get Resource()
            {
                return this.$Resource;
            }
             /*object? */ set Resource(value)
            {
                this.$Resource = value;
            }
            //--TRIMMABLE-BOUNDARY-END(128849477744)
            
            //--TRIMMABLE-BOUNDARY-START(120259543152)
            /*IEnumerable<IAuthorizationRequirement> */ get PendingRequirements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pendingRequirements;
            }
            //--TRIMMABLE-BOUNDARY-END(120259543152)
            
            //--TRIMMABLE-BOUNDARY-START(47245099120)
            /*IEnumerable<AuthorizationFailureReason> */ get FailureReasons()
            {
                return this._failedReasons ?? $.$$.S.Array.Empty($.$maa.MAA.AuthorizationFailureReason);
            }
            //--TRIMMABLE-BOUNDARY-END(47245099120)
            
            //--TRIMMABLE-BOUNDARY-START(111669608560)
            /*bool */ get HasFailed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._failCalled;
            }
            //--TRIMMABLE-BOUNDARY-END(111669608560)
            
            //--TRIMMABLE-BOUNDARY-START(115964575856)
            /*bool */ get HasSucceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._failCalled && this._succeedCalled && !$.$sl.SL.Enumerable.Any$1($.$maa.MAA.IAuthorizationRequirement, this.PendingRequirements);
            }
            //--TRIMMABLE-BOUNDARY-END(115964575856)
            
            //--TRIMMABLE-BOUNDARY-START(38655164528)
            /*void */ Fail()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._failCalled = true;
            }
            //--TRIMMABLE-BOUNDARY-END(38655164528)
            
            //--TRIMMABLE-BOUNDARY-START(42950131824)
            /*void */ Fail$1(/*AuthorizationFailureReason*/ reason)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Fail();
                if (reason !== null)
                {
                    if (this._failedReasons === null)
                    {
                        this._failedReasons = new ($.$$.SCG.List$$($.$maa.MAA.AuthorizationFailureReason))().$ctor$1();
                    }
                    this._failedReasons.Add(reason);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950131824)
            
            //--TRIMMABLE-BOUNDARY-START(133144445040)
            /*void */ Succeed(/*IAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144445040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._succeedCalled = true;
                this._pendingRequirements.Remove(requirement);
            }
            //--TRIMMABLE-BOUNDARY-END(133144445040)
            
            static $h = 458864;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554510448),
    {
      "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194772080,
        "f": 50331777
      },
      "n": "Requirements",
      "d": 458864,
      "h": 124554510448,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124554510448),
//--TRIMMABLE-BOUNDARY-START(137439412336),
    {
      "p": 393285,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374641264,
        "f": 50331777
      },
      "n": "User",
      "d": 458864,
      "h": 137439412336,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(137439412336),
//--TRIMMABLE-BOUNDARY-START(128849477744),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784706672,
        "f": 50331777
      },
      "n": "Resource",
      "d": 458864,
      "h": 128849477744,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(128849477744),
//--TRIMMABLE-BOUNDARY-START(120259543152),
    {
      "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604837488,
        "f": 50331777
      },
      "n": "PendingRequirements",
      "d": 458864,
      "h": 120259543152,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(120259543152),
//--TRIMMABLE-BOUNDARY-START(47245099120),
    {
      "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.AuthorizationFailureReason).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033712,
        "f": 50331777
      },
      "n": "FailureReasons",
      "d": 458864,
      "h": 47245099120,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47245099120),
//--TRIMMABLE-BOUNDARY-START(111669608560),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424968304,
        "f": 50331777
      },
      "n": "HasFailed",
      "d": 458864,
      "h": 111669608560,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111669608560),
//--TRIMMABLE-BOUNDARY-START(115964575856),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014902896,
        "f": 50331777
      },
      "n": "HasSucceeded",
      "d": 458864,
      "h": 115964575856,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(115964575856)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655164528),
    {
      "r": 65537,
      "n": "Fail",
      "d": 458864,
      "h": 38655164528,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38655164528),
//--TRIMMABLE-BOUNDARY-START(42950131824),
    {
      "r": 65537,
      "p": [
        {
          "n": "reason",
          "p": 262256
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 458864,
      "h": 42950131824,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950131824),
//--TRIMMABLE-BOUNDARY-START(133144445040),
    {
      "r": 65537,
      "p": [
        {
          "n": "requirement",
          "p": 1704048
        }
      ],
      "n": "Succeed",
      "d": 458864,
      "h": 133144445040,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(133144445040)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885360752),
    {
      "t": $.$$.SCG.HashSet$$($.$maa.MAA.IAuthorizationRequirement).$h,
      "n": "_pendingRequirements",
      "d": 458864,
      "h": 12885360752,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360752),
//--TRIMMABLE-BOUNDARY-START(8590393456),
    {
      "t": $.$$.SCG.List$$($.$maa.MAA.AuthorizationFailureReason).$h,
      "n": "_failedReasons",
      "d": 458864,
      "h": 8590393456,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393456),
//--TRIMMABLE-BOUNDARY-START(4295426160),
    {
      "t": 262145,
      "n": "_failCalled",
      "d": 458864,
      "h": 4295426160,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426160),
//--TRIMMABLE-BOUNDARY-START(17180328048),
    {
      "t": 262145,
      "n": "_succeedCalled",
      "d": 458864,
      "h": 17180328048,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180328048)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360197232),
    {
      "p": [
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458864,
      "h": 34360197232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197232)
  ],
  "h": 458864
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationHandlerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458864)
        
        

        //--TRIMMABLE-BOUNDARY-START(524400)
        $asm.$cls(`$maa.MAA.AuthorizationMetrics`, ($self) => class AuthorizationMetrics extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770328176)
            /*string*/ static MeterName = null;
            //--TRIMMABLE-BOUNDARY-END(25770328176)
            
            //--TRIMMABLE-BOUNDARY-START(8590458992)
            /*Meter*/ _meter = null;
            //--TRIMMABLE-BOUNDARY-END(8590458992)
            
            //--TRIMMABLE-BOUNDARY-START(4295491696)
            /*Counter<long>*/ _authorizedCount = null;
            //--TRIMMABLE-BOUNDARY-END(4295491696)
            
            //--TRIMMABLE-BOUNDARY-START(12885426288)
            $ctor$1(/*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426288);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._meter = $.$sdd.SDM.MeterFactoryExtensions.Create(meterFactory, "Microsoft.AspNetCore.Authorization"/*MeterName*/, null, null);
                    this._authorizedCount = this._meter.CreateCounter$1($.$$.S.Int64, "aspnetcore.authorization.attempts", "{attempt}", "The total number of authorization attempts.");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426288)
            
            //--TRIMMABLE-BOUNDARY-START(17180393584)
            /*void */ AuthorizeAttemptCompleted(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (_authorizedCount.Enabled) { ... }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393584)
            
            //--TRIMMABLE-BOUNDARY-START(21475360880)
            /*void */ AuthorizeAttemptCore(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tags = new $.$sdd.SD.TagList().$ctor$3($.$$.S.ReadOnlySpan$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), [new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("aspnetcore.user.is_authenticated", $.$box((user.Identity?.SSP$1$IIdentity$IsAuthenticated ?? null) ?? false, $.$$.S.Boolean))], null, null)));
                if (!(policyName === null))
                {
                    tags.Add$1("aspnetcore.authorization.policy", policyName);
                }
                if (!(result === null))
                {
                    /*var*/ let resultTagValue = result.Succeeded ? "success" : "failure";
                    tags.Add$1("aspnetcore.authorization.result", resultTagValue);
                }
                if (!(exception === null))
                {
                    tags.Add$1("error.type", exception.GetType$1().FullName);
                }
                this._authorizedCount.Add(1n, $.$ref(() => tags, ));
            }
            //--TRIMMABLE-BOUNDARY-END(21475360880)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328176)
                    this.MeterName = "Microsoft.AspNetCore.Authorization";
                    //--TRIMMABLE-BOUNDARY-END(25770328176)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524400;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393584),
    {
      "r": 65537,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policyName",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 786544
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "AuthorizeAttemptCompleted",
      "d": 524400,
      "h": 17180393584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393584),
//--TRIMMABLE-BOUNDARY-START(21475360880),
    {
      "r": 65537,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policyName",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 786544
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "AuthorizeAttemptCore",
      "d": 524400,
      "h": 21475360880,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475360880)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770328176),
    {
      "t": 1310721,
      "n": "MeterName",
      "d": 524400,
      "h": 25770328176,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328176),
//--TRIMMABLE-BOUNDARY-START(8590458992),
    {
      "t": 6553646,
      "n": "_meter",
      "d": 524400,
      "h": 8590458992,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458992),
//--TRIMMABLE-BOUNDARY-START(4295491696),
    {
      "t": $.$sdd.SDM.Counter$$($.$$.S.Int64).$h,
      "n": "_authorizedCount",
      "d": 524400,
      "h": 4295491696,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491696)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426288),
    {
      "p": [
        {
          "n": "meterFactory",
          "p": 5439534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524400,
      "h": 12885426288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426288)
  ],
  "h": 524400
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationMetrics`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationMetrics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524400)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424944)
        $asm.$cls(`$maa.MAS.DebuggerHelpers`, ($self) => class DebuggerHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(12887326832)
            static /*string */ GetDebugText$1(/*string*/ key1, /*object?*/ value1, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.MAS.DebuggerHelpers.GetDebugText($.$$.S.ReadOnlySpan$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), [$.$maa.MAS.DebuggerHelpers.Create(key1, value1)], [-1], null)), includeNullValues, prefix);
            }
            //--TRIMMABLE-BOUNDARY-END(12887326832)
            
            //--TRIMMABLE-BOUNDARY-START(17182294128)
            static /*string */ GetDebugText$2(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182294128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.MAS.DebuggerHelpers.GetDebugText($.$$.S.ReadOnlySpan$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), [$.$maa.MAS.DebuggerHelpers.Create(key1, value1), $.$maa.MAS.DebuggerHelpers.Create(key2, value2)], [-1], null)), includeNullValues, prefix);
            }
            //--TRIMMABLE-BOUNDARY-END(17182294128)
            
            //--TRIMMABLE-BOUNDARY-START(21477261424)
            static /*string */ GetDebugText$3(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*string*/ key3, /*object?*/ value3, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477261424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.MAS.DebuggerHelpers.GetDebugText($.$$.S.ReadOnlySpan$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), [$.$maa.MAS.DebuggerHelpers.Create(key1, value1), $.$maa.MAS.DebuggerHelpers.Create(key2, value2), $.$maa.MAS.DebuggerHelpers.Create(key3, value3)], [-1], null)), includeNullValues, prefix);
            }
            //--TRIMMABLE-BOUNDARY-END(21477261424)
            
            //--TRIMMABLE-BOUNDARY-START(8592359536)
            static /*string */ GetDebugText(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ values, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592359536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (values.Length === 0)
                {
                    return prefix ?? $.$$.S.String.Empty;
                }
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                if (prefix !== null)
                {
                    sb.Append$21(prefix);
                }
                /*var*/ let first = true;
                for(/*var*/ let i = 0; i < values.Length; i++)
                {
                    /*var*/ let kvp = values._reference.GetAt(i);
                    if ($.$maa.MAS.DebuggerHelpers.HasValue(kvp.Value) || includeNullValues)
                    {
                        if (first)
                        {
                            if (prefix !== null)
                            {
                                sb.Append$5(/* */ 32);
                            }
                            first = false;
                        }
                        else 
                        {
                            sb.Append$21(", ");
                        }
                        sb.Append$21(kvp.Key);
                        sb.Append$21(": ");
                        let s;
                        let enumerable;
                        if (kvp.Value === null)
                        {
                            sb.Append$21("(null)");
                        }
                        else if ($.$is(kvp.Value, $.$$.S.String, { set $v($v){ s = $v; } }))
                        {
                            sb.Append$21(s);
                        }
                        else if ($.$is(kvp.Value, $.$$.SC$1.IEnumerable, { set $v($v){ enumerable = $v; } }))
                        {
                            /*var*/ let firstItem = true;
                            let $en1 = enumerable.SC$1$IEnumerable$GetEnumerator();
                            while ($en1.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en1.SC$1$IEnumerator$Current;
                                {
                                    if (firstItem)
                                    {
                                        firstItem = false;
                                    }
                                    else 
                                    {
                                        sb.Append$5(/*,*/ 44);
                                    }
                                    sb.Append$15(item);
                                }
                            }
                        }
                        else 
                        {
                            sb.Append$15(kvp.Value);
                        }
                    }
                }
                return sb.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(8592359536)
            
            //--TRIMMABLE-BOUNDARY-START(25772228720)
            static /*bool */ HasValue(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772228720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return false;
                }
                let enumerable;
                if (!(value !== null && ($.$is(value, $.$$.S.String))) && $.$is(value, $.$$.SC$1.IEnumerable, { set $v($v){ enumerable = $v; } }) && !enumerable.SC$1$IEnumerable$GetEnumerator().SC$1$IEnumerator$MoveNext())
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25772228720)
            
            //--TRIMMABLE-BOUNDARY-START(4297392240)
            static /*KeyValuePair<string, object?> */ Create(/*string*/ key, /*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297392240);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3(key, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297392240)
            
            static $h = 2424944;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887326832),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key1",
          "p": 1310721
        },
        {
          "n": "value1",
          "p": 131073
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "o": "@$1",
      "d": 2424944,
      "h": 12887326832,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887326832),
//--TRIMMABLE-BOUNDARY-START(17182294128),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key1",
          "p": 1310721
        },
        {
          "n": "value1",
          "p": 131073
        },
        {
          "n": "key2",
          "p": 1310721
        },
        {
          "n": "value2",
          "p": 131073
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "o": "@$2",
      "d": 2424944,
      "h": 17182294128,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182294128),
//--TRIMMABLE-BOUNDARY-START(21477261424),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key1",
          "p": 1310721
        },
        {
          "n": "value1",
          "p": 131073
        },
        {
          "n": "key2",
          "p": 1310721
        },
        {
          "n": "value2",
          "p": 131073
        },
        {
          "n": "key3",
          "p": 1310721
        },
        {
          "n": "value3",
          "p": 131073
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "o": "@$3",
      "d": 2424944,
      "h": 21477261424,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477261424),
//--TRIMMABLE-BOUNDARY-START(8592359536),
    {
      "r": 1310721,
      "p": [
        {
          "n": "values",
          "p": $.$$.S.ReadOnlySpan$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h
        },
        {
          "n": "includeNullValues",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDebugText",
      "d": 2424944,
      "h": 8592359536,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592359536),
//--TRIMMABLE-BOUNDARY-START(25772228720),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "HasValue",
      "d": 2424944,
      "h": 25772228720,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25772228720),
//--TRIMMABLE-BOUNDARY-START(4297392240),
    {
      "r": $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Create",
      "d": 2424944,
      "h": 4297392240,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297392240)
  ],
  "h": 2424944
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Shared.DebuggerHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Shared${separator}DebuggerHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424944)
        
        

        //--TRIMMABLE-BOUNDARY-START(852080)
        $asm.$cls(`$maa.MAA.AuthorizationServiceExtensions`, ($self) => class AuthorizationServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885753968)
            static /*Task<AuthorizationResult> */ AuthorizeAsync$2(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*IAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(requirement, "requirement");
                return service.MAA$IAuthorizationService$AuthorizeAsync(user, resource, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$maa.MAA.IAuthorizationRequirement), [requirement], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885753968)
            
            //--TRIMMABLE-BOUNDARY-START(8590786672)
            static /*Task<AuthorizationResult> */ AuthorizeAsync$1(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return service.MAA$IAuthorizationService$AuthorizeAsync(user, resource, policy.Requirements);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786672)
            
            //--TRIMMABLE-BOUNDARY-START(4295819376)
            static /*Task<AuthorizationResult> */ AuthorizeAsync(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return $.$maa.MAA.AuthorizationServiceExtensions.AuthorizeAsync$1(service, user, null, policy);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819376)
            
            //--TRIMMABLE-BOUNDARY-START(17180721264)
            static /*Task<AuthorizationResult> */ AuthorizeAsync$3(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*string*/ policyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                return service.MAA$IAuthorizationService$AuthorizeAsync$1(user, null, policyName);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721264)
            
            static $h = 852080;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753968),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835120
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirement",
          "p": 1704048
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$2",
      "d": 852080,
      "h": 12885753968,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885753968),
//--TRIMMABLE-BOUNDARY-START(8590786672),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835120
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$1",
      "d": 852080,
      "h": 8590786672,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590786672),
//--TRIMMABLE-BOUNDARY-START(4295819376),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835120
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "AuthorizeAsync",
      "d": 852080,
      "h": 4295819376,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295819376),
//--TRIMMABLE-BOUNDARY-START(17180721264),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "service",
          "p": 1835120
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$3",
      "d": 852080,
      "h": 17180721264,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180721264)
  ],
  "h": 852080
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852080)
        
        

        //--TRIMMABLE-BOUNDARY-START(131184)
        $asm.$cls(`$maa.MAA.AuthorizationBuilder`, ($self) => class AuthorizationBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590065776)
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065776);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065776)
            
            //--TRIMMABLE-BOUNDARY-START(47244771440)
            /*IServiceCollection*/ $Services = null;
            /*IServiceCollection */ get Services()
            {
                return this.$Services;
            }
             /*IServiceCollection */ set Services(value)
            {
                this.$Services = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771440)
            
            //--TRIMMABLE-BOUNDARY-START(60129673328)
            /*AuthorizationBuilder */ SetInvokeHandlersAfterFailure(/*bool*/ invoke)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$maa.MAA.AuthorizationOptions, this.Services, new ($.$$.S.Action$$($.$maa.MAA.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.InvokeHandlersAfterFailure = invoke;
                }, $YCHyXk ??= {"r":65537,"p":[{"n":"o","p":589936}],"n":"","d":131184,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673328)
            
            //--TRIMMABLE-BOUNDARY-START(51539738736)
            /*AuthorizationBuilder */ SetDefaultPolicy(/*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$maa.MAA.AuthorizationOptions, this.Services, new ($.$$.S.Action$$($.$maa.MAA.AuthorizationOptions))().$ctor(this,  (/**/ o) =>
                {
                    return o.DefaultPolicy = policy;
                }, $gFDWVi ??= {"r":65537,"p":[{"n":"o","p":589936}],"n":"","d":131184,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738736)
            
            //--TRIMMABLE-BOUNDARY-START(55834706032)
            /*AuthorizationBuilder */ SetFallbackPolicy(/*AuthorizationPolicy?*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$maa.MAA.AuthorizationOptions, this.Services, new ($.$$.S.Action$$($.$maa.MAA.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.FallbackPolicy = policy;
                }, $Egoach ??= {"r":65537,"p":[{"n":"o","p":589936}],"n":"","d":131184,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706032)
            
            //--TRIMMABLE-BOUNDARY-START(30064902256)
            /*AuthorizationBuilder */ AddPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$maa.MAA.AuthorizationOptions, this.Services, new ($.$$.S.Action$$($.$maa.MAA.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy(name, policy);
                }, $NUsoFb ??= {"r":65537,"p":[{"n":"o","p":589936}],"n":"","d":131184,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902256)
            
            //--TRIMMABLE-BOUNDARY-START(34359869552)
            /*AuthorizationBuilder */ AddPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$maa.MAA.AuthorizationOptions, this.Services, new ($.$$.S.Action$$($.$maa.MAA.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy$1(name, configurePolicy);
                }, $tWMQVk ??= {"r":65537,"p":[{"n":"o","p":589936}],"n":"","d":131184,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359869552)
            
            //--TRIMMABLE-BOUNDARY-START(12885033072)
            /*AuthorizationBuilder */ AddDefaultPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetDefaultPolicy(policy);
                return this.AddPolicy(name, policy);
            }
            //--TRIMMABLE-BOUNDARY-END(12885033072)
            
            //--TRIMMABLE-BOUNDARY-START(17180000368)
            /*AuthorizationBuilder */ AddDefaultPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.MAA.AuthorizationPolicyBuilder().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddDefaultPolicy(name, policyBuilder.Build());
            }
            //--TRIMMABLE-BOUNDARY-END(17180000368)
            
            //--TRIMMABLE-BOUNDARY-START(21474967664)
            /*AuthorizationBuilder */ AddFallbackPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetFallbackPolicy(policy);
                return this.AddPolicy(name, policy);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967664)
            
            //--TRIMMABLE-BOUNDARY-START(25769934960)
            /*AuthorizationBuilder */ AddFallbackPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.MAA.AuthorizationPolicyBuilder().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddFallbackPolicy(name, policyBuilder.Build());
            }
            //--TRIMMABLE-BOUNDARY-END(25769934960)
            
            static $h = 131184;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244771440),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949804144,
        "f": 50331777
      },
      "n": "Services",
      "d": 131184,
      "h": 47244771440,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47244771440)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129673328),
    {
      "r": 131184,
      "p": [
        {
          "n": "invoke",
          "p": 262145
        }
      ],
      "n": "SetInvokeHandlersAfterFailure",
      "d": 131184,
      "h": 60129673328,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60129673328),
//--TRIMMABLE-BOUNDARY-START(51539738736),
    {
      "r": 131184,
      "p": [
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "SetDefaultPolicy",
      "d": 131184,
      "h": 51539738736,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51539738736),
//--TRIMMABLE-BOUNDARY-START(55834706032),
    {
      "r": 131184,
      "p": [
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "SetFallbackPolicy",
      "d": 131184,
      "h": 55834706032,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55834706032),
//--TRIMMABLE-BOUNDARY-START(30064902256),
    {
      "r": 131184,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "AddPolicy",
      "d": 131184,
      "h": 30064902256,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30064902256),
//--TRIMMABLE-BOUNDARY-START(34359869552),
    {
      "r": 131184,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.S.Action$$($.$maa.MAA.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddPolicy",
      "o": "@$1",
      "d": 131184,
      "h": 34359869552,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34359869552),
//--TRIMMABLE-BOUNDARY-START(12885033072),
    {
      "r": 131184,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "AddDefaultPolicy",
      "d": 131184,
      "h": 12885033072,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885033072),
//--TRIMMABLE-BOUNDARY-START(17180000368),
    {
      "r": 131184,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.S.Action$$($.$maa.MAA.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddDefaultPolicy",
      "o": "@$1",
      "d": 131184,
      "h": 17180000368,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180000368),
//--TRIMMABLE-BOUNDARY-START(21474967664),
    {
      "r": 131184,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "AddFallbackPolicy",
      "d": 131184,
      "h": 21474967664,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21474967664),
//--TRIMMABLE-BOUNDARY-START(25769934960),
    {
      "r": 131184,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "configurePolicy",
          "p": $.$$.S.Action$$($.$maa.MAA.AuthorizationPolicyBuilder).$h
        }
      ],
      "n": "AddFallbackPolicy",
      "o": "@$1",
      "d": 131184,
      "h": 25769934960,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25769934960)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065776),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131184,
      "h": 8590065776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065776)
  ],
  "h": 131184
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131184)
        
        

        //--TRIMMABLE-BOUNDARY-START(721008)
        $asm.$cls(`$maa.MAA.AuthorizationPolicyBuilder`, ($self) => class AuthorizationPolicyBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688304)
            /*DenyAnonymousAuthorizationRequirement*/ static _denyAnonymousAuthorizationRequirement = null;
            //--TRIMMABLE-BOUNDARY-END(4295688304)
            
            //--TRIMMABLE-BOUNDARY-START(25770524784)
            $ctor$2(/*params string[]*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524784);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AddAuthenticationSchemes(authenticationSchemes);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524784)
            
            //--TRIMMABLE-BOUNDARY-START(21475557488)
            $ctor$1(/*AuthorizationPolicy*/ policy)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557488);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Combine(policy);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557488)
            
            //--TRIMMABLE-BOUNDARY-START(103079936112)
            /*IList<IAuthorizationRequirement>*/ Requirements = null;
            //--TRIMMABLE-BOUNDARY-END(103079936112)
            
            //--TRIMMABLE-BOUNDARY-START(47245361264)
            /*IList<string>*/ AuthenticationSchemes = null;
            //--TRIMMABLE-BOUNDARY-END(47245361264)
            
            //--TRIMMABLE-BOUNDARY-START(30065492080)
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemes(/*params string[]*/ schemes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065492080);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AddAuthenticationSchemesCore(schemes);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065492080)
            
            //--TRIMMABLE-BOUNDARY-START(34360459376)
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemesCore(/*IEnumerable<string>*/ schemes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = schemes.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let authType = $en1.SCG$IEnumerator$$$Current;
                    {
                        this.AuthenticationSchemes.SCG$ICollection$$$Add(authType);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360459376)
            
            //--TRIMMABLE-BOUNDARY-START(38655426672)
            /*AuthorizationPolicyBuilder */ AddRequirements(/*params IAuthorizationRequirement[]*/ requirements)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426672);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AddRequirementsCore(requirements);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655426672)
            
            //--TRIMMABLE-BOUNDARY-START(42950393968)
            /*AuthorizationPolicyBuilder */ AddRequirementsCore(/*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en2 = requirements.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let req = $en2.SCG$IEnumerator$$$Current;
                    {
                        this.Requirements.SCG$ICollection$$$Add(req);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393968)
            
            //--TRIMMABLE-BOUNDARY-START(55835295856)
            /*AuthorizationPolicyBuilder */ Combine(/*AuthorizationPolicy*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.AddAuthenticationSchemesCore(policy.AuthenticationSchemes);
                this.AddRequirementsCore(policy.Requirements);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295856)
            
            //--TRIMMABLE-BOUNDARY-START(94490001520)
            /*AuthorizationPolicyBuilder */ RequireClaim$1(/*string*/ claimType, /*params string[]*/ allowedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                return this.RequireClaim(claimType, allowedValues);
            }
            //--TRIMMABLE-BOUNDARY-END(94490001520)
            
            //--TRIMMABLE-BOUNDARY-START(90195034224)
            /*AuthorizationPolicyBuilder */ RequireClaim(/*string*/ claimType, /*IEnumerable<string>*/ allowedValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.SCG$ICollection$$$Add(new $.$maa.MAAI.ClaimsAuthorizationRequirement().$ctor$2(claimType, allowedValues));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90195034224)
            
            //--TRIMMABLE-BOUNDARY-START(98784968816)
            /*AuthorizationPolicyBuilder */ RequireClaim$2(/*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.SCG$ICollection$$$Add(new $.$maa.MAAI.ClaimsAuthorizationRequirement().$ctor$2(claimType, null));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(98784968816)
            
            //--TRIMMABLE-BOUNDARY-START(111669870704)
            /*AuthorizationPolicyBuilder */ RequireRole$1(/*params string[]*/ roles)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                return this.RequireRole(roles);
            }
            //--TRIMMABLE-BOUNDARY-END(111669870704)
            
            //--TRIMMABLE-BOUNDARY-START(107374903408)
            /*AuthorizationPolicyBuilder */ RequireRole(/*IEnumerable<string>*/ roles)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                this.Requirements.SCG$ICollection$$$Add(new $.$maa.MAAI.RolesAuthorizationRequirement().$ctor$2(roles));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(107374903408)
            
            //--TRIMMABLE-BOUNDARY-START(115964838000)
            /*AuthorizationPolicyBuilder */ RequireUserName(/*string*/ userName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964838000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(userName, "userName");
                this.Requirements.SCG$ICollection$$$Add(new $.$maa.MAAI.NameAuthorizationRequirement().$ctor$2(userName));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115964838000)
            
            //--TRIMMABLE-BOUNDARY-START(85900066928)
            /*AuthorizationPolicyBuilder */ RequireAuthenticatedUser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Requirements.SCG$ICollection$$$Add($.$maa.MAA.AuthorizationPolicyBuilder._denyAnonymousAuthorizationRequirement);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066928)
            
            //--TRIMMABLE-BOUNDARY-START(77310132336)
            /*AuthorizationPolicyBuilder */ RequireAssertion(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.SCG$ICollection$$$Add(new $.$maa.MAAI.AssertionRequirement().$ctor$1(handler));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310132336)
            
            //--TRIMMABLE-BOUNDARY-START(81605099632)
            /*AuthorizationPolicyBuilder */ RequireAssertion$1(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.SCG$ICollection$$$Add(new $.$maa.MAAI.AssertionRequirement().$ctor$2(handler));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605099632)
            
            //--TRIMMABLE-BOUNDARY-START(51540328560)
            /*AuthorizationPolicy */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$maa.MAA.AuthorizationPolicy().$ctor$1(this.Requirements, $.$sl.SL.Enumerable.Distinct$1($.$$.S.String, this.AuthenticationSchemes));
            }
            //--TRIMMABLE-BOUNDARY-END(51540328560)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(103079936112)
                this.Requirements = new ($.$$.SCG.List$$($.$maa.MAA.IAuthorizationRequirement))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(103079936112)
                
                //--TRIMMABLE-BOUNDARY-START(47245361264)
                this.AuthenticationSchemes = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(47245361264)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17180590192)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688304)
                    this._denyAnonymousAuthorizationRequirement = new $.$maa.MAAI.DenyAnonymousAuthorizationRequirement().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(4295688304)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180590192)
            
            static $h = 721008;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079936112),
    {
      "p": $.$$.SCG.IList$$($.$maa.MAA.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015165040,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144707184,
        "f": 83886081
      },
      "n": "Requirements",
      "d": 721008,
      "h": 103079936112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079936112),
//--TRIMMABLE-BOUNDARY-START(47245361264),
    {
      "p": $.$$.SCG.IList$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425230448,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554772592,
        "f": 83886081
      },
      "n": "AuthenticationSchemes",
      "d": 721008,
      "h": 47245361264,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245361264)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065492080),
    {
      "r": 721008,
      "p": [
        {
          "n": "schemes",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "AddAuthenticationSchemes",
      "d": 721008,
      "h": 30065492080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065492080),
//--TRIMMABLE-BOUNDARY-START(34360459376),
    {
      "r": 721008,
      "p": [
        {
          "n": "schemes",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "AddAuthenticationSchemesCore",
      "d": 721008,
      "h": 34360459376,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360459376),
//--TRIMMABLE-BOUNDARY-START(38655426672),
    {
      "r": 721008,
      "p": [
        {
          "n": "requirements",
          "p": $.$typeArray($.$maa.MAA.IAuthorizationRequirement).$h,
          "f": 16
        }
      ],
      "n": "AddRequirements",
      "d": 721008,
      "h": 38655426672,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426672),
//--TRIMMABLE-BOUNDARY-START(42950393968),
    {
      "r": 721008,
      "p": [
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        }
      ],
      "n": "AddRequirementsCore",
      "d": 721008,
      "h": 42950393968,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393968),
//--TRIMMABLE-BOUNDARY-START(55835295856),
    {
      "r": 721008,
      "p": [
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": "Combine",
      "d": 721008,
      "h": 55835295856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835295856),
//--TRIMMABLE-BOUNDARY-START(94490001520),
    {
      "r": 721008,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "allowedValues",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RequireClaim",
      "o": "@$1",
      "d": 721008,
      "h": 94490001520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490001520),
//--TRIMMABLE-BOUNDARY-START(90195034224),
    {
      "r": 721008,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "allowedValues",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "RequireClaim",
      "d": 721008,
      "h": 90195034224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195034224),
//--TRIMMABLE-BOUNDARY-START(98784968816),
    {
      "r": 721008,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "RequireClaim",
      "o": "@$2",
      "d": 721008,
      "h": 98784968816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784968816),
//--TRIMMABLE-BOUNDARY-START(111669870704),
    {
      "r": 721008,
      "p": [
        {
          "n": "roles",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RequireRole",
      "o": "@$1",
      "d": 721008,
      "h": 111669870704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669870704),
//--TRIMMABLE-BOUNDARY-START(107374903408),
    {
      "r": 721008,
      "p": [
        {
          "n": "roles",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "RequireRole",
      "d": 721008,
      "h": 107374903408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374903408),
//--TRIMMABLE-BOUNDARY-START(115964838000),
    {
      "r": 721008,
      "p": [
        {
          "n": "userName",
          "p": 1310721
        }
      ],
      "n": "RequireUserName",
      "d": 721008,
      "h": 115964838000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964838000),
//--TRIMMABLE-BOUNDARY-START(85900066928),
    {
      "r": 721008,
      "n": "RequireAuthenticatedUser",
      "d": 721008,
      "h": 85900066928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900066928),
//--TRIMMABLE-BOUNDARY-START(77310132336),
    {
      "r": 721008,
      "p": [
        {
          "n": "handler",
          "p": $.$$.S.Func$$$($.$maa.MAA.AuthorizationHandlerContext, $.$$.S.Boolean).$h
        }
      ],
      "n": "RequireAssertion",
      "d": 721008,
      "h": 77310132336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310132336),
//--TRIMMABLE-BOUNDARY-START(81605099632),
    {
      "r": 721008,
      "p": [
        {
          "n": "handler",
          "p": $.$$.S.Func$$$($.$maa.MAA.AuthorizationHandlerContext, $.$$.STT.Task$$($.$$.S.Boolean)).$h
        }
      ],
      "n": "RequireAssertion",
      "o": "@$1",
      "d": 721008,
      "h": 81605099632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605099632),
//--TRIMMABLE-BOUNDARY-START(51540328560),
    {
      "r": 655472,
      "n": "Build",
      "d": 721008,
      "h": 51540328560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328560)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688304),
    {
      "t": 2031728,
      "n": "_denyAnonymousAuthorizationRequirement",
      "d": 721008,
      "h": 4295688304,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295688304)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770524784),
    {
      "p": [
        {
          "n": "authenticationSchemes",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721008,
      "h": 25770524784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524784),
//--TRIMMABLE-BOUNDARY-START(21475557488),
    {
      "p": [
        {
          "n": "policy",
          "p": 655472
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721008,
      "h": 21475557488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557488)
  ],
  "h": 721008
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationPolicyBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721008)
        
        

        //--TRIMMABLE-BOUNDARY-START(2556016)
        $asm.$cls(`$maa.MEI.SecurityHelper`, ($self) => class SecurityHelper
        {
            //--TRIMMABLE-BOUNDARY-START(8592490608)
            static /*ClaimsPrincipal */ MergeUserPrincipal(/*ClaimsPrincipal?*/ existingPrincipal, /*ClaimsPrincipal?*/ additionalPrincipal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592490608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (existingPrincipal === null && additionalPrincipal !== null)
                {
                    return additionalPrincipal;
                }
                /*var*/ let newPrincipal = new $.$ssc.SSC.ClaimsPrincipal().$ctor$1();
                if (additionalPrincipal !== null)
                {
                    newPrincipal.AddIdentities(additionalPrincipal.Identities);
                }
                if (existingPrincipal !== null)
                {
                    newPrincipal.AddIdentities($.$sl.SL.Enumerable.Where($.$ssc.SSC.ClaimsIdentity, existingPrincipal.Identities, new ($.$$.S.Func$$$($.$ssc.SSC.ClaimsIdentity, $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                    {
                        return i.IsAuthenticated || $.$sl.SL.Enumerable.Any$1($.$ssc.SSC.Claim, i.Claims);
                    }, $pQKivc ??= {"r":262145,"p":[{"n":"i","p":262213}],"n":"","d":2556016,"h":0,"f":17825794})));
                }
                return newPrincipal;
            }
            //--TRIMMABLE-BOUNDARY-END(8592490608)
            
            //--TRIMMABLE-BOUNDARY-START(4297523312)
            static /*bool */ IsAuthenticated(/*ClaimsPrincipal?*/ user)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297523312);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !((user?.Identity ?? null) === null) && $.$sl.SL.Enumerable.Any($.$ssc.SSC.ClaimsIdentity, user.Identities, new ($.$$.S.Func$$$($.$ssc.SSC.ClaimsIdentity, $.$$.S.Boolean))().$ctor($.$maa.MEI.SecurityHelper, /*static*/ (/*identity*/ identity) =>
                    {
                        return identity.IsAuthenticated;
                    }, $ErxJrf ??= {"r":262145,"p":[{"n":"identity","p":262213}],"n":"","d":2556016,"h":0,"f":17825826}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297523312)
            
            static $h = 2556016;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592490608),
    {
      "r": 393285,
      "p": [
        {
          "n": "existingPrincipal",
          "p": 393285
        },
        {
          "n": "additionalPrincipal",
          "p": 393285
        }
      ],
      "n": "MergeUserPrincipal",
      "d": 2556016,
      "h": 8592490608,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592490608),
//--TRIMMABLE-BOUNDARY-START(4297523312),
    {
      "r": 262145,
      "p": [
        {
          "n": "user",
          "p": 393285
        }
      ],
      "n": "IsAuthenticated",
      "d": 2556016,
      "h": 4297523312,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297523312)
  ],
  "h": 2556016
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.SecurityHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}SecurityHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2556016)
        
        

        //--TRIMMABLE-BOUNDARY-START(655472)
        $asm.$cls(`$maa.MAA.AuthorizationPolicy`, ($self) => class AuthorizationPolicy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885557360)
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*IEnumerable<string>*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(authenticationSchemes, "authenticationSchemes");
                    if (!$.$sl.SL.Enumerable.Any$1($.$maa.MAA.IAuthorizationRequirement, requirements))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$maa.Resources.Exception_AuthorizationPolicyEmpty);
                    }
                    this.Requirements = new ($.$$.SCG.List$$($.$maa.MAA.IAuthorizationRequirement))().$ctor$2(requirements).AsReadOnly();
                    this.AuthenticationSchemes = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$2(authenticationSchemes).AsReadOnly();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557360)
            
            //--TRIMMABLE-BOUNDARY-START(55835230320)
            /*IReadOnlyList<IAuthorizationRequirement>*/ Requirements = null;
            //--TRIMMABLE-BOUNDARY-END(55835230320)
            
            //--TRIMMABLE-BOUNDARY-START(17180524656)
            /*IReadOnlyList<string>*/ AuthenticationSchemes = null;
            //--TRIMMABLE-BOUNDARY-END(17180524656)
            
            //--TRIMMABLE-BOUNDARY-START(21475491952)
            static /*AuthorizationPolicy */ Combine(/*params AuthorizationPolicy[]*/ policies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                return $.$maa.MAA.AuthorizationPolicy.Combine$1(policies);
            }
            //--TRIMMABLE-BOUNDARY-END(21475491952)
            
            //--TRIMMABLE-BOUNDARY-START(25770459248)
            static /*AuthorizationPolicy */ Combine$1(/*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                /*var*/ let builder = new $.$maa.MAA.AuthorizationPolicyBuilder().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                let $en1 = policies.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let policy = $en1.SCG$IEnumerator$$$Current;
                    {
                        builder.Combine(policy);
                    }
                }
                return builder.Build();
            }
            //--TRIMMABLE-BOUNDARY-END(25770459248)
            
            //--TRIMMABLE-BOUNDARY-START(34360393840)
            static /*Task<AuthorizationPolicy?> */ CombineAsync$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360393840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maa.MAA.AuthorizationPolicy.CombineAsync(policyProvider, authorizeData, $.$sl.SL.Enumerable.Empty($.$maa.MAA.AuthorizationPolicy));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360393840)
            
            //--TRIMMABLE-BOUNDARY-START(30065426544)
            static /*Task<AuthorizationPolicy?> *//*async*/  CombineAsync(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData, /*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy), $.$maa.MAA.AuthorizationPolicy, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065426544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(authorizeData, "authorizeData");
                    /*var*/ let anyPolicies = $.$sl.SL.Enumerable.Any$1($.$maa.MAA.AuthorizationPolicy, policies);
                    /*var*/ let skipEnumeratingData = false;
                    let dataList;
                    if ($.$is(authorizeData, $.$$.SCG.IList$$($.$mam.MAA.IAuthorizeData), { set $v($v){ dataList = $v; } }))
                    {
                        skipEnumeratingData = dataList.SCG$ICollection$$$Count === 0;
                    }
                    /*AuthorizationPolicyBuilder?*/ let policyBuilder = null;
                    if (!skipEnumeratingData)
                    {
                        let $en2 = authorizeData.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let authorizeDatum = $en2.SCG$IEnumerator$$$Current;
                            {
                                if (policyBuilder === null)
                                {
                                    policyBuilder = new $.$maa.MAA.AuthorizationPolicyBuilder().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                                }
                                /*var*/ let useDefaultPolicy = !(anyPolicies);
                                if (!$.$$.S.String.IsNullOrWhiteSpace(authorizeDatum.MAA$IAuthorizeData$Policy))
                                {
                                    let $t3, $r3;
                                    /*var*/ let policy = ($t3 = policyProvider.MAA$IAuthorizationPolicyProvider$GetPolicyAsync(authorizeDatum.MAA$IAuthorizeData$Policy).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                    if (policy === null)
                                    {
                                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$maa.Resources.FormatException_AuthorizationPolicyNotFound(authorizeDatum.MAA$IAuthorizeData$Policy));
                                    }
                                    policyBuilder.Combine(policy);
                                    useDefaultPolicy = false;
                                }
                                /*string?*/ let __ca1__;
                                /*var*/ let rolesSplit = ((__ca1__ = authorizeDatum.MAA$IAuthorizeData$Roles) !== null ? $.$$.S.String.Split$1.call(__ca1__, /*,*/ 44, 0) : null);
                                const $t4 = rolesSplit;
                                if ($.$$.S.Int32.op_GreaterThan($.$ifnn($t4, ($t) => $t.length), 0))
                                {
                                    /*var*/ let trimmedRolesSplit = $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, rolesSplit, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return !$.$$.S.String.IsNullOrWhiteSpace(r);
                                    }, $dHPlvb ??= {"r":262145,"p":[{"n":"r","p":1310721}],"n":"","d":655472,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return $.$$.S.String.Trim.call(r);
                                    }, $ObNBuf ??= {"r":1310721,"p":[{"n":"r","p":1310721}],"n":"","d":655472,"h":0,"f":17825794}));
                                    policyBuilder.RequireRole(trimmedRolesSplit);
                                    useDefaultPolicy = false;
                                }
                                /*string?*/ let __ca2__;
                                /*var*/ let authTypesSplit = ((__ca2__ = authorizeDatum.MAA$IAuthorizeData$AuthenticationSchemes) !== null ? $.$$.S.String.Split$1.call(__ca2__, /*,*/ 44, 0) : null);
                                const $t5 = authTypesSplit;
                                if ($.$$.S.Int32.op_GreaterThan($.$ifnn($t5, ($t) => $t.length), 0))
                                {
                                    let $i6 = 0;
                                    let $arr6 = authTypesSplit;
                                    while ($i6 < $arr6.length)
                                    {
                                        let authType = $arr6[$i6++];
                                        if (!$.$$.S.String.IsNullOrWhiteSpace(authType))
                                        {
                                            policyBuilder.AuthenticationSchemes.SCG$ICollection$$$Add($.$$.S.String.Trim.call(authType));
                                        }
                                    }
                                }
                                if (useDefaultPolicy)
                                {
                                    let $t7, $r7;
                                    policyBuilder.Combine(($t7 = policyProvider.MAA$IAuthorizationPolicyProvider$GetDefaultPolicyAsync().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7))));
                                }
                            }
                        }
                    }
                    if (anyPolicies)
                    {
                        policyBuilder ??= new $.$maa.MAA.AuthorizationPolicyBuilder().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                        let $en8 = policies.SCG$IEnumerable$$$GetEnumerator();
                        while ($en8.SC$1$IEnumerator$MoveNext())
                        {
                            let policy = $en8.SCG$IEnumerator$$$Current;
                            {
                                policyBuilder.Combine(policy);
                            }
                        }
                    }
                    if (policyBuilder === null)
                    {
                        let $t9, $r9;
                        /*var*/ let fallbackPolicy = ($t9 = policyProvider.MAA$IAuthorizationPolicyProvider$GetFallbackPolicyAsync().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        if (fallbackPolicy !== null)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, fallbackPolicy);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, policyBuilder?.Build() ?? null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065426544)
            
            static $h = 655472;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835230320),
    {
      "p": $.$$.SCG.IReadOnlyList$$($.$maa.MAA.IAuthorizationRequirement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540263024,
        "f": 50331649
      },
      "n": "Requirements",
      "d": 655472,
      "h": 55835230320,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835230320),
//--TRIMMABLE-BOUNDARY-START(17180524656),
    {
      "p": $.$$.SCG.IReadOnlyList$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950328432,
        "f": 50331649
      },
      "n": "AuthenticationSchemes",
      "d": 655472,
      "h": 17180524656,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524656)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475491952),
    {
      "r": 655472,
      "p": [
        {
          "n": "policies",
          "p": $.$typeArray($.$maa.MAA.AuthorizationPolicy).$h,
          "f": 16
        }
      ],
      "n": "Combine",
      "d": 655472,
      "h": 21475491952,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475491952),
//--TRIMMABLE-BOUNDARY-START(25770459248),
    {
      "r": 655472,
      "p": [
        {
          "n": "policies",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.AuthorizationPolicy).$h
        }
      ],
      "n": "Combine",
      "o": "@$1",
      "d": 655472,
      "h": 25770459248,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770459248),
//--TRIMMABLE-BOUNDARY-START(34360393840),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyProvider",
          "p": 1638512
        },
        {
          "n": "authorizeData",
          "p": $.$$.SCG.IEnumerable$$($.$mam.MAA.IAuthorizeData).$h
        }
      ],
      "n": "CombineAsync",
      "o": "@$1",
      "d": 655472,
      "h": 34360393840,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360393840),
//--TRIMMABLE-BOUNDARY-START(30065426544),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyProvider",
          "p": 1638512
        },
        {
          "n": "authorizeData",
          "p": $.$$.SCG.IEnumerable$$($.$mam.MAA.IAuthorizeData).$h
        },
        {
          "n": "policies",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.AuthorizationPolicy).$h
        }
      ],
      "n": "CombineAsync",
      "d": 655472,
      "h": 30065426544,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(30065426544)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557360),
    {
      "p": [
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        },
        {
          "n": "authenticationSchemes",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655472,
      "h": 12885557360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557360)
  ],
  "h": 655472
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizationPolicy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizationPolicy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655472)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048688)
        $asm.$cls(`$maa.MAA.DefaultAuthorizationHandlerContextFactory`, ($self) => class DefaultAuthorizationHandlerContextFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590983280)
            /*AuthorizationHandlerContext */ CreateContext(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$maa.MAA.AuthorizationHandlerContext().$ctor$1(requirements, user, resource);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983280)
            
            //--TRIMMABLE-BOUNDARY-START(4296474736)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory.CreateContext(System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>, System.Security.Claims.ClaimsPrincipal, object?)
            MAA$IAuthorizationHandlerContextFactory$CreateContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296474736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateContext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296474736)
            
            //--TRIMMABLE-BOUNDARY-START(4296015984)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015984)
            
            //--TRIMMABLE-BOUNDARY-START(4296015984)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296015984)
            
            static $h = 1048688;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983280),
    {
      "r": 458864,
      "p": [
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        },
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        }
      ],
      "n": "CreateContext",
      "d": 1048688,
      "h": 8590983280,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590983280)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015984),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048688,
      "h": 4296015984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015984)
  ],
  "h": 1048688
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandlerContextFactory ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerContextFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}DefaultAuthorizationHandlerContextFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048688)
        
        

        //--TRIMMABLE-BOUNDARY-START(983152)
        $asm.$cls(`$maa.MAA.DefaultAuthorizationEvaluator`, ($self) => class DefaultAuthorizationEvaluator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590917744)
            /*AuthorizationResult */ Evaluate(/*AuthorizationHandlerContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917744);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return context.HasSucceeded ? $.$maa.MAA.AuthorizationResult.Success() : $.$maa.MAA.AuthorizationResult.Failed$1(context.HasFailed ? $.$maa.MAA.AuthorizationFailure.Failed(context.FailureReasons) : $.$maa.MAA.AuthorizationFailure.Failed$1(context.PendingRequirements));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590917744)
            
            //--TRIMMABLE-BOUNDARY-START(4296343664)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator.Evaluate(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            MAA$IAuthorizationEvaluator$Evaluate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Evaluate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296343664)
            
            //--TRIMMABLE-BOUNDARY-START(4295950448)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950448)
            
            //--TRIMMABLE-BOUNDARY-START(4295950448)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950448)
            
            static $h = 983152;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917744),
    {
      "r": 786544,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "Evaluate",
      "d": 983152,
      "h": 8590917744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917744)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950448),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983152,
      "h": 4295950448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950448)
  ],
  "h": 983152
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationEvaluator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.DefaultAuthorizationEvaluator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}DefaultAuthorizationEvaluator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983152)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114224)
        $asm.$cls(`$maa.MAA.DefaultAuthorizationHandlerProvider`, ($self) => class DefaultAuthorizationHandlerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296081520)
            /*Task<IEnumerable<IAuthorizationHandler>>*/ _handlersTask = null;
            //--TRIMMABLE-BOUNDARY-END(4296081520)
            
            //--TRIMMABLE-BOUNDARY-START(8591048816)
            $ctor$1(/*IEnumerable<IAuthorizationHandler>*/ handlers)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591048816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    this._handlersTask = $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationHandler), handlers);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591048816)
            
            //--TRIMMABLE-BOUNDARY-START(12886016112)
            /*Task<IEnumerable<IAuthorizationHandler>> */ GetHandlersAsync(/*AuthorizationHandlerContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886016112);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._handlersTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886016112)
            
            //--TRIMMABLE-BOUNDARY-START(4296540272)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider.GetHandlersAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            MAA$IAuthorizationHandlerProvider$GetHandlersAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHandlersAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296540272)
            
            static $h = 1114224;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886016112),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationHandler)).$h,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "GetHandlersAsync",
      "d": 1114224,
      "h": 12886016112,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016112)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081520),
    {
      "t": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationHandler)).$h,
      "n": "_handlersTask",
      "d": 1114224,
      "h": 4296081520,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081520)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048816),
    {
      "p": [
        {
          "n": "handlers",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationHandler).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114224,
      "h": 8591048816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048816)
  ],
  "h": 1114224
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandlerProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}DefaultAuthorizationHandlerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114224)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228336)
        $asm.$cls(`$maa.MAAI.PassThroughAuthorizationHandler`, ($self) => class PassThroughAuthorizationHandler extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297195632)
            /*AuthorizationOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(4297195632)
            
            //--TRIMMABLE-BOUNDARY-START(8592162928)
            $ctor$1()
            {
                this.$ctor$2($.$meo.MEO.Options.Create($.$maa.MAA.AuthorizationOptions, new $.$maa.MAA.AuthorizationOptions().$ctor$1()));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592162928);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592162928)
            
            //--TRIMMABLE-BOUNDARY-START(12887130224)
            $ctor$2(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887130224);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._options = options.MEO$IOptions$Microsoft$AspNetCore$Authorization$AuthorizationOptions$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887130224)
            
            //--TRIMMABLE-BOUNDARY-START(17182097520)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182097520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = $.$sl.SL.Enumerable.OfType($.$maa.MAA.IAuthorizationHandler, context.Requirements).SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let handler = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            ($t2 = handler.MAA$IAuthorizationHandler$HandleAsync(context).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            if (!this._options.InvokeHandlersAfterFailure && context.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182097520)
            
            //--TRIMMABLE-BOUNDARY-START(4296409200)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            MAA$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409200)
            
            //--TRIMMABLE-BOUNDARY-START(8592162928)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592162928)
            
            static $h = 2228336;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182097520),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "HandleAsync",
      "d": 2228336,
      "h": 17182097520,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17182097520)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297195632),
    {
      "t": 589936,
      "n": "_options",
      "d": 2228336,
      "h": 4297195632,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297195632)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592162928),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228336,
      "h": 8592162928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592162928),
//--TRIMMABLE-BOUNDARY-START(12887130224),
    {
      "p": [
        {
          "n": "options",
          "p": $.$meo.MEO.IOptions$$($.$maa.MAA.AuthorizationOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228336,
      "h": 12887130224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887130224)
  ],
  "h": 2228336
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.Infrastructure.PassThroughAuthorizationHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}Infrastructure${separator}PassThroughAuthorizationHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228336)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179760)
        $asm.$cls(`$maa.MAA.DefaultAuthorizationPolicyProvider`, ($self) => class DefaultAuthorizationPolicyProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886081648)
            /*AuthorizationOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(12886081648)
            
            //--TRIMMABLE-BOUNDARY-START(4296147056)
            /*Task<AuthorizationPolicy>?*/ _cachedDefaultPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(4296147056)
            
            //--TRIMMABLE-BOUNDARY-START(8591114352)
            /*Task<AuthorizationPolicy?>?*/ _cachedFallbackPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(8591114352)
            
            //--TRIMMABLE-BOUNDARY-START(17181048944)
            $ctor$1(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181048944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    this._options = options.MEO$IOptions$Microsoft$AspNetCore$Authorization$AuthorizationOptions$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048944)
            
            //--TRIMMABLE-BOUNDARY-START(21476016240)
            /*Task<AuthorizationPolicy> */ GetDefaultPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._cachedDefaultPolicy === null || this._cachedDefaultPolicy.Result !== this._options.DefaultPolicy)
                {
                    this._cachedDefaultPolicy = $.$$.STT.Task.FromResult($.$maa.MAA.AuthorizationPolicy, this._options.DefaultPolicy);
                }
                return this._cachedDefaultPolicy;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016240)
            
            //--TRIMMABLE-BOUNDARY-START(25770983536)
            /*Task<AuthorizationPolicy?> */ GetFallbackPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._cachedFallbackPolicy === null || this._cachedFallbackPolicy.Result !== this._options.FallbackPolicy)
                {
                    this._cachedFallbackPolicy = $.$$.STT.Task.FromResult($.$maa.MAA.AuthorizationPolicy, this._options.FallbackPolicy);
                }
                return this._cachedFallbackPolicy;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983536)
            
            //--TRIMMABLE-BOUNDARY-START(30065950832)
            /*Task<AuthorizationPolicy?> */ GetPolicyAsync(/*string*/ policyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._options.GetPolicyTask(policyName);
            }
            //--TRIMMABLE-BOUNDARY-END(30065950832)
            
            //--TRIMMABLE-BOUNDARY-START(12886540400)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetPolicyAsync(string)
            MAA$IAuthorizationPolicyProvider$GetPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886540400)
            
            //--TRIMMABLE-BOUNDARY-START(4296605808)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetDefaultPolicyAsync()
            MAA$IAuthorizationPolicyProvider$GetDefaultPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDefaultPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296605808)
            
            //--TRIMMABLE-BOUNDARY-START(8591573104)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetFallbackPolicyAsync()
            MAA$IAuthorizationPolicyProvider$GetFallbackPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFallbackPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591573104)
            
            static $h = 1179760;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476016240),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "GetDefaultPolicyAsync",
      "d": 1179760,
      "h": 21476016240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016240),
//--TRIMMABLE-BOUNDARY-START(25770983536),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "GetFallbackPolicyAsync",
      "d": 1179760,
      "h": 25770983536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770983536),
//--TRIMMABLE-BOUNDARY-START(30065950832),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "GetPolicyAsync",
      "d": 1179760,
      "h": 30065950832,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065950832)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886081648),
    {
      "t": 589936,
      "n": "_options",
      "d": 1179760,
      "h": 12886081648,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081648),
//--TRIMMABLE-BOUNDARY-START(4296147056),
    {
      "t": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "_cachedDefaultPolicy",
      "d": 1179760,
      "h": 4296147056,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147056),
//--TRIMMABLE-BOUNDARY-START(8591114352),
    {
      "t": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "_cachedFallbackPolicy",
      "d": 1179760,
      "h": 8591114352,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114352)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048944),
    {
      "p": [
        {
          "n": "options",
          "p": $.$meo.MEO.IOptions$$($.$maa.MAA.AuthorizationOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179760,
      "h": 17181048944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048944)
  ],
  "h": 1179760
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationPolicyProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.DefaultAuthorizationPolicyProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}DefaultAuthorizationPolicyProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179760)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162800)
        $asm.$cls(`$maa.MAAI.OperationAuthorizationRequirement`, ($self) => class OperationAuthorizationRequirement extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476999280)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(21476999280)
            
            //--TRIMMABLE-BOUNDARY-START(34361901168)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("OperationAuthorizationRequirement")}:Name=${$.$strNN(this.Name)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(34361901168)
            
            //--TRIMMABLE-BOUNDARY-START(8592097392)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592097392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592097392)
            
            //--TRIMMABLE-BOUNDARY-START(8592097392)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592097392)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21476999280)
                this.Name = null;
                //--TRIMMABLE-BOUNDARY-END(21476999280)
                
            }
            static $h = 2162800;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476999280),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182031984,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066933872,
        "f": 83886081
      },
      "n": "Name",
      "d": 2162800,
      "h": 21476999280,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476999280)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361901168),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2162800,
      "h": 34361901168,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361901168)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592097392),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162800,
      "h": 8592097392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592097392)
  ],
  "h": 2162800
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.Infrastructure.OperationAuthorizationRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}Infrastructure${separator}OperationAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162800)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245296)
        $asm.$cls(`$maa.MAA.DefaultAuthorizationService`, ($self) => class DefaultAuthorizationService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476081776)
            /*AuthorizationOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(21476081776)
            
            //--TRIMMABLE-BOUNDARY-START(4296212592)
            /*IAuthorizationHandlerContextFactory*/ _contextFactory = null;
            //--TRIMMABLE-BOUNDARY-END(4296212592)
            
            //--TRIMMABLE-BOUNDARY-START(12886147184)
            /*IAuthorizationHandlerProvider*/ _handlers = null;
            //--TRIMMABLE-BOUNDARY-END(12886147184)
            
            //--TRIMMABLE-BOUNDARY-START(8591179888)
            /*IAuthorizationEvaluator*/ _evaluator = null;
            //--TRIMMABLE-BOUNDARY-END(8591179888)
            
            //--TRIMMABLE-BOUNDARY-START(25771049072)
            /*IAuthorizationPolicyProvider*/ _policyProvider = null;
            //--TRIMMABLE-BOUNDARY-END(25771049072)
            
            //--TRIMMABLE-BOUNDARY-START(17181114480)
            /*ILogger*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(17181114480)
            
            //--TRIMMABLE-BOUNDARY-START(30066016368)
            $ctor$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IAuthorizationHandlerProvider*/ handlers, /*ILogger<DefaultAuthorizationService>*/ logger, /*IAuthorizationHandlerContextFactory*/ contextFactory, /*IAuthorizationEvaluator*/ evaluator, /*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066016368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(contextFactory, "contextFactory");
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(evaluator, "evaluator");
                    this._options = options.MEO$IOptions$Microsoft$AspNetCore$Authorization$AuthorizationOptions$Value;
                    this._handlers = handlers;
                    this._policyProvider = policyProvider;
                    this._logger = logger;
                    this._evaluator = evaluator;
                    this._contextFactory = contextFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066016368)
            
            //--TRIMMABLE-BOUNDARY-START(34360983664)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationResult), $.$maa.MAA.AuthorizationResult, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360983664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    /*var*/ let authContext = this._contextFactory.MAA$IAuthorizationHandlerContextFactory$CreateContext(requirements, user, resource);
                    /*var*/ let handlers = ($t1 = this._handlers.MAA$IAuthorizationHandlerProvider$GetHandlersAsync(authContext).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    let $en2 = handlers.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let handler = $en2.SCG$IEnumerator$$$Current;
                        {
                            let $t3, $r3;
                            ($t3 = handler.MAA$IAuthorizationHandler$HandleAsync(authContext).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            if (!this._options.InvokeHandlersAfterFailure && authContext.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                    /*var*/ let result = this._evaluator.MAA$IAuthorizationEvaluator$Evaluate(authContext);
                    if (result.Succeeded)
                    {
                        $.$maa.MEL.LoggingExtensions.UserAuthorizationSucceeded(this._logger);
                    }
                    else 
                    {
                        $.$maa.MEL.LoggingExtensions.UserAuthorizationFailed(this._logger, result.Failure);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360983664)
            
            //--TRIMMABLE-BOUNDARY-START(38655950960)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationResult), $.$maa.MAA.AuthorizationResult, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655950960);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let policy = ($t4 = this.GetPolicyAsync(policyName).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t5 = $.$maa.MAA.AuthorizationServiceExtensions.AuthorizeAsync$1(this, user, resource, policy).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655950960)
            
            //--TRIMMABLE-BOUNDARY-START(42950918256)
            /*Task<AuthorizationPolicy> *//*async*/  GetPolicyAsync(/*string*/ policyName)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy), $.$maa.MAA.AuthorizationPolicy, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950918256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$firstOf(($t6 = this._policyProvider.MAA$IAuthorizationPolicyProvider$GetPolicyAsync(policyName).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`No policy found: ${$.$strNN(policyName)}.`) }));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950918256)
            
            //--TRIMMABLE-BOUNDARY-START(4296802416)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>)
            MAA$IAuthorizationService$AuthorizeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthorizeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296802416)
            
            //--TRIMMABLE-BOUNDARY-START(8591769712)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, string)
            MAA$IAuthorizationService$AuthorizeAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthorizeAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591769712)
            
            static $h = 1245296;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360983664),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        }
      ],
      "n": "AuthorizeAsync",
      "d": 1245296,
      "h": 34360983664,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(34360983664),
//--TRIMMABLE-BOUNDARY-START(38655950960),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$1",
      "d": 1245296,
      "h": 38655950960,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(38655950960),
//--TRIMMABLE-BOUNDARY-START(42950918256),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "GetPolicyAsync",
      "d": 1245296,
      "h": 42950918256,
      "f": 16781312
    },
//--TRIMMABLE-BOUNDARY-END(42950918256)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476081776),
    {
      "t": 589936,
      "n": "_options",
      "d": 1245296,
      "h": 21476081776,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476081776),
//--TRIMMABLE-BOUNDARY-START(4296212592),
    {
      "t": 1507440,
      "n": "_contextFactory",
      "d": 1245296,
      "h": 4296212592,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212592),
//--TRIMMABLE-BOUNDARY-START(12886147184),
    {
      "t": 1572976,
      "n": "_handlers",
      "d": 1245296,
      "h": 12886147184,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147184),
//--TRIMMABLE-BOUNDARY-START(8591179888),
    {
      "t": 1376368,
      "n": "_evaluator",
      "d": 1245296,
      "h": 8591179888,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179888),
//--TRIMMABLE-BOUNDARY-START(25771049072),
    {
      "t": 1638512,
      "n": "_policyProvider",
      "d": 1245296,
      "h": 25771049072,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771049072),
//--TRIMMABLE-BOUNDARY-START(17181114480),
    {
      "t": 917592,
      "n": "_logger",
      "d": 1245296,
      "h": 17181114480,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181114480)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066016368),
    {
      "p": [
        {
          "n": "policyProvider",
          "p": 1638512
        },
        {
          "n": "handlers",
          "p": 1572976
        },
        {
          "n": "logger",
          "p": $.$mexla.MEL.ILogger$$($.$maa.MAA.DefaultAuthorizationService).$h
        },
        {
          "n": "contextFactory",
          "p": 1507440
        },
        {
          "n": "evaluator",
          "p": 1376368
        },
        {
          "n": "options",
          "p": $.$meo.MEO.IOptions$$($.$maa.MAA.AuthorizationOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245296,
      "h": 30066016368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066016368)
  ],
  "h": 1245296
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.DefaultAuthorizationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}DefaultAuthorizationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245296)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900656)
        $asm.$cls(`$maa.MAAI.AssertionRequirement`, ($self) => class AssertionRequirement extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066671728)
            /*Func<AuthorizationHandlerContext, Task<bool>>*/ Handler = null;
            //--TRIMMABLE-BOUNDARY-END(30066671728)
            
            //--TRIMMABLE-BOUNDARY-START(8591835248)
            $ctor$1(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591835248);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = new ($.$$.S.Func$$$($.$maa.MAA.AuthorizationHandlerContext, $.$$.STT.Task$$($.$$.S.Boolean)))().$ctor(this,  (/*context*/ context) =>
                    {
                        return $.$$.STT.Task.FromResult($.$$.S.Boolean, handler.Invoke(context));
                    }, $MArwui ??= {"r":$.$$.STT.Task$$($.$$.S.Boolean).$h,"p":[{"n":"context","p":458864}],"n":"","d":1900656,"h":0,"f":17825794});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591835248)
            
            //--TRIMMABLE-BOUNDARY-START(12886802544)
            $ctor$2(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886802544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = handler;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886802544)
            
            //--TRIMMABLE-BOUNDARY-START(25771704432)
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771704432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (($t1 = this.Handler.Invoke(context).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))))
                    {
                        context.Succeed(this);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25771704432)
            
            //--TRIMMABLE-BOUNDARY-START(34361639024)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361639024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("Handler")} assertion should evaluate to true.`;
            }
            //--TRIMMABLE-BOUNDARY-END(34361639024)
            
            //--TRIMMABLE-BOUNDARY-START(4296409200)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            MAA$IAuthorizationHandler$HandleAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296409200)
            
            static $h = 1900656;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066671728),
    {
      "p": $.$$.S.Func$$$($.$maa.MAA.AuthorizationHandlerContext, $.$$.STT.Task$$($.$$.S.Boolean)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476737136,
        "f": 50331649
      },
      "n": "Handler",
      "d": 1900656,
      "h": 30066671728,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066671728)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771704432),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        }
      ],
      "n": "HandleAsync",
      "d": 1900656,
      "h": 25771704432,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25771704432),
//--TRIMMABLE-BOUNDARY-START(34361639024),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1900656,
      "h": 34361639024,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361639024)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591835248),
    {
      "p": [
        {
          "n": "handler",
          "p": $.$$.S.Func$$$($.$maa.MAA.AuthorizationHandlerContext, $.$$.S.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900656,
      "h": 8591835248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591835248),
//--TRIMMABLE-BOUNDARY-START(12886802544),
    {
      "p": [
        {
          "n": "handler",
          "p": $.$$.S.Func$$$($.$maa.MAA.AuthorizationHandlerContext, $.$$.STT.Task$$($.$$.S.Boolean)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900656,
      "h": 12886802544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802544)
  ],
  "h": 1900656
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler, $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}Infrastructure${separator}AssertionRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900656)
        
        

        //--TRIMMABLE-BOUNDARY-START(65648)
        $asm.$cls(`$maa.MAA.AllowAnonymousAttribute`, ($self) => class AllowAnonymousAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590000240)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "AllowAnonymous";
            }
            //--TRIMMABLE-BOUNDARY-END(8590000240)
            
            //--TRIMMABLE-BOUNDARY-START(4295032944)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032944)
            
            //--TRIMMABLE-BOUNDARY-START(4295032944)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032944)
            
            static $h = 65648;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000240),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 65648,
      "h": 8590000240,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590000240)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032944),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65648,
      "h": 4295032944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032944)
  ],
  "h": 65648,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 68,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{ToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.MAA.IAllowAnonymous ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AllowAnonymousAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65648)
        
        

        //--TRIMMABLE-BOUNDARY-START(917616)
        $asm.$cls(`$maa.MAA.AuthorizeAttribute`, ($self) => class AuthorizeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(17180786800)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786800);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786800)
            
            //--TRIMMABLE-BOUNDARY-START(21475754096)
            $ctor$3(/*string*/ policy)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754096);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Policy = policy;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754096)
            
            //--TRIMMABLE-BOUNDARY-START(55835492464)
            /*string?*/ Policy = null;
            //--TRIMMABLE-BOUNDARY-END(55835492464)
            
            //--TRIMMABLE-BOUNDARY-START(60130459760)
            /*string?*/ Roles = null;
            //--TRIMMABLE-BOUNDARY-END(60130459760)
            
            //--TRIMMABLE-BOUNDARY-START(25770721392)
            /*string?*/ AuthenticationSchemes = null;
            //--TRIMMABLE-BOUNDARY-END(25770721392)
            
            //--TRIMMABLE-BOUNDARY-START(90195230832)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195230832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maa.MAS.DebuggerHelpers.GetDebugText$3("Policy", this.Policy, "Roles", this.Roles, "AuthenticationSchemes", this.AuthenticationSchemes, false, "Authorize");
            }
            //--TRIMMABLE-BOUNDARY-END(90195230832)
            
            //--TRIMMABLE-BOUNDARY-START(21474967663)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get MAA$IAuthorizeData$Policy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Policy;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967663)
            
            //--TRIMMABLE-BOUNDARY-START(55834706031)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set MAA$IAuthorizeData$Policy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Policy = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706031)
            
            //--TRIMMABLE-BOUNDARY-START(30064902255)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get MAA$IAuthorizeData$Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Roles;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902255)
            
            //--TRIMMABLE-BOUNDARY-START(64424640623)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set MAA$IAuthorizeData$Roles(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Roles = value;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640623)
            
            //--TRIMMABLE-BOUNDARY-START(12885033071)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get MAA$IAuthorizeData$AuthenticationSchemes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticationSchemes;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033071)
            
            //--TRIMMABLE-BOUNDARY-START(47244771439)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set MAA$IAuthorizeData$AuthenticationSchemes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationSchemes = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771439)
            
            //--TRIMMABLE-BOUNDARY-START(17180786800)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180786800)
            
            static $h = 917616;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835492464),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590576,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310328944,
        "f": 83886081
      },
      "n": "Policy",
      "d": 917616,
      "h": 55835492464,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835492464),
//--TRIMMABLE-BOUNDARY-START(60130459760),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540525168,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900263536,
        "f": 83886081
      },
      "n": "Roles",
      "d": 917616,
      "h": 60130459760,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459760),
//--TRIMMABLE-BOUNDARY-START(25770721392),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655984,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720394352,
        "f": 83886081
      },
      "n": "AuthenticationSchemes",
      "d": 917616,
      "h": 25770721392,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770721392)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195230832),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 917616,
      "h": 90195230832,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195230832)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786800),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917616,
      "h": 17180786800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786800),
//--TRIMMABLE-BOUNDARY-START(21475754096),
    {
      "p": [
        {
          "n": "policy",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917616,
      "h": 21475754096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754096)
  ],
  "h": 917616,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 68,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{ToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.MAA.IAuthorizeData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.AuthorizeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}AuthorizeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917616)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031728)
        $asm.$cls(`$maa.MAAI.DenyAnonymousAuthorizationRequirement`, ($self) => class DenyAnonymousAuthorizationRequirement extends $.$maa.MAA.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8591966320)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*DenyAnonymousAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$maa.MEI.SecurityHelper.IsAuthenticated(context.User))
                {
                    context.Succeed(requirement);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8591966320)
            
            //--TRIMMABLE-BOUNDARY-START(12886933616)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("DenyAnonymousAuthorizationRequirement")}: Requires an authenticated user.`;
            }
            //--TRIMMABLE-BOUNDARY-END(12886933616)
            
            //--TRIMMABLE-BOUNDARY-START(4296999024)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296999024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296999024)
            
            //--TRIMMABLE-BOUNDARY-START(4296999024)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296999024)
            
            static $h = 2031728;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maa.MAA.AuthorizationHandler$$($.$maa.MAAI.DenyAnonymousAuthorizationRequirement); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591966320),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        },
        {
          "n": "requirement",
          "p": 2031728
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 2031728,
      "h": 8591966320,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591966320),
//--TRIMMABLE-BOUNDARY-START(12886933616),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2031728,
      "h": 12886933616,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886933616)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296999024),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031728,
      "h": 4296999024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296999024)
  ],
  "h": 2031728
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler, $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}Infrastructure${separator}DenyAnonymousAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031728)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097264)
        $asm.$cls(`$maa.MAAI.NameAuthorizationRequirement`, ($self) => class NameAuthorizationRequirement extends $.$maa.MAA.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8592031856)
            $ctor$2(/*string*/ requiredName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592031856);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(requiredName, "requiredName");
                    this.RequiredName = requiredName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592031856)
            
            //--TRIMMABLE-BOUNDARY-START(25771901040)
            /*string*/ RequiredName = null;
            //--TRIMMABLE-BOUNDARY-END(25771901040)
            
            //--TRIMMABLE-BOUNDARY-START(21476933744)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*NameAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476933744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context.User !== null)
                {
                    /*var*/ let succeed = false;
                    let $en1 = context.User.Identities.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let identity = $en1.SCG$IEnumerator$$$Current;
                        {
                            if ($.$$.S.String.Equals$3(identity.Name, requirement.RequiredName, 4/*StringComparison.Ordinal*/))
                            {
                                succeed = true;
                                break;
                            }
                        }
                    }
                    if (succeed)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(21476933744)
            
            //--TRIMMABLE-BOUNDARY-START(30066868336)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066868336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("NameAuthorizationRequirement")}:Requires a user identity with Name equal to ${$.$strNN(this.RequiredName)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(30066868336)
            
            static $h = 2097264;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maa.MAA.AuthorizationHandler$$($.$maa.MAAI.NameAuthorizationRequirement); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771901040),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181966448,
        "f": 50331649
      },
      "n": "RequiredName",
      "d": 2097264,
      "h": 25771901040,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771901040)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476933744),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        },
        {
          "n": "requirement",
          "p": 2097264
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 2097264,
      "h": 21476933744,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476933744),
//--TRIMMABLE-BOUNDARY-START(30066868336),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2097264,
      "h": 30066868336,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066868336)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592031856),
    {
      "p": [
        {
          "n": "requiredName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097264,
      "h": 8592031856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592031856)
  ],
  "h": 2097264
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler, $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}Infrastructure${separator}NameAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097264)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966192)
        $asm.$cls(`$maa.MAAI.ClaimsAuthorizationRequirement`, ($self) => class ClaimsAuthorizationRequirement extends $.$maa.MAA.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(4296933488)
            /*bool*/ _emptyAllowedValues = false;
            //--TRIMMABLE-BOUNDARY-END(4296933488)
            
            //--TRIMMABLE-BOUNDARY-START(17181835376)
            $ctor$2(/*string*/ claimType, /*IEnumerable<string>?*/ allowedValues)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181835376);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                    this.ClaimType = claimType;
                    this.AllowedValues = allowedValues;
                    this._emptyAllowedValues = this.AllowedValues === null || !$.$sl.SL.Enumerable.Any$1($.$$.S.String, this.AllowedValues);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181835376)
            
            //--TRIMMABLE-BOUNDARY-START(25771769968)
            /*string*/ ClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(25771769968)
            
            //--TRIMMABLE-BOUNDARY-START(21476802672)
            /*IEnumerable<string>?*/ AllowedValues = null;
            //--TRIMMABLE-BOUNDARY-END(21476802672)
            
            //--TRIMMABLE-BOUNDARY-START(47246606448)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*ClaimsAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246606448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    if (requirement._emptyAllowedValues)
                    {
                        let $en1 = context.User.Claims.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let claim = $en1.SCG$IEnumerator$$$Current;
                            {
                                if ($.$$.S.String.Equals$3(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    else 
                    {
                        let $en2 = context.User.Claims.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let claim = $en2.SCG$IEnumerator$$$Current;
                            {
                                if ($.$$.S.String.Equals$3(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$sl.SL.Enumerable.Contains($.$$.S.String, requirement.AllowedValues, claim.Value, $.$$.S.StringComparer.Ordinal))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47246606448)
            
            //--TRIMMABLE-BOUNDARY-START(51541573744)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541573744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let value = (this._emptyAllowedValues) ? $.$$.S.String.Empty : ` and Claim.Value is one of the following values: (${$.$strNN($.$$.S.String.Join$5("|", this.AllowedValues))})`;
                return `${$.$strNN("ClaimsAuthorizationRequirement")}:Claim.Type=${$.$strNN(this.ClaimType)}${$.$strNN(value)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(51541573744)
            
            static $h = 1966192;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maa.MAA.AuthorizationHandler$$($.$maa.MAAI.ClaimsAuthorizationRequirement); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771769968),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951639152,
        "f": 50331649
      },
      "n": "ClaimType",
      "d": 1966192,
      "h": 25771769968,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771769968),
//--TRIMMABLE-BOUNDARY-START(21476802672),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361704560,
        "f": 50331649
      },
      "n": "AllowedValues",
      "d": 1966192,
      "h": 21476802672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476802672)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246606448),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        },
        {
          "n": "requirement",
          "p": 1966192
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 1966192,
      "h": 47246606448,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246606448),
//--TRIMMABLE-BOUNDARY-START(51541573744),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1966192,
      "h": 51541573744,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541573744)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296933488),
    {
      "t": 262145,
      "n": "_emptyAllowedValues",
      "d": 1966192,
      "h": 4296933488,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933488)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181835376),
    {
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "allowedValues",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966192,
      "h": 17181835376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181835376)
  ],
  "h": 1966192
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler, $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}Infrastructure${separator}ClaimsAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966192)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293872)
        $asm.$cls(`$maa.MAAI.RolesAuthorizationRequirement`, ($self) => class RolesAuthorizationRequirement extends $.$maa.MAA.AuthorizationHandler$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8592228464)
            $ctor$2(/*IEnumerable<string>*/ allowedRoles)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592228464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$maa.MAS.ArgumentNullThrowHelper.ThrowIfNull(allowedRoles, "allowedRoles");
                    if (!$.$sl.SL.Enumerable.Any$1($.$$.S.String, allowedRoles))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$maa.Resources.Exception_RoleRequirementEmpty);
                    }
                    this.AllowedRoles = allowedRoles;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592228464)
            
            //--TRIMMABLE-BOUNDARY-START(12887195760)
            /*IEnumerable<string>*/ AllowedRoles = null;
            //--TRIMMABLE-BOUNDARY-END(12887195760)
            
            //--TRIMMABLE-BOUNDARY-START(25772097648)
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*RolesAuthorizationRequirement*/ requirement)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772097648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    let $en1 = requirement.AllowedRoles.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let role = $en1.SCG$IEnumerator$$$Current;
                        {
                            if (context.User.IsInRole(role))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(25772097648)
            
            //--TRIMMABLE-BOUNDARY-START(30067064944)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067064944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let roles = `User.IsInRole must be true for one of the following roles: (${$.$strNN($.$$.S.String.Join$5("|", this.AllowedRoles))})`;
                return `${$.$strNN("RolesAuthorizationRequirement")}:${$.$strNN(roles)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(30067064944)
            
            static $h = 2293872;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maa.MAA.AuthorizationHandler$$($.$maa.MAAI.RolesAuthorizationRequirement); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887195760),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477130352,
        "f": 50331649
      },
      "n": "AllowedRoles",
      "d": 2293872,
      "h": 12887195760,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887195760)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772097648),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 458864
        },
        {
          "n": "requirement",
          "p": 2293872
        }
      ],
      "n": "HandleRequirementAsync",
      "d": 2293872,
      "h": 25772097648,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25772097648),
//--TRIMMABLE-BOUNDARY-START(30067064944),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2293872,
      "h": 30067064944,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067064944)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592228464),
    {
      "p": [
        {
          "n": "allowedRoles",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293872,
      "h": 8592228464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592228464)
  ],
  "h": 2293872
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationHandler, $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}Infrastructure${separator}RolesAuthorizationRequirement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293872)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310832)
        $asm.$cls(`$maa.MAA.DefaultAuthorizationServiceImpl`, ($self) => class DefaultAuthorizationServiceImpl extends $.$maa.MAA.DefaultAuthorizationService
        {
            //--TRIMMABLE-BOUNDARY-START(12886212720)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationResult), $.$maa.MAA.AuthorizationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886212720);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        let $t1, $r1;
                        result = ($t1 = super.AuthorizeAsync(user, resource, requirements).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, null, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, null, result, null);
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12886212720)
            
            //--TRIMMABLE-BOUNDARY-START(17181180016)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationResult), $.$maa.MAA.AuthorizationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181180016);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        /*var*/ let policy = ($t2 = this.GetPolicyAsync(policyName).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        result = ($t3 = super.AuthorizeAsync(user, resource, policy.Requirements).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, policyName, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, policyName, result, null);
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181180016)
            
            //Begin primary constructor
            /*IAuthorizationPolicyProvider*/ policyProvider = null;
            /*IAuthorizationHandlerProvider*/ handlers = null;
            /*ILogger<DefaultAuthorizationService>*/ logger = null;
            /*IAuthorizationHandlerContextFactory*/ contextFactory = null;
            /*IAuthorizationEvaluator*/ evaluator = null;
            /*IOptions<AuthorizationOptions>*/ options = null;
            /*AuthorizationMetrics*/ metrics = null;
            $ctor$2(/*IAuthorizationPolicyProvider*/policyProvider, /*IAuthorizationHandlerProvider*/handlers, /*ILogger<DefaultAuthorizationService>*/logger, /*IAuthorizationHandlerContextFactory*/contextFactory, /*IAuthorizationEvaluator*/evaluator, /*IOptions<AuthorizationOptions>*/options, /*AuthorizationMetrics*/metrics)
            {
                this.policyProvider = policyProvider;
                this.handlers = handlers;
                this.logger = logger;
                this.contextFactory = contextFactory;
                this.evaluator = evaluator;
                this.options = options;
                this.metrics = metrics;
                super.$ctor$1(this.policyProvider, this.handlers, this.logger, this.contextFactory, this.evaluator, this.options);
                return this
            }
            //End primary constructor
            static $h = 1310832;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maa.MAA.DefaultAuthorizationService; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886212720),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        }
      ],
      "n": "AuthorizeAsync",
      "d": 1310832,
      "h": 12886212720,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(12886212720),
//--TRIMMABLE-BOUNDARY-START(17181180016),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$1",
      "d": 1310832,
      "h": 17181180016,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(17181180016)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296278128),
    {
      "t": 524400,
      "n": "\u003Cmetrics\u003EP",
      "d": 1310832,
      "h": 4296278128,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245424),
    {
      "p": [
        {
          "n": "policyProvider",
          "p": 1638512
        },
        {
          "n": "handlers",
          "p": 1572976
        },
        {
          "n": "logger",
          "p": $.$mexla.MEL.ILogger$$($.$maa.MAA.DefaultAuthorizationService).$h
        },
        {
          "n": "contextFactory",
          "p": 1507440
        },
        {
          "n": "evaluator",
          "p": 1376368
        },
        {
          "n": "options",
          "p": $.$meo.MEO.IOptions$$($.$maa.MAA.AuthorizationOptions).$h
        },
        {
          "n": "metrics",
          "p": 524400
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310832,
      "h": 8591245424,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591245424)
  ],
  "h": 1310832
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.DefaultAuthorizationServiceImpl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}DefaultAuthorizationServiceImpl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310832)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions"));
})();
//--TRIMMABLE-BOUNDARY-END(112)
