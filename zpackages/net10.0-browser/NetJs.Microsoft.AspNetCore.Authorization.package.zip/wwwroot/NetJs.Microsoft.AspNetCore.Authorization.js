
(function ($global, $, $spc, $mam, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Authorization", 
    {"h":51286,"f":"Microsoft.AspNetCore.Authorization","v":"1.0.35.0","a":[{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"ASP.NET Core authorization classes.\nCommonly used types:\nMicrosoft.AspNetCore.Authorization.AllowAnonymousAttribute\nMicrosoft.AspNetCore.Authorization.AuthorizeAttribute","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Authorization","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Authorization","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.AspNetCore.Authorization.Test","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":96337921,"c":4391305217,"a":[{"v":188135,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":122599,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator", ($self) => class IAuthorizationEvaluator
        {
            static $h = 1427542;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":837718,"p":[{"n":"context","p":510038}],"n":"Evaluate","o":"Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate","d":1427542,"h":4296394838,"f":257}],"h":1427542}; }
            static get $fullName() { return `IAuthorizationEvaluator`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider", ($self) => class IAuthorizationPolicyProvider
        {
            static $h = 1689686;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyName","p":1310721}],"n":"GetPolicyAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync","d":1689686,"h":4296656982,"f":257},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetDefaultPolicyAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync","d":1689686,"h":8591624278,"f":257},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetFallbackPolicyAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync","d":1689686,"h":12886591574,"f":257}],"h":1689686}; }
            static get $fullName() { return `IAuthorizationPolicyProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider", ($self) => class IAuthorizationHandlerProvider
        {
            static $h = 1624150;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,"p":[{"n":"context","p":510038}],"n":"GetHandlersAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync","d":1624150,"h":4296591446,"f":257}],"h":1624150}; }
            static get $fullName() { return `IAuthorizationHandlerProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirementData", ($self) => class IAuthorizationRequirementData
        {
            static $h = 1820758;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"n":"GetRequirements","o":"Microsoft$AspNetCore$Authorization$IAuthorizationRequirementData$GetRequirements","d":1820758,"h":4296788054,"f":257}],"h":1820758}; }
            static get $fullName() { return `IAuthorizationRequirementData`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement", ($self) => class IAuthorizationRequirement
        {
            static $h = 1755222;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":1755222}; }
            static get $fullName() { return `IAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler", ($self) => class IAuthorizationHandler
        {
            static $h = 1493078;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133300225,"p":[{"n":"context","p":510038}],"n":"HandleAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync","d":1493078,"h":4296460374,"f":257}],"h":1493078}; }
            static get $fullName() { return `IAuthorizationHandler`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService", ($self) => class IAuthorizationService
        {
            static $h = 1886294;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AuthorizeAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync","d":1886294,"h":4296853590,"f":257},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1","d":1886294,"h":8591820886,"f":257}],"h":1886294}; }
            static get $fullName() { return `IAuthorizationService`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory", ($self) => class IAuthorizationHandlerContextFactory
        {
            static $h = 1558614;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":510038,"p":[{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"user","p":425999},{"n":"resource","p":131073}],"n":"CreateContext","o":"Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext","d":1558614,"h":4296525910,"f":257}],"h":1558614}; }
            static get $fullName() { return `IAuthorizationHandlerContextFactory`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<>", (TRequirement) => $asm.$gt("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<>", [TRequirement], ($self) => class AuthorizationHandler$$ extends $.$spc.System.Object
        {
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    var $en3 = $.$sl.System.Linq.Enumerable.OfType(TRequirement, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var req = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await this.HandleRequirementAsync(context, req).ConfigureAwait(false);
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 444502;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"context","p":510038}],"n":"HandleAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4225},{"r":133300225,"p":[{"n":"context","p":510038},{"n":"requirement","p":TRequirement?.$h??1507328}],"n":"HandleRequirementAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":260}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4}],"i":[1493078],"g":[TRequirement?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `AuthorizationHandler<${TRequirement?.$fullName}>`; }
        }));
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<,>", (TRequirement, TResource) => $asm.$gt("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<,>", [TRequirement, TResource], ($self) => class AuthorizationHandler$$$ extends $.$spc.System.Object
        {
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    let resource;
                    if ($.$is(context.Resource, TResource, { set $v(v){ resource = v; } }))
                    {
                        var $en4 = $.$sl.System.Linq.Enumerable.OfType(TRequirement, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var req = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                await this.HandleRequirementAsync(context, req, resource).ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 378966;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"context","p":510038}],"n":"HandleAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4225},{"r":133300225,"p":[{"n":"context","p":510038},{"n":"requirement","p":TRequirement?.$h??1507328},{"n":"resource","p":TResource?.$h??1572864}],"n":"HandleRequirementAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":260}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4}],"i":[1493078],"g":[TRequirement?.$h??1507328,TResource?.$h??1572864],"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `AuthorizationHandler<${TRequirement?.$fullName},${TResource?.$fullName}>`; }
        }));
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext", ($self) => class AuthorizationHandlerContext extends $.$spc.System.Object
        {
            /*HashSet<IAuthorizationRequirement>*/ _pendingRequirements = null;
            /*List<AuthorizationFailureReason>?*/ _failedReasons = null;
            /*bool*/ _failCalled = false;
            /*bool*/ _succeedCalled = false;
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    this.Requirements = requirements;
                    this.User = user;
                    this.Resource = resource;
                    this._pendingRequirements = new ($.$spc.System.Collections.Generic.HashSet$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$4(requirements);
                }
                return this;
            }
            /*IEnumerable<IAuthorizationRequirement>*/ Requirements = null;
            /*ClaimsPrincipal*/ User = null;
            /*object?*/ Resource = null;
            /*IEnumerable<IAuthorizationRequirement> */ get PendingRequirements()
            {
                return this._pendingRequirements;
            }
            /*IEnumerable<AuthorizationFailureReason> */ get FailureReasons()
            {
                return this._failedReasons ?? $.$spc.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason);
            }
            /*bool */ get HasFailed()
            {
                return this._failCalled;
            }
            /*bool */ get HasSucceeded()
            {
                return !this._failCalled && this._succeedCalled && !$.$sl.System.Linq.Enumerable.Any($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, this.PendingRequirements);
            }
            /*void */ Fail()
            {
                this._failCalled = true;
            }
            /*void */ Fail$1(/*AuthorizationFailureReason*/ reason)
            {
                this.Fail();
                if (reason !== null)
                {
                    if (this._failedReasons === null)
                    {
                        this._failedReasons = new ($.$spc.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason))().$ctor$1();
                    }
                    this._failedReasons.Add(reason);
                }
            }
            /*void */ Succeed(/*IAuthorizationRequirement*/ requirement)
            {
                this._succeedCalled = true;
                this._pendingRequirements.Remove(requirement);
            }
            static $h = 510038;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":34360248406,"f":129},"n":"Requirements","d":510038,"h":30065281110,"f":129},{"p":425999,"g":{"r":0,"d":0,"h":47245150294,"f":129},"n":"User","d":510038,"h":42950182998,"f":129},{"p":131073,"g":{"r":0,"d":0,"h":60130052182,"f":129},"n":"Resource","d":510038,"h":55835084886,"f":129},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":68719986774,"f":129},"n":"PendingRequirements","d":510038,"h":64425019478,"f":129},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,"g":{"r":0,"d":0,"h":77309921366,"f":129},"n":"FailureReasons","d":510038,"h":73014954070,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":85899855958,"f":129},"n":"HasFailed","d":510038,"h":81604888662,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":94489790550,"f":129},"n":"HasSucceeded","d":510038,"h":90194823254,"f":129}],"m":[{"r":65537,"n":"Fail","d":510038,"h":98784757846,"f":129},{"r":65537,"p":[{"n":"reason","p":313430}],"n":"Fail","o":"@$1","d":510038,"h":103079725142,"f":129},{"r":65537,"p":[{"n":"requirement","p":1755222}],"n":"Succeed","d":510038,"h":107374692438,"f":129}],"l":[{"t":$.$spc.System.Collections.Generic.HashSet$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"n":"_pendingRequirements","d":510038,"h":4295477334,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,"n":"_failedReasons","d":510038,"h":8590444630,"f":2},{"t":262145,"n":"_failCalled","d":510038,"h":12885411926,"f":2},{"t":262145,"n":"_succeedCalled","d":510038,"h":17180379222,"f":2}],"c":[{"p":[{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"user","p":425999},{"n":"resource","p":131073}],"n":".ctor","o":"$ctor$1","d":510038,"h":21475346518,"f":1}],"h":510038}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationHandlerContext`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions", ($self) => class AuthorizationOptions extends $.$spc.System.Object
        {
            /*Task<AuthorizationPolicy?>*/ static _nullPolicyTask = null;
            /*Dictionary<string, Task<AuthorizationPolicy?>>*/ PolicyMap = null;
            /*bool*/ InvokeHandlersAfterFailure = false;
            /*AuthorizationPolicy*/ DefaultPolicy = null;
            /*AuthorizationPolicy?*/ FallbackPolicy = null;
            /*void */ AddPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.PolicyMap.set_Item(name, $.$spc.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policy));
            }
            /*void */ AddPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                this.PolicyMap.set_Item(name, $.$spc.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policyBuilder.Build()));
            }
            /*AuthorizationPolicy? */ GetPolicy(/*string*/ name)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value;
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy))))
                {
                    return value.Result;
                }
                return null;
            }
            /*Task<AuthorizationPolicy?> */ GetPolicyTask(/*string*/ name)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value;
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy))))
                {
                    return value;
                }
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions._nullPolicyTask;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PolicyMap = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy)))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                this.InvokeHandlersAfterFailure = true;
                this.DefaultPolicy = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [  ], null, null)).RequireAuthenticatedUser().Build();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._nullPolicyTask = $.$spc.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, null);
                }
            }
            static $h = 641110;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy)).$h,"g":{"r":0,"d":0,"h":17180510294,"f":2},"n":"PolicyMap","d":641110,"h":12885542998,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":30065412182,"f":1},"s":{"r":0,"d":0,"h":34360379478,"f":1},"n":"InvokeHandlersAfterFailure","d":641110,"h":25770444886,"f":1},{"p":706646,"g":{"r":0,"d":0,"h":47245281366,"f":1},"s":{"r":0,"d":0,"h":51540248662,"f":1},"n":"DefaultPolicy","d":641110,"h":42950314070,"f":1},{"p":706646,"g":{"r":0,"d":0,"h":64425150550,"f":1},"s":{"r":0,"d":0,"h":68720117846,"f":1},"n":"FallbackPolicy","d":641110,"h":60130183254,"f":1}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"policy","p":706646}],"n":"AddPolicy","d":641110,"h":73015085142,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddPolicy","o":"@$1","d":641110,"h":77310052438,"f":1},{"r":706646,"p":[{"n":"name","p":1310721}],"n":"GetPolicy","d":641110,"h":81605019734,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"name","p":1310721}],"n":"GetPolicyTask","d":641110,"h":85899987030,"f":8}],"l":[{"t":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"_nullPolicyTask","d":641110,"h":4295608406,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":641110,"h":90194954326,"f":1}],"h":641110}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationOptions`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics", ($self) => class AuthorizationMetrics extends $.$spc.System.Object
        {
            /*string*/ static MeterName = null;
            /*Meter*/ _meter = null;
            /*Counter<long>*/ _authorizedCount = null;
            $ctor$1(/*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    this._meter = $.$sdd.System.Diagnostics.Metrics.MeterFactoryExtensions.Create(meterFactory, "Microsoft.AspNetCore.Authorization"/*MeterName*/, null, null);
                    this._authorizedCount = this._meter.CreateCounter($.$spc.System.Int64, "aspnetcore.authorization.attempts", "{attempt}", "The total number of authorization attempts.");
                }
                return this;
            }
            /*void */ AuthorizeAttemptCompleted(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                //if (_authorizedCount.Enabled) { ... }
            }
            /*void */ AuthorizeAttemptCore(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                /*var*/ let tags = new $.$sdd.System.Diagnostics.TagList().$ctor$2($.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("aspnetcore.user.is_authenticated", $.$box((user.Identity?.System$Security$Principal$IIdentity$IsAuthenticated ?? null) ?? false, $.$spc.System.Boolean))], null, null)));
                if (!(policyName === null))
                {
                    tags.Add("aspnetcore.authorization.policy", policyName);
                }
                if (!(result === null))
                {
                    /*var*/ let resultTagValue = result.Succeeded ? "success" : "failure";
                    tags.Add("aspnetcore.authorization.result", resultTagValue);
                }
                if (!(exception === null))
                {
                    tags.Add("error.type", exception.GetType$1().FullName);
                }
                this._authorizedCount.Add$6(1n, $.$ref(() => tags, ));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MeterName = "Microsoft.AspNetCore.Authorization";
                }
            }
            static $h = 575574;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"user","p":425999},{"n":"policyName","p":1310721},{"n":"result","p":837718},{"n":"exception","p":47251457}],"n":"AuthorizeAttemptCompleted","d":575574,"h":21475412054,"f":1},{"r":65537,"p":[{"n":"user","p":425999},{"n":"policyName","p":1310721},{"n":"result","p":837718},{"n":"exception","p":47251457}],"n":"AuthorizeAttemptCore","d":575574,"h":25770379350,"f":2}],"l":[{"t":1310721,"n":"MeterName","d":575574,"h":4295542870,"f":33},{"t":6553644,"n":"_meter","d":575574,"h":8590510166,"f":2},{"t":$.$sdd.System.Diagnostics.Metrics.Counter$$($.$spc.System.Int64).$h,"n":"_authorizedCount","d":575574,"h":12885477462,"f":2}],"c":[{"p":[{"n":"meterFactory","p":5439532}],"n":".ctor","o":"$ctor$1","d":575574,"h":17180444758,"f":1}],"h":575574}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationMetrics`; }
        });
        
        $asm.$cls("$maa.Microsoft.Extensions.DependencyInjection.AuthorizationServiceCollectionExtensions", ($self) => class AuthorizationServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddAuthorizationCore(/*this IServiceCollection*/ services)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.AddMetrics(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics, $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationServiceImpl));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationPolicyProvider));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerProvider));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationEvaluator));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerContextFactory));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.PassThroughAuthorizationHandler));
                return services;
            }
            static /*IServiceCollection */ AddAuthorizationCore$1(/*this IServiceCollection*/ services, /*Action<AuthorizationOptions>*/ configure)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configure, "configure");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, services, configure);
                return $.$maa.Microsoft.Extensions.DependencyInjection.AuthorizationServiceCollectionExtensions.AddAuthorizationCore(services);
            }
            static $h = 2541654;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"AddAuthorizationCore","d":2541654,"h":4297508950,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configure","p":$.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":"AddAuthorizationCore","o":"@$1","d":2541654,"h":8592476246,"f":33}],"h":2541654}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                if (argument === null)
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.Throw(paramName);
                }
            }
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                if (argument === null)
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.Throw(paramName);
                }
                else if (argument.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13("Must not be null or empty", paramName);
                }
            }
            static /*void */ Throw(/*string?*/ paramName)
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16(paramName);
            }
            static $h = 2410582;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":131073},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2738262,"c":4297705558,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNull","d":2410582,"h":4297377878,"f":33},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2738262,"c":4297705558,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":2410582,"h":8592345174,"f":33},{"r":65537,"p":[{"n":"paramName","p":1310721}],"n":"Throw","d":2410582,"h":12887312470,"f":40}],"h":2410582}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure", ($self) => class AuthorizationFailure extends $.$spc.System.Object
        {
            /*AuthorizationFailure*/ static _explicitFailure = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool*/ FailCalled = false;
            /*IEnumerable<IAuthorizationRequirement>*/ FailedRequirements = null;
            /*IEnumerable<AuthorizationFailureReason>*/ FailureReasons = null;
            static /*AuthorizationFailure */ ExplicitFail()
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure._explicitFailure;
            }
            static /*AuthorizationFailure */ Failed(/*IEnumerable<AuthorizationFailureReason>*/ reasons)
            {
                return (() =>
                {
                    //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                    const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.FailCalled = true;
                    $i1.FailureReasons = reasons;
                    return $i1;
                })();
            }
            static /*AuthorizationFailure */ Failed$1(/*IEnumerable<IAuthorizationRequirement>*/ failed)
            {
                return (() =>
                {
                    //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                    const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.FailedRequirements = failed;
                    return $i1;
                })();
            }
            //default member initializer
            constructor()
            {
                super();
                this.FailCalled = false;
                this.FailedRequirements = $.$spc.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement);
                this.FailureReasons = $.$spc.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._explicitFailure = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.FailCalled = true;
                        return $i1;
                    })();
                }
            }
            static $h = 247894;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475084374,"f":1},"s":{"r":0,"d":0,"h":25770051670,"f":2},"n":"FailCalled","d":247894,"h":17180117078,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":38654953558,"f":1},"s":{"r":0,"d":0,"h":42949920854,"f":2},"n":"FailedRequirements","d":247894,"h":34359986262,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,"g":{"r":0,"d":0,"h":55834822742,"f":1},"s":{"r":0,"d":0,"h":60129790038,"f":2},"n":"FailureReasons","d":247894,"h":51539855446,"f":1}],"m":[{"r":247894,"n":"ExplicitFail","d":247894,"h":64424757334,"f":33},{"r":247894,"p":[{"n":"reasons","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h}],"n":"Failed","d":247894,"h":68719724630,"f":33},{"r":247894,"p":[{"n":"failed","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"Failed","o":"@$1","d":247894,"h":73014691926,"f":33}],"l":[{"t":247894,"n":"_explicitFailure","d":247894,"h":4295215190,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":247894,"h":8590182486,"f":2}],"h":247894}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationFailure`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason", ($self) => class AuthorizationFailureReason extends $.$spc.System.Object
        {
            $ctor$1(/*IAuthorizationHandler*/ handler, /*string*/ message)
            {
                super.$ctor();
                {
                    this.Handler = handler;
                    this.Message = message;
                }
                return this;
            }
            /*string*/ Message = null;
            /*IAuthorizationHandler*/ Handler = null;
            static $h = 313430;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180182614,"f":1},"n":"Message","d":313430,"h":12885215318,"f":1},{"p":1493078,"g":{"r":0,"d":0,"h":30065084502,"f":1},"n":"Handler","d":313430,"h":25770117206,"f":1}],"c":[{"p":[{"n":"handler","p":1493078},{"n":"message","p":1310721}],"n":".ctor","o":"$ctor$1","d":313430,"h":4295280726,"f":1}],"h":313430}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationFailureReason`; }
        });
        
        $asm.$cls("$maa.Resources", ($self) => class Resources
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$maa.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.AspNetCore.Authorization", $.$maa.Resources.$type.Assembly);
                    $.$maa.Resources.s_resourceManager = temp;
                }
                return $.$maa.Resources.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$maa.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$maa.Resources.resourceCulture = value;
            }
            static /*string */ get Exception_AuthorizationPolicyEmpty()
            {
                return "AuthorizationPolicy must have at least one requirement.";
            }
            static /*string */ get Exception_AuthorizationPolicyNotFound()
            {
                return "The AuthorizationPolicy named: '{0}' was not found.";
            }
            static /*string */ FormatException_AuthorizationPolicyNotFound(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The AuthorizationPolicy named: '{0}' was not found.", arg1);
            }
            static /*string */ get Exception_RoleRequirementEmpty()
            {
                return "At least one role must be specified.";
            }
            static $h = 2672726;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":85524481,"g":{"r":0,"d":0,"h":17182541910,"f":40},"n":"ResourceManager","d":2672726,"h":12887574614,"f":40,"a":[{"t":33226753,"c":4328194049,"a":[{"v":2,"t":33292289}]}]},{"p":51183617,"g":{"r":0,"d":0,"h":25772476502,"f":40},"s":{"r":0,"d":0,"h":30067443798,"f":40},"n":"Culture","d":2672726,"h":21477509206,"f":40,"a":[{"t":33226753,"c":4328194049,"a":[{"v":2,"t":33292289}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38657378390,"f":40},"n":"Exception_AuthorizationPolicyEmpty","d":2672726,"h":34362411094,"f":40},{"p":1310721,"g":{"r":0,"d":0,"h":47247312982,"f":40},"n":"Exception_AuthorizationPolicyNotFound","d":2672726,"h":42952345686,"f":40},{"p":1310721,"g":{"r":0,"d":0,"h":60132214870,"f":40},"n":"Exception_RoleRequirementEmpty","d":2672726,"h":55837247574,"f":40}],"m":[{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatException_AuthorizationPolicyNotFound","d":2672726,"h":51542280278,"f":40}],"l":[{"t":85524481,"n":"s_resourceManager","d":2672726,"h":4297640022,"f":34},{"t":51183617,"n":"resourceCulture","d":2672726,"h":8592607318,"f":34}],"h":2672726,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"System.Resources.Tools.StronglyTypedResourceBuilder","t":1310721},{"v":"17.0.0.0","t":1310721}]},{"t":37748737,"c":4332716033},{"t":88539137,"c":4383506433}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult", ($self) => class AuthorizationResult extends $.$spc.System.Object
        {
            /*AuthorizationResult*/ static _succeededResult = null;
            /*AuthorizationResult*/ static _failedResult = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool*/ Succeeded = false;
            /*AuthorizationFailure?*/ Failure = null;
            static /*AuthorizationResult */ Success()
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult._succeededResult;
            }
            static /*AuthorizationResult */ Failed(/*AuthorizationFailure*/ failure)
            {
                return (() =>
                {
                    //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                    const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Failure = failure;
                    return $i1;
                })();
            }
            static /*AuthorizationResult */ Failed$1()
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult._failedResult;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Succeeded = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._succeededResult = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Succeeded = true;
                        return $i1;
                    })();
                }
                {
                    this._failedResult = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Failure = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.ExplicitFail();
                        return $i1;
                    })();
                }
            }
            static $h = 837718;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770641494,"f":1},"s":{"r":0,"d":0,"h":30065608790,"f":2},"n":"Succeeded","d":837718,"h":21475674198,"f":1},{"p":247894,"g":{"r":0,"d":0,"h":42950510678,"f":1},"s":{"r":0,"d":0,"h":47245477974,"f":2},"n":"Failure","d":837718,"h":38655543382,"f":1}],"m":[{"r":837718,"n":"Success","d":837718,"h":51540445270,"f":33},{"r":837718,"p":[{"n":"failure","p":247894}],"n":"Failed","d":837718,"h":55835412566,"f":33},{"r":837718,"n":"Failed","o":"@$1","d":837718,"h":60130379862,"f":33}],"l":[{"t":837718,"n":"_succeededResult","d":837718,"h":4295805014,"f":34},{"t":837718,"n":"_failedResult","d":837718,"h":8590772310,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":837718,"h":12885739606,"f":2}],"h":837718}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationResult`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions", ($self) => class AuthorizationServiceExtensions
        {
            static /*Task<AuthorizationResult> */ AuthorizeAsync(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*IAuthorizationRequirement*/ requirement)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirement, "requirement");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync(user, resource, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement), [requirement], [-1], null));
            }
            static /*Task<AuthorizationResult> */ AuthorizeAsync$1(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync(user, resource, policy.Requirements);
            }
            static /*Task<AuthorizationResult> */ AuthorizeAsync$2(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync$1(service, user, null, policy);
            }
            static /*Task<AuthorizationResult> */ AuthorizeAsync$3(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*string*/ policyName)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1(user, null, policyName);
            }
            static $h = 903254;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1886294},{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"requirement","p":1755222}],"n":"AuthorizeAsync","d":903254,"h":4295870550,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1886294},{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"policy","p":706646}],"n":"AuthorizeAsync","o":"@$1","d":903254,"h":8590837846,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1886294},{"n":"user","p":425999},{"n":"policy","p":706646}],"n":"AuthorizeAsync","o":"@$2","d":903254,"h":12885805142,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1886294},{"n":"user","p":425999},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"@$3","d":903254,"h":17180772438,"f":33}],"h":903254}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationServiceExtensions`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers", ($self) => class DebuggerHelpers
        {
            static /*string */ GetDebugText(/*string*/ key1, /*object?*/ value1, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText$3($.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1)], [-1], null)), includeNullValues, prefix);
            }
            static /*string */ GetDebugText$1(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText$3($.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key2, value2)], [-1], null)), includeNullValues, prefix);
            }
            static /*string */ GetDebugText$2(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*string*/ key3, /*object?*/ value3, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText$3($.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key2, value2), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key3, value3)], [-1], null)), includeNullValues, prefix);
            }
            static /*string */ GetDebugText$3(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ values, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                if (values.Length === 0)
                {
                    return prefix ?? $.$spc.System.String.Empty;
                }
                /*var*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                if ($.$spc.System.String.op_Inequality(prefix, null))
                {
                    sb.Append$2(prefix);
                }
                /*var*/ let first = true;
                for(/*var*/ let i = 0; i < values.Length; i++)
                {
                    /*var*/ let kvp = values.get_Item(i).$v;
                    if ($.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.HasValue(kvp.Value) || includeNullValues)
                    {
                        if (first)
                        {
                            if ($.$spc.System.String.op_Inequality(prefix, null))
                            {
                                sb.Append$7(/* */ 32);
                            }
                            first = false;
                        }
                        else 
                        {
                            sb.Append$2(", ");
                        }
                        sb.Append$2(kvp.Key);
                        sb.Append$2(": ");
                        let s;
                        let enumerable;
                        if (kvp.Value === null)
                        {
                            sb.Append$2("(null)");
                        }
                        else if ($.$is(kvp.Value, $.$spc.System.String, { set $v(v){ s = v; } }))
                        {
                            sb.Append$2(s);
                        }
                        else if ($.$is(kvp.Value, $.$spc.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                        {
                            /*var*/ let firstItem = true;
                            var $en5 = enumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    if (firstItem)
                                    {
                                        firstItem = false;
                                    }
                                    else 
                                    {
                                        sb.Append$7(/*,*/ 44);
                                    }
                                    sb.Append$19(item);
                                }
                            }
                        }
                        else 
                        {
                            sb.Append$19(kvp.Value);
                        }
                    }
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*bool */ HasValue(/*object?*/ value)
            {
                if (value === null)
                {
                    return false;
                }
                let enumerable;
                if (!(value !== null && ($.$is(value, $.$spc.System.String))) && $.$is(value, $.$spc.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }) && !enumerable.System$Collections$IEnumerable$GetEnumerator().System$Collections$IEnumerator$MoveNext())
                {
                    return false;
                }
                return true;
            }
            static /*KeyValuePair<string, object?> */ Create(/*string*/ key, /*object?*/ value)
            {
                return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(key, value);
            }
            static $h = 2476118;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"key1","p":1310721},{"n":"value1","p":131073},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","d":2476118,"h":4297443414,"f":33},{"r":1310721,"p":[{"n":"key1","p":1310721},{"n":"value1","p":131073},{"n":"key2","p":1310721},{"n":"value2","p":131073},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","o":"@$1","d":2476118,"h":8592410710,"f":33},{"r":1310721,"p":[{"n":"key1","p":1310721},{"n":"value1","p":131073},{"n":"key2","p":1310721},{"n":"value2","p":131073},{"n":"key3","p":1310721},{"n":"value3","p":131073},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","o":"@$2","d":2476118,"h":12887378006,"f":33},{"r":1310721,"p":[{"n":"values","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","o":"@$3","d":2476118,"h":17182345302,"f":33},{"r":262145,"p":[{"n":"value","p":131073}],"n":"HasValue","d":2476118,"h":21477312598,"f":34},{"r":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"p":[{"n":"key","p":1310721},{"n":"value","p":131073}],"n":"Create","d":2476118,"h":25772279894,"f":34}],"h":2476118}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `DebuggerHelpers`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder", ($self) => class AuthorizationPolicyBuilder extends $.$spc.System.Object
        {
            /*DenyAnonymousAuthorizationRequirement*/ static _denyAnonymousAuthorizationRequirement = null;
            $ctor$1(/*params string[]*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    this.AddAuthenticationSchemes(authenticationSchemes);
                }
                return this;
            }
            $ctor$2(/*AuthorizationPolicy*/ policy)
            {
                super.$ctor();
                {
                    this.Combine(policy);
                }
                return this;
            }
            /*IList<IAuthorizationRequirement>*/ Requirements = null;
            /*IList<string>*/ AuthenticationSchemes = null;
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemes(/*params string[]*/ schemes)
            {
                return this.AddAuthenticationSchemesCore(schemes);
            }
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemesCore(/*IEnumerable<string>*/ schemes)
            {
                var $en2 = schemes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var authType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.AuthenticationSchemes.System$Collections$Generic$ICollection$$$Add(authType, [$.$spc.System.String]);
                    }
                }
                return this;
            }
            /*AuthorizationPolicyBuilder */ AddRequirements(/*params IAuthorizationRequirement[]*/ requirements)
            {
                return this.AddRequirementsCore(requirements);
            }
            /*AuthorizationPolicyBuilder */ AddRequirementsCore(/*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                var $en2 = requirements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var req = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.Requirements.System$Collections$Generic$ICollection$$$Add(req, [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                    }
                }
                return this;
            }
            /*AuthorizationPolicyBuilder */ Combine(/*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.AddAuthenticationSchemesCore(policy.AuthenticationSchemes);
                this.AddRequirementsCore(policy.Requirements);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireClaim(/*string*/ claimType, /*params string[]*/ allowedValues)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                return this.RequireClaim$1(claimType, allowedValues);
            }
            /*AuthorizationPolicyBuilder */ RequireClaim$1(/*string*/ claimType, /*IEnumerable<string>*/ allowedValues)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement().$ctor$2(claimType, allowedValues), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireClaim$2(/*string*/ claimType)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement().$ctor$2(claimType, null), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireRole(/*params string[]*/ roles)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                return this.RequireRole$1(roles);
            }
            /*AuthorizationPolicyBuilder */ RequireRole$1(/*IEnumerable<string>*/ roles)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement().$ctor$2(roles), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireUserName(/*string*/ userName)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(userName, "userName");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement().$ctor$2(userName), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireAuthenticatedUser()
            {
                this.Requirements.System$Collections$Generic$ICollection$$$Add($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder._denyAnonymousAuthorizationRequirement, [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireAssertion(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement().$ctor$1(handler), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireAssertion$1(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement().$ctor$2(handler), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicy */ Build()
            {
                return new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy().$ctor$1(this.Requirements, $.$sl.System.Linq.Enumerable.Distinct($.$spc.System.String, this.AuthenticationSchemes));
            }
            //default member initializer
            constructor()
            {
                super();
                this.Requirements = new ($.$spc.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$1();
                this.AuthenticationSchemes = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._denyAnonymousAuthorizationRequirement = new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement().$ctor$2();
                }
            }
            static $h = 772182;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":25770575958,"f":1},"s":{"r":0,"d":0,"h":30065543254,"f":1},"n":"Requirements","d":772182,"h":21475608662,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":42950445142,"f":1},"s":{"r":0,"d":0,"h":47245412438,"f":1},"n":"AuthenticationSchemes","d":772182,"h":38655477846,"f":1}],"m":[{"r":772182,"p":[{"n":"schemes","p":0,"f":16}],"n":"AddAuthenticationSchemes","d":772182,"h":51540379734,"f":1},{"r":772182,"p":[{"n":"schemes","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"AddAuthenticationSchemesCore","d":772182,"h":55835347030,"f":2},{"r":772182,"p":[{"n":"requirements","p":0,"f":16}],"n":"AddRequirements","d":772182,"h":60130314326,"f":1},{"r":772182,"p":[{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AddRequirementsCore","d":772182,"h":64425281622,"f":2},{"r":772182,"p":[{"n":"policy","p":706646}],"n":"Combine","d":772182,"h":68720248918,"f":1},{"r":772182,"p":[{"n":"claimType","p":1310721},{"n":"allowedValues","p":0,"f":16}],"n":"RequireClaim","d":772182,"h":73015216214,"f":1},{"r":772182,"p":[{"n":"claimType","p":1310721},{"n":"allowedValues","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"RequireClaim","o":"@$1","d":772182,"h":77310183510,"f":1},{"r":772182,"p":[{"n":"claimType","p":1310721}],"n":"RequireClaim","o":"@$2","d":772182,"h":81605150806,"f":1},{"r":772182,"p":[{"n":"roles","p":0,"f":16}],"n":"RequireRole","d":772182,"h":85900118102,"f":1},{"r":772182,"p":[{"n":"roles","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"RequireRole","o":"@$1","d":772182,"h":90195085398,"f":1},{"r":772182,"p":[{"n":"userName","p":1310721}],"n":"RequireUserName","d":772182,"h":94490052694,"f":1},{"r":772182,"n":"RequireAuthenticatedUser","d":772182,"h":98785019990,"f":1},{"r":772182,"p":[{"n":"handler","p":$.$spc.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$spc.System.Boolean).$h}],"n":"RequireAssertion","d":772182,"h":103079987286,"f":1},{"r":772182,"p":[{"n":"handler","p":$.$spc.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean)).$h}],"n":"RequireAssertion","o":"@$1","d":772182,"h":107374954582,"f":1},{"r":706646,"n":"Build","d":772182,"h":111669921878,"f":1}],"l":[{"t":2082902,"n":"_denyAnonymousAuthorizationRequirement","d":772182,"h":4295739478,"f":34}],"c":[{"p":[{"n":"authenticationSchemes","p":0,"f":16}],"n":".ctor","o":"$ctor$1","d":772182,"h":8590706774,"f":1},{"p":[{"n":"policy","p":706646}],"n":".ctor","o":"$ctor$2","d":772182,"h":12885674070,"f":1}],"h":772182}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationPolicyBuilder`; }
        });
        
        $asm.$cls("$maa.Microsoft.Extensions.Logging.LoggingExtensions", ($self) => class LoggingExtensions
        {
            static /*void */ UserAuthorizationFailed$1(/*this ILogger*/ logger, /*AuthorizationFailure*/ failure)
            {
                /*var*/ let reason = failure.FailCalled ? "Fail() was explicitly called." : "These requirements were not met:" + $.$spc.System.Environment.NewLine + $.$spc.System.String.Join$12($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, $.$spc.System.Environment.NewLine, failure.FailedRequirements);
                $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationFailed(logger, reason);
            }
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.Exception?>*/ static __UserAuthorizationSucceededCallback = null;
            static /*void */ UserAuthorizationSucceeded(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger)
            {
                if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                {
                    $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.__UserAuthorizationSucceededCallback.Invoke(logger, null);
                }
            }
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __UserAuthorizationFailedCallback = null;
            static /*void */ UserAuthorizationFailed(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ reason)
            {
                if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/))
                {
                    $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.__UserAuthorizationFailedCallback.Invoke(logger, reason, null);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.__UserAuthorizationSucceededCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$1(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$2(1, "UserAuthorizationSucceeded"), "Authorization was successful.", (() =>
                    {
                        //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                        const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SkipEnabledCheck = true;
                        return $i1;
                    })());
                }
                {
                    this.__UserAuthorizationFailedCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$3($.$spc.System.String, 2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$2(2, "UserAuthorizationFailed"), "Authorization failed. {Reason}", (() =>
                    {
                        //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                        const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SkipEnabledCheck = true;
                        return $i1;
                    })());
                }
            }
            static $h = 2607190;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"logger","p":917525}],"n":"UserAuthorizationSucceeded","d":2607190,"h":4297574486,"f":33,"a":[{"t":2228245,"c":8592162837,"a":[{"v":1,"t":655361},{"v":1,"t":2293781},{"v":"Authorization was successful.","t":1310721}],"n":[{"n":"EventName","v":"UserAuthorizationSucceeded","t":1310721}]},{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"reason","p":1310721}],"n":"UserAuthorizationFailed","d":2607190,"h":8592541782,"f":34,"a":[{"t":2228245,"c":8592162837,"a":[{"v":2,"t":655361},{"v":2,"t":2293781},{"v":"Authorization failed. {Reason}","t":1310721}],"n":[{"n":"EventName","v":"UserAuthorizationFailed","t":1310721}]},{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"failure","p":247894}],"n":"UserAuthorizationFailed","o":"@$1","d":2607190,"h":12887509078,"f":33}],"l":[{"t":$.$spc.System.Action$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.Exception).$h,"n":"__UserAuthorizationSucceededCallback","d":2607190,"h":17182476374,"f":34,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"t":$.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.String, $.$spc.System.Exception).$h,"n":"__UserAuthorizationFailedCallback","d":2607190,"h":21477443670,"f":34,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"h":2607190}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `LoggingExtensions`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy", ($self) => class AuthorizationPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*IEnumerable<string>*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(authenticationSchemes, "authenticationSchemes");
                    if (!$.$sl.System.Linq.Enumerable.Any($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, requirements))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$maa.Resources.Exception_AuthorizationPolicyEmpty);
                    }
                    this.Requirements = new ($.$spc.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$3(requirements).AsReadOnly();
                    this.AuthenticationSchemes = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$3(authenticationSchemes).AsReadOnly();
                }
                return this;
            }
            /*IReadOnlyList<IAuthorizationRequirement>*/ Requirements = null;
            /*IReadOnlyList<string>*/ AuthenticationSchemes = null;
            static /*AuthorizationPolicy */ Combine(/*params AuthorizationPolicy[]*/ policies)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.Combine$1(policies);
            }
            static /*AuthorizationPolicy */ Combine$1(/*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                /*var*/ let builder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [  ], null, null));
                var $en2 = policies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var policy = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        builder.Combine(policy);
                    }
                }
                return builder.Build();
            }
            static /*Task<AuthorizationPolicy?> */ CombineAsync(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData)
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.CombineAsync$1(policyProvider, authorizeData, $.$sl.System.Linq.Enumerable.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy));
            }
            static /*Task<AuthorizationPolicy?> *//*async*/  CombineAsync$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData, /*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, async () => 
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(authorizeData, "authorizeData");
                    /*var*/ let anyPolicies = $.$sl.System.Linq.Enumerable.Any($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policies);
                    /*var*/ let skipEnumeratingData = false;
                    let dataList;
                    if ($.$is(authorizeData, $.$spc.System.Collections.Generic.IList$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData), { set $v(v){ dataList = v; } }))
                    {
                        skipEnumeratingData = dataList.System$Collections$Generic$ICollection$$$Count === 0;
                    }
                    /*AuthorizationPolicyBuilder?*/ let policyBuilder = null;
                    if (!skipEnumeratingData)
                    {
                        var $en4 = authorizeData.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var authorizeDatum = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (policyBuilder === null)
                                {
                                    policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [  ], null, null));
                                }
                                /*var*/ let useDefaultPolicy = !(anyPolicies);
                                if (!$.$spc.System.String.IsNullOrWhiteSpace(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy))
                                {
                                    /*var*/ let policy = await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy).ConfigureAwait$2(false);
                                    if (policy === null)
                                    {
                                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$maa.Resources.FormatException_AuthorizationPolicyNotFound(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy));
                                    }
                                    policyBuilder.Combine(policy);
                                    useDefaultPolicy = false;
                                }
                                const $t1 = () => authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles;
                                /*var*/ let rolesSplit = $.$ifnn($t1, ($t) => $.$spc.System.String.Split.call($t, /*,*/ 44, 0));
                                const $t2 = rolesSplit;
                                if ($.$spc.System.Int32.op_GreaterThan$1($.$ifnn($t2, ($t) => $t.length), 0))
                                {
                                    /*var*/ let trimmedRolesSplit = $.$sl.System.Linq.Enumerable.Select($.$spc.System.String, $.$spc.System.String, $.$sl.System.Linq.Enumerable.Where($.$spc.System.String, rolesSplit, new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.Boolean))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return !$.$spc.System.String.IsNullOrWhiteSpace(r);
                                    }, {"r":262145,"p":[{"n":"r","p":1310721}],"n":"","d":706646,"h":0,"f":1048578})), new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.String))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return $.$spc.System.String.Trim.call(r);
                                    }, {"r":1310721,"p":[{"n":"r","p":1310721}],"n":"","d":706646,"h":0,"f":1048578}));
                                    policyBuilder.RequireRole$1(trimmedRolesSplit);
                                    useDefaultPolicy = false;
                                }
                                const $t3 = () => authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes;
                                /*var*/ let authTypesSplit = $.$ifnn($t3, ($t) => $.$spc.System.String.Split.call($t, /*,*/ 44, 0));
                                const $t4 = authTypesSplit;
                                if ($.$spc.System.Int32.op_GreaterThan$1($.$ifnn($t4, ($t) => $t.length), 0))
                                {
                                    let $i5 = 0;
                                    let $arr5 = authTypesSplit;
                                    while ($i5 < $arr5.length)
                                    {
                                        let authType = $arr5[$i5++];
                                        if (!$.$spc.System.String.IsNullOrWhiteSpace(authType))
                                        {
                                            policyBuilder.AuthenticationSchemes.System$Collections$Generic$ICollection$$$Add($.$spc.System.String.Trim.call(authType), [$.$spc.System.String]);
                                        }
                                    }
                                }
                                if (useDefaultPolicy)
                                {
                                    policyBuilder.Combine(await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync().ConfigureAwait$2(false));
                                }
                            }
                        }
                    }
                    if (anyPolicies)
                    {
                        policyBuilder ??= new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [  ], null, null));
                        var $en4 = policies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var policy = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                policyBuilder.Combine(policy);
                            }
                        }
                    }
                    if (policyBuilder === null)
                    {
                        /*var*/ let fallbackPolicy = await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync().ConfigureAwait$2(false);
                        if (fallbackPolicy !== null)
                        {
                            return fallbackPolicy;
                        }
                    }
                    return policyBuilder?.Build();
                });
            }
            static $h = 706646;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":17180575830,"f":1},"n":"Requirements","d":706646,"h":12885608534,"f":1},{"p":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":30065477718,"f":1},"n":"AuthenticationSchemes","d":706646,"h":25770510422,"f":1}],"m":[{"r":706646,"p":[{"n":"policies","p":0,"f":16}],"n":"Combine","d":706646,"h":34360445014,"f":33},{"r":706646,"p":[{"n":"policies","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h}],"n":"Combine","o":"@$1","d":706646,"h":38655412310,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyProvider","p":1689686},{"n":"authorizeData","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h}],"n":"CombineAsync","d":706646,"h":42950379606,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyProvider","p":1689686},{"n":"authorizeData","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h},{"n":"policies","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h}],"n":"CombineAsync","o":"@$1","d":706646,"h":47245346902,"f":4129}],"c":[{"p":[{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"authenticationSchemes","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$1","d":706646,"h":4295673942,"f":1}],"h":706646}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationPolicy`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationBuilder", ($self) => class AuthorizationBuilder extends $.$spc.System.Object
        {
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                this.Services = services;
                return this;
            }
            /*IServiceCollection*/ Services = null;
            /*AuthorizationBuilder */ SetInvokeHandlersAfterFailure(/*bool*/ invoke)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/**/ o) =>
                {
                    return o.InvokeHandlersAfterFailure = invoke;
                }, {"r":65537,"p":[{"n":"o","p":641110}],"n":"","d":182358,"h":0,"f":1048578}));
                return this;
            }
            /*AuthorizationBuilder */ SetDefaultPolicy(/*AuthorizationPolicy*/ policy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.DefaultPolicy = policy;
                }, {"r":65537,"p":[{"n":"o","p":641110}],"n":"","d":182358,"h":0,"f":1048578}));
                return this;
            }
            /*AuthorizationBuilder */ SetFallbackPolicy(/*AuthorizationPolicy?*/ policy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.FallbackPolicy = policy;
                }, {"r":65537,"p":[{"n":"o","p":641110}],"n":"","d":182358,"h":0,"f":1048578}));
                return this;
            }
            /*AuthorizationBuilder */ AddPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy(name, policy);
                }, {"r":65537,"p":[{"n":"o","p":641110}],"n":"","d":182358,"h":0,"f":1048578}));
                return this;
            }
            /*AuthorizationBuilder */ AddPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy$1(name, configurePolicy);
                }, {"r":65537,"p":[{"n":"o","p":641110}],"n":"","d":182358,"h":0,"f":1048578}));
                return this;
            }
            /*AuthorizationBuilder */ AddDefaultPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                this.SetDefaultPolicy(policy);
                return this.AddPolicy(name, policy);
            }
            /*AuthorizationBuilder */ AddDefaultPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddDefaultPolicy(name, policyBuilder.Build());
            }
            /*AuthorizationBuilder */ AddFallbackPolicy(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                this.SetFallbackPolicy(policy);
                return this.AddPolicy(name, policy);
            }
            /*AuthorizationBuilder */ AddFallbackPolicy$1(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddFallbackPolicy(name, policyBuilder.Build());
            }
            static $h = 182358;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":786435,"g":{"r":0,"d":0,"h":17180051542,"f":129},"n":"Services","d":182358,"h":12885084246,"f":129}],"m":[{"r":182358,"p":[{"n":"invoke","p":262145}],"n":"SetInvokeHandlersAfterFailure","d":182358,"h":21475018838,"f":129},{"r":182358,"p":[{"n":"policy","p":706646}],"n":"SetDefaultPolicy","d":182358,"h":25769986134,"f":129},{"r":182358,"p":[{"n":"policy","p":706646}],"n":"SetFallbackPolicy","d":182358,"h":30064953430,"f":129},{"r":182358,"p":[{"n":"name","p":1310721},{"n":"policy","p":706646}],"n":"AddPolicy","d":182358,"h":34359920726,"f":129},{"r":182358,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddPolicy","o":"@$1","d":182358,"h":38654888022,"f":129},{"r":182358,"p":[{"n":"name","p":1310721},{"n":"policy","p":706646}],"n":"AddDefaultPolicy","d":182358,"h":42949855318,"f":129},{"r":182358,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddDefaultPolicy","o":"@$1","d":182358,"h":47244822614,"f":129},{"r":182358,"p":[{"n":"name","p":1310721},{"n":"policy","p":706646}],"n":"AddFallbackPolicy","d":182358,"h":51539789910,"f":129},{"r":182358,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$spc.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddFallbackPolicy","o":"@$1","d":182358,"h":55834757206,"f":129}],"c":[{"p":[{"n":"services","p":786435}],"n":".ctor","o":"$ctor$1","d":182358,"h":4295149654,"f":1}],"h":182358}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthorizationBuilder`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationEvaluator", ($self) => class DefaultAuthorizationEvaluator extends $.$spc.System.Object
        {
            /*AuthorizationResult */ Evaluate(/*AuthorizationHandlerContext*/ context)
            {
                return context.HasSucceeded ? $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult.Success() : $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult.Failed(context.HasFailed ? $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.Failed(context.FailureReasons) : $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.Failed$1(context.PendingRequirements));
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator.Evaluate(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate()
            {
                return this.Evaluate(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1034326;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":837718,"p":[{"n":"context","p":510038}],"n":"Evaluate","d":1034326,"h":4296001622,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1034326,"h":8590968918,"f":1}],"i":[1427542],"h":1034326}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator ]; }
            static get $fullName() { return `DefaultAuthorizationEvaluator`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerContextFactory", ($self) => class DefaultAuthorizationHandlerContextFactory extends $.$spc.System.Object
        {
            /*AuthorizationHandlerContext */ CreateContext(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                return new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext().$ctor$1(requirements, user, resource);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory.CreateContext(System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>, System.Security.Claims.ClaimsPrincipal, object?)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext()
            {
                return this.CreateContext(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1099862;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":510038,"p":[{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"user","p":425999},{"n":"resource","p":131073}],"n":"CreateContext","d":1099862,"h":4296067158,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1099862,"h":8591034454,"f":1}],"i":[1558614],"h":1099862}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory ]; }
            static get $fullName() { return `DefaultAuthorizationHandlerContextFactory`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerProvider", ($self) => class DefaultAuthorizationHandlerProvider extends $.$spc.System.Object
        {
            /*Task<IEnumerable<IAuthorizationHandler>>*/ _handlersTask = null;
            $ctor$1(/*IEnumerable<IAuthorizationHandler>*/ handlers)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    this._handlersTask = $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler), handlers);
                }
                return this;
            }
            /*Task<IEnumerable<IAuthorizationHandler>> */ GetHandlersAsync(/*AuthorizationHandlerContext*/ context)
            {
                return this._handlersTask;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider.GetHandlersAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync()
            {
                return this.GetHandlersAsync(...arguments);
            }
            static $h = 1165398;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,"p":[{"n":"context","p":510038}],"n":"GetHandlersAsync","d":1165398,"h":12886067286,"f":1}],"l":[{"t":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,"n":"_handlersTask","d":1165398,"h":4296132694,"f":2}],"c":[{"p":[{"n":"handlers","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler).$h}],"n":".ctor","o":"$ctor$1","d":1165398,"h":8591099990,"f":1}],"i":[1624150],"h":1165398}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider ]; }
            static get $fullName() { return `DefaultAuthorizationHandlerProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService", ($self) => class DefaultAuthorizationService extends $.$spc.System.Object
        {
            /*AuthorizationOptions*/ _options = null;
            /*IAuthorizationHandlerContextFactory*/ _contextFactory = null;
            /*IAuthorizationHandlerProvider*/ _handlers = null;
            /*IAuthorizationEvaluator*/ _evaluator = null;
            /*IAuthorizationPolicyProvider*/ _policyProvider = null;
            /*ILogger*/ _logger = null;
            $ctor$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IAuthorizationHandlerProvider*/ handlers, /*ILogger<DefaultAuthorizationService>*/ logger, /*IAuthorizationHandlerContextFactory*/ contextFactory, /*IAuthorizationEvaluator*/ evaluator, /*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(contextFactory, "contextFactory");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(evaluator, "evaluator");
                    this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                    this._handlers = handlers;
                    this._policyProvider = policyProvider;
                    this._logger = logger;
                    this._evaluator = evaluator;
                    this._contextFactory = contextFactory;
                }
                return this;
            }
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    /*var*/ let authContext = this._contextFactory.Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext(requirements, user, resource);
                    /*var*/ let handlers = await this._handlers.Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync(authContext).ConfigureAwait$2(false);
                    var $en3 = handlers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var handler = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await handler.Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync(authContext).ConfigureAwait(false);
                            if (!this._options.InvokeHandlersAfterFailure && authContext.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                    /*var*/ let result = this._evaluator.Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate(authContext);
                    if (result.Succeeded)
                    {
                        $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationSucceeded(this._logger);
                    }
                    else 
                    {
                        $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationFailed$1(this._logger, result.Failure);
                    }
                    return result;
                });
            }
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    /*var*/ let policy = await this.GetPolicyAsync(policyName).ConfigureAwait$2(false);
                    return await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync$1(this, user, resource, policy).ConfigureAwait$2(false);
                });
            }
            /*Task<AuthorizationPolicy> *//*async*/  GetPolicyAsync(/*string*/ policyName)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, async () => 
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                    return $.$firstOf(await this._policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync(policyName).ConfigureAwait$2(false), () => { throw new $.$spc.System.InvalidOperationException().$ctor$10(`No policy found: ${policyName}.`) });
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>)
            Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync()
            {
                return this.AuthorizeAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, string)
            Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1()
            {
                return this.AuthorizeAsync$1(...arguments);
            }
            static $h = 1296470;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AuthorizeAsync","d":1296470,"h":34361034838,"f":4225},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"@$1","d":1296470,"h":38656002134,"f":4225},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyName","p":1310721}],"n":"GetPolicyAsync","d":1296470,"h":42950969430,"f":4096}],"l":[{"t":641110,"n":"_options","d":1296470,"h":4296263766,"f":2},{"t":1558614,"n":"_contextFactory","d":1296470,"h":8591231062,"f":2},{"t":1624150,"n":"_handlers","d":1296470,"h":12886198358,"f":2},{"t":1427542,"n":"_evaluator","d":1296470,"h":17181165654,"f":2},{"t":1689686,"n":"_policyProvider","d":1296470,"h":21476132950,"f":2},{"t":917525,"n":"_logger","d":1296470,"h":25771100246,"f":2}],"c":[{"p":[{"n":"policyProvider","p":1689686},{"n":"handlers","p":1624150},{"n":"logger","p":$.$mela.Microsoft.Extensions.Logging.ILogger$$($.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService).$h},{"n":"contextFactory","p":1558614},{"n":"evaluator","p":1427542},{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":".ctor","o":"$ctor$1","d":1296470,"h":30066067542,"f":1}],"i":[1886294],"h":1296470}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService ]; }
            static get $fullName() { return `DefaultAuthorizationService`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.OperationAuthorizationRequirement", ($self) => class OperationAuthorizationRequirement extends $.$spc.System.Object
        {
            /*string*/ Name = null;
            static/*conventional*/ /*string */ ToString()
            {
                return `${"OperationAuthorizationRequirement"}:Name=${this.Name}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.OperationAuthorizationRequirement.ToString.apply(this, arguments); }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Name = null;
            }
            static $h = 2213974;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12887115862,"f":1},"s":{"r":0,"d":0,"h":17182083158,"f":1},"n":"Name","d":2213974,"h":8592148566,"f":1}],"m":[{"r":1310721,"n":"ToString","d":2213974,"h":21477050454,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":2213974,"h":25772017750,"f":1}],"i":[1755222],"h":2213974}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `OperationAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.PassThroughAuthorizationHandler", ($self) => class PassThroughAuthorizationHandler extends $.$spc.System.Object
        {
            /*AuthorizationOptions*/ _options = null;
            $ctor$1()
            {
                this.$ctor$2($.$meo.Microsoft.Extensions.Options.Options.Create($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions().$ctor$1()));
                {
                }
                return this;
            }
            $ctor$2(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                return this;
            }
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    var $en3 = $.$sl.System.Linq.Enumerable.OfType($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var handler = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await handler.Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync(context).ConfigureAwait(false);
                            if (!this._options.InvokeHandlersAfterFailure && context.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            static $h = 2279510;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"context","p":510038}],"n":"HandleAsync","d":2279510,"h":17182148694,"f":4097}],"l":[{"t":641110,"n":"_options","d":2279510,"h":4297246806,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2279510,"h":8592214102,"f":1},{"p":[{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":".ctor","o":"$ctor$2","d":2279510,"h":12887181398,"f":1}],"i":[1493078],"h":2279510}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `PassThroughAuthorizationHandler`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationPolicyProvider", ($self) => class DefaultAuthorizationPolicyProvider extends $.$spc.System.Object
        {
            /*AuthorizationOptions*/ _options = null;
            /*Task<AuthorizationPolicy>?*/ _cachedDefaultPolicy = null;
            /*Task<AuthorizationPolicy?>?*/ _cachedFallbackPolicy = null;
            $ctor$1(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                }
                return this;
            }
            /*Task<AuthorizationPolicy> */ GetDefaultPolicyAsync()
            {
                if (this._cachedDefaultPolicy === null || this._cachedDefaultPolicy.Result !== this._options.DefaultPolicy)
                {
                    this._cachedDefaultPolicy = $.$spc.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, this._options.DefaultPolicy);
                }
                return this._cachedDefaultPolicy;
            }
            /*Task<AuthorizationPolicy?> */ GetFallbackPolicyAsync()
            {
                if (this._cachedFallbackPolicy === null || this._cachedFallbackPolicy.Result !== this._options.FallbackPolicy)
                {
                    this._cachedFallbackPolicy = $.$spc.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, this._options.FallbackPolicy);
                }
                return this._cachedFallbackPolicy;
            }
            /*Task<AuthorizationPolicy?> */ GetPolicyAsync(/*string*/ policyName)
            {
                return this._options.GetPolicyTask(policyName);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetPolicyAsync(string)
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync()
            {
                return this.GetPolicyAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetDefaultPolicyAsync()
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync()
            {
                return this.GetDefaultPolicyAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetFallbackPolicyAsync()
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync()
            {
                return this.GetFallbackPolicyAsync(...arguments);
            }
            static $h = 1230934;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetDefaultPolicyAsync","d":1230934,"h":21476067414,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetFallbackPolicyAsync","d":1230934,"h":25771034710,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyName","p":1310721}],"n":"GetPolicyAsync","d":1230934,"h":30066002006,"f":129}],"l":[{"t":641110,"n":"_options","d":1230934,"h":4296198230,"f":2},{"t":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"_cachedDefaultPolicy","d":1230934,"h":8591165526,"f":2},{"t":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"_cachedFallbackPolicy","d":1230934,"h":12886132822,"f":2}],"c":[{"p":[{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":".ctor","o":"$ctor$1","d":1230934,"h":17181100118,"f":1}],"i":[1689686],"h":1230934}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider ]; }
            static get $fullName() { return `DefaultAuthorizationPolicyProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement", ($self) => class AssertionRequirement extends $.$spc.System.Object
        {
            /*Func<AuthorizationHandlerContext, Task<bool>>*/ Handler = null;
            $ctor$1(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = new ($.$spc.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean)))().$ctor(this,  (/*context*/ context) =>
                    {
                        return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Boolean, handler.Invoke(context));
                    }, {"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"context","p":510038}],"n":"","d":1951830,"h":0,"f":1048578});
                }
                return this;
            }
            $ctor$2(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = handler;
                }
                return this;
            }
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (await this.Handler.Invoke(context).ConfigureAwait$2(false))
                    {
                        context.Succeed(this);
                    }
                });
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"Handler"} assertion should evaluate to true.`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement.ToString.apply(this, arguments); }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            static $h = 1951830;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean)).$h,"g":{"r":0,"d":0,"h":12886853718,"f":1},"n":"Handler","d":1951830,"h":8591886422,"f":1}],"m":[{"r":133300225,"p":[{"n":"context","p":510038}],"n":"HandleAsync","d":1951830,"h":25771755606,"f":4097},{"r":1310721,"n":"ToString","d":1951830,"h":30066722902,"f":32769}],"c":[{"p":[{"n":"handler","p":$.$spc.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$spc.System.Boolean).$h}],"n":".ctor","o":"$ctor$1","d":1951830,"h":17181821014,"f":1},{"p":[{"n":"handler","p":$.$spc.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean)).$h}],"n":".ctor","o":"$ctor$2","d":1951830,"h":21476788310,"f":1}],"i":[1493078,1755222],"h":1951830}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `AssertionRequirement`; }
        });
        
        $asm.$cls("$maa.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    this.ParameterName = parameterName;
                }
                return this;
            }
            /*string*/ ParameterName = null;
            static $h = 2738262;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182607446,"f":1},"n":"ParameterName","d":2738262,"h":12887640150,"f":1}],"c":[{"p":[{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$2","d":2738262,"h":4297705558,"f":1}],"h":2738262,"a":[{"t":14680065,"c":21489516545,"a":[{"v":2048,"t":14614529}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute", ($self) => class AllowAnonymousAttribute extends $.$spc.System.Attribute
        {
            static/*conventional*/ /*string */ ToString()
            {
                return "AllowAnonymous";
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute.ToString.apply(this, arguments); }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 116822;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"m":[{"r":1310721,"n":"ToString","d":116822,"h":4295084118,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":116822,"h":8590051414,"f":1}],"i":[122599],"h":116822,"a":[{"t":14680065,"c":21489516545,"a":[{"v":68,"t":14614529}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":37617665,"c":8627552257,"a":[{"v":"{ToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous ]; }
            static get $fullName() { return `AllowAnonymousAttribute`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizeAttribute", ($self) => class AuthorizeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ policy)
            {
                super.$ctor$1();
                {
                    this.Policy = policy;
                }
                return this;
            }
            /*string?*/ Policy = null;
            /*string?*/ Roles = null;
            /*string?*/ AuthenticationSchemes = null;
            static/*conventional*/ /*string */ ToString()
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText$2("Policy", this.Policy, "Roles", this.Roles, "AuthenticationSchemes", this.AuthenticationSchemes, false, "Authorize");
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizeAttribute.ToString.apply(this, arguments); }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy()
            {
                return this.Policy;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy(value)
            {
                this.Policy = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles()
            {
                return this.Roles;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles(value)
            {
                this.Roles = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes()
            {
                return this.AuthenticationSchemes;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes(value)
            {
                this.AuthenticationSchemes = value;
            }
            static $h = 968790;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475805270,"f":1},"s":{"r":0,"d":0,"h":25770772566,"f":1},"n":"Policy","d":968790,"h":17180837974,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655674454,"f":1},"s":{"r":0,"d":0,"h":42950641750,"f":1},"n":"Roles","d":968790,"h":34360707158,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835543638,"f":1},"s":{"r":0,"d":0,"h":60130510934,"f":1},"n":"AuthenticationSchemes","d":968790,"h":51540576342,"f":1}],"m":[{"r":1310721,"n":"ToString","d":968790,"h":64425478230,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":968790,"h":4295936086,"f":1},{"p":[{"n":"policy","p":1310721}],"n":".ctor","o":"$ctor$3","d":968790,"h":8590903382,"f":1}],"i":[188135],"h":968790,"a":[{"t":14680065,"c":21489516545,"a":[{"v":68,"t":14614529}],"n":[{"n":"AllowMultiple","v":true,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":37617665,"c":8627552257,"a":[{"v":"{ToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData ]; }
            static get $fullName() { return `AuthorizeAttribute`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement", ($self) => class NameAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            $ctor$2(/*string*/ requiredName)
            {
                super.$ctor$1();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requiredName, "requiredName");
                    this.RequiredName = requiredName;
                }
                return this;
            }
            /*string*/ RequiredName = null;
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*NameAuthorizationRequirement*/ requirement)
            {
                if (context.User !== null)
                {
                    /*var*/ let succeed = false;
                    var $en3 = context.User.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var identity = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.Equals$5(identity.Name, requirement.RequiredName, 4/*StringComparison.Ordinal*/))
                            {
                                succeed = true;
                                break;
                            }
                        }
                    }
                    if (succeed)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"NameAuthorizationRequirement"}:Requires a user identity with Name equal to ${this.RequiredName}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement.ToString.apply(this, arguments); }
            static $h = 2148438;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182017622,"f":1},"n":"RequiredName","d":2148438,"h":12887050326,"f":1}],"m":[{"r":133300225,"p":[{"n":"context","p":510038},{"n":"requirement","p":2148438}],"n":"HandleRequirementAsync","d":2148438,"h":21476984918,"f":32772},{"r":1310721,"n":"ToString","d":2148438,"h":25771952214,"f":32769}],"c":[{"p":[{"n":"requiredName","p":1310721}],"n":".ctor","o":"$ctor$2","d":2148438,"h":4297115734,"f":1}],"i":[1493078,1755222],"h":2148438}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `NameAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement", ($self) => class ClaimsAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            /*bool*/ _emptyAllowedValues = false;
            $ctor$2(/*string*/ claimType, /*IEnumerable<string>?*/ allowedValues)
            {
                super.$ctor$1();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                    this.ClaimType = claimType;
                    this.AllowedValues = allowedValues;
                    this._emptyAllowedValues = this.AllowedValues === null || !$.$sl.System.Linq.Enumerable.Any($.$spc.System.String, this.AllowedValues);
                }
                return this;
            }
            /*string*/ ClaimType = null;
            /*IEnumerable<string>?*/ AllowedValues = null;
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*ClaimsAuthorizationRequirement*/ requirement)
            {
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    if (requirement._emptyAllowedValues)
                    {
                        var $en4 = context.User.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$spc.System.String.Equals$5(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    else 
                    {
                        var $en4 = context.User.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$spc.System.String.Equals$5(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$sl.System.Linq.Enumerable.Contains$1($.$spc.System.String, requirement.AllowedValues, claim.Value, $.$spc.System.StringComparer.Ordinal))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let value = (this._emptyAllowedValues) ? $.$spc.System.String.Empty : ` and Claim.Value is one of the following values: (${$.$spc.System.String.Join$6("|", this.AllowedValues)})`;
                return `${"ClaimsAuthorizationRequirement"}:Claim.Type=${this.ClaimType}${value}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement.ToString.apply(this, arguments); }
            static $h = 2017366;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476853846,"f":1},"n":"ClaimType","d":2017366,"h":17181886550,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":34361755734,"f":1},"n":"AllowedValues","d":2017366,"h":30066788438,"f":1}],"m":[{"r":133300225,"p":[{"n":"context","p":510038},{"n":"requirement","p":2017366}],"n":"HandleRequirementAsync","d":2017366,"h":38656723030,"f":32772},{"r":1310721,"n":"ToString","d":2017366,"h":42951690326,"f":32769}],"l":[{"t":262145,"n":"_emptyAllowedValues","d":2017366,"h":4296984662,"f":2}],"c":[{"p":[{"n":"claimType","p":1310721},{"n":"allowedValues","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$2","d":2017366,"h":8591951958,"f":1}],"i":[1493078,1755222],"h":2017366}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `ClaimsAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement", ($self) => class DenyAnonymousAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*DenyAnonymousAuthorizationRequirement*/ requirement)
            {
                /*var*/ let user = context.User;
                /*var*/ let userIsAnonymous = (user?.Identity ?? null) === null || !$.$sl.System.Linq.Enumerable.Any$1($.$ssc.System.Security.Claims.ClaimsIdentity, user.Identities, new ($.$spc.System.Func$$$($.$ssc.System.Security.Claims.ClaimsIdentity, $.$spc.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.IsAuthenticated;
                }, {"r":262145,"p":[{"n":"i","p":294927}],"n":"","d":2082902,"h":0,"f":1048578}));
                if (!userIsAnonymous)
                {
                    context.Succeed(requirement);
                }
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"DenyAnonymousAuthorizationRequirement"}: Requires an authenticated user.`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement.ToString.apply(this, arguments); }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2082902;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133300225,"p":[{"n":"context","p":510038},{"n":"requirement","p":2082902}],"n":"HandleRequirementAsync","d":2082902,"h":4297050198,"f":32772},{"r":1310721,"n":"ToString","d":2082902,"h":8592017494,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":2082902,"h":12886984790,"f":1}],"i":[1493078,1755222],"h":2082902}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `DenyAnonymousAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement", ($self) => class RolesAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            $ctor$2(/*IEnumerable<string>*/ allowedRoles)
            {
                super.$ctor$1();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(allowedRoles, "allowedRoles");
                    if (!$.$sl.System.Linq.Enumerable.Any($.$spc.System.String, allowedRoles))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$maa.Resources.Exception_RoleRequirementEmpty);
                    }
                    this.AllowedRoles = allowedRoles;
                }
                return this;
            }
            /*IEnumerable<string>*/ AllowedRoles = null;
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*RolesAuthorizationRequirement*/ requirement)
            {
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    var $en3 = requirement.AllowedRoles.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var role = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (context.User.IsInRole(role))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let roles = `User.IsInRole must be true for one of the following roles: (${$.$spc.System.String.Join$6("|", this.AllowedRoles)})`;
                return `${"RolesAuthorizationRequirement"}:${roles}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement.ToString.apply(this, arguments); }
            static $h = 2345046;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":17182214230,"f":1},"n":"AllowedRoles","d":2345046,"h":12887246934,"f":1}],"m":[{"r":133300225,"p":[{"n":"context","p":510038},{"n":"requirement","p":2345046}],"n":"HandleRequirementAsync","d":2345046,"h":21477181526,"f":32772},{"r":1310721,"n":"ToString","d":2345046,"h":25772148822,"f":32769}],"c":[{"p":[{"n":"allowedRoles","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$2","d":2345046,"h":4297312342,"f":1}],"i":[1493078,1755222],"h":2345046}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `RolesAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationServiceImpl", ($self) => class DefaultAuthorizationServiceImpl extends $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService
        {
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        result = await super.AuthorizeAsync(user, resource, requirements).ConfigureAwait$2(false);
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, null, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, null, result, null);
                    return result;
                });
            }
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        /*var*/ let policy = await this.GetPolicyAsync(policyName).ConfigureAwait$2(false);
                        result = await super.AuthorizeAsync(user, resource, policy.Requirements).ConfigureAwait$2(false);
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, policyName, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, policyName, result, null);
                    return result;
                });
            }
            //Begin primary constructor
            /*IAuthorizationPolicyProvider*/ policyProvider = null;
            /*IAuthorizationHandlerProvider*/ handlers = null;
            /*ILogger<DefaultAuthorizationService>*/ logger = null;
            /*IAuthorizationHandlerContextFactory*/ contextFactory = null;
            /*IAuthorizationEvaluator*/ evaluator = null;
            /*IOptions<AuthorizationOptions>*/ options = null;
            /*AuthorizationMetrics*/ metrics = null;
            $ctor$2(/*IAuthorizationPolicyProvider*/$policyProvider, /*IAuthorizationHandlerProvider*/$handlers, /*ILogger<DefaultAuthorizationService>*/$logger, /*IAuthorizationHandlerContextFactory*/$contextFactory, /*IAuthorizationEvaluator*/$evaluator, /*IOptions<AuthorizationOptions>*/$options, /*AuthorizationMetrics*/$metrics)
            {
                this.policyProvider = $policyProvider;
                this.handlers = $handlers;
                this.logger = $logger;
                this.contextFactory = $contextFactory;
                this.evaluator = $evaluator;
                this.options = $options;
                this.metrics = $metrics;
                return this
            }
            //End primary constructor
            static $h = 1362006;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1296470,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"requirements","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AuthorizeAsync","d":1362006,"h":12886263894,"f":36865},{"r":$.$spc.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":425999},{"n":"resource","p":131073},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"@$1","d":1362006,"h":17181231190,"f":36865}],"l":[{"t":575574,"n":"\u003Cmetrics\u003EP","d":1362006,"h":8591296598,"f":2}],"c":[{"p":[{"n":"policyProvider","p":1689686},{"n":"handlers","p":1624150},{"n":"logger","p":$.$mela.Microsoft.Extensions.Logging.ILogger$$($.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService).$h},{"n":"contextFactory","p":1558614},{"n":"evaluator","p":1427542},{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h},{"n":"metrics","p":575574}],"n":".ctor","o":"$ctor$2","d":1362006,"h":4296329302,"f":1}],"i":[1886294],"h":1362006}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService ]; }
            static get $fullName() { return `DefaultAuthorizationServiceImpl`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions"))