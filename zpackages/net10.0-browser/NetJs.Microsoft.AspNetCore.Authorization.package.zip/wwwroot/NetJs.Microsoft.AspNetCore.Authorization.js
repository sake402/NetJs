
(function ($global, $, $$, $mam, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Authorization", 
    {"h":55948,"f":"Microsoft.AspNetCore.Authorization","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":96206849,"c":4391174145,"a":[{"v":190691,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":125155,"t":142475265}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"ASP.NET Core authorization classes.\nCommonly used types:\nMicrosoft.AspNetCore.Authorization.AllowAnonymousAttribute\nMicrosoft.AspNetCore.Authorization.AuthorizeAttribute","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Authorization","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Authorization","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.AspNetCore.Authorization.Test","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler", ($self) => class IAuthorizationHandler
        {
            static $h = 1497740;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133169153,"p":[{"n":"context","p":514700}],"n":"HandleAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync","d":1497740,"h":4296465036,"f":16777473}],"h":1497740}; }
            static get $fullName() { return `IAuthorizationHandler`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider", ($self) => class IAuthorizationHandlerProvider
        {
            static $h = 1628812;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,"p":[{"n":"context","p":514700}],"n":"GetHandlersAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync","d":1628812,"h":4296596108,"f":16777473}],"h":1628812}; }
            static get $fullName() { return `IAuthorizationHandlerProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory", ($self) => class IAuthorizationHandlerContextFactory
        {
            static $h = 1563276;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":514700,"p":[{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"user","p":426462},{"n":"resource","p":131073}],"n":"CreateContext","o":"Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext","d":1563276,"h":4296530572,"f":16777473}],"h":1563276}; }
            static get $fullName() { return `IAuthorizationHandlerContextFactory`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider", ($self) => class IAuthorizationPolicyProvider
        {
            static $h = 1694348;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyName","p":1310721}],"n":"GetPolicyAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync","d":1694348,"h":4296661644,"f":16777473},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetDefaultPolicyAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync","d":1694348,"h":8591628940,"f":16777473},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetFallbackPolicyAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync","d":1694348,"h":12886596236,"f":16777473}],"h":1694348}; }
            static get $fullName() { return `IAuthorizationPolicyProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService", ($self) => class IAuthorizationService
        {
            static $h = 1890956;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AuthorizeAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync","d":1890956,"h":4296858252,"f":16777473},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1","d":1890956,"h":8591825548,"f":16777473}],"h":1890956}; }
            static get $fullName() { return `IAuthorizationService`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirementData", ($self) => class IAuthorizationRequirementData
        {
            static $h = 1825420;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"n":"GetRequirements","o":"Microsoft$AspNetCore$Authorization$IAuthorizationRequirementData$GetRequirements","d":1825420,"h":4296792716,"f":16777473}],"h":1825420}; }
            static get $fullName() { return `IAuthorizationRequirementData`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement", ($self) => class IAuthorizationRequirement
        {
            static $h = 1759884;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":1759884}; }
            static get $fullName() { return `IAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator", ($self) => class IAuthorizationEvaluator
        {
            static $h = 1432204;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":842380,"p":[{"n":"context","p":514700}],"n":"Evaluate","o":"Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate","d":1432204,"h":4296399500,"f":16777473}],"h":1432204}; }
            static get $fullName() { return `IAuthorizationEvaluator`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<>", (TRequirement) => $asm.$gt("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<>", [TRequirement], ($self) => class AuthorizationHandler$$ extends $.$$.System.Object
        {
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    var $en3 = $.$sl.System.Linq.Enumerable.OfType(TRequirement, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var req = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await this.HandleRequirementAsync(context, req).ConfigureAwait(false);
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 449164;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"context","p":514700}],"n":"HandleAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16781441},{"r":133169153,"p":[{"n":"context","p":514700},{"n":"requirement","p":TRequirement?.$h??1507328}],"n":"HandleRequirementAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777476}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777220}],"i":[1497740],"g":[TRequirement?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `AuthorizationHandler<${TRequirement?.$fullName}>`; }
        }));
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<,>", (TRequirement, TResource) => $asm.$gt("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler<,>", [TRequirement, TResource], ($self) => class AuthorizationHandler$$$ extends $.$$.System.Object
        {
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    let resource;
                    if ($.$is(context.Resource, TResource, { set $v(v){ resource = v; } }))
                    {
                        var $en4 = $.$sl.System.Linq.Enumerable.OfType(TRequirement, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var req = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                await this.HandleRequirementAsync(context, req, resource).ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 383628;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"context","p":514700}],"n":"HandleAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16781441},{"r":133169153,"p":[{"n":"context","p":514700},{"n":"requirement","p":TRequirement?.$h??1507328},{"n":"resource","p":TResource?.$h??1572864}],"n":"HandleRequirementAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777476}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777220}],"i":[1497740],"g":[TRequirement?.$h??1507328,TResource?.$h??1572864],"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `AuthorizationHandler<${TRequirement?.$fullName},${TResource?.$fullName}>`; }
        }));
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics", ($self) => class AuthorizationMetrics extends $.$$.System.Object
        {
            /*string*/ static MeterName = null;
            /*Meter*/ _meter = null;
            /*Counter<long>*/ _authorizedCount = null;
            $ctor$1(/*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    this._meter = $.$sdd.System.Diagnostics.Metrics.MeterFactoryExtensions.Create(meterFactory, "Microsoft.AspNetCore.Authorization"/*MeterName*/, null, null);
                    this._authorizedCount = this._meter.CreateCounter$1($.$$.System.Int64, "aspnetcore.authorization.attempts", "{attempt}", "The total number of authorization attempts.");
                }
                return this;
            }
            /*void */ AuthorizeAttemptCompleted(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                //if (_authorizedCount.Enabled) { ... }
            }
            /*void */ AuthorizeAttemptCore(/*ClaimsPrincipal*/ user, /*string?*/ policyName, /*AuthorizationResult?*/ result, /*Exception?*/ exception)
            {
                /*var*/ let tags = new $.$sdd.System.Diagnostics.TagList().$ctor$3($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("aspnetcore.user.is_authenticated", $.$box((user.Identity?.System$Security$Principal$IIdentity$IsAuthenticated ?? null) ?? false, $.$$.System.Boolean))], null, null)));
                if (!(policyName === null))
                {
                    tags.Add$1("aspnetcore.authorization.policy", policyName);
                }
                if (!(result === null))
                {
                    /*var*/ let resultTagValue = result.Succeeded ? "success" : "failure";
                    tags.Add$1("aspnetcore.authorization.result", resultTagValue);
                }
                if (!(exception === null))
                {
                    tags.Add$1("error.type", exception.GetType$1().FullName);
                }
                this._authorizedCount.Add$5(1n, $.$ref(() => tags, ));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MeterName = "Microsoft.AspNetCore.Authorization";
                }
            }
            static $h = 580236;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"user","p":426462},{"n":"policyName","p":1310721},{"n":"result","p":842380},{"n":"exception","p":47251457}],"n":"AuthorizeAttemptCompleted","d":580236,"h":21475416716,"f":16777217},{"r":65537,"p":[{"n":"user","p":426462},{"n":"policyName","p":1310721},{"n":"result","p":842380},{"n":"exception","p":47251457}],"n":"AuthorizeAttemptCore","d":580236,"h":25770384012,"f":16777218}],"l":[{"t":1310721,"n":"MeterName","d":580236,"h":4295547532,"f":4194337},{"t":6553644,"n":"_meter","d":580236,"h":8590514828,"f":4194306},{"t":$.$sdd.System.Diagnostics.Metrics.Counter$$($.$$.System.Int64).$h,"n":"_authorizedCount","d":580236,"h":12885482124,"f":4194306}],"c":[{"p":[{"n":"meterFactory","p":5439532}],"n":".ctor","o":"$ctor$1","d":580236,"h":17180449420,"f":16777217}],"h":580236}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationMetrics`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult", ($self) => class AuthorizationResult extends $.$$.System.Object
        {
            /*AuthorizationResult*/ static _succeededResult = null;
            /*AuthorizationResult*/ static _failedResult = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool*/ Succeeded = false;
            /*AuthorizationFailure?*/ Failure = null;
            static /*AuthorizationResult */ Success()
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult._succeededResult;
            }
            static /*AuthorizationResult */ Failed$1(/*AuthorizationFailure*/ failure)
            {
                return (() =>
                {
                    //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                    const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Failure = failure;
                    return $i1;
                })();
            }
            static /*AuthorizationResult */ Failed()
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult._failedResult;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Succeeded = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._succeededResult = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Succeeded = true;
                        return $i1;
                    })();
                }
                {
                    this._failedResult = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Failure = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.ExplicitFail();
                        return $i1;
                    })();
                }
            }
            static $h = 842380;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770646156,"f":50331649},"s":{"r":0,"d":0,"h":30065613452,"f":83886082},"n":"Succeeded","d":842380,"h":21475678860,"f":2097153},{"p":252556,"g":{"r":0,"d":0,"h":42950515340,"f":50331649},"s":{"r":0,"d":0,"h":47245482636,"f":83886082},"n":"Failure","d":842380,"h":38655548044,"f":2097153}],"m":[{"r":842380,"n":"Success","d":842380,"h":51540449932,"f":16777249},{"r":842380,"p":[{"n":"failure","p":252556}],"n":"Failed","o":"@$1","d":842380,"h":55835417228,"f":16777249},{"r":842380,"n":"Failed","d":842380,"h":60130384524,"f":16777249}],"l":[{"t":842380,"n":"_succeededResult","d":842380,"h":4295809676,"f":4194338},{"t":842380,"n":"_failedResult","d":842380,"h":8590776972,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":842380,"h":12885744268,"f":16777218}],"h":842380}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationResult`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions", ($self) => class AuthorizationOptions extends $.$$.System.Object
        {
            /*Task<AuthorizationPolicy?>*/ static _nullPolicyTask = null;
            /*Dictionary<string, Task<AuthorizationPolicy?>>*/ PolicyMap = null;
            /*bool*/ InvokeHandlersAfterFailure = false;
            /*AuthorizationPolicy*/ DefaultPolicy = null;
            /*AuthorizationPolicy?*/ FallbackPolicy = null;
            /*void */ AddPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.PolicyMap.set_Item(name, $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policy));
            }
            /*void */ AddPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                this.PolicyMap.set_Item(name, $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policyBuilder.Build()));
            }
            /*AuthorizationPolicy? */ GetPolicy(/*string*/ name)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value;
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy))))
                {
                    return value.Result;
                }
                return null;
            }
            /*Task<AuthorizationPolicy?> */ GetPolicyTask(/*string*/ name)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value;
                if (this.PolicyMap.TryGetValue(name, $.$ref(() => value, ($v) => value = $v, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy))))
                {
                    return value;
                }
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions._nullPolicyTask;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PolicyMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy)))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                this.InvokeHandlersAfterFailure = true;
                this.DefaultPolicy = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null)).RequireAuthenticatedUser().Build();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._nullPolicyTask = $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, null);
                }
            }
            static $h = 645772;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy)).$h,"g":{"r":0,"d":0,"h":17180514956,"f":50331650},"n":"PolicyMap","d":645772,"h":12885547660,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":30065416844,"f":50331649},"s":{"r":0,"d":0,"h":34360384140,"f":83886081},"n":"InvokeHandlersAfterFailure","d":645772,"h":25770449548,"f":2097153},{"p":711308,"g":{"r":0,"d":0,"h":47245286028,"f":50331649},"s":{"r":0,"d":0,"h":51540253324,"f":83886081},"n":"DefaultPolicy","d":645772,"h":42950318732,"f":2097153},{"p":711308,"g":{"r":0,"d":0,"h":64425155212,"f":50331649},"s":{"r":0,"d":0,"h":68720122508,"f":83886081},"n":"FallbackPolicy","d":645772,"h":60130187916,"f":2097153}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"policy","p":711308}],"n":"AddPolicy","o":"@$1","d":645772,"h":73015089804,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddPolicy","d":645772,"h":77310057100,"f":16777217},{"r":711308,"p":[{"n":"name","p":1310721}],"n":"GetPolicy","d":645772,"h":81605024396,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"name","p":1310721}],"n":"GetPolicyTask","d":645772,"h":85899991692,"f":16777224}],"l":[{"t":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"_nullPolicyTask","d":645772,"h":4295613068,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":645772,"h":90194958988,"f":16777217}],"h":645772}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationOptions`; }
        });
        
        $asm.$cls("$maa.Resources", ($self) => class Resources
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$maa.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.AspNetCore.Authorization", $.$maa.Resources.$type.Assembly);
                    $.$maa.Resources.s_resourceManager = temp;
                }
                return $.$maa.Resources.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$maa.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$maa.Resources.resourceCulture = value;
            }
            static /*string */ get Exception_AuthorizationPolicyEmpty()
            {
                return "AuthorizationPolicy must have at least one requirement.";
            }
            static /*string */ get Exception_AuthorizationPolicyNotFound()
            {
                return "The AuthorizationPolicy named: '{0}' was not found.";
            }
            static /*string */ FormatException_AuthorizationPolicyNotFound(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The AuthorizationPolicy named: '{0}' was not found.", arg1);
            }
            static /*string */ get Exception_RoleRequirementEmpty()
            {
                return "At least one role must be specified.";
            }
            static $h = 2677388;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":85393409,"g":{"r":0,"d":0,"h":17182546572,"f":50331688},"n":"ResourceManager","d":2677388,"h":12887579276,"f":2097192,"a":[{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]},{"p":51183617,"g":{"r":0,"d":0,"h":25772481164,"f":50331688},"s":{"r":0,"d":0,"h":30067448460,"f":83886120},"n":"Culture","d":2677388,"h":21477513868,"f":2097192,"a":[{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38657383052,"f":50331688},"n":"Exception_AuthorizationPolicyEmpty","d":2677388,"h":34362415756,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":47247317644,"f":50331688},"n":"Exception_AuthorizationPolicyNotFound","d":2677388,"h":42952350348,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":60132219532,"f":50331688},"n":"Exception_RoleRequirementEmpty","d":2677388,"h":55837252236,"f":2097192}],"m":[{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatException_AuthorizationPolicyNotFound","d":2677388,"h":51542284940,"f":16777256}],"l":[{"t":85393409,"n":"s_resourceManager","d":2677388,"h":4297644684,"f":4194338},{"t":51183617,"n":"resourceCulture","d":2677388,"h":8592611980,"f":4194338}],"h":2677388,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"System.Resources.Tools.StronglyTypedResourceBuilder","t":1310721},{"v":"17.0.0.0","t":1310721}]},{"t":37748737,"c":4332716033},{"t":88408065,"c":4383375361}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure", ($self) => class AuthorizationFailure extends $.$$.System.Object
        {
            /*AuthorizationFailure*/ static _explicitFailure = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool*/ FailCalled = false;
            /*IEnumerable<IAuthorizationRequirement>*/ FailedRequirements = null;
            /*IEnumerable<AuthorizationFailureReason>*/ FailureReasons = null;
            static /*AuthorizationFailure */ ExplicitFail()
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure._explicitFailure;
            }
            static /*AuthorizationFailure */ Failed(/*IEnumerable<AuthorizationFailureReason>*/ reasons)
            {
                return (() =>
                {
                    //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                    const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.FailCalled = true;
                    $i1.FailureReasons = reasons;
                    return $i1;
                })();
            }
            static /*AuthorizationFailure */ Failed$1(/*IEnumerable<IAuthorizationRequirement>*/ failed)
            {
                return (() =>
                {
                    //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                    const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.FailedRequirements = failed;
                    return $i1;
                })();
            }
            //default member initializer
            constructor()
            {
                super();
                this.FailCalled = false;
                this.FailedRequirements = $.$$.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement);
                this.FailureReasons = $.$$.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._explicitFailure = (() =>
                    {
                        //new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure()
                        const $t1 = $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.FailCalled = true;
                        return $i1;
                    })();
                }
            }
            static $h = 252556;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475089036,"f":50331649},"s":{"r":0,"d":0,"h":25770056332,"f":83886082},"n":"FailCalled","d":252556,"h":17180121740,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":38654958220,"f":50331649},"s":{"r":0,"d":0,"h":42949925516,"f":83886082},"n":"FailedRequirements","d":252556,"h":34359990924,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,"g":{"r":0,"d":0,"h":55834827404,"f":50331649},"s":{"r":0,"d":0,"h":60129794700,"f":83886082},"n":"FailureReasons","d":252556,"h":51539860108,"f":2097153}],"m":[{"r":252556,"n":"ExplicitFail","d":252556,"h":64424761996,"f":16777249},{"r":252556,"p":[{"n":"reasons","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h}],"n":"Failed","d":252556,"h":68719729292,"f":16777249},{"r":252556,"p":[{"n":"failed","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"Failed","o":"@$1","d":252556,"h":73014696588,"f":16777249}],"l":[{"t":252556,"n":"_explicitFailure","d":252556,"h":4295219852,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":252556,"h":8590187148,"f":16777218}],"h":252556}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationFailure`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason", ($self) => class AuthorizationFailureReason extends $.$$.System.Object
        {
            $ctor$1(/*IAuthorizationHandler*/ handler, /*string*/ message)
            {
                super.$ctor();
                {
                    this.Handler = handler;
                    this.Message = message;
                }
                return this;
            }
            /*string*/ Message = null;
            /*IAuthorizationHandler*/ Handler = null;
            static $h = 318092;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180187276,"f":50331649},"n":"Message","d":318092,"h":12885219980,"f":2097153},{"p":1497740,"g":{"r":0,"d":0,"h":30065089164,"f":50331649},"n":"Handler","d":318092,"h":25770121868,"f":2097153}],"c":[{"p":[{"n":"handler","p":1497740},{"n":"message","p":1310721}],"n":".ctor","o":"$ctor$1","d":318092,"h":4295285388,"f":16777217}],"h":318092}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationFailureReason`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions", ($self) => class AuthorizationServiceExtensions
        {
            static /*Task<AuthorizationResult> */ AuthorizeAsync$1(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*IAuthorizationRequirement*/ requirement)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirement, "requirement");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync(user, resource, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement), [requirement], [-1], null));
            }
            static /*Task<AuthorizationResult> */ AuthorizeAsync(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*object?*/ resource, /*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync(user, resource, policy.Requirements);
            }
            static /*Task<AuthorizationResult> */ AuthorizeAsync$3(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync(service, user, null, policy);
            }
            static /*Task<AuthorizationResult> */ AuthorizeAsync$2(/*this IAuthorizationService*/ service, /*ClaimsPrincipal*/ user, /*string*/ policyName)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(service, "service");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                return service.Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1(user, null, policyName);
            }
            static $h = 907916;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1890956},{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"requirement","p":1759884}],"n":"AuthorizeAsync","o":"@$1","d":907916,"h":4295875212,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1890956},{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"policy","p":711308}],"n":"AuthorizeAsync","d":907916,"h":8590842508,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1890956},{"n":"user","p":426462},{"n":"policy","p":711308}],"n":"AuthorizeAsync","o":"@$3","d":907916,"h":12885809804,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"service","p":1890956},{"n":"user","p":426462},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"@$2","d":907916,"h":17180777100,"f":16777249}],"h":907916}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationServiceExtensions`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers", ($self) => class DebuggerHelpers
        {
            static /*string */ GetDebugText$1(/*string*/ key1, /*object?*/ value1, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1)], [-1], null)), includeNullValues, prefix);
            }
            static /*string */ GetDebugText$2(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key2, value2)], [-1], null)), includeNullValues, prefix);
            }
            static /*string */ GetDebugText$3(/*string*/ key1, /*object?*/ value1, /*string*/ key2, /*object?*/ value2, /*string*/ key3, /*object?*/ value3, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText($.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), [$.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key1, value1), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key2, value2), $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.Create(key3, value3)], [-1], null)), includeNullValues, prefix);
            }
            static /*string */ GetDebugText(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ values, /*bool*/ includeNullValues, /*string?*/ prefix)
            {
                if (values.Length === 0)
                {
                    return prefix ?? $.$$.System.String.Empty;
                }
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    sb.Append$19(prefix);
                }
                /*var*/ let first = true;
                for(/*var*/ let i = 0; i < values.Length; i++)
                {
                    /*var*/ let kvp = values.get_Item(i).$v;
                    if ($.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.HasValue(kvp.Value) || includeNullValues)
                    {
                        if (first)
                        {
                            if ($.$$.System.String.op_Inequality(prefix, null))
                            {
                                sb.Append$3(/* */ 32);
                            }
                            first = false;
                        }
                        else 
                        {
                            sb.Append$19(", ");
                        }
                        sb.Append$19(kvp.Key);
                        sb.Append$19(": ");
                        let s;
                        let enumerable;
                        if (kvp.Value === null)
                        {
                            sb.Append$19("(null)");
                        }
                        else if ($.$is(kvp.Value, $.$$.System.String, { set $v(v){ s = v; } }))
                        {
                            sb.Append$19(s);
                        }
                        else if ($.$is(kvp.Value, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                        {
                            /*var*/ let firstItem = true;
                            var $en5 = enumerable.System$Collections$IEnumerable$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$IEnumerator$Current;
                                {
                                    if (firstItem)
                                    {
                                        firstItem = false;
                                    }
                                    else 
                                    {
                                        sb.Append$3(/*,*/ 44);
                                    }
                                    sb.Append$13(item);
                                }
                            }
                        }
                        else 
                        {
                            sb.Append$13(kvp.Value);
                        }
                    }
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*bool */ HasValue(/*object?*/ value)
            {
                if (value === null)
                {
                    return false;
                }
                let enumerable;
                if (!(value !== null && ($.$is(value, $.$$.System.String))) && $.$is(value, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }) && !enumerable.System$Collections$IEnumerable$GetEnumerator().System$Collections$IEnumerator$MoveNext())
                {
                    return false;
                }
                return true;
            }
            static /*KeyValuePair<string, object?> */ Create(/*string*/ key, /*object?*/ value)
            {
                return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(key, value);
            }
            static $h = 2480780;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"key1","p":1310721},{"n":"value1","p":131073},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","o":"@$1","d":2480780,"h":4297448076,"f":16777249},{"r":1310721,"p":[{"n":"key1","p":1310721},{"n":"value1","p":131073},{"n":"key2","p":1310721},{"n":"value2","p":131073},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","o":"@$2","d":2480780,"h":8592415372,"f":16777249},{"r":1310721,"p":[{"n":"key1","p":1310721},{"n":"value1","p":131073},{"n":"key2","p":1310721},{"n":"value2","p":131073},{"n":"key3","p":1310721},{"n":"value3","p":131073},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","o":"@$3","d":2480780,"h":12887382668,"f":16777249},{"r":1310721,"p":[{"n":"values","p":$.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h},{"n":"includeNullValues","p":262145,"f":65,"v":true},{"n":"prefix","p":1310721,"f":65}],"n":"GetDebugText","d":2480780,"h":17182349964,"f":16777249},{"r":262145,"p":[{"n":"value","p":131073}],"n":"HasValue","d":2480780,"h":21477317260,"f":16777250},{"r":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,"p":[{"n":"key","p":1310721},{"n":"value","p":131073}],"n":"Create","d":2480780,"h":25772284556,"f":16777250}],"h":2480780}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DebuggerHelpers`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext", ($self) => class AuthorizationHandlerContext extends $.$$.System.Object
        {
            /*HashSet<IAuthorizationRequirement>*/ _pendingRequirements = null;
            /*List<AuthorizationFailureReason>?*/ _failedReasons = null;
            /*bool*/ _failCalled = false;
            /*bool*/ _succeedCalled = false;
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    this.Requirements = requirements;
                    this.User = user;
                    this.Resource = resource;
                    this._pendingRequirements = new ($.$$.System.Collections.Generic.HashSet$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$3(requirements);
                }
                return this;
            }
            /*IEnumerable<IAuthorizationRequirement>*/ Requirements = null;
            /*ClaimsPrincipal*/ User = null;
            /*object?*/ Resource = null;
            /*IEnumerable<IAuthorizationRequirement> */ get PendingRequirements()
            {
                return this._pendingRequirements;
            }
            /*IEnumerable<AuthorizationFailureReason> */ get FailureReasons()
            {
                return this._failedReasons ?? $.$$.System.Array.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason);
            }
            /*bool */ get HasFailed()
            {
                return this._failCalled;
            }
            /*bool */ get HasSucceeded()
            {
                return !this._failCalled && this._succeedCalled && !$.$sl.System.Linq.Enumerable.Any$1($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, this.PendingRequirements);
            }
            /*void */ Fail()
            {
                this._failCalled = true;
            }
            /*void */ Fail$1(/*AuthorizationFailureReason*/ reason)
            {
                this.Fail();
                if (reason !== null)
                {
                    if (this._failedReasons === null)
                    {
                        this._failedReasons = new ($.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason))().$ctor$1();
                    }
                    this._failedReasons.Add(reason);
                }
            }
            /*void */ Succeed(/*IAuthorizationRequirement*/ requirement)
            {
                this._succeedCalled = true;
                this._pendingRequirements.Remove(requirement);
            }
            static $h = 514700;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":34360253068,"f":50331777},"n":"Requirements","d":514700,"h":30065285772,"f":2097281},{"p":426462,"g":{"r":0,"d":0,"h":47245154956,"f":50331777},"n":"User","d":514700,"h":42950187660,"f":2097281},{"p":131073,"g":{"r":0,"d":0,"h":60130056844,"f":50331777},"n":"Resource","d":514700,"h":55835089548,"f":2097281},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":68719991436,"f":50331777},"n":"PendingRequirements","d":514700,"h":64425024140,"f":2097281},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,"g":{"r":0,"d":0,"h":77309926028,"f":50331777},"n":"FailureReasons","d":514700,"h":73014958732,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":85899860620,"f":50331777},"n":"HasFailed","d":514700,"h":81604893324,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":94489795212,"f":50331777},"n":"HasSucceeded","d":514700,"h":90194827916,"f":2097281}],"m":[{"r":65537,"n":"Fail","d":514700,"h":98784762508,"f":16777345},{"r":65537,"p":[{"n":"reason","p":318092}],"n":"Fail","o":"@$1","d":514700,"h":103079729804,"f":16777345},{"r":65537,"p":[{"n":"requirement","p":1759884}],"n":"Succeed","d":514700,"h":107374697100,"f":16777345}],"l":[{"t":$.$$.System.Collections.Generic.HashSet$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"n":"_pendingRequirements","d":514700,"h":4295481996,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailureReason).$h,"n":"_failedReasons","d":514700,"h":8590449292,"f":4194306},{"t":262145,"n":"_failCalled","d":514700,"h":12885416588,"f":4194306},{"t":262145,"n":"_succeedCalled","d":514700,"h":17180383884,"f":4194306}],"c":[{"p":[{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"user","p":426462},{"n":"resource","p":131073}],"n":".ctor","o":"$ctor$1","d":514700,"h":21475351180,"f":16777217}],"h":514700}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationHandlerContext`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            static $h = 2415244;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":131073},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2742924,"c":4297710220,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNull","d":2415244,"h":4297382540,"f":16777249},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2742924,"c":4297710220,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":2415244,"h":8592349836,"f":16777249}],"h":2415244}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        
        $asm.$cls("$maa.Microsoft.Extensions.DependencyInjection.AuthorizationServiceCollectionExtensions", ($self) => class AuthorizationServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddAuthorizationCore$1(/*this IServiceCollection*/ services)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.AddMetrics$1(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$3($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics, $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationMetrics));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationServiceImpl));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationPolicyProvider));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerProvider));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationEvaluator));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory, $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerContextFactory));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$2($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.PassThroughAuthorizationHandler));
                return services;
            }
            static /*IServiceCollection */ AddAuthorizationCore(/*this IServiceCollection*/ services, /*Action<AuthorizationOptions>*/ configure)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configure, "configure");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, services, configure);
                return $.$maa.Microsoft.Extensions.DependencyInjection.AuthorizationServiceCollectionExtensions.AddAuthorizationCore$1(services);
            }
            static $h = 2546316;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"AddAuthorizationCore","o":"@$1","d":2546316,"h":4297513612,"f":16777249},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configure","p":$.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":"AddAuthorizationCore","d":2546316,"h":8592480908,"f":16777249}],"h":2546316}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$maa.Microsoft.Extensions.Logging.LoggingExtensions", ($self) => class LoggingExtensions
        {
            static /*void */ UserAuthorizationFailed$1(/*this ILogger*/ logger, /*AuthorizationFailure*/ failure)
            {
                /*var*/ let reason = failure.FailCalled ? "Fail() was explicitly called." : "These requirements were not met:" + $.$$.System.Environment.NewLine + $.$$.System.String.Join$12($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, $.$$.System.Environment.NewLine, failure.FailedRequirements);
                $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationFailed(logger, reason);
            }
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.Exception?>*/ static __UserAuthorizationSucceededCallback = null;
            static /*void */ UserAuthorizationSucceeded(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger)
            {
                if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                {
                    $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.__UserAuthorizationSucceededCallback.Invoke(logger, null);
                }
            }
            /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __UserAuthorizationFailedCallback = null;
            static /*void */ UserAuthorizationFailed(/*this global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ reason)
            {
                if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/))
                {
                    $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.__UserAuthorizationFailedCallback.Invoke(logger, reason, null);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.__UserAuthorizationSucceededCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$3(1, "UserAuthorizationSucceeded"), "Authorization was successful.", (() =>
                    {
                        //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                        const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SkipEnabledCheck = true;
                        return $i1;
                    })());
                }
                {
                    this.__UserAuthorizationFailedCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$12($.$$.System.String, 2/*global::Microsoft.Extensions.Logging.LogLevel.Information*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$3(2, "UserAuthorizationFailed"), "Authorization failed. {Reason}", (() =>
                    {
                        //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                        const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.SkipEnabledCheck = true;
                        return $i1;
                    })());
                }
            }
            static $h = 2611852;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"logger","p":917525}],"n":"UserAuthorizationSucceeded","d":2611852,"h":4297579148,"f":16777249,"a":[{"t":2228245,"c":8592162837,"a":[{"v":1,"t":655361},{"v":1,"t":2293781},{"v":"Authorization was successful.","t":1310721}],"n":[{"n":"EventName","v":"UserAuthorizationSucceeded","t":1310721}]},{"t":23592961,"c":12908494849,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"reason","p":1310721}],"n":"UserAuthorizationFailed","d":2611852,"h":8592546444,"f":16777250,"a":[{"t":2228245,"c":8592162837,"a":[{"v":2,"t":655361},{"v":2,"t":2293781},{"v":"Authorization failed. {Reason}","t":1310721}],"n":[{"n":"EventName","v":"UserAuthorizationFailed","t":1310721}]},{"t":23592961,"c":12908494849,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"failure","p":252556}],"n":"UserAuthorizationFailed","o":"@$1","d":2611852,"h":12887513740,"f":16777249}],"l":[{"t":$.$$.System.Action$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$$.System.Exception).$h,"n":"__UserAuthorizationSucceededCallback","d":2611852,"h":17182481036,"f":4194338,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"t":$.$$.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$$.System.String, $.$$.System.Exception).$h,"n":"__UserAuthorizationFailedCallback","d":2611852,"h":21477448332,"f":4194338,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"h":2611852}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LoggingExtensions`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder", ($self) => class AuthorizationPolicyBuilder extends $.$$.System.Object
        {
            /*DenyAnonymousAuthorizationRequirement*/ static _denyAnonymousAuthorizationRequirement = null;
            $ctor$1(/*params string[]*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    this.AddAuthenticationSchemes(authenticationSchemes);
                }
                return this;
            }
            $ctor$2(/*AuthorizationPolicy*/ policy)
            {
                super.$ctor();
                {
                    this.Combine(policy);
                }
                return this;
            }
            /*IList<IAuthorizationRequirement>*/ Requirements = null;
            /*IList<string>*/ AuthenticationSchemes = null;
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemes(/*params string[]*/ schemes)
            {
                return this.AddAuthenticationSchemesCore(schemes);
            }
            /*AuthorizationPolicyBuilder */ AddAuthenticationSchemesCore(/*IEnumerable<string>*/ schemes)
            {
                var $en2 = schemes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var authType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.AuthenticationSchemes.System$Collections$Generic$ICollection$$$Add(authType, [$.$$.System.String]);
                    }
                }
                return this;
            }
            /*AuthorizationPolicyBuilder */ AddRequirements(/*params IAuthorizationRequirement[]*/ requirements)
            {
                return this.AddRequirementsCore(requirements);
            }
            /*AuthorizationPolicyBuilder */ AddRequirementsCore(/*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                var $en2 = requirements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var req = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.Requirements.System$Collections$Generic$ICollection$$$Add(req, [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                    }
                }
                return this;
            }
            /*AuthorizationPolicyBuilder */ Combine(/*AuthorizationPolicy*/ policy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policy, "policy");
                this.AddAuthenticationSchemesCore(policy.AuthenticationSchemes);
                this.AddRequirementsCore(policy.Requirements);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireClaim$1(/*string*/ claimType, /*params string[]*/ allowedValues)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                return this.RequireClaim(claimType, allowedValues);
            }
            /*AuthorizationPolicyBuilder */ RequireClaim(/*string*/ claimType, /*IEnumerable<string>*/ allowedValues)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement().$ctor$2(claimType, allowedValues), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireClaim$2(/*string*/ claimType)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement().$ctor$2(claimType, null), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireRole$1(/*params string[]*/ roles)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                return this.RequireRole(roles);
            }
            /*AuthorizationPolicyBuilder */ RequireRole(/*IEnumerable<string>*/ roles)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(roles, "roles");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement().$ctor$2(roles), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireUserName(/*string*/ userName)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(userName, "userName");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement().$ctor$2(userName), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireAuthenticatedUser()
            {
                this.Requirements.System$Collections$Generic$ICollection$$$Add($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder._denyAnonymousAuthorizationRequirement, [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireAssertion(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement().$ctor$1(handler), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicyBuilder */ RequireAssertion$1(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                this.Requirements.System$Collections$Generic$ICollection$$$Add(new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement().$ctor$2(handler), [$.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement]);
                return this;
            }
            /*AuthorizationPolicy */ Build()
            {
                return new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy().$ctor$1(this.Requirements, $.$sl.System.Linq.Enumerable.Distinct$1($.$$.System.String, this.AuthenticationSchemes));
            }
            //default member initializer
            constructor()
            {
                super();
                this.Requirements = new ($.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$1();
                this.AuthenticationSchemes = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._denyAnonymousAuthorizationRequirement = new $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement().$ctor$2();
                }
            }
            static $h = 776844;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IList$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":25770580620,"f":50331649},"s":{"r":0,"d":0,"h":30065547916,"f":83886081},"n":"Requirements","d":776844,"h":21475613324,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":42950449804,"f":50331649},"s":{"r":0,"d":0,"h":47245417100,"f":83886081},"n":"AuthenticationSchemes","d":776844,"h":38655482508,"f":2097153}],"m":[{"r":776844,"p":[{"n":"schemes","p":$.$typeArray($.$$.System.String).$h,"f":16}],"n":"AddAuthenticationSchemes","d":776844,"h":51540384396,"f":16777217},{"r":776844,"p":[{"n":"schemes","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":"AddAuthenticationSchemesCore","d":776844,"h":55835351692,"f":16777218},{"r":776844,"p":[{"n":"requirements","p":$.$typeArray($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"f":16}],"n":"AddRequirements","d":776844,"h":60130318988,"f":16777217},{"r":776844,"p":[{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AddRequirementsCore","d":776844,"h":64425286284,"f":16777218},{"r":776844,"p":[{"n":"policy","p":711308}],"n":"Combine","d":776844,"h":68720253580,"f":16777217},{"r":776844,"p":[{"n":"claimType","p":1310721},{"n":"allowedValues","p":$.$typeArray($.$$.System.String).$h,"f":16}],"n":"RequireClaim","o":"@$1","d":776844,"h":73015220876,"f":16777217},{"r":776844,"p":[{"n":"claimType","p":1310721},{"n":"allowedValues","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":"RequireClaim","d":776844,"h":77310188172,"f":16777217},{"r":776844,"p":[{"n":"claimType","p":1310721}],"n":"RequireClaim","o":"@$2","d":776844,"h":81605155468,"f":16777217},{"r":776844,"p":[{"n":"roles","p":$.$typeArray($.$$.System.String).$h,"f":16}],"n":"RequireRole","o":"@$1","d":776844,"h":85900122764,"f":16777217},{"r":776844,"p":[{"n":"roles","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":"RequireRole","d":776844,"h":90195090060,"f":16777217},{"r":776844,"p":[{"n":"userName","p":1310721}],"n":"RequireUserName","d":776844,"h":94490057356,"f":16777217},{"r":776844,"n":"RequireAuthenticatedUser","d":776844,"h":98785024652,"f":16777217},{"r":776844,"p":[{"n":"handler","p":$.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Boolean).$h}],"n":"RequireAssertion","d":776844,"h":103079991948,"f":16777217},{"r":776844,"p":[{"n":"handler","p":$.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)).$h}],"n":"RequireAssertion","o":"@$1","d":776844,"h":107374959244,"f":16777217},{"r":711308,"n":"Build","d":776844,"h":111669926540,"f":16777217}],"l":[{"t":2087564,"n":"_denyAnonymousAuthorizationRequirement","d":776844,"h":4295744140,"f":4194338}],"c":[{"p":[{"n":"authenticationSchemes","p":$.$typeArray($.$$.System.String).$h,"f":16}],"n":".ctor","o":"$ctor$1","d":776844,"h":8590711436,"f":16777217},{"p":[{"n":"policy","p":711308}],"n":".ctor","o":"$ctor$2","d":776844,"h":12885678732,"f":16777217}],"h":776844}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationPolicyBuilder`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy", ($self) => class AuthorizationPolicy extends $.$$.System.Object
        {
            $ctor$1(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*IEnumerable<string>*/ authenticationSchemes)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(authenticationSchemes, "authenticationSchemes");
                    if (!$.$sl.System.Linq.Enumerable.Any$1($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement, requirements))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$maa.Resources.Exception_AuthorizationPolicyEmpty);
                    }
                    this.Requirements = new ($.$$.System.Collections.Generic.List$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement))().$ctor$2(requirements).AsReadOnly();
                    this.AuthenticationSchemes = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$2(authenticationSchemes).AsReadOnly();
                }
                return this;
            }
            /*IReadOnlyList<IAuthorizationRequirement>*/ Requirements = null;
            /*IReadOnlyList<string>*/ AuthenticationSchemes = null;
            static /*AuthorizationPolicy */ Combine$1(/*params AuthorizationPolicy[]*/ policies)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.Combine(policies);
            }
            static /*AuthorizationPolicy */ Combine(/*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policies, "policies");
                /*var*/ let builder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                var $en2 = policies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var policy = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        builder.Combine(policy);
                    }
                }
                return builder.Build();
            }
            static /*Task<AuthorizationPolicy?> */ CombineAsync$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData)
            {
                return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.CombineAsync(policyProvider, authorizeData, $.$sl.System.Linq.Enumerable.Empty($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy));
            }
            static /*Task<AuthorizationPolicy?> *//*async*/  CombineAsync(/*IAuthorizationPolicyProvider*/ policyProvider, /*IEnumerable<IAuthorizeData>*/ authorizeData, /*IEnumerable<AuthorizationPolicy>*/ policies)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, async () => 
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(authorizeData, "authorizeData");
                    /*var*/ let anyPolicies = $.$sl.System.Linq.Enumerable.Any$1($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, policies);
                    /*var*/ let skipEnumeratingData = false;
                    let dataList;
                    if ($.$is(authorizeData, $.$$.System.Collections.Generic.IList$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData), { set $v(v){ dataList = v; } }))
                    {
                        skipEnumeratingData = dataList.System$Collections$Generic$ICollection$$$Count === 0;
                    }
                    /*AuthorizationPolicyBuilder?*/ let policyBuilder = null;
                    if (!skipEnumeratingData)
                    {
                        var $en4 = authorizeData.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var authorizeDatum = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (policyBuilder === null)
                                {
                                    policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                                }
                                /*var*/ let useDefaultPolicy = !(anyPolicies);
                                if (!$.$$.System.String.IsNullOrWhiteSpace(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy))
                                {
                                    /*var*/ let policy = await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy).ConfigureAwait$2(false);
                                    if (policy === null)
                                    {
                                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$maa.Resources.FormatException_AuthorizationPolicyNotFound(authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy));
                                    }
                                    policyBuilder.Combine(policy);
                                    useDefaultPolicy = false;
                                }
                                const $t1 = () => authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles;
                                /*var*/ let rolesSplit = $.$ifnn($t1, ($t) => $.$$.System.String.Split$1.call($t, /*,*/ 44, 0));
                                const $t2 = rolesSplit;
                                if ($.$$.System.Int32.op_GreaterThan$1($.$ifnn($t2, ($t) => $t.length), 0))
                                {
                                    /*var*/ let trimmedRolesSplit = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.String, $.$$.System.String, $.$sl.System.Linq.Enumerable.Where($.$$.System.String, rolesSplit, new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.Boolean))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return !$.$$.System.String.IsNullOrWhiteSpace(r);
                                    }, {"r":262145,"p":[{"n":"r","p":1310721}],"n":"","d":711308,"h":0,"f":17825794})), new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.String))().$ctor(this,  (/*r*/ r) =>
                                    {
                                        return $.$$.System.String.Trim.call(r);
                                    }, {"r":1310721,"p":[{"n":"r","p":1310721}],"n":"","d":711308,"h":0,"f":17825794}));
                                    policyBuilder.RequireRole(trimmedRolesSplit);
                                    useDefaultPolicy = false;
                                }
                                const $t3 = () => authorizeDatum.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes;
                                /*var*/ let authTypesSplit = $.$ifnn($t3, ($t) => $.$$.System.String.Split$1.call($t, /*,*/ 44, 0));
                                const $t4 = authTypesSplit;
                                if ($.$$.System.Int32.op_GreaterThan$1($.$ifnn($t4, ($t) => $t.length), 0))
                                {
                                    let $i5 = 0;
                                    let $arr5 = authTypesSplit;
                                    while ($i5 < $arr5.length)
                                    {
                                        let authType = $arr5[$i5++];
                                        if (!$.$$.System.String.IsNullOrWhiteSpace(authType))
                                        {
                                            policyBuilder.AuthenticationSchemes.System$Collections$Generic$ICollection$$$Add($.$$.System.String.Trim.call(authType), [$.$$.System.String]);
                                        }
                                    }
                                }
                                if (useDefaultPolicy)
                                {
                                    policyBuilder.Combine(await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync().ConfigureAwait$2(false));
                                }
                            }
                        }
                    }
                    if (anyPolicies)
                    {
                        policyBuilder ??= new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                        var $en4 = policies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var policy = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                policyBuilder.Combine(policy);
                            }
                        }
                    }
                    if (policyBuilder === null)
                    {
                        /*var*/ let fallbackPolicy = await policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync().ConfigureAwait$2(false);
                        if (fallbackPolicy !== null)
                        {
                            return fallbackPolicy;
                        }
                    }
                    return policyBuilder?.Build() ?? null;
                });
            }
            static $h = 711308;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IReadOnlyList$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h,"g":{"r":0,"d":0,"h":17180580492,"f":50331649},"n":"Requirements","d":711308,"h":12885613196,"f":2097153},{"p":$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":30065482380,"f":50331649},"n":"AuthenticationSchemes","d":711308,"h":25770515084,"f":2097153}],"m":[{"r":711308,"p":[{"n":"policies","p":$.$typeArray($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"f":16}],"n":"Combine","o":"@$1","d":711308,"h":34360449676,"f":16777249},{"r":711308,"p":[{"n":"policies","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h}],"n":"Combine","d":711308,"h":38655416972,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyProvider","p":1694348},{"n":"authorizeData","p":$.$$.System.Collections.Generic.IEnumerable$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h}],"n":"CombineAsync","o":"@$1","d":711308,"h":42950384268,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyProvider","p":1694348},{"n":"authorizeData","p":$.$$.System.Collections.Generic.IEnumerable$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h},{"n":"policies","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h}],"n":"CombineAsync","d":711308,"h":47245351564,"f":16781345}],"c":[{"p":[{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"authenticationSchemes","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":".ctor","o":"$ctor$1","d":711308,"h":4295678604,"f":16777217}],"h":711308}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationPolicy`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizationBuilder", ($self) => class AuthorizationBuilder extends $.$$.System.Object
        {
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                this.Services = services;
                return this;
            }
            /*IServiceCollection*/ Services = null;
            /*AuthorizationBuilder */ SetInvokeHandlersAfterFailure(/*bool*/ invoke)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/**/ o) =>
                {
                    return o.InvokeHandlersAfterFailure = invoke;
                }, {"r":65537,"p":[{"n":"o","p":645772}],"n":"","d":187020,"h":0,"f":17825794}));
                return this;
            }
            /*AuthorizationBuilder */ SetDefaultPolicy(/*AuthorizationPolicy*/ policy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.DefaultPolicy = policy;
                }, {"r":65537,"p":[{"n":"o","p":645772}],"n":"","d":187020,"h":0,"f":17825794}));
                return this;
            }
            /*AuthorizationBuilder */ SetFallbackPolicy(/*AuthorizationPolicy?*/ policy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.FallbackPolicy = policy;
                }, {"r":65537,"p":[{"n":"o","p":645772}],"n":"","d":187020,"h":0,"f":17825794}));
                return this;
            }
            /*AuthorizationBuilder */ AddPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy$1(name, policy);
                }, {"r":65537,"p":[{"n":"o","p":645772}],"n":"","d":187020,"h":0,"f":17825794}));
                return this;
            }
            /*AuthorizationBuilder */ AddPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, this.Services, new ($.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.AddPolicy(name, configurePolicy);
                }, {"r":65537,"p":[{"n":"o","p":645772}],"n":"","d":187020,"h":0,"f":17825794}));
                return this;
            }
            /*AuthorizationBuilder */ AddDefaultPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                this.SetDefaultPolicy(policy);
                return this.AddPolicy$1(name, policy);
            }
            /*AuthorizationBuilder */ AddDefaultPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddDefaultPolicy$1(name, policyBuilder.Build());
            }
            /*AuthorizationBuilder */ AddFallbackPolicy$1(/*string*/ name, /*AuthorizationPolicy*/ policy)
            {
                this.SetFallbackPolicy(policy);
                return this.AddPolicy$1(name, policy);
            }
            /*AuthorizationBuilder */ AddFallbackPolicy(/*string*/ name, /*Action<AuthorizationPolicyBuilder>*/ configurePolicy)
            {
                $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(configurePolicy, "configurePolicy");
                /*var*/ let policyBuilder = new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [  ], null, null));
                configurePolicy.Invoke(policyBuilder);
                return this.AddFallbackPolicy$1(name, policyBuilder.Build());
            }
            static $h = 187020;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":786435,"g":{"r":0,"d":0,"h":17180056204,"f":50331777},"n":"Services","d":187020,"h":12885088908,"f":2097281}],"m":[{"r":187020,"p":[{"n":"invoke","p":262145}],"n":"SetInvokeHandlersAfterFailure","d":187020,"h":21475023500,"f":16777345},{"r":187020,"p":[{"n":"policy","p":711308}],"n":"SetDefaultPolicy","d":187020,"h":25769990796,"f":16777345},{"r":187020,"p":[{"n":"policy","p":711308}],"n":"SetFallbackPolicy","d":187020,"h":30064958092,"f":16777345},{"r":187020,"p":[{"n":"name","p":1310721},{"n":"policy","p":711308}],"n":"AddPolicy","o":"@$1","d":187020,"h":34359925388,"f":16777345},{"r":187020,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddPolicy","d":187020,"h":38654892684,"f":16777345},{"r":187020,"p":[{"n":"name","p":1310721},{"n":"policy","p":711308}],"n":"AddDefaultPolicy","o":"@$1","d":187020,"h":42949859980,"f":16777345},{"r":187020,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddDefaultPolicy","d":187020,"h":47244827276,"f":16777345},{"r":187020,"p":[{"n":"name","p":1310721},{"n":"policy","p":711308}],"n":"AddFallbackPolicy","o":"@$1","d":187020,"h":51539794572,"f":16777345},{"r":187020,"p":[{"n":"name","p":1310721},{"n":"configurePolicy","p":$.$$.System.Action$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder).$h}],"n":"AddFallbackPolicy","d":187020,"h":55834761868,"f":16777345}],"c":[{"p":[{"n":"services","p":786435}],"n":".ctor","o":"$ctor$1","d":187020,"h":4295154316,"f":16777217}],"h":187020}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthorizationBuilder`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerProvider", ($self) => class DefaultAuthorizationHandlerProvider extends $.$$.System.Object
        {
            /*Task<IEnumerable<IAuthorizationHandler>>*/ _handlersTask = null;
            $ctor$1(/*IEnumerable<IAuthorizationHandler>*/ handlers)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    this._handlersTask = $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler), handlers);
                }
                return this;
            }
            /*Task<IEnumerable<IAuthorizationHandler>> */ GetHandlersAsync(/*AuthorizationHandlerContext*/ context)
            {
                return this._handlersTask;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider.GetHandlersAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync()
            {
                return this.GetHandlersAsync(...arguments);
            }
            static $h = 1170060;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,"p":[{"n":"context","p":514700}],"n":"GetHandlersAsync","d":1170060,"h":12886071948,"f":16777217}],"l":[{"t":$.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler)).$h,"n":"_handlersTask","d":1170060,"h":4296137356,"f":4194306}],"c":[{"p":[{"n":"handlers","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler).$h}],"n":".ctor","o":"$ctor$1","d":1170060,"h":8591104652,"f":16777217}],"i":[1628812],"h":1170060}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerProvider ]; }
            static get $fullName() { return `DefaultAuthorizationHandlerProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationHandlerContextFactory", ($self) => class DefaultAuthorizationHandlerContextFactory extends $.$$.System.Object
        {
            /*AuthorizationHandlerContext */ CreateContext(/*IEnumerable<IAuthorizationRequirement>*/ requirements, /*ClaimsPrincipal*/ user, /*object?*/ resource)
            {
                return new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext().$ctor$1(requirements, user, resource);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory.CreateContext(System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>, System.Security.Claims.ClaimsPrincipal, object?)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext()
            {
                return this.CreateContext(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1104524;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":514700,"p":[{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h},{"n":"user","p":426462},{"n":"resource","p":131073}],"n":"CreateContext","d":1104524,"h":4296071820,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":1104524,"h":8591039116,"f":16777217}],"i":[1563276],"h":1104524}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandlerContextFactory ]; }
            static get $fullName() { return `DefaultAuthorizationHandlerContextFactory`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.OperationAuthorizationRequirement", ($self) => class OperationAuthorizationRequirement extends $.$$.System.Object
        {
            /*string*/ Name = null;
            static/*conventional*/ /*string */ ToString()
            {
                return `${"OperationAuthorizationRequirement"}:Name=${this.Name}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.OperationAuthorizationRequirement.ToString.apply(this, arguments); }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Name = null;
            }
            static $h = 2218636;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12887120524,"f":50331649},"s":{"r":0,"d":0,"h":17182087820,"f":83886081},"n":"Name","d":2218636,"h":8592153228,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":2218636,"h":21477055116,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$1","d":2218636,"h":25772022412,"f":16777217}],"i":[1759884],"h":2218636}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `OperationAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService", ($self) => class DefaultAuthorizationService extends $.$$.System.Object
        {
            /*AuthorizationOptions*/ _options = null;
            /*IAuthorizationHandlerContextFactory*/ _contextFactory = null;
            /*IAuthorizationHandlerProvider*/ _handlers = null;
            /*IAuthorizationEvaluator*/ _evaluator = null;
            /*IAuthorizationPolicyProvider*/ _policyProvider = null;
            /*ILogger*/ _logger = null;
            $ctor$1(/*IAuthorizationPolicyProvider*/ policyProvider, /*IAuthorizationHandlerProvider*/ handlers, /*ILogger<DefaultAuthorizationService>*/ logger, /*IAuthorizationHandlerContextFactory*/ contextFactory, /*IAuthorizationEvaluator*/ evaluator, /*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyProvider, "policyProvider");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handlers, "handlers");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(contextFactory, "contextFactory");
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(evaluator, "evaluator");
                    this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                    this._handlers = handlers;
                    this._policyProvider = policyProvider;
                    this._logger = logger;
                    this._evaluator = evaluator;
                    this._contextFactory = contextFactory;
                }
                return this;
            }
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requirements, "requirements");
                    /*var*/ let authContext = this._contextFactory.Microsoft$AspNetCore$Authorization$IAuthorizationHandlerContextFactory$CreateContext(requirements, user, resource);
                    /*var*/ let handlers = await this._handlers.Microsoft$AspNetCore$Authorization$IAuthorizationHandlerProvider$GetHandlersAsync(authContext).ConfigureAwait$2(false);
                    var $en3 = handlers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var handler = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await handler.Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync(authContext).ConfigureAwait(false);
                            if (!this._options.InvokeHandlersAfterFailure && authContext.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                    /*var*/ let result = this._evaluator.Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate(authContext);
                    if (result.Succeeded)
                    {
                        $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationSucceeded(this._logger);
                    }
                    else 
                    {
                        $.$maa.Microsoft.Extensions.Logging.LoggingExtensions.UserAuthorizationFailed$1(this._logger, result.Failure);
                    }
                    return result;
                });
            }
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    /*var*/ let policy = await this.GetPolicyAsync(policyName).ConfigureAwait$2(false);
                    return await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync(this, user, resource, policy).ConfigureAwait$2(false);
                });
            }
            /*Task<AuthorizationPolicy> *//*async*/  GetPolicyAsync(/*string*/ policyName)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, async () => 
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(policyName, "policyName");
                    return $.$firstOf(await this._policyProvider.Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync(policyName).ConfigureAwait$2(false), () => { throw new $.$$.System.InvalidOperationException().$ctor$12(`No policy found: ${policyName}.`) });
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>)
            Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync()
            {
                return this.AuthorizeAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, string)
            Microsoft$AspNetCore$Authorization$IAuthorizationService$AuthorizeAsync$1()
            {
                return this.AuthorizeAsync$1(...arguments);
            }
            static $h = 1301132;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AuthorizeAsync","d":1301132,"h":34361039500,"f":16781441},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"@$1","d":1301132,"h":38656006796,"f":16781441},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyName","p":1310721}],"n":"GetPolicyAsync","d":1301132,"h":42950974092,"f":16781312}],"l":[{"t":645772,"n":"_options","d":1301132,"h":4296268428,"f":4194306},{"t":1563276,"n":"_contextFactory","d":1301132,"h":8591235724,"f":4194306},{"t":1628812,"n":"_handlers","d":1301132,"h":12886203020,"f":4194306},{"t":1432204,"n":"_evaluator","d":1301132,"h":17181170316,"f":4194306},{"t":1694348,"n":"_policyProvider","d":1301132,"h":21476137612,"f":4194306},{"t":917525,"n":"_logger","d":1301132,"h":25771104908,"f":4194306}],"c":[{"p":[{"n":"policyProvider","p":1694348},{"n":"handlers","p":1628812},{"n":"logger","p":$.$mela.Microsoft.Extensions.Logging.ILogger$$($.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService).$h},{"n":"contextFactory","p":1563276},{"n":"evaluator","p":1432204},{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":".ctor","o":"$ctor$1","d":1301132,"h":30066072204,"f":16777217}],"i":[1890956],"h":1301132}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService ]; }
            static get $fullName() { return `DefaultAuthorizationService`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationPolicyProvider", ($self) => class DefaultAuthorizationPolicyProvider extends $.$$.System.Object
        {
            /*AuthorizationOptions*/ _options = null;
            /*Task<AuthorizationPolicy>?*/ _cachedDefaultPolicy = null;
            /*Task<AuthorizationPolicy?>?*/ _cachedFallbackPolicy = null;
            $ctor$1(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(options, "options");
                    this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                }
                return this;
            }
            /*Task<AuthorizationPolicy> */ GetDefaultPolicyAsync()
            {
                if (this._cachedDefaultPolicy === null || this._cachedDefaultPolicy.Result !== this._options.DefaultPolicy)
                {
                    this._cachedDefaultPolicy = $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, this._options.DefaultPolicy);
                }
                return this._cachedDefaultPolicy;
            }
            /*Task<AuthorizationPolicy?> */ GetFallbackPolicyAsync()
            {
                if (this._cachedFallbackPolicy === null || this._cachedFallbackPolicy.Result !== this._options.FallbackPolicy)
                {
                    this._cachedFallbackPolicy = $.$$.System.Threading.Tasks.Task.FromResult($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy, this._options.FallbackPolicy);
                }
                return this._cachedFallbackPolicy;
            }
            /*Task<AuthorizationPolicy?> */ GetPolicyAsync(/*string*/ policyName)
            {
                return this._options.GetPolicyTask(policyName);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetPolicyAsync(string)
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetPolicyAsync()
            {
                return this.GetPolicyAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetDefaultPolicyAsync()
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetDefaultPolicyAsync()
            {
                return this.GetDefaultPolicyAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetFallbackPolicyAsync()
            Microsoft$AspNetCore$Authorization$IAuthorizationPolicyProvider$GetFallbackPolicyAsync()
            {
                return this.GetFallbackPolicyAsync(...arguments);
            }
            static $h = 1235596;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetDefaultPolicyAsync","d":1235596,"h":21476072076,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"GetFallbackPolicyAsync","d":1235596,"h":25771039372,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"p":[{"n":"policyName","p":1310721}],"n":"GetPolicyAsync","d":1235596,"h":30066006668,"f":16777345}],"l":[{"t":645772,"n":"_options","d":1235596,"h":4296202892,"f":4194306},{"t":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"_cachedDefaultPolicy","d":1235596,"h":8591170188,"f":4194306},{"t":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy).$h,"n":"_cachedFallbackPolicy","d":1235596,"h":12886137484,"f":4194306}],"c":[{"p":[{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":".ctor","o":"$ctor$1","d":1235596,"h":17181104780,"f":16777217}],"i":[1694348],"h":1235596}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider ]; }
            static get $fullName() { return `DefaultAuthorizationPolicyProvider`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationEvaluator", ($self) => class DefaultAuthorizationEvaluator extends $.$$.System.Object
        {
            /*AuthorizationResult */ Evaluate(/*AuthorizationHandlerContext*/ context)
            {
                return context.HasSucceeded ? $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult.Success() : $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult.Failed$1(context.HasFailed ? $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.Failed(context.FailureReasons) : $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationFailure.Failed$1(context.PendingRequirements));
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator.Evaluate(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationEvaluator$Evaluate()
            {
                return this.Evaluate(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1038988;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":842380,"p":[{"n":"context","p":514700}],"n":"Evaluate","d":1038988,"h":4296006284,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":1038988,"h":8590973580,"f":16777217}],"i":[1432204],"h":1038988}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationEvaluator ]; }
            static get $fullName() { return `DefaultAuthorizationEvaluator`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.PassThroughAuthorizationHandler", ($self) => class PassThroughAuthorizationHandler extends $.$$.System.Object
        {
            /*AuthorizationOptions*/ _options = null;
            $ctor$1()
            {
                this.$ctor$2($.$meo.Microsoft.Extensions.Options.Options.Create($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions, new $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions().$ctor$1()));
                {
                }
                return this;
            }
            $ctor$2(/*IOptions<AuthorizationOptions>*/ options)
            {
                super.$ctor();
                this._options = options.Microsoft$Extensions$Options$IOptions$$$Value;
                return this;
            }
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    var $en3 = $.$sl.System.Linq.Enumerable.OfType($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, context.Requirements).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var handler = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            await handler.Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync(context).ConfigureAwait(false);
                            if (!this._options.InvokeHandlersAfterFailure && context.HasFailed)
                            {
                                break;
                            }
                        }
                    }
                });
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            static $h = 2284172;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"context","p":514700}],"n":"HandleAsync","d":2284172,"h":17182153356,"f":16781313}],"l":[{"t":645772,"n":"_options","d":2284172,"h":4297251468,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":2284172,"h":8592218764,"f":16777217},{"p":[{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h}],"n":".ctor","o":"$ctor$2","d":2284172,"h":12887186060,"f":16777217}],"i":[1497740],"h":2284172}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler ]; }
            static get $fullName() { return `PassThroughAuthorizationHandler`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement", ($self) => class AssertionRequirement extends $.$$.System.Object
        {
            /*Func<AuthorizationHandlerContext, Task<bool>>*/ Handler = null;
            $ctor$1(/*Func<AuthorizationHandlerContext, bool>*/ handler)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = new ($.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)))().$ctor(this,  (/*context*/ context) =>
                    {
                        return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Boolean, handler.Invoke(context));
                    }, {"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,"p":[{"n":"context","p":514700}],"n":"","d":1956492,"h":0,"f":17825794});
                }
                return this;
            }
            $ctor$2(/*Func<AuthorizationHandlerContext, Task<bool>>*/ handler)
            {
                super.$ctor();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(handler, "handler");
                    this.Handler = handler;
                }
                return this;
            }
            /*Task *//*async*/  HandleAsync(/*AuthorizationHandlerContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (await this.Handler.Invoke(context).ConfigureAwait$2(false))
                    {
                        context.Succeed(this);
                    }
                });
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"Handler"} assertion should evaluate to true.`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement.ToString.apply(this, arguments); }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationHandler.HandleAsync(Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext)
            Microsoft$AspNetCore$Authorization$IAuthorizationHandler$HandleAsync()
            {
                return this.HandleAsync(...arguments);
            }
            static $h = 1956492;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)).$h,"g":{"r":0,"d":0,"h":12886858380,"f":50331649},"n":"Handler","d":1956492,"h":8591891084,"f":2097153}],"m":[{"r":133169153,"p":[{"n":"context","p":514700}],"n":"HandleAsync","d":1956492,"h":25771760268,"f":16781313},{"r":1310721,"n":"ToString","d":1956492,"h":30066727564,"f":16809985}],"c":[{"p":[{"n":"handler","p":$.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Boolean).$h}],"n":".ctor","o":"$ctor$1","d":1956492,"h":17181825676,"f":16777217},{"p":[{"n":"handler","p":$.$$.System.Func$$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandlerContext, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)).$h}],"n":".ctor","o":"$ctor$2","d":1956492,"h":21476792972,"f":16777217}],"i":[1497740,1759884],"h":1956492}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `AssertionRequirement`; }
        });
        
        $asm.$cls("$maa.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    this.ParameterName = parameterName;
                }
                return this;
            }
            /*string*/ ParameterName = null;
            static $h = 2742924;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182612108,"f":50331649},"n":"ParameterName","d":2742924,"h":12887644812,"f":2097153}],"c":[{"p":[{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$2","d":2742924,"h":4297710220,"f":16777217}],"h":2742924,"a":[{"t":14745601,"c":21489582081,"a":[{"v":2048,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute", ($self) => class AllowAnonymousAttribute extends $.$$.System.Attribute
        {
            static/*conventional*/ /*string */ ToString()
            {
                return "AllowAnonymous";
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute.ToString.apply(this, arguments); }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 121484;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"m":[{"r":1310721,"n":"ToString","d":121484,"h":4295088780,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$2","d":121484,"h":8590056076,"f":16777217}],"i":[125155],"h":121484,"a":[{"t":14745601,"c":21489582081,"a":[{"v":68,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":37617665,"c":8627552257,"a":[{"v":"{ToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous ]; }
            static get $fullName() { return `AllowAnonymousAttribute`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.AuthorizeAttribute", ($self) => class AuthorizeAttribute extends $.$$.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ policy)
            {
                super.$ctor$1();
                {
                    this.Policy = policy;
                }
                return this;
            }
            /*string?*/ Policy = null;
            /*string?*/ Roles = null;
            /*string?*/ AuthenticationSchemes = null;
            static/*conventional*/ /*string */ ToString()
            {
                return $.$maa.Microsoft.AspNetCore.Shared.DebuggerHelpers.GetDebugText$3("Policy", this.Policy, "Roles", this.Roles, "AuthenticationSchemes", this.AuthenticationSchemes, false, "Authorize");
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizeAttribute.ToString.apply(this, arguments); }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy()
            {
                return this.Policy;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy(value)
            {
                this.Policy = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles()
            {
                return this.Roles;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles(value)
            {
                this.Roles = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes()
            {
                return this.AuthenticationSchemes;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes(value)
            {
                this.AuthenticationSchemes = value;
            }
            static $h = 973452;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475809932,"f":50331649},"s":{"r":0,"d":0,"h":25770777228,"f":83886081},"n":"Policy","d":973452,"h":17180842636,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":38655679116,"f":50331649},"s":{"r":0,"d":0,"h":42950646412,"f":83886081},"n":"Roles","d":973452,"h":34360711820,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55835548300,"f":50331649},"s":{"r":0,"d":0,"h":60130515596,"f":83886081},"n":"AuthenticationSchemes","d":973452,"h":51540581004,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":973452,"h":64425482892,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$2","d":973452,"h":4295940748,"f":16777217},{"p":[{"n":"policy","p":1310721}],"n":".ctor","o":"$ctor$3","d":973452,"h":8590908044,"f":16777217}],"i":[190691],"h":973452,"a":[{"t":14745601,"c":21489582081,"a":[{"v":68,"t":14680065}],"n":[{"n":"AllowMultiple","v":true,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":37617665,"c":8627552257,"a":[{"v":"{ToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData ]; }
            static get $fullName() { return `AuthorizeAttribute`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement", ($self) => class NameAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            $ctor$2(/*string*/ requiredName)
            {
                super.$ctor$1();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(requiredName, "requiredName");
                    this.RequiredName = requiredName;
                }
                return this;
            }
            /*string*/ RequiredName = null;
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*NameAuthorizationRequirement*/ requirement)
            {
                if (context.User !== null)
                {
                    /*var*/ let succeed = false;
                    var $en3 = context.User.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var identity = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.Equals$2(identity.Name, requirement.RequiredName, 4/*StringComparison.Ordinal*/))
                            {
                                succeed = true;
                                break;
                            }
                        }
                    }
                    if (succeed)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"NameAuthorizationRequirement"}:Requires a user identity with Name equal to ${this.RequiredName}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement.ToString.apply(this, arguments); }
            static $h = 2153100;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182022284,"f":50331649},"n":"RequiredName","d":2153100,"h":12887054988,"f":2097153}],"m":[{"r":133169153,"p":[{"n":"context","p":514700},{"n":"requirement","p":2153100}],"n":"HandleRequirementAsync","d":2153100,"h":21476989580,"f":16809988},{"r":1310721,"n":"ToString","d":2153100,"h":25771956876,"f":16809985}],"c":[{"p":[{"n":"requiredName","p":1310721}],"n":".ctor","o":"$ctor$2","d":2153100,"h":4297120396,"f":16777217}],"i":[1497740,1759884],"h":2153100}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.NameAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `NameAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement", ($self) => class ClaimsAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            /*bool*/ _emptyAllowedValues = false;
            $ctor$2(/*string*/ claimType, /*IEnumerable<string>?*/ allowedValues)
            {
                super.$ctor$1();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(claimType, "claimType");
                    this.ClaimType = claimType;
                    this.AllowedValues = allowedValues;
                    this._emptyAllowedValues = this.AllowedValues === null || !$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, this.AllowedValues);
                }
                return this;
            }
            /*string*/ ClaimType = null;
            /*IEnumerable<string>?*/ AllowedValues = null;
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*ClaimsAuthorizationRequirement*/ requirement)
            {
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    if (requirement._emptyAllowedValues)
                    {
                        var $en4 = context.User.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$$.System.String.Equals$2(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    else 
                    {
                        var $en4 = context.User.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$$.System.String.Equals$2(claim.Type, requirement.ClaimType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$sl.System.Linq.Enumerable.Contains($.$$.System.String, requirement.AllowedValues, claim.Value, $.$$.System.StringComparer.Ordinal))
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let value = (this._emptyAllowedValues) ? $.$$.System.String.Empty : ` and Claim.Value is one of the following values: (${$.$$.System.String.Join$5("|", this.AllowedValues)})`;
                return `${"ClaimsAuthorizationRequirement"}:Claim.Type=${this.ClaimType}${value}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement.ToString.apply(this, arguments); }
            static $h = 2022028;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476858508,"f":50331649},"n":"ClaimType","d":2022028,"h":17181891212,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":34361760396,"f":50331649},"n":"AllowedValues","d":2022028,"h":30066793100,"f":2097153}],"m":[{"r":133169153,"p":[{"n":"context","p":514700},{"n":"requirement","p":2022028}],"n":"HandleRequirementAsync","d":2022028,"h":38656727692,"f":16809988},{"r":1310721,"n":"ToString","d":2022028,"h":42951694988,"f":16809985}],"l":[{"t":262145,"n":"_emptyAllowedValues","d":2022028,"h":4296989324,"f":4194306}],"c":[{"p":[{"n":"claimType","p":1310721},{"n":"allowedValues","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":".ctor","o":"$ctor$2","d":2022028,"h":8591956620,"f":16777217}],"i":[1497740,1759884],"h":2022028}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.ClaimsAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `ClaimsAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement", ($self) => class DenyAnonymousAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*DenyAnonymousAuthorizationRequirement*/ requirement)
            {
                /*var*/ let user = context.User;
                /*var*/ let userIsAnonymous = (user?.Identity ?? null) === null || !$.$sl.System.Linq.Enumerable.Any($.$ssc.System.Security.Claims.ClaimsIdentity, user.Identities, new ($.$$.System.Func$$$($.$ssc.System.Security.Claims.ClaimsIdentity, $.$$.System.Boolean))().$ctor(this,  (/**/ i) =>
                {
                    return i.IsAuthenticated;
                }, {"r":262145,"p":[{"n":"i","p":295390}],"n":"","d":2087564,"h":0,"f":17825794}));
                if (!userIsAnonymous)
                {
                    context.Succeed(requirement);
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"DenyAnonymousAuthorizationRequirement"}: Requires an authenticated user.`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement.ToString.apply(this, arguments); }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2087564;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133169153,"p":[{"n":"context","p":514700},{"n":"requirement","p":2087564}],"n":"HandleRequirementAsync","d":2087564,"h":4297054860,"f":16809988},{"r":1310721,"n":"ToString","d":2087564,"h":8592022156,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$2","d":2087564,"h":12886989452,"f":16777217}],"i":[1497740,1759884],"h":2087564}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.DenyAnonymousAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `DenyAnonymousAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement", ($self) => class RolesAuthorizationRequirement extends $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($self)
        {
            $ctor$2(/*IEnumerable<string>*/ allowedRoles)
            {
                super.$ctor$1();
                {
                    $.$maa.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(allowedRoles, "allowedRoles");
                    if (!$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, allowedRoles))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$maa.Resources.Exception_RoleRequirementEmpty);
                    }
                    this.AllowedRoles = allowedRoles;
                }
                return this;
            }
            /*IEnumerable<string>*/ AllowedRoles = null;
            /*Task */ HandleRequirementAsync(/*AuthorizationHandlerContext*/ context, /*RolesAuthorizationRequirement*/ requirement)
            {
                if (context.User !== null)
                {
                    /*var*/ let found = false;
                    var $en3 = requirement.AllowedRoles.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var role = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (context.User.IsInRole(role))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    if (found)
                    {
                        context.Succeed(requirement);
                    }
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*var*/ let roles = `User.IsInRole must be true for one of the following roles: (${$.$$.System.String.Join$5("|", this.AllowedRoles)})`;
                return `${"RolesAuthorizationRequirement"}:${roles}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement.ToString.apply(this, arguments); }
            static $h = 2349708;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":17182218892,"f":50331649},"n":"AllowedRoles","d":2349708,"h":12887251596,"f":2097153}],"m":[{"r":133169153,"p":[{"n":"context","p":514700},{"n":"requirement","p":2349708}],"n":"HandleRequirementAsync","d":2349708,"h":21477186188,"f":16809988},{"r":1310721,"n":"ToString","d":2349708,"h":25772153484,"f":16809985}],"c":[{"p":[{"n":"allowedRoles","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":".ctor","o":"$ctor$2","d":2349708,"h":4297317004,"f":16777217}],"i":[1497740,1759884],"h":2349708}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationHandler$$($.$maa.Microsoft.AspNetCore.Authorization.Infrastructure.RolesAuthorizationRequirement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationHandler, $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement ]; }
            static get $fullName() { return `RolesAuthorizationRequirement`; }
        });
        
        $asm.$cls("$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationServiceImpl", ($self) => class DefaultAuthorizationServiceImpl extends $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService
        {
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        result = await super.AuthorizeAsync(user, resource, requirements).ConfigureAwait$2(false);
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, null, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, null, result, null);
                    return result;
                });
            }
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult), $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult, async () => 
                {
                    /*AuthorizationResult*/ let result;
                    try
                    {
                        /*var*/ let policy = await this.GetPolicyAsync(policyName).ConfigureAwait$2(false);
                        result = await super.AuthorizeAsync(user, resource, policy.Requirements).ConfigureAwait$2(false);
                    }
                    catch(ex)
                    {
                        this.metrics.AuthorizeAttemptCompleted(user, policyName, null, ex);
                        throw ex;
                    }
                    this.metrics.AuthorizeAttemptCompleted(user, policyName, result, null);
                    return result;
                });
            }
            //Begin primary constructor
            /*IAuthorizationPolicyProvider*/ policyProvider = null;
            /*IAuthorizationHandlerProvider*/ handlers = null;
            /*ILogger<DefaultAuthorizationService>*/ logger = null;
            /*IAuthorizationHandlerContextFactory*/ contextFactory = null;
            /*IAuthorizationEvaluator*/ evaluator = null;
            /*IOptions<AuthorizationOptions>*/ options = null;
            /*AuthorizationMetrics*/ metrics = null;
            $ctor$2(/*IAuthorizationPolicyProvider*/$policyProvider, /*IAuthorizationHandlerProvider*/$handlers, /*ILogger<DefaultAuthorizationService>*/$logger, /*IAuthorizationHandlerContextFactory*/$contextFactory, /*IAuthorizationEvaluator*/$evaluator, /*IOptions<AuthorizationOptions>*/$options, /*AuthorizationMetrics*/$metrics)
            {
                this.policyProvider = $policyProvider;
                this.handlers = $handlers;
                this.logger = $logger;
                this.contextFactory = $contextFactory;
                this.evaluator = $evaluator;
                this.options = $options;
                this.metrics = $metrics;
                return this
            }
            //End primary constructor
            static $h = 1366668;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1301132,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"requirements","p":$.$$.System.Collections.Generic.IEnumerable$$($.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationRequirement).$h}],"n":"AuthorizeAsync","d":1366668,"h":12886268556,"f":16814081},{"r":$.$$.System.Threading.Tasks.Task$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationResult).$h,"p":[{"n":"user","p":426462},{"n":"resource","p":131073},{"n":"policyName","p":1310721}],"n":"AuthorizeAsync","o":"@$1","d":1366668,"h":17181235852,"f":16814081}],"l":[{"t":580236,"n":"\u003Cmetrics\u003EP","d":1366668,"h":8591301260,"f":4194306}],"c":[{"p":[{"n":"policyProvider","p":1694348},{"n":"handlers","p":1628812},{"n":"logger","p":$.$mela.Microsoft.Extensions.Logging.ILogger$$($.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService).$h},{"n":"contextFactory","p":1563276},{"n":"evaluator","p":1432204},{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$maa.Microsoft.AspNetCore.Authorization.AuthorizationOptions).$h},{"n":"metrics","p":580236}],"n":".ctor","o":"$ctor$2","d":1366668,"h":4296333964,"f":16777217}],"i":[1890956],"h":1366668}; }
            static get $b() { return $.$maa.Microsoft.AspNetCore.Authorization.DefaultAuthorizationService; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.Microsoft.AspNetCore.Authorization.IAuthorizationService ]; }
            static get $fullName() { return `DefaultAuthorizationServiceImpl`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions"))