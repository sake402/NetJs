
//--TRIMMABLE-BOUNDARY-START(114)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mexla, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mam, $maa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Authorization", 
    {
  "h": 114,
  "f": "Microsoft.AspNetCore.Components.Authorization",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Authentication and authorization support for Blazor applications.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 115736577,
      "c": 8705671169,
      "a": [
        {
          "v": 917618,
          "t": 187760641
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(852082)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.IHostEnvironmentAuthenticationStateProvider", ($self) => class IHostEnvironmentAuthenticationStateProvider
        {
            static $h = 852082;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295819378),
    {
      "r": 65537,
      "p": [
        {
          "n": "authenticationStateTask",
          "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h
        }
      ],
      "n": "SetAuthenticationState",
      "o": "Microsoft$AspNetCore$Components$Authorization$IHostEnvironmentAuthenticationStateProvider$SetAuthenticationState",
      "d": 852082,
      "h": 4295819378,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295819378)
  ],
  "h": 852082
}; }
            static get $fullName() { return `IHostEnvironmentAuthenticationStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852082)
        
        
        //--TRIMMABLE-BOUNDARY-START(327794)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider", ($self) => class AuthenticationStateProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180196978)
            /*AuthenticationStateChangedHandler?*/ AuthenticationStateChanged = null;
            //--TRIMMABLE-BOUNDARY-END(17180196978)
            
            //--TRIMMABLE-BOUNDARY-START(17180196978)
            //--TRIMMABLE-BOUNDARY-START(12885229682)
            add_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                this.AuthenticationStateChanged = $.$$.System.Delegate.Combine(this.AuthenticationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229682)
            
            //--TRIMMABLE-BOUNDARY-START(34360066162)
            remove_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                this.AuthenticationStateChanged = $.$$.System.Delegate.Remove(this.AuthenticationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066162)
            
            //--TRIMMABLE-BOUNDARY-END(17180196978)
            
            //--TRIMMABLE-BOUNDARY-START(25770131570)
            /*void */ NotifyAuthenticationStateChanged(/*Task<AuthenticationState>*/ task)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(task, "task");
                this.AuthenticationStateChanged?.Invoke(task);
            }
            //--TRIMMABLE-BOUNDARY-END(25770131570)
            
            //--TRIMMABLE-BOUNDARY-START(4295295090)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295090)
            
            static $h = 327794;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475164274),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "n": "GetAuthenticationStateAsync",
      "d": 327794,
      "h": 21475164274,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475164274),
//--TRIMMABLE-BOUNDARY-START(25770131570),
    {
      "r": 65537,
      "p": [
        {
          "n": "task",
          "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h
        }
      ],
      "n": "NotifyAuthenticationStateChanged",
      "d": 327794,
      "h": 25770131570,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25770131570)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295090),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327794,
      "h": 4295295090,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295295090)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(17180196978),
    {
      "e": 196722,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196722
          }
        ],
        "n": "add_AuthenticationStateChanged",
        "d": 327794,
        "h": 12885229682,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196722
          }
        ],
        "n": "remove_AuthenticationStateChanged",
        "d": 327794,
        "h": 34360066162,
        "f": 285212673
      },
      "n": "AuthenticationStateChanged",
      "d": 327794,
      "h": 17180196978,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(17180196978)
  ],
  "h": 327794
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthenticationStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327794)
        
        
        //--TRIMMABLE-BOUNDARY-START(655474)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore", ($self) => class AuthorizeViewCore extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(73015099506)
            /*AuthenticationState?*/ currentAuthenticationState = null;
            //--TRIMMABLE-BOUNDARY-END(73015099506)
            
            //--TRIMMABLE-BOUNDARY-START(154619478130)
            /*bool?*/ isAuthorized = null;
            //--TRIMMABLE-BOUNDARY-END(154619478130)
            
            //--TRIMMABLE-BOUNDARY-START(68720132210)
            /*RenderFragment<AuthenticationState>?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(68720132210)
            
            //--TRIMMABLE-BOUNDARY-START(163209412722)
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            //--TRIMMABLE-BOUNDARY-END(163209412722)
            
            //--TRIMMABLE-BOUNDARY-START(55835230322)
            /*RenderFragment<AuthenticationState>?*/ Authorized = null;
            //--TRIMMABLE-BOUNDARY-END(55835230322)
            
            //--TRIMMABLE-BOUNDARY-START(60130197618)
            /*RenderFragment?*/ Authorizing = null;
            //--TRIMMABLE-BOUNDARY-END(60130197618)
            
            //--TRIMMABLE-BOUNDARY-START(171799347314)
            /*object?*/ Resource = null;
            //--TRIMMABLE-BOUNDARY-END(171799347314)
            
            //--TRIMMABLE-BOUNDARY-START(42950328434)
            /*Task<AuthenticationState>?*/ AuthenticationState = null;
            //--TRIMMABLE-BOUNDARY-END(42950328434)
            
            //--TRIMMABLE-BOUNDARY-START(47245295730)
            /*IAuthorizationPolicyProvider*/ AuthorizationPolicyProvider = null;
            //--TRIMMABLE-BOUNDARY-END(47245295730)
            
            //--TRIMMABLE-BOUNDARY-START(51540263026)
            /*IAuthorizationService*/ AuthorizationService = null;
            //--TRIMMABLE-BOUNDARY-END(51540263026)
            
            //--TRIMMABLE-BOUNDARY-START(64425164914)
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425164914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.isAuthorized === null)
                {
                    builder.AddContent$4(0, this.Authorizing);
                }
                else if (this.isAuthorized === true)
                {
                    /*var*/ let authorized = this.Authorized ?? this.ChildContent;
                    builder.AddContent$4(0, (authorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
                else 
                {
                    builder.AddContent$4(0, (this.NotAuthorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425164914)
            
            //--TRIMMABLE-BOUNDARY-START(167504380018)
            /*Task *//*async*/  OnParametersSetAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504380018);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ChildContent !== null && this.Authorized !== null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Do not specify both '${"Authorized"}' and '${"ChildContent"}'.`);
                    }
                    if (this.AuthenticationState === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Authorization requires a cascading parameter of type Task<${"AuthenticationState"}>. Consider using ${$.$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState.$type.Name} to supply this.`);
                    }
                    this.isAuthorized = null;
                    this.currentAuthenticationState = await this.AuthenticationState;
                    this.isAuthorized = await this.IsAuthorizedAsync(this.currentAuthenticationState.User);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504380018)
            
            //--TRIMMABLE-BOUNDARY-START(158914445426)
            /*Task<bool> *//*async*/  IsAuthorizedAsync(/*ClaimsPrincipal*/ user)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914445426);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let authorizeData = this.GetAuthorizeData();
                    if (authorizeData === null)
                    {
                        return true;
                    }
                    $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore.EnsureNoAuthenticationSchemeSpecified(authorizeData);
                    /*var*/ let policy = await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.CombineAsync$1(this.AuthorizationPolicyProvider, authorizeData);
                    /*var*/ let result = await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync(this.AuthorizationService, user, this.Resource, policy);
                    return result.Succeeded;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914445426)
            
            //--TRIMMABLE-BOUNDARY-START(77310066802)
            static /*void */ EnsureNoAuthenticationSchemeSpecified(/*IAuthorizeData[]*/ authorizeData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310066802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < authorizeData.length; i++)
                {
                    /*var*/ let entry = $.$$.System.Array.$ReadT1.call(authorizeData, i);
                    if (!$.$$.System.String.IsNullOrEmpty(entry.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes))
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(`The authorization data specifies an authentication scheme with value '${entry.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes}'. Authentication schemes cannot be specified for components.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310066802)
            
            //--TRIMMABLE-BOUNDARY-START(38655361138)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655361138)
            
            //default member initializer
            constructor()
            {
                super();
                this.AuthorizationPolicyProvider = null;
                this.AuthorizationService = null;
            }
            static $h = 655474;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720132210),
    {
      "p": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849674354,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338954866,
        "f": 83886081
      },
      "n": "ChildContent",
      "d": 655474,
      "h": 68720132210,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720132210),
//--TRIMMABLE-BOUNDARY-START(163209412722),
    {
      "p": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439608946,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928889458,
        "f": 83886081
      },
      "n": "NotAuthorized",
      "d": 655474,
      "h": 163209412722,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209412722),
//--TRIMMABLE-BOUNDARY-START(55835230322),
    {
      "p": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669805170,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159085682,
        "f": 83886081
      },
      "n": "Authorized",
      "d": 655474,
      "h": 55835230322,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835230322),
//--TRIMMABLE-BOUNDARY-START(60130197618),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259739762,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749020274,
        "f": 83886081
      },
      "n": "Authorizing",
      "d": 655474,
      "h": 60130197618,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130197618),
//--TRIMMABLE-BOUNDARY-START(171799347314),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029543538,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518824050,
        "f": 83886081
      },
      "n": "Resource",
      "d": 655474,
      "h": 171799347314,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799347314),
//--TRIMMABLE-BOUNDARY-START(42950328434),
    {
      "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001394,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389281906,
        "f": 83886082
      },
      "n": "AuthenticationState",
      "d": 655474,
      "h": 42950328434,
      "f": 2097154,
      "a": [
        {
          "t": 524396,
          "c": 8590458988
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950328434),
//--TRIMMABLE-BOUNDARY-START(47245295730),
    {
      "p": 1638505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935986,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979216498,
        "f": 83886082
      },
      "n": "AuthorizationPolicyProvider",
      "d": 655474,
      "h": 47245295730,
      "f": 2097154,
      "a": [
        {
          "t": 4259948,
          "c": 8594194540
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245295730),
//--TRIMMABLE-BOUNDARY-START(51540263026),
    {
      "p": 1835113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079870578,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569151090,
        "f": 83886082
      },
      "n": "AuthorizationService",
      "d": 655474,
      "h": 51540263026,
      "f": 2097154,
      "a": [
        {
          "t": 4259948,
          "c": 8594194540
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540263026)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425164914),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        }
      ],
      "n": "BuildRenderTree",
      "d": 655474,
      "h": 64425164914,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64425164914),
//--TRIMMABLE-BOUNDARY-START(167504380018),
    {
      "r": 177668097,
      "n": "OnParametersSetAsync",
      "d": 655474,
      "h": 167504380018,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(167504380018),
//--TRIMMABLE-BOUNDARY-START(150324510834),
    {
      "r": $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,
      "n": "GetAuthorizeData",
      "d": 655474,
      "h": 150324510834,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(150324510834),
//--TRIMMABLE-BOUNDARY-START(158914445426),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        }
      ],
      "n": "IsAuthorizedAsync",
      "d": 655474,
      "h": 158914445426,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(158914445426),
//--TRIMMABLE-BOUNDARY-START(77310066802),
    {
      "r": 65537,
      "p": [
        {
          "n": "authorizeData",
          "p": $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h
        }
      ],
      "n": "EnsureNoAuthenticationSchemeSpecified",
      "d": 655474,
      "h": 77310066802,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77310066802)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015099506),
    {
      "t": 131186,
      "n": "currentAuthenticationState",
      "d": 655474,
      "h": 73015099506,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015099506),
//--TRIMMABLE-BOUNDARY-START(154619478130),
    {
      "t": $.$typeNullable($.$$.System.Boolean).$h,
      "n": "isAuthorized",
      "d": 655474,
      "h": 154619478130,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154619478130)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655361138),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655474,
      "h": 38655361138,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38655361138)
  ],
  "i": [2752620,3145836,3080300
  ],
  "h": 655474
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `AuthorizeViewCore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655474)
        
        
        //--TRIMMABLE-BOUNDARY-START(262258)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateData", ($self) => class AuthenticationStateData extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475098738)
            /*IList<ClaimData>*/ Claims = null;
            //--TRIMMABLE-BOUNDARY-END(21475098738)
            
            //--TRIMMABLE-BOUNDARY-START(51539869810)
            /*string*/ NameClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(51539869810)
            
            //--TRIMMABLE-BOUNDARY-START(55834837106)
            /*string*/ RoleClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(55834837106)
            
            //--TRIMMABLE-BOUNDARY-START(17180131442)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131442)
            
            //default member initializer
            constructor()
            {
                super();
                this.Claims = (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData))().$ctor$1();
                    return $t1;
                })();
                this.NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                this.RoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            }
            static $h = 262258;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475098738),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033330,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771698,
        "f": 83886081
      },
      "n": "Claims",
      "d": 262258,
      "h": 21475098738,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098738),
//--TRIMMABLE-BOUNDARY-START(51539869810),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967922,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014706290,
        "f": 83886081
      },
      "n": "NameClaimType",
      "d": 262258,
      "h": 51539869810,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539869810),
//--TRIMMABLE-BOUNDARY-START(55834837106),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902514,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604640882,
        "f": 83886081
      },
      "n": "RoleClaimType",
      "d": 262258,
      "h": 55834837106,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837106)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131442),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262258,
      "h": 17180131442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131442)
  ],
  "h": 262258
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthenticationStateData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262258)
        
        
        //--TRIMMABLE-BOUNDARY-START(917618)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager", ($self) => class HotReloadManager extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770721394)
            /*HotReloadManager*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(25770721394)
            
            //--TRIMMABLE-BOUNDARY-START(51540525170)
            /*bool*/ MetadataUpdateSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51540525170)
            
            //--TRIMMABLE-BOUNDARY-START(47245557874)
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245557874)
            
            //--TRIMMABLE-BOUNDARY-START(55835492466)
            /*Action?*/ OnDeltaApplied = null;
            //--TRIMMABLE-BOUNDARY-END(55835492466)
            
            //--TRIMMABLE-BOUNDARY-START(55835492466)
            //--TRIMMABLE-BOUNDARY-START(21475754098)
            add_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Combine(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475754098)
            
            //--TRIMMABLE-BOUNDARY-START(64425427058)
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Remove(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425427058)
            
            //--TRIMMABLE-BOUNDARY-END(55835492466)
            
            //--TRIMMABLE-BOUNDARY-START(81605296242)
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605296242);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605296242)
            
            //--TRIMMABLE-BOUNDARY-START(77310328946)
            /*void */ TriggerOnDeltaApplied()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310328946);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310328946)
            
            //--TRIMMABLE-BOUNDARY-START(12885819506)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819506)
            
            //default member initializer
            constructor()
            {
                super();
                this.MetadataUpdateSupported = $.$$.System.Reflection.Metadata.MetadataUpdater.IsSupported;
            }
            //--TRIMMABLE-BOUNDARY-START(8590852210)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770721394)
                    this.Default = new $.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770721394)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590852210)
            
            static $h = 917618;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540525170),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590578,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015361650,
        "f": 83886081
      },
      "n": "MetadataUpdateSupported",
      "d": 917618,
      "h": 51540525170,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540525170),
//--TRIMMABLE-BOUNDARY-START(47245557874),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655986,
        "f": 50331649
      },
      "n": "IsSubscribedTo",
      "d": 917618,
      "h": 47245557874,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245557874)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605296242),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "UpdateApplication",
      "d": 917618,
      "h": 81605296242,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605296242),
//--TRIMMABLE-BOUNDARY-START(77310328946),
    {
      "r": 65537,
      "n": "TriggerOnDeltaApplied",
      "d": 917618,
      "h": 77310328946,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310328946)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770721394),
    {
      "t": 917618,
      "n": "Default",
      "d": 917618,
      "h": 25770721394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770721394)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819506),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917618,
      "h": 12885819506,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819506)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55835492466),
    {
      "e": 42401793,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42401793
          }
        ],
        "n": "add_OnDeltaApplied",
        "d": 917618,
        "h": 21475754098,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42401793
          }
        ],
        "n": "remove_OnDeltaApplied",
        "d": 917618,
        "h": 64425427058,
        "f": 285212673
      },
      "n": "OnDeltaApplied",
      "d": 917618,
      "h": 55835492466,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835492466)
  ],
  "h": 917618
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HotReloadManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917618)
        
        
        //--TRIMMABLE-BOUNDARY-START(131186)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState", ($self) => class AuthenticationState extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590065778)
            $ctor$1(/*ClaimsPrincipal*/ user)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065778);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(user, "user");
                    this.User = user;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065778)
            
            //--TRIMMABLE-BOUNDARY-START(21474967666)
            /*ClaimsPrincipal*/ User = null;
            //--TRIMMABLE-BOUNDARY-END(21474967666)
            
            static $h = 131186;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967666),
    {
      "p": 393285,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000370,
        "f": 50331649
      },
      "n": "User",
      "d": 131186,
      "h": 21474967666,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474967666)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065778),
    {
      "p": [
        {
          "n": "user",
          "p": 393285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131186,
      "h": 8590065778,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065778)
  ],
  "h": 131186
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthenticationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131186)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048690)
        $asm.$cls("$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions", ($self) => class CascadingAuthenticationStateServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590983282)
            static /*IServiceCollection */ AddCascadingAuthenticationState(/*this IServiceCollection*/ serviceCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mac.Microsoft.Extensions.DependencyInjection.CascadingValueServiceCollectionExtensions.AddCascadingValue($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState), serviceCollection, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))))().$ctor(this,  (/*services*/ services) =>
                {
                    /*var*/ let authenticationStateProvider = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider, services);
                    return new $.$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource().$ctor$6(authenticationStateProvider);
                }, {
  "r": $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)).$h,
  "p": [
    {
      "n": "services",
      "p": 327718
    }
  ],
  "n": "",
  "d": 1048690,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590983282)
            
            //--TRIMMABLE-BOUNDARY-START(1114226)
            static $_AuthenticationStateCascadingValueSource;
            static get AuthenticationStateCascadingValueSource()
            {
                let $cls = $.$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions;
                return $cls.$_AuthenticationStateCascadingValueSource ??= $asm.$ncls("$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource", ($self) => class AuthenticationStateCascadingValueSource extends $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))
                {
                    //--TRIMMABLE-BOUNDARY-START(4296081522)
                    /*AuthenticationStateProvider*/ _authenticationStateProvider = null;
                    //--TRIMMABLE-BOUNDARY-END(4296081522)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591048818)
                    $ctor$6(/*AuthenticationStateProvider*/ authenticationStateProvider)
                    {
                        super.$ctor$2(new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)))().$ctor(authenticationStateProvider, authenticationStateProvider.GetAuthenticationStateAsync), false);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591048818);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._authenticationStateProvider = authenticationStateProvider;
                            this._authenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591048818)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180983410)
                    /*void */ HandleAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180983410);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        _ = this.NotifyChangedAsync$1(newAuthStateTask);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180983410)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886016114)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886016114);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._authenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886016114)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    static $h = 1114226;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180983410),
    {
      "r": 65537,
      "p": [
        {
          "n": "newAuthStateTask",
          "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h
        }
      ],
      "n": "HandleAuthenticationStateChanged",
      "d": 1114226,
      "h": 17180983410,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180983410),
//--TRIMMABLE-BOUNDARY-START(12886016114),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1114226,
      "h": 12886016114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016114)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081522),
    {
      "t": 327794,
      "n": "_authenticationStateProvider",
      "d": 1114226,
      "h": 4296081522,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081522)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048818),
    {
      "p": [
        {
          "n": "authenticationStateProvider",
          "p": 327794
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1114226,
      "h": 8591048818,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048818)
  ],
  "i": [2687084,90308609
  ],
  "d": 1048690,
  "h": 1114226
}; }
                    static get $b() { return $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.ICascadingValueSupplier, $.$$.System.IDisposable ]; }
                    static get $fullName() { return `CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource`; }
                }, $cls, ($v) => $cls.$_AuthenticationStateCascadingValueSource = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114226)
            
            static $h = 1048690;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983282),
    {
      "r": 786522,
      "p": [
        {
          "n": "serviceCollection",
          "p": 786522
        }
      ],
      "n": "AddCascadingAuthenticationState",
      "d": 1048690,
      "h": 8590983282,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590983282)
  ],
  "j": [1114226
  ],
  "h": 1048690
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CascadingAuthenticationStateServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048690)
        
        
        //--TRIMMABLE-BOUNDARY-START(65650)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache", ($self) => class AttributeAuthorizeDataCache
        {
            //--TRIMMABLE-BOUNDARY-START(8590000242)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.System.Action().$ctor($.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache, $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000242)
            
            //--TRIMMABLE-BOUNDARY-START(4295032946)
            /*ConcurrentDictionary<Type, IAuthorizeData[]?>*/ static _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4295032946)
            
            //--TRIMMABLE-BOUNDARY-START(12884967538)
            static /*void */ ClearCache()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967538);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967538)
            
            //--TRIMMABLE-BOUNDARY-START(21474902130)
            static /*IAuthorizeData[]? */ GetAuthorizeDataForType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result;
                if (!$.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.TryGetValue(type, $.$ref(() => result, ($v) => result = $v, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData))))
                {
                    result = $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.ComputeAuthorizeDataForType(type);
                    $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.set_Item$1(type, result);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902130)
            
            //--TRIMMABLE-BOUNDARY-START(17179934834)
            static /*IAuthorizeData[]? */ ComputeAuthorizeDataForType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let allAttributes = type.GetCustomAttributes(true);
                /*List<IAuthorizeData>?*/ let authorizeDatas = null;
                for(/*var*/ let i = 0; i < allAttributes.length; i++)
                {
                    if ($.$is($.$$.System.Array.$ReadT1.call(allAttributes, i), $.$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous))
                    {
                        return null;
                    }
                    let authorizeData;
                    if ($.$is($.$$.System.Array.$ReadT1.call(allAttributes, i), $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData, { set $v(v){ authorizeData = v; } }))
                    {
                        authorizeDatas ??= new ($.$$.System.Collections.Generic.List$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData))().$ctor$1();
                        authorizeDatas.Add(authorizeData);
                    }
                }
                return authorizeDatas?.ToArray() ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934834)
            
            //--TRIMMABLE-BOUNDARY-START(8590000242)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032946)
                    this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4295032946)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000242)
            
            static $h = 65650;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884967538),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 65650,
      "h": 12884967538,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12884967538),
//--TRIMMABLE-BOUNDARY-START(21474902130),
    {
      "r": $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetAuthorizeDataForType",
      "d": 65650,
      "h": 21474902130,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474902130),
//--TRIMMABLE-BOUNDARY-START(17179934834),
    {
      "r": $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "ComputeAuthorizeDataForType",
      "d": 65650,
      "h": 17179934834,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17179934834)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032946),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData)).$h,
      "n": "_cache",
      "d": 65650,
      "h": 4295032946,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032946)
  ],
  "h": 65650
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AttributeAuthorizeDataCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65650)
        
        
        //--TRIMMABLE-BOUNDARY-START(393330)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter", ($self) => class AuthorizeDataAdapter extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360626)
            /*AuthorizeView*/ _component = null;
            //--TRIMMABLE-BOUNDARY-END(4295360626)
            
            //--TRIMMABLE-BOUNDARY-START(8590327922)
            $ctor$1(/*AuthorizeView*/ component)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327922);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._component = $.$firstOf(component, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("component") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327922)
            
            //--TRIMMABLE-BOUNDARY-START(42950066290)
            /*string? */ get Policy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._component.Policy;
            }
            /*string? */ set Policy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(42950066290)
            
            //--TRIMMABLE-BOUNDARY-START(47245033586)
            /*string? */ get Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._component.Roles;
            }
            /*string? */ set Roles(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(47245033586)
            
            //--TRIMMABLE-BOUNDARY-START(12885295218)
            /*string? */ get AuthenticationSchemes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            /*string? */ set AuthenticationSchemes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834968178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12885295218)
            
            //--TRIMMABLE-BOUNDARY-START(21474967656)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Policy;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967656)
            
            //--TRIMMABLE-BOUNDARY-START(55834706024)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Policy = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706024)
            
            //--TRIMMABLE-BOUNDARY-START(30064902248)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Roles;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902248)
            
            //--TRIMMABLE-BOUNDARY-START(64424640616)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Roles = value;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640616)
            
            //--TRIMMABLE-BOUNDARY-START(12885033064)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticationSchemes;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033064)
            
            //--TRIMMABLE-BOUNDARY-START(47244771432)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationSchemes = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771432)
            
            static $h = 393330;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950066290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164402,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424902770,
        "f": 83886081
      },
      "n": "Policy",
      "d": 393330,
      "h": 42950066290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950066290),
//--TRIMMABLE-BOUNDARY-START(47245033586),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655098994,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014837362,
        "f": 83886081
      },
      "n": "Roles",
      "d": 393330,
      "h": 47245033586,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245033586),
//--TRIMMABLE-BOUNDARY-START(12885295218),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475229810,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834968178,
        "f": 83886081
      },
      "n": "AuthenticationSchemes",
      "d": 393330,
      "h": 12885295218,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885295218)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360626),
    {
      "t": 589938,
      "n": "_component",
      "d": 393330,
      "h": 4295360626,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360626)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327922),
    {
      "p": [
        {
          "n": "component",
          "p": 589938
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393330,
      "h": 8590327922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327922)
  ],
  "i": [131176
  ],
  "h": 393330
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData ]; }
            static get $fullName() { return `AuthorizeDataAdapter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393330)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179762)
        $asm.$cls("$maca.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296147058)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296147058)
            
            static $h = 1179762;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296147058),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179762,
      "h": 4296147058,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296147058)
  ],
  "h": 1179762,
  "a": [
    {
      "t": 983154,
      "c": 4295950450
    },
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179762)
        
        
        //--TRIMMABLE-BOUNDARY-START(786546)
        $asm.$str("$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData", ($self) => class ClaimData extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180655730)
            $ctor$3(/*string*/ type, /*string*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Type = type;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655730)
            
            //--TRIMMABLE-BOUNDARY-START(21475623026)
            $ctor$4(/*Claim*/ claim)
            {
                this.$ctor$3(claim.Type, claim.Value);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475623026);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623026)
            
            //--TRIMMABLE-BOUNDARY-START(42950459506)
            /*string*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(42950459506)
            
            //--TRIMMABLE-BOUNDARY-START(47245426802)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(47245426802)
            
            //--TRIMMABLE-BOUNDARY-START(12885688434)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688434)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Type = this.Type;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 786546;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950459506),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065557618,
        "f": 50331649
      },
      "n": "Type",
      "d": 786546,
      "h": 42950459506,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950459506),
//--TRIMMABLE-BOUNDARY-START(47245426802),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655492210,
        "f": 50331649
      },
      "n": "Value",
      "d": 786546,
      "h": 47245426802,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245426802)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180655730),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786546,
      "h": 17180655730,
      "f": 16777217,
      "a": [
        {
          "t": 13434964,
          "c": 4308402260
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180655730),
//--TRIMMABLE-BOUNDARY-START(21475623026),
    {
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786546,
      "h": 21475623026,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623026),
//--TRIMMABLE-BOUNDARY-START(12885688434),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786546,
      "h": 12885688434,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688434)
  ],
  "h": 786546
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ClaimData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786546)
        
        
        //--TRIMMABLE-BOUNDARY-START(983154)
        $asm.$cls("$maca.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295950450)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950450)
            
            static $h = 983154;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950450),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983154,
      "h": 4295950450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950450)
  ],
  "h": 983154
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983154)
        
        
        //--TRIMMABLE-BOUNDARY-START(721010)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState", ($self) => class CascadingAuthenticationState extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(25770524786)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.CascadingValue$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)), 0);
                __builder.AddComponentParameter(1, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState), this._currentAuthenticationStateTask));
                __builder.AddComponentParameter(2, "ChildContent", (this.ChildContent));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770524786)
            
            //--TRIMMABLE-BOUNDARY-START(4295688306)
            /*Task<AuthenticationState>?*/ _currentAuthenticationStateTask = null;
            //--TRIMMABLE-BOUNDARY-END(4295688306)
            
            //--TRIMMABLE-BOUNDARY-START(30065492082)
            /*RenderFragment?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(30065492082)
            
            //--TRIMMABLE-BOUNDARY-START(55835295858)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
                this._currentAuthenticationStateTask = this.AuthenticationStateProvider.GetAuthenticationStateAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(55835295858)
            
            //--TRIMMABLE-BOUNDARY-START(51540328562)
            /*void */ OnAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.InvokeAsync(new $.$$.System.Action().$ctor(this,  () =>
                {
                    this._currentAuthenticationStateTask = newAuthStateTask;
                    this.StateHasChanged();
                }, {
  "r": 65537,
  "n": "",
  "d": 721010,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(51540328562)
            
            //--TRIMMABLE-BOUNDARY-START(77310132338)
            /*void */ System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(77310132338)
            
            //--TRIMMABLE-BOUNDARY-START(21475557490)
            /*AuthenticationStateProvider*/ AuthenticationStateProvider = null;
            //--TRIMMABLE-BOUNDARY-END(21475557490)
            
            //--TRIMMABLE-BOUNDARY-START(17180590194)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590194)
            
            //default member initializer
            constructor()
            {
                super();
                this.AuthenticationStateProvider = null;
            }
            static $h = 721010;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065492082),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361266,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015165042,
        "f": 83886081
      },
      "n": "ChildContent",
      "d": 721010,
      "h": 30065492082,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065492082),
//--TRIMMABLE-BOUNDARY-START(21475557490),
    {
      "p": 327794,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426674,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425230450,
        "f": 83886082
      },
      "n": "AuthenticationStateProvider",
      "d": 721010,
      "h": 21475557490,
      "f": 2097154,
      "a": [
        {
          "t": 4259948,
          "c": 8594194540
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475557490)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770524786),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "BuildRenderTree",
      "d": 721010,
      "h": 25770524786,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770524786),
//--TRIMMABLE-BOUNDARY-START(55835295858),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 721010,
      "h": 55835295858,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835295858),
//--TRIMMABLE-BOUNDARY-START(51540328562),
    {
      "r": 65537,
      "p": [
        {
          "n": "newAuthStateTask",
          "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h
        }
      ],
      "n": "OnAuthenticationStateChanged",
      "d": 721010,
      "h": 51540328562,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540328562)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688306),
    {
      "t": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "n": "_currentAuthenticationStateTask",
      "d": 721010,
      "h": 4295688306,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688306)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180590194),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721010,
      "h": 17180590194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590194)
  ],
  "i": [2752620,3145836,3080300,90308609
  ],
  "h": 721010
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721010)
        
        
        //--TRIMMABLE-BOUNDARY-START(196722)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler", ($self) => class AuthenticationStateChangedHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ task)
            {
                return this.$nativeFunction.call(this.$target, task);
            }
            static $h = 196722;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065906),
    {
      "r": 65537,
      "p": [
        {
          "n": "task",
          "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h
        }
      ],
      "n": "Invoke",
      "d": 196722,
      "h": 17180065906,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180065906),
//--TRIMMABLE-BOUNDARY-START(8590131314),
    {
      "r": 89784321,
      "p": [
        {
          "n": "task",
          "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 196722,
      "h": 8590131314,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590131314),
//--TRIMMABLE-BOUNDARY-START(12885098610),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 196722,
      "h": 12885098610,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885098610)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164018),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 196722,
      "h": 4295164018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295164018)
  ],
  "i": [89980929,157483009
  ],
  "h": 196722
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `AuthenticationStateChangedHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196722)
        
        
        //--TRIMMABLE-BOUNDARY-START(589938)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeView", ($self) => class AuthorizeView extends $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore
        {
            //--TRIMMABLE-BOUNDARY-START(47245230194)
            /*IAuthorizeData[]*/ selfAsAuthorizeData = null;
            //--TRIMMABLE-BOUNDARY-END(47245230194)
            
            //--TRIMMABLE-BOUNDARY-START(12885491826)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491826);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.selfAsAuthorizeData = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter), [new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter().$ctor$1(this)], null, null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491826)
            
            //--TRIMMABLE-BOUNDARY-START(38655295602)
            /*string?*/ Policy = null;
            //--TRIMMABLE-BOUNDARY-END(38655295602)
            
            //--TRIMMABLE-BOUNDARY-START(42950262898)
            /*string?*/ Roles = null;
            //--TRIMMABLE-BOUNDARY-END(42950262898)
            
            //--TRIMMABLE-BOUNDARY-START(34360328306)
            /*IAuthorizeData[] */ GetAuthorizeData()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360328306);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.selfAsAuthorizeData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360328306)
            
            static $h = 589938;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 655474,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655295602),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475426418,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835164786,
        "f": 83886081
      },
      "n": "Policy",
      "d": 589938,
      "h": 38655295602,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655295602),
//--TRIMMABLE-BOUNDARY-START(42950262898),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065361010,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425099378,
        "f": 83886081
      },
      "n": "Roles",
      "d": 589938,
      "h": 42950262898,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950262898)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360328306),
    {
      "r": $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,
      "n": "GetAuthorizeData",
      "d": 589938,
      "h": 34360328306,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360328306)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245230194),
    {
      "t": $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,
      "n": "selfAsAuthorizeData",
      "d": 589938,
      "h": 47245230194,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245230194)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491826),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589938,
      "h": 12885491826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491826)
  ],
  "i": [2752620,3145836,3080300
  ],
  "h": 589938
}; }
            static get $b() { return $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `AuthorizeView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589938)
        
        
        //--TRIMMABLE-BOUNDARY-START(458866)
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView", ($self) => class AuthorizeRouteView extends $.$mac.Microsoft.AspNetCore.Components.RouteView
        {
            //--TRIMMABLE-BOUNDARY-START(8590393458)
            /*RenderFragment<AuthenticationState>*/ static _defaultNotAuthorizedContent = null;
            //--TRIMMABLE-BOUNDARY-END(8590393458)
            
            //--TRIMMABLE-BOUNDARY-START(4295426162)
            /*RenderFragment*/ static _defaultAuthorizingContent = null;
            //--TRIMMABLE-BOUNDARY-END(4295426162)
            
            //--TRIMMABLE-BOUNDARY-START(17180328050)
            /*RenderFragment*/ _renderAuthorizeRouteViewCoreDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(17180328050)
            
            //--TRIMMABLE-BOUNDARY-START(12885360754)
            /*RenderFragment<AuthenticationState>*/ _renderAuthorizedDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(12885360754)
            
            //--TRIMMABLE-BOUNDARY-START(25770262642)
            /*RenderFragment<AuthenticationState>*/ _renderNotAuthorizedDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(25770262642)
            
            //--TRIMMABLE-BOUNDARY-START(21475295346)
            /*RenderFragment*/ _renderAuthorizingDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(21475295346)
            
            //--TRIMMABLE-BOUNDARY-START(55835033714)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835033714);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*RenderFragment*/ let renderBaseRouteViewDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, super.Render);
                    this._renderAuthorizedDelegate = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/**/ authenticateState) =>
                    {
                        return renderBaseRouteViewDelegate;
                    }, {
  "r": 6881388,
  "p": [
    {
      "n": "authenticateState",
      "p": 131186
    }
  ],
  "n": "",
  "d": 458866,
  "h": 0,
  "f": 17825794
});
                    this._renderNotAuthorizedDelegate = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/*authenticationState*/ authenticationState) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return this.RenderNotAuthorizedInDefaultLayout(builder, authenticationState);
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 7536748
    }
  ],
  "n": "",
  "d": 458866,
  "h": 0,
  "f": 17825794
});
                    }, {
  "r": 6881388,
  "p": [
    {
      "n": "authenticationState",
      "p": 131186
    }
  ],
  "n": "",
  "d": 458866,
  "h": 0,
  "f": 17825794
});
                    this._renderAuthorizingDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderAuthorizingInDefaultLayout);
                    this._renderAuthorizeRouteViewCoreDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderAuthorizeRouteViewCore);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835033714)
            
            //--TRIMMABLE-BOUNDARY-START(103079673970)
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            //--TRIMMABLE-BOUNDARY-END(103079673970)
            
            //--TRIMMABLE-BOUNDARY-START(60130001010)
            /*RenderFragment?*/ Authorizing = null;
            //--TRIMMABLE-BOUNDARY-END(60130001010)
            
            //--TRIMMABLE-BOUNDARY-START(128849477746)
            /*object?*/ Resource = null;
            //--TRIMMABLE-BOUNDARY-END(128849477746)
            
            //--TRIMMABLE-BOUNDARY-START(64424968306)
            /*Task<AuthenticationState>?*/ ExistingCascadedAuthenticationState = null;
            //--TRIMMABLE-BOUNDARY-END(64424968306)
            
            //--TRIMMABLE-BOUNDARY-START(107374641266)
            /*void */ Render(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ExistingCascadedAuthenticationState !== null)
                {
                    this._renderAuthorizeRouteViewCoreDelegate.Invoke(builder);
                }
                else 
                {
                    builder.OpenComponent$1($.$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState, 0);
                    builder.AddComponentParameter(1, "ChildContent", this._renderAuthorizeRouteViewCoreDelegate);
                    builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374641266)
            
            //--TRIMMABLE-BOUNDARY-START(111669608562)
            /*void */ RenderAuthorizeRouteViewCore(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.OpenComponent$1($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView.AuthorizeRouteViewCore, 0);
                builder.AddComponentParameter(1, "RouteData", this.RouteData);
                builder.AddComponentParameter(2, "Authorized", this._renderAuthorizedDelegate);
                builder.AddComponentParameter(3, "Authorizing", this._renderAuthorizingDelegate);
                builder.AddComponentParameter(4, "NotAuthorized", this._renderNotAuthorizedDelegate);
                builder.AddComponentParameter(5, "Resource", this.Resource);
                builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(111669608562)
            
            //--TRIMMABLE-BOUNDARY-START(120259543154)
            /*void */ RenderContentInDefaultLayout(/*RenderTreeBuilder*/ builder, /*RenderFragment*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.LayoutView, 0);
                builder.AddComponentParameter(1, "Layout", this.DefaultLayout);
                builder.AddComponentParameter(2, "ChildContent", content);
                builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(120259543154)
            
            //--TRIMMABLE-BOUNDARY-START(124554510450)
            /*void */ RenderNotAuthorizedInDefaultLayout(/*RenderTreeBuilder*/ builder, /*AuthenticationState*/ authenticationState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554510450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let content = this.NotAuthorized ?? $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView._defaultNotAuthorizedContent;
                this.RenderContentInDefaultLayout(builder, content.Invoke(authenticationState));
            }
            //--TRIMMABLE-BOUNDARY-END(124554510450)
            
            //--TRIMMABLE-BOUNDARY-START(115964575858)
            /*void */ RenderAuthorizingInDefaultLayout(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let content = this.Authorizing ?? $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView._defaultAuthorizingContent;
                this.RenderContentInDefaultLayout(builder, content);
            }
            //--TRIMMABLE-BOUNDARY-END(115964575858)
            
            //--TRIMMABLE-BOUNDARY-START(524402)
            static $_AuthorizeRouteViewCore;
            static get AuthorizeRouteViewCore()
            {
                let $cls = $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView;
                return $cls.$_AuthorizeRouteViewCore ??= $asm.$ncls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView.AuthorizeRouteViewCore", ($self) => class AuthorizeRouteViewCore extends $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328178)
                    /*RouteData*/ RouteData = null;
                    //--TRIMMABLE-BOUNDARY-END(25770328178)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475360882)
                    /*IAuthorizeData[]? */ GetAuthorizeData()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475360882);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.GetAuthorizeDataForType(this.RouteData.PageType);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475360882)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458994)
                    //default reference type constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590458994)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.RouteData = null;
                    }
                    static $h = 524402;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 655474,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770328178),
    {
      "p": 9961580,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180393586,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360262770,
        "f": 83886081
      },
      "n": "RouteData",
      "d": 524402,
      "h": 25770328178,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770328178)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475360882),
    {
      "r": $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,
      "n": "GetAuthorizeData",
      "d": 524402,
      "h": 21475360882,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475360882)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458994),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524402,
      "h": 8590458994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458994)
  ],
  "i": [2752620,3145836,3080300
  ],
  "d": 458866,
  "h": 524402
}; }
                    static get $b() { return $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
                    static get $fullName() { return `AuthorizeRouteView.AuthorizeRouteViewCore`; }
                }, $cls, ($v) => $cls.$_AuthorizeRouteViewCore = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524402)
            
            //--TRIMMABLE-BOUNDARY-START(51540066418)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393458)
                    this._defaultNotAuthorizedContent = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/**/ state) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return builder.AddContent$2(0, "Not authorized");
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 7536748
    }
  ],
  "n": "",
  "d": 458866,
  "h": 0,
  "f": 17825794
});
                    }, {
  "r": 6881388,
  "p": [
    {
      "n": "state",
      "p": 131186
    }
  ],
  "n": "",
  "d": 458866,
  "h": 0,
  "f": 17825794
});
                    //--TRIMMABLE-BOUNDARY-END(8590393458)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295426162)
                    this._defaultAuthorizingContent = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        return builder.AddContent$2(0, "Authorizing...");
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 7536748
    }
  ],
  "n": "",
  "d": 458866,
  "h": 0,
  "f": 17825794
});
                    //--TRIMMABLE-BOUNDARY-END(4295426162)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540066418)
            
            static $h = 458866;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 10223724,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079673970),
    {
      "p": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194772082,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619281522,
        "f": 83886081
      },
      "n": "NotAuthorized",
      "d": 458866,
      "h": 103079673970,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079673970),
//--TRIMMABLE-BOUNDARY-START(60130001010),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014902898,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439412338,
        "f": 83886081
      },
      "n": "Authorizing",
      "d": 458866,
      "h": 60130001010,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130001010),
//--TRIMMABLE-BOUNDARY-START(128849477746),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784706674,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209216114,
        "f": 83886081
      },
      "n": "Resource",
      "d": 458866,
      "h": 128849477746,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849477746),
//--TRIMMABLE-BOUNDARY-START(64424968306),
    {
      "p": $.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604837490,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029346930,
        "f": 83886082
      },
      "n": "ExistingCascadedAuthenticationState",
      "d": 458866,
      "h": 64424968306,
      "f": 2097154,
      "a": [
        {
          "t": 524396,
          "c": 8590458988
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424968306)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107374641266),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        }
      ],
      "n": "Render",
      "d": 458866,
      "h": 107374641266,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107374641266),
//--TRIMMABLE-BOUNDARY-START(111669608562),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        }
      ],
      "n": "RenderAuthorizeRouteViewCore",
      "d": 458866,
      "h": 111669608562,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111669608562),
//--TRIMMABLE-BOUNDARY-START(120259543154),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        },
        {
          "n": "content",
          "p": 6881388
        }
      ],
      "n": "RenderContentInDefaultLayout",
      "d": 458866,
      "h": 120259543154,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120259543154),
//--TRIMMABLE-BOUNDARY-START(124554510450),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        },
        {
          "n": "authenticationState",
          "p": 131186
        }
      ],
      "n": "RenderNotAuthorizedInDefaultLayout",
      "d": 458866,
      "h": 124554510450,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554510450),
//--TRIMMABLE-BOUNDARY-START(115964575858),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        }
      ],
      "n": "RenderAuthorizingInDefaultLayout",
      "d": 458866,
      "h": 115964575858,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964575858)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393458),
    {
      "t": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "n": "_defaultNotAuthorizedContent",
      "d": 458866,
      "h": 8590393458,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590393458),
//--TRIMMABLE-BOUNDARY-START(4295426162),
    {
      "t": 6881388,
      "n": "_defaultAuthorizingContent",
      "d": 458866,
      "h": 4295426162,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295426162),
//--TRIMMABLE-BOUNDARY-START(17180328050),
    {
      "t": 6881388,
      "n": "_renderAuthorizeRouteViewCoreDelegate",
      "d": 458866,
      "h": 17180328050,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180328050),
//--TRIMMABLE-BOUNDARY-START(12885360754),
    {
      "t": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "n": "_renderAuthorizedDelegate",
      "d": 458866,
      "h": 12885360754,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360754),
//--TRIMMABLE-BOUNDARY-START(25770262642),
    {
      "t": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,
      "n": "_renderNotAuthorizedDelegate",
      "d": 458866,
      "h": 25770262642,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770262642),
//--TRIMMABLE-BOUNDARY-START(21475295346),
    {
      "t": 6881388,
      "n": "_renderAuthorizingDelegate",
      "d": 458866,
      "h": 21475295346,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475295346)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835033714),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458866,
      "h": 55835033714,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835033714)
  ],
  "i": [2752620
  ],
  "j": [524402
  ],
  "h": 458866
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.RouteView; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent ]; }
            static get $fullName() { return `AuthorizeRouteView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458866)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.AspNetCore.Authorization"))
//--TRIMMABLE-BOUNDARY-END(114)
