
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mam, $maa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Authorization", 
    {"h":42086,"f":"Microsoft.AspNetCore.Components.Authorization","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Authentication and authorization support for Blazor applications.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.Authorization","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.Authorization","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":78512129,"c":4373479425,"a":[{"v":959590,"t":142475265}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.IHostEnvironmentAuthenticationStateProvider", ($self) => class IHostEnvironmentAuthenticationStateProvider
        {
            static $h = 894054;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"authenticationStateTask","p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"SetAuthenticationState","o":"Microsoft$AspNetCore$Components$Authorization$IHostEnvironmentAuthenticationStateProvider$SetAuthenticationState","d":894054,"h":4295861350,"f":16777473}],"h":894054}; }
            static get $fullName() { return `IHostEnvironmentAuthenticationStateProvider`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider", ($self) => class AuthenticationStateProvider extends $.$$.System.Object
        {
            /*AuthenticationStateChangedHandler?*/ AuthenticationStateChanged = null;
            add_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                this.AuthenticationStateChanged = $.$$.System.Delegate.Combine(this.AuthenticationStateChanged, value);
            }
            remove_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                this.AuthenticationStateChanged = $.$$.System.Delegate.Remove(this.AuthenticationStateChanged, value);
            }
            /*void */ NotifyAuthenticationStateChanged(/*Task<AuthenticationState>*/ task)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(task, "task");
                this.AuthenticationStateChanged?.Invoke(task);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 369766;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"GetAuthenticationStateAsync","d":369766,"h":4295337062,"f":16777473},{"r":65537,"p":[{"n":"task","p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"NotifyAuthenticationStateChanged","d":369766,"h":21475206246,"f":16777220}],"c":[{"n":".ctor","o":"$ctor$1","d":369766,"h":25770173542,"f":16777220}],"e":[{"e":238694,"m":{"r":65537,"p":[{"n":"value","p":238694}],"n":"add_AuthenticationStateChanged","d":369766,"h":8590304358,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":238694}],"n":"remove_AuthenticationStateChanged","d":369766,"h":12885271654,"f":285212673},"n":"AuthenticationStateChanged","d":369766,"h":17180238950,"f":8388609}],"h":369766}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthenticationStateProvider`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore", ($self) => class AuthorizeViewCore extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*AuthenticationState?*/ currentAuthenticationState = null;
            /*bool?*/ isAuthorized = null;
            /*RenderFragment<AuthenticationState>?*/ ChildContent = null;
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            /*RenderFragment<AuthenticationState>?*/ Authorized = null;
            /*RenderFragment?*/ Authorizing = null;
            /*object?*/ Resource = null;
            /*Task<AuthenticationState>?*/ AuthenticationState = null;
            /*IAuthorizationPolicyProvider*/ AuthorizationPolicyProvider = null;
            /*IAuthorizationService*/ AuthorizationService = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                if (this.isAuthorized === null)
                {
                    builder.AddContent$4(0, this.Authorizing);
                }
                else if (this.isAuthorized === true)
                {
                    /*var*/ let authorized = this.Authorized ?? this.ChildContent;
                    builder.AddContent$4(0, (authorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
                else 
                {
                    builder.AddContent$4(0, (this.NotAuthorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
            }
            /*Task *//*async*/  OnParametersSetAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (this.ChildContent !== null && this.Authorized !== null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Do not specify both '${"Authorized"}' and '${"ChildContent"}'.`);
                    }
                    if (this.AuthenticationState === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Authorization requires a cascading parameter of type Task<${"AuthenticationState"}>. Consider using ${$.$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState.$type.Name} to supply this.`);
                    }
                    this.isAuthorized = null;
                    this.currentAuthenticationState = await this.AuthenticationState;
                    this.isAuthorized = await this.IsAuthorizedAsync(this.currentAuthenticationState.User);
                });
            }
            /*Task<bool> *//*async*/  IsAuthorizedAsync(/*ClaimsPrincipal*/ user)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    /*var*/ let authorizeData = this.GetAuthorizeData();
                    if (authorizeData === null)
                    {
                        return true;
                    }
                    $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore.EnsureNoAuthenticationSchemeSpecified(authorizeData);
                    /*var*/ let policy = await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.CombineAsync$1(this.AuthorizationPolicyProvider, authorizeData);
                    /*var*/ let result = await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync(this.AuthorizationService, user, this.Resource, policy);
                    return result.Succeeded;
                });
            }
            static /*void */ EnsureNoAuthenticationSchemeSpecified(/*IAuthorizeData[]*/ authorizeData)
            {
                for(/*var*/ let i = 0; i < authorizeData.length; i++)
                {
                    /*var*/ let entry = $.$$.System.Array.$ReadT1.call(authorizeData, i);
                    if (!$.$$.System.String.IsNullOrEmpty(entry.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes))
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(`The authorization data specifies an authentication scheme with value '${entry.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes}'. Authentication schemes cannot be specified for components.`);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AuthorizationPolicyProvider = null;
                this.AuthorizationService = null;
            }
            static $h = 697446;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":21475533926,"f":50331649},"s":{"r":0,"d":0,"h":25770501222,"f":83886081},"n":"ChildContent","d":697446,"h":17180566630,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":38655403110,"f":50331649},"s":{"r":0,"d":0,"h":42950370406,"f":83886081},"n":"NotAuthorized","d":697446,"h":34360435814,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":55835272294,"f":50331649},"s":{"r":0,"d":0,"h":60130239590,"f":83886081},"n":"Authorized","d":697446,"h":51540304998,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":6881288,"g":{"r":0,"d":0,"h":73015141478,"f":50331649},"s":{"r":0,"d":0,"h":77310108774,"f":83886081},"n":"Authorizing","d":697446,"h":68720174182,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":131073,"g":{"r":0,"d":0,"h":90195010662,"f":50331649},"s":{"r":0,"d":0,"h":94489977958,"f":83886081},"n":"Resource","d":697446,"h":85900043366,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":107374879846,"f":50331650},"s":{"r":0,"d":0,"h":111669847142,"f":83886082},"n":"AuthenticationState","d":697446,"h":103079912550,"f":2097154,"a":[{"t":524296,"c":21475360776}]},{"p":1694348,"g":{"r":0,"d":0,"h":124554749030,"f":50331650},"s":{"r":0,"d":0,"h":128849716326,"f":83886082},"n":"AuthorizationPolicyProvider","d":697446,"h":120259781734,"f":2097154,"a":[{"t":4259848,"c":21479096328}]},{"p":1890956,"g":{"r":0,"d":0,"h":141734618214,"f":50331650},"s":{"r":0,"d":0,"h":146029585510,"f":83886082},"n":"AuthorizationService","d":697446,"h":137439650918,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":697446,"h":150324552806,"f":16809988},{"r":133169153,"n":"OnParametersSetAsync","d":697446,"h":154619520102,"f":16814084},{"r":$.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,"n":"GetAuthorizeData","d":697446,"h":158914487398,"f":16777476},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,"p":[{"n":"user","p":426462}],"n":"IsAuthorizedAsync","d":697446,"h":163209454694,"f":16781314},{"r":65537,"p":[{"n":"authorizeData","p":$.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h}],"n":"EnsureNoAuthenticationSchemeSpecified","d":697446,"h":167504421990,"f":16777250}],"l":[{"t":173158,"n":"currentAuthenticationState","d":697446,"h":4295664742,"f":4194306},{"t":$.$typeNullable($.$$.System.Boolean).$h,"n":"isAuthorized","d":697446,"h":8590632038,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":697446,"h":171799389286,"f":16777220}],"i":[2752520,3145736,3080200],"h":697446}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `AuthorizeViewCore`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateData", ($self) => class AuthenticationStateData extends $.$$.System.Object
        {
            /*IList<ClaimData>*/ Claims = null;
            /*string*/ NameClaimType = null;
            /*string*/ RoleClaimType = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Claims = (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData))().$ctor$1();
                    return $t1;
                })();
                this.NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                this.RoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            }
            static $h = 304230;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IList$$($.$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData).$h,"g":{"r":0,"d":0,"h":12885206118,"f":50331649},"s":{"r":0,"d":0,"h":17180173414,"f":83886081},"n":"Claims","d":304230,"h":8590238822,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065075302,"f":50331649},"s":{"r":0,"d":0,"h":34360042598,"f":83886081},"n":"NameClaimType","d":304230,"h":25770108006,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47244944486,"f":50331649},"s":{"r":0,"d":0,"h":51539911782,"f":83886081},"n":"RoleClaimType","d":304230,"h":42949977190,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":304230,"h":55834879078,"f":16777217}],"h":304230}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthenticationStateData`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState", ($self) => class AuthenticationState extends $.$$.System.Object
        {
            $ctor$1(/*ClaimsPrincipal*/ user)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(user, "user");
                    this.User = user;
                }
                return this;
            }
            /*ClaimsPrincipal*/ User = null;
            static $h = 173158;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":426462,"g":{"r":0,"d":0,"h":17180042342,"f":50331649},"n":"User","d":173158,"h":12885075046,"f":2097153}],"c":[{"p":[{"n":"user","p":426462}],"n":".ctor","o":"$ctor$1","d":173158,"h":4295140454,"f":16777217}],"h":173158}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AuthenticationState`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager", ($self) => class HotReloadManager extends $.$$.System.Object
        {
            /*HotReloadManager*/ static Default = null;
            /*bool*/ MetadataUpdateSupported = false;
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            /*Action?*/ OnDeltaApplied = null;
            add_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Combine(this.OnDeltaApplied, value);
            }
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Remove(this.OnDeltaApplied, value);
            }
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                return ($.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
            }
            /*void */ TriggerOnDeltaApplied()
            {
                return (this.OnDeltaApplied?.Invoke() ?? null);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataUpdateSupported = $.$$.System.Reflection.Metadata.MetadataUpdater.IsSupported;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager().$ctor$1();
                }
            }
            static $h = 959590;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180828774,"f":50331649},"s":{"r":0,"d":0,"h":21475796070,"f":83886081},"n":"MetadataUpdateSupported","d":959590,"h":12885861478,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30065730662,"f":50331649},"n":"IsSubscribedTo","d":959590,"h":25770763366,"f":2097153}],"m":[{"r":65537,"p":[{"n":"_","p":$.$typeArray($.$$.System.Type).$h}],"n":"UpdateApplication","d":959590,"h":47245599846,"f":16777249},{"r":65537,"n":"TriggerOnDeltaApplied","d":959590,"h":51540567142,"f":16777224}],"l":[{"t":959590,"n":"Default","d":959590,"h":4295926886,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":959590,"h":55835534438,"f":16777217}],"e":[{"e":11730945,"m":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"add_OnDeltaApplied","d":959590,"h":34360697958,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"remove_OnDeltaApplied","d":959590,"h":38655665254,"f":285212673},"n":"OnDeltaApplied","d":959590,"h":42950632550,"f":8388609}],"h":959590}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HotReloadManager`; }
        });
        
        $asm.$cls("$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions", ($self) => class CascadingAuthenticationStateServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddCascadingAuthenticationState(/*this IServiceCollection*/ serviceCollection)
            {
                return $.$mac.Microsoft.Extensions.DependencyInjection.CascadingValueServiceCollectionExtensions.AddCascadingValue($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState), serviceCollection, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))))().$ctor(this,  (/*services*/ services) =>
                {
                    /*var*/ let authenticationStateProvider = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider, services);
                    return new $.$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource().$ctor$6(authenticationStateProvider);
                }, {"r":$.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)).$h,"p":[{"n":"services","p":327717}],"n":"","d":1090662,"h":0,"f":17825794}));
            }
            static $_AuthenticationStateCascadingValueSource;
            static get AuthenticationStateCascadingValueSource()
            {
                let $cls = $.$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions;
                return $cls.$_AuthenticationStateCascadingValueSource ??= $asm.$ncls("$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource", ($self) => class AuthenticationStateCascadingValueSource extends $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))
                {
                    /*AuthenticationStateProvider*/ _authenticationStateProvider = null;
                    $ctor$6(/*AuthenticationStateProvider*/ authenticationStateProvider)
                    {
                        super.$ctor$2(new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)))().$ctor(authenticationStateProvider, authenticationStateProvider.GetAuthenticationStateAsync), false);
                        {
                            this._authenticationStateProvider = authenticationStateProvider;
                            this._authenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                        }
                        return this;
                    }
                    /*void */ HandleAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
                    {
                        _ = this.NotifyChangedAsync$1(newAuthStateTask);
                    }
                    /*void */ Dispose()
                    {
                        this._authenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 1156198;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"newAuthStateTask","p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"HandleAuthenticationStateChanged","d":1156198,"h":12886058086,"f":16777218},{"r":65537,"n":"Dispose","d":1156198,"h":17181025382,"f":16777217}],"l":[{"t":369766,"n":"_authenticationStateProvider","d":1156198,"h":4296123494,"f":4194306}],"c":[{"p":[{"n":"authenticationStateProvider","p":369766}],"n":".ctor","o":"$ctor$6","d":1156198,"h":8591090790,"f":16777217}],"i":[2686984,57540609],"d":1090662,"h":1156198}; }
                    static get $b() { return $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.ICascadingValueSupplier, $.$$.System.IDisposable ]; }
                    static get $fullName() { return `CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource`; }
                }, $cls, ($v) => $cls.$_AuthenticationStateCascadingValueSource = $v);
            }
            static $h = 1090662;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"serviceCollection","p":786435}],"n":"AddCascadingAuthenticationState","d":1090662,"h":4296057958,"f":16777249}],"j":[1156198],"h":1090662}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `CascadingAuthenticationStateServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache", ($self) => class AttributeAuthorizeDataCache
        {
            /*Static constructor*/ static $cctor()
            {
                if ($.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.System.Action().$ctor($.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache, $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.ClearCache));
                }
            }
            /*ConcurrentDictionary<Type, IAuthorizeData[]?>*/ static _cache = null;
            static /*void */ ClearCache()
            {
                return $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.Clear();
            }
            static /*IAuthorizeData[]? */ GetAuthorizeDataForType(/*Type*/ type)
            {
                /*var*/ let result;
                if (!$.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.TryGetValue(type, $.$ref(() => result, ($v) => result = $v, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData))))
                {
                    result = $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.ComputeAuthorizeDataForType(type);
                    $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.set_Item(type, result);
                }
                return result;
            }
            static /*IAuthorizeData[]? */ ComputeAuthorizeDataForType(/*Type*/ type)
            {
                /*var*/ let allAttributes = type.GetCustomAttributes(true);
                /*List<IAuthorizeData>?*/ let authorizeDatas = null;
                for(/*var*/ let i = 0; i < allAttributes.length; i++)
                {
                    if ($.$is($.$$.System.Array.$ReadT1.call(allAttributes, i), $.$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous))
                    {
                        return null;
                    }
                    let authorizeData;
                    if ($.$is($.$$.System.Array.$ReadT1.call(allAttributes, i), $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData, { set $v(v){ authorizeData = v; } }))
                    {
                        authorizeDatas ??= new ($.$$.System.Collections.Generic.List$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData))().$ctor$1();
                        authorizeDatas.Add(authorizeData);
                    }
                }
                return authorizeDatas?.ToArray() ?? null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData)))().$ctor$1();
                }
            }
            static $h = 107622;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ClearCache","d":107622,"h":12885009510,"f":16777250},{"r":$.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,"p":[{"n":"type","p":142475265}],"n":"GetAuthorizeDataForType","d":107622,"h":17179976806,"f":16777249},{"r":$.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,"p":[{"n":"type","p":142475265}],"n":"ComputeAuthorizeDataForType","d":107622,"h":21474944102,"f":16777250}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData)).$h,"n":"_cache","d":107622,"h":8590042214,"f":4194338}],"h":107622}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AttributeAuthorizeDataCache`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter", ($self) => class AuthorizeDataAdapter extends $.$$.System.Object
        {
            /*AuthorizeView*/ _component = null;
            $ctor$1(/*AuthorizeView*/ component)
            {
                super.$ctor();
                {
                    this._component = $.$firstOf(component, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("component") });
                }
                return this;
            }
            /*string? */ get Policy()
            {
                return this._component.Policy;
            }
            /*string? */ set Policy(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*string? */ get Roles()
            {
                return this._component.Roles;
            }
            /*string? */ set Roles(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*string? */ get AuthenticationSchemes()
            {
                return null;
            }
            /*string? */ set AuthenticationSchemes(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy()
            {
                return this.Policy;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy(value)
            {
                this.Policy = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles()
            {
                return this.Roles;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles(value)
            {
                this.Roles = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes()
            {
                return this.AuthenticationSchemes;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes(value)
            {
                this.AuthenticationSchemes = value;
            }
            static $h = 435302;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180304486,"f":50331649},"s":{"r":0,"d":0,"h":21475271782,"f":83886081},"n":"Policy","d":435302,"h":12885337190,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065206374,"f":50331649},"s":{"r":0,"d":0,"h":34360173670,"f":83886081},"n":"Roles","d":435302,"h":25770239078,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42950108262,"f":50331649},"s":{"r":0,"d":0,"h":47245075558,"f":83886081},"n":"AuthenticationSchemes","d":435302,"h":38655140966,"f":2097153}],"l":[{"t":631910,"n":"_component","d":435302,"h":4295402598,"f":4194306}],"c":[{"p":[{"n":"component","p":631910}],"n":".ctor","o":"$ctor$1","d":435302,"h":8590369894,"f":16777217}],"i":[190691],"h":435302}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData ]; }
            static get $fullName() { return `AuthorizeDataAdapter`; }
        });
        
        $asm.$cls("$maca.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1025126;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":1025126,"h":4295992422,"f":16777217}],"h":1025126}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$maca.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1221734;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":1221734,"h":4296189030,"f":16777217}],"h":1221734,"a":[{"t":1025126,"c":4295992422},{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$str("$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData", ($self) => class ClaimData extends $.$$.System.ValueType
        {
            $ctor$3(/*string*/ type, /*string*/ value)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                    this.Value = value;
                }
                return this;
            }
            $ctor$4(/*Claim*/ claim)
            {
                this.$ctor$3(claim.Type, claim.Value);
                {
                }
                return this;
            }
            /*string*/ Type = null;
            /*string*/ Value = null;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Type = this.Type;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 828518;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475664998,"f":50331649},"n":"Type","d":828518,"h":17180697702,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34360566886,"f":50331649},"n":"Value","d":828518,"h":30065599590,"f":2097153}],"c":[{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":828518,"h":4295795814,"f":16777217,"a":[{"t":13087683,"c":4308054979}]},{"p":[{"n":"claim","p":164318}],"n":".ctor","o":"$ctor$4","d":828518,"h":8590763110,"f":16777217},{"n":".ctor","o":"$ctor$2","d":828518,"h":38655534182,"f":16777217}],"h":828518}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ClaimData`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState", ($self) => class CascadingAuthenticationState extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.CascadingValue$$($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)), 0);
                __builder.AddComponentParameter(1, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState), this._currentAuthenticationStateTask));
                __builder.AddComponentParameter(2, "ChildContent", (this.ChildContent));
                __builder.CloseComponent();
            }
            /*Task<AuthenticationState>?*/ _currentAuthenticationStateTask = null;
            /*RenderFragment?*/ ChildContent = null;
            /*void */ OnInitialized()
            {
                this.AuthenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
                this._currentAuthenticationStateTask = this.AuthenticationStateProvider.GetAuthenticationStateAsync();
            }
            /*void */ OnAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
            {
                _ = this.InvokeAsync(new $.$$.System.Action().$ctor(this,  () =>
                {
                    this._currentAuthenticationStateTask = newAuthStateTask;
                    this.StateHasChanged();
                }, {"r":65537,"n":"","d":762982,"h":0,"f":17825794}));
            }
            /*void */ System$IDisposable$Dispose()
            {
                this.AuthenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
            }
            /*AuthenticationStateProvider*/ AuthenticationStateProvider = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AuthenticationStateProvider = null;
            }
            static $h = 762982;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":6881288,"g":{"r":0,"d":0,"h":21475599462,"f":50331649},"s":{"r":0,"d":0,"h":25770566758,"f":83886081},"n":"ChildContent","d":762982,"h":17180632166,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":369766,"g":{"r":0,"d":0,"h":51540370534,"f":50331650},"s":{"r":0,"d":0,"h":55835337830,"f":83886082},"n":"AuthenticationStateProvider","d":762982,"h":47245403238,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":762982,"h":4295730278,"f":16809988},{"r":65537,"n":"OnInitialized","d":762982,"h":30065534054,"f":16809988},{"r":65537,"p":[{"n":"newAuthStateTask","p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"OnAuthenticationStateChanged","d":762982,"h":34360501350,"f":16777218}],"l":[{"t":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_currentAuthenticationStateTask","d":762982,"h":8590697574,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":762982,"h":60130305126,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":762982}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler", ($self) => class AuthenticationStateChangedHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ task)
            {
                return this.$nativeFunction.call(this.$target, task);
            }
            static $h = 238694;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"task","p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"Invoke","d":238694,"h":8590173286,"f":16777345},{"r":57016321,"p":[{"n":"task","p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":238694,"h":12885140582,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":238694,"h":17180107878,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":238694,"h":4295205990,"f":16777217}],"i":[57212929,113246209],"h":238694}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `AuthenticationStateChangedHandler`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeView", ($self) => class AuthorizeView extends $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore
        {
            /*IAuthorizeData[]*/ selfAsAuthorizeData = null;
            $ctor$3()
            {
                super.$ctor$2();
                {
                    this.selfAsAuthorizeData = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter), [new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter().$ctor$1(this)], null, null);
                }
                return this;
            }
            /*string?*/ Policy = null;
            /*string?*/ Roles = null;
            /*IAuthorizeData[] */ GetAuthorizeData()
            {
                return this.selfAsAuthorizeData;
            }
            static $h = 631910;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":697446,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475468390,"f":50331649},"s":{"r":0,"d":0,"h":25770435686,"f":83886081},"n":"Policy","d":631910,"h":17180501094,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655337574,"f":50331649},"s":{"r":0,"d":0,"h":42950304870,"f":83886081},"n":"Roles","d":631910,"h":34360370278,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":$.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,"n":"GetAuthorizeData","d":631910,"h":47245272166,"f":16809988}],"l":[{"t":$.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,"n":"selfAsAuthorizeData","d":631910,"h":4295599206,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$3","d":631910,"h":8590566502,"f":16777217}],"i":[2752520,3145736,3080200],"h":631910}; }
            static get $b() { return $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `AuthorizeView`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView", ($self) => class AuthorizeRouteView extends $.$mac.Microsoft.AspNetCore.Components.RouteView
        {
            /*RenderFragment<AuthenticationState>*/ static _defaultNotAuthorizedContent = null;
            /*RenderFragment*/ static _defaultAuthorizingContent = null;
            /*RenderFragment*/ _renderAuthorizeRouteViewCoreDelegate = null;
            /*RenderFragment<AuthenticationState>*/ _renderAuthorizedDelegate = null;
            /*RenderFragment<AuthenticationState>*/ _renderNotAuthorizedDelegate = null;
            /*RenderFragment*/ _renderAuthorizingDelegate = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    /*RenderFragment*/ let renderBaseRouteViewDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, super.Render);
                    this._renderAuthorizedDelegate = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/*authenticateState*/ authenticateState) =>
                    {
                        return renderBaseRouteViewDelegate;
                    }, {"r":6881288,"p":[{"n":"authenticateState","p":173158}],"n":"","d":500838,"h":0,"f":17825794});
                    this._renderNotAuthorizedDelegate = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/*authenticationState*/ authenticationState) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return this.RenderNotAuthorizedInDefaultLayout(builder, authenticationState);
                        }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":500838,"h":0,"f":17825794});
                    }, {"r":6881288,"p":[{"n":"authenticationState","p":173158}],"n":"","d":500838,"h":0,"f":17825794});
                    this._renderAuthorizingDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderAuthorizingInDefaultLayout);
                    this._renderAuthorizeRouteViewCoreDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderAuthorizeRouteViewCore);
                }
                return this;
            }
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            /*RenderFragment?*/ Authorizing = null;
            /*object?*/ Resource = null;
            /*Task<AuthenticationState>?*/ ExistingCascadedAuthenticationState = null;
            /*void */ Render(/*RenderTreeBuilder*/ builder)
            {
                if (this.ExistingCascadedAuthenticationState !== null)
                {
                    this._renderAuthorizeRouteViewCoreDelegate.Invoke(builder);
                }
                else 
                {
                    builder.OpenComponent$1($.$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState, 0);
                    builder.AddComponentParameter(1, "ChildContent", this._renderAuthorizeRouteViewCoreDelegate);
                    builder.CloseComponent();
                }
            }
            /*void */ RenderAuthorizeRouteViewCore(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenComponent$1($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView.AuthorizeRouteViewCore, 0);
                builder.AddComponentParameter(1, "RouteData", this.RouteData);
                builder.AddComponentParameter(2, "Authorized", this._renderAuthorizedDelegate);
                builder.AddComponentParameter(3, "Authorizing", this._renderAuthorizingDelegate);
                builder.AddComponentParameter(4, "NotAuthorized", this._renderNotAuthorizedDelegate);
                builder.AddComponentParameter(5, "Resource", this.Resource);
                builder.CloseComponent();
            }
            /*void */ RenderContentInDefaultLayout(/*RenderTreeBuilder*/ builder, /*RenderFragment*/ content)
            {
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.LayoutView, 0);
                builder.AddComponentParameter(1, "Layout", this.DefaultLayout);
                builder.AddComponentParameter(2, "ChildContent", content);
                builder.CloseComponent();
            }
            /*void */ RenderNotAuthorizedInDefaultLayout(/*RenderTreeBuilder*/ builder, /*AuthenticationState*/ authenticationState)
            {
                /*var*/ let content = this.NotAuthorized ?? $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView._defaultNotAuthorizedContent;
                this.RenderContentInDefaultLayout(builder, content.Invoke(authenticationState));
            }
            /*void */ RenderAuthorizingInDefaultLayout(/*RenderTreeBuilder*/ builder)
            {
                /*var*/ let content = this.Authorizing ?? $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView._defaultAuthorizingContent;
                this.RenderContentInDefaultLayout(builder, content);
            }
            static $_AuthorizeRouteViewCore;
            static get AuthorizeRouteViewCore()
            {
                let $cls = $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView;
                return $cls.$_AuthorizeRouteViewCore ??= $asm.$ncls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView.AuthorizeRouteViewCore", ($self) => class AuthorizeRouteViewCore extends $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore
                {
                    /*RouteData*/ RouteData = null;
                    /*IAuthorizeData[]? */ GetAuthorizeData()
                    {
                        return $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.GetAuthorizeDataForType(this.RouteData.PageType);
                    }
                    //default reference type constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.RouteData = null;
                    }
                    static $h = 566374;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":697446,"p":[{"p":9961480,"g":{"r":0,"d":0,"h":12885468262,"f":50331649},"s":{"r":0,"d":0,"h":17180435558,"f":83886081},"n":"RouteData","d":566374,"h":8590500966,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":$.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData).$h,"n":"GetAuthorizeData","d":566374,"h":21475402854,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":566374,"h":25770370150,"f":16777217}],"i":[2752520,3145736,3080200],"d":500838,"h":566374}; }
                    static get $b() { return $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
                    static get $fullName() { return `AuthorizeRouteView.AuthorizeRouteViewCore`; }
                }, $cls, ($v) => $cls.$_AuthorizeRouteViewCore = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._defaultNotAuthorizedContent = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/*state*/ state) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return builder.AddContent$2(0, "Not authorized");
                        }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":500838,"h":0,"f":17825794});
                    }, {"r":6881288,"p":[{"n":"state","p":173158}],"n":"","d":500838,"h":0,"f":17825794});
                }
                {
                    this._defaultAuthorizingContent = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        return builder.AddContent$2(0, "Authorizing...");
                    }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":500838,"h":0,"f":17825794});
                }
            }
            static $h = 500838;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":10223624,"p":[{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":42950173798,"f":50331649},"s":{"r":0,"d":0,"h":47245141094,"f":83886081},"n":"NotAuthorized","d":500838,"h":38655206502,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":6881288,"g":{"r":0,"d":0,"h":60130042982,"f":50331649},"s":{"r":0,"d":0,"h":64425010278,"f":83886081},"n":"Authorizing","d":500838,"h":55835075686,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":131073,"g":{"r":0,"d":0,"h":77309912166,"f":50331649},"s":{"r":0,"d":0,"h":81604879462,"f":83886081},"n":"Resource","d":500838,"h":73014944870,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":94489781350,"f":50331650},"s":{"r":0,"d":0,"h":98784748646,"f":83886082},"n":"ExistingCascadedAuthenticationState","d":500838,"h":90194814054,"f":2097154,"a":[{"t":524296,"c":21475360776}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"Render","d":500838,"h":103079715942,"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"RenderAuthorizeRouteViewCore","d":500838,"h":107374683238,"f":16777218},{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"content","p":6881288}],"n":"RenderContentInDefaultLayout","d":500838,"h":111669650534,"f":16777218},{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"authenticationState","p":173158}],"n":"RenderNotAuthorizedInDefaultLayout","d":500838,"h":115964617830,"f":16777218},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"RenderAuthorizingInDefaultLayout","d":500838,"h":120259585126,"f":16777218}],"l":[{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_defaultNotAuthorizedContent","d":500838,"h":4295468134,"f":4194338},{"t":6881288,"n":"_defaultAuthorizingContent","d":500838,"h":8590435430,"f":4194338},{"t":6881288,"n":"_renderAuthorizeRouteViewCoreDelegate","d":500838,"h":12885402726,"f":4194306},{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_renderAuthorizedDelegate","d":500838,"h":17180370022,"f":4194306},{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_renderNotAuthorizedDelegate","d":500838,"h":21475337318,"f":4194306},{"t":6881288,"n":"_renderAuthorizingDelegate","d":500838,"h":25770304614,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":500838,"h":30065271910,"f":16777217}],"i":[2752520],"j":[566374],"h":500838}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.RouteView; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent ]; }
            static get $fullName() { return `AuthorizeRouteView`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.AspNetCore.Authorization"))