
//--TRIMMABLE-BOUNDARY-START(121)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $mecga, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mexla, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mam, $maa) {
    "use strict";
    let _;
    let $txuJLd;
    let $zPVwHe;
    let $OQHyxh;
    let $BXScFj;
    let $TxZmpi;
    let $PsbeKk;
    let $KmOzFd;
    let $vhWUOf;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Authorization", 
    {
  "h": 121,
  "f": "Microsoft.AspNetCore.Components.Authorization",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Authentication and authorization support for Blazor applications.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.Authorization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 116457473,
      "c": 8706392065,
      "a": [
        {
          "v": 917625,
          "t": 188547073
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(852089)
        $asm.$cls(`$maca.MACA.IHostEnvironmentAuthenticationStateProvider`, ($self) => class IHostEnvironmentAuthenticationStateProvider
        {
            static $h = 852089;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295819385),
    {
      "r": 65537,
      "p": [
        {
          "n": "authenticationStateTask",
          "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h
        }
      ],
      "n": "SetAuthenticationState",
      "o": "MACA$IHostEnvironmentAuthenticationStateProvider$SetAuthenticationState",
      "d": 852089,
      "h": 4295819385,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295819385)
  ],
  "h": 852089
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.IHostEnvironmentAuthenticationStateProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}IHostEnvironmentAuthenticationStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852089)
        
        

        //--TRIMMABLE-BOUNDARY-START(327801)
        $asm.$cls(`$maca.MACA.AuthenticationStateProvider`, ($self) => class AuthenticationStateProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180196985)
            /*AuthenticationStateChangedHandler?*/ AuthenticationStateChanged = null;
            //--TRIMMABLE-BOUNDARY-END(17180196985)
            
            //--TRIMMABLE-BOUNDARY-START(17180196985)
            //--TRIMMABLE-BOUNDARY-START(12885229689)
            add_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationStateChanged = $.$$.S.Delegate.Combine$2(this.AuthenticationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229689)
            
            //--TRIMMABLE-BOUNDARY-START(34360066169)
            remove_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationStateChanged = $.$$.S.Delegate.Remove(this.AuthenticationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066169)
            
            //--TRIMMABLE-BOUNDARY-END(17180196985)
            
            //--TRIMMABLE-BOUNDARY-START(25770131577)
            /*void */ NotifyAuthenticationStateChanged(/*Task<AuthenticationState>*/ task)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(task, "task");
                this.AuthenticationStateChanged?.Invoke(task);
            }
            //--TRIMMABLE-BOUNDARY-END(25770131577)
            
            //--TRIMMABLE-BOUNDARY-START(4295295097)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295097)
            
            //--TRIMMABLE-BOUNDARY-START(4295295097)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295097)
            
            static $h = 327801;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475164281),
    {
      "r": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h,
      "n": "GetAuthenticationStateAsync",
      "d": 327801,
      "h": 21475164281,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475164281),
//--TRIMMABLE-BOUNDARY-START(25770131577),
    {
      "r": 65537,
      "p": [
        {
          "n": "task",
          "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h
        }
      ],
      "n": "NotifyAuthenticationStateChanged",
      "d": 327801,
      "h": 25770131577,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25770131577)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295097),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327801,
      "h": 4295295097,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295295097)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(17180196985),
    {
      "e": 196729,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196729
          }
        ],
        "n": "add_AuthenticationStateChanged",
        "d": 327801,
        "h": 12885229689,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196729
          }
        ],
        "n": "remove_AuthenticationStateChanged",
        "d": 327801,
        "h": 34360066169,
        "f": 285212673
      },
      "n": "AuthenticationStateChanged",
      "d": 327801,
      "h": 17180196985,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(17180196985)
  ],
  "h": 327801
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthenticationStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327801)
        
        

        //--TRIMMABLE-BOUNDARY-START(655481)
        $asm.$cls(`$maca.MACA.AuthorizeViewCore`, ($self) => class AuthorizeViewCore extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(73015099513)
            /*AuthenticationState?*/ currentAuthenticationState = null;
            //--TRIMMABLE-BOUNDARY-END(73015099513)
            
            //--TRIMMABLE-BOUNDARY-START(154619478137)
            /*bool?*/ isAuthorized = null;
            //--TRIMMABLE-BOUNDARY-END(154619478137)
            
            //--TRIMMABLE-BOUNDARY-START(68720132217)
            /*RenderFragment<AuthenticationState>?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(68720132217)
            
            //--TRIMMABLE-BOUNDARY-START(163209412729)
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            //--TRIMMABLE-BOUNDARY-END(163209412729)
            
            //--TRIMMABLE-BOUNDARY-START(55835230329)
            /*RenderFragment<AuthenticationState>?*/ Authorized = null;
            //--TRIMMABLE-BOUNDARY-END(55835230329)
            
            //--TRIMMABLE-BOUNDARY-START(60130197625)
            /*RenderFragment?*/ Authorizing = null;
            //--TRIMMABLE-BOUNDARY-END(60130197625)
            
            //--TRIMMABLE-BOUNDARY-START(171799347321)
            /*object?*/ Resource = null;
            //--TRIMMABLE-BOUNDARY-END(171799347321)
            
            //--TRIMMABLE-BOUNDARY-START(42950328441)
            /*Task<AuthenticationState>?*/ AuthenticationState = null;
            //--TRIMMABLE-BOUNDARY-END(42950328441)
            
            //--TRIMMABLE-BOUNDARY-START(47245295737)
            /*IAuthorizationPolicyProvider*/ AuthorizationPolicyProvider = null;
            //--TRIMMABLE-BOUNDARY-END(47245295737)
            
            //--TRIMMABLE-BOUNDARY-START(51540263033)
            /*IAuthorizationService*/ AuthorizationService = null;
            //--TRIMMABLE-BOUNDARY-END(51540263033)
            
            //--TRIMMABLE-BOUNDARY-START(64425164921)
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425164921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.isAuthorized === null)
                {
                    builder.AddContent$1(0, this.Authorizing);
                }
                else if (this.isAuthorized === true)
                {
                    /*var*/ let authorized = this.Authorized ?? this.ChildContent;
                    builder.AddContent$1(0, (authorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
                else 
                {
                    builder.AddContent$1(0, (this.NotAuthorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425164921)
            
            //--TRIMMABLE-BOUNDARY-START(167504380025)
            /*Task *//*async*/  OnParametersSetAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504380025);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ChildContent !== null && this.Authorized !== null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`Do not specify both '${$.$strNN("Authorized")}' and '${$.$strNN("ChildContent")}'.`);
                    }
                    if (this.AuthenticationState === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`Authorization requires a cascading parameter of type Task<${$.$strNN("AuthenticationState")}>. Consider using ${$.$strNN($.$maca.MACA.CascadingAuthenticationState.$type.Name)} to supply this.`);
                    }
                    this.isAuthorized = null;
                    this.currentAuthenticationState = ($t1 = this.AuthenticationState, ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.isAuthorized = ($t2 = this.IsAuthorizedAsync(this.currentAuthenticationState.User), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504380025)
            
            //--TRIMMABLE-BOUNDARY-START(158914445433)
            /*Task<bool> *//*async*/  IsAuthorizedAsync(/*ClaimsPrincipal*/ user)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914445433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let authorizeData = this.GetAuthorizeData();
                    if (authorizeData === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, true);
                    }
                    $.$maca.MACA.AuthorizeViewCore.EnsureNoAuthenticationSchemeSpecified(authorizeData);
                    /*var*/ let policy = ($t3 = $.$maa.MAA.AuthorizationPolicy.CombineAsync$1(this.AuthorizationPolicyProvider, authorizeData), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    /*var*/ let result = ($t4 = $.$maa.MAA.AuthorizationServiceExtensions.AuthorizeAsync$1(this.AuthorizationService, user, this.Resource, policy), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, result.Succeeded);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914445433)
            
            //--TRIMMABLE-BOUNDARY-START(77310066809)
            static /*void */ EnsureNoAuthenticationSchemeSpecified(/*IAuthorizeData[]*/ authorizeData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310066809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < authorizeData.length; i++)
                {
                    /*var*/ let entry = $.$$.System.Array.$ReadT1.call(authorizeData, i);
                    if (!$.$$.S.String.IsNullOrEmpty(entry.MAA$IAuthorizeData$AuthenticationSchemes))
                    {
                        throw new $.$$.S.NotSupportedException().$ctor$12(`The authorization data specifies an authentication scheme with value '${$.$strNN(entry.MAA$IAuthorizeData$AuthenticationSchemes)}'. Authentication schemes cannot be specified for components.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310066809)
            
            //--TRIMMABLE-BOUNDARY-START(38655361145)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655361145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655361145)
            
            //--TRIMMABLE-BOUNDARY-START(38655361145)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(38655361145)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47245295737)
                this.AuthorizationPolicyProvider = null;
                //--TRIMMABLE-BOUNDARY-END(47245295737)
                
                //--TRIMMABLE-BOUNDARY-START(51540263033)
                this.AuthorizationService = null;
                //--TRIMMABLE-BOUNDARY-END(51540263033)
                
            }
            static $h = 655481;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720132217),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849674361,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338954873,
        "f": 83886081
      },
      "n": "ChildContent",
      "d": 655481,
      "h": 68720132217,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720132217),
//--TRIMMABLE-BOUNDARY-START(163209412729),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439608953,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928889465,
        "f": 83886081
      },
      "n": "NotAuthorized",
      "d": 655481,
      "h": 163209412729,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209412729),
//--TRIMMABLE-BOUNDARY-START(55835230329),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669805177,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159085689,
        "f": 83886081
      },
      "n": "Authorized",
      "d": 655481,
      "h": 55835230329,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835230329),
//--TRIMMABLE-BOUNDARY-START(60130197625),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259739769,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749020281,
        "f": 83886081
      },
      "n": "Authorizing",
      "d": 655481,
      "h": 60130197625,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130197625),
//--TRIMMABLE-BOUNDARY-START(171799347321),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029543545,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518824057,
        "f": 83886081
      },
      "n": "Resource",
      "d": 655481,
      "h": 171799347321,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799347321),
//--TRIMMABLE-BOUNDARY-START(42950328441),
    {
      "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001401,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389281913,
        "f": 83886082
      },
      "n": "AuthenticationState",
      "d": 655481,
      "h": 42950328441,
      "f": 2097154,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950328441),
//--TRIMMABLE-BOUNDARY-START(47245295737),
    {
      "p": 1638512,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935993,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979216505,
        "f": 83886082
      },
      "n": "AuthorizationPolicyProvider",
      "d": 655481,
      "h": 47245295737,
      "f": 2097154,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245295737),
//--TRIMMABLE-BOUNDARY-START(51540263033),
    {
      "p": 1835120,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079870585,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569151097,
        "f": 83886082
      },
      "n": "AuthorizationService",
      "d": 655481,
      "h": 51540263033,
      "f": 2097154,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540263033)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425164921),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 655481,
      "h": 64425164921,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64425164921),
//--TRIMMABLE-BOUNDARY-START(167504380025),
    {
      "r": 178454529,
      "n": "OnParametersSetAsync",
      "d": 655481,
      "h": 167504380025,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(167504380025),
//--TRIMMABLE-BOUNDARY-START(150324510841),
    {
      "r": $.$typeArray($.$mam.MAA.IAuthorizeData).$h,
      "n": "GetAuthorizeData",
      "d": 655481,
      "h": 150324510841,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(150324510841),
//--TRIMMABLE-BOUNDARY-START(158914445433),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        }
      ],
      "n": "IsAuthorizedAsync",
      "d": 655481,
      "h": 158914445433,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(158914445433),
//--TRIMMABLE-BOUNDARY-START(77310066809),
    {
      "r": 65537,
      "p": [
        {
          "n": "authorizeData",
          "p": $.$typeArray($.$mam.MAA.IAuthorizeData).$h
        }
      ],
      "n": "EnsureNoAuthenticationSchemeSpecified",
      "d": 655481,
      "h": 77310066809,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77310066809)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015099513),
    {
      "t": 131193,
      "n": "currentAuthenticationState",
      "d": 655481,
      "h": 73015099513,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015099513),
//--TRIMMABLE-BOUNDARY-START(154619478137),
    {
      "t": $.$typeNullable($.$$.S.Boolean).$h,
      "n": "isAuthorized",
      "d": 655481,
      "h": 154619478137,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154619478137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655361145),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655481,
      "h": 38655361145,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38655361145)
  ],
  "h": 655481
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthorizeViewCore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655481)
        
        

        //--TRIMMABLE-BOUNDARY-START(262265)
        $asm.$cls(`$maca.MACA.AuthenticationStateData`, ($self) => class AuthenticationStateData extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475098745)
            /*IList<ClaimData>*/ Claims = null;
            //--TRIMMABLE-BOUNDARY-END(21475098745)
            
            //--TRIMMABLE-BOUNDARY-START(51539869817)
            /*string*/ NameClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(51539869817)
            
            //--TRIMMABLE-BOUNDARY-START(55834837113)
            /*string*/ RoleClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(55834837113)
            
            //--TRIMMABLE-BOUNDARY-START(17180131449)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131449)
            
            //--TRIMMABLE-BOUNDARY-START(17180131449)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180131449)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475098745)
                this.Claims = (() =>
                {
                    let $t1 = new ($.$$.SCG.List$$($.$maca.MACA.ClaimData))().$ctor$1();
                    return $t1;
                })();
                //--TRIMMABLE-BOUNDARY-END(21475098745)
                
                //--TRIMMABLE-BOUNDARY-START(51539869817)
                this.NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                //--TRIMMABLE-BOUNDARY-END(51539869817)
                
                //--TRIMMABLE-BOUNDARY-START(55834837113)
                this.RoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                //--TRIMMABLE-BOUNDARY-END(55834837113)
                
            }
            static $h = 262265;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475098745),
    {
      "p": $.$$.SCG.IList$$($.$maca.MACA.ClaimData).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033337,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771705,
        "f": 83886081
      },
      "n": "Claims",
      "d": 262265,
      "h": 21475098745,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098745),
//--TRIMMABLE-BOUNDARY-START(51539869817),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967929,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014706297,
        "f": 83886081
      },
      "n": "NameClaimType",
      "d": 262265,
      "h": 51539869817,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539869817),
//--TRIMMABLE-BOUNDARY-START(55834837113),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902521,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604640889,
        "f": 83886081
      },
      "n": "RoleClaimType",
      "d": 262265,
      "h": 55834837113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131449),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262265,
      "h": 17180131449,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131449)
  ],
  "h": 262265
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthenticationStateData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthenticationStateData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262265)
        
        

        //--TRIMMABLE-BOUNDARY-START(131193)
        $asm.$cls(`$maca.MACA.AuthenticationState`, ($self) => class AuthenticationState extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590065785)
            $ctor$1(/*ClaimsPrincipal*/ user)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(user, "user");
                    this.User = user;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065785)
            
            //--TRIMMABLE-BOUNDARY-START(21474967673)
            /*ClaimsPrincipal*/ User = null;
            //--TRIMMABLE-BOUNDARY-END(21474967673)
            
            static $h = 131193;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967673),
    {
      "p": 393285,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000377,
        "f": 50331649
      },
      "n": "User",
      "d": 131193,
      "h": 21474967673,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474967673)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065785),
    {
      "p": [
        {
          "n": "user",
          "p": 393285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131193,
      "h": 8590065785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065785)
  ],
  "h": 131193
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthenticationState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthenticationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131193)
        
        

        //--TRIMMABLE-BOUNDARY-START(917625)
        $asm.$cls(`$maca.MACH.HotReloadManager`, ($self) => class HotReloadManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770721401)
            /*HotReloadManager*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(25770721401)
            
            //--TRIMMABLE-BOUNDARY-START(51540525177)
            /*bool*/ MetadataUpdateSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51540525177)
            
            //--TRIMMABLE-BOUNDARY-START(47245557881)
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245557881)
            
            //--TRIMMABLE-BOUNDARY-START(55835492473)
            /*Action?*/ OnDeltaApplied = null;
            //--TRIMMABLE-BOUNDARY-END(55835492473)
            
            //--TRIMMABLE-BOUNDARY-START(55835492473)
            //--TRIMMABLE-BOUNDARY-START(21475754105)
            add_OnDeltaApplied(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDeltaApplied = $.$$.S.Delegate.Combine$2(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475754105)
            
            //--TRIMMABLE-BOUNDARY-START(64425427065)
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425427065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDeltaApplied = $.$$.S.Delegate.Remove(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425427065)
            
            //--TRIMMABLE-BOUNDARY-END(55835492473)
            
            //--TRIMMABLE-BOUNDARY-START(81605296249)
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605296249);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$maca.MACH.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605296249)
            
            //--TRIMMABLE-BOUNDARY-START(77310328953)
            /*void */ TriggerOnDeltaApplied()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310328953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310328953)
            
            //--TRIMMABLE-BOUNDARY-START(12885819513)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819513)
            
            //--TRIMMABLE-BOUNDARY-START(12885819513)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885819513)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540525177)
                this.MetadataUpdateSupported = $.$$.SRM.MetadataUpdater.IsSupported;
                //--TRIMMABLE-BOUNDARY-END(51540525177)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8590852217)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770721401)
                    this.Default = new $.$maca.MACH.HotReloadManager().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770721401)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590852217)
            
            static $h = 917625;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540525177),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590585,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015361657,
        "f": 83886081
      },
      "n": "MetadataUpdateSupported",
      "d": 917625,
      "h": 51540525177,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540525177),
//--TRIMMABLE-BOUNDARY-START(47245557881),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655993,
        "f": 50331649
      },
      "n": "IsSubscribedTo",
      "d": 917625,
      "h": 47245557881,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245557881)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605296249),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "UpdateApplication",
      "d": 917625,
      "h": 81605296249,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605296249),
//--TRIMMABLE-BOUNDARY-START(77310328953),
    {
      "r": 65537,
      "n": "TriggerOnDeltaApplied",
      "d": 917625,
      "h": 77310328953,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310328953)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770721401),
    {
      "t": 917625,
      "n": "Default",
      "d": 917625,
      "h": 25770721401,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770721401)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819513),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917625,
      "h": 12885819513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819513)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55835492473),
    {
      "e": 43122689,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "add_OnDeltaApplied",
        "d": 917625,
        "h": 21475754105,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "remove_OnDeltaApplied",
        "d": 917625,
        "h": 64425427065,
        "f": 285212673
      },
      "n": "OnDeltaApplied",
      "d": 917625,
      "h": 55835492473,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835492473)
  ],
  "h": 917625
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.HotReload.HotReloadManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}HotReload${separator}HotReloadManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917625)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048697)
        $asm.$cls(`$maca.MED.CascadingAuthenticationStateServiceCollectionExtensions`, ($self) => class CascadingAuthenticationStateServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296015993)
            static /*IServiceCollection */ AddCascadingAuthenticationState(/*this IServiceCollection*/ serviceCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mac.MED.CascadingValueServiceCollectionExtensions.AddCascadingValue($.$$.STT.Task$$($.$maca.MACA.AuthenticationState), serviceCollection, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$mac.MAC.CascadingValueSource$$($.$$.STT.Task$$($.$maca.MACA.AuthenticationState))))().$ctor(this,  (/*services*/ services) =>
                {
                    /*var*/ let authenticationStateProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$maca.MACA.AuthenticationStateProvider, services);
                    return new $.$maca.MED.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource().$ctor$6(authenticationStateProvider);
                }, $txuJLd ??= {"r":$.$mac.MAC.CascadingValueSource$$($.$$.STT.Task$$($.$maca.MACA.AuthenticationState)).$h,"p":[{"n":"services","p":327718}],"n":"","d":1048697,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296015993)
            
            //--TRIMMABLE-BOUNDARY-START(1114233)
            static $_AuthenticationStateCascadingValueSource;
            static get AuthenticationStateCascadingValueSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$maca.MED.CascadingAuthenticationStateServiceCollectionExtensions;
                return $cls.$_AuthenticationStateCascadingValueSource ??= $asm.$ncls(`$maca.MED.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource`, ($self) => class AuthenticationStateCascadingValueSource extends $.$mac.MAC.CascadingValueSource$$($.$$.STT.Task$$($.$maca.MACA.AuthenticationState))
                {
                    //--TRIMMABLE-BOUNDARY-START(4296081529)
                    /*AuthenticationStateProvider*/ _authenticationStateProvider = null;
                    //--TRIMMABLE-BOUNDARY-END(4296081529)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591048825)
                    $ctor$6(/*AuthenticationStateProvider*/ authenticationStateProvider)
                    {
                        super.$ctor$2(new ($.$$.S.Func$$($.$$.STT.Task$$($.$maca.MACA.AuthenticationState)))().$ctor(authenticationStateProvider, authenticationStateProvider.GetAuthenticationStateAsync), false);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591048825);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._authenticationStateProvider = authenticationStateProvider;
                            this._authenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.MACA.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591048825)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180983417)
                    /*void */ HandleAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180983417);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        _ = this.NotifyChangedAsync$1(newAuthStateTask);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180983417)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886016121)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886016121);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._authenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.MACA.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886016121)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $h = 1114233;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$mac.MAC.CascadingValueSource$$($.$$.STT.Task$$($.$maca.MACA.AuthenticationState)); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180983417),
    {
      "r": 65537,
      "p": [
        {
          "n": "newAuthStateTask",
          "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h
        }
      ],
      "n": "HandleAuthenticationStateChanged",
      "d": 1114233,
      "h": 17180983417,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180983417),
//--TRIMMABLE-BOUNDARY-START(12886016121),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1114233,
      "h": 12886016121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016121)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081529),
    {
      "t": 327801,
      "n": "_authenticationStateProvider",
      "d": 1114233,
      "h": 4296081529,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081529)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048825),
    {
      "p": [
        {
          "n": "authenticationStateProvider",
          "p": 327801
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1114233,
      "h": 8591048825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048825)
  ],
  "d": 1048697,
  "h": 1114233
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.MAC.ICascadingValueSupplier, $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions+AuthenticationStateCascadingValueSource`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}CascadingAuthenticationStateServiceCollectionExtensions${separator}AuthenticationStateCascadingValueSource`; }
                }, $cls, ($v) => $cls.$_AuthenticationStateCascadingValueSource = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114233)
            
            static $h = 1048697;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296015993),
    {
      "r": 786522,
      "p": [
        {
          "n": "serviceCollection",
          "p": 786522
        }
      ],
      "n": "AddCascadingAuthenticationState",
      "d": 1048697,
      "h": 4296015993,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296015993)
  ],
  "h": 1048697
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$maca.MED.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}CascadingAuthenticationStateServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048697)
        
        

        //--TRIMMABLE-BOUNDARY-START(65657)
        $asm.$cls(`$maca.MACA.AttributeAuthorizeDataCache`, ($self) => class AttributeAuthorizeDataCache
        {
            //--TRIMMABLE-BOUNDARY-START(8590000249)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$maca.MACH.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$maca.MACH.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.S.Action().$ctor($.$maca.MACA.AttributeAuthorizeDataCache, $.$maca.MACA.AttributeAuthorizeDataCache.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000249)
            
            //--TRIMMABLE-BOUNDARY-START(4295032953)
            /*ConcurrentDictionary<Type, IAuthorizeData[]?>*/ static _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4295032953)
            
            //--TRIMMABLE-BOUNDARY-START(12884967545)
            static /*void */ ClearCache()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967545);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maca.MACA.AttributeAuthorizeDataCache._cache.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967545)
            
            //--TRIMMABLE-BOUNDARY-START(21474902137)
            static /*IAuthorizeData[]? */ GetAuthorizeDataForType(/*Type*/ type)
            {
                /*var*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$maca.MACA.AttributeAuthorizeDataCache._cache.TryGetValue(type, $.$ref(() => result, ($v) => result = $v, $.$typeArray($.$mam.MAA.IAuthorizeData))))
                {
                    result = $.$maca.MACA.AttributeAuthorizeDataCache.ComputeAuthorizeDataForType(type);
                    $.$maca.MACA.AttributeAuthorizeDataCache._cache.set_Item$1(type, result);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902137)
            
            //--TRIMMABLE-BOUNDARY-START(17179934841)
            static /*IAuthorizeData[]? */ ComputeAuthorizeDataForType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let allAttributes = type.GetCustomAttributes(true);
                /*List<IAuthorizeData>?*/ let authorizeDatas = null;
                for(/*var*/ let i = 0; i < allAttributes.length; i++)
                {
                    if ($.$is($.$$.System.Array.$ReadT1.call(allAttributes, i), $.$mam.MAA.IAllowAnonymous))
                    {
                        return null;
                    }
                    let authorizeData;
                    if ($.$is($.$$.System.Array.$ReadT1.call(allAttributes, i), $.$mam.MAA.IAuthorizeData, { set $v($v){ authorizeData = $v; } }))
                    {
                        authorizeDatas ??= new ($.$$.SCG.List$$($.$mam.MAA.IAuthorizeData))().$ctor$1();
                        authorizeDatas.Add(authorizeData);
                    }
                }
                return authorizeDatas?.ToArray() ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934841)
            
            //--TRIMMABLE-BOUNDARY-START(8590000249)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032953)
                    this._cache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$typeArray($.$mam.MAA.IAuthorizeData)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4295032953)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000249)
            
            static $h = 65657;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884967545),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 65657,
      "h": 12884967545,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12884967545),
//--TRIMMABLE-BOUNDARY-START(21474902137),
    {
      "r": $.$typeArray($.$mam.MAA.IAuthorizeData).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetAuthorizeDataForType",
      "d": 65657,
      "h": 21474902137,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474902137),
//--TRIMMABLE-BOUNDARY-START(17179934841),
    {
      "r": $.$typeArray($.$mam.MAA.IAuthorizeData).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "ComputeAuthorizeDataForType",
      "d": 65657,
      "h": 17179934841,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17179934841)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032953),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$typeArray($.$mam.MAA.IAuthorizeData)).$h,
      "n": "_cache",
      "d": 65657,
      "h": 4295032953,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032953)
  ],
  "h": 65657
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AttributeAuthorizeDataCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65657)
        
        

        //--TRIMMABLE-BOUNDARY-START(393337)
        $asm.$cls(`$maca.MACA.AuthorizeDataAdapter`, ($self) => class AuthorizeDataAdapter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360633)
            /*AuthorizeView*/ _component = null;
            //--TRIMMABLE-BOUNDARY-END(4295360633)
            
            //--TRIMMABLE-BOUNDARY-START(8590327929)
            $ctor$1(/*AuthorizeView*/ component)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._component = $.$firstOf(component, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("component") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327929)
            
            //--TRIMMABLE-BOUNDARY-START(42950066297)
            /*string? */ get Policy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._component.Policy;
            }
            /*string? */ set Policy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(42950066297)
            
            //--TRIMMABLE-BOUNDARY-START(47245033593)
            /*string? */ get Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655099001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._component.Roles;
            }
            /*string? */ set Roles(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(47245033593)
            
            //--TRIMMABLE-BOUNDARY-START(12885295225)
            /*string? */ get AuthenticationSchemes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            /*string? */ set AuthenticationSchemes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834968185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12885295225)
            
            //--TRIMMABLE-BOUNDARY-START(21474967663)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get MAA$IAuthorizeData$Policy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Policy;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967663)
            
            //--TRIMMABLE-BOUNDARY-START(55834706031)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set MAA$IAuthorizeData$Policy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Policy = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706031)
            
            //--TRIMMABLE-BOUNDARY-START(30064902255)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get MAA$IAuthorizeData$Roles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Roles;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902255)
            
            //--TRIMMABLE-BOUNDARY-START(64424640623)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set MAA$IAuthorizeData$Roles(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Roles = value;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640623)
            
            //--TRIMMABLE-BOUNDARY-START(12885033071)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get MAA$IAuthorizeData$AuthenticationSchemes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticationSchemes;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033071)
            
            //--TRIMMABLE-BOUNDARY-START(47244771439)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set MAA$IAuthorizeData$AuthenticationSchemes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationSchemes = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771439)
            
            static $h = 393337;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950066297),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164409,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424902777,
        "f": 83886081
      },
      "n": "Policy",
      "d": 393337,
      "h": 42950066297,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950066297),
//--TRIMMABLE-BOUNDARY-START(47245033593),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655099001,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014837369,
        "f": 83886081
      },
      "n": "Roles",
      "d": 393337,
      "h": 47245033593,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245033593),
//--TRIMMABLE-BOUNDARY-START(12885295225),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475229817,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834968185,
        "f": 83886081
      },
      "n": "AuthenticationSchemes",
      "d": 393337,
      "h": 12885295225,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885295225)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360633),
    {
      "t": 589945,
      "n": "_component",
      "d": 393337,
      "h": 4295360633,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360633)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327929),
    {
      "p": [
        {
          "n": "component",
          "p": 589945
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393337,
      "h": 8590327929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327929)
  ],
  "h": 393337
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.MAA.IAuthorizeData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthorizeDataAdapter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393337)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179769)
        $asm.$cls(`$maca.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296147065)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296147065)
            
            //--TRIMMABLE-BOUNDARY-START(4296147065)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296147065)
            
            static $h = 1179769;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296147065),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179769,
      "h": 4296147065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296147065)
  ],
  "h": 1179769,
  "a": [
    {
      "t": 983161,
      "c": 4295950457
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179769)
        
        

        //--TRIMMABLE-BOUNDARY-START(786553)
        $asm.$str(`$maca.MACA.ClaimData`, ($self) => class ClaimData extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21475623033)
            $ctor$4(/*string*/ type, /*string*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475623033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Type = type;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623033)
            
            //--TRIMMABLE-BOUNDARY-START(17180655737)
            $ctor$3(/*Claim*/ claim)
            {
                this.$ctor$4(claim.Type, claim.Value);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655737);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655737)
            
            //--TRIMMABLE-BOUNDARY-START(42950459513)
            /*string*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(42950459513)
            
            //--TRIMMABLE-BOUNDARY-START(47245426809)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(47245426809)
            
            //--TRIMMABLE-BOUNDARY-START(12885688441)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688441)
            
            //--TRIMMABLE-BOUNDARY-START(12885688441)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885688441)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Type = this.Type;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 786553;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950459513),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065557625,
        "f": 50331649
      },
      "n": "Type",
      "d": 786553,
      "h": 42950459513,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950459513),
//--TRIMMABLE-BOUNDARY-START(47245426809),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655492217,
        "f": 50331649
      },
      "n": "Value",
      "d": 786553,
      "h": 47245426809,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245426809)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475623033),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786553,
      "h": 21475623033,
      "f": 16777217,
      "a": [
        {
          "t": 13434964,
          "c": 4308402260
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475623033),
//--TRIMMABLE-BOUNDARY-START(17180655737),
    {
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786553,
      "h": 17180655737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655737),
//--TRIMMABLE-BOUNDARY-START(12885688441),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786553,
      "h": 12885688441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688441)
  ],
  "h": 786553
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.ClaimData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}ClaimData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786553)
        
        

        //--TRIMMABLE-BOUNDARY-START(983161)
        $asm.$cls(`$maca.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295950457)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950457)
            
            //--TRIMMABLE-BOUNDARY-START(4295950457)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950457)
            
            static $h = 983161;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950457),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983161,
      "h": 4295950457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950457)
  ],
  "h": 983161
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983161)
        
        

        //--TRIMMABLE-BOUNDARY-START(721017)
        $asm.$cls(`$maca.MACA.CascadingAuthenticationState`, ($self) => class CascadingAuthenticationState extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(25770524793)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$$.STT.Task$$($.$maca.MACA.AuthenticationState)), 0);
                __builder.AddComponentParameter(1, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.STT.Task$$($.$maca.MACA.AuthenticationState), this._currentAuthenticationStateTask));
                __builder.AddComponentParameter(2, "ChildContent", (this.ChildContent));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770524793)
            
            //--TRIMMABLE-BOUNDARY-START(4295688313)
            /*Task<AuthenticationState>?*/ _currentAuthenticationStateTask = null;
            //--TRIMMABLE-BOUNDARY-END(4295688313)
            
            //--TRIMMABLE-BOUNDARY-START(30065492089)
            /*RenderFragment?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(30065492089)
            
            //--TRIMMABLE-BOUNDARY-START(55835295865)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.MACA.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
                this._currentAuthenticationStateTask = this.AuthenticationStateProvider.GetAuthenticationStateAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(55835295865)
            
            //--TRIMMABLE-BOUNDARY-START(51540328569)
            /*void */ OnAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.InvokeAsync(new $.$$.S.Action().$ctor(this,  () =>
                {
                    this._currentAuthenticationStateTask = newAuthStateTask;
                    this.StateHasChanged();
                }, $zPVwHe ??= {"r":65537,"n":"","d":721017,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(51540328569)
            
            //--TRIMMABLE-BOUNDARY-START(77310132345)
            /*void */ S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AuthenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.MACA.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(77310132345)
            
            //--TRIMMABLE-BOUNDARY-START(21475557497)
            /*AuthenticationStateProvider*/ AuthenticationStateProvider = null;
            //--TRIMMABLE-BOUNDARY-END(21475557497)
            
            //--TRIMMABLE-BOUNDARY-START(17180590201)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590201)
            
            //--TRIMMABLE-BOUNDARY-START(17180590201)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180590201)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475557497)
                this.AuthenticationStateProvider = null;
                //--TRIMMABLE-BOUNDARY-END(21475557497)
                
            }
            static $h = 721017;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065492089),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361273,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015165049,
        "f": 83886081
      },
      "n": "ChildContent",
      "d": 721017,
      "h": 30065492089,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065492089),
//--TRIMMABLE-BOUNDARY-START(21475557497),
    {
      "p": 327801,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426681,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425230457,
        "f": 83886082
      },
      "n": "AuthenticationStateProvider",
      "d": 721017,
      "h": 21475557497,
      "f": 2097154,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475557497)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770524793),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 721017,
      "h": 25770524793,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770524793),
//--TRIMMABLE-BOUNDARY-START(55835295865),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 721017,
      "h": 55835295865,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835295865),
//--TRIMMABLE-BOUNDARY-START(51540328569),
    {
      "r": 65537,
      "p": [
        {
          "n": "newAuthStateTask",
          "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h
        }
      ],
      "n": "OnAuthenticationStateChanged",
      "d": 721017,
      "h": 51540328569,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540328569)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688313),
    {
      "t": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h,
      "n": "_currentAuthenticationStateTask",
      "d": 721017,
      "h": 4295688313,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688313)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180590201),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721017,
      "h": 17180590201,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590201)
  ],
  "h": 721017
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}CascadingAuthenticationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721017)
        
        

        //--TRIMMABLE-BOUNDARY-START(196729)
        $asm.$cls(`$maca.MACA.AuthenticationStateChangedHandler`, ($self) => class AuthenticationStateChangedHandler extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ task)
            {
                return this.$nativeFunction.call(this.$target, task);
            }
            static $h = 196729;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065913),
    {
      "r": 65537,
      "p": [
        {
          "n": "task",
          "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h
        }
      ],
      "n": "Invoke",
      "d": 196729,
      "h": 17180065913,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180065913),
//--TRIMMABLE-BOUNDARY-START(8590131321),
    {
      "r": 90570753,
      "p": [
        {
          "n": "task",
          "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 196729,
      "h": 8590131321,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590131321),
//--TRIMMABLE-BOUNDARY-START(12885098617),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 196729,
      "h": 12885098617,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885098617)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164025),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 196729,
      "h": 4295164025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295164025)
  ],
  "h": 196729
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthenticationStateChangedHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196729)
        
        

        //--TRIMMABLE-BOUNDARY-START(589945)
        $asm.$cls(`$maca.MACA.AuthorizeView`, ($self) => class AuthorizeView extends $.$maca.MACA.AuthorizeViewCore
        {
            //--TRIMMABLE-BOUNDARY-START(47245230201)
            /*IAuthorizeData[]*/ selfAsAuthorizeData = null;
            //--TRIMMABLE-BOUNDARY-END(47245230201)
            
            //--TRIMMABLE-BOUNDARY-START(12885491833)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.selfAsAuthorizeData = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$maca.MACA.AuthorizeDataAdapter), [new $.$maca.MACA.AuthorizeDataAdapter().$ctor$1(this)], null, null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491833)
            
            //--TRIMMABLE-BOUNDARY-START(38655295609)
            /*string?*/ Policy = null;
            //--TRIMMABLE-BOUNDARY-END(38655295609)
            
            //--TRIMMABLE-BOUNDARY-START(42950262905)
            /*string?*/ Roles = null;
            //--TRIMMABLE-BOUNDARY-END(42950262905)
            
            //--TRIMMABLE-BOUNDARY-START(34360328313)
            /*IAuthorizeData[] */ GetAuthorizeData()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360328313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.selfAsAuthorizeData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360328313)
            
            //--TRIMMABLE-BOUNDARY-START(12885491833)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885491833)
            
            static $h = 589945;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maca.MACA.AuthorizeViewCore; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655295609),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475426425,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835164793,
        "f": 83886081
      },
      "n": "Policy",
      "d": 589945,
      "h": 38655295609,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655295609),
//--TRIMMABLE-BOUNDARY-START(42950262905),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065361017,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425099385,
        "f": 83886081
      },
      "n": "Roles",
      "d": 589945,
      "h": 42950262905,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950262905)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360328313),
    {
      "r": $.$typeArray($.$mam.MAA.IAuthorizeData).$h,
      "n": "GetAuthorizeData",
      "d": 589945,
      "h": 34360328313,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360328313)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245230201),
    {
      "t": $.$typeArray($.$mam.MAA.IAuthorizeData).$h,
      "n": "selfAsAuthorizeData",
      "d": 589945,
      "h": 47245230201,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245230201)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491833),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589945,
      "h": 12885491833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491833)
  ],
  "h": 589945
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthorizeView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthorizeView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589945)
        
        

        //--TRIMMABLE-BOUNDARY-START(458873)
        $asm.$cls(`$maca.MACA.AuthorizeRouteView`, ($self) => class AuthorizeRouteView extends $.$mac.MAC.RouteView
        {
            //--TRIMMABLE-BOUNDARY-START(8590393465)
            /*RenderFragment<AuthenticationState>*/ static _defaultNotAuthorizedContent = null;
            //--TRIMMABLE-BOUNDARY-END(8590393465)
            
            //--TRIMMABLE-BOUNDARY-START(4295426169)
            /*RenderFragment*/ static _defaultAuthorizingContent = null;
            //--TRIMMABLE-BOUNDARY-END(4295426169)
            
            //--TRIMMABLE-BOUNDARY-START(17180328057)
            /*RenderFragment*/ _renderAuthorizeRouteViewCoreDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(17180328057)
            
            //--TRIMMABLE-BOUNDARY-START(12885360761)
            /*RenderFragment<AuthenticationState>*/ _renderAuthorizedDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(12885360761)
            
            //--TRIMMABLE-BOUNDARY-START(25770262649)
            /*RenderFragment<AuthenticationState>*/ _renderNotAuthorizedDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(25770262649)
            
            //--TRIMMABLE-BOUNDARY-START(21475295353)
            /*RenderFragment*/ _renderAuthorizingDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(21475295353)
            
            //--TRIMMABLE-BOUNDARY-START(51540066425)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540066425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*RenderFragment*/ let renderBaseRouteViewDelegate = new $.$mac.MAC.RenderFragment().$ctor(this, super.Render);
                    this._renderAuthorizedDelegate = new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this,  (/**/ authenticateState) =>
                    {
                        return renderBaseRouteViewDelegate;
                    }, $OQHyxh ??= {"r":6881395,"p":[{"n":"authenticateState","p":131193}],"n":"","d":458873,"h":0,"f":17825794});
                    this._renderNotAuthorizedDelegate = new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this,  (/*authenticationState*/ authenticationState) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return this.RenderNotAuthorizedInDefaultLayout(builder, authenticationState);
                        }, $BXScFj ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":458873,"h":0,"f":17825794});
                    }, $TxZmpi ??= {"r":6881395,"p":[{"n":"authenticationState","p":131193}],"n":"","d":458873,"h":0,"f":17825794});
                    this._renderAuthorizingDelegate = new $.$mac.MAC.RenderFragment().$ctor(this, this.RenderAuthorizingInDefaultLayout);
                    this._renderAuthorizeRouteViewCoreDelegate = new $.$mac.MAC.RenderFragment().$ctor(this, this.RenderAuthorizeRouteViewCore);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066425)
            
            //--TRIMMABLE-BOUNDARY-START(98784706681)
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            //--TRIMMABLE-BOUNDARY-END(98784706681)
            
            //--TRIMMABLE-BOUNDARY-START(55835033721)
            /*RenderFragment?*/ Authorizing = null;
            //--TRIMMABLE-BOUNDARY-END(55835033721)
            
            //--TRIMMABLE-BOUNDARY-START(124554510457)
            /*object?*/ Resource = null;
            //--TRIMMABLE-BOUNDARY-END(124554510457)
            
            //--TRIMMABLE-BOUNDARY-START(60130001017)
            /*Task<AuthenticationState>?*/ ExistingCascadedAuthenticationState = null;
            //--TRIMMABLE-BOUNDARY-END(60130001017)
            
            //--TRIMMABLE-BOUNDARY-START(103079673977)
            /*void */ Render(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ExistingCascadedAuthenticationState !== null)
                {
                    this._renderAuthorizeRouteViewCoreDelegate.Invoke(builder);
                }
                else 
                {
                    builder.OpenComponent$1($.$maca.MACA.CascadingAuthenticationState, 0);
                    builder.AddComponentParameter(1, "ChildContent", this._renderAuthorizeRouteViewCoreDelegate);
                    builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079673977)
            
            //--TRIMMABLE-BOUNDARY-START(107374641273)
            /*void */ RenderAuthorizeRouteViewCore(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.OpenComponent$1($.$maca.MACA.AuthorizeRouteView.AuthorizeRouteViewCore, 0);
                builder.AddComponentParameter(1, "RouteData", this.RouteData);
                builder.AddComponentParameter(2, "Authorized", this._renderAuthorizedDelegate);
                builder.AddComponentParameter(3, "Authorizing", this._renderAuthorizingDelegate);
                builder.AddComponentParameter(4, "NotAuthorized", this._renderNotAuthorizedDelegate);
                builder.AddComponentParameter(5, "Resource", this.Resource);
                builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(107374641273)
            
            //--TRIMMABLE-BOUNDARY-START(115964575865)
            /*void */ RenderContentInDefaultLayout(/*RenderTreeBuilder*/ builder, /*RenderFragment*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.OpenComponent$1($.$mac.MAC.LayoutView, 0);
                builder.AddComponentParameter(1, "Layout", this.DefaultLayout);
                builder.AddComponentParameter(2, "ChildContent", content);
                builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(115964575865)
            
            //--TRIMMABLE-BOUNDARY-START(120259543161)
            /*void */ RenderNotAuthorizedInDefaultLayout(/*RenderTreeBuilder*/ builder, /*AuthenticationState*/ authenticationState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let content = this.NotAuthorized ?? $.$maca.MACA.AuthorizeRouteView._defaultNotAuthorizedContent;
                this.RenderContentInDefaultLayout(builder, content.Invoke(authenticationState));
            }
            //--TRIMMABLE-BOUNDARY-END(120259543161)
            
            //--TRIMMABLE-BOUNDARY-START(111669608569)
            /*void */ RenderAuthorizingInDefaultLayout(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let content = this.Authorizing ?? $.$maca.MACA.AuthorizeRouteView._defaultAuthorizingContent;
                this.RenderContentInDefaultLayout(builder, content);
            }
            //--TRIMMABLE-BOUNDARY-END(111669608569)
            
            //--TRIMMABLE-BOUNDARY-START(524409)
            static $_AuthorizeRouteViewCore;
            static get AuthorizeRouteViewCore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$maca.MACA.AuthorizeRouteView;
                return $cls.$_AuthorizeRouteViewCore ??= $asm.$ncls(`$maca.MACA.AuthorizeRouteView.AuthorizeRouteViewCore`, ($self) => class AuthorizeRouteViewCore extends $.$maca.MACA.AuthorizeViewCore
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328185)
                    /*RouteData*/ RouteData = null;
                    //--TRIMMABLE-BOUNDARY-END(25770328185)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475360889)
                    /*IAuthorizeData[]? */ GetAuthorizeData()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475360889);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$maca.MACA.AttributeAuthorizeDataCache.GetAuthorizeDataForType(this.RouteData.PageType);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475360889)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590459001)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590459001);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590459001)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590459001)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590459001)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25770328185)
                        this.RouteData = null;
                        //--TRIMMABLE-BOUNDARY-END(25770328185)
                        
                    }
                    static $h = 524409;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$maca.MACA.AuthorizeViewCore; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770328185),
    {
      "p": 9961587,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180393593,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360262777,
        "f": 83886081
      },
      "n": "RouteData",
      "d": 524409,
      "h": 25770328185,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770328185)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475360889),
    {
      "r": $.$typeArray($.$mam.MAA.IAuthorizeData).$h,
      "n": "GetAuthorizeData",
      "d": 524409,
      "h": 21475360889,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475360889)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590459001),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524409,
      "h": 8590459001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590459001)
  ],
  "d": 458873,
  "h": 524409
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView+AuthorizeRouteViewCore`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthorizeRouteView${separator}AuthorizeRouteViewCore`; }
                }, $cls, ($v) => $cls.$_AuthorizeRouteViewCore = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524409)
            
            //--TRIMMABLE-BOUNDARY-START(51540066425)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(51540066425)
            
            //--TRIMMABLE-BOUNDARY-START(47245099129)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393465)
                    this._defaultNotAuthorizedContent = new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this,  (/*state*/ state) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return builder.AddContent$4(0, "Not authorized");
                        }, $PsbeKk ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":458873,"h":0,"f":17825794});
                    }, $KmOzFd ??= {"r":6881395,"p":[{"n":"state","p":131193}],"n":"","d":458873,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(8590393465)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295426169)
                    this._defaultAuthorizingContent = new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        return builder.AddContent$4(0, "Authorizing...");
                    }, $vhWUOf ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":458873,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(4295426169)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245099129)
            
            static $h = 458873;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.RouteView; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784706681),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899804793,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324314233,
        "f": 83886081
      },
      "n": "NotAuthorized",
      "d": 458873,
      "h": 98784706681,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784706681),
//--TRIMMABLE-BOUNDARY-START(55835033721),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719935609,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144445049,
        "f": 83886081
      },
      "n": "Authorizing",
      "d": 458873,
      "h": 55835033721,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835033721),
//--TRIMMABLE-BOUNDARY-START(124554510457),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489739385,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914248825,
        "f": 83886081
      },
      "n": "Resource",
      "d": 458873,
      "h": 124554510457,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554510457),
//--TRIMMABLE-BOUNDARY-START(60130001017),
    {
      "p": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309870201,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734379641,
        "f": 83886082
      },
      "n": "ExistingCascadedAuthenticationState",
      "d": 458873,
      "h": 60130001017,
      "f": 2097154,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130001017)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103079673977),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        }
      ],
      "n": "Render",
      "d": 458873,
      "h": 103079673977,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103079673977),
//--TRIMMABLE-BOUNDARY-START(107374641273),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        }
      ],
      "n": "RenderAuthorizeRouteViewCore",
      "d": 458873,
      "h": 107374641273,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374641273),
//--TRIMMABLE-BOUNDARY-START(115964575865),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "content",
          "p": 6881395
        }
      ],
      "n": "RenderContentInDefaultLayout",
      "d": 458873,
      "h": 115964575865,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964575865),
//--TRIMMABLE-BOUNDARY-START(120259543161),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "authenticationState",
          "p": 131193
        }
      ],
      "n": "RenderNotAuthorizedInDefaultLayout",
      "d": 458873,
      "h": 120259543161,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120259543161),
//--TRIMMABLE-BOUNDARY-START(111669608569),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        }
      ],
      "n": "RenderAuthorizingInDefaultLayout",
      "d": 458873,
      "h": 111669608569,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111669608569)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393465),
    {
      "t": $.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState).$h,
      "n": "_defaultNotAuthorizedContent",
      "d": 458873,
      "h": 8590393465,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590393465),
//--TRIMMABLE-BOUNDARY-START(4295426169),
    {
      "t": 6881395,
      "n": "_defaultAuthorizingContent",
      "d": 458873,
      "h": 4295426169,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295426169),
//--TRIMMABLE-BOUNDARY-START(17180328057),
    {
      "t": 6881395,
      "n": "_renderAuthorizeRouteViewCoreDelegate",
      "d": 458873,
      "h": 17180328057,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180328057),
//--TRIMMABLE-BOUNDARY-START(12885360761),
    {
      "t": $.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState).$h,
      "n": "_renderAuthorizedDelegate",
      "d": 458873,
      "h": 12885360761,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360761),
//--TRIMMABLE-BOUNDARY-START(25770262649),
    {
      "t": $.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState).$h,
      "n": "_renderNotAuthorizedDelegate",
      "d": 458873,
      "h": 25770262649,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770262649),
//--TRIMMABLE-BOUNDARY-START(21475295353),
    {
      "t": 6881395,
      "n": "_renderAuthorizingDelegate",
      "d": 458873,
      "h": 21475295353,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475295353)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51540066425),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458873,
      "h": 51540066425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540066425)
  ],
  "h": 458873
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$maca.MACA.AuthorizeRouteView.AuthorizeRouteViewCore ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Authorization${separator}AuthorizeRouteView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458873)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.AspNetCore.Authorization"));
})();
//--TRIMMABLE-BOUNDARY-END(121)
