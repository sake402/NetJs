
(function ($global, $, $spc, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mam, $maa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Authorization", 
    {"h":58910,"f":"Microsoft.AspNetCore.Components.Authorization","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Authentication and authorization support for Blazor applications.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.Authorization","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.Authorization","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":78512129,"c":4373479425,"a":[{"v":976414,"t":142606337}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.IHostEnvironmentAuthenticationStateProvider", ($self) => class IHostEnvironmentAuthenticationStateProvider
        {
            static $h = 910878;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"authenticationStateTask","p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"SetAuthenticationState","o":"Microsoft$AspNetCore$Components$Authorization$IHostEnvironmentAuthenticationStateProvider$SetAuthenticationState","d":910878,"h":4295878174,"f":257}],"h":910878}; }
            static get $fullName() { return `IHostEnvironmentAuthenticationStateProvider`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider", ($self) => class AuthenticationStateProvider extends $.$spc.System.Object
        {
            /*AuthenticationStateChangedHandler?*/ AuthenticationStateChanged = null;
            add_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                this.AuthenticationStateChanged = $.$spc.System.Delegate.Combine(this.AuthenticationStateChanged, value);
            }
            remove_AuthenticationStateChanged(/*AuthenticationStateChangedHandler?*/ value)
            {
                this.AuthenticationStateChanged = $.$spc.System.Delegate.Remove(this.AuthenticationStateChanged, value);
            }
            /*void */ NotifyAuthenticationStateChanged(/*Task<AuthenticationState>*/ task)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(task, "task");
                this.AuthenticationStateChanged?.Invoke(task);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 386590;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"GetAuthenticationStateAsync","d":386590,"h":4295353886,"f":257},{"r":65537,"p":[{"n":"task","p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"NotifyAuthenticationStateChanged","d":386590,"h":21475223070,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":386590,"h":25770190366,"f":4}],"e":[{"e":255518,"m":{"r":65537,"p":[{"n":"value","p":255518}],"n":"add_AuthenticationStateChanged","d":386590,"h":8590321182,"f":1},"r":{"r":65537,"p":[{"n":"value","p":255518}],"n":"remove_AuthenticationStateChanged","d":386590,"h":12885288478,"f":1},"n":"AuthenticationStateChanged","d":386590,"h":17180255774,"f":1}],"h":386590}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthenticationStateProvider`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore", ($self) => class AuthorizeViewCore extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*AuthenticationState?*/ currentAuthenticationState = null;
            /*bool?*/ isAuthorized = null;
            /*RenderFragment<AuthenticationState>?*/ ChildContent = null;
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            /*RenderFragment<AuthenticationState>?*/ Authorized = null;
            /*RenderFragment?*/ Authorizing = null;
            /*object?*/ Resource = null;
            /*Task<AuthenticationState>?*/ AuthenticationState = null;
            /*IAuthorizationPolicyProvider*/ AuthorizationPolicyProvider = null;
            /*IAuthorizationService*/ AuthorizationService = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                if (this.isAuthorized === null)
                {
                    builder.AddContent$1(0, this.Authorizing);
                }
                else if (this.isAuthorized === true)
                {
                    /*var*/ let authorized = this.Authorized ?? this.ChildContent;
                    builder.AddContent$1(0, (authorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
                else 
                {
                    builder.AddContent$1(0, (this.NotAuthorized?.Invoke(this.currentAuthenticationState) ?? null));
                }
            }
            /*Task *//*async*/  OnParametersSetAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.ChildContent !== null && this.Authorized !== null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`Do not specify both '${"Authorized"}' and '${"ChildContent"}'.`);
                    }
                    if (this.AuthenticationState === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`Authorization requires a cascading parameter of type Task<${"AuthenticationState"}>. Consider using ${$.$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState.$type.Name} to supply this.`);
                    }
                    this.isAuthorized = null;
                    this.currentAuthenticationState = await this.AuthenticationState;
                    this.isAuthorized = await this.IsAuthorizedAsync(this.currentAuthenticationState.User);
                });
            }
            /*Task<bool> *//*async*/  IsAuthorizedAsync(/*ClaimsPrincipal*/ user)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    /*var*/ let authorizeData = this.GetAuthorizeData();
                    if (authorizeData === null)
                    {
                        return true;
                    }
                    $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore.EnsureNoAuthenticationSchemeSpecified(authorizeData);
                    /*var*/ let policy = await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationPolicy.CombineAsync(this.AuthorizationPolicyProvider, authorizeData);
                    /*var*/ let result = await $.$maa.Microsoft.AspNetCore.Authorization.AuthorizationServiceExtensions.AuthorizeAsync$1(this.AuthorizationService, user, this.Resource, policy);
                    return result.Succeeded;
                });
            }
            static /*void */ EnsureNoAuthenticationSchemeSpecified(/*IAuthorizeData[]*/ authorizeData)
            {
                for(/*var*/ let i = 0; i < authorizeData.length; i++)
                {
                    /*var*/ let entry = $.$spc.System.Array.$ReadT1.call(authorizeData, i);
                    if (!$.$spc.System.String.IsNullOrEmpty(entry.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes))
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10(`The authorization data specifies an authentication scheme with value '${entry.Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes}'. Authentication schemes cannot be specified for components.`);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AuthorizationPolicyProvider = null;
                this.AuthorizationService = null;
            }
            static $h = 714270;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":21475550750,"f":1},"s":{"r":0,"d":0,"h":25770518046,"f":1},"n":"ChildContent","d":714270,"h":17180583454,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":38655419934,"f":1},"s":{"r":0,"d":0,"h":42950387230,"f":1},"n":"NotAuthorized","d":714270,"h":34360452638,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":55835289118,"f":1},"s":{"r":0,"d":0,"h":60130256414,"f":1},"n":"Authorized","d":714270,"h":51540321822,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":6881288,"g":{"r":0,"d":0,"h":73015158302,"f":1},"s":{"r":0,"d":0,"h":77310125598,"f":1},"n":"Authorizing","d":714270,"h":68720191006,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":131073,"g":{"r":0,"d":0,"h":90195027486,"f":1},"s":{"r":0,"d":0,"h":94489994782,"f":1},"n":"Resource","d":714270,"h":85900060190,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":107374896670,"f":2},"s":{"r":0,"d":0,"h":111669863966,"f":2},"n":"AuthenticationState","d":714270,"h":103079929374,"f":2,"a":[{"t":524296,"c":21475360776}]},{"p":1700854,"g":{"r":0,"d":0,"h":124554765854,"f":2},"s":{"r":0,"d":0,"h":128849733150,"f":2},"n":"AuthorizationPolicyProvider","d":714270,"h":120259798558,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1897462,"g":{"r":0,"d":0,"h":141734635038,"f":2},"s":{"r":0,"d":0,"h":146029602334,"f":2},"n":"AuthorizationService","d":714270,"h":137439667742,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":714270,"h":150324569630,"f":32772},{"r":133300225,"n":"OnParametersSetAsync","d":714270,"h":154619536926,"f":36868},{"r":0,"n":"GetAuthorizeData","d":714270,"h":158914504222,"f":260},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"user","p":447163}],"n":"IsAuthorizedAsync","d":714270,"h":163209471518,"f":4098},{"r":65537,"p":[{"n":"authorizeData","p":0}],"n":"EnsureNoAuthenticationSchemeSpecified","d":714270,"h":167504438814,"f":34}],"l":[{"t":189982,"n":"currentAuthenticationState","d":714270,"h":4295681566,"f":2},{"t":$.$typeNullable($.$spc.System.Boolean).$h,"n":"isAuthorized","d":714270,"h":8590648862,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":714270,"h":171799406110,"f":4}],"i":[2752520,3145736,3080200],"h":714270}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `AuthorizeViewCore`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateData", ($self) => class AuthenticationStateData extends $.$spc.System.Object
        {
            /*IList<ClaimData>*/ Claims = null;
            /*string*/ NameClaimType = null;
            /*string*/ RoleClaimType = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Claims = (() =>
                {
                    let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData))().$ctor$1();
                    return $t1;
                })();
                this.NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                this.RoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            }
            static $h = 321054;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData).$h,"g":{"r":0,"d":0,"h":12885222942,"f":1},"s":{"r":0,"d":0,"h":17180190238,"f":1},"n":"Claims","d":321054,"h":8590255646,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065092126,"f":1},"s":{"r":0,"d":0,"h":34360059422,"f":1},"n":"NameClaimType","d":321054,"h":25770124830,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47244961310,"f":1},"s":{"r":0,"d":0,"h":51539928606,"f":1},"n":"RoleClaimType","d":321054,"h":42949994014,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":321054,"h":55834895902,"f":1}],"h":321054}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthenticationStateData`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState", ($self) => class AuthenticationState extends $.$spc.System.Object
        {
            $ctor$1(/*ClaimsPrincipal*/ user)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(user, "user");
                    this.User = user;
                }
                return this;
            }
            /*ClaimsPrincipal*/ User = null;
            static $h = 189982;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":447163,"g":{"r":0,"d":0,"h":17180059166,"f":1},"n":"User","d":189982,"h":12885091870,"f":1}],"c":[{"p":[{"n":"user","p":447163}],"n":".ctor","o":"$ctor$1","d":189982,"h":4295157278,"f":1}],"h":189982}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AuthenticationState`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager", ($self) => class HotReloadManager extends $.$spc.System.Object
        {
            /*HotReloadManager*/ static Default = null;
            /*bool*/ MetadataUpdateSupported = false;
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            /*Action?*/ OnDeltaApplied = null;
            add_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$spc.System.Delegate.Combine(this.OnDeltaApplied, value);
            }
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$spc.System.Delegate.Remove(this.OnDeltaApplied, value);
            }
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                return ($.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
            }
            /*void */ TriggerOnDeltaApplied()
            {
                return (this.OnDeltaApplied?.Invoke() ?? null);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataUpdateSupported = $.$spc.System.Reflection.Metadata.MetadataUpdater.IsSupported;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager().$ctor$1();
                }
            }
            static $h = 976414;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180845598,"f":1},"s":{"r":0,"d":0,"h":21475812894,"f":1},"n":"MetadataUpdateSupported","d":976414,"h":12885878302,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065747486,"f":1},"n":"IsSubscribedTo","d":976414,"h":25770780190,"f":1}],"m":[{"r":65537,"p":[{"n":"_","p":0}],"n":"UpdateApplication","d":976414,"h":47245616670,"f":33},{"r":65537,"n":"TriggerOnDeltaApplied","d":976414,"h":51540583966,"f":8}],"l":[{"t":976414,"n":"Default","d":976414,"h":4295943710,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":976414,"h":55835551262,"f":1}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnDeltaApplied","d":976414,"h":34360714782,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnDeltaApplied","d":976414,"h":38655682078,"f":1},"n":"OnDeltaApplied","d":976414,"h":42950649374,"f":1}],"h":976414}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `HotReloadManager`; }
        });
        
        $asm.$cls("$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions", ($self) => class CascadingAuthenticationStateServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddCascadingAuthenticationState(/*this IServiceCollection*/ serviceCollection)
            {
                return $.$mac.Microsoft.Extensions.DependencyInjection.CascadingValueServiceCollectionExtensions.AddCascadingValue$2($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState), serviceCollection, new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))))().$ctor(this,  (/*services*/ services) =>
                {
                    /*var*/ let authenticationStateProvider = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider, services);
                    return new $.$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource().$ctor$5(authenticationStateProvider);
                }, {"r":$.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)).$h,"p":[{"n":"services","p":327717}],"n":"","d":1107486,"h":0,"f":1048578}));
            }
            static $_AuthenticationStateCascadingValueSource;
            static get AuthenticationStateCascadingValueSource()
            {
                let $cls = $.$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions;
                return $cls.$_AuthenticationStateCascadingValueSource ??= $asm.$ncls("$maca.Microsoft.Extensions.DependencyInjection.CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource", ($self) => class AuthenticationStateCascadingValueSource extends $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))
                {
                    /*AuthenticationStateProvider*/ _authenticationStateProvider = null;
                    $ctor$5(/*AuthenticationStateProvider*/ authenticationStateProvider)
                    {
                        super.$ctor$3(new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)))().$ctor(authenticationStateProvider, authenticationStateProvider.GetAuthenticationStateAsync), false);
                        {
                            this._authenticationStateProvider = authenticationStateProvider;
                            this._authenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                        }
                        return this;
                    }
                    /*void */ HandleAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
                    {
                        _ = this.NotifyChangedAsync$1(newAuthStateTask);
                    }
                    /*void */ Dispose()
                    {
                        this._authenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.HandleAuthenticationStateChanged));
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 1173022;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"newAuthStateTask","p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"HandleAuthenticationStateChanged","d":1173022,"h":12886074910,"f":2},{"r":65537,"n":"Dispose","d":1173022,"h":17181042206,"f":1}],"l":[{"t":386590,"n":"_authenticationStateProvider","d":1173022,"h":4296140318,"f":2}],"c":[{"p":[{"n":"authenticationStateProvider","p":386590}],"n":".ctor","o":"$ctor$5","d":1173022,"h":8591107614,"f":1}],"i":[2686984,57540609],"d":1107486,"h":1173022}; }
                    static get $b() { return $.$mac.Microsoft.AspNetCore.Components.CascadingValueSource$$($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.ICascadingValueSupplier, $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `CascadingAuthenticationStateServiceCollectionExtensions.AuthenticationStateCascadingValueSource`; }
                }, $cls, ($v) => $cls.$_AuthenticationStateCascadingValueSource = $v);
            }
            static $h = 1107486;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"serviceCollection","p":786435}],"n":"AddCascadingAuthenticationState","d":1107486,"h":4296074782,"f":33}],"j":[1173022],"h":1107486}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `CascadingAuthenticationStateServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache", ($self) => class AttributeAuthorizeDataCache
        {
            /*Static constructor*/ static $cctor()
            {
                if ($.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$maca.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$spc.System.Action().$ctor($.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache, $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.ClearCache));
                }
            }
            /*ConcurrentDictionary<Type, IAuthorizeData[]?>*/ static _cache = null;
            static /*void */ ClearCache()
            {
                return $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.Clear();
            }
            static /*IAuthorizeData[]? */ GetAuthorizeDataForType(/*Type*/ type)
            {
                /*var*/ let result;
                if (!$.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.TryGetValue(type, $.$ref(() => result, ($v) => result = $v, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData))))
                {
                    result = $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.ComputeAuthorizeDataForType(type);
                    $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache._cache.set_Item(type, result);
                }
                return result;
            }
            static /*IAuthorizeData[]? */ ComputeAuthorizeDataForType(/*Type*/ type)
            {
                /*var*/ let allAttributes = type.GetCustomAttributes(true);
                /*List<IAuthorizeData>?*/ let authorizeDatas = null;
                for(/*var*/ let i = 0; i < allAttributes.length; i++)
                {
                    if ($.$is($.$spc.System.Array.$ReadT1.call(allAttributes, i), $.$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous))
                    {
                        return null;
                    }
                    let authorizeData;
                    if ($.$is($.$spc.System.Array.$ReadT1.call(allAttributes, i), $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData, { set $v(v){ authorizeData = v; } }))
                    {
                        authorizeDatas ??= new ($.$spc.System.Collections.Generic.List$$($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData))().$ctor$1();
                        authorizeDatas.Add(authorizeData);
                    }
                }
                return authorizeDatas?.ToArray();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData)))().$ctor$1();
                }
            }
            static $h = 124446;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ClearCache","d":124446,"h":12885026334,"f":34},{"r":0,"p":[{"n":"type","p":142606337}],"n":"GetAuthorizeDataForType","d":124446,"h":17179993630,"f":33},{"r":0,"p":[{"n":"type","p":142606337}],"n":"ComputeAuthorizeDataForType","d":124446,"h":21474960926,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$typeArray($.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData)).$h,"n":"_cache","d":124446,"h":8590059038,"f":34}],"h":124446}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AttributeAuthorizeDataCache`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter", ($self) => class AuthorizeDataAdapter extends $.$spc.System.Object
        {
            /*AuthorizeView*/ _component = null;
            $ctor$1(/*AuthorizeView*/ component)
            {
                super.$ctor();
                {
                    this._component = $.$firstOf(component, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("component") });
                }
                return this;
            }
            /*string? */ get Policy()
            {
                return this._component.Policy;
            }
            /*string? */ set Policy(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*string? */ get Roles()
            {
                return this._component.Roles;
            }
            /*string? */ set Roles(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*string? */ get AuthenticationSchemes()
            {
                return null;
            }
            /*string? */ set AuthenticationSchemes(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy()
            {
                return this.Policy;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Policy.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy(value)
            {
                this.Policy = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles()
            {
                return this.Roles;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.Roles.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles(value)
            {
                this.Roles = value;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.get
            get Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes()
            {
                return this.AuthenticationSchemes;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizeData.AuthenticationSchemes.set
            set Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes(value)
            {
                this.AuthenticationSchemes = value;
            }
            static $h = 452126;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180321310,"f":1},"s":{"r":0,"d":0,"h":21475288606,"f":1},"n":"Policy","d":452126,"h":12885354014,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065223198,"f":1},"s":{"r":0,"d":0,"h":34360190494,"f":1},"n":"Roles","d":452126,"h":25770255902,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950125086,"f":1},"s":{"r":0,"d":0,"h":47245092382,"f":1},"n":"AuthenticationSchemes","d":452126,"h":38655157790,"f":1}],"l":[{"t":648734,"n":"_component","d":452126,"h":4295419422,"f":2}],"c":[{"p":[{"n":"component","p":648734}],"n":".ctor","o":"$ctor$1","d":452126,"h":8590386718,"f":1}],"i":[169926],"h":452126}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData ]; }
            static get $fullName() { return `AuthorizeDataAdapter`; }
        });
        
        $asm.$cls("$maca.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1041950;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":1041950,"h":4296009246,"f":1}],"h":1041950}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$maca.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1238558;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":1238558,"h":4296205854,"f":1}],"h":1238558,"a":[{"t":1041950,"c":4296009246},{"t":14680065,"c":21489516545,"a":[{"v":4,"t":14614529}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$str("$maca.Microsoft.AspNetCore.Components.Authorization.ClaimData", ($self) => class ClaimData extends $.$spc.System.ValueType
        {
            $ctor$2(/*string*/ type, /*string*/ value)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                    this.Value = value;
                }
                return this;
            }
            $ctor$3(/*Claim*/ claim)
            {
                this.$ctor$2(claim.Type, claim.Value);
                {
                }
                return this;
            }
            /*string*/ Type = null;
            /*string*/ Value = null;
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Type = this.Type;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 845342;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475681822,"f":1},"n":"Type","d":845342,"h":17180714526,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360583710,"f":1},"n":"Value","d":845342,"h":30065616414,"f":1}],"c":[{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$2","d":845342,"h":4295812638,"f":1,"a":[{"t":13080237,"c":4308047533}]},{"p":[{"n":"claim","p":185019}],"n":".ctor","o":"$ctor$3","d":845342,"h":8590779934,"f":1},{"n":".ctor","o":"$ctor$4","d":845342,"h":38655551006,"f":1}],"h":845342}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `ClaimData`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState", ($self) => class CascadingAuthenticationState extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$mac.Microsoft.AspNetCore.Components.CascadingValue$$($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState)), 0);
                __builder.AddComponentParameter(1, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState), this._currentAuthenticationStateTask));
                __builder.AddComponentParameter(2, "ChildContent", (this.ChildContent));
                __builder.CloseComponent();
            }
            /*Task<AuthenticationState>?*/ _currentAuthenticationStateTask = null;
            /*RenderFragment?*/ ChildContent = null;
            /*void */ OnInitialized()
            {
                this.AuthenticationStateProvider.add_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
                this._currentAuthenticationStateTask = this.AuthenticationStateProvider.GetAuthenticationStateAsync();
            }
            /*void */ OnAuthenticationStateChanged(/*Task<AuthenticationState>*/ newAuthStateTask)
            {
                _ = this.InvokeAsync(new $.$spc.System.Action().$ctor(this,  () =>
                {
                    this._currentAuthenticationStateTask = newAuthStateTask;
                    this.StateHasChanged();
                }, {"r":65537,"n":"","d":779806,"h":0,"f":1048578}));
            }
            /*void */ System$IDisposable$Dispose()
            {
                this.AuthenticationStateProvider.remove_AuthenticationStateChanged(new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler().$ctor(this, this.OnAuthenticationStateChanged));
            }
            /*AuthenticationStateProvider*/ AuthenticationStateProvider = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AuthenticationStateProvider = null;
            }
            static $h = 779806;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":6881288,"g":{"r":0,"d":0,"h":21475616286,"f":1},"s":{"r":0,"d":0,"h":25770583582,"f":1},"n":"ChildContent","d":779806,"h":17180648990,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":386590,"g":{"r":0,"d":0,"h":51540387358,"f":2},"s":{"r":0,"d":0,"h":55835354654,"f":2},"n":"AuthenticationStateProvider","d":779806,"h":47245420062,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":779806,"h":4295747102,"f":32772},{"r":65537,"n":"OnInitialized","d":779806,"h":30065550878,"f":32772},{"r":65537,"p":[{"n":"newAuthStateTask","p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"OnAuthenticationStateChanged","d":779806,"h":34360518174,"f":2}],"l":[{"t":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_currentAuthenticationStateTask","d":779806,"h":8590714398,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":779806,"h":60130321950,"f":1}],"i":[2752520,3145736,3080200,57540609],"h":779806}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationStateChangedHandler", ($self) => class AuthenticationStateChangedHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ task)
            {
                return this.$nativeFunction.call(this.$target, task);
            }
            static $h = 255518;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"task","p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h}],"n":"Invoke","d":255518,"h":8590190110,"f":129},{"r":57016321,"p":[{"n":"task","p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":255518,"h":12885157406,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":255518,"h":17180124702,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":255518,"h":4295222814,"f":1}],"i":[57212929,113377281],"h":255518}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `AuthenticationStateChangedHandler`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeView", ($self) => class AuthorizeView extends $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore
        {
            /*IAuthorizeData[]*/ selfAsAuthorizeData = null;
            $ctor$3()
            {
                super.$ctor$2();
                {
                    this.selfAsAuthorizeData = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter), [new $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeDataAdapter().$ctor$1(this)], null, null);
                }
                return this;
            }
            /*string?*/ Policy = null;
            /*string?*/ Roles = null;
            /*IAuthorizeData[] */ GetAuthorizeData()
            {
                return this.selfAsAuthorizeData;
            }
            static $h = 648734;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":714270,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475485214,"f":1},"s":{"r":0,"d":0,"h":25770452510,"f":1},"n":"Policy","d":648734,"h":17180517918,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655354398,"f":1},"s":{"r":0,"d":0,"h":42950321694,"f":1},"n":"Roles","d":648734,"h":34360387102,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":0,"n":"GetAuthorizeData","d":648734,"h":47245288990,"f":32772}],"l":[{"t":0,"n":"selfAsAuthorizeData","d":648734,"h":4295616030,"f":2}],"c":[{"n":".ctor","o":"$ctor$3","d":648734,"h":8590583326,"f":1}],"i":[2752520,3145736,3080200],"h":648734}; }
            static get $b() { return $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `AuthorizeView`; }
        });
        
        $asm.$cls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView", ($self) => class AuthorizeRouteView extends $.$mac.Microsoft.AspNetCore.Components.RouteView
        {
            /*RenderFragment<AuthenticationState>*/ static _defaultNotAuthorizedContent = null;
            /*RenderFragment*/ static _defaultAuthorizingContent = null;
            /*RenderFragment*/ _renderAuthorizeRouteViewCoreDelegate = null;
            /*RenderFragment<AuthenticationState>*/ _renderAuthorizedDelegate = null;
            /*RenderFragment<AuthenticationState>*/ _renderNotAuthorizedDelegate = null;
            /*RenderFragment*/ _renderAuthorizingDelegate = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    /*RenderFragment*/ let renderBaseRouteViewDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(super, super.Render);
                    this._renderAuthorizedDelegate = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/*authenticateState*/ authenticateState) =>
                    {
                        return renderBaseRouteViewDelegate;
                    }, {"r":6881288,"p":[{"n":"authenticateState","p":189982}],"n":"","d":517662,"h":0,"f":1048578});
                    this._renderNotAuthorizedDelegate = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/*authenticationState*/ authenticationState) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return this.RenderNotAuthorizedInDefaultLayout(builder, authenticationState);
                        }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":517662,"h":0,"f":1048578});
                    }, {"r":6881288,"p":[{"n":"authenticationState","p":189982}],"n":"","d":517662,"h":0,"f":1048578});
                    this._renderAuthorizingDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderAuthorizingInDefaultLayout);
                    this._renderAuthorizeRouteViewCoreDelegate = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderAuthorizeRouteViewCore);
                }
                return this;
            }
            /*RenderFragment<AuthenticationState>?*/ NotAuthorized = null;
            /*RenderFragment?*/ Authorizing = null;
            /*object?*/ Resource = null;
            /*Task<AuthenticationState>?*/ ExistingCascadedAuthenticationState = null;
            /*void */ Render(/*RenderTreeBuilder*/ builder)
            {
                if (this.ExistingCascadedAuthenticationState !== null)
                {
                    this._renderAuthorizeRouteViewCoreDelegate.Invoke(builder);
                }
                else 
                {
                    builder.OpenComponent($.$maca.Microsoft.AspNetCore.Components.Authorization.CascadingAuthenticationState, 0);
                    builder.AddComponentParameter(1, "ChildContent", this._renderAuthorizeRouteViewCoreDelegate);
                    builder.CloseComponent();
                }
            }
            /*void */ RenderAuthorizeRouteViewCore(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenComponent($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView.AuthorizeRouteViewCore, 0);
                builder.AddComponentParameter(1, "RouteData", this.RouteData);
                builder.AddComponentParameter(2, "Authorized", this._renderAuthorizedDelegate);
                builder.AddComponentParameter(3, "Authorizing", this._renderAuthorizingDelegate);
                builder.AddComponentParameter(4, "NotAuthorized", this._renderNotAuthorizedDelegate);
                builder.AddComponentParameter(5, "Resource", this.Resource);
                builder.CloseComponent();
            }
            /*void */ RenderContentInDefaultLayout(/*RenderTreeBuilder*/ builder, /*RenderFragment*/ content)
            {
                builder.OpenComponent($.$mac.Microsoft.AspNetCore.Components.LayoutView, 0);
                builder.AddComponentParameter(1, "Layout", this.DefaultLayout);
                builder.AddComponentParameter(2, "ChildContent", content);
                builder.CloseComponent();
            }
            /*void */ RenderNotAuthorizedInDefaultLayout(/*RenderTreeBuilder*/ builder, /*AuthenticationState*/ authenticationState)
            {
                /*var*/ let content = this.NotAuthorized ?? $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView._defaultNotAuthorizedContent;
                this.RenderContentInDefaultLayout(builder, content.Invoke(authenticationState));
            }
            /*void */ RenderAuthorizingInDefaultLayout(/*RenderTreeBuilder*/ builder)
            {
                /*var*/ let content = this.Authorizing ?? $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView._defaultAuthorizingContent;
                this.RenderContentInDefaultLayout(builder, content);
            }
            static $_AuthorizeRouteViewCore;
            static get AuthorizeRouteViewCore()
            {
                let $cls = $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView;
                return $cls.$_AuthorizeRouteViewCore ??= $asm.$ncls("$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeRouteView.AuthorizeRouteViewCore", ($self) => class AuthorizeRouteViewCore extends $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore
                {
                    /*RouteData*/ RouteData = null;
                    /*IAuthorizeData[]? */ GetAuthorizeData()
                    {
                        return $.$maca.Microsoft.AspNetCore.Components.Authorization.AttributeAuthorizeDataCache.GetAuthorizeDataForType(this.RouteData.PageType);
                    }
                    //default reference type constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.RouteData = null;
                    }
                    static $h = 583198;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":714270,"p":[{"p":9961480,"g":{"r":0,"d":0,"h":12885485086,"f":1},"s":{"r":0,"d":0,"h":17180452382,"f":1},"n":"RouteData","d":583198,"h":8590517790,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":0,"n":"GetAuthorizeData","d":583198,"h":21475419678,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":583198,"h":25770386974,"f":1}],"i":[2752520,3145736,3080200],"d":517662,"h":583198}; }
                    static get $b() { return $.$maca.Microsoft.AspNetCore.Components.Authorization.AuthorizeViewCore; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
                    static get $fullName() { return `AuthorizeRouteView.AuthorizeRouteViewCore`; }
                }, $cls, ($v) => $cls.$_AuthorizeRouteViewCore = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._defaultNotAuthorizedContent = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState))().$ctor(this,  (/*state*/ state) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                            return builder.AddContent(0, "Not authorized");
                        }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":517662,"h":0,"f":1048578});
                    }, {"r":6881288,"p":[{"n":"state","p":189982}],"n":"","d":517662,"h":0,"f":1048578});
                }
                {
                    this._defaultAuthorizingContent = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        return builder.AddContent(0, "Authorizing...");
                    }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":517662,"h":0,"f":1048578});
                }
            }
            static $h = 517662;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":10223624,"p":[{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":42950190622,"f":1},"s":{"r":0,"d":0,"h":47245157918,"f":1},"n":"NotAuthorized","d":517662,"h":38655223326,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":6881288,"g":{"r":0,"d":0,"h":60130059806,"f":1},"s":{"r":0,"d":0,"h":64425027102,"f":1},"n":"Authorizing","d":517662,"h":55835092510,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":131073,"g":{"r":0,"d":0,"h":77309928990,"f":1},"s":{"r":0,"d":0,"h":81604896286,"f":1},"n":"Resource","d":517662,"h":73014961694,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$spc.System.Threading.Tasks.Task$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"g":{"r":0,"d":0,"h":94489798174,"f":2},"s":{"r":0,"d":0,"h":98784765470,"f":2},"n":"ExistingCascadedAuthenticationState","d":517662,"h":90194830878,"f":2,"a":[{"t":524296,"c":21475360776}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"Render","d":517662,"h":103079732766,"f":32772},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"RenderAuthorizeRouteViewCore","d":517662,"h":107374700062,"f":2},{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"content","p":6881288}],"n":"RenderContentInDefaultLayout","d":517662,"h":111669667358,"f":2},{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"authenticationState","p":189982}],"n":"RenderNotAuthorizedInDefaultLayout","d":517662,"h":115964634654,"f":2},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"RenderAuthorizingInDefaultLayout","d":517662,"h":120259601950,"f":2}],"l":[{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_defaultNotAuthorizedContent","d":517662,"h":4295484958,"f":34},{"t":6881288,"n":"_defaultAuthorizingContent","d":517662,"h":8590452254,"f":34},{"t":6881288,"n":"_renderAuthorizeRouteViewCoreDelegate","d":517662,"h":12885419550,"f":2},{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_renderAuthorizedDelegate","d":517662,"h":17180386846,"f":2},{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$maca.Microsoft.AspNetCore.Components.Authorization.AuthenticationState).$h,"n":"_renderNotAuthorizedDelegate","d":517662,"h":21475354142,"f":2},{"t":6881288,"n":"_renderAuthorizingDelegate","d":517662,"h":25770321438,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":517662,"h":30065288734,"f":1}],"i":[2752520],"j":[583198],"h":517662}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.RouteView; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent ]; }
            static get $fullName() { return `AuthorizeRouteView`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.AspNetCore.Authorization"))