
(function ($global, $, $spc, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Forms", 
    {"h":10,"f":"Microsoft.AspNetCore.Components.Forms","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Forms and validation support for Blazor applications.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft.AspNetCore.Components.Forms","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"Microsoft.AspNetCore.Components.Forms","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.AspNetCore.Components.Forms.Tests","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":78512129,"c":4373479425,"a":[{"v":1114122,"t":142606337}]},{"t":78512129,"c":4373479425,"a":[{"v":196618,"t":142606337}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore", ($self) => class ValidationMessageStore extends $.$spc.System.Object
        {
            /*EditContext*/ _editContext = null;
            /*Dictionary<FieldIdentifier, List<string>>*/ _messages = null;
            $ctor$1(/*EditContext*/ editContext)
            {
                super.$ctor();
                {
                    this._editContext = $.$firstOf(editContext, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("editContext") });
                }
                return this;
            }
            /*void */ Add(/*in FieldIdentifier*/ fieldIdentifier, /*string*/ message)
            {
                return this.GetOrCreateMessagesListForField(fieldIdentifier).Add(message);
            }
            /*void */ Add$1(/*Expression<Func<object>>*/ accessor, /*string*/ message)
            {
                return this.Add($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$spc.System.Object, accessor), ), message);
            }
            /*void */ Add$2(/*in FieldIdentifier*/ fieldIdentifier, /*IEnumerable<string>*/ messages)
            {
                return this.GetOrCreateMessagesListForField(fieldIdentifier).AddRange(messages);
            }
            /*void */ Add$3(/*Expression<Func<object>>*/ accessor, /*IEnumerable<string>*/ messages)
            {
                return this.Add$2($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$spc.System.Object, accessor), ), messages);
            }
            /*IEnumerable<string>*/ get_Item(/*FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let messages;
                return this._messages.TryGetValue(fieldIdentifier, $.$ref(() => messages, ($v) => messages = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.String))) ? messages : $.$spc.System.Array.Empty($.$spc.System.String);
        ;
            }
            /*IEnumerable<string>*/ get_Item$1(/*Expression<Func<object>>*/ accessor)
            {
                return this.get_Item($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$spc.System.Object, accessor));
        ;
            }
            /*void */ Clear()
            {
                var $en2 = this._messages.Keys.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var fieldIdentifier = $en2.Current;
                    {
                        this.DissociateFromField($.$ref(() => fieldIdentifier, ));
                    }
                }
                this._messages.Clear();
            }
            /*void */ Clear$1(/*Expression<Func<object>>*/ accessor)
            {
                return this.Clear$2($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$spc.System.Object, accessor), ));
            }
            /*void */ Clear$2(/*in FieldIdentifier*/ fieldIdentifier)
            {
                this.DissociateFromField(fieldIdentifier);
                this._messages.Remove(fieldIdentifier.$v);
            }
            /*List<string> */ GetOrCreateMessagesListForField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let messagesForField;
                if (!this._messages.TryGetValue(fieldIdentifier.$v, $.$ref(() => messagesForField, ($v) => messagesForField = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.String))))
                {
                    messagesForField = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                    this._messages.Add(fieldIdentifier.$v, messagesForField);
                    this.AssociateWithField(fieldIdentifier);
                }
                return messagesForField;
            }
            /*void */ AssociateWithField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                return this._editContext.GetOrAddFieldState(fieldIdentifier).AssociateWithValidationMessageStore(this);
            }
            /*void */ DissociateFromField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                return (this._editContext.GetFieldState(fieldIdentifier)?.DissociateFromValidationMessageStore(this) ?? null);
            }
            //default member initializer
            constructor()
            {
                super();
                this._messages = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$spc.System.Collections.Generic.List$$($.$spc.System.String)))().$ctor$1();
            }
            static $h = 917514;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"i":[{"n":"fieldIdentifier","p":655370}],"g":{"r":0,"d":0,"h":38655623178,"f":1},"n":"Item","o":"@$2","d":917514,"h":34360655882,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"i":[{"n":"accessor","p":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$($.$spc.System.Object)).$h}],"g":{"r":0,"d":0,"h":47245557770,"f":1},"n":"Item","o":"@$3","d":917514,"h":42950590474,"f":1}],"m":[{"r":65537,"p":[{"n":"fieldIdentifier","p":655370,"f":8},{"n":"message","p":1310721}],"n":"Add","d":917514,"h":17180786698,"f":1},{"r":65537,"p":[{"n":"accessor","p":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$($.$spc.System.Object)).$h},{"n":"message","p":1310721}],"n":"Add","o":"@$1","d":917514,"h":21475753994,"f":1},{"r":65537,"p":[{"n":"fieldIdentifier","p":655370,"f":8},{"n":"messages","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Add","o":"@$2","d":917514,"h":25770721290,"f":1},{"r":65537,"p":[{"n":"accessor","p":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$($.$spc.System.Object)).$h},{"n":"messages","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Add","o":"@$3","d":917514,"h":30065688586,"f":1},{"r":65537,"n":"Clear","d":917514,"h":51540525066,"f":1},{"r":65537,"p":[{"n":"accessor","p":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$($.$spc.System.Object)).$h}],"n":"Clear","o":"@$1","d":917514,"h":55835492362,"f":1},{"r":65537,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"Clear","o":"@$2","d":917514,"h":60130459658,"f":1},{"r":$.$spc.System.Collections.Generic.List$$($.$spc.System.String).$h,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"GetOrCreateMessagesListForField","d":917514,"h":64425426954,"f":2},{"r":65537,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"AssociateWithField","d":917514,"h":68720394250,"f":2},{"r":65537,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"DissociateFromField","d":917514,"h":73015361546,"f":2}],"l":[{"t":131082,"n":"_editContext","d":917514,"h":4295884810,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$spc.System.Collections.Generic.List$$($.$spc.System.String)).$h,"n":"_messages","d":917514,"h":8590852106,"f":2}],"c":[{"p":[{"n":"editContext","p":131082}],"n":".ctor","o":"$ctor$1","d":917514,"h":12885819402,"f":1}],"h":917514}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ValidationMessageStore`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.EditContextProperties", ($self) => class EditContextProperties extends $.$spc.System.Object
        {
            /*Dictionary<object, object>?*/ _contents = null;
            /*object*/ get_Item(/*object*/ key)
            {
                return this._contents === null ? (() =>
                {
        throw new $.$spc.System.Collections.Generic.KeyNotFoundException().$ctor$9()        })() : this._contents.get_Item(key);
            }
            /*void*/ set_Item(/*object*/ key, /*object*/ value)
            {
                this._contents ??= new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$1();
                this._contents.set_Item(key, value);
            }
            /*bool */ TryGetValue(/*object*/ key, /*out object?*/ value)
            {
                if (this._contents === null)
                {
                    value.$v = null;
                    return false;
                }
                else 
                {
                    return this._contents.TryGetValue(key, value);
                }
            }
            /*bool */ Remove(/*object*/ key)
            {
                return (this._contents?.Remove(key) ?? null) ?? false;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 327690;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":12885229578,"f":1},"s":{"r":0,"d":0,"h":17180196874,"f":1},"n":"Item","o":"@$2","d":327690,"h":8590262282,"f":1}],"m":[{"r":262145,"p":[{"n":"key","p":131073},{"n":"value","p":131073,"f":2}],"n":"TryGetValue","d":327690,"h":21475164170,"f":1},{"r":262145,"p":[{"n":"key","p":131073}],"n":"Remove","d":327690,"h":25770131466,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h,"n":"_contents","d":327690,"h":4295294986,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":327690,"h":30065098762,"f":1}],"h":327690}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `EditContextProperties`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.FieldState", ($self) => class FieldState extends $.$spc.System.Object
        {
            /*FieldIdentifier*/ _fieldIdentifier;
            /*HashSet<ValidationMessageStore>?*/ _validationMessageStores = null;
            $ctor$1(/*FieldIdentifier*/ fieldIdentifier)
            {
                super.$ctor();
                {
                    this._fieldIdentifier = fieldIdentifier;
                }
                return this;
            }
            /*bool*/ IsModified = false;
            /*IEnumerable<string> */ GetValidationMessages()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this._validationMessageStores !== null)
                    {
                        var $en4 = this._validationMessageStores.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var store = $en4.Current;
                            {
                                var $en6 = store.get_Item(this._fieldIdentifier).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var message = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        yield message;
                                    }
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*void */ AssociateWithValidationMessageStore(/*ValidationMessageStore*/ validationMessageStore)
            {
                if (this._validationMessageStores === null)
                {
                    this._validationMessageStores = new ($.$spc.System.Collections.Generic.HashSet$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore))().$ctor$1();
                }
                this._validationMessageStores.Add(validationMessageStore);
            }
            /*void */ DissociateFromValidationMessageStore(/*ValidationMessageStore*/ validationMessageStore)
            {
                return (this._validationMessageStores?.Remove(validationMessageStore) ?? null);
            }
            //default member initializer
            constructor()
            {
                super();
                this._fieldIdentifier = $.$default($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier);
                this.IsModified = false;
            }
            static $h = 720906;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770524682,"f":1},"s":{"r":0,"d":0,"h":30065491978,"f":1},"n":"IsModified","d":720906,"h":21475557386,"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"n":"GetValidationMessages","d":720906,"h":34360459274,"f":1},{"r":65537,"p":[{"n":"validationMessageStore","p":917514}],"n":"AssociateWithValidationMessageStore","d":720906,"h":38655426570,"f":1},{"r":65537,"p":[{"n":"validationMessageStore","p":917514}],"n":"DissociateFromValidationMessageStore","d":720906,"h":42950393866,"f":1}],"l":[{"t":655370,"n":"_fieldIdentifier","d":720906,"h":4295688202,"f":2},{"t":$.$spc.System.Collections.Generic.HashSet$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore).$h,"n":"_validationMessageStores","d":720906,"h":8590655498,"f":2}],"c":[{"p":[{"n":"fieldIdentifier","p":655370}],"n":".ctor","o":"$ctor$1","d":720906,"h":12885622794,"f":1}],"h":720906}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `FieldState`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager", ($self) => class HotReloadManager extends $.$spc.System.Object
        {
            /*HotReloadManager*/ static Default = null;
            /*bool*/ MetadataUpdateSupported = false;
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            /*Action?*/ OnDeltaApplied = null;
            add_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$spc.System.Delegate.Combine(this.OnDeltaApplied, value);
            }
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$spc.System.Delegate.Remove(this.OnDeltaApplied, value);
            }
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                return ($.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
            }
            /*void */ TriggerOnDeltaApplied()
            {
                return (this.OnDeltaApplied?.Invoke() ?? null);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataUpdateSupported = $.$spc.System.Reflection.Metadata.MetadataUpdater.IsSupported;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager().$ctor$1();
                }
            }
            static $h = 1114122;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180983306,"f":1},"s":{"r":0,"d":0,"h":21475950602,"f":1},"n":"MetadataUpdateSupported","d":1114122,"h":12886016010,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065885194,"f":1},"n":"IsSubscribedTo","d":1114122,"h":25770917898,"f":1}],"m":[{"r":65537,"p":[{"n":"_","p":0}],"n":"UpdateApplication","d":1114122,"h":47245754378,"f":33},{"r":65537,"n":"TriggerOnDeltaApplied","d":1114122,"h":51540721674,"f":8}],"l":[{"t":1114122,"n":"Default","d":1114122,"h":4296081418,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1114122,"h":55835688970,"f":1}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnDeltaApplied","d":1114122,"h":34360852490,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnDeltaApplied","d":1114122,"h":38655819786,"f":1},"n":"OnDeltaApplied","d":1114122,"h":42950787082,"f":1}],"h":1114122}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `HotReloadManager`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter", ($self) => class ExpressionFormatter
        {
            /*Static constructor*/ static $cctor()
            {
                if ($.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$spc.System.Action().$ctor($.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.ClearCache));
                }
            }
            /*int*/ static StackAllocBufferSize = 128;
            static $_CapturedValueFormatter;
            static get CapturedValueFormatter()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter;
                return $cls.$_CapturedValueFormatter ??= $asm.$ncls("$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter", ($self) => class CapturedValueFormatter extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/*$.$spc.System.Object*/ closure, /**/ builder)
                    {
                        return this.$nativeFunction.call(this.$target, closure, builder);
                    }
                    static $h = 458762;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786442,"f":4}],"n":"Invoke","d":458762,"h":8590393354,"f":129},{"r":57016321,"p":[{"n":"closure","p":131073},{"n":"builder","p":786442,"f":4},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":458762,"h":12885360650,"f":129},{"r":65537,"p":[{"n":"builder","p":786442,"f":4},{"n":"result","p":57016321}],"n":"EndInvoke","d":458762,"h":17180327946,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":458762,"h":4295426058,"f":1}],"i":[57212929,113377281],"d":393226,"h":458762}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `ExpressionFormatter.CapturedValueFormatter`; }
                }, $cls, ($v) => $cls.$_CapturedValueFormatter = $v);
            }
            /*ConcurrentDictionary<MemberInfo, CapturedValueFormatter>*/ static s_capturedValueFormatterCache = null;
            /*ConcurrentDictionary<MethodInfo, MethodInfoData>*/ static s_methodInfoDataCache = null;
            static /*void */ ClearCache()
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.Clear();
                $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.Clear();
            }
            static /*string */ FormatLambda(/*LambdaExpression*/ expression)
            {
                return $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatLambda$1(expression, null);
            }
            static /*string */ FormatLambda$1(/*LambdaExpression*/ expression, /*string?*/ prefix)
            {
                /*var*/ let builder = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder().$ctor$3($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128/*StackAllocBufferSize*/, null));
                /*var*/ let node = expression.Body;
                /*var*/ let wasLastExpressionMemberAccess = false;
                /*var*/ let wasLastExpressionIndexer = false;
                while(!(node === null))
                {
                    let $switch1 = node.NodeType;
                    switch($switch1)
                    {
                        case 9/*ExpressionType.Constant*/:
                        /*var*/ let constantExpression = $.$cast(node, $.$sle.System.Linq.Expressions.ConstantExpression);
                        node = null;
                        break;
                        case 6/*ExpressionType.Call*/:
                        /*var*/ let methodCallExpression = $.$cast(node, $.$sle.System.Linq.Expressions.MethodCallExpression);
                        if (!$.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.IsSingleArgumentIndexer(methodCallExpression))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("Method calls cannot be formatted.");
                        }
                        node = methodCallExpression.Object;
                        if ($.$spc.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront($.$spc.System.String.op_Implicit("."));
                        }
                        wasLastExpressionIndexer = true;
                        builder.InsertFront($.$spc.System.String.op_Implicit("]"));
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(methodCallExpression.Arguments.get_Item(0), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                        builder.InsertFront($.$spc.System.String.op_Implicit("["));
                        break;
                        case 5/*ExpressionType.ArrayIndex*/:
                        /*var*/ let binaryExpression = $.$cast(node, $.$sle.System.Linq.Expressions.BinaryExpression);
                        node = binaryExpression.Left;
                        if ($.$spc.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront($.$spc.System.String.op_Implicit("."));
                        }
                        builder.InsertFront($.$spc.System.String.op_Implicit("]"));
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(binaryExpression.Right, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                        builder.InsertFront($.$spc.System.String.op_Implicit("["));
                        wasLastExpressionIndexer = true;
                        break;
                        case 23/*ExpressionType.MemberAccess*/:
                        /*var*/ let memberExpression = $.$cast(node, $.$sle.System.Linq.Expressions.MemberExpression);
                        node = memberExpression.Expression;
                        if ($.$spc.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            builder.InsertFront($.$spc.System.String.op_Implicit("."));
                        }
                        wasLastExpressionMemberAccess = true;
                        wasLastExpressionIndexer = false;
                        /*var*/ let name = ($.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$6($.$srsp.System.Runtime.Serialization.DataMemberAttribute, memberExpression.Member)?.Name ?? null) ?? memberExpression.Member.Name;
                        builder.InsertFront($.$spc.System.String.op_Implicit(name));
                        break;
                        default:
                        node = null;
                        break;
                    }
                }
                if ($.$spc.System.String.op_Inequality(prefix, null))
                {
                    if (!builder.Empty && !wasLastExpressionIndexer)
                    {
                        builder.InsertFront($.$spc.System.String.op_Implicit("."));
                    }
                    builder.InsertFront($.$spc.System.String.op_Implicit(prefix));
                }
                /*var*/ let result = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.call(builder);
                builder.Dispose();
                return result;
            }
            static /*bool */ IsSingleArgumentIndexer(/*Expression*/ expression)
            {
                let methodExpression;
                if (!$.$is(expression, $.$sle.System.Linq.Expressions.MethodCallExpression, { set $v(v){ methodExpression = v; } }) || methodExpression.Arguments.Count !== 1)
                {
                    return false;
                }
                /*var*/ let methodInfoData = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.GetOrCreateMethodInfoData(methodExpression.Method);
                return methodInfoData.IsSingleArgumentIndexer;
            }
            static /*MethodInfoData */ GetOrCreateMethodInfoData(/*MethodInfo*/ methodInfo)
            {
                /*var*/ let methodInfoData;
                if (!$.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.TryGetValue(methodInfo, $.$ref(() => methodInfoData, ($v) => methodInfoData = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData)))
                {
                    methodInfoData = GetMethodInfoData(methodInfo);
                    $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.set_Item(methodInfo, methodInfoData);
                }
                return methodInfoData;
                /*static MethodInfoData*/  function GetMethodInfoData(/*MethodInfo*/ methodInfo)
                {
                    /*var*/ let declaringType = methodInfo.DeclaringType;
                    if (declaringType === null)
                    {
                        return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$2(false);
                    }
                    /*var*/ let defaultMember = $.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$10($.$spc.System.Reflection.DefaultMemberAttribute, declaringType, true);
                    if (defaultMember === null)
                    {
                        return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$2(false);
                    }
                    /*var*/ let runtimeProperties = $.$spc.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperties(declaringType);
                    if (runtimeProperties === null)
                    {
                        return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$2(false);
                    }
                    var $en3 = runtimeProperties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var property = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.Equals$5(defaultMember.MemberName, property.Name, 4/*StringComparison.Ordinal*/) && $.$spc.System.Reflection.MethodInfo.op_Equality$2(property.GetMethod, methodInfo))
                            {
                                return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$2(true);
                            }
                        }
                    }
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$2(false);
                }
            }
            static /*void */ FormatIndexArgument(/*Expression*/ indexExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //switch (indexExpression)
                {
                    let memberExpression;
                    let constantExpression;
                    $switchJumpStart1: 
                    //case MemberExpression memberExpression when memberExpression.Expression is ConstantExpression constantExpression:
                    if ($.$is(indexExpression, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ memberExpression = v; } }) && $.$is(memberExpression.Expression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constantExpression = v; } }))
                    {
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatCapturedValue(memberExpression, constantExpression, builder);
                    }
                    //case ConstantExpression constantExpression:
                    else if ($.$is(indexExpression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constantExpression = v; } }))
                    {
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatConstantValue(constantExpression, builder);
                    }
                    //default
                    else
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`Unable to evaluate index expressions of type '${$.$spc.System.Object.GetType.call(indexExpression).Name}'.`);
                    }
                }
            }
            static /*string */ FormatIndexArgument$1(/*Expression*/ indexExpression)
            {
                /*var*/ let builder = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder().$ctor$3($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128/*StackAllocBufferSize*/, null));
                try
                {
                    $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(indexExpression, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                    /*var*/ let result = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.call(builder);
                    return result;
                }
                finally
                {
                    {
                        builder.Dispose();
                    }
                }
            }
            static /*void */ FormatCapturedValue(/*MemberExpression*/ memberExpression, /*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                /*var*/ let member = memberExpression.Member;
                /*var*/ let format;
                if (!$.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.TryGetValue(member, $.$ref(() => format, ($v) => format = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter)))
                {
                    format = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CreateCapturedValueFormatter(memberExpression);
                    $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.set_Item(member, format);
                }
                format.Invoke(constantExpression.Value, builder);
            }
            static /*CapturedValueFormatter */ CreateCapturedValueFormatter(/*MemberExpression*/ memberExpression)
            {
                /*var*/ let memberType = memberExpression.Type;
                if ($.$spc.System.Type.op_Equality$1(memberType, $.$spc.System.Int32.$type))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$spc.System.Int32, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$1($.$spc.System.Int32, func.Invoke(closure));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786442,"f":4}],"n":"","d":393226,"h":0,"f":1048578});
                }
                else if ($.$spc.System.Type.op_Equality$1(memberType, $.$spc.System.String.$type))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$spc.System.String, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront($.$spc.System.String.op_Implicit(func.Invoke(closure)));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786442,"f":4}],"n":"","d":393226,"h":0,"f":1048578});
                }
                else if ($.$spc.System.ISpanFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$spc.System.ISpanFormattable, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$1($.$spc.System.ISpanFormattable, func.Invoke(closure));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786442,"f":4}],"n":"","d":393226,"h":0,"f":1048578});
                }
                else if ($.$spc.System.IFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$spc.System.IFormattable, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$2(func.Invoke(closure));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786442,"f":4}],"n":"","d":393226,"h":0,"f":1048578});
                }
                else 
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`Cannot format an index argument of type '${$.$spc.System.Type.ToString.call(memberType)}'.`);
                }
                /*static Func<object, TResult>*/  function CompileMemberEvaluator(TResult, /*MemberExpression*/ memberExpression)
                {
                    /*var*/ let parameterExpression = $.$sle.System.Linq.Expressions.Expression.Parameter($.$spc.System.Object.$type);
                    /*var*/ let convertExpression = $.$sle.System.Linq.Expressions.Expression.Convert(parameterExpression, memberExpression.Member.DeclaringType);
                    /*var*/ let replacedMemberExpression = memberExpression.Update(convertExpression);
                    /*var*/ let replacedExpression = $.$sle.System.Linq.Expressions.Expression.Lambda($.$spc.System.Func$$$($.$spc.System.Object, TResult), replacedMemberExpression, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ parameterExpression ], null, null));
                    return replacedExpression.Compile$3();
                }
            }
            static /*void */ FormatConstantValue(/*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //switch (constantExpression.Value)
                let $switch1 = constantExpression.Value;
                {
                    let s;
                    let spanFormattable;
                    let formattable;
                    let x;
                    $switchJumpStart1: 
                    //case string s:
                    if ($.$is($switch1, $.$spc.System.String, { set $v(v){ s = v; } }))
                    {
                        builder.$v.InsertFront($.$spc.System.String.op_Implicit(s));
                    }
                    //case ISpanFormattable spanFormattable:
                    else if ($.$is($switch1, $.$spc.System.ISpanFormattable, { set $v(v){ spanFormattable = v; } }))
                    {
                        builder.$v.InsertFront$1($.$spc.System.ISpanFormattable, spanFormattable);
                    }
                    //case IFormattable formattable:
                    else if ($.$is($switch1, $.$spc.System.IFormattable, { set $v(v){ formattable = v; } }))
                    {
                        builder.$v.InsertFront$2(formattable);
                    }
                    //case null:
                    else if ($switch1 == null)
                    {
                        builder.$v.InsertFront($.$spc.System.String.op_Implicit("null"));
                    }
                    //case var x:
                    else if ($switch1 != null && (x = $switch1))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`Unable to format constant values of type '${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(x))}'.`);
                    }
                }
            }
            static $_MethodInfoData;
            static get MethodInfoData()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter;
                return $cls.$_MethodInfoData ??= $asm.$nstr("$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData", ($self) => class MethodInfoData extends $.$spc.System.ValueType
                {
                    /*bool*/ IsSingleArgumentIndexer = false;
                    $ctor$2(/*bool*/ isSingleArgumentIndexer)
                    {
                        super.$ctor$1();
                        {
                            this.IsSingleArgumentIndexer = isSingleArgumentIndexer;
                        }
                        return this;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsSingleArgumentIndexer = this.IsSingleArgumentIndexer;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsSingleArgumentIndexer = false;
                    }
                    static $h = 524298;
                    static $z = 1;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885426186,"f":1},"n":"IsSingleArgumentIndexer","d":524298,"h":8590458890,"f":1}],"c":[{"p":[{"n":"isSingleArgumentIndexer","p":262145}],"n":".ctor","o":"$ctor$2","d":524298,"h":17180393482,"f":1},{"n":".ctor","o":"$ctor$3","d":524298,"h":21475360778,"f":1}],"d":393226,"h":524298}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `ExpressionFormatter.MethodInfoData`; }
                }, $cls, ($v) => $cls.$_MethodInfoData = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_capturedValueFormatterCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Reflection.MemberInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter))().$ctor$1();
                }
                {
                    this.s_methodInfoDataCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Reflection.MethodInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData))().$ctor$1();
                }
            }
            static $h = 393226;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ClearCache","d":393226,"h":25770197002,"f":33},{"r":1310721,"p":[{"n":"expression","p":38513054}],"n":"FormatLambda","d":393226,"h":30065164298,"f":33},{"r":1310721,"p":[{"n":"expression","p":38513054},{"n":"prefix","p":1310721,"f":65}],"n":"FormatLambda","o":"@$1","d":393226,"h":34360131594,"f":33},{"r":262145,"p":[{"n":"expression","p":8694174}],"n":"IsSingleArgumentIndexer","d":393226,"h":38655098890,"f":40},{"r":524298,"p":[{"n":"methodInfo","p":79626241}],"n":"GetOrCreateMethodInfoData","d":393226,"h":42950066186,"f":34},{"r":65537,"p":[{"n":"indexExpression","p":8694174},{"n":"builder","p":786442,"f":4}],"n":"FormatIndexArgument","d":393226,"h":47245033482,"f":34},{"r":1310721,"p":[{"n":"indexExpression","p":8694174}],"n":"FormatIndexArgument","o":"@$1","d":393226,"h":51540000778,"f":40},{"r":65537,"p":[{"n":"memberExpression","p":38971806},{"n":"constantExpression","p":7776670},{"n":"builder","p":786442,"f":4}],"n":"FormatCapturedValue","d":393226,"h":55834968074,"f":34},{"r":458762,"p":[{"n":"memberExpression","p":38971806}],"n":"CreateCapturedValueFormatter","d":393226,"h":60129935370,"f":34},{"r":65537,"p":[{"n":"constantExpression","p":7776670},{"n":"builder","p":786442,"f":4}],"n":"FormatConstantValue","d":393226,"h":64424902666,"f":34}],"l":[{"t":655361,"n":"StackAllocBufferSize","d":393226,"h":8590327818,"f":40},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Reflection.MemberInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter).$h,"n":"s_capturedValueFormatterCache","d":393226,"h":17180262410,"f":34},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Reflection.MethodInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData).$h,"n":"s_methodInfoDataCache","d":393226,"h":21475229706,"f":34}],"j":[458762,524298],"h":393226}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ExpressionFormatter`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions", ($self) => class EditContextDataAnnotationsExtensions
        {
            static /*EditContext */ AddDataAnnotationsValidation(/*this EditContext*/ editContext)
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.EnableDataAnnotationsValidation(editContext);
                return editContext;
            }
            static /*IDisposable */ EnableDataAnnotationsValidation(/*this EditContext*/ editContext)
            {
                return new $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions().$ctor$1(editContext, null);
            }
            static /*IDisposable */ EnableDataAnnotationsValidation$1(/*this EditContext*/ editContext, /*IServiceProvider*/ serviceProvider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceProvider, "serviceProvider");
                return new $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions().$ctor$1(editContext, serviceProvider);
            }
            /*Action?*/ static OnClearCache = null;
            static add_OnClearCache(/*Action?*/ value)
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache = $.$spc.System.Delegate.Combine($.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache, value);
            }
            static remove_OnClearCache(/*Action?*/ value)
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache = $.$spc.System.Delegate.Remove($.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache, value);
            }
            static /*void */ ClearCache(/*Type[]?*/ _)
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache?.Invoke();
            }
            static $_DataAnnotationsEventSubscriptions;
            static get DataAnnotationsEventSubscriptions()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions;
                return $cls.$_DataAnnotationsEventSubscriptions ??= $asm.$ncls("$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions", ($self) => class DataAnnotationsEventSubscriptions extends $.$spc.System.Object
                {
                    /*ConcurrentDictionary<(Type ModelType, string FieldName), PropertyInfo?>*/ static _propertyInfoCache = null;
                    /*EditContext*/ _editContext = null;
                    /*IServiceProvider?*/ _serviceProvider = null;
                    /*ValidationMessageStore*/ _messages = null;
                    /*ValidationOptions?*/ _validationOptions = null;
                    /*IValidatableInfo?*/ _validatorTypeInfo = null;
                    /*Dictionary<string, FieldIdentifier>*/ _validationPathToFieldIdentifierMapping = null;
                    $ctor$1(/*EditContext*/ editContext, /*IServiceProvider*/ serviceProvider)
                    {
                        super.$ctor();
                        {
                            this._editContext = $.$firstOf(editContext, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("editContext") });
                            this._serviceProvider = serviceProvider;
                            this._messages = new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore().$ctor$1(this._editContext);
                            /*System.IServiceProvider*/ let __ca1__;
                            /*Microsoft.Extensions.Options.IOptions<Microsoft.Extensions.Validation.ValidationOptions>?*/ let __ca2__;
                            this._validationOptions = ((__ca1__ = this._serviceProvider) !== null ? ((__ca2__ = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$meo.Microsoft.Extensions.Options.IOptions$$($.$mev.Microsoft.Extensions.Validation.ValidationOptions), __ca1__)) !== null ? __ca2__.Microsoft$Extensions$Options$IOptions$$$Value : null) : null);
                            /*var*/ let typeInfo;
                            this._validatorTypeInfo = this._validationOptions !== null && this._validationOptions.TryGetValidatableTypeInfo($.$spc.System.Object.GetType.call(this._editContext.Model), $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)) ? typeInfo : null;
                            this._editContext.add_OnFieldChanged(new ($.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs))().$ctor(this, this.OnFieldChanged));
                            this._editContext.add_OnValidationRequested(new ($.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                            if ($.$spc.System.Reflection.Metadata.MetadataUpdater.IsSupported)
                            {
                                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache(new $.$spc.System.Action().$ctor(this, this.ClearCache));
                            }
                        }
                        return this;
                    }
                    /*void */ OnFieldChanged(/*object?*/ sender, /*FieldChangedEventArgs*/ eventArgs)
                    {
                        /*var*/ let fieldIdentifier = eventArgs.FieldIdentifier;
                        /*var*/ let propertyInfo;
                        if ($.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions.TryGetValidatableProperty($.$ref(() => fieldIdentifier, ), $.$ref(() => propertyInfo, ($v) => propertyInfo = $v, $.$spc.System.Reflection.PropertyInfo)))
                        {
                            /*var*/ let propertyValue = propertyInfo.GetValue(fieldIdentifier.Model);
                            /*var*/ let validationContext = (() =>
                            {
                                //new $.$sca.System.ComponentModel.DataAnnotations.ValidationContext()
                                const $t2 = $.$sca.System.ComponentModel.DataAnnotations.ValidationContext;
                                const $i2 = new $t2();
                                $i2.$ctor$3(fieldIdentifier.Model, this._serviceProvider, null);
                                $i2.MemberName = propertyInfo.Name;
                                return $i2;
                            })();
                            /*var*/ let results = new ($.$spc.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult))().$ctor$1();
                            $.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidateProperty(propertyValue, validationContext, results);
                            this._messages.Clear$2($.$ref(() => fieldIdentifier, ));
                            var $en5 = $.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan($.$sca.System.ComponentModel.DataAnnotations.ValidationResult, results).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var result = $en5.Current.$v;
                                {
                                    this._messages.Add($.$ref(() => fieldIdentifier, ), result.ErrorMessage);
                                }
                            }
                            this._editContext.NotifyValidationStateChanged();
                        }
                    }
                    /*void */ OnValidationRequested(/*object?*/ sender, /*ValidationRequestedEventArgs*/ e)
                    {
                        /*var*/ let validationContext = new $.$sca.System.ComponentModel.DataAnnotations.ValidationContext().$ctor$3(this._editContext.Model, this._serviceProvider, null);
                        if (!this.TryValidateTypeInfo(validationContext))
                        {
                            this.ValidateWithDefaultValidator(validationContext);
                        }
                        this._editContext.NotifyValidationStateChanged();
                    }
                    /*void */ ValidateWithDefaultValidator(/*ValidationContext*/ validationContext)
                    {
                        /*var*/ let validationResults = new ($.$spc.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult))().$ctor$1();
                        $.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidateObject$1(this._editContext.Model, validationContext, validationResults, true);
                        this._messages.Clear();
                        var $en4 = validationResults.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var validationResult = $en4.Current;
                            {
                                if (validationResult === null)
                                {
                                    continue;
                                }
                                /*var*/ let hasMemberNames = false;
                                var $en6 = validationResult.MemberNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var memberName = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        hasMemberNames = true;
                                        this._messages.Add($.$ref(() => this._editContext.Field(memberName), ), validationResult.ErrorMessage);
                                    }
                                }
                                if (!hasMemberNames)
                                {
                                    this._messages.Add($.$ref(() => new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$2(this._editContext.Model, $.$spc.System.String.Empty), ), validationResult.ErrorMessage);
                                }
                            }
                        }
                    }
                    /*bool */ TryValidateTypeInfo(/*ValidationContext*/ validationContext)
                    {
                        if (this._validatorTypeInfo === null)
                        {
                            return false;
                        }
                        /*var*/ let validateContext = (() =>
                        {
                            //new $.$mev.Microsoft.Extensions.Validation.ValidateContext()
                            const $t1 = $.$mev.Microsoft.Extensions.Validation.ValidateContext;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.ValidationOptions = this._validationOptions;
                            $i1.ValidationContext = validationContext;
                            return $i1;
                        })();
                        try
                        {
                            validateContext.add_OnValidationError(new ($.$spc.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext))().$ctor(this, this.AddMapping));
                            /*var*/ let validationTask = this._validatorTypeInfo.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(this._editContext.Model, validateContext, $.$spc.System.Threading.CancellationToken.None);
                            if (!validationTask.IsCompleted)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10("Async validation is not supported");
                            }
                            /*var*/ let validationErrors = validateContext.ValidationErrors;
                            this._messages.Clear();
                            if (!(validationErrors === null) && validationErrors.Count > 0)
                            {
                                var $en6 = validationErrors.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    let [ fieldKey, messages ] = $.$destructure($en6.Current);
                                    {
                                        /*var*/ let fieldIdentifier = this._validationPathToFieldIdentifierMapping.get_Item(fieldKey);
                                        this._messages.Add$2($.$ref(() => fieldIdentifier, ), messages);
                                    }
                                }
                            }
                        }
                        catch($e)
                        {
                            throw $e;
                        }
                        finally
                        {
                            {
                                validateContext.remove_OnValidationError(new ($.$spc.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext))().$ctor(this, this.AddMapping));
                                this._validationPathToFieldIdentifierMapping.Clear();
                            }
                        }
                        return true;
                    }
                    /*void */ AddMapping(/*ValidationErrorContext*/ context)
                    {
                        this._validationPathToFieldIdentifierMapping.set_Item(context.Path, new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$2(context.Container ?? this._editContext.Model, context.Name));
                    }
                    /*void */ Dispose()
                    {
                        this._messages.Clear();
                        this._editContext.remove_OnFieldChanged(new ($.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs))().$ctor(this, this.OnFieldChanged));
                        this._editContext.remove_OnValidationRequested(new ($.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                        this._editContext.NotifyValidationStateChanged();
                        if ($.$spc.System.Reflection.Metadata.MetadataUpdater.IsSupported)
                        {
                            $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache(new $.$spc.System.Action().$ctor(this, this.ClearCache));
                        }
                    }
                    static /*bool */ TryGetValidatableProperty(/*in FieldIdentifier*/ fieldIdentifier, /*out PropertyInfo?*/ propertyInfo)
                    {
                        /*var*/ let cacheKey = new ($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.String))().$ctor$2($.$spc.System.Object.GetType.call(fieldIdentifier.$v.Model), fieldIdentifier.$v.FieldName);
                        if (!$.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.TryGetValue(cacheKey.Clone(), propertyInfo))
                        {
                            propertyInfo.$v = cacheKey.Item1.GetProperty(cacheKey.Item2);
                            $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.set_Item(cacheKey.Clone(), propertyInfo.$v);
                        }
                        return $.$spc.System.Reflection.PropertyInfo.op_Inequality$1(propertyInfo.$v, null);
                    }
                    /*void */ ClearCache()
                    {
                        $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.Clear();
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._validationPathToFieldIdentifierMapping = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier))().$ctor$1();
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this._propertyInfoCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.String), $.$spc.System.Reflection.PropertyInfo))().$ctor$1();
                        }
                    }
                    static $h = 262154;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"eventArgs","p":589834}],"n":"OnFieldChanged","d":262154,"h":38654967818,"f":2},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":983050}],"n":"OnValidationRequested","d":262154,"h":42949935114,"f":2},{"r":65537,"p":[{"n":"validationContext","p":3538982}],"n":"ValidateWithDefaultValidator","d":262154,"h":47244902410,"f":2},{"r":262145,"p":[{"n":"validationContext","p":3538982}],"n":"TryValidateTypeInfo","d":262154,"h":51539869706,"f":2},{"r":65537,"p":[{"n":"context","p":851997}],"n":"AddMapping","d":262154,"h":55834837002,"f":2},{"r":65537,"n":"Dispose","d":262154,"h":60129804298,"f":1},{"r":262145,"p":[{"n":"fieldIdentifier","p":655370,"f":8},{"n":"propertyInfo","p":81657857,"f":2}],"n":"TryGetValidatableProperty","d":262154,"h":64424771594,"f":34},{"r":65537,"n":"ClearCache","d":262154,"h":68719738890,"f":8}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.String), $.$spc.System.Reflection.PropertyInfo).$h,"n":"_propertyInfoCache","d":262154,"h":4295229450,"f":34},{"t":131082,"n":"_editContext","d":262154,"h":8590196746,"f":2},{"t":327717,"n":"_serviceProvider","d":262154,"h":12885164042,"f":2},{"t":917514,"n":"_messages","d":262154,"h":17180131338,"f":2},{"t":917533,"n":"_validationOptions","d":262154,"h":21475098634,"f":2},{"t":131101,"n":"_validatorTypeInfo","d":262154,"h":25770065930,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier).$h,"n":"_validationPathToFieldIdentifierMapping","d":262154,"h":30065033226,"f":2}],"c":[{"p":[{"n":"editContext","p":131082},{"n":"serviceProvider","p":327717}],"n":".ctor","o":"$ctor$1","d":262154,"h":34360000522,"f":1}],"i":[57540609],"d":196618,"h":262154}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions`; }
                }, $cls, ($v) => $cls.$_DataAnnotationsEventSubscriptions = $v);
            }
            static $h = 196618;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131082,"p":[{"n":"editContext","p":131082}],"n":"AddDataAnnotationsValidation","d":196618,"h":4295163914,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Use EnableDataAnnotationsValidation instead.","t":1310721}]}]},{"r":57540609,"p":[{"n":"editContext","p":131082}],"n":"EnableDataAnnotationsValidation","d":196618,"h":8590131210,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API is obsolete and may be removed in future versions. Use the overload that accepts an IServiceProvider instead.","t":1310721}]}]},{"r":57540609,"p":[{"n":"editContext","p":131082},{"n":"serviceProvider","p":327717}],"n":"EnableDataAnnotationsValidation","o":"@$1","d":196618,"h":12885098506,"f":33},{"r":65537,"p":[{"n":"_","p":0}],"n":"ClearCache","d":196618,"h":30064967690,"f":34}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnClearCache","d":196618,"h":17180065802,"f":34},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnClearCache","d":196618,"h":21475033098,"f":34},"n":"OnClearCache","d":196618,"h":25770000394,"f":34}],"j":[262154],"h":196618}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `EditContextDataAnnotationsExtensions`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.EditContext", ($self) => class EditContext extends $.$spc.System.Object
        {
            /*Dictionary<FieldIdentifier, FieldState>*/ _fieldStates = null;
            $ctor$1(/*object*/ model)
            {
                super.$ctor();
                {
                    this.Model = $.$firstOf(model, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("model") });
                    this.Properties = new $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextProperties().$ctor$1();
                }
                return this;
            }
            /*EventHandler<FieldChangedEventArgs>?*/ OnFieldChanged = null;
            add_OnFieldChanged(/*EventHandler<FieldChangedEventArgs>?*/ value)
            {
                this.OnFieldChanged = $.$spc.System.Delegate.Combine(this.OnFieldChanged, value);
            }
            remove_OnFieldChanged(/*EventHandler<FieldChangedEventArgs>?*/ value)
            {
                this.OnFieldChanged = $.$spc.System.Delegate.Remove(this.OnFieldChanged, value);
            }
            /*EventHandler<ValidationRequestedEventArgs>?*/ OnValidationRequested = null;
            add_OnValidationRequested(/*EventHandler<ValidationRequestedEventArgs>?*/ value)
            {
                this.OnValidationRequested = $.$spc.System.Delegate.Combine(this.OnValidationRequested, value);
            }
            remove_OnValidationRequested(/*EventHandler<ValidationRequestedEventArgs>?*/ value)
            {
                this.OnValidationRequested = $.$spc.System.Delegate.Remove(this.OnValidationRequested, value);
            }
            /*EventHandler<ValidationStateChangedEventArgs>?*/ OnValidationStateChanged = null;
            add_OnValidationStateChanged(/*EventHandler<ValidationStateChangedEventArgs>?*/ value)
            {
                this.OnValidationStateChanged = $.$spc.System.Delegate.Combine(this.OnValidationStateChanged, value);
            }
            remove_OnValidationStateChanged(/*EventHandler<ValidationStateChangedEventArgs>?*/ value)
            {
                this.OnValidationStateChanged = $.$spc.System.Delegate.Remove(this.OnValidationStateChanged, value);
            }
            /*FieldIdentifier */ Field(/*string*/ fieldName)
            {
                return new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$2(this.Model, fieldName);
            }
            /*object*/ Model = null;
            /*EditContextProperties*/ Properties = null;
            /*bool*/ ShouldUseFieldIdentifiers = false;
            /*void */ NotifyFieldChanged(/*in FieldIdentifier*/ fieldIdentifier)
            {
                this.GetOrAddFieldState(fieldIdentifier).IsModified = true;
                this.OnFieldChanged?.Invoke(this, new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs().$ctor$2(fieldIdentifier));
            }
            /*void */ NotifyValidationStateChanged()
            {
                this.OnValidationStateChanged?.Invoke(this, $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs.Empty);
            }
            /*void */ MarkAsUnmodified(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let state;
                if (this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)))
                {
                    state.IsModified = false;
                }
            }
            /*void */ MarkAsUnmodified$1()
            {
                var $en2 = this._fieldStates.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var state = $en2.Current;
                    {
                        state.Value.IsModified = false;
                    }
                }
            }
            /*bool */ IsModified()
            {
                var $en2 = this._fieldStates.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var state = $en2.Current;
                    {
                        if (state.Value.IsModified)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*IEnumerable<string> */ GetValidationMessages()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = this._fieldStates.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var state = $en3.Current;
                        {
                            var $en5 = state.Value.GetValidationMessages().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var message = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield message;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<string> */ GetValidationMessages$1(/*FieldIdentifier*/ fieldIdentifier)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let state;
                    if (this._fieldStates.TryGetValue(fieldIdentifier, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)))
                    {
                        var $en4 = state.GetValidationMessages().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var message = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                yield message;
                            }
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<string> */ GetValidationMessages$2(/*Expression<Func<object>>*/ accessor)
            {
                return this.GetValidationMessages$1($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$spc.System.Object, accessor));
            }
            /*bool */ IsModified$1(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let state;
                return this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)) ? state.IsModified : false;
            }
            /*bool */ IsModified$2(/*Expression<Func<object>>*/ accessor)
            {
                return this.IsModified$1($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$spc.System.Object, accessor), ));
            }
            /*bool */ IsValid(/*in FieldIdentifier*/ fieldIdentifier)
            {
                return !$.$sl.System.Linq.Enumerable.Any($.$spc.System.String, this.GetValidationMessages$1(fieldIdentifier.$v));
            }
            /*bool */ IsValid$1(/*Expression<Func<object>>*/ accessor)
            {
                return this.IsValid($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$spc.System.Object, accessor), ));
            }
            /*bool */ Validate()
            {
                this.OnValidationRequested?.Invoke(this, $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs.Empty);
                return !$.$sl.System.Linq.Enumerable.Any($.$spc.System.String, this.GetValidationMessages());
            }
            /*FieldState? */ GetFieldState(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let state;
                this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState));
                return state;
            }
            /*FieldState */ GetOrAddFieldState(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let state;
                if (!this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)))
                {
                    state = new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState().$ctor$1(fieldIdentifier.$v);
                    this._fieldStates.Add(fieldIdentifier.$v, state);
                }
                return state;
            }
            //default member initializer
            constructor()
            {
                super();
                this._fieldStates = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState))().$ctor$1();
                this.ShouldUseFieldIdentifiers = !$.$spc.System.OperatingSystem.IsBrowser();
            }
            static $h = 131082;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":64424640522,"f":1},"n":"Model","d":131082,"h":60129673226,"f":1},{"p":327690,"g":{"r":0,"d":0,"h":77309542410,"f":1},"n":"Properties","d":131082,"h":73014575114,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90194444298,"f":1},"s":{"r":0,"d":0,"h":94489411594,"f":1},"n":"ShouldUseFieldIdentifiers","d":131082,"h":85899477002,"f":1}],"m":[{"r":655370,"p":[{"n":"fieldName","p":1310721}],"n":"Field","d":131082,"h":51539738634,"f":1},{"r":65537,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"NotifyFieldChanged","d":131082,"h":98784378890,"f":1},{"r":65537,"n":"NotifyValidationStateChanged","d":131082,"h":103079346186,"f":1},{"r":65537,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"MarkAsUnmodified","d":131082,"h":107374313482,"f":1},{"r":65537,"n":"MarkAsUnmodified","o":"@$1","d":131082,"h":111669280778,"f":1},{"r":262145,"n":"IsModified","d":131082,"h":115964248074,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"n":"GetValidationMessages","d":131082,"h":120259215370,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"p":[{"n":"fieldIdentifier","p":655370}],"n":"GetValidationMessages","o":"@$1","d":131082,"h":124554182666,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"p":[{"n":"accessor","p":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$($.$spc.System.Object)).$h}],"n":"GetValidationMessages","o":"@$2","d":131082,"h":128849149962,"f":1},{"r":262145,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"IsModified","o":"@$1","d":131082,"h":133144117258,"f":1},{"r":262145,"p":[{"n":"accessor","p":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$($.$spc.System.Object)).$h}],"n":"IsModified","o":"@$2","d":131082,"h":137439084554,"f":1},{"r":262145,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"IsValid","d":131082,"h":141734051850,"f":1},{"r":262145,"p":[{"n":"accessor","p":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$($.$spc.System.Object)).$h}],"n":"IsValid","o":"@$1","d":131082,"h":146029019146,"f":1},{"r":262145,"n":"Validate","d":131082,"h":150323986442,"f":1},{"r":720906,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"GetFieldState","d":131082,"h":154618953738,"f":8},{"r":720906,"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":"GetOrAddFieldState","d":131082,"h":158913921034,"f":8}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState).$h,"n":"_fieldStates","d":131082,"h":4295098378,"f":2}],"c":[{"p":[{"n":"model","p":131073}],"n":".ctor","o":"$ctor$1","d":131082,"h":8590065674,"f":1}],"e":[{"e":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs).$h}],"n":"add_OnFieldChanged","d":131082,"h":12885032970,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs).$h}],"n":"remove_OnFieldChanged","d":131082,"h":17180000266,"f":1},"n":"OnFieldChanged","d":131082,"h":21474967562,"f":1},{"e":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs).$h}],"n":"add_OnValidationRequested","d":131082,"h":25769934858,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs).$h}],"n":"remove_OnValidationRequested","d":131082,"h":30064902154,"f":1},"n":"OnValidationRequested","d":131082,"h":34359869450,"f":1},{"e":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h}],"n":"add_OnValidationStateChanged","d":131082,"h":38654836746,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h}],"n":"remove_OnValidationStateChanged","d":131082,"h":42949804042,"f":1},"n":"OnValidationStateChanged","d":131082,"h":47244771338,"f":1}],"h":131082}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `EditContext`; }
        });
        
        $asm.$str("$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder", ($self) => class ReverseStringBuilder extends $.$spc.System.ValueType
        {
            /*int*/ static MinimumRentedArraySize = 1024;
            /*ArrayPool<char>*/ static s_arrayPool = null;
            /*int*/  get _nextEndIndex() { return this.$getField(0, 4); }
            /*int*/  set _nextEndIndex(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _currentBuffer() { return this.$getField(4, 6); }
            /*Span<char>*/  set _currentBuffer(value) { this.$setField(4, 6, value); }
            /*SequenceSegment?*/  get _fallbackSequenceSegment() { return this.$getField(10, 4); }
            /*SequenceSegment?*/  set _fallbackSequenceSegment(value) { this.$setField(10, 4, value); }
            /*int */ get SequenceSegmentCount()
            {
                return (this._fallbackSequenceSegment?.Count() ?? null) ?? 0;
            }
            $ctor$2(/*int*/ conservativeEstimatedStringLength)
            {
                super.$ctor$1();
                {
                    /*var*/ let array = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(conservativeEstimatedStringLength);
                    this._fallbackSequenceSegment = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(array, null);
                    this._currentBuffer = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(array);
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            $ctor$3(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._currentBuffer = initialBuffer;
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            /*bool */ get Empty()
            {
                return this._nextEndIndex === this._currentBuffer.Length;
            }
            /*void */ InsertFront(/*scoped ReadOnlySpan<char>*/ span)
            {
                /*var*/ let startIndex = ((this._nextEndIndex - span.Length) | 0);
                if (startIndex >= 0)
                {
                    let $t1 = this._currentBuffer;
                    span.CopyTo($t1.Slice$1(startIndex, $t1.Length - startIndex));
                    this._nextEndIndex = startIndex;
                    return;
                }
                if (this._fallbackSequenceSegment === null)
                {
                    /*var*/ let remainingLength = -startIndex;
                    /*var*/ let sizeToRent = ((this._currentBuffer.Length + $.$spc.System.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0))) | 0);
                    /*var*/ let newBuffer = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, null);
                    /*var*/ let newEndIndex = ((((newBuffer.length - this._currentBuffer.Length) | 0) + this._nextEndIndex) | 0);
                    let $t1 = this._currentBuffer;
                    $t1.Slice$1(this._nextEndIndex, $t1.Length - this._nextEndIndex).CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Char, newBuffer, newEndIndex));
                    newEndIndex -= span.Length;
                    span.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Char, newBuffer, newEndIndex));
                    this._currentBuffer = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(newBuffer);
                    this._nextEndIndex = newEndIndex;
                }
                else 
                {
                    /*var*/ let remainingLength = -startIndex;
                    let $t1 = span;
                    $t1.Slice$1(remainingLength, $t1.Length - remainingLength).CopyTo(this._currentBuffer);
                    let $t2 = span;
                    span = $t2.Slice$1(0, remainingLength);
                    /*var*/ let sizeToRent = $.$spc.System.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0));
                    /*var*/ let newBuffer = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, this._fallbackSequenceSegment);
                    this._currentBuffer = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(newBuffer);
                    startIndex = ((this._currentBuffer.Length - remainingLength) | 0);
                    let $t3 = this._currentBuffer;
                    span.CopyTo($t3.Slice$1(startIndex, $t3.Length - startIndex));
                    this._nextEndIndex = startIndex;
                }
            }
            /*void */ InsertFront$1(T, /*T*/ value)
            {
                /*Span<char>*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 11, null);
                /*var*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, result, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), $.$spc.System.Globalization.CultureInfo.InvariantCulture))
                {
                    let $t2 = result;
                    this.InsertFront($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($t2.Slice$1(0, charsWritten)));
                }
                else 
                {
                    this.InsertFront$2($.$box(value, T));
                }
            }
            /*void */ InsertFront$2(/*IFormattable*/ formattable)
            {
                return this.InsertFront($.$spc.System.String.op_Implicit(formattable.System$IFormattable$ToString(null, $.$spc.System.Globalization.CultureInfo.InvariantCulture)));
            }
            static/*conventional*/ /*string */ ToString()
            {
                let $t1 = this._currentBuffer;
                return this._fallbackSequenceSegment === null ? $.$spc.System.String.Create($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($t1.Slice$1(this._nextEndIndex, $t1.Length - this._nextEndIndex))) : this._fallbackSequenceSegment.ToString$1(this._nextEndIndex);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.apply(this, arguments); }
            /*void */ Dispose()
            {
                this._fallbackSequenceSegment?.Dispose();
            }
            static $_SequenceSegment;
            static get SequenceSegment()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder;
                return $cls.$_SequenceSegment ??= $asm.$ncls("$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment", ($self) => class SequenceSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Char)
                {
                    /*char[]*/ _array = null;
                    $ctor$2(/*char[]*/ array, /*SequenceSegment?*/ next)
                    {
                        super.$ctor$1();
                        {
                            this._array = array;
                            this.Memory = $.$spc.System.ReadOnlyMemory$$($.$spc.System.Char).op_Implicit(array);
                            this.Next = next;
                        }
                        return this;
                    }
                    /*int */ Count()
                    {
                        /*var*/ let count = 0;
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment))
                        {
                            count++;
                        }
                        return count;
                    }
                    /*string */ ToString$1(/*int*/ startIndex)
                    {
                        this.RunningIndex = 0n;
                        /*var*/ let tail = this;
                        let next;
                        while($.$is(tail.Next, $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment, { set $v(v){ next = v; } }))
                        {
                            next.RunningIndex = tail.RunningIndex + BigInt(tail.Memory.Length);
                            tail = next;
                        }
                        /*var*/ let sequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Char))().$ctor$3(this, startIndex, tail, tail.Memory.Length);
                        return $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Char).ToString.call(sequence);
                    }
                    /*void */ Dispose()
                    {
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment))
                        {
                            $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Return(current._array, false);
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 851978;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":655361,"n":"Count","d":851978,"h":12885753866,"f":8},{"r":1310721,"p":[{"n":"startIndex","p":655361}],"n":"ToString","o":"@$1","d":851978,"h":17180721162,"f":1},{"r":65537,"n":"Dispose","d":851978,"h":21475688458,"f":1}],"l":[{"t":0,"n":"_array","d":851978,"h":4295819274,"f":2}],"c":[{"p":[{"n":"array","p":0},{"n":"next","p":851978,"f":65}],"n":".ctor","o":"$ctor$2","d":851978,"h":8590786570,"f":1}],"i":[57540609],"d":786442,"h":851978}; }
                    static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Char); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `ReverseStringBuilder.SequenceSegment`; }
                }, $cls, ($v) => $cls.$_SequenceSegment = $v);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._nextEndIndex = this._nextEndIndex;
                copy._currentBuffer = this._currentBuffer.Clone();
                copy._fallbackSequenceSegment = this._fallbackSequenceSegment;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._nextEndIndex = 0;
                this._currentBuffer = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._fallbackSequenceSegment = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_arrayPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared;
                }
            }
            static $h = 786442;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065557514,"f":8},"n":"SequenceSegmentCount","d":786442,"h":25770590218,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":47245426698,"f":1},"n":"Empty","d":786442,"h":42950459402,"f":1}],"m":[{"r":65537,"p":[{"n":"span","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"InsertFront","d":786442,"h":51540393994,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => T.$h}],"g":["T"],"n":"InsertFront","o":"@$1","d":786442,"h":55835361290,"f":131073},{"r":65537,"p":[{"n":"formattable","p":57737217}],"n":"InsertFront","o":"@$2","d":786442,"h":60130328586,"f":1},{"r":1310721,"n":"ToString","d":786442,"h":64425295882,"f":32769},{"r":65537,"n":"Dispose","d":786442,"h":68720263178,"f":1}],"l":[{"t":655361,"n":"MinimumRentedArraySize","d":786442,"h":4295753738,"f":33},{"t":$.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).$h,"n":"s_arrayPool","d":786442,"h":8590721034,"f":34},{"t":655361,"n":"_nextEndIndex","d":786442,"h":12885688330,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_currentBuffer","d":786442,"h":17180655626,"f":2},{"t":851978,"n":"_fallbackSequenceSegment","d":786442,"h":21475622922,"f":2}],"c":[{"p":[{"n":"conservativeEstimatedStringLength","p":655361}],"n":".ctor","o":"$ctor$2","d":786442,"h":34360524810,"f":1},{"p":[{"n":"initialBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":".ctor","o":"$ctor$3","d":786442,"h":38655492106,"f":1},{"n":".ctor","o":"$ctor$4","d":786442,"h":77310197770,"f":1}],"j":[851978],"h":786442}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `ReverseStringBuilder`; }
        });
        
        $asm.$str("$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier", ($self) => class FieldIdentifier extends $.$spc.System.ValueType
        {
            /*ConcurrentDictionary<(Type ModelType, MemberInfo Member), Func<object, object>>*/ static _fieldAccessors = null;
            /*Static constructor*/ static $cctor()
            {
                if ($.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$spc.System.Action().$ctor($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.ClearCache));
                }
            }
            static /*FieldIdentifier */ Create(TField, /*Expression<Func<TField>>*/ accessor)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(accessor, "accessor");
                /*var*/ let model;
                /*var*/ let fieldName;
                $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.ParseAccessor(TField, accessor, $.$ref(() => model, ($v) => model = $v, $.$spc.System.Object), $.$ref(() => fieldName, ($v) => fieldName = $v, $.$spc.System.String));
                return new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$2(model, fieldName);
            }
            $ctor$2(/*object*/ model, /*string*/ fieldName)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(model, "model");
                    if ($.$spc.System.Object.GetType.call(model).IsValueType)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13("The model must be a reference-typed object.", "model");
                    }
                    this.Model = model;
                    this.FieldName = $.$firstOf(fieldName, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("fieldName") });
                }
                return this;
            }
            /*object*/ Model = null;
            /*string*/ FieldName = null;
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*var*/ let modelHash = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode$1(this.Model);
                /*var*/ let fieldHash = $.$spc.System.StringComparer.Ordinal.GetHashCode$2(this.FieldName);
                return $.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32).GetHashCode.call(new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(modelHash, fieldHash));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let otherIdentifier;
                return $.$is(obj, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, { set $v(v){ otherIdentifier = v; } }) && this.Equals$2(otherIdentifier);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*FieldIdentifier*/ otherIdentifier)
            {
                return $.$spc.System.Object.ReferenceEquals(otherIdentifier.Model, this.Model) && $.$spc.System.String.Equals$5(otherIdentifier.FieldName, this.FieldName, 4/*StringComparison.Ordinal*/);
            }
            static /*void */ ParseAccessor(T, /*Expression<Func<T>>*/ accessor, /*out object*/ model, /*out string*/ fieldName)
            {
                /*var*/ let accessorBody = accessor.Body;
                let unaryExpression;
                if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.UnaryExpression, { set $v(v){ unaryExpression = v; } }) && unaryExpression.NodeType === 10/*ExpressionType.Convert*/ && $.$spc.System.Type.op_Equality$1(unaryExpression.Type, $.$spc.System.Object.$type))
                {
                    accessorBody = unaryExpression.Operand;
                }
                //switch (accessorBody)
                {
                    let memberExpression;
                    let methodCallExpression;
                    let binaryExpression;
                    $switchJumpStart1: 
                    //case MemberExpression memberExpression:
                    if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ memberExpression = v; } }))
                    {
                        fieldName.$v = memberExpression.Member.Name;
                        //switch (memberExpression.Expression)
                        let $switch2 = memberExpression.Expression;
                        {
                            let constant;
                            let member;
                            $switchJumpStart2: 
                            //case ConstantExpression constant when constant.Value == null:
                            if ($.$is($switch2, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constant = v; } }) && constant.Value === null)
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$10("The provided expression must evaluate to a non-null value.");
                            }
                            //case ConstantExpression constant when constant.Value != null:
                            else if ($.$is($switch2, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constant = v; } }) && constant.Value !== null)
                            {
                                model.$v = constant.Value;
                            }
                            //case MemberExpression member when member.Expression is ConstantExpression:
                            else if ($.$is($switch2, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ member = v; } }) && $.$is(member.Expression, $.$sle.System.Linq.Expressions.ConstantExpression))
                            {
                                model.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetModelFromMemberAccess(member, null);
                            }
                            //case not null:
                            else if ($switch2 != null && $switch2 === null)
                            {
                                /*var*/ let modelLambda = $.$sle.System.Linq.Expressions.Expression.Lambda$10($.$spc.System.Func$$($.$spc.System.Object).$type, memberExpression.Expression, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [  ], null, null));
                                /*var*/ let modelLambdaCompiled = $.$cast(modelLambda.Compile(), $.$spc.System.Func$$($.$spc.System.Object));
                                /*var*/ let result = $.$firstOf(modelLambdaCompiled.Invoke(), () => { throw new $.$spc.System.ArgumentException().$ctor$10("The provided expression must evaluate to a non-null value.") });
                                model.$v = result;
                            }
                            //default
                            else
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$10(`The provided expression contains a ${$.$spc.System.Object.GetType.call(accessorBody).Name} which is not supported. ${"FieldIdentifier"} only supports simple member accessors (fields, properties) of an object.`);
                            }
                        }
                    }
                    //case MethodCallExpression methodCallExpression when ExpressionFormatter.IsSingleArgumentIndexer(accessorBody):
                    else if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.MethodCallExpression, { set $v(v){ methodCallExpression = v; } }) && $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.IsSingleArgumentIndexer(accessorBody))
                    {
                        fieldName.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument$1(methodCallExpression.Arguments.get_Item(0));
                        model.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetModelFromIndexer(methodCallExpression.Object);
                    }
                    //case BinaryExpression binaryExpression when binaryExpression.NodeType == ExpressionType.ArrayIndex:
                    else if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.BinaryExpression, { set $v(v){ binaryExpression = v; } }) && binaryExpression.NodeType === 5/*ExpressionType.ArrayIndex*/)
                    {
                        fieldName.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument$1(binaryExpression.Right);
                        model.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetModelFromIndexer(binaryExpression.Left);
                    }
                    //default
                    else
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10(`The provided expression contains a ${$.$spc.System.Object.GetType.call(accessorBody).Name} which is not supported. ${"FieldIdentifier"} only supports simple member accessors (fields, properties) of an object.`);
                    }
                }
            }
            static /*object */ GetModelFromMemberAccess(/*MemberExpression*/ member, /*ConcurrentDictionary<(Type ModelType, MemberInfo Member), Func<object, object>>?*/ cache)
            {
                cache ??= $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier._fieldAccessors;
                /*Func<object, object>?*/ let accessor = null;
                /*object?*/ let value = null;
                //switch (member.Expression)
                let $switch1 = member.Expression;
                {
                    let model;
                    $switchJumpStart1: 
                    //case ConstantExpression model:
                    if ($.$is($switch1, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ model = v; } }))
                    {
                        value = $.$firstOf(model.Value, () => { throw new $.$spc.System.ArgumentException().$ctor$10("The provided expression must evaluate to a non-null value.") });
                        accessor = cache.GetOrAdd(new ($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Reflection.MemberInfo))().$ctor$2($.$spc.System.Object.GetType.call(value), member.Member), new ($.$spc.System.Func$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Reflection.MemberInfo), $.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object)))().$ctor($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, CreateAccessor));
                    }
                    //default
                    else
                    {
                    }
                }
                if (accessor === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`Unable to compile expression: ${$.$sle.System.Linq.Expressions.Expression.ToString.call(member)}`);
                }
                if (value === null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10("The provided expression must evaluate to a non-null value.");
                }
                /*var*/ let result = accessor.Invoke(value);
                return result;
                /*static Func<object, object>*/  function CreateAccessor(/*(Type model, MemberInfo member)*/ arg)
                {
                    /*var*/ let parameter = $.$sle.System.Linq.Expressions.Expression.Parameter$1($.$spc.System.Object.$type, "value");
                    /*Expression*/ let expression = $.$sle.System.Linq.Expressions.Expression.Convert(parameter, arg.Item1);
                    expression = $.$sle.System.Linq.Expressions.Expression.MakeMemberAccess(expression, arg.Item2);
                    expression = $.$sle.System.Linq.Expressions.Expression.Convert(expression, $.$spc.System.Object.$type);
                    /*var*/ let lambda = $.$sle.System.Linq.Expressions.Expression.Lambda($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object), expression, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ parameter ], null, null));
                    /*var*/ let func = lambda.Compile$3();
                    return func;
                }
            }
            static /*object */ GetModelFromIndexer(/*Expression*/ methodCallExpression)
            {
                /*object*/ let model;
                /*var*/ let methodCallObjectLambda = $.$sle.System.Linq.Expressions.Expression.Lambda$10($.$spc.System.Func$$($.$spc.System.Object).$type, methodCallExpression, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [  ], null, null));
                /*var*/ let methodCallObjectLambdaCompiled = $.$cast(methodCallObjectLambda.Compile(), $.$spc.System.Func$$($.$spc.System.Object));
                /*var*/ let result = methodCallObjectLambdaCompiled.Invoke();
                if (result === null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10("The provided expression must evaluate to a non-null value.");
                }
                model = result;
                return model;
            }
            static /*void */ ClearCache()
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier._fieldAccessors.Clear();
            }
            //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.Forms.FieldIdentifier>.Equals(Microsoft.AspNetCore.Components.Forms.FieldIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Model = this.Model;
                copy.FieldName = this.FieldName;
                return copy;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._fieldAccessors = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Reflection.MemberInfo), $.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object)))().$ctor$1();
                }
            }
            static $h = 655370;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":131073,"g":{"r":0,"d":0,"h":30065426442,"f":1},"n":"Model","d":655370,"h":25770459146,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950328330,"f":1},"n":"FieldName","d":655370,"h":38655361034,"f":1}],"m":[{"r":655370,"p":[{"n":"accessor","p":(TField) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$(TField)).$h}],"g":["TField"],"n":"Create","d":655370,"h":12885557258,"f":131105},{"r":655361,"n":"GetHashCode","d":655370,"h":47245295626,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":655370,"h":51540262922,"f":32769},{"r":262145,"p":[{"n":"otherIdentifier","p":655370}],"n":"Equals","o":"@$2","d":655370,"h":55835230218,"f":1},{"r":65537,"p":[{"n":"accessor","p":(T) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$(T)).$h},{"n":"model","p":131073,"f":2},{"n":"fieldName","p":1310721,"f":2}],"g":["T"],"n":"ParseAccessor","d":655370,"h":60130197514,"f":131106},{"r":131073,"p":[{"n":"member","p":38971806},{"n":"cache","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Reflection.MemberInfo), $.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object)).$h,"f":65}],"n":"GetModelFromMemberAccess","d":655370,"h":64425164810,"f":40},{"r":131073,"p":[{"n":"methodCallExpression","p":8694174}],"n":"GetModelFromIndexer","d":655370,"h":68720132106,"f":34},{"r":65537,"n":"ClearCache","d":655370,"h":73015099402,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Reflection.MemberInfo), $.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object)).$h,"n":"_fieldAccessors","d":655370,"h":4295622666,"f":34}],"c":[{"p":[{"n":"model","p":131073},{"n":"fieldName","p":1310721}],"n":".ctor","o":"$ctor$2","d":655370,"h":17180524554,"f":1},{"n":".ctor","o":"$ctor$3","d":655370,"h":77310066698,"f":1}],"i":[$.$spc.System.IEquatable$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier).$h],"h":655370}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier) ]; }
            static get $fullName() { return `FieldIdentifier`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.DataAnnotationsValidator", ($self) => class DataAnnotationsValidator extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*IDisposable?*/ _subscriptions = null;
            /*EditContext?*/ _originalEditContext = null;
            /*EditContext?*/ CurrentEditContext = null;
            /*IServiceProvider*/ ServiceProvider = null;
            /*void */ OnInitialized()
            {
                if (this.CurrentEditContext === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`${"DataAnnotationsValidator"} requires a cascading ` + `parameter of type ${"EditContext"}. For example, you can use ${"DataAnnotationsValidator"} ` + `inside an EditForm.`);
                }
                this._subscriptions = $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.EnableDataAnnotationsValidation$1(this.CurrentEditContext, this.ServiceProvider);
                this._originalEditContext = this.CurrentEditContext;
            }
            /*void */ OnParametersSet()
            {
                if (this.CurrentEditContext !== this._originalEditContext)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))} does not support changing the ` + `${"EditContext"} dynamically.`);
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
            }
            /*void */ System$IDisposable$Dispose()
            {
                this._subscriptions?.System$IDisposable$Dispose();
                this._subscriptions = null;
                this.Dispose(true);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ServiceProvider = null;
            }
            static $h = 65546;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":131082,"g":{"r":0,"d":0,"h":21474902026,"f":2},"s":{"r":0,"d":0,"h":25769869322,"f":2},"n":"CurrentEditContext","d":65546,"h":17179934730,"f":2,"a":[{"t":524296,"c":21475360776}]},{"p":327717,"g":{"r":0,"d":0,"h":38654771210,"f":2},"s":{"r":0,"d":0,"h":42949738506,"f":2},"n":"ServiceProvider","d":65546,"h":34359803914,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"n":"OnInitialized","d":65546,"h":47244705802,"f":32772},{"r":65537,"n":"OnParametersSet","d":65546,"h":51539673098,"f":32772},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":65546,"h":55834640394,"f":132}],"l":[{"t":57540609,"n":"_subscriptions","d":65546,"h":4295032842,"f":2},{"t":131082,"n":"_originalEditContext","d":65546,"h":8590000138,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":65546,"h":64424574986,"f":1}],"i":[2752520,3145736,3080200,57540609],"h":65546}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `DataAnnotationsValidator`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs", ($self) => class ValidationRequestedEventArgs extends $.$spc.System.EventArgs
        {
            /*ValidationRequestedEventArgs*/ static Empty = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs().$ctor$2();
                }
            }
            static $h = 983050;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"l":[{"t":983050,"n":"Empty","d":983050,"h":4295950346,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":983050,"h":8590917642,"f":1}],"h":983050}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `ValidationRequestedEventArgs`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs", ($self) => class ValidationStateChangedEventArgs extends $.$spc.System.EventArgs
        {
            /*ValidationStateChangedEventArgs*/ static Empty = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs().$ctor$2();
                }
            }
            static $h = 1048586;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"l":[{"t":1048586,"n":"Empty","d":1048586,"h":4296015882,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":1048586,"h":8590983178,"f":1}],"h":1048586}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `ValidationStateChangedEventArgs`; }
        });
        
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs", ($self) => class FieldChangedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*in FieldIdentifier*/ fieldIdentifier)
            {
                super.$ctor$1();
                {
                    this.FieldIdentifier = fieldIdentifier.$v;
                }
                return this;
            }
            /*FieldIdentifier*/ FieldIdentifier;
            //default member initializer
            constructor()
            {
                super();
                this.FieldIdentifier = $.$default($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier);
            }
            static $h = 589834;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":655370,"g":{"r":0,"d":0,"h":17180459018,"f":1},"n":"FieldIdentifier","d":589834,"h":12885491722,"f":1}],"c":[{"p":[{"n":"fieldIdentifier","p":655370,"f":8}],"n":".ctor","o":"$ctor$2","d":589834,"h":4295557130,"f":1}],"h":589834}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `FieldChangedEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives"))