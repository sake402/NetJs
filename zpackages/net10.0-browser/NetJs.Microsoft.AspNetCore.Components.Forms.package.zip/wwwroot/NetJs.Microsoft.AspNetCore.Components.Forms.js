
//--TRIMMABLE-BOUNDARY-START(116)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $mecga, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mexla, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp) {
    "use strict";
    let _;
    let $hIStZg;
    let $KtjEkc;
    let $GoZLHe;
    let $lvwAkl;
    let $nfZJve;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Forms", 
    {
  "h": 116,
  "f": "Microsoft.AspNetCore.Components.Forms",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Forms and validation support for Blazor applications.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.Forms",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.Forms",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.Forms.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 116457473,
      "c": 8706392065,
      "a": [
        {
          "v": 1114228,
          "t": 188547073
        }
      ]
    },
    {
      "t": 116457473,
      "c": 8706392065,
      "a": [
        {
          "v": 196724,
          "t": 188547073
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(917620)
        $asm.$cls(`$macf.MACF.ValidationMessageStore`, ($self) => class ValidationMessageStore extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295884916)
            /*EditContext*/ _editContext = null;
            //--TRIMMABLE-BOUNDARY-END(4295884916)
            
            //--TRIMMABLE-BOUNDARY-START(8590852212)
            /*Dictionary<FieldIdentifier, List<string>>*/ _messages = null;
            //--TRIMMABLE-BOUNDARY-END(8590852212)
            
            //--TRIMMABLE-BOUNDARY-START(12885819508)
            $ctor$1(/*EditContext*/ editContext)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885819508);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._editContext = $.$firstOf(editContext, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("editContext") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819508)
            
            //--TRIMMABLE-BOUNDARY-START(21475754100)
            /*void */ Add$1(/*in FieldIdentifier*/ fieldIdentifier, /*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754100);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetOrCreateMessagesListForField(fieldIdentifier).Add(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475754100)
            
            //--TRIMMABLE-BOUNDARY-START(30065688692)
            /*void */ Add$3(/*Expression<Func<object>>*/ accessor, /*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065688692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add$1($.$ref(() => $.$macf.MACF.FieldIdentifier.Create($.$$.S.Object, accessor), ), message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065688692)
            
            //--TRIMMABLE-BOUNDARY-START(17180786804)
            /*void */ Add(/*in FieldIdentifier*/ fieldIdentifier, /*IEnumerable<string>*/ messages)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786804);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetOrCreateMessagesListForField(fieldIdentifier).AddRange(messages);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180786804)
            
            //--TRIMMABLE-BOUNDARY-START(25770721396)
            /*void */ Add$2(/*Expression<Func<object>>*/ accessor, /*IEnumerable<string>*/ messages)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770721396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add($.$ref(() => $.$macf.MACF.FieldIdentifier.Create($.$$.S.Object, accessor), ), messages);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721396)
            
            //--TRIMMABLE-BOUNDARY-START(77310328948)
            /*IEnumerable<string>*/ get_Item$1(/*FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let messages;
                return this._messages.TryGetValue(fieldIdentifier, $.$ref(() => messages, ($v) => messages = $v, $.$$.SCG.List$$($.$$.S.String))) ? messages : $.$$.S.Array.Empty($.$$.S.String);
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(77310328948)
            
            //--TRIMMABLE-BOUNDARY-START(81605296244)
            /*IEnumerable<string>*/ get_Item$2(/*Expression<Func<object>>*/ accessor)
            {
                return this.get_Item$1($.$macf.MACF.FieldIdentifier.Create($.$$.S.Object, accessor));
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(81605296244)
            
            //--TRIMMABLE-BOUNDARY-START(38655623284)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en4 = this._messages.Keys.GetEnumerator();
                while ($en4.MoveNext())
                {
                    let fieldIdentifier = $en4.Current;
                    {
                        this.DissociateFromField($.$ref(() => fieldIdentifier, ));
                    }
                }
                this._messages.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(38655623284)
            
            //--TRIMMABLE-BOUNDARY-START(47245557876)
            /*void */ Clear$2(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245557876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Clear$1($.$ref(() => $.$macf.MACF.FieldIdentifier.Create($.$$.S.Object, accessor), ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245557876)
            
            //--TRIMMABLE-BOUNDARY-START(42950590580)
            /*void */ Clear$1(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DissociateFromField(fieldIdentifier);
                this._messages.Remove$1(fieldIdentifier.$v);
            }
            //--TRIMMABLE-BOUNDARY-END(42950590580)
            
            //--TRIMMABLE-BOUNDARY-START(73015361652)
            /*List<string> */ GetOrCreateMessagesListForField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let messagesForField;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._messages.TryGetValue(fieldIdentifier.$v, $.$ref(() => messagesForField, ($v) => messagesForField = $v, $.$$.SCG.List$$($.$$.S.String))))
                {
                    messagesForField = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                    this._messages.Add(fieldIdentifier.$v, messagesForField);
                    this.AssociateWithField(fieldIdentifier);
                }
                return messagesForField;
            }
            //--TRIMMABLE-BOUNDARY-END(73015361652)
            
            //--TRIMMABLE-BOUNDARY-START(34360655988)
            /*void */ AssociateWithField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360655988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._editContext.GetOrAddFieldState(fieldIdentifier).AssociateWithValidationMessageStore(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360655988)
            
            //--TRIMMABLE-BOUNDARY-START(51540525172)
            /*void */ DissociateFromField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540525172);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._editContext.GetFieldState(fieldIdentifier)?.DissociateFromValidationMessageStore(this) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540525172)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590852212)
                this._messages = new ($.$$.SCG.Dictionary$$$($.$macf.MACF.FieldIdentifier, $.$$.SCG.List$$($.$$.S.String)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590852212)
                
            }
            static $h = 917620;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310328948),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "i": [
        {
          "n": "fieldIdentifier",
          "p": 655476
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130459764,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 917620,
      "h": 77310328948,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(77310328948),
//--TRIMMABLE-BOUNDARY-START(81605296244),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "i": [
        {
          "n": "accessor",
          "p": $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Object)).$h
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720394356,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 917620,
      "h": 81605296244,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(81605296244)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475754100),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 917620,
      "h": 21475754100,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754100),
//--TRIMMABLE-BOUNDARY-START(30065688692),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Object)).$h
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$3",
      "d": 917620,
      "h": 30065688692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688692),
//--TRIMMABLE-BOUNDARY-START(17180786804),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        },
        {
          "n": "messages",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "Add",
      "d": 917620,
      "h": 17180786804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786804),
//--TRIMMABLE-BOUNDARY-START(25770721396),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Object)).$h
        },
        {
          "n": "messages",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "Add",
      "o": "@$2",
      "d": 917620,
      "h": 25770721396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721396),
//--TRIMMABLE-BOUNDARY-START(38655623284),
    {
      "r": 65537,
      "n": "Clear",
      "d": 917620,
      "h": 38655623284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655623284),
//--TRIMMABLE-BOUNDARY-START(47245557876),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Object)).$h
        }
      ],
      "n": "Clear",
      "o": "@$2",
      "d": 917620,
      "h": 47245557876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245557876),
//--TRIMMABLE-BOUNDARY-START(42950590580),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "Clear",
      "o": "@$1",
      "d": 917620,
      "h": 42950590580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950590580),
//--TRIMMABLE-BOUNDARY-START(73015361652),
    {
      "r": $.$$.SCG.List$$($.$$.S.String).$h,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "GetOrCreateMessagesListForField",
      "d": 917620,
      "h": 73015361652,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015361652),
//--TRIMMABLE-BOUNDARY-START(34360655988),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "AssociateWithField",
      "d": 917620,
      "h": 34360655988,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360655988),
//--TRIMMABLE-BOUNDARY-START(51540525172),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "DissociateFromField",
      "d": 917620,
      "h": 51540525172,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540525172)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884916),
    {
      "t": 131188,
      "n": "_editContext",
      "d": 917620,
      "h": 4295884916,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884916),
//--TRIMMABLE-BOUNDARY-START(8590852212),
    {
      "t": $.$$.SCG.Dictionary$$$($.$macf.MACF.FieldIdentifier, $.$$.SCG.List$$($.$$.S.String)).$h,
      "n": "_messages",
      "d": 917620,
      "h": 8590852212,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852212)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819508),
    {
      "p": [
        {
          "n": "editContext",
          "p": 131188
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917620,
      "h": 12885819508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819508)
  ],
  "h": 917620
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ValidationMessageStore`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ValidationMessageStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917620)
        
        

        //--TRIMMABLE-BOUNDARY-START(327796)
        $asm.$cls(`$macf.MACF.EditContextProperties`, ($self) => class EditContextProperties extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295092)
            /*Dictionary<object, object>?*/ _contents = null;
            //--TRIMMABLE-BOUNDARY-END(4295295092)
            
            //--TRIMMABLE-BOUNDARY-START(34360066164)
            /*object*/ get_Item$1(/*object*/ key)
            {
                return this._contents === null ? (() =>
                {
        throw new $.$$.SCG.KeyNotFoundException().$ctor$9()        })() : this._contents.get_Item(key);
            }
            /*void*/ set_Item$1(/*object*/ key, /*object*/ value)
            {
                this._contents ??= new ($.$$.SCG.Dictionary$$$($.$$.S.Object, $.$$.S.Object))().$ctor$1();
                this._contents.set_Item(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066164)
            
            //--TRIMMABLE-BOUNDARY-START(38655033460)
            /*bool */ TryGetValue(/*object*/ key, /*out object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._contents === null)
                {
                    value.$v = null;
                    return false;
                }
                else 
                {
                    return this._contents.TryGetValue(key, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033460)
            
            //--TRIMMABLE-BOUNDARY-START(21475164276)
            /*bool */ Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._contents?.Remove$1(key) ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164276)
            
            //--TRIMMABLE-BOUNDARY-START(8590262388)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262388)
            
            //--TRIMMABLE-BOUNDARY-START(8590262388)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590262388)
            
            static $h = 327796;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360066164),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196980,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065098868,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 327796,
      "h": 34360066164,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(34360066164)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655033460),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 327796,
      "h": 38655033460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033460),
//--TRIMMABLE-BOUNDARY-START(21475164276),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 327796,
      "h": 21475164276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164276)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295092),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Object, $.$$.S.Object).$h,
      "n": "_contents",
      "d": 327796,
      "h": 4295295092,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295092)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262388),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327796,
      "h": 8590262388,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262388)
  ],
  "h": 327796
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.EditContextProperties`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}EditContextProperties`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327796)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114228)
        $asm.$cls(`$macf.MACH.HotReloadManager`, ($self) => class HotReloadManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770918004)
            /*HotReloadManager*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(25770918004)
            
            //--TRIMMABLE-BOUNDARY-START(51540721780)
            /*bool*/ MetadataUpdateSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51540721780)
            
            //--TRIMMABLE-BOUNDARY-START(47245754484)
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245754484)
            
            //--TRIMMABLE-BOUNDARY-START(55835689076)
            /*Action?*/ OnDeltaApplied = null;
            //--TRIMMABLE-BOUNDARY-END(55835689076)
            
            //--TRIMMABLE-BOUNDARY-START(55835689076)
            //--TRIMMABLE-BOUNDARY-START(21475950708)
            add_OnDeltaApplied(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDeltaApplied = $.$$.S.Delegate.Combine$2(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475950708)
            
            //--TRIMMABLE-BOUNDARY-START(64425623668)
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425623668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDeltaApplied = $.$$.S.Delegate.Remove(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425623668)
            
            //--TRIMMABLE-BOUNDARY-END(55835689076)
            
            //--TRIMMABLE-BOUNDARY-START(81605492852)
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605492852);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$macf.MACH.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605492852)
            
            //--TRIMMABLE-BOUNDARY-START(77310525556)
            /*void */ TriggerOnDeltaApplied()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310525556);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310525556)
            
            //--TRIMMABLE-BOUNDARY-START(12886016116)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886016116)
            
            //--TRIMMABLE-BOUNDARY-START(12886016116)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886016116)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540721780)
                this.MetadataUpdateSupported = $.$$.SRM.MetadataUpdater.IsSupported;
                //--TRIMMABLE-BOUNDARY-END(51540721780)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8591048820)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770918004)
                    this.Default = new $.$macf.MACH.HotReloadManager().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770918004)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591048820)
            
            static $h = 1114228;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540721780),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015558260,
        "f": 83886081
      },
      "n": "MetadataUpdateSupported",
      "d": 1114228,
      "h": 51540721780,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540721780),
//--TRIMMABLE-BOUNDARY-START(47245754484),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360852596,
        "f": 50331649
      },
      "n": "IsSubscribedTo",
      "d": 1114228,
      "h": 47245754484,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245754484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605492852),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "UpdateApplication",
      "d": 1114228,
      "h": 81605492852,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605492852),
//--TRIMMABLE-BOUNDARY-START(77310525556),
    {
      "r": 65537,
      "n": "TriggerOnDeltaApplied",
      "d": 1114228,
      "h": 77310525556,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310525556)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770918004),
    {
      "t": 1114228,
      "n": "Default",
      "d": 1114228,
      "h": 25770918004,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770918004)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886016116),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114228,
      "h": 12886016116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016116)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55835689076),
    {
      "e": 43122689,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "add_OnDeltaApplied",
        "d": 1114228,
        "h": 21475950708,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "remove_OnDeltaApplied",
        "d": 1114228,
        "h": 64425623668,
        "f": 285212673
      },
      "n": "OnDeltaApplied",
      "d": 1114228,
      "h": 55835689076,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835689076)
  ],
  "h": 1114228
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.HotReload.HotReloadManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}HotReload${separator}HotReloadManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114228)
        
        

        //--TRIMMABLE-BOUNDARY-START(721012)
        $asm.$cls(`$macf.MACF.FieldState`, ($self) => class FieldState extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688308)
            /*FieldIdentifier*/ _fieldIdentifier;
            //--TRIMMABLE-BOUNDARY-END(4295688308)
            
            //--TRIMMABLE-BOUNDARY-START(8590655604)
            /*HashSet<ValidationMessageStore>?*/ _validationMessageStores = null;
            //--TRIMMABLE-BOUNDARY-END(8590655604)
            
            //--TRIMMABLE-BOUNDARY-START(17180590196)
            $ctor$1(/*FieldIdentifier*/ fieldIdentifier)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180590196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._fieldIdentifier = fieldIdentifier;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590196)
            
            //--TRIMMABLE-BOUNDARY-START(42950393972)
            /*bool*/ IsModified = false;
            //--TRIMMABLE-BOUNDARY-END(42950393972)
            
            //--TRIMMABLE-BOUNDARY-START(38655426676)
            /*IEnumerable<string> */ GetValidationMessages()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.String))().$ctor$1(function*()
                {
                    if (this._validationMessageStores !== null)
                    {
                        let $en1 = this._validationMessageStores.GetEnumerator();
                        while ($en1.MoveNext())
                        {
                            let store = $en1.Current;
                            {
                                let $en2 = store.get_Item$1(this._fieldIdentifier).SCG$IEnumerable$$$GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let message = $en2.SCG$IEnumerator$$$Current;
                                    {
                                        yield message;
                                    }
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(38655426676)
            
            //--TRIMMABLE-BOUNDARY-START(21475557492)
            /*void */ AssociateWithValidationMessageStore(/*ValidationMessageStore*/ validationMessageStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._validationMessageStores === null)
                {
                    this._validationMessageStores = new ($.$$.SCG.HashSet$$($.$macf.MACF.ValidationMessageStore))().$ctor$1();
                }
                this._validationMessageStores.Add(validationMessageStore);
            }
            //--TRIMMABLE-BOUNDARY-END(21475557492)
            
            //--TRIMMABLE-BOUNDARY-START(25770524788)
            /*void */ DissociateFromValidationMessageStore(/*ValidationMessageStore*/ validationMessageStore)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._validationMessageStores?.Remove(validationMessageStore) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770524788)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688308)
                this._fieldIdentifier = $.$default($.$macf.MACF.FieldIdentifier);
                //--TRIMMABLE-BOUNDARY-END(4295688308)
                
            }
            static $h = 721012;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950393972),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360459380,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540328564,
        "f": 83886081
      },
      "n": "IsModified",
      "d": 721012,
      "h": 42950393972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950393972)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655426676),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "n": "GetValidationMessages",
      "d": 721012,
      "h": 38655426676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426676),
//--TRIMMABLE-BOUNDARY-START(21475557492),
    {
      "r": 65537,
      "p": [
        {
          "n": "validationMessageStore",
          "p": 917620
        }
      ],
      "n": "AssociateWithValidationMessageStore",
      "d": 721012,
      "h": 21475557492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557492),
//--TRIMMABLE-BOUNDARY-START(25770524788),
    {
      "r": 65537,
      "p": [
        {
          "n": "validationMessageStore",
          "p": 917620
        }
      ],
      "n": "DissociateFromValidationMessageStore",
      "d": 721012,
      "h": 25770524788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524788)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688308),
    {
      "t": 655476,
      "n": "_fieldIdentifier",
      "d": 721012,
      "h": 4295688308,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688308),
//--TRIMMABLE-BOUNDARY-START(8590655604),
    {
      "t": $.$$.SCG.HashSet$$($.$macf.MACF.ValidationMessageStore).$h,
      "n": "_validationMessageStores",
      "d": 721012,
      "h": 8590655604,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655604)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180590196),
    {
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721012,
      "h": 17180590196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590196)
  ],
  "h": 721012
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.FieldState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}FieldState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721012)
        
        

        //--TRIMMABLE-BOUNDARY-START(131188)
        $asm.$cls(`$macf.MACF.EditContext`, ($self) => class EditContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098484)
            /*Dictionary<FieldIdentifier, FieldState>*/ _fieldStates = null;
            //--TRIMMABLE-BOUNDARY-END(4295098484)
            
            //--TRIMMABLE-BOUNDARY-START(21474967668)
            $ctor$1(/*object*/ model)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474967668);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Model = $.$firstOf(model, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("model") });
                    this.Properties = new $.$macf.MACF.EditContextProperties().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967668)
            
            //--TRIMMABLE-BOUNDARY-START(146029019252)
            /*EventHandler<FieldChangedEventArgs>?*/ OnFieldChanged = null;
            //--TRIMMABLE-BOUNDARY-END(146029019252)
            
            //--TRIMMABLE-BOUNDARY-START(146029019252)
            //--TRIMMABLE-BOUNDARY-START(30064902260)
            add_OnFieldChanged(/*EventHandler<FieldChangedEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnFieldChanged = $.$$.S.Delegate.Combine$2(this.OnFieldChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30064902260)
            
            //--TRIMMABLE-BOUNDARY-START(167503855732)
            remove_OnFieldChanged(/*EventHandler<FieldChangedEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503855732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnFieldChanged = $.$$.S.Delegate.Remove(this.OnFieldChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(167503855732)
            
            //--TRIMMABLE-BOUNDARY-END(146029019252)
            
            //--TRIMMABLE-BOUNDARY-START(150323986548)
            /*EventHandler<ValidationRequestedEventArgs>?*/ OnValidationRequested = null;
            //--TRIMMABLE-BOUNDARY-END(150323986548)
            
            //--TRIMMABLE-BOUNDARY-START(150323986548)
            //--TRIMMABLE-BOUNDARY-START(38654836852)
            add_OnValidationRequested(/*EventHandler<ValidationRequestedEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationRequested = $.$$.S.Delegate.Combine$2(this.OnValidationRequested, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38654836852)
            
            //--TRIMMABLE-BOUNDARY-START(176093790324)
            remove_OnValidationRequested(/*EventHandler<ValidationRequestedEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093790324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationRequested = $.$$.S.Delegate.Remove(this.OnValidationRequested, value);
            }
            //--TRIMMABLE-BOUNDARY-END(176093790324)
            
            //--TRIMMABLE-BOUNDARY-END(150323986548)
            
            //--TRIMMABLE-BOUNDARY-START(154618953844)
            /*EventHandler<ValidationStateChangedEventArgs>?*/ OnValidationStateChanged = null;
            //--TRIMMABLE-BOUNDARY-END(154618953844)
            
            //--TRIMMABLE-BOUNDARY-START(154618953844)
            //--TRIMMABLE-BOUNDARY-START(47244771444)
            add_OnValidationStateChanged(/*EventHandler<ValidationStateChangedEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationStateChanged = $.$$.S.Delegate.Combine$2(this.OnValidationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(47244771444)
            
            //--TRIMMABLE-BOUNDARY-START(184683724916)
            remove_OnValidationStateChanged(/*EventHandler<ValidationStateChangedEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683724916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationStateChanged = $.$$.S.Delegate.Remove(this.OnValidationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(184683724916)
            
            //--TRIMMABLE-BOUNDARY-END(154618953844)
            
            //--TRIMMABLE-BOUNDARY-START(51539738740)
            /*FieldIdentifier */ Field(/*string*/ fieldName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539738740);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$macf.MACF.FieldIdentifier().$ctor$3(this.Model, fieldName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539738740)
            
            //--TRIMMABLE-BOUNDARY-START(133144117364)
            /*object*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(133144117364)
            
            //--TRIMMABLE-BOUNDARY-START(158913921140)
            /*EditContextProperties*/ Properties = null;
            //--TRIMMABLE-BOUNDARY-END(158913921140)
            
            //--TRIMMABLE-BOUNDARY-START(197568626804)
            /*bool*/ ShouldUseFieldIdentifiers = false;
            //--TRIMMABLE-BOUNDARY-END(197568626804)
            
            //--TRIMMABLE-BOUNDARY-START(137439084660)
            /*void */ NotifyFieldChanged(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439084660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.GetOrAddFieldState(fieldIdentifier).IsModified = true;
                this.OnFieldChanged?.Invoke(this, new $.$macf.MACF.FieldChangedEventArgs().$ctor$2(fieldIdentifier));
            }
            //--TRIMMABLE-BOUNDARY-END(137439084660)
            
            //--TRIMMABLE-BOUNDARY-START(141734051956)
            /*void */ NotifyValidationStateChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734051956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationStateChanged?.Invoke(this, $.$macf.MACF.ValidationStateChangedEventArgs.Empty$1);
            }
            //--TRIMMABLE-BOUNDARY-END(141734051956)
            
            //--TRIMMABLE-BOUNDARY-START(128849150068)
            /*void */ MarkAsUnmodified$1(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let state;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849150068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.MACF.FieldState)))
                {
                    state.IsModified = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849150068)
            
            //--TRIMMABLE-BOUNDARY-START(124554182772)
            /*void */ MarkAsUnmodified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554182772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en5 = this._fieldStates.GetEnumerator();
                while ($en5.MoveNext())
                {
                    let state = $en5.Current;
                    {
                        state.Value.IsModified = false;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554182772)
            
            //--TRIMMABLE-BOUNDARY-START(103079346292)
            /*bool */ IsModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en6 = this._fieldStates.GetEnumerator();
                while ($en6.MoveNext())
                {
                    let state = $en6.Current;
                    {
                        if (state.Value.IsModified)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(103079346292)
            
            //--TRIMMABLE-BOUNDARY-START(90194444404)
            /*IEnumerable<string> */ GetValidationMessages()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.String))().$ctor$1(function*()
                {
                    let $en7 = this._fieldStates.GetEnumerator();
                    while ($en7.MoveNext())
                    {
                        let state = $en7.Current;
                        {
                            let $en8 = state.Value.GetValidationMessages().SCG$IEnumerable$$$GetEnumerator();
                            while ($en8.SC$1$IEnumerator$MoveNext())
                            {
                                let message = $en8.SCG$IEnumerator$$$Current;
                                {
                                    yield message;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(90194444404)
            
            //--TRIMMABLE-BOUNDARY-START(94489411700)
            /*IEnumerable<string> */ GetValidationMessages$1(/*FieldIdentifier*/ fieldIdentifier)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.String))().$ctor$1(function*()
                {
                    /*var*/ let state;
                    if (this._fieldStates.TryGetValue(fieldIdentifier, $.$ref(() => state, ($v) => state = $v, $.$macf.MACF.FieldState)))
                    {
                        let $en10 = state.GetValidationMessages().SCG$IEnumerable$$$GetEnumerator();
                        while ($en10.SC$1$IEnumerator$MoveNext())
                        {
                            let message = $en10.SCG$IEnumerator$$$Current;
                            {
                                yield message;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(94489411700)
            
            //--TRIMMABLE-BOUNDARY-START(98784378996)
            /*IEnumerable<string> */ GetValidationMessages$2(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784378996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetValidationMessages$1($.$macf.MACF.FieldIdentifier.Create($.$$.S.Object, accessor));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784378996)
            
            //--TRIMMABLE-BOUNDARY-START(107374313588)
            /*bool */ IsModified$1(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    /*var*/ let state;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374313588);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.MACF.FieldState)) ? state.IsModified : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374313588)
            
            //--TRIMMABLE-BOUNDARY-START(111669280884)
            /*bool */ IsModified$2(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669280884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsModified$1($.$ref(() => $.$macf.MACF.FieldIdentifier.Create($.$$.S.Object, accessor), ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669280884)
            
            //--TRIMMABLE-BOUNDARY-START(115964248180)
            /*bool */ IsValid(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964248180);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$sl.SL.Enumerable.Any$1($.$$.S.String, this.GetValidationMessages$1(fieldIdentifier.$v));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964248180)
            
            //--TRIMMABLE-BOUNDARY-START(120259215476)
            /*bool */ IsValid$1(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259215476);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsValid($.$ref(() => $.$macf.MACF.FieldIdentifier.Create($.$$.S.Object, accessor), ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259215476)
            
            //--TRIMMABLE-BOUNDARY-START(201863594100)
            /*bool */ Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863594100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationRequested?.Invoke(this, $.$macf.MACF.ValidationRequestedEventArgs.Empty$1);
                return !$.$sl.SL.Enumerable.Any$1($.$$.S.String, this.GetValidationMessages());
            }
            //--TRIMMABLE-BOUNDARY-END(201863594100)
            
            //--TRIMMABLE-BOUNDARY-START(81604509812)
            /*FieldState? */ GetFieldState(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let state;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.MACF.FieldState));
                return state;
            }
            //--TRIMMABLE-BOUNDARY-END(81604509812)
            
            //--TRIMMABLE-BOUNDARY-START(85899477108)
            /*FieldState */ GetOrAddFieldState(/*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let state;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899477108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.MACF.FieldState)))
                {
                    state = new $.$macf.MACF.FieldState().$ctor$1(fieldIdentifier.$v);
                    this._fieldStates.Add(fieldIdentifier.$v, state);
                }
                return state;
            }
            //--TRIMMABLE-BOUNDARY-END(85899477108)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295098484)
                this._fieldStates = new ($.$$.SCG.Dictionary$$$($.$macf.MACF.FieldIdentifier, $.$macf.MACF.FieldState))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295098484)
                
                //--TRIMMABLE-BOUNDARY-START(197568626804)
                this.ShouldUseFieldIdentifiers = !$.$$.S.OperatingSystem.IsBrowser();
                //--TRIMMABLE-BOUNDARY-END(197568626804)
                
            }
            static $h = 131188;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144117364),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129673332,
        "f": 50331649
      },
      "n": "Model",
      "d": 131188,
      "h": 133144117364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144117364),
//--TRIMMABLE-BOUNDARY-START(158913921140),
    {
      "p": 327796,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719607924,
        "f": 50331649
      },
      "n": "Properties",
      "d": 131188,
      "h": 158913921140,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158913921140),
//--TRIMMABLE-BOUNDARY-START(197568626804),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309542516,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193273659508,
        "f": 83886081
      },
      "n": "ShouldUseFieldIdentifiers",
      "d": 131188,
      "h": 197568626804,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197568626804)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539738740),
    {
      "r": 655476,
      "p": [
        {
          "n": "fieldName",
          "p": 1310721
        }
      ],
      "n": "Field",
      "d": 131188,
      "h": 51539738740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539738740),
//--TRIMMABLE-BOUNDARY-START(137439084660),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "NotifyFieldChanged",
      "d": 131188,
      "h": 137439084660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439084660),
//--TRIMMABLE-BOUNDARY-START(141734051956),
    {
      "r": 65537,
      "n": "NotifyValidationStateChanged",
      "d": 131188,
      "h": 141734051956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734051956),
//--TRIMMABLE-BOUNDARY-START(128849150068),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "MarkAsUnmodified",
      "o": "@$1",
      "d": 131188,
      "h": 128849150068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849150068),
//--TRIMMABLE-BOUNDARY-START(124554182772),
    {
      "r": 65537,
      "n": "MarkAsUnmodified",
      "d": 131188,
      "h": 124554182772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554182772),
//--TRIMMABLE-BOUNDARY-START(103079346292),
    {
      "r": 262145,
      "n": "IsModified",
      "d": 131188,
      "h": 103079346292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079346292),
//--TRIMMABLE-BOUNDARY-START(90194444404),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "n": "GetValidationMessages",
      "d": 131188,
      "h": 90194444404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194444404),
//--TRIMMABLE-BOUNDARY-START(94489411700),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476
        }
      ],
      "n": "GetValidationMessages",
      "o": "@$1",
      "d": 131188,
      "h": 94489411700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489411700),
//--TRIMMABLE-BOUNDARY-START(98784378996),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Object)).$h
        }
      ],
      "n": "GetValidationMessages",
      "o": "@$2",
      "d": 131188,
      "h": 98784378996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784378996),
//--TRIMMABLE-BOUNDARY-START(107374313588),
    {
      "r": 262145,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "IsModified",
      "o": "@$1",
      "d": 131188,
      "h": 107374313588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374313588),
//--TRIMMABLE-BOUNDARY-START(111669280884),
    {
      "r": 262145,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Object)).$h
        }
      ],
      "n": "IsModified",
      "o": "@$2",
      "d": 131188,
      "h": 111669280884,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669280884),
//--TRIMMABLE-BOUNDARY-START(115964248180),
    {
      "r": 262145,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "IsValid",
      "d": 131188,
      "h": 115964248180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964248180),
//--TRIMMABLE-BOUNDARY-START(120259215476),
    {
      "r": 262145,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Object)).$h
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 131188,
      "h": 120259215476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259215476),
//--TRIMMABLE-BOUNDARY-START(201863594100),
    {
      "r": 262145,
      "n": "Validate",
      "d": 131188,
      "h": 201863594100,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201863594100),
//--TRIMMABLE-BOUNDARY-START(81604509812),
    {
      "r": 721012,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "GetFieldState",
      "d": 131188,
      "h": 81604509812,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(81604509812),
//--TRIMMABLE-BOUNDARY-START(85899477108),
    {
      "r": 721012,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": "GetOrAddFieldState",
      "d": 131188,
      "h": 85899477108,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85899477108)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098484),
    {
      "t": $.$$.SCG.Dictionary$$$($.$macf.MACF.FieldIdentifier, $.$macf.MACF.FieldState).$h,
      "n": "_fieldStates",
      "d": 131188,
      "h": 4295098484,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21474967668),
    {
      "p": [
        {
          "n": "model",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131188,
      "h": 21474967668,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474967668)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(146029019252),
    {
      "e": $.$$.S.EventHandler$$($.$macf.MACF.FieldChangedEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$macf.MACF.FieldChangedEventArgs).$h
          }
        ],
        "n": "add_OnFieldChanged",
        "d": 131188,
        "h": 30064902260,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$macf.MACF.FieldChangedEventArgs).$h
          }
        ],
        "n": "remove_OnFieldChanged",
        "d": 131188,
        "h": 167503855732,
        "f": 285212673
      },
      "n": "OnFieldChanged",
      "d": 131188,
      "h": 146029019252,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(146029019252),
//--TRIMMABLE-BOUNDARY-START(150323986548),
    {
      "e": $.$$.S.EventHandler$$($.$macf.MACF.ValidationRequestedEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$macf.MACF.ValidationRequestedEventArgs).$h
          }
        ],
        "n": "add_OnValidationRequested",
        "d": 131188,
        "h": 38654836852,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$macf.MACF.ValidationRequestedEventArgs).$h
          }
        ],
        "n": "remove_OnValidationRequested",
        "d": 131188,
        "h": 176093790324,
        "f": 285212673
      },
      "n": "OnValidationRequested",
      "d": 131188,
      "h": 150323986548,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(150323986548),
//--TRIMMABLE-BOUNDARY-START(154618953844),
    {
      "e": $.$$.S.EventHandler$$($.$macf.MACF.ValidationStateChangedEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$macf.MACF.ValidationStateChangedEventArgs).$h
          }
        ],
        "n": "add_OnValidationStateChanged",
        "d": 131188,
        "h": 47244771444,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$macf.MACF.ValidationStateChangedEventArgs).$h
          }
        ],
        "n": "remove_OnValidationStateChanged",
        "d": 131188,
        "h": 184683724916,
        "f": 285212673
      },
      "n": "OnValidationStateChanged",
      "d": 131188,
      "h": 154618953844,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(154618953844)
  ],
  "h": 131188
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.EditContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}EditContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131188)
        
        

        //--TRIMMABLE-BOUNDARY-START(196724)
        $asm.$cls(`$macf.MACF.EditContextDataAnnotationsExtensions`, ($self) => class EditContextDataAnnotationsExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885098612)
            static /*EditContext */ AddDataAnnotationsValidation(/*this EditContext*/ editContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.MACF.EditContextDataAnnotationsExtensions.EnableDataAnnotationsValidation$1(editContext);
                return editContext;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098612)
            
            //--TRIMMABLE-BOUNDARY-START(25770000500)
            static /*IDisposable */ EnableDataAnnotationsValidation$1(/*this EditContext*/ editContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions().$ctor$1(editContext, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000500)
            
            //--TRIMMABLE-BOUNDARY-START(21475033204)
            static /*IDisposable */ EnableDataAnnotationsValidation(/*this EditContext*/ editContext, /*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                return new $.$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions().$ctor$1(editContext, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(21475033204)
            
            //--TRIMMABLE-BOUNDARY-START(30064967796)
            /*Action?*/ static OnClearCache = null;
            //--TRIMMABLE-BOUNDARY-END(30064967796)
            
            //--TRIMMABLE-BOUNDARY-START(30064967796)
            //--TRIMMABLE-BOUNDARY-START(8590131316)
            static add_OnClearCache(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.MACF.EditContextDataAnnotationsExtensions.OnClearCache = $.$$.S.Delegate.Combine$2($.$macf.MACF.EditContextDataAnnotationsExtensions.OnClearCache, value);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131316)
            
            //--TRIMMABLE-BOUNDARY-START(38654902388)
            static remove_OnClearCache(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.MACF.EditContextDataAnnotationsExtensions.OnClearCache = $.$$.S.Delegate.Remove($.$macf.MACF.EditContextDataAnnotationsExtensions.OnClearCache, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38654902388)
            
            //--TRIMMABLE-BOUNDARY-END(30064967796)
            
            //--TRIMMABLE-BOUNDARY-START(17180065908)
            static /*void */ ClearCache(/*Type[]?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.MACF.EditContextDataAnnotationsExtensions.OnClearCache?.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065908)
            
            //--TRIMMABLE-BOUNDARY-START(262260)
            static $_DataAnnotationsEventSubscriptions;
            static get DataAnnotationsEventSubscriptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macf.MACF.EditContextDataAnnotationsExtensions;
                return $cls.$_DataAnnotationsEventSubscriptions ??= $asm.$ncls(`$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions`, ($self) => class DataAnnotationsEventSubscriptions extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885164148)
                    /*ConcurrentDictionary<(Type ModelType, string FieldName), PropertyInfo?>*/ static _propertyInfoCache = null;
                    //--TRIMMABLE-BOUNDARY-END(12885164148)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295229556)
                    /*EditContext*/ _editContext = null;
                    //--TRIMMABLE-BOUNDARY-END(4295229556)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131444)
                    /*IServiceProvider?*/ _serviceProvider = null;
                    //--TRIMMABLE-BOUNDARY-END(17180131444)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590196852)
                    /*ValidationMessageStore*/ _messages = null;
                    //--TRIMMABLE-BOUNDARY-END(8590196852)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098740)
                    /*ValidationOptions?*/ _validationOptions = null;
                    //--TRIMMABLE-BOUNDARY-END(21475098740)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065033332)
                    /*IValidatableInfo?*/ _validatorTypeInfo = null;
                    //--TRIMMABLE-BOUNDARY-END(30065033332)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770066036)
                    /*Dictionary<string, FieldIdentifier>*/ _validationPathToFieldIdentifierMapping = null;
                    //--TRIMMABLE-BOUNDARY-END(25770066036)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654967924)
                    $ctor$1(/*EditContext*/ editContext, /*IServiceProvider*/ serviceProvider)
                    {
                        super.$ctor();
                        {
                            /*var*/ let typeInfo;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38654967924);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._editContext = $.$firstOf(editContext, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("editContext") });
                            this._serviceProvider = serviceProvider;
                            this._messages = new $.$macf.MACF.ValidationMessageStore().$ctor$1(this._editContext);
                            /*System.IServiceProvider*/ let __ca1__;
                            /*Microsoft.Extensions.Options.IOptions<Microsoft.Extensions.Validation.ValidationOptions>?*/ let __ca2__;
                            this._validationOptions = ((__ca1__ = this._serviceProvider) !== null ? ((__ca2__ = $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$meo.MEO.IOptions$$($.$mev.MEV.ValidationOptions), __ca1__)) !== null ? __ca2__.MEO$IOptions$Microsoft$Extensions$Validation$ValidationOptions$Value : null) : null);
                            this._validatorTypeInfo = this._validationOptions !== null && this._validationOptions.TryGetValidatableTypeInfo($.$$.S.Object.GetType.call(this._editContext.Model), $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$mev.MEV.IValidatableInfo)) ? typeInfo : null;
                            this._editContext.add_OnFieldChanged(new ($.$$.S.EventHandler$$($.$macf.MACF.FieldChangedEventArgs))().$ctor(this, this.OnFieldChanged));
                            this._editContext.add_OnValidationRequested(new ($.$$.S.EventHandler$$($.$macf.MACF.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                            if ($.$$.SRM.MetadataUpdater.IsSupported)
                            {
                                $.$macf.MACF.EditContextDataAnnotationsExtensions.OnClearCache(new $.$$.S.Action().$ctor(this, this.ClearCache));
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654967924)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834837108)
                    /*void */ OnFieldChanged(/*object?*/ sender, /*FieldChangedEventArgs*/ eventArgs)
                    {
                        /*var*/ let propertyInfo;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834837108);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let fieldIdentifier = eventArgs.FieldIdentifier;
                        if ($.$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions.TryGetValidatableProperty($.$ref(() => fieldIdentifier, ), $.$ref(() => propertyInfo, ($v) => propertyInfo = $v, $.$$.SR.PropertyInfo)))
                        {
                            /*var*/ let propertyValue = propertyInfo.GetValue$2(fieldIdentifier.Model);
                            /*var*/ let validationContext = (() =>
                            {
                                //new $.$sca.SCD.ValidationContext()
                                const $t3 = $.$sca.SCD.ValidationContext;
                                const $i3 = new $t3();
                                $i3.$ctor$2(fieldIdentifier.Model, this._serviceProvider, null);
                                $i3.MemberName = propertyInfo.Name;
                                return $i3;
                            })();
                            /*var*/ let results = new ($.$$.SCG.List$$($.$sca.SCD.ValidationResult))().$ctor$1();
                            $.$sca.SCD.Validator.TryValidateProperty(propertyValue, validationContext, results);
                            this._messages.Clear$1($.$ref(() => fieldIdentifier, ));
                            let $en4 = $.$$.SRI.CollectionsMarshal.AsSpan($.$sca.SCD.ValidationResult, results).GetEnumerator();
                            while ($en4.MoveNext())
                            {
                                let result = $en4.Current.$v;
                                {
                                    this._messages.Add$1($.$ref(() => fieldIdentifier, ), result.ErrorMessage);
                                }
                            }
                            this._editContext.NotifyValidationStateChanged();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834837108)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129804404)
                    /*void */ OnValidationRequested(/*object?*/ sender, /*ValidationRequestedEventArgs*/ e)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60129804404);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let validationContext = new $.$sca.SCD.ValidationContext().$ctor$2(this._editContext.Model, this._serviceProvider, null);
                        if (!this.TryValidateTypeInfo(validationContext))
                        {
                            this.ValidateWithDefaultValidator(validationContext);
                        }
                        this._editContext.NotifyValidationStateChanged();
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129804404)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014706292)
                    /*void */ ValidateWithDefaultValidator(/*ValidationContext*/ validationContext)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014706292);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let validationResults = new ($.$$.SCG.List$$($.$sca.SCD.ValidationResult))().$ctor$1();
                        $.$sca.SCD.Validator.TryValidateObject(this._editContext.Model, validationContext, validationResults, true);
                        this._messages.Clear();
                        let $en5 = validationResults.GetEnumerator();
                        while ($en5.MoveNext())
                        {
                            let validationResult = $en5.Current;
                            {
                                if (validationResult === null)
                                {
                                    continue;
                                }
                                /*var*/ let hasMemberNames = false;
                                let $en6 = validationResult.MemberNames.SCG$IEnumerable$$$GetEnumerator();
                                while ($en6.SC$1$IEnumerator$MoveNext())
                                {
                                    let memberName = $en6.SCG$IEnumerator$$$Current;
                                    {
                                        hasMemberNames = true;
                                        this._messages.Add$1($.$ref(() => this._editContext.Field(memberName), ), validationResult.ErrorMessage);
                                    }
                                }
                                if (!hasMemberNames)
                                {
                                    this._messages.Add$1($.$ref(() => new $.$macf.MACF.FieldIdentifier().$ctor$3(this._editContext.Model, $.$$.S.String.Empty), ), validationResult.ErrorMessage);
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014706292)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719738996)
                    /*bool */ TryValidateTypeInfo(/*ValidationContext*/ validationContext)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719738996);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._validatorTypeInfo === null)
                        {
                            return false;
                        }
                        /*var*/ let validateContext = (() =>
                        {
                            //new $.$mev.MEV.ValidateContext()
                            const $t7 = $.$mev.MEV.ValidateContext;
                            const $i7 = new $t7();
                            $i7.$ctor$1();
                            $i7.ValidationOptions = this._validationOptions;
                            $i7.ValidationContext = validationContext;
                            return $i7;
                        })();
                        try
                        {
                            validateContext.add_OnValidationError(new ($.$$.S.Action$$($.$mev.MEV.ValidationErrorContext))().$ctor(this, this.AddMapping));
                            /*var*/ let validationTask = this._validatorTypeInfo.MEV$IValidatableInfo$ValidateAsync(this._editContext.Model, validateContext, $.$$.ST$1.CancellationToken.None);
                            if (!validationTask.IsCompleted)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("Async validation is not supported");
                            }
                            /*var*/ let validationErrors = validateContext.ValidationErrors;
                            this._messages.Clear();
                            if (!(validationErrors === null) && validationErrors.Count > 0)
                            {
                                let $en8 = validationErrors.GetEnumerator();
                                while ($en8.MoveNext())
                                {
                                    let [ fieldKey, messages ] = $.$destructure($en8.Current, 2);
                                    {
                                        /*var*/ let fieldIdentifier = this._validationPathToFieldIdentifierMapping.get_Item(fieldKey);
                                        this._messages.Add($.$ref(() => fieldIdentifier, ), messages);
                                    }
                                }
                            }
                        }
                        catch($e)
                        {
                            throw $e;
                        }
                        finally
                        {
                            {
                                validateContext.remove_OnValidationError(new ($.$$.S.Action$$($.$mev.MEV.ValidationErrorContext))().$ctor(this, this.AddMapping));
                                this._validationPathToFieldIdentifierMapping.Clear();
                            }
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719738996)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949935220)
                    /*void */ AddMapping(/*ValidationErrorContext*/ context)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949935220);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._validationPathToFieldIdentifierMapping.set_Item(context.Path, new $.$macf.MACF.FieldIdentifier().$ctor$3(context.Container ?? this._editContext.Model, context.Name));
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949935220)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539869812)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51539869812);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._messages.Clear();
                        this._editContext.remove_OnFieldChanged(new ($.$$.S.EventHandler$$($.$macf.MACF.FieldChangedEventArgs))().$ctor(this, this.OnFieldChanged));
                        this._editContext.remove_OnValidationRequested(new ($.$$.S.EventHandler$$($.$macf.MACF.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                        this._editContext.NotifyValidationStateChanged();
                        if ($.$$.SRM.MetadataUpdater.IsSupported)
                        {
                            $.$macf.MACF.EditContextDataAnnotationsExtensions.OnClearCache(new $.$$.S.Action().$ctor(this, this.ClearCache));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539869812)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424771700)
                    static /*bool */ TryGetValidatableProperty(/*in FieldIdentifier*/ fieldIdentifier, /*out PropertyInfo?*/ propertyInfo)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424771700);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let cacheKey = new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.String))().$ctor$3($.$$.S.Object.GetType.call(fieldIdentifier.$v.Model), fieldIdentifier.$v.FieldName);
                        if (!$.$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.TryGetValue($.$clone(cacheKey), propertyInfo))
                        {
                            propertyInfo.$v = cacheKey.Item1.GetProperty$6(cacheKey.Item2);
                            $.$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.set_Item$1($.$clone(cacheKey), propertyInfo.$v);
                        }
                        return $.$$.SR.PropertyInfo.op_Inequality$1(propertyInfo.$v, null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64424771700)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244902516)
                    /*void */ ClearCache()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47244902516);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.Clear();
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244902516)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25770066036)
                        this._validationPathToFieldIdentifierMapping = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$macf.MACF.FieldIdentifier))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(25770066036)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(34360000628)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360000628);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12885164148)
                            this._propertyInfoCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.String), $.$$.SR.PropertyInfo))().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(12885164148)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360000628)
                    
                    static $h = 262260;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834837108),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "eventArgs",
          "p": 589940
        }
      ],
      "n": "OnFieldChanged",
      "d": 262260,
      "h": 55834837108,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55834837108),
//--TRIMMABLE-BOUNDARY-START(60129804404),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 983156
        }
      ],
      "n": "OnValidationRequested",
      "d": 262260,
      "h": 60129804404,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129804404),
//--TRIMMABLE-BOUNDARY-START(73014706292),
    {
      "r": 65537,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "ValidateWithDefaultValidator",
      "d": 262260,
      "h": 73014706292,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014706292),
//--TRIMMABLE-BOUNDARY-START(68719738996),
    {
      "r": 262145,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "TryValidateTypeInfo",
      "d": 262260,
      "h": 68719738996,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68719738996),
//--TRIMMABLE-BOUNDARY-START(42949935220),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 852081
        }
      ],
      "n": "AddMapping",
      "d": 262260,
      "h": 42949935220,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949935220),
//--TRIMMABLE-BOUNDARY-START(51539869812),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262260,
      "h": 51539869812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869812),
//--TRIMMABLE-BOUNDARY-START(64424771700),
    {
      "r": 262145,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        },
        {
          "n": "propertyInfo",
          "p": 119603201,
          "f": 2
        }
      ],
      "n": "TryGetValidatableProperty",
      "d": 262260,
      "h": 64424771700,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424771700),
//--TRIMMABLE-BOUNDARY-START(47244902516),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 262260,
      "h": 47244902516,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47244902516)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885164148),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.String), $.$$.SR.PropertyInfo).$h,
      "n": "_propertyInfoCache",
      "d": 262260,
      "h": 12885164148,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885164148),
//--TRIMMABLE-BOUNDARY-START(4295229556),
    {
      "t": 131188,
      "n": "_editContext",
      "d": 262260,
      "h": 4295229556,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229556),
//--TRIMMABLE-BOUNDARY-START(17180131444),
    {
      "t": 327718,
      "n": "_serviceProvider",
      "d": 262260,
      "h": 17180131444,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131444),
//--TRIMMABLE-BOUNDARY-START(8590196852),
    {
      "t": 917620,
      "n": "_messages",
      "d": 262260,
      "h": 8590196852,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196852),
//--TRIMMABLE-BOUNDARY-START(21475098740),
    {
      "t": 917617,
      "n": "_validationOptions",
      "d": 262260,
      "h": 21475098740,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475098740),
//--TRIMMABLE-BOUNDARY-START(30065033332),
    {
      "t": 131185,
      "n": "_validatorTypeInfo",
      "d": 262260,
      "h": 30065033332,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065033332),
//--TRIMMABLE-BOUNDARY-START(25770066036),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$macf.MACF.FieldIdentifier).$h,
      "n": "_validationPathToFieldIdentifierMapping",
      "d": 262260,
      "h": 25770066036,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770066036)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38654967924),
    {
      "p": [
        {
          "n": "editContext",
          "p": 131188
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262260,
      "h": 38654967924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967924)
  ],
  "d": 196724,
  "h": 262260
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions+DataAnnotationsEventSubscriptions`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}EditContextDataAnnotationsExtensions${separator}DataAnnotationsEventSubscriptions`; }
                }, $cls, ($v) => $cls.$_DataAnnotationsEventSubscriptions = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262260)
            
            static $h = 196724;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885098612),
    {
      "r": 131188,
      "p": [
        {
          "n": "editContext",
          "p": 131188
        }
      ],
      "n": "AddDataAnnotationsValidation",
      "d": 196724,
      "h": 12885098612,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Use EnableDataAnnotationsValidation instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885098612),
//--TRIMMABLE-BOUNDARY-START(25770000500),
    {
      "r": 91095041,
      "p": [
        {
          "n": "editContext",
          "p": 131188
        }
      ],
      "n": "EnableDataAnnotationsValidation",
      "o": "@$1",
      "d": 196724,
      "h": 25770000500,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API is obsolete and may be removed in future versions. Use the overload that accepts an IServiceProvider instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770000500),
//--TRIMMABLE-BOUNDARY-START(21475033204),
    {
      "r": 91095041,
      "p": [
        {
          "n": "editContext",
          "p": 131188
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "EnableDataAnnotationsValidation",
      "d": 196724,
      "h": 21475033204,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475033204),
//--TRIMMABLE-BOUNDARY-START(17180065908),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "ClearCache",
      "d": 196724,
      "h": 17180065908,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180065908)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(30064967796),
    {
      "e": 43122689,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "add_OnClearCache",
        "d": 196724,
        "h": 8590131316,
        "f": 150994978
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "remove_OnClearCache",
        "d": 196724,
        "h": 38654902388,
        "f": 285212706
      },
      "n": "OnClearCache",
      "d": 196724,
      "h": 30064967796,
      "f": 8388642
    },
//--TRIMMABLE-BOUNDARY-END(30064967796)
  ],
  "h": 196724
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macf.MACF.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}EditContextDataAnnotationsExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196724)
        
        

        //--TRIMMABLE-BOUNDARY-START(393332)
        $asm.$cls(`$macf.MACF.ExpressionFormatter`, ($self) => class ExpressionFormatter
        {
            //--TRIMMABLE-BOUNDARY-START(4295360628)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macf.MACH.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macf.MACH.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.S.Action().$ctor($.$macf.MACF.ExpressionFormatter, $.$macf.MACF.ExpressionFormatter.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360628)
            
            //--TRIMMABLE-BOUNDARY-START(60129935476)
            /*int*/ static StackAllocBufferSize = 128;
            //--TRIMMABLE-BOUNDARY-END(60129935476)
            
            //--TRIMMABLE-BOUNDARY-START(458868)
            static $_CapturedValueFormatter;
            static get CapturedValueFormatter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macf.MACF.ExpressionFormatter;
                return $cls.$_CapturedValueFormatter ??= $asm.$ncls(`$macf.MACF.ExpressionFormatter.CapturedValueFormatter`, ($self) => class CapturedValueFormatter extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/*$.$$.S.Object*/ closure, /**/ builder)
                    {
                        return this.$nativeFunction.call(this.$target, closure, builder);
                    }
                    static $h = 458868;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180328052),
    {
      "r": 65537,
      "p": [
        {
          "n": "closure",
          "p": 131073
        },
        {
          "n": "builder",
          "p": 786548,
          "f": 4
        }
      ],
      "n": "Invoke",
      "d": 458868,
      "h": 17180328052,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180328052),
//--TRIMMABLE-BOUNDARY-START(8590393460),
    {
      "r": 90570753,
      "p": [
        {
          "n": "closure",
          "p": 131073
        },
        {
          "n": "builder",
          "p": 786548,
          "f": 4
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 458868,
      "h": 8590393460,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590393460),
//--TRIMMABLE-BOUNDARY-START(12885360756),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 786548,
          "f": 4
        },
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 458868,
      "h": 12885360756,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885360756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426164),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458868,
      "h": 4295426164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426164)
  ],
  "d": 393332,
  "h": 458868
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ExpressionFormatter+CapturedValueFormatter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ExpressionFormatter${separator}CapturedValueFormatter`; }
                }, $cls, ($v) => $cls.$_CapturedValueFormatter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458868)
            
            //--TRIMMABLE-BOUNDARY-START(51540000884)
            /*ConcurrentDictionary<MemberInfo, CapturedValueFormatter>*/ static s_capturedValueFormatterCache = null;
            //--TRIMMABLE-BOUNDARY-END(51540000884)
            
            //--TRIMMABLE-BOUNDARY-START(55834968180)
            /*ConcurrentDictionary<MethodInfo, MethodInfoData>*/ static s_methodInfoDataCache = null;
            //--TRIMMABLE-BOUNDARY-END(55834968180)
            
            //--TRIMMABLE-BOUNDARY-START(8590327924)
            static /*void */ ClearCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.MACF.ExpressionFormatter.s_capturedValueFormatterCache.Clear();
                $.$macf.MACF.ExpressionFormatter.s_methodInfoDataCache.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(8590327924)
            
            //--TRIMMABLE-BOUNDARY-START(38655098996)
            static /*string */ FormatLambda$1(/*LambdaExpression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macf.MACF.ExpressionFormatter.FormatLambda(expression, null);
            }
            //--TRIMMABLE-BOUNDARY-END(38655098996)
            
            //--TRIMMABLE-BOUNDARY-START(34360131700)
            static /*string */ FormatLambda(/*LambdaExpression*/ expression, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$macf.MACF.ReverseStringBuilder().$ctor$4($.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 128/*StackAllocBufferSize*/, null));
                /*var*/ let node = expression.Body;
                /*var*/ let wasLastExpressionMemberAccess = false;
                /*var*/ let wasLastExpressionIndexer = false;
                while(!(node === null))
                {
                    var constantExpression;
                    var methodCallExpression;
                    var binaryExpression;
                    var memberExpression;
                    var name;
                    let $switch1 = node.NodeType;
                    switch($switch1)
                    {
                        case 9/*ExpressionType.Constant*/:
                        constantExpression = $.$cast(node, $.$sle.SLE.ConstantExpression);
                        node = null;
                        break;
                        case 6/*ExpressionType.Call*/:
                        methodCallExpression = $.$cast(node, $.$sle.SLE.MethodCallExpression);
                        if (!$.$macf.MACF.ExpressionFormatter.IsSingleArgumentIndexer(methodCallExpression))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Method calls cannot be formatted.");
                        }
                        node = methodCallExpression.Object;
                        if (prefix !== null && $.$is(node, $.$sle.SLE.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront$1($.$$.S.String.op_Implicit("."));
                        }
                        wasLastExpressionIndexer = true;
                        builder.InsertFront$1($.$$.S.String.op_Implicit("]"));
                        $.$macf.MACF.ExpressionFormatter.FormatIndexArgument(methodCallExpression.Arguments.get_Item(0), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$macf.MACF.ReverseStringBuilder, () => builder, ($v) => builder = $v, null, true));
                        builder.InsertFront$1($.$$.S.String.op_Implicit("["));
                        break;
                        case 5/*ExpressionType.ArrayIndex*/:
                        binaryExpression = $.$cast(node, $.$sle.SLE.BinaryExpression);
                        node = binaryExpression.Left;
                        if (prefix !== null && $.$is(node, $.$sle.SLE.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront$1($.$$.S.String.op_Implicit("."));
                        }
                        builder.InsertFront$1($.$$.S.String.op_Implicit("]"));
                        $.$macf.MACF.ExpressionFormatter.FormatIndexArgument(binaryExpression.Right, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$macf.MACF.ReverseStringBuilder, () => builder, ($v) => builder = $v, null, true));
                        builder.InsertFront$1($.$$.S.String.op_Implicit("["));
                        wasLastExpressionIndexer = true;
                        break;
                        case 23/*ExpressionType.MemberAccess*/:
                        memberExpression = $.$cast(node, $.$sle.SLE.MemberExpression);
                        node = memberExpression.Expression;
                        if (prefix !== null && $.$is(node, $.$sle.SLE.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            builder.InsertFront$1($.$$.S.String.op_Implicit("."));
                        }
                        wasLastExpressionMemberAccess = true;
                        wasLastExpressionIndexer = false;
                        name = ($.$$.SR.CustomAttributeExtensions.GetCustomAttribute$8($.$srsp.SRS.DataMemberAttribute, memberExpression.Member)?.Name ?? null) ?? memberExpression.Member.Name;
                        builder.InsertFront$1($.$$.S.String.op_Implicit(name));
                        break;
                        default:
                        node = null;
                        break;
                    }
                }
                if (prefix !== null)
                {
                    if (!builder.Empty && !wasLastExpressionIndexer)
                    {
                        builder.InsertFront$1($.$$.S.String.op_Implicit("."));
                    }
                    builder.InsertFront$1($.$$.S.String.op_Implicit(prefix));
                }
                /*var*/ let result = builder.ToString();
                builder.Dispose();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131700)
            
            //--TRIMMABLE-BOUNDARY-START(47245033588)
            static /*bool */ IsSingleArgumentIndexer(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let methodExpression;
                if (!$.$is(expression, $.$sle.SLE.MethodCallExpression, { set $v($v){ methodExpression = $v; } }) || methodExpression.Arguments.Count !== 1)
                {
                    return false;
                }
                /*var*/ let methodInfoData = $.$macf.MACF.ExpressionFormatter.GetOrCreateMethodInfoData(methodExpression.Method);
                return methodInfoData.IsSingleArgumentIndexer;
            }
            //--TRIMMABLE-BOUNDARY-END(47245033588)
            
            //--TRIMMABLE-BOUNDARY-START(42950066292)
            static /*MethodInfoData */ GetOrCreateMethodInfoData(/*MethodInfo*/ methodInfo)
            {
                /*var*/ let methodInfoData;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macf.MACF.ExpressionFormatter.s_methodInfoDataCache.TryGetValue(methodInfo, $.$ref(() => methodInfoData, ($v) => methodInfoData = $v, $.$macf.MACF.ExpressionFormatter.MethodInfoData)))
                {
                    methodInfoData = GetMethodInfoData(methodInfo);
                    $.$macf.MACF.ExpressionFormatter.s_methodInfoDataCache.set_Item$1(methodInfo, methodInfoData);
                }
                return methodInfoData;
                /*static MethodInfoData*/  function GetMethodInfoData(/*MethodInfo*/ methodInfo)
                {
                    /*var*/ let declaringType = methodInfo.DeclaringType;
                    if (declaringType === null)
                    {
                        return new $.$macf.MACF.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    /*var*/ let defaultMember = $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$7($.$$.SR.DefaultMemberAttribute, declaringType, true);
                    if (defaultMember === null)
                    {
                        return new $.$macf.MACF.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    /*var*/ let runtimeProperties = $.$$.SR.RuntimeReflectionExtensions.GetRuntimeProperties(declaringType);
                    if (runtimeProperties === null)
                    {
                        return new $.$macf.MACF.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    let $en5 = runtimeProperties.SCG$IEnumerable$$$GetEnumerator();
                    while ($en5.SC$1$IEnumerator$MoveNext())
                    {
                        let property = $en5.SCG$IEnumerator$$$Current;
                        {
                            if ($.$$.S.String.Equals$3(defaultMember.MemberName, property.Name, 4/*StringComparison.Ordinal*/) && $.$$.SR.MethodInfo.op_Equality$2(property.GetMethod, methodInfo))
                            {
                                return new $.$macf.MACF.ExpressionFormatter.MethodInfoData().$ctor$3(true);
                            }
                        }
                    }
                    return new $.$macf.MACF.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950066292)
            
            //--TRIMMABLE-BOUNDARY-START(25770197108)
            static /*void */ FormatIndexArgument(/*Expression*/ indexExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //switch (indexExpression)
                {
                    let memberExpression;
                    let constantExpression;
                    $switchJumpStart6: 
                    //case MemberExpression memberExpression when memberExpression.Expression is ConstantExpression constantExpression:
                    if ($.$is(indexExpression, $.$sle.SLE.MemberExpression, { set $v(v){ memberExpression = v; } }) && $.$is(memberExpression.Expression, $.$sle.SLE.ConstantExpression, { set $v($v){ constantExpression = $v; } }))
                    {
                        $.$macf.MACF.ExpressionFormatter.FormatCapturedValue(memberExpression, constantExpression, builder);
                    }
                    //case ConstantExpression constantExpression:
                    else if ($.$is(indexExpression, $.$sle.SLE.ConstantExpression, { set $v(v){ constantExpression = v; } }))
                    {
                        $.$macf.MACF.ExpressionFormatter.FormatConstantValue(constantExpression, builder);
                    }
                    //default
                    else
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`Unable to evaluate index expressions of type '${$.$strNN($.$$.S.Object.GetType.call(indexExpression).Name)}'.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770197108)
            
            //--TRIMMABLE-BOUNDARY-START(30065164404)
            static /*string */ FormatIndexArgument$1(/*Expression*/ indexExpression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$macf.MACF.ReverseStringBuilder().$ctor$4($.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 128/*StackAllocBufferSize*/, null));
                try
                {
                    $.$macf.MACF.ExpressionFormatter.FormatIndexArgument(indexExpression, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$macf.MACF.ReverseStringBuilder, () => builder, ($v) => builder = $v, null, true));
                    /*var*/ let result = builder.ToString();
                    return result;
                }
                finally
                {
                    {
                        builder.Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164404)
            
            //--TRIMMABLE-BOUNDARY-START(17180262516)
            static /*void */ FormatCapturedValue(/*MemberExpression*/ memberExpression, /*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                /*var*/ let format;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let member = memberExpression.Member;
                if (!$.$macf.MACF.ExpressionFormatter.s_capturedValueFormatterCache.TryGetValue(member, $.$ref(() => format, ($v) => format = $v, $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter)))
                {
                    format = $.$macf.MACF.ExpressionFormatter.CreateCapturedValueFormatter(memberExpression);
                    $.$macf.MACF.ExpressionFormatter.s_capturedValueFormatterCache.set_Item$1(member, format);
                }
                format.Invoke(constantExpression.Value, builder);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262516)
            
            //--TRIMMABLE-BOUNDARY-START(12885295220)
            static /*CapturedValueFormatter */ CreateCapturedValueFormatter(/*MemberExpression*/ memberExpression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let memberType = memberExpression.Type;
                if (memberType === $.$$.S.Int32.$type)
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.S.Int32, memberExpression);
                    return new $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$2($.$$.S.Int32, func.Invoke(closure));
                    }, $KtjEkc ??= {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786548,"f":4}],"n":"","d":393332,"h":0,"f":17825794});
                }
                else if (memberType === $.$$.S.String.$type)
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.S.String, memberExpression);
                    return new $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$1($.$$.S.String.op_Implicit(func.Invoke(closure)));
                    }, $GoZLHe ??= {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786548,"f":4}],"n":"","d":393332,"h":0,"f":17825794});
                }
                else if ($.$$.S.ISpanFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.S.ISpanFormattable, memberExpression);
                    return new $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$2($.$$.S.ISpanFormattable, func.Invoke(closure));
                    }, $lvwAkl ??= {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786548,"f":4}],"n":"","d":393332,"h":0,"f":17825794});
                }
                else if ($.$$.S.IFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.S.IFormattable, memberExpression);
                    return new $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront(func.Invoke(closure));
                    }, $nfZJve ??= {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":786548,"f":4}],"n":"","d":393332,"h":0,"f":17825794});
                }
                else 
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Cannot format an index argument of type '${$.$strNN(memberType.ToString())}'.`);
                }
                /*static Func<object, TResult>*/  function CompileMemberEvaluator(TResult, /*MemberExpression*/ memberExpression)
                {
                    /*var*/ let parameterExpression = $.$sle.SLE.Expression.Parameter$1($.$$.S.Object.$type);
                    /*var*/ let convertExpression = $.$sle.SLE.Expression.Convert$1(parameterExpression, memberExpression.Member.DeclaringType);
                    /*var*/ let replacedMemberExpression = memberExpression.Update(convertExpression);
                    /*var*/ let replacedExpression = $.$sle.SLE.Expression.Lambda$15($.$$.S.Func$$$($.$$.S.Object, TResult), replacedMemberExpression, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ parameterExpression ], null, null));
                    return replacedExpression.Compile$3();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295220)
            
            //--TRIMMABLE-BOUNDARY-START(21475229812)
            static /*void */ FormatConstantValue(/*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //switch (constantExpression.Value)
                let $switch12 = constantExpression.Value;
                {
                    let s;
                    let spanFormattable;
                    let formattable;
                    let x;
                    $switchJumpStart12: 
                    //case string s:
                    if ($.$is($switch12, $.$$.S.String, { set $v(v){ s = v; } }))
                    {
                        builder.$v.InsertFront$1($.$$.S.String.op_Implicit(s));
                    }
                    //case ISpanFormattable spanFormattable:
                    else if ($.$is($switch12, $.$$.S.ISpanFormattable, { set $v(v){ spanFormattable = v; } }))
                    {
                        builder.$v.InsertFront$2($.$$.S.ISpanFormattable, spanFormattable);
                    }
                    //case IFormattable formattable:
                    else if ($.$is($switch12, $.$$.S.IFormattable, { set $v(v){ formattable = v; } }))
                    {
                        builder.$v.InsertFront(formattable);
                    }
                    //case null:
                    else if ($switch12 == null)
                    {
                        builder.$v.InsertFront$1($.$$.S.String.op_Implicit("null"));
                    }
                    //case var x:
                    else if ($switch12 != null && (x = $switch12))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`Unable to format constant values of type '${$.$strNN($.$$.S.Object.GetType.call(x).ToString())}'.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475229812)
            
            //--TRIMMABLE-BOUNDARY-START(524404)
            static $_MethodInfoData;
            static get MethodInfoData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macf.MACF.ExpressionFormatter;
                return $cls.$_MethodInfoData ??= $asm.$nstr(`$macf.MACF.ExpressionFormatter.MethodInfoData`, ($self) => class MethodInfoData extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328180)
                    /*bool*/ IsSingleArgumentIndexer = false;
                    //--TRIMMABLE-BOUNDARY-END(25770328180)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885426292)
                    $ctor$3(/*bool*/ isSingleArgumentIndexer)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885426292);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.IsSingleArgumentIndexer = isSingleArgumentIndexer;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885426292)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458996)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590458996);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590458996)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458996)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590458996)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsSingleArgumentIndexer = this.IsSingleArgumentIndexer;
                        return copy;
                    }
                    static $h = 524404;
                    static $z = 1;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770328180),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360884,
        "f": 50331649
      },
      "n": "IsSingleArgumentIndexer",
      "d": 524404,
      "h": 25770328180,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770328180)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426292),
    {
      "p": [
        {
          "n": "isSingleArgumentIndexer",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524404,
      "h": 12885426292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426292),
//--TRIMMABLE-BOUNDARY-START(8590458996),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524404,
      "h": 8590458996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458996)
  ],
  "d": 393332,
  "h": 524404
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ExpressionFormatter+MethodInfoData`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ExpressionFormatter${separator}MethodInfoData`; }
                }, $cls, ($v) => $cls.$_MethodInfoData = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524404)
            
            //--TRIMMABLE-BOUNDARY-START(4295360628)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(51540000884)
                    this.s_capturedValueFormatterCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.SR.MemberInfo, $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(51540000884)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834968180)
                    this.s_methodInfoDataCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.SR.MethodInfo, $.$macf.MACF.ExpressionFormatter.MethodInfoData))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(55834968180)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360628)
            
            static $h = 393332;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327924),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 393332,
      "h": 8590327924,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327924),
//--TRIMMABLE-BOUNDARY-START(38655098996),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 38797349
        }
      ],
      "n": "FormatLambda",
      "o": "@$1",
      "d": 393332,
      "h": 38655098996,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655098996),
//--TRIMMABLE-BOUNDARY-START(34360131700),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 38797349
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "FormatLambda",
      "d": 393332,
      "h": 34360131700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360131700),
//--TRIMMABLE-BOUNDARY-START(47245033588),
    {
      "r": 262145,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "IsSingleArgumentIndexer",
      "d": 393332,
      "h": 47245033588,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47245033588),
//--TRIMMABLE-BOUNDARY-START(42950066292),
    {
      "r": 524404,
      "p": [
        {
          "n": "methodInfo",
          "p": 117571585
        }
      ],
      "n": "GetOrCreateMethodInfoData",
      "d": 393332,
      "h": 42950066292,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950066292),
//--TRIMMABLE-BOUNDARY-START(25770197108),
    {
      "r": 65537,
      "p": [
        {
          "n": "indexExpression",
          "p": 8781861
        },
        {
          "n": "builder",
          "p": 786548,
          "f": 4
        }
      ],
      "n": "FormatIndexArgument",
      "d": 393332,
      "h": 25770197108,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770197108),
//--TRIMMABLE-BOUNDARY-START(30065164404),
    {
      "r": 1310721,
      "p": [
        {
          "n": "indexExpression",
          "p": 8781861
        }
      ],
      "n": "FormatIndexArgument",
      "o": "@$1",
      "d": 393332,
      "h": 30065164404,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065164404),
//--TRIMMABLE-BOUNDARY-START(17180262516),
    {
      "r": 65537,
      "p": [
        {
          "n": "memberExpression",
          "p": 39321637
        },
        {
          "n": "constantExpression",
          "p": 7864357
        },
        {
          "n": "builder",
          "p": 786548,
          "f": 4
        }
      ],
      "n": "FormatCapturedValue",
      "d": 393332,
      "h": 17180262516,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180262516),
//--TRIMMABLE-BOUNDARY-START(12885295220),
    {
      "r": 458868,
      "p": [
        {
          "n": "memberExpression",
          "p": 39321637
        }
      ],
      "n": "CreateCapturedValueFormatter",
      "d": 393332,
      "h": 12885295220,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885295220),
//--TRIMMABLE-BOUNDARY-START(21475229812),
    {
      "r": 65537,
      "p": [
        {
          "n": "constantExpression",
          "p": 7864357
        },
        {
          "n": "builder",
          "p": 786548,
          "f": 4
        }
      ],
      "n": "FormatConstantValue",
      "d": 393332,
      "h": 21475229812,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475229812)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60129935476),
    {
      "t": 655361,
      "n": "StackAllocBufferSize",
      "d": 393332,
      "h": 60129935476,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129935476),
//--TRIMMABLE-BOUNDARY-START(51540000884),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.SR.MemberInfo, $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter).$h,
      "n": "s_capturedValueFormatterCache",
      "d": 393332,
      "h": 51540000884,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540000884),
//--TRIMMABLE-BOUNDARY-START(55834968180),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.SR.MethodInfo, $.$macf.MACF.ExpressionFormatter.MethodInfoData).$h,
      "n": "s_methodInfoDataCache",
      "d": 393332,
      "h": 55834968180,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834968180)
  ],
  "h": 393332
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macf.MACF.ExpressionFormatter.CapturedValueFormatter, $.$macf.MACF.ExpressionFormatter.MethodInfoData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ExpressionFormatter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ExpressionFormatter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393332)
        
        

        //--TRIMMABLE-BOUNDARY-START(786548)
        $asm.$str(`$macf.MACF.ReverseStringBuilder`, ($self) => class ReverseStringBuilder extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(73015230580)
            /*int*/ static MinimumRentedArraySize = 1024;
            //--TRIMMABLE-BOUNDARY-END(73015230580)
            
            //--TRIMMABLE-BOUNDARY-START(77310197876)
            /*ArrayPool<char>*/ static s_arrayPool = null;
            //--TRIMMABLE-BOUNDARY-END(77310197876)
            
            //--TRIMMABLE-BOUNDARY-START(12885688436)
            /*int*/ _nextEndIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(12885688436)
            
            //--TRIMMABLE-BOUNDARY-START(4295753844)
            /*Span<char>*/ _currentBuffer;
            //--TRIMMABLE-BOUNDARY-END(4295753844)
            
            //--TRIMMABLE-BOUNDARY-START(8590721140)
            /*SequenceSegment?*/ _fallbackSequenceSegment = null;
            //--TRIMMABLE-BOUNDARY-END(8590721140)
            
            //--TRIMMABLE-BOUNDARY-START(81605165172)
            /*int */ get SequenceSegmentCount()
            {
                return (this._fallbackSequenceSegment?.Count() ?? null) ?? 0;
            }
            //--TRIMMABLE-BOUNDARY-END(81605165172)
            
            //--TRIMMABLE-BOUNDARY-START(25770590324)
            $ctor$3(/*int*/ conservativeEstimatedStringLength)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590324);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let array = $.$macf.MACF.ReverseStringBuilder.s_arrayPool.Rent(conservativeEstimatedStringLength);
                    this._fallbackSequenceSegment = new $.$macf.MACF.ReverseStringBuilder.SequenceSegment().$ctor$2(array, null);
                    this._currentBuffer = $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(array);
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590324)
            
            //--TRIMMABLE-BOUNDARY-START(30065557620)
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557620);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._currentBuffer = initialBuffer;
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557620)
            
            //--TRIMMABLE-BOUNDARY-START(38655492212)
            /*bool */ get Empty()
            {
                return this._nextEndIndex === this._currentBuffer.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492212)
            
            //--TRIMMABLE-BOUNDARY-START(64425295988)
            /*void */ InsertFront$1(/*scoped ReadOnlySpan<char>*/ span)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let startIndex = ((this._nextEndIndex - span.Length) | 0);
                if (startIndex >= 0)
                {
                    let $t1 = this._currentBuffer;
                    span.CopyTo($t1.Slice(startIndex, $t1.Length - startIndex));
                    this._nextEndIndex = startIndex;
                    return;
                }
                if (this._fallbackSequenceSegment === null)
                {
                    /*var*/ let remainingLength = -startIndex;
                    /*var*/ let sizeToRent = ((this._currentBuffer.Length + $.$$.S.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0))) | 0);
                    /*var*/ let newBuffer = $.$macf.MACF.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macf.MACF.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, null);
                    /*var*/ let newEndIndex = ((((newBuffer.length - this._currentBuffer.Length) | 0) + this._nextEndIndex) | 0);
                    let $t2 = this._currentBuffer;
                    $t2.Slice(this._nextEndIndex, $t2.Length - this._nextEndIndex).CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Char, newBuffer, newEndIndex));
                    newEndIndex -= span.Length;
                    span.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Char, newBuffer, newEndIndex));
                    this._currentBuffer = $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(newBuffer);
                    this._nextEndIndex = newEndIndex;
                }
                else 
                {
                    /*var*/ let remainingLength = -startIndex;
                    let $t3 = span;
                    $t3.Slice(remainingLength, $t3.Length - remainingLength).CopyTo(this._currentBuffer);
                    let $t4 = span;
                    span = $t4.Slice(0, remainingLength);
                    /*var*/ let sizeToRent = $.$$.S.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0));
                    /*var*/ let newBuffer = $.$macf.MACF.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macf.MACF.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, this._fallbackSequenceSegment);
                    this._currentBuffer = $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(newBuffer);
                    startIndex = ((this._currentBuffer.Length - remainingLength) | 0);
                    let $t5 = this._currentBuffer;
                    span.CopyTo($t5.Slice(startIndex, $t5.Length - startIndex));
                    this._nextEndIndex = startIndex;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425295988)
            
            //--TRIMMABLE-BOUNDARY-START(68720263284)
            /*void */ InsertFront$2(T, /*T*/ value)
            {
                /*var*/ let charsWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<char>*/ let result = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 11, null);
                if ($.$dsp(value, T, ($t) => $t.S$ISpanFormattable$TryFormat, result, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.S.Int32), new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))(), $.$$.SG.CultureInfo.InvariantCulture))
                {
                    let $t7 = result;
                    this.InsertFront$1($.$$.S.Span$$($.$$.S.Char).op_Implicit($t7.Slice(0, charsWritten)));
                }
                else 
                {
                    this.InsertFront($.$box(value, T));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720263284)
            
            //--TRIMMABLE-BOUNDARY-START(60130328692)
            /*void */ InsertFront(/*IFormattable*/ formattable)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130328692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InsertFront$1($.$$.S.String.op_Implicit(formattable.S$IFormattable$ToString(null, $.$$.SG.CultureInfo.InvariantCulture)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130328692)
            
            //--TRIMMABLE-BOUNDARY-START(85900132468)
            /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900132468);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $t8 = this._currentBuffer;
                    return this._fallbackSequenceSegment === null ? $.$$.S.String.Create$2($.$$.S.Span$$($.$$.S.Char).op_Implicit($t8.Slice(this._nextEndIndex, $t8.Length - this._nextEndIndex))) : this._fallbackSequenceSegment.ToString$1(this._nextEndIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900132468)
            
            //--TRIMMABLE-BOUNDARY-START(34360524916)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._fallbackSequenceSegment?.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(34360524916)
            
            //--TRIMMABLE-BOUNDARY-START(852084)
            static $_SequenceSegment;
            static get SequenceSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(852084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macf.MACF.ReverseStringBuilder;
                return $cls.$_SequenceSegment ??= $asm.$ncls(`$macf.MACF.ReverseStringBuilder.SequenceSegment`, ($self) => class SequenceSegment extends $.$sm.SB.ReadOnlySequenceSegment$$($.$$.S.Char)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295819380)
                    /*char[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4295819380)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786676)
                    $ctor$2(/*char[]*/ array, /*SequenceSegment?*/ next)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590786676);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._array = array;
                            this.Memory = $.$$.S.ReadOnlyMemory$$($.$$.S.Char).op_Implicit$1(array);
                            this.Next = next;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590786676)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885753972)
                    /*int */ Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885753972);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let count = 0;
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macf.MACF.ReverseStringBuilder.SequenceSegment))
                        {
                            count++;
                        }
                        return count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885753972)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475688564)
                    /*string */ ToString$1(/*int*/ startIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475688564);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.RunningIndex = 0n;
                        /*var*/ let tail = this;
                        let next;
                        while($.$is(tail.Next, $.$macf.MACF.ReverseStringBuilder.SequenceSegment, { set $v($v){ next = $v; } }))
                        {
                            next.RunningIndex = BigInt.asIntN(64, tail.RunningIndex + BigInt(tail.Memory.Length));
                            tail = next;
                        }
                        /*var*/ let sequence = new ($.$sm.SB.ReadOnlySequence$$($.$$.S.Char))().$ctor$3(this, startIndex, tail, tail.Memory.Length);
                        return sequence.ToString();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475688564)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721268)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180721268);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macf.MACF.ReverseStringBuilder.SequenceSegment))
                        {
                            $.$macf.MACF.ReverseStringBuilder.s_arrayPool.Return(current._array, false);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180721268)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $h = 852084;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$sm.SB.ReadOnlySequenceSegment$$($.$$.S.Char); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753972),
    {
      "r": 655361,
      "n": "Count",
      "d": 852084,
      "h": 12885753972,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885753972),
//--TRIMMABLE-BOUNDARY-START(21475688564),
    {
      "r": 1310721,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 852084,
      "h": 21475688564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688564),
//--TRIMMABLE-BOUNDARY-START(17180721268),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 852084,
      "h": 17180721268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721268)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819380),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_array",
      "d": 852084,
      "h": 4295819380,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786676),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "next",
          "p": 852084,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852084,
      "h": 8590786676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786676)
  ],
  "d": 786548,
  "h": 852084
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder+SequenceSegment`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ReverseStringBuilder${separator}SequenceSegment`; }
                }, $cls, ($v) => $cls.$_SequenceSegment = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(852084)
            
            //--TRIMMABLE-BOUNDARY-START(21475623028)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475623028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623028)
            
            //--TRIMMABLE-BOUNDARY-START(21475623028)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475623028)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._nextEndIndex = this._nextEndIndex;
                copy._currentBuffer = this._currentBuffer.$clone();
                copy._fallbackSequenceSegment = this._fallbackSequenceSegment;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295753844)
                this._currentBuffer = $.$default($.$$.S.Span$$($.$$.S.Char));
                //--TRIMMABLE-BOUNDARY-END(4295753844)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17180655732)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(77310197876)
                    this.s_arrayPool = $.$$.SB.ArrayPool$$($.$$.S.Char).Shared;
                    //--TRIMMABLE-BOUNDARY-END(77310197876)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180655732)
            
            static $h = 786548;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605165172),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361396,
        "f": 50331656
      },
      "n": "SequenceSegmentCount",
      "d": 786548,
      "h": 81605165172,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(81605165172),
//--TRIMMABLE-BOUNDARY-START(38655492212),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426804,
        "f": 50331649
      },
      "n": "Empty",
      "d": 786548,
      "h": 38655492212,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655492212)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425295988),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "InsertFront",
      "o": "@$1",
      "d": 786548,
      "h": 64425295988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425295988),
//--TRIMMABLE-BOUNDARY-START(68720263284),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "InsertFront",
      "o": "@$2",
      "d": 786548,
      "h": 68720263284,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(68720263284),
//--TRIMMABLE-BOUNDARY-START(60130328692),
    {
      "r": 65537,
      "p": [
        {
          "n": "formattable",
          "p": 91291649
        }
      ],
      "n": "InsertFront",
      "d": 786548,
      "h": 60130328692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130328692),
//--TRIMMABLE-BOUNDARY-START(85900132468),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 786548,
      "h": 85900132468,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900132468),
//--TRIMMABLE-BOUNDARY-START(34360524916),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 786548,
      "h": 34360524916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524916)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015230580),
    {
      "t": 655361,
      "n": "MinimumRentedArraySize",
      "d": 786548,
      "h": 73015230580,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015230580),
//--TRIMMABLE-BOUNDARY-START(77310197876),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Char).$h,
      "n": "s_arrayPool",
      "d": 786548,
      "h": 77310197876,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310197876),
//--TRIMMABLE-BOUNDARY-START(12885688436),
    {
      "t": 655361,
      "n": "_nextEndIndex",
      "d": 786548,
      "h": 12885688436,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688436),
//--TRIMMABLE-BOUNDARY-START(4295753844),
    {
      "t": $.$$.S.Span$$($.$$.S.Char).$h,
      "n": "_currentBuffer",
      "d": 786548,
      "h": 4295753844,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753844),
//--TRIMMABLE-BOUNDARY-START(8590721140),
    {
      "t": 852084,
      "n": "_fallbackSequenceSegment",
      "d": 786548,
      "h": 8590721140,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721140)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590324),
    {
      "p": [
        {
          "n": "conservativeEstimatedStringLength",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786548,
      "h": 25770590324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590324),
//--TRIMMABLE-BOUNDARY-START(30065557620),
    {
      "p": [
        {
          "n": "initialBuffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786548,
      "h": 30065557620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557620),
//--TRIMMABLE-BOUNDARY-START(21475623028),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786548,
      "h": 21475623028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623028)
  ],
  "h": 786548
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macf.MACF.ReverseStringBuilder.SequenceSegment ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ReverseStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786548)
        
        

        //--TRIMMABLE-BOUNDARY-START(655476)
        $asm.$str(`$macf.MACF.FieldIdentifier`, ($self) => class FieldIdentifier extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295622772)
            /*ConcurrentDictionary<(Type ModelType, MemberInfo Member), Func<object, object>>*/ static _fieldAccessors = null;
            //--TRIMMABLE-BOUNDARY-END(4295622772)
            
            //--TRIMMABLE-BOUNDARY-START(17180524660)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macf.MACH.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macf.MACH.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.S.Action().$ctor($.$macf.MACF.FieldIdentifier, $.$macf.MACF.FieldIdentifier.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180524660)
            
            //--TRIMMABLE-BOUNDARY-START(34360393844)
            static /*FieldIdentifier */ Create(TField, /*Expression<Func<TField>>*/ accessor)
            {
                /*var*/ let model;
                /*var*/ let fieldName;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(accessor, "accessor");
                $.$macf.MACF.FieldIdentifier.ParseAccessor(TField, accessor, $.$ref(() => model, ($v) => model = $v, $.$$.S.Object), $.$ref(() => fieldName, ($v) => fieldName = $v, $.$$.S.String));
                return new $.$macf.MACF.FieldIdentifier().$ctor$3(model, fieldName);
            }
            //--TRIMMABLE-BOUNDARY-END(34360393844)
            
            //--TRIMMABLE-BOUNDARY-START(25770459252)
            $ctor$3(/*object*/ model, /*string*/ fieldName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770459252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(model, "model");
                    if ($.$$.S.Object.GetType.call(model).IsValueType)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13("The model must be a reference-typed object.", "model");
                    }
                    this.Model = model;
                    this.FieldName = $.$firstOf(fieldName, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("fieldName") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770459252)
            
            //--TRIMMABLE-BOUNDARY-START(81605034100)
            /*object*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(81605034100)
            
            //--TRIMMABLE-BOUNDARY-START(47245295732)
            /*string*/ FieldName = null;
            //--TRIMMABLE-BOUNDARY-END(47245295732)
            
            //--TRIMMABLE-BOUNDARY-START(68720132212)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720132212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let modelHash = $.$$.SRC.RuntimeHelpers.GetHashCode$1(this.Model);
                /*var*/ let fieldHash = $.$$.S.StringComparer.Ordinal.GetHashCode$2(this.FieldName);
                return new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(modelHash, fieldHash).GetHashCode();
            }
            //--TRIMMABLE-BOUNDARY-END(68720132212)
            
            //--TRIMMABLE-BOUNDARY-START(38655361140)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655361140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let otherIdentifier;
                    return $.$is(obj, $.$macf.MACF.FieldIdentifier, { set $v($v){ otherIdentifier = $v; } }) && this.Equals$2(otherIdentifier);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655361140)
            
            //--TRIMMABLE-BOUNDARY-START(42950328436)
            /*bool */ Equals$2(/*FieldIdentifier*/ otherIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950328436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Object.ReferenceEquals(otherIdentifier.Model, this.Model) && $.$$.S.String.Equals$3(otherIdentifier.FieldName, this.FieldName, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(42950328436)
            
            //--TRIMMABLE-BOUNDARY-START(85900001396)
            static /*void */ ParseAccessor(T, /*Expression<Func<T>>*/ accessor, /*out object*/ model, /*out string*/ fieldName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900001396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let accessorBody = accessor.Body;
                let unaryExpression;
                if ($.$is(accessorBody, $.$sle.SLE.UnaryExpression, { set $v($v){ unaryExpression = $v; } }) && unaryExpression.NodeType === 10/*ExpressionType.Convert*/ && unaryExpression.Type === $.$$.S.Object.$type)
                {
                    accessorBody = unaryExpression.Operand;
                }
                //switch (accessorBody)
                {
                    let memberExpression;
                    let methodCallExpression;
                    let binaryExpression;
                    $switchJumpStart3: 
                    //case MemberExpression memberExpression:
                    if ($.$is(accessorBody, $.$sle.SLE.MemberExpression, { set $v(v){ memberExpression = v; } }))
                    {
                        fieldName.$v = memberExpression.Member.Name;
                        var modelLambda;
                        var modelLambdaCompiled;
                        var result;
                        //switch (memberExpression.Expression)
                        let $switch4 = memberExpression.Expression;
                        {
                            let constant;
                            let member;
                            $switchJumpStart4: 
                            //case ConstantExpression constant when constant.Value == null:
                            if ($.$is($switch4, $.$sle.SLE.ConstantExpression, { set $v(v){ constant = v; } }) && constant.Value === null)
                            {
                                throw new $.$$.S.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.");
                            }
                            //case ConstantExpression constant when constant.Value != null:
                            else if ($.$is($switch4, $.$sle.SLE.ConstantExpression, { set $v(v){ constant = v; } }) && constant.Value !== null)
                            {
                                model.$v = constant.Value;
                            }
                            //case MemberExpression member when member.Expression is ConstantExpression:
                            else if ($.$is($switch4, $.$sle.SLE.MemberExpression, { set $v(v){ member = v; } }) && $.$is(member.Expression, $.$sle.SLE.ConstantExpression))
                            {
                                model.$v = $.$macf.MACF.FieldIdentifier.GetModelFromMemberAccess(member, null);
                            }
                            //case not null:
                            else if ($switch4 != null && $switch4 === null)
                            {
                                modelLambda = $.$sle.SLE.Expression.Lambda$3($.$$.S.Func$$($.$$.S.Object).$type, memberExpression.Expression, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                modelLambdaCompiled = $.$cast(modelLambda.Compile(), $.$$.S.Func$$($.$$.S.Object));
                                result = $.$firstOf(modelLambdaCompiled.Invoke(), () => { throw new $.$$.S.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.") });
                                model.$v = result;
                            }
                            //default
                            else
                            {
                                throw new $.$$.S.ArgumentException().$ctor$14(`The provided expression contains a ${$.$strNN($.$$.S.Object.GetType.call(accessorBody).Name)} which is not supported. ${$.$strNN("FieldIdentifier")} only supports simple member accessors (fields, properties) of an object.`);
                            }
                        }
                    }
                    //case MethodCallExpression methodCallExpression when ExpressionFormatter.IsSingleArgumentIndexer(accessorBody):
                    else if ($.$is(accessorBody, $.$sle.SLE.MethodCallExpression, { set $v(v){ methodCallExpression = v; } }) && $.$macf.MACF.ExpressionFormatter.IsSingleArgumentIndexer(accessorBody))
                    {
                        fieldName.$v = $.$macf.MACF.ExpressionFormatter.FormatIndexArgument$1(methodCallExpression.Arguments.get_Item(0));
                        model.$v = $.$macf.MACF.FieldIdentifier.GetModelFromIndexer(methodCallExpression.Object);
                    }
                    //case BinaryExpression binaryExpression when binaryExpression.NodeType == ExpressionType.ArrayIndex:
                    else if ($.$is(accessorBody, $.$sle.SLE.BinaryExpression, { set $v(v){ binaryExpression = v; } }) && binaryExpression.NodeType === 5/*ExpressionType.ArrayIndex*/)
                    {
                        fieldName.$v = $.$macf.MACF.ExpressionFormatter.FormatIndexArgument$1(binaryExpression.Right);
                        model.$v = $.$macf.MACF.FieldIdentifier.GetModelFromIndexer(binaryExpression.Left);
                    }
                    //default
                    else
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14(`The provided expression contains a ${$.$strNN($.$$.S.Object.GetType.call(accessorBody).Name)} which is not supported. ${$.$strNN("FieldIdentifier")} only supports simple member accessors (fields, properties) of an object.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900001396)
            
            //--TRIMMABLE-BOUNDARY-START(77310066804)
            static /*object */ GetModelFromMemberAccess(/*MemberExpression*/ member, /*ConcurrentDictionary<(Type ModelType, MemberInfo Member), Func<object, object>>?*/ cache)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310066804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cache ??= $.$macf.MACF.FieldIdentifier._fieldAccessors;
                /*Func<object, object>?*/ let accessor = null;
                /*object?*/ let value = null;
                //switch (member.Expression)
                let $switch5 = member.Expression;
                {
                    let model;
                    $switchJumpStart5: 
                    //case ConstantExpression model:
                    if ($.$is($switch5, $.$sle.SLE.ConstantExpression, { set $v(v){ model = v; } }))
                    {
                        value = $.$firstOf(model.Value, () => { throw new $.$$.S.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.") });
                        accessor = cache.GetOrAdd(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.SR.MemberInfo))().$ctor$3($.$$.S.Object.GetType.call(value), member.Member), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.SR.MemberInfo), $.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object)))().$ctor($.$macf.MACF.FieldIdentifier, CreateAccessor, $hIStZg ??= {"r":$.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object).$h,"p":[{"n":"arg","p":$.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.SR.MemberInfo).$h}],"n":"CreateAccessor","d":655476,"h":0,"f":16777250}));
                    }
                    //default
                    else
                    {
                    }
                }
                if (accessor === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Unable to compile expression: ${$.$strNN(member.ToString())}`);
                }
                if (value === null)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.");
                }
                /*var*/ let result = accessor.Invoke(value);
                return result;
                /*static Func<object, object>*/  function CreateAccessor(/*(Type model, MemberInfo member)*/ arg)
                {
                    /*var*/ let parameter = $.$sle.SLE.Expression.Parameter($.$$.S.Object.$type, "value");
                    /*Expression*/ let expression = $.$sle.SLE.Expression.Convert$1(parameter, arg.Item1);
                    expression = $.$sle.SLE.Expression.MakeMemberAccess(expression, arg.Item2);
                    expression = $.$sle.SLE.Expression.Convert$1(expression, $.$$.S.Object.$type);
                    /*var*/ let lambda = $.$sle.SLE.Expression.Lambda$15($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object), expression, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ parameter ], null, null));
                    /*var*/ let func = lambda.Compile$3();
                    return func;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310066804)
            
            //--TRIMMABLE-BOUNDARY-START(73015099508)
            static /*object */ GetModelFromIndexer(/*Expression*/ methodCallExpression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015099508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let model;
                /*var*/ let methodCallObjectLambda = $.$sle.SLE.Expression.Lambda$3($.$$.S.Func$$($.$$.S.Object).$type, methodCallExpression, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                /*var*/ let methodCallObjectLambdaCompiled = $.$cast(methodCallObjectLambda.Compile(), $.$$.S.Func$$($.$$.S.Object));
                /*var*/ let result = methodCallObjectLambdaCompiled.Invoke();
                if (result === null)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.");
                }
                model = result;
                return model;
            }
            //--TRIMMABLE-BOUNDARY-END(73015099508)
            
            //--TRIMMABLE-BOUNDARY-START(30065426548)
            static /*void */ ClearCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.MACF.FieldIdentifier._fieldAccessors.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(30065426548)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.Forms.FieldIdentifier>.Equals(Microsoft.AspNetCore.Components.Forms.FieldIdentifier)
            S$IEquatable$Microsoft$AspNetCore$Components$Forms$FieldIdentifier$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(21475491956)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475491956)
            
            //--TRIMMABLE-BOUNDARY-START(21475491956)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475491956)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Model = this.Model;
                copy.FieldName = this.FieldName;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(17180524660)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622772)
                    this._fieldAccessors = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.SR.MemberInfo), $.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4295622772)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180524660)
            
            static $h = 655476;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605034100),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425164916,
        "f": 50331649
      },
      "n": "Model",
      "d": 655476,
      "h": 81605034100,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605034100),
//--TRIMMABLE-BOUNDARY-START(47245295732),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835230324,
        "f": 50331649
      },
      "n": "FieldName",
      "d": 655476,
      "h": 47245295732,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245295732)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360393844),
    {
      "r": 655476,
      "p": [
        {
          "n": "accessor",
          "p": (TField) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TField)).$h
        }
      ],
      "g": [
        "TField"
      ],
      "n": "Create",
      "d": 655476,
      "h": 34360393844,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34360393844),
//--TRIMMABLE-BOUNDARY-START(68720132212),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 655476,
      "h": 68720132212,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720132212),
//--TRIMMABLE-BOUNDARY-START(38655361140),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 655476,
      "h": 38655361140,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655361140),
//--TRIMMABLE-BOUNDARY-START(42950328436),
    {
      "r": 262145,
      "p": [
        {
          "n": "otherIdentifier",
          "p": 655476
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 655476,
      "h": 42950328436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950328436),
//--TRIMMABLE-BOUNDARY-START(85900001396),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": (T) => $.$sle.SLE.Expression$$($.$$.S.Func$$(T)).$h
        },
        {
          "n": "model",
          "p": 131073,
          "f": 2
        },
        {
          "n": "fieldName",
          "p": 1310721,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "ParseAccessor",
      "d": 655476,
      "h": 85900001396,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(85900001396),
//--TRIMMABLE-BOUNDARY-START(77310066804),
    {
      "r": 131073,
      "p": [
        {
          "n": "member",
          "p": 39321637
        },
        {
          "n": "cache",
          "p": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.SR.MemberInfo), $.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object)).$h,
          "f": 65
        }
      ],
      "n": "GetModelFromMemberAccess",
      "d": 655476,
      "h": 77310066804,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77310066804),
//--TRIMMABLE-BOUNDARY-START(73015099508),
    {
      "r": 131073,
      "p": [
        {
          "n": "methodCallExpression",
          "p": 8781861
        }
      ],
      "n": "GetModelFromIndexer",
      "d": 655476,
      "h": 73015099508,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73015099508),
//--TRIMMABLE-BOUNDARY-START(30065426548),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 655476,
      "h": 30065426548,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065426548)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622772),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.SR.MemberInfo), $.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object)).$h,
      "n": "_fieldAccessors",
      "d": 655476,
      "h": 4295622772,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295622772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770459252),
    {
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "fieldName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655476,
      "h": 25770459252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459252),
//--TRIMMABLE-BOUNDARY-START(21475491956),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655476,
      "h": 21475491956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491956)
  ],
  "h": 655476
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$macf.MACF.FieldIdentifier) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.FieldIdentifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}FieldIdentifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655476)
        
        

        //--TRIMMABLE-BOUNDARY-START(65652)
        $asm.$cls(`$macf.MACF.DataAnnotationsValidator`, ($self) => class DataAnnotationsValidator extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8590000244)
            /*IDisposable?*/ _subscriptions = null;
            //--TRIMMABLE-BOUNDARY-END(8590000244)
            
            //--TRIMMABLE-BOUNDARY-START(4295032948)
            /*EditContext?*/ _originalEditContext = null;
            //--TRIMMABLE-BOUNDARY-END(4295032948)
            
            //--TRIMMABLE-BOUNDARY-START(25769869428)
            /*EditContext?*/ CurrentEditContext = null;
            //--TRIMMABLE-BOUNDARY-END(25769869428)
            
            //--TRIMMABLE-BOUNDARY-START(60129607796)
            /*IServiceProvider*/ ServiceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(60129607796)
            
            //--TRIMMABLE-BOUNDARY-START(51539673204)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentEditContext === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN($.$strNN(`${$.$strNN("DataAnnotationsValidator")} requires a cascading `) + $.$strNN(`parameter of type ${$.$strNN("EditContext")}. For example, you can use ${$.$strNN("DataAnnotationsValidator")} `)) + $.$strNN(`inside an EditForm.`));
                }
                this._subscriptions = $.$macf.MACF.EditContextDataAnnotationsExtensions.EnableDataAnnotationsValidation(this.CurrentEditContext, this.ServiceProvider);
                this._originalEditContext = this.CurrentEditContext;
            }
            //--TRIMMABLE-BOUNDARY-END(51539673204)
            
            //--TRIMMABLE-BOUNDARY-START(55834640500)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentEditContext !== this._originalEditContext)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN(`${$.$strNN($.$$.S.Object.GetType.call(this).ToString())} does not support changing the `) + $.$strNN(`${$.$strNN("EditContext")} dynamically.`));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834640500)
            
            //--TRIMMABLE-BOUNDARY-START(30064836724)
            /*void */ Dispose(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30064836724)
            
            //--TRIMMABLE-BOUNDARY-START(81604444276)
            /*void */ S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._subscriptions?.S$IDisposable$Dispose();
                this._subscriptions = null;
                this.Dispose(true);
            }
            //--TRIMMABLE-BOUNDARY-END(81604444276)
            
            //--TRIMMABLE-BOUNDARY-START(21474902132)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902132)
            
            //--TRIMMABLE-BOUNDARY-START(21474902132)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21474902132)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129607796)
                this.ServiceProvider = null;
                //--TRIMMABLE-BOUNDARY-END(60129607796)
                
            }
            static $h = 65652;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25769869428),
    {
      "p": 131188,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654771316,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719542388,
        "f": 83886082
      },
      "n": "CurrentEditContext",
      "d": 65652,
      "h": 25769869428,
      "f": 2097154,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25769869428),
//--TRIMMABLE-BOUNDARY-START(60129607796),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244705908,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309476980,
        "f": 83886082
      },
      "n": "ServiceProvider",
      "d": 65652,
      "h": 60129607796,
      "f": 2097154,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129607796)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539673204),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 65652,
      "h": 51539673204,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51539673204),
//--TRIMMABLE-BOUNDARY-START(55834640500),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 65652,
      "h": 55834640500,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55834640500),
//--TRIMMABLE-BOUNDARY-START(30064836724),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "d": 65652,
      "h": 30064836724,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30064836724)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590000244),
    {
      "t": 91095041,
      "n": "_subscriptions",
      "d": 65652,
      "h": 8590000244,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000244),
//--TRIMMABLE-BOUNDARY-START(4295032948),
    {
      "t": 131188,
      "n": "_originalEditContext",
      "d": 65652,
      "h": 4295032948,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032948)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21474902132),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65652,
      "h": 21474902132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902132)
  ],
  "h": 65652
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.DataAnnotationsValidator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}DataAnnotationsValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65652)
        
        

        //--TRIMMABLE-BOUNDARY-START(589940)
        $asm.$cls(`$macf.MACF.FieldChangedEventArgs`, ($self) => class FieldChangedEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(8590524532)
            $ctor$2(/*in FieldIdentifier*/ fieldIdentifier)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524532);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FieldIdentifier = fieldIdentifier.$v;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524532)
            
            //--TRIMMABLE-BOUNDARY-START(12885491828)
            /*FieldIdentifier*/ FieldIdentifier;
            //--TRIMMABLE-BOUNDARY-END(12885491828)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885491828)
                this.FieldIdentifier = $.$default($.$macf.MACF.FieldIdentifier);
                //--TRIMMABLE-BOUNDARY-END(12885491828)
                
            }
            static $h = 589940;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885491828),
    {
      "p": 655476,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475426420,
        "f": 50331649
      },
      "n": "FieldIdentifier",
      "d": 589940,
      "h": 12885491828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885491828)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524532),
    {
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655476,
          "f": 8
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589940,
      "h": 8590524532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524532)
  ],
  "h": 589940
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}FieldChangedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589940)
        
        

        //--TRIMMABLE-BOUNDARY-START(983156)
        $asm.$cls(`$macf.MACF.ValidationRequestedEventArgs`, ($self) => class ValidationRequestedEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(12885885044)
            /*ValidationRequestedEventArgs*/ static Empty$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885885044)
            
            //--TRIMMABLE-BOUNDARY-START(8590917748)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917748);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917748)
            
            //--TRIMMABLE-BOUNDARY-START(8590917748)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590917748)
            
            //--TRIMMABLE-BOUNDARY-START(4295950452)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885885044)
                    this.Empty$1 = new $.$macf.MACF.ValidationRequestedEventArgs().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(12885885044)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295950452)
            
            static $h = 983156;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885885044),
    {
      "t": 983156,
      "n": "Empty",
      "o": "@$1",
      "d": 983156,
      "h": 12885885044,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885885044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917748),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983156,
      "h": 8590917748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917748)
  ],
  "h": 983156
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ValidationRequestedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983156)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048692)
        $asm.$cls(`$macf.MACF.ValidationStateChangedEventArgs`, ($self) => class ValidationStateChangedEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(12885950580)
            /*ValidationStateChangedEventArgs*/ static Empty$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885950580)
            
            //--TRIMMABLE-BOUNDARY-START(8590983284)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590983284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983284)
            
            //--TRIMMABLE-BOUNDARY-START(8590983284)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590983284)
            
            //--TRIMMABLE-BOUNDARY-START(4296015988)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885950580)
                    this.Empty$1 = new $.$macf.MACF.ValidationStateChangedEventArgs().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(12885950580)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296015988)
            
            static $h = 1048692;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885950580),
    {
      "t": 1048692,
      "n": "Empty",
      "o": "@$1",
      "d": 1048692,
      "h": 12885950580,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590983284),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048692,
      "h": 8590983284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590983284)
  ],
  "h": 1048692
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}ValidationStateChangedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048692)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives"));
})();
//--TRIMMABLE-BOUNDARY-END(116)
