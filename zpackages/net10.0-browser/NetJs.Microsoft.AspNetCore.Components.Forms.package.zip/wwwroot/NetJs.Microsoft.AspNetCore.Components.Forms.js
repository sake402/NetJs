
//--TRIMMABLE-BOUNDARY-START(109)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Forms", 
    {
  "h": 109,
  "f": "Microsoft.AspNetCore.Components.Forms",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "Forms and validation support for Blazor applications.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.Forms",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.Forms",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.Forms.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 115605505,
      "c": 4410572801,
      "a": [
        {
          "v": 1114221,
          "t": 187629569
        }
      ]
    },
    {
      "t": 115605505,
      "c": 4410572801,
      "a": [
        {
          "v": 196717,
          "t": 187629569
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(721005)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.FieldState", ($self) => class FieldState extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688301)
            /*FieldIdentifier*/ _fieldIdentifier;
            //--TRIMMABLE-BOUNDARY-END(4295688301)
            
            //--TRIMMABLE-BOUNDARY-START(8590655597)
            /*HashSet<ValidationMessageStore>?*/ _validationMessageStores = null;
            //--TRIMMABLE-BOUNDARY-END(8590655597)
            
            //--TRIMMABLE-BOUNDARY-START(12885622893)
            $ctor$1(/*FieldIdentifier*/ fieldIdentifier)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622893);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._fieldIdentifier = fieldIdentifier;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622893)
            
            //--TRIMMABLE-BOUNDARY-START(42950393965)
            /*bool*/ IsModified = false;
            //--TRIMMABLE-BOUNDARY-END(42950393965)
            
            //--TRIMMABLE-BOUNDARY-START(38655426669)
            /*IEnumerable<string> */ GetValidationMessages()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this._validationMessageStores !== null)
                    {
                        var $en4 = this._validationMessageStores.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var store = $en4.Current;
                            {
                                var $en6 = store.get_Item(this._fieldIdentifier).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var message = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        yield message;
                                    }
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(38655426669)
            
            //--TRIMMABLE-BOUNDARY-START(21475557485)
            /*void */ AssociateWithValidationMessageStore(/*ValidationMessageStore*/ validationMessageStore)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._validationMessageStores === null)
                {
                    this._validationMessageStores = new ($.$$.System.Collections.Generic.HashSet$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore))().$ctor$1();
                }
                this._validationMessageStores.Add(validationMessageStore);
            }
            //--TRIMMABLE-BOUNDARY-END(21475557485)
            
            //--TRIMMABLE-BOUNDARY-START(25770524781)
            /*void */ DissociateFromValidationMessageStore(/*ValidationMessageStore*/ validationMessageStore)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524781);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._validationMessageStores?.Remove(validationMessageStore) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770524781)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688301)
                this._fieldIdentifier = $.$default($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier);
                //--TRIMMABLE-BOUNDARY-END(4295688301)
                
            }
            static $h = 721005;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950393965),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360459373,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540328557,
        "f": 83886081
      },
      "n": "IsModified",
      "d": 721005,
      "h": 42950393965,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950393965)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655426669),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "n": "GetValidationMessages",
      "d": 721005,
      "h": 38655426669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426669),
//--TRIMMABLE-BOUNDARY-START(21475557485),
    {
      "r": 65537,
      "p": [
        {
          "n": "validationMessageStore",
          "p": 917613
        }
      ],
      "n": "AssociateWithValidationMessageStore",
      "d": 721005,
      "h": 21475557485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557485),
//--TRIMMABLE-BOUNDARY-START(25770524781),
    {
      "r": 65537,
      "p": [
        {
          "n": "validationMessageStore",
          "p": 917613
        }
      ],
      "n": "DissociateFromValidationMessageStore",
      "d": 721005,
      "h": 25770524781,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524781)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688301),
    {
      "t": 655469,
      "n": "_fieldIdentifier",
      "d": 721005,
      "h": 4295688301,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688301),
//--TRIMMABLE-BOUNDARY-START(8590655597),
    {
      "t": $.$$.System.Collections.Generic.HashSet$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore).$h,
      "n": "_validationMessageStores",
      "d": 721005,
      "h": 8590655597,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655597)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622893),
    {
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721005,
      "h": 12885622893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622893)
  ],
  "h": 721005
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FieldState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721005)
        
        
        //--TRIMMABLE-BOUNDARY-START(327789)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.EditContextProperties", ($self) => class EditContextProperties extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295085)
            /*Dictionary<object, object>?*/ _contents = null;
            //--TRIMMABLE-BOUNDARY-END(4295295085)
            
            //--TRIMMABLE-BOUNDARY-START(34360066157)
            /*object*/ get_Item(/*object*/ key)
            {
                return this._contents === null ? (() =>
                {
        throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$9()        })() : this._contents.get_Item(key);
            }
            /*void*/ set_Item(/*object*/ key, /*object*/ value)
            {
                this._contents ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object))().$ctor$1();
                this._contents.set_Item(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066157)
            
            //--TRIMMABLE-BOUNDARY-START(38655033453)
            /*bool */ TryGetValue(/*object*/ key, /*out object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._contents === null)
                {
                    value.$v = null;
                    return false;
                }
                else 
                {
                    return this._contents.TryGetValue(key, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033453)
            
            //--TRIMMABLE-BOUNDARY-START(21475164269)
            /*bool */ Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._contents?.Remove$1(key) ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164269)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 327789;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360066157),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196973,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065098861,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": 327789,
      "h": 34360066157,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360066157)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655033453),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 327789,
      "h": 38655033453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033453),
//--TRIMMABLE-BOUNDARY-START(21475164269),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 327789,
      "h": 21475164269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164269)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295085),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object).$h,
      "n": "_contents",
      "d": 327789,
      "h": 4295295085,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295085)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262381),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327789,
      "h": 8590262381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262381)
  ],
  "h": 327789
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EditContextProperties`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327789)
        
        
        //--TRIMMABLE-BOUNDARY-START(917613)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore", ($self) => class ValidationMessageStore extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295884909)
            /*EditContext*/ _editContext = null;
            //--TRIMMABLE-BOUNDARY-END(4295884909)
            
            //--TRIMMABLE-BOUNDARY-START(8590852205)
            /*Dictionary<FieldIdentifier, List<string>>*/ _messages = null;
            //--TRIMMABLE-BOUNDARY-END(8590852205)
            
            //--TRIMMABLE-BOUNDARY-START(12885819501)
            $ctor$1(/*EditContext*/ editContext)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885819501);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._editContext = $.$firstOf(editContext, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("editContext") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819501)
            
            //--TRIMMABLE-BOUNDARY-START(17180786797)
            /*void */ Add$3(/*in FieldIdentifier*/ fieldIdentifier, /*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786797);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetOrCreateMessagesListForField(fieldIdentifier).Add(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180786797)
            
            //--TRIMMABLE-BOUNDARY-START(21475754093)
            /*void */ Add$1(/*Expression<Func<object>>*/ accessor, /*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add$3($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$$.System.Object, accessor), ), message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475754093)
            
            //--TRIMMABLE-BOUNDARY-START(25770721389)
            /*void */ Add$2(/*in FieldIdentifier*/ fieldIdentifier, /*IEnumerable<string>*/ messages)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770721389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetOrCreateMessagesListForField(fieldIdentifier).AddRange(messages);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721389)
            
            //--TRIMMABLE-BOUNDARY-START(30065688685)
            /*void */ Add(/*Expression<Func<object>>*/ accessor, /*IEnumerable<string>*/ messages)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065688685);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add$2($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$$.System.Object, accessor), ), messages);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065688685)
            
            //--TRIMMABLE-BOUNDARY-START(77310328941)
            /*IEnumerable<string>*/ get_Item(/*FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let messages;
                return this._messages.TryGetValue(fieldIdentifier, $.$ref(() => messages, ($v) => messages = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))) ? messages : $.$$.System.Array.Empty($.$$.System.String);
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(77310328941)
            
            //--TRIMMABLE-BOUNDARY-START(81605296237)
            /*IEnumerable<string>*/ get_Item$1(/*Expression<Func<object>>*/ accessor)
            {
                return this.get_Item($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$$.System.Object, accessor));
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(81605296237)
            
            //--TRIMMABLE-BOUNDARY-START(38655623277)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._messages.Keys.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var fieldIdentifier = $en2.Current;
                    {
                        this.DissociateFromField($.$ref(() => fieldIdentifier, ));
                    }
                }
                this._messages.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(38655623277)
            
            //--TRIMMABLE-BOUNDARY-START(42950590573)
            /*void */ Clear$1(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950590573);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Clear$2($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$$.System.Object, accessor), ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950590573)
            
            //--TRIMMABLE-BOUNDARY-START(47245557869)
            /*void */ Clear$2(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DissociateFromField(fieldIdentifier);
                this._messages.Remove$1(fieldIdentifier.$v);
            }
            //--TRIMMABLE-BOUNDARY-END(47245557869)
            
            //--TRIMMABLE-BOUNDARY-START(73015361645)
            /*List<string> */ GetOrCreateMessagesListForField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let messagesForField;
                if (!this._messages.TryGetValue(fieldIdentifier.$v, $.$ref(() => messagesForField, ($v) => messagesForField = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))))
                {
                    messagesForField = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    this._messages.Add(fieldIdentifier.$v, messagesForField);
                    this.AssociateWithField(fieldIdentifier);
                }
                return messagesForField;
            }
            //--TRIMMABLE-BOUNDARY-END(73015361645)
            
            //--TRIMMABLE-BOUNDARY-START(34360655981)
            /*void */ AssociateWithField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360655981);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._editContext.GetOrAddFieldState(fieldIdentifier).AssociateWithValidationMessageStore(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360655981)
            
            //--TRIMMABLE-BOUNDARY-START(51540525165)
            /*void */ DissociateFromField(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540525165);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._editContext.GetFieldState(fieldIdentifier)?.DissociateFromValidationMessageStore(this) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540525165)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590852205)
                this._messages = new ($.$$.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590852205)
                
            }
            static $h = 917613;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310328941),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "i": [
        {
          "n": "fieldIdentifier",
          "p": 655469
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130459757,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 917613,
      "h": 77310328941,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310328941),
//--TRIMMABLE-BOUNDARY-START(81605296237),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "i": [
        {
          "n": "accessor",
          "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$($.$$.System.Object)).$h
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720394349,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$3",
      "d": 917613,
      "h": 81605296237,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605296237)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180786797),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$3",
      "d": 917613,
      "h": 17180786797,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786797),
//--TRIMMABLE-BOUNDARY-START(21475754093),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$($.$$.System.Object)).$h
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 917613,
      "h": 21475754093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754093),
//--TRIMMABLE-BOUNDARY-START(25770721389),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        },
        {
          "n": "messages",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "Add",
      "o": "@$2",
      "d": 917613,
      "h": 25770721389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721389),
//--TRIMMABLE-BOUNDARY-START(30065688685),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$($.$$.System.Object)).$h
        },
        {
          "n": "messages",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "Add",
      "d": 917613,
      "h": 30065688685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688685),
//--TRIMMABLE-BOUNDARY-START(38655623277),
    {
      "r": 65537,
      "n": "Clear",
      "d": 917613,
      "h": 38655623277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655623277),
//--TRIMMABLE-BOUNDARY-START(42950590573),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$($.$$.System.Object)).$h
        }
      ],
      "n": "Clear",
      "o": "@$1",
      "d": 917613,
      "h": 42950590573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950590573),
//--TRIMMABLE-BOUNDARY-START(47245557869),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "Clear",
      "o": "@$2",
      "d": 917613,
      "h": 47245557869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245557869),
//--TRIMMABLE-BOUNDARY-START(73015361645),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "GetOrCreateMessagesListForField",
      "d": 917613,
      "h": 73015361645,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015361645),
//--TRIMMABLE-BOUNDARY-START(34360655981),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "AssociateWithField",
      "d": 917613,
      "h": 34360655981,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360655981),
//--TRIMMABLE-BOUNDARY-START(51540525165),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "DissociateFromField",
      "d": 917613,
      "h": 51540525165,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540525165)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884909),
    {
      "t": 131181,
      "n": "_editContext",
      "d": 917613,
      "h": 4295884909,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884909),
//--TRIMMABLE-BOUNDARY-START(8590852205),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$$.System.Collections.Generic.List$$($.$$.System.String)).$h,
      "n": "_messages",
      "d": 917613,
      "h": 8590852205,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852205)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819501),
    {
      "p": [
        {
          "n": "editContext",
          "p": 131181
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917613,
      "h": 12885819501,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819501)
  ],
  "h": 917613
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ValidationMessageStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917613)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114221)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager", ($self) => class HotReloadManager extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770917997)
            /*HotReloadManager*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(25770917997)
            
            //--TRIMMABLE-BOUNDARY-START(51540721773)
            /*bool*/ MetadataUpdateSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51540721773)
            
            //--TRIMMABLE-BOUNDARY-START(47245754477)
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245754477)
            
            //--TRIMMABLE-BOUNDARY-START(55835689069)
            /*Action?*/ OnDeltaApplied = null;
            //--TRIMMABLE-BOUNDARY-END(55835689069)
            
            //--TRIMMABLE-BOUNDARY-START(55835689069)
            //--TRIMMABLE-BOUNDARY-START(21475950701)
            add_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Combine(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475950701)
            
            //--TRIMMABLE-BOUNDARY-START(64425623661)
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Remove(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425623661)
            
            //--TRIMMABLE-BOUNDARY-END(55835689069)
            
            //--TRIMMABLE-BOUNDARY-START(81605492845)
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605492845);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605492845)
            
            //--TRIMMABLE-BOUNDARY-START(77310525549)
            /*void */ TriggerOnDeltaApplied()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310525549);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310525549)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataUpdateSupported = $.$$.System.Reflection.Metadata.MetadataUpdater.IsSupported;
            }
            //--TRIMMABLE-BOUNDARY-START(4296081517)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770917997)
                    this.Default = new $.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770917997)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296081517)
            
            static $h = 1114221;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540721773),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787181,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015558253,
        "f": 83886081
      },
      "n": "MetadataUpdateSupported",
      "d": 1114221,
      "h": 51540721773,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540721773),
//--TRIMMABLE-BOUNDARY-START(47245754477),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360852589,
        "f": 50331649
      },
      "n": "IsSubscribedTo",
      "d": 1114221,
      "h": 47245754477,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245754477)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605492845),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "UpdateApplication",
      "d": 1114221,
      "h": 81605492845,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605492845),
//--TRIMMABLE-BOUNDARY-START(77310525549),
    {
      "r": 65537,
      "n": "TriggerOnDeltaApplied",
      "d": 1114221,
      "h": 77310525549,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310525549)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770917997),
    {
      "t": 1114221,
      "n": "Default",
      "d": 1114221,
      "h": 25770917997,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770917997)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048813),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114221,
      "h": 8591048813,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048813)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55835689069),
    {
      "e": 42270721,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42270721
          }
        ],
        "n": "add_OnDeltaApplied",
        "d": 1114221,
        "h": 21475950701,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42270721
          }
        ],
        "n": "remove_OnDeltaApplied",
        "d": 1114221,
        "h": 64425623661,
        "f": 285212673
      },
      "n": "OnDeltaApplied",
      "d": 1114221,
      "h": 55835689069,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835689069)
  ],
  "h": 1114221
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HotReloadManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114221)
        
        
        //--TRIMMABLE-BOUNDARY-START(131181)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.EditContext", ($self) => class EditContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098477)
            /*Dictionary<FieldIdentifier, FieldState>*/ _fieldStates = null;
            //--TRIMMABLE-BOUNDARY-END(4295098477)
            
            //--TRIMMABLE-BOUNDARY-START(8590065773)
            $ctor$1(/*object*/ model)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065773);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Model = $.$firstOf(model, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("model") });
                    this.Properties = new $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextProperties().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065773)
            
            //--TRIMMABLE-BOUNDARY-START(146029019245)
            /*EventHandler<FieldChangedEventArgs>?*/ OnFieldChanged = null;
            //--TRIMMABLE-BOUNDARY-END(146029019245)
            
            //--TRIMMABLE-BOUNDARY-START(146029019245)
            //--TRIMMABLE-BOUNDARY-START(30064902253)
            add_OnFieldChanged(/*EventHandler<FieldChangedEventArgs>?*/ value)
            {
                this.OnFieldChanged = $.$$.System.Delegate.Combine(this.OnFieldChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30064902253)
            
            //--TRIMMABLE-BOUNDARY-START(167503855725)
            remove_OnFieldChanged(/*EventHandler<FieldChangedEventArgs>?*/ value)
            {
                this.OnFieldChanged = $.$$.System.Delegate.Remove(this.OnFieldChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(167503855725)
            
            //--TRIMMABLE-BOUNDARY-END(146029019245)
            
            //--TRIMMABLE-BOUNDARY-START(150323986541)
            /*EventHandler<ValidationRequestedEventArgs>?*/ OnValidationRequested = null;
            //--TRIMMABLE-BOUNDARY-END(150323986541)
            
            //--TRIMMABLE-BOUNDARY-START(150323986541)
            //--TRIMMABLE-BOUNDARY-START(38654836845)
            add_OnValidationRequested(/*EventHandler<ValidationRequestedEventArgs>?*/ value)
            {
                this.OnValidationRequested = $.$$.System.Delegate.Combine(this.OnValidationRequested, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38654836845)
            
            //--TRIMMABLE-BOUNDARY-START(176093790317)
            remove_OnValidationRequested(/*EventHandler<ValidationRequestedEventArgs>?*/ value)
            {
                this.OnValidationRequested = $.$$.System.Delegate.Remove(this.OnValidationRequested, value);
            }
            //--TRIMMABLE-BOUNDARY-END(176093790317)
            
            //--TRIMMABLE-BOUNDARY-END(150323986541)
            
            //--TRIMMABLE-BOUNDARY-START(154618953837)
            /*EventHandler<ValidationStateChangedEventArgs>?*/ OnValidationStateChanged = null;
            //--TRIMMABLE-BOUNDARY-END(154618953837)
            
            //--TRIMMABLE-BOUNDARY-START(154618953837)
            //--TRIMMABLE-BOUNDARY-START(47244771437)
            add_OnValidationStateChanged(/*EventHandler<ValidationStateChangedEventArgs>?*/ value)
            {
                this.OnValidationStateChanged = $.$$.System.Delegate.Combine(this.OnValidationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(47244771437)
            
            //--TRIMMABLE-BOUNDARY-START(184683724909)
            remove_OnValidationStateChanged(/*EventHandler<ValidationStateChangedEventArgs>?*/ value)
            {
                this.OnValidationStateChanged = $.$$.System.Delegate.Remove(this.OnValidationStateChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(184683724909)
            
            //--TRIMMABLE-BOUNDARY-END(154618953837)
            
            //--TRIMMABLE-BOUNDARY-START(51539738733)
            /*FieldIdentifier */ Field(/*string*/ fieldName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539738733);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$3(this.Model, fieldName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539738733)
            
            //--TRIMMABLE-BOUNDARY-START(133144117357)
            /*object*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(133144117357)
            
            //--TRIMMABLE-BOUNDARY-START(158913921133)
            /*EditContextProperties*/ Properties = null;
            //--TRIMMABLE-BOUNDARY-END(158913921133)
            
            //--TRIMMABLE-BOUNDARY-START(197568626797)
            /*bool*/ ShouldUseFieldIdentifiers = false;
            //--TRIMMABLE-BOUNDARY-END(197568626797)
            
            //--TRIMMABLE-BOUNDARY-START(137439084653)
            /*void */ NotifyFieldChanged(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439084653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.GetOrAddFieldState(fieldIdentifier).IsModified = true;
                this.OnFieldChanged?.Invoke(this, new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs().$ctor$2(fieldIdentifier));
            }
            //--TRIMMABLE-BOUNDARY-END(137439084653)
            
            //--TRIMMABLE-BOUNDARY-START(141734051949)
            /*void */ NotifyValidationStateChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734051949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationStateChanged?.Invoke(this, $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs.Empty$1);
            }
            //--TRIMMABLE-BOUNDARY-END(141734051949)
            
            //--TRIMMABLE-BOUNDARY-START(124554182765)
            /*void */ MarkAsUnmodified$1(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554182765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let state;
                if (this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)))
                {
                    state.IsModified = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554182765)
            
            //--TRIMMABLE-BOUNDARY-START(128849150061)
            /*void */ MarkAsUnmodified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849150061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._fieldStates.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var state = $en2.Current;
                    {
                        state.Value.IsModified = false;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849150061)
            
            //--TRIMMABLE-BOUNDARY-START(103079346285)
            /*bool */ IsModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._fieldStates.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var state = $en2.Current;
                    {
                        if (state.Value.IsModified)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(103079346285)
            
            //--TRIMMABLE-BOUNDARY-START(90194444397)
            /*IEnumerable<string> */ GetValidationMessages()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = this._fieldStates.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var state = $en3.Current;
                        {
                            var $en5 = state.Value.GetValidationMessages().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var message = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield message;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(90194444397)
            
            //--TRIMMABLE-BOUNDARY-START(94489411693)
            /*IEnumerable<string> */ GetValidationMessages$1(/*FieldIdentifier*/ fieldIdentifier)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let state;
                    if (this._fieldStates.TryGetValue(fieldIdentifier, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)))
                    {
                        var $en4 = state.GetValidationMessages().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var message = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                yield message;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(94489411693)
            
            //--TRIMMABLE-BOUNDARY-START(98784378989)
            /*IEnumerable<string> */ GetValidationMessages$2(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784378989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetValidationMessages$1($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$$.System.Object, accessor));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784378989)
            
            //--TRIMMABLE-BOUNDARY-START(107374313581)
            /*bool */ IsModified$2(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374313581);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let state;
                    return this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)) ? state.IsModified : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374313581)
            
            //--TRIMMABLE-BOUNDARY-START(111669280877)
            /*bool */ IsModified$1(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669280877);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsModified$2($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$$.System.Object, accessor), ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669280877)
            
            //--TRIMMABLE-BOUNDARY-START(115964248173)
            /*bool */ IsValid$1(/*in FieldIdentifier*/ fieldIdentifier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964248173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, this.GetValidationMessages$1(fieldIdentifier.$v));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964248173)
            
            //--TRIMMABLE-BOUNDARY-START(120259215469)
            /*bool */ IsValid(/*Expression<Func<object>>*/ accessor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259215469);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsValid$1($.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create($.$$.System.Object, accessor), ));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259215469)
            
            //--TRIMMABLE-BOUNDARY-START(201863594093)
            /*bool */ Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863594093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidationRequested?.Invoke(this, $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs.Empty$1);
                return !$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, this.GetValidationMessages());
            }
            //--TRIMMABLE-BOUNDARY-END(201863594093)
            
            //--TRIMMABLE-BOUNDARY-START(81604509805)
            /*FieldState? */ GetFieldState(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let state;
                this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState));
                return state;
            }
            //--TRIMMABLE-BOUNDARY-END(81604509805)
            
            //--TRIMMABLE-BOUNDARY-START(85899477101)
            /*FieldState */ GetOrAddFieldState(/*in FieldIdentifier*/ fieldIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899477101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let state;
                if (!this._fieldStates.TryGetValue(fieldIdentifier.$v, $.$ref(() => state, ($v) => state = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState)))
                {
                    state = new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState().$ctor$1(fieldIdentifier.$v);
                    this._fieldStates.Add(fieldIdentifier.$v, state);
                }
                return state;
            }
            //--TRIMMABLE-BOUNDARY-END(85899477101)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295098477)
                this._fieldStates = new ($.$$.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295098477)
                
                this.ShouldUseFieldIdentifiers = !$.$$.System.OperatingSystem.IsBrowser();
            }
            static $h = 131181;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144117357),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129673325,
        "f": 50331649
      },
      "n": "Model",
      "d": 131181,
      "h": 133144117357,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144117357),
//--TRIMMABLE-BOUNDARY-START(158913921133),
    {
      "p": 327789,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719607917,
        "f": 50331649
      },
      "n": "Properties",
      "d": 131181,
      "h": 158913921133,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158913921133),
//--TRIMMABLE-BOUNDARY-START(197568626797),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309542509,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193273659501,
        "f": 83886081
      },
      "n": "ShouldUseFieldIdentifiers",
      "d": 131181,
      "h": 197568626797,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197568626797)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539738733),
    {
      "r": 655469,
      "p": [
        {
          "n": "fieldName",
          "p": 1310721
        }
      ],
      "n": "Field",
      "d": 131181,
      "h": 51539738733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539738733),
//--TRIMMABLE-BOUNDARY-START(137439084653),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "NotifyFieldChanged",
      "d": 131181,
      "h": 137439084653,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439084653),
//--TRIMMABLE-BOUNDARY-START(141734051949),
    {
      "r": 65537,
      "n": "NotifyValidationStateChanged",
      "d": 131181,
      "h": 141734051949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734051949),
//--TRIMMABLE-BOUNDARY-START(124554182765),
    {
      "r": 65537,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "MarkAsUnmodified",
      "o": "@$1",
      "d": 131181,
      "h": 124554182765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554182765),
//--TRIMMABLE-BOUNDARY-START(128849150061),
    {
      "r": 65537,
      "n": "MarkAsUnmodified",
      "d": 131181,
      "h": 128849150061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849150061),
//--TRIMMABLE-BOUNDARY-START(103079346285),
    {
      "r": 262145,
      "n": "IsModified",
      "d": 131181,
      "h": 103079346285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079346285),
//--TRIMMABLE-BOUNDARY-START(90194444397),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "n": "GetValidationMessages",
      "d": 131181,
      "h": 90194444397,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194444397),
//--TRIMMABLE-BOUNDARY-START(94489411693),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469
        }
      ],
      "n": "GetValidationMessages",
      "o": "@$1",
      "d": 131181,
      "h": 94489411693,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489411693),
//--TRIMMABLE-BOUNDARY-START(98784378989),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$($.$$.System.Object)).$h
        }
      ],
      "n": "GetValidationMessages",
      "o": "@$2",
      "d": 131181,
      "h": 98784378989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784378989),
//--TRIMMABLE-BOUNDARY-START(107374313581),
    {
      "r": 262145,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "IsModified",
      "o": "@$2",
      "d": 131181,
      "h": 107374313581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374313581),
//--TRIMMABLE-BOUNDARY-START(111669280877),
    {
      "r": 262145,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$($.$$.System.Object)).$h
        }
      ],
      "n": "IsModified",
      "o": "@$1",
      "d": 131181,
      "h": 111669280877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669280877),
//--TRIMMABLE-BOUNDARY-START(115964248173),
    {
      "r": 262145,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 131181,
      "h": 115964248173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964248173),
//--TRIMMABLE-BOUNDARY-START(120259215469),
    {
      "r": 262145,
      "p": [
        {
          "n": "accessor",
          "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$($.$$.System.Object)).$h
        }
      ],
      "n": "IsValid",
      "d": 131181,
      "h": 120259215469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259215469),
//--TRIMMABLE-BOUNDARY-START(201863594093),
    {
      "r": 262145,
      "n": "Validate",
      "d": 131181,
      "h": 201863594093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201863594093),
//--TRIMMABLE-BOUNDARY-START(81604509805),
    {
      "r": 721005,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "GetFieldState",
      "d": 131181,
      "h": 81604509805,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(81604509805),
//--TRIMMABLE-BOUNDARY-START(85899477101),
    {
      "r": 721005,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": "GetOrAddFieldState",
      "d": 131181,
      "h": 85899477101,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85899477101)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098477),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldState).$h,
      "n": "_fieldStates",
      "d": 131181,
      "h": 4295098477,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098477)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065773),
    {
      "p": [
        {
          "n": "model",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131181,
      "h": 8590065773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065773)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(146029019245),
    {
      "e": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs).$h
          }
        ],
        "n": "add_OnFieldChanged",
        "d": 131181,
        "h": 30064902253,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs).$h
          }
        ],
        "n": "remove_OnFieldChanged",
        "d": 131181,
        "h": 167503855725,
        "f": 285212673
      },
      "n": "OnFieldChanged",
      "d": 131181,
      "h": 146029019245,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(146029019245),
//--TRIMMABLE-BOUNDARY-START(150323986541),
    {
      "e": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs).$h
          }
        ],
        "n": "add_OnValidationRequested",
        "d": 131181,
        "h": 38654836845,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs).$h
          }
        ],
        "n": "remove_OnValidationRequested",
        "d": 131181,
        "h": 176093790317,
        "f": 285212673
      },
      "n": "OnValidationRequested",
      "d": 131181,
      "h": 150323986541,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(150323986541),
//--TRIMMABLE-BOUNDARY-START(154618953837),
    {
      "e": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h
          }
        ],
        "n": "add_OnValidationStateChanged",
        "d": 131181,
        "h": 47244771437,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h
          }
        ],
        "n": "remove_OnValidationStateChanged",
        "d": 131181,
        "h": 184683724909,
        "f": 285212673
      },
      "n": "OnValidationStateChanged",
      "d": 131181,
      "h": 154618953837,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(154618953837)
  ],
  "h": 131181
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EditContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131181)
        
        
        //--TRIMMABLE-BOUNDARY-START(196717)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions", ($self) => class EditContextDataAnnotationsExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885098605)
            static /*EditContext */ AddDataAnnotationsValidation(/*this EditContext*/ editContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.EnableDataAnnotationsValidation$1(editContext);
                return editContext;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098605)
            
            //--TRIMMABLE-BOUNDARY-START(25770000493)
            static /*IDisposable */ EnableDataAnnotationsValidation$1(/*this EditContext*/ editContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions().$ctor$1(editContext, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000493)
            
            //--TRIMMABLE-BOUNDARY-START(30064967789)
            static /*IDisposable */ EnableDataAnnotationsValidation(/*this EditContext*/ editContext, /*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                return new $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions().$ctor$1(editContext, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(30064967789)
            
            //--TRIMMABLE-BOUNDARY-START(34359935085)
            /*Action?*/ static OnClearCache = null;
            //--TRIMMABLE-BOUNDARY-END(34359935085)
            
            //--TRIMMABLE-BOUNDARY-START(34359935085)
            //--TRIMMABLE-BOUNDARY-START(8590131309)
            static add_OnClearCache(/*Action?*/ value)
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache = $.$$.System.Delegate.Combine($.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache, value);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131309)
            
            //--TRIMMABLE-BOUNDARY-START(42949869677)
            static remove_OnClearCache(/*Action?*/ value)
            {
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache = $.$$.System.Delegate.Remove($.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache, value);
            }
            //--TRIMMABLE-BOUNDARY-END(42949869677)
            
            //--TRIMMABLE-BOUNDARY-END(34359935085)
            
            //--TRIMMABLE-BOUNDARY-START(17180065901)
            static /*void */ ClearCache(/*Type[]?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache?.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065901)
            
            //--TRIMMABLE-BOUNDARY-START(262253)
            static $_DataAnnotationsEventSubscriptions;
            static get DataAnnotationsEventSubscriptions()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions;
                return $cls.$_DataAnnotationsEventSubscriptions ??= $asm.$ncls("$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions", ($self) => class DataAnnotationsEventSubscriptions extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885164141)
                    /*ConcurrentDictionary<(Type ModelType, string FieldName), PropertyInfo?>*/ static _propertyInfoCache = null;
                    //--TRIMMABLE-BOUNDARY-END(12885164141)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295229549)
                    /*EditContext*/ _editContext = null;
                    //--TRIMMABLE-BOUNDARY-END(4295229549)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131437)
                    /*IServiceProvider?*/ _serviceProvider = null;
                    //--TRIMMABLE-BOUNDARY-END(17180131437)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590196845)
                    /*ValidationMessageStore*/ _messages = null;
                    //--TRIMMABLE-BOUNDARY-END(8590196845)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098733)
                    /*ValidationOptions?*/ _validationOptions = null;
                    //--TRIMMABLE-BOUNDARY-END(21475098733)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065033325)
                    /*IValidatableInfo?*/ _validatorTypeInfo = null;
                    //--TRIMMABLE-BOUNDARY-END(30065033325)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770066029)
                    /*Dictionary<string, FieldIdentifier>*/ _validationPathToFieldIdentifierMapping = null;
                    //--TRIMMABLE-BOUNDARY-END(25770066029)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654967917)
                    $ctor$1(/*EditContext*/ editContext, /*IServiceProvider*/ serviceProvider)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38654967917);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._editContext = $.$firstOf(editContext, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("editContext") });
                            this._serviceProvider = serviceProvider;
                            this._messages = new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore().$ctor$1(this._editContext);
                            /*System.IServiceProvider*/ let __ca1__;
                            /*Microsoft.Extensions.Options.IOptions<Microsoft.Extensions.Validation.ValidationOptions>?*/ let __ca2__;
                            this._validationOptions = ((__ca1__ = this._serviceProvider) !== null ? ((__ca2__ = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$meo.Microsoft.Extensions.Options.IOptions$$($.$mev.Microsoft.Extensions.Validation.ValidationOptions), __ca1__)) !== null ? __ca2__.Microsoft$Extensions$Options$IOptions$$$Value : null) : null);
                            /*var*/ let typeInfo;
                            this._validatorTypeInfo = this._validationOptions !== null && this._validationOptions.TryGetValidatableTypeInfo($.$$.System.Object.GetType.call(this._editContext.Model), $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$mev.Microsoft.Extensions.Validation.IValidatableInfo)) ? typeInfo : null;
                            this._editContext.add_OnFieldChanged(new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs))().$ctor(this, this.OnFieldChanged));
                            this._editContext.add_OnValidationRequested(new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                            if ($.$$.System.Reflection.Metadata.MetadataUpdater.IsSupported)
                            {
                                $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache(new $.$$.System.Action().$ctor(this, this.ClearCache));
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654967917)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834837101)
                    /*void */ OnFieldChanged(/*object?*/ sender, /*FieldChangedEventArgs*/ eventArgs)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834837101);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let fieldIdentifier = eventArgs.FieldIdentifier;
                        /*var*/ let propertyInfo;
                        if ($.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions.TryGetValidatableProperty($.$ref(() => fieldIdentifier, ), $.$ref(() => propertyInfo, ($v) => propertyInfo = $v, $.$$.System.Reflection.PropertyInfo)))
                        {
                            /*var*/ let propertyValue = propertyInfo.GetValue$2(fieldIdentifier.Model);
                            /*var*/ let validationContext = (() =>
                            {
                                //new $.$sca.System.ComponentModel.DataAnnotations.ValidationContext()
                                const $t2 = $.$sca.System.ComponentModel.DataAnnotations.ValidationContext;
                                const $i2 = new $t2();
                                $i2.$ctor$3(fieldIdentifier.Model, this._serviceProvider, null);
                                $i2.MemberName = propertyInfo.Name;
                                return $i2;
                            })();
                            /*var*/ let results = new ($.$$.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult))().$ctor$1();
                            $.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidateProperty(propertyValue, validationContext, results);
                            this._messages.Clear$2($.$ref(() => fieldIdentifier, ));
                            var $en5 = $.$$.System.Runtime.InteropServices.CollectionsMarshal.AsSpan($.$sca.System.ComponentModel.DataAnnotations.ValidationResult, results).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var result = $en5.Current.$v;
                                {
                                    this._messages.Add$3($.$ref(() => fieldIdentifier, ), result.ErrorMessage);
                                }
                            }
                            this._editContext.NotifyValidationStateChanged();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834837101)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129804397)
                    /*void */ OnValidationRequested(/*object?*/ sender, /*ValidationRequestedEventArgs*/ e)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60129804397);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let validationContext = new $.$sca.System.ComponentModel.DataAnnotations.ValidationContext().$ctor$3(this._editContext.Model, this._serviceProvider, null);
                        if (!this.TryValidateTypeInfo(validationContext))
                        {
                            this.ValidateWithDefaultValidator(validationContext);
                        }
                        this._editContext.NotifyValidationStateChanged();
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129804397)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014706285)
                    /*void */ ValidateWithDefaultValidator(/*ValidationContext*/ validationContext)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014706285);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let validationResults = new ($.$$.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult))().$ctor$1();
                        $.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidateObject(this._editContext.Model, validationContext, validationResults, true);
                        this._messages.Clear();
                        var $en4 = validationResults.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var validationResult = $en4.Current;
                            {
                                if (validationResult === null)
                                {
                                    continue;
                                }
                                /*var*/ let hasMemberNames = false;
                                var $en6 = validationResult.MemberNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var memberName = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        hasMemberNames = true;
                                        this._messages.Add$3($.$ref(() => this._editContext.Field(memberName), ), validationResult.ErrorMessage);
                                    }
                                }
                                if (!hasMemberNames)
                                {
                                    this._messages.Add$3($.$ref(() => new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$3(this._editContext.Model, $.$$.System.String.Empty), ), validationResult.ErrorMessage);
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014706285)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719738989)
                    /*bool */ TryValidateTypeInfo(/*ValidationContext*/ validationContext)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719738989);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._validatorTypeInfo === null)
                        {
                            return false;
                        }
                        /*var*/ let validateContext = (() =>
                        {
                            //new $.$mev.Microsoft.Extensions.Validation.ValidateContext()
                            const $t1 = $.$mev.Microsoft.Extensions.Validation.ValidateContext;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.ValidationOptions = this._validationOptions;
                            $i1.ValidationContext = validationContext;
                            return $i1;
                        })();
                        try
                        {
                            validateContext.add_OnValidationError(new ($.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext))().$ctor(this, this.AddMapping));
                            /*var*/ let validationTask = this._validatorTypeInfo.Microsoft$Extensions$Validation$IValidatableInfo$ValidateAsync(this._editContext.Model, validateContext, $.$$.System.Threading.CancellationToken.None);
                            if (!validationTask.IsCompleted)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12("Async validation is not supported");
                            }
                            /*var*/ let validationErrors = validateContext.ValidationErrors;
                            this._messages.Clear();
                            if (!(validationErrors === null) && validationErrors.Count > 0)
                            {
                                var $en6 = validationErrors.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    let [ fieldKey, messages ] = $.$destructure($en6.Current);
                                    {
                                        /*var*/ let fieldIdentifier = this._validationPathToFieldIdentifierMapping.get_Item(fieldKey);
                                        this._messages.Add$2($.$ref(() => fieldIdentifier, ), messages);
                                    }
                                }
                            }
                        }
                        catch($e)
                        {
                            throw $e;
                        }
                        finally
                        {
                            {
                                validateContext.remove_OnValidationError(new ($.$$.System.Action$$($.$mev.Microsoft.Extensions.Validation.ValidationErrorContext))().$ctor(this, this.AddMapping));
                                this._validationPathToFieldIdentifierMapping.Clear();
                            }
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719738989)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949935213)
                    /*void */ AddMapping(/*ValidationErrorContext*/ context)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949935213);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._validationPathToFieldIdentifierMapping.set_Item(context.Path, new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$3(context.Container ?? this._editContext.Model, context.Name));
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949935213)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539869805)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51539869805);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._messages.Clear();
                        this._editContext.remove_OnFieldChanged(new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs))().$ctor(this, this.OnFieldChanged));
                        this._editContext.remove_OnValidationRequested(new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                        this._editContext.NotifyValidationStateChanged();
                        if ($.$$.System.Reflection.Metadata.MetadataUpdater.IsSupported)
                        {
                            $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.OnClearCache(new $.$$.System.Action().$ctor(this, this.ClearCache));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539869805)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424771693)
                    static /*bool */ TryGetValidatableProperty(/*in FieldIdentifier*/ fieldIdentifier, /*out PropertyInfo?*/ propertyInfo)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424771693);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let cacheKey = new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String))().$ctor$3($.$$.System.Object.GetType.call(fieldIdentifier.$v.Model), fieldIdentifier.$v.FieldName);
                        if (!$.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.TryGetValue(cacheKey.Clone(), propertyInfo))
                        {
                            propertyInfo.$v = cacheKey.Item1.GetProperty$6(cacheKey.Item2);
                            $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.set_Item(cacheKey.Clone(), propertyInfo.$v);
                        }
                        return $.$$.System.Reflection.PropertyInfo.op_Inequality$1(propertyInfo.$v, null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64424771693)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244902509)
                    /*void */ ClearCache()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47244902509);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions._propertyInfoCache.Clear();
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244902509)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25770066029)
                        this._validationPathToFieldIdentifierMapping = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(25770066029)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(34360000621)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(12885164141)
                            this._propertyInfoCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$$.System.Reflection.PropertyInfo))().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(12885164141)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360000621)
                    
                    static $h = 262253;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834837101),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "eventArgs",
          "p": 589933
        }
      ],
      "n": "OnFieldChanged",
      "d": 262253,
      "h": 55834837101,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55834837101),
//--TRIMMABLE-BOUNDARY-START(60129804397),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 983149
        }
      ],
      "n": "OnValidationRequested",
      "d": 262253,
      "h": 60129804397,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129804397),
//--TRIMMABLE-BOUNDARY-START(73014706285),
    {
      "r": 65537,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "ValidateWithDefaultValidator",
      "d": 262253,
      "h": 73014706285,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014706285),
//--TRIMMABLE-BOUNDARY-START(68719738989),
    {
      "r": 262145,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "TryValidateTypeInfo",
      "d": 262253,
      "h": 68719738989,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68719738989),
//--TRIMMABLE-BOUNDARY-START(42949935213),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 852074
        }
      ],
      "n": "AddMapping",
      "d": 262253,
      "h": 42949935213,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949935213),
//--TRIMMABLE-BOUNDARY-START(51539869805),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262253,
      "h": 51539869805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869805),
//--TRIMMABLE-BOUNDARY-START(64424771693),
    {
      "r": 262145,
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        },
        {
          "n": "propertyInfo",
          "p": 118751233,
          "f": 2
        }
      ],
      "n": "TryGetValidatableProperty",
      "d": 262253,
      "h": 64424771693,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424771693),
//--TRIMMABLE-BOUNDARY-START(47244902509),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 262253,
      "h": 47244902509,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47244902509)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885164141),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$$.System.Reflection.PropertyInfo).$h,
      "n": "_propertyInfoCache",
      "d": 262253,
      "h": 12885164141,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885164141),
//--TRIMMABLE-BOUNDARY-START(4295229549),
    {
      "t": 131181,
      "n": "_editContext",
      "d": 262253,
      "h": 4295229549,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229549),
//--TRIMMABLE-BOUNDARY-START(17180131437),
    {
      "t": 327718,
      "n": "_serviceProvider",
      "d": 262253,
      "h": 17180131437,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131437),
//--TRIMMABLE-BOUNDARY-START(8590196845),
    {
      "t": 917613,
      "n": "_messages",
      "d": 262253,
      "h": 8590196845,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196845),
//--TRIMMABLE-BOUNDARY-START(21475098733),
    {
      "t": 917610,
      "n": "_validationOptions",
      "d": 262253,
      "h": 21475098733,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475098733),
//--TRIMMABLE-BOUNDARY-START(30065033325),
    {
      "t": 131178,
      "n": "_validatorTypeInfo",
      "d": 262253,
      "h": 30065033325,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065033325),
//--TRIMMABLE-BOUNDARY-START(25770066029),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier).$h,
      "n": "_validationPathToFieldIdentifierMapping",
      "d": 262253,
      "h": 25770066029,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770066029)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38654967917),
    {
      "p": [
        {
          "n": "editContext",
          "p": 131181
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262253,
      "h": 38654967917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967917)
  ],
  "i": [90177537
  ],
  "d": 196717,
  "h": 262253
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `EditContextDataAnnotationsExtensions.DataAnnotationsEventSubscriptions`; }
                }, $cls, ($v) => $cls.$_DataAnnotationsEventSubscriptions = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262253)
            
            static $h = 196717;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885098605),
    {
      "r": 131181,
      "p": [
        {
          "n": "editContext",
          "p": 131181
        }
      ],
      "n": "AddDataAnnotationsValidation",
      "d": 196717,
      "h": 12885098605,
      "f": 16777249,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Use EnableDataAnnotationsValidation instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885098605),
//--TRIMMABLE-BOUNDARY-START(25770000493),
    {
      "r": 90177537,
      "p": [
        {
          "n": "editContext",
          "p": 131181
        }
      ],
      "n": "EnableDataAnnotationsValidation",
      "o": "@$1",
      "d": 196717,
      "h": 25770000493,
      "f": 16777249,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This API is obsolete and may be removed in future versions. Use the overload that accepts an IServiceProvider instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770000493),
//--TRIMMABLE-BOUNDARY-START(30064967789),
    {
      "r": 90177537,
      "p": [
        {
          "n": "editContext",
          "p": 131181
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "EnableDataAnnotationsValidation",
      "d": 196717,
      "h": 30064967789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064967789),
//--TRIMMABLE-BOUNDARY-START(17180065901),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "ClearCache",
      "d": 196717,
      "h": 17180065901,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180065901)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(34359935085),
    {
      "e": 42270721,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42270721
          }
        ],
        "n": "add_OnClearCache",
        "d": 196717,
        "h": 8590131309,
        "f": 150994978
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42270721
          }
        ],
        "n": "remove_OnClearCache",
        "d": 196717,
        "h": 42949869677,
        "f": 285212706
      },
      "n": "OnClearCache",
      "d": 196717,
      "h": 34359935085,
      "f": 8388642
    },
//--TRIMMABLE-BOUNDARY-END(34359935085)
  ],
  "j": [262253
  ],
  "h": 196717
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EditContextDataAnnotationsExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196717)
        
        
        //--TRIMMABLE-BOUNDARY-START(393325)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter", ($self) => class ExpressionFormatter
        {
            //--TRIMMABLE-BOUNDARY-START(4295360621)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.System.Action().$ctor($.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360621)
            
            //--TRIMMABLE-BOUNDARY-START(68719870061)
            /*int*/ static StackAllocBufferSize = 128;
            //--TRIMMABLE-BOUNDARY-END(68719870061)
            
            //--TRIMMABLE-BOUNDARY-START(458861)
            static $_CapturedValueFormatter;
            static get CapturedValueFormatter()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter;
                return $cls.$_CapturedValueFormatter ??= $asm.$ncls("$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter", ($self) => class CapturedValueFormatter extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/*$.$$.System.Object*/ closure, /**/ builder)
                    {
                        return this.$nativeFunction.call(this.$target, closure, builder);
                    }
                    static $h = 458861;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98828289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180328045),
    {
      "r": 65537,
      "p": [
        {
          "n": "closure",
          "p": 131073
        },
        {
          "n": "builder",
          "p": 786541,
          "f": 4
        }
      ],
      "n": "Invoke",
      "d": 458861,
      "h": 17180328045,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180328045),
//--TRIMMABLE-BOUNDARY-START(8590393453),
    {
      "r": 89653249,
      "p": [
        {
          "n": "closure",
          "p": 131073
        },
        {
          "n": "builder",
          "p": 786541,
          "f": 4
        },
        {
          "n": "callback",
          "p": 45154305
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 458861,
      "h": 8590393453,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590393453),
//--TRIMMABLE-BOUNDARY-START(12885360749),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 786541,
          "f": 4
        },
        {
          "n": "result",
          "p": 89653249
        }
      ],
      "n": "EndInvoke",
      "d": 458861,
      "h": 12885360749,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885360749)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426157),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458861,
      "h": 4295426157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426157)
  ],
  "i": [89849857,157351937
  ],
  "d": 393325,
  "h": 458861
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `ExpressionFormatter.CapturedValueFormatter`; }
                }, $cls, ($v) => $cls.$_CapturedValueFormatter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458861)
            
            //--TRIMMABLE-BOUNDARY-START(60129935469)
            /*ConcurrentDictionary<MemberInfo, CapturedValueFormatter>*/ static s_capturedValueFormatterCache = null;
            //--TRIMMABLE-BOUNDARY-END(60129935469)
            
            //--TRIMMABLE-BOUNDARY-START(64424902765)
            /*ConcurrentDictionary<MethodInfo, MethodInfoData>*/ static s_methodInfoDataCache = null;
            //--TRIMMABLE-BOUNDARY-END(64424902765)
            
            //--TRIMMABLE-BOUNDARY-START(12885295213)
            static /*void */ ClearCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.Clear();
                $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(12885295213)
            
            //--TRIMMABLE-BOUNDARY-START(38655098989)
            static /*string */ FormatLambda$1(/*LambdaExpression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatLambda(expression, null);
            }
            //--TRIMMABLE-BOUNDARY-END(38655098989)
            
            //--TRIMMABLE-BOUNDARY-START(42950066285)
            static /*string */ FormatLambda(/*LambdaExpression*/ expression, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 128/*StackAllocBufferSize*/, null));
                /*var*/ let node = expression.Body;
                /*var*/ let wasLastExpressionMemberAccess = false;
                /*var*/ let wasLastExpressionIndexer = false;
                while(!(node === null))
                {
                    let $switch1 = node.NodeType;
                    switch($switch1)
                    {
                        case 9/*ExpressionType.Constant*/:
                        /*var*/ let constantExpression = $.$cast(node, $.$sle.System.Linq.Expressions.ConstantExpression);
                        node = null;
                        break;
                        case 6/*ExpressionType.Call*/:
                        /*var*/ let methodCallExpression = $.$cast(node, $.$sle.System.Linq.Expressions.MethodCallExpression);
                        if (!$.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.IsSingleArgumentIndexer(methodCallExpression))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("Method calls cannot be formatted.");
                        }
                        node = methodCallExpression.Object;
                        if ($.$$.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                        }
                        wasLastExpressionIndexer = true;
                        builder.InsertFront$1($.$$.System.String.op_Implicit("]"));
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(methodCallExpression.Arguments.get_Item(0), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                        builder.InsertFront$1($.$$.System.String.op_Implicit("["));
                        break;
                        case 5/*ExpressionType.ArrayIndex*/:
                        /*var*/ let binaryExpression = $.$cast(node, $.$sle.System.Linq.Expressions.BinaryExpression);
                        node = binaryExpression.Left;
                        if ($.$$.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                        }
                        builder.InsertFront$1($.$$.System.String.op_Implicit("]"));
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(binaryExpression.Right, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                        builder.InsertFront$1($.$$.System.String.op_Implicit("["));
                        wasLastExpressionIndexer = true;
                        break;
                        case 23/*ExpressionType.MemberAccess*/:
                        /*var*/ let memberExpression = $.$cast(node, $.$sle.System.Linq.Expressions.MemberExpression);
                        node = memberExpression.Expression;
                        if ($.$$.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                        }
                        wasLastExpressionMemberAccess = true;
                        wasLastExpressionIndexer = false;
                        /*var*/ let name = ($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$8($.$srsp.System.Runtime.Serialization.DataMemberAttribute, memberExpression.Member)?.Name ?? null) ?? memberExpression.Member.Name;
                        builder.InsertFront$1($.$$.System.String.op_Implicit(name));
                        break;
                        default:
                        node = null;
                        break;
                    }
                }
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    if (!builder.Empty && !wasLastExpressionIndexer)
                    {
                        builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                    }
                    builder.InsertFront$1($.$$.System.String.op_Implicit(prefix));
                }
                /*var*/ let result = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.call(builder);
                builder.Dispose();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(42950066285)
            
            //--TRIMMABLE-BOUNDARY-START(51540000877)
            static /*bool */ IsSingleArgumentIndexer(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540000877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let methodExpression;
                if (!$.$is(expression, $.$sle.System.Linq.Expressions.MethodCallExpression, { set $v(v){ methodExpression = v; } }) || methodExpression.Arguments.Count !== 1)
                {
                    return false;
                }
                /*var*/ let methodInfoData = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.GetOrCreateMethodInfoData(methodExpression.Method);
                return methodInfoData.IsSingleArgumentIndexer;
            }
            //--TRIMMABLE-BOUNDARY-END(51540000877)
            
            //--TRIMMABLE-BOUNDARY-START(47245033581)
            static /*MethodInfoData */ GetOrCreateMethodInfoData(/*MethodInfo*/ methodInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let methodInfoData;
                if (!$.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.TryGetValue(methodInfo, $.$ref(() => methodInfoData, ($v) => methodInfoData = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData)))
                {
                    methodInfoData = GetMethodInfoData(methodInfo);
                    $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.set_Item(methodInfo, methodInfoData);
                }
                return methodInfoData;
                /*static MethodInfoData*/  function GetMethodInfoData(/*MethodInfo*/ methodInfo)
                {
                    /*var*/ let declaringType = methodInfo.DeclaringType;
                    if (declaringType === null)
                    {
                        return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    /*var*/ let defaultMember = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$7($.$$.System.Reflection.DefaultMemberAttribute, declaringType, true);
                    if (defaultMember === null)
                    {
                        return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    /*var*/ let runtimeProperties = $.$$.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperties(declaringType);
                    if (runtimeProperties === null)
                    {
                        return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    var $en3 = runtimeProperties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var property = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.Equals$2(defaultMember.MemberName, property.Name, 4/*StringComparison.Ordinal*/) && $.$$.System.Reflection.MethodInfo.op_Equality$2(property.GetMethod, methodInfo))
                            {
                                return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(true);
                            }
                        }
                    }
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245033581)
            
            //--TRIMMABLE-BOUNDARY-START(30065164397)
            static /*void */ FormatIndexArgument(/*Expression*/ indexExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //switch (indexExpression)
                {
                    let memberExpression;
                    let constantExpression;
                    $switchJumpStart1: 
                    //case MemberExpression memberExpression when memberExpression.Expression is ConstantExpression constantExpression:
                    if ($.$is(indexExpression, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ memberExpression = v; } }) && $.$is(memberExpression.Expression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constantExpression = v; } }))
                    {
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatCapturedValue(memberExpression, constantExpression, builder);
                    }
                    //case ConstantExpression constantExpression:
                    else if ($.$is(indexExpression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constantExpression = v; } }))
                    {
                        $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatConstantValue(constantExpression, builder);
                    }
                    //default
                    else
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Unable to evaluate index expressions of type '${$.$$.System.Object.GetType.call(indexExpression).Name}'.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164397)
            
            //--TRIMMABLE-BOUNDARY-START(34360131693)
            static /*string */ FormatIndexArgument$1(/*Expression*/ indexExpression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 128/*StackAllocBufferSize*/, null));
                try
                {
                    $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(indexExpression, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                    /*var*/ let result = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.call(builder);
                    return result;
                }
                finally
                {
                    {
                        builder.Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360131693)
            
            //--TRIMMABLE-BOUNDARY-START(21475229805)
            static /*void */ FormatCapturedValue(/*MemberExpression*/ memberExpression, /*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let member = memberExpression.Member;
                /*var*/ let format;
                if (!$.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.TryGetValue(member, $.$ref(() => format, ($v) => format = $v, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter)))
                {
                    format = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CreateCapturedValueFormatter(memberExpression);
                    $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.set_Item(member, format);
                }
                format.Invoke(constantExpression.Value, builder);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229805)
            
            //--TRIMMABLE-BOUNDARY-START(17180262509)
            static /*CapturedValueFormatter */ CreateCapturedValueFormatter(/*MemberExpression*/ memberExpression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let memberType = memberExpression.Type;
                if ($.$$.System.Type.op_Equality$1(memberType, $.$$.System.Int32.$type))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.Int32, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$2($.$$.System.Int32, func.Invoke(closure));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "closure",
      "p": 131073
    },
    {
      "n": "builder",
      "p": 786541,
      "f": 4
    }
  ],
  "n": "",
  "d": 393325,
  "h": 0,
  "f": 17825794
});
                }
                else if ($.$$.System.Type.op_Equality$1(memberType, $.$$.System.String.$type))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.String, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$1($.$$.System.String.op_Implicit(func.Invoke(closure)));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "closure",
      "p": 131073
    },
    {
      "n": "builder",
      "p": 786541,
      "f": 4
    }
  ],
  "n": "",
  "d": 393325,
  "h": 0,
  "f": 17825794
});
                }
                else if ($.$$.System.ISpanFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.ISpanFormattable, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$2($.$$.System.ISpanFormattable, func.Invoke(closure));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "closure",
      "p": 131073
    },
    {
      "n": "builder",
      "p": 786541,
      "f": 4
    }
  ],
  "n": "",
  "d": 393325,
  "h": 0,
  "f": 17825794
});
                }
                else if ($.$$.System.IFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.IFormattable, memberExpression);
                    return new $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront(func.Invoke(closure));
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "closure",
      "p": 131073
    },
    {
      "n": "builder",
      "p": 786541,
      "f": 4
    }
  ],
  "n": "",
  "d": 393325,
  "h": 0,
  "f": 17825794
});
                }
                else 
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Cannot format an index argument of type '${$.$$.System.Type.ToString.call(memberType)}'.`);
                }
                /*static Func<object, TResult>*/  function CompileMemberEvaluator(TResult, /*MemberExpression*/ memberExpression)
                {
                    /*var*/ let parameterExpression = $.$sle.System.Linq.Expressions.Expression.Parameter$1($.$$.System.Object.$type);
                    /*var*/ let convertExpression = $.$sle.System.Linq.Expressions.Expression.Convert$1(parameterExpression, memberExpression.Member.DeclaringType);
                    /*var*/ let replacedMemberExpression = memberExpression.Update(convertExpression);
                    /*var*/ let replacedExpression = $.$sle.System.Linq.Expressions.Expression.Lambda$17($.$$.System.Func$$$($.$$.System.Object, TResult), replacedMemberExpression, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ parameterExpression ], null, null));
                    return replacedExpression.Compile$3();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262509)
            
            //--TRIMMABLE-BOUNDARY-START(25770197101)
            static /*void */ FormatConstantValue(/*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //switch (constantExpression.Value)
                let $switch1 = constantExpression.Value;
                {
                    let s;
                    let spanFormattable;
                    let formattable;
                    let x;
                    $switchJumpStart1: 
                    //case string s:
                    if ($.$is($switch1, $.$$.System.String, { set $v(v){ s = v; } }))
                    {
                        builder.$v.InsertFront$1($.$$.System.String.op_Implicit(s));
                    }
                    //case ISpanFormattable spanFormattable:
                    else if ($.$is($switch1, $.$$.System.ISpanFormattable, { set $v(v){ spanFormattable = v; } }))
                    {
                        builder.$v.InsertFront$2($.$$.System.ISpanFormattable, spanFormattable);
                    }
                    //case IFormattable formattable:
                    else if ($.$is($switch1, $.$$.System.IFormattable, { set $v(v){ formattable = v; } }))
                    {
                        builder.$v.InsertFront(formattable);
                    }
                    //case null:
                    else if ($switch1 == null)
                    {
                        builder.$v.InsertFront$1($.$$.System.String.op_Implicit("null"));
                    }
                    //case var x:
                    else if ($switch1 != null && (x = $switch1))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Unable to format constant values of type '${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(x))}'.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770197101)
            
            //--TRIMMABLE-BOUNDARY-START(524397)
            static $_MethodInfoData;
            static get MethodInfoData()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter;
                return $cls.$_MethodInfoData ??= $asm.$nstr("$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData", ($self) => class MethodInfoData extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328173)
                    /*bool*/ IsSingleArgumentIndexer = false;
                    //--TRIMMABLE-BOUNDARY-END(25770328173)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295491693)
                    $ctor$3(/*bool*/ isSingleArgumentIndexer)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295491693);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.IsSingleArgumentIndexer = isSingleArgumentIndexer;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295491693)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsSingleArgumentIndexer = this.IsSingleArgumentIndexer;
                        return copy;
                    }
                    static $h = 524397;
                    static $z = 1;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770328173),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360877,
        "f": 50331649
      },
      "n": "IsSingleArgumentIndexer",
      "d": 524397,
      "h": 25770328173,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770328173)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491693),
    {
      "p": [
        {
          "n": "isSingleArgumentIndexer",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524397,
      "h": 4295491693,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491693),
//--TRIMMABLE-BOUNDARY-START(8590458989),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524397,
      "h": 8590458989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458989)
  ],
  "d": 393325,
  "h": 524397
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `ExpressionFormatter.MethodInfoData`; }
                }, $cls, ($v) => $cls.$_MethodInfoData = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524397)
            
            //--TRIMMABLE-BOUNDARY-START(4295360621)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60129935469)
                    this.s_capturedValueFormatterCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MemberInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(60129935469)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424902765)
                    this.s_methodInfoDataCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MethodInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(64424902765)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360621)
            
            static $h = 393325;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295213),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 393325,
      "h": 12885295213,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885295213),
//--TRIMMABLE-BOUNDARY-START(38655098989),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 38797349
        }
      ],
      "n": "FormatLambda",
      "o": "@$1",
      "d": 393325,
      "h": 38655098989,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655098989),
//--TRIMMABLE-BOUNDARY-START(42950066285),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 38797349
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "FormatLambda",
      "d": 393325,
      "h": 42950066285,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950066285),
//--TRIMMABLE-BOUNDARY-START(51540000877),
    {
      "r": 262145,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "IsSingleArgumentIndexer",
      "d": 393325,
      "h": 51540000877,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540000877),
//--TRIMMABLE-BOUNDARY-START(47245033581),
    {
      "r": 524397,
      "p": [
        {
          "n": "methodInfo",
          "p": 116719617
        }
      ],
      "n": "GetOrCreateMethodInfoData",
      "d": 393325,
      "h": 47245033581,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245033581),
//--TRIMMABLE-BOUNDARY-START(30065164397),
    {
      "r": 65537,
      "p": [
        {
          "n": "indexExpression",
          "p": 8781861
        },
        {
          "n": "builder",
          "p": 786541,
          "f": 4
        }
      ],
      "n": "FormatIndexArgument",
      "d": 393325,
      "h": 30065164397,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065164397),
//--TRIMMABLE-BOUNDARY-START(34360131693),
    {
      "r": 1310721,
      "p": [
        {
          "n": "indexExpression",
          "p": 8781861
        }
      ],
      "n": "FormatIndexArgument",
      "o": "@$1",
      "d": 393325,
      "h": 34360131693,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360131693),
//--TRIMMABLE-BOUNDARY-START(21475229805),
    {
      "r": 65537,
      "p": [
        {
          "n": "memberExpression",
          "p": 39321637
        },
        {
          "n": "constantExpression",
          "p": 7864357
        },
        {
          "n": "builder",
          "p": 786541,
          "f": 4
        }
      ],
      "n": "FormatCapturedValue",
      "d": 393325,
      "h": 21475229805,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475229805),
//--TRIMMABLE-BOUNDARY-START(17180262509),
    {
      "r": 458861,
      "p": [
        {
          "n": "memberExpression",
          "p": 39321637
        }
      ],
      "n": "CreateCapturedValueFormatter",
      "d": 393325,
      "h": 17180262509,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180262509),
//--TRIMMABLE-BOUNDARY-START(25770197101),
    {
      "r": 65537,
      "p": [
        {
          "n": "constantExpression",
          "p": 7864357
        },
        {
          "n": "builder",
          "p": 786541,
          "f": 4
        }
      ],
      "n": "FormatConstantValue",
      "d": 393325,
      "h": 25770197101,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770197101)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719870061),
    {
      "t": 655361,
      "n": "StackAllocBufferSize",
      "d": 393325,
      "h": 68719870061,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719870061),
//--TRIMMABLE-BOUNDARY-START(60129935469),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MemberInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter).$h,
      "n": "s_capturedValueFormatterCache",
      "d": 393325,
      "h": 60129935469,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129935469),
//--TRIMMABLE-BOUNDARY-START(64424902765),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MethodInfo, $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData).$h,
      "n": "s_methodInfoDataCache",
      "d": 393325,
      "h": 64424902765,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64424902765)
  ],
  "j": [458861,524397
  ],
  "h": 393325
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ExpressionFormatter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393325)
        
        
        //--TRIMMABLE-BOUNDARY-START(786541)
        $asm.$str("$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder", ($self) => class ReverseStringBuilder extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(73015230573)
            /*int*/ static MinimumRentedArraySize = 1024;
            //--TRIMMABLE-BOUNDARY-END(73015230573)
            
            //--TRIMMABLE-BOUNDARY-START(77310197869)
            /*ArrayPool<char>*/ static s_arrayPool = null;
            //--TRIMMABLE-BOUNDARY-END(77310197869)
            
            //--TRIMMABLE-BOUNDARY-START(12885688429)
            /*int*/  get _nextEndIndex() { return this.$getField(0, 4); }
            /*int*/  set _nextEndIndex(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885688429)
            
            //--TRIMMABLE-BOUNDARY-START(4295753837)
            /*Span<char>*/  get _currentBuffer() { return this.$getField(4, 6); }
            /*Span<char>*/  set _currentBuffer(value) { this.$setField(4, 6, value); }
            //--TRIMMABLE-BOUNDARY-END(4295753837)
            
            //--TRIMMABLE-BOUNDARY-START(8590721133)
            /*SequenceSegment?*/  get _fallbackSequenceSegment() { return this.$getField(10, 4); }
            /*SequenceSegment?*/  set _fallbackSequenceSegment(value) { this.$setField(10, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590721133)
            
            //--TRIMMABLE-BOUNDARY-START(85900132461)
            /*int */ get SequenceSegmentCount()
            {
                return (this._fallbackSequenceSegment?.Count() ?? null) ?? 0;
            }
            //--TRIMMABLE-BOUNDARY-END(85900132461)
            
            //--TRIMMABLE-BOUNDARY-START(21475623021)
            $ctor$3(/*int*/ conservativeEstimatedStringLength)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475623021);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let array = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(conservativeEstimatedStringLength);
                    this._fallbackSequenceSegment = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(array, null);
                    this._currentBuffer = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(array);
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623021)
            
            //--TRIMMABLE-BOUNDARY-START(25770590317)
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590317);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._currentBuffer = initialBuffer;
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590317)
            
            //--TRIMMABLE-BOUNDARY-START(38655492205)
            /*bool */ get Empty()
            {
                return this._nextEndIndex === this._currentBuffer.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492205)
            
            //--TRIMMABLE-BOUNDARY-START(60130328685)
            /*void */ InsertFront$1(/*scoped ReadOnlySpan<char>*/ span)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130328685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let startIndex = ((this._nextEndIndex - span.Length) | 0);
                if (startIndex >= 0)
                {
                    let $t1 = this._currentBuffer;
                    span.CopyTo($t1.Slice(startIndex, $t1.Length - startIndex));
                    this._nextEndIndex = startIndex;
                    return;
                }
                if (this._fallbackSequenceSegment === null)
                {
                    /*var*/ let remainingLength = -startIndex;
                    /*var*/ let sizeToRent = ((this._currentBuffer.Length + $.$$.System.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0))) | 0);
                    /*var*/ let newBuffer = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, null);
                    /*var*/ let newEndIndex = ((((newBuffer.length - this._currentBuffer.Length) | 0) + this._nextEndIndex) | 0);
                    let $t1 = this._currentBuffer;
                    $t1.Slice(this._nextEndIndex, $t1.Length - this._nextEndIndex).CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, newBuffer, newEndIndex));
                    newEndIndex -= span.Length;
                    span.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, newBuffer, newEndIndex));
                    this._currentBuffer = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(newBuffer);
                    this._nextEndIndex = newEndIndex;
                }
                else 
                {
                    /*var*/ let remainingLength = -startIndex;
                    let $t1 = span;
                    $t1.Slice(remainingLength, $t1.Length - remainingLength).CopyTo(this._currentBuffer);
                    let $t2 = span;
                    span = $t2.Slice(0, remainingLength);
                    /*var*/ let sizeToRent = $.$$.System.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0));
                    /*var*/ let newBuffer = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, this._fallbackSequenceSegment);
                    this._currentBuffer = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(newBuffer);
                    startIndex = ((this._currentBuffer.Length - remainingLength) | 0);
                    let $t3 = this._currentBuffer;
                    span.CopyTo($t3.Slice(startIndex, $t3.Length - startIndex));
                    this._nextEndIndex = startIndex;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130328685)
            
            //--TRIMMABLE-BOUNDARY-START(64425295981)
            /*void */ InsertFront$2(T, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<char>*/ let result = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 11, null);
                /*var*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, result, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), $.$$.System.Globalization.CultureInfo.InvariantCulture))
                {
                    let $t2 = result;
                    this.InsertFront$1($.$$.System.Span$$($.$$.System.Char).op_Implicit($t2.Slice(0, charsWritten)));
                }
                else 
                {
                    this.InsertFront($.$box(value, T));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425295981)
            
            //--TRIMMABLE-BOUNDARY-START(68720263277)
            /*void */ InsertFront(/*IFormattable*/ formattable)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720263277);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InsertFront$1($.$$.System.String.op_Implicit(formattable.System$IFormattable$ToString(null, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720263277)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 90195099757, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195099757);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $t1 = this._currentBuffer;
                    return this._fallbackSequenceSegment === null ? $.$$.System.String.Create$2($.$$.System.Span$$($.$$.System.Char).op_Implicit($t1.Slice(this._nextEndIndex, $t1.Length - this._nextEndIndex))) : this._fallbackSequenceSegment.ToString$1(this._nextEndIndex);
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 90195099757, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(34360524909)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._fallbackSequenceSegment?.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(34360524909)
            
            //--TRIMMABLE-BOUNDARY-START(852077)
            static $_SequenceSegment;
            static get SequenceSegment()
            {
                let $cls = $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder;
                return $cls.$_SequenceSegment ??= $asm.$ncls("$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment", ($self) => class SequenceSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$$.System.Char)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295819373)
                    /*char[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4295819373)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786669)
                    $ctor$2(/*char[]*/ array, /*SequenceSegment?*/ next)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590786669);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._array = array;
                            this.Memory = $.$$.System.ReadOnlyMemory$$($.$$.System.Char).op_Implicit$1(array);
                            this.Next = next;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590786669)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885753965)
                    /*int */ Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885753965);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let count = 0;
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment))
                        {
                            count++;
                        }
                        return count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885753965)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475688557)
                    /*string */ ToString$1(/*int*/ startIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475688557);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.RunningIndex = 0n;
                        /*var*/ let tail = this;
                        let next;
                        while($.$is(tail.Next, $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment, { set $v(v){ next = v; } }))
                        {
                            next.RunningIndex = tail.RunningIndex + BigInt(tail.Memory.Length);
                            tail = next;
                        }
                        /*var*/ let sequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char))().$ctor$7(this, startIndex, tail, tail.Memory.Length);
                        return $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).ToString.call(sequence);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475688557)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721261)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180721261);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment))
                        {
                            $.$macf.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Return(current._array, false);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180721261)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    static $h = 852077;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753965),
    {
      "r": 655361,
      "n": "Count",
      "d": 852077,
      "h": 12885753965,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885753965),
//--TRIMMABLE-BOUNDARY-START(21475688557),
    {
      "r": 1310721,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 852077,
      "h": 21475688557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688557),
//--TRIMMABLE-BOUNDARY-START(17180721261),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 852077,
      "h": 17180721261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721261)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819373),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_array",
      "d": 852077,
      "h": 4295819373,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819373)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786669),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "next",
          "p": 852077,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852077,
      "h": 8590786669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786669)
  ],
  "i": [90177537
  ],
  "d": 786541,
  "h": 852077
}; }
                    static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$$.System.Char); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `ReverseStringBuilder.SequenceSegment`; }
                }, $cls, ($v) => $cls.$_SequenceSegment = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(852077)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._nextEndIndex = this._nextEndIndex;
                copy._currentBuffer = this._currentBuffer.Clone();
                copy._fallbackSequenceSegment = this._fallbackSequenceSegment;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885688429)
                this._nextEndIndex = 0;
                //--TRIMMABLE-BOUNDARY-END(12885688429)
                
                //--TRIMMABLE-BOUNDARY-START(4295753837)
                this._currentBuffer = $.$default($.$$.System.Span$$($.$$.System.Char));
                //--TRIMMABLE-BOUNDARY-END(4295753837)
                
                //--TRIMMABLE-BOUNDARY-START(8590721133)
                this._fallbackSequenceSegment = null;
                //--TRIMMABLE-BOUNDARY-END(8590721133)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17180655725)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77310197869)
                    this.s_arrayPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared;
                    //--TRIMMABLE-BOUNDARY-END(77310197869)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180655725)
            
            static $h = 786541;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900132461),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361389,
        "f": 50331656
      },
      "n": "SequenceSegmentCount",
      "d": 786541,
      "h": 85900132461,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(85900132461),
//--TRIMMABLE-BOUNDARY-START(38655492205),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426797,
        "f": 50331649
      },
      "n": "Empty",
      "d": 786541,
      "h": 38655492205,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655492205)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130328685),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "InsertFront",
      "o": "@$1",
      "d": 786541,
      "h": 60130328685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130328685),
//--TRIMMABLE-BOUNDARY-START(64425295981),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "InsertFront",
      "o": "@$2",
      "d": 786541,
      "h": 64425295981,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(64425295981),
//--TRIMMABLE-BOUNDARY-START(68720263277),
    {
      "r": 65537,
      "p": [
        {
          "n": "formattable",
          "p": 90374145
        }
      ],
      "n": "InsertFront",
      "d": 786541,
      "h": 68720263277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720263277),
//--TRIMMABLE-BOUNDARY-START(ALL, 90195099757, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 786541,
      "h": 90195099757,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 90195099757, 330712612865),
//--TRIMMABLE-BOUNDARY-START(34360524909),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 786541,
      "h": 34360524909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524909)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015230573),
    {
      "t": 655361,
      "n": "MinimumRentedArraySize",
      "d": 786541,
      "h": 73015230573,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015230573),
//--TRIMMABLE-BOUNDARY-START(77310197869),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,
      "n": "s_arrayPool",
      "d": 786541,
      "h": 77310197869,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310197869),
//--TRIMMABLE-BOUNDARY-START(12885688429),
    {
      "t": 655361,
      "n": "_nextEndIndex",
      "d": 786541,
      "h": 12885688429,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688429),
//--TRIMMABLE-BOUNDARY-START(4295753837),
    {
      "t": $.$$.System.Span$$($.$$.System.Char).$h,
      "n": "_currentBuffer",
      "d": 786541,
      "h": 4295753837,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753837),
//--TRIMMABLE-BOUNDARY-START(8590721133),
    {
      "t": 852077,
      "n": "_fallbackSequenceSegment",
      "d": 786541,
      "h": 8590721133,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721133)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475623021),
    {
      "p": [
        {
          "n": "conservativeEstimatedStringLength",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786541,
      "h": 21475623021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623021),
//--TRIMMABLE-BOUNDARY-START(25770590317),
    {
      "p": [
        {
          "n": "initialBuffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786541,
      "h": 25770590317,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590317),
//--TRIMMABLE-BOUNDARY-START(30065557613),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786541,
      "h": 30065557613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557613)
  ],
  "j": [852077
  ],
  "h": 786541
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ReverseStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786541)
        
        
        //--TRIMMABLE-BOUNDARY-START(655469)
        $asm.$str("$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier", ($self) => class FieldIdentifier extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295622765)
            /*ConcurrentDictionary<(Type ModelType, MemberInfo Member), Func<object, object>>*/ static _fieldAccessors = null;
            //--TRIMMABLE-BOUNDARY-END(4295622765)
            
            //--TRIMMABLE-BOUNDARY-START(8590590061)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590590061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macf.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.System.Action().$ctor($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590590061)
            
            //--TRIMMABLE-BOUNDARY-START(34360393837)
            static /*FieldIdentifier */ Create(TField, /*Expression<Func<TField>>*/ accessor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(accessor, "accessor");
                /*var*/ let model;
                /*var*/ let fieldName;
                $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.ParseAccessor(TField, accessor, $.$ref(() => model, ($v) => model = $v, $.$$.System.Object), $.$ref(() => fieldName, ($v) => fieldName = $v, $.$$.System.String));
                return new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$3(model, fieldName);
            }
            //--TRIMMABLE-BOUNDARY-END(34360393837)
            
            //--TRIMMABLE-BOUNDARY-START(12885557357)
            $ctor$3(/*object*/ model, /*string*/ fieldName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557357);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(model, "model");
                    if ($.$$.System.Object.GetType.call(model).IsValueType)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("The model must be a reference-typed object.", "model");
                    }
                    this.Model = model;
                    this.FieldName = $.$firstOf(fieldName, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("fieldName") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557357)
            
            //--TRIMMABLE-BOUNDARY-START(81605034093)
            /*object*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(81605034093)
            
            //--TRIMMABLE-BOUNDARY-START(47245295725)
            /*string*/ FieldName = null;
            //--TRIMMABLE-BOUNDARY-END(47245295725)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68720132205, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720132205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let modelHash = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode$1(this.Model);
                /*var*/ let fieldHash = $.$$.System.StringComparer.Ordinal.GetHashCode$2(this.FieldName);
                return $.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).GetHashCode.call(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(modelHash, fieldHash));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68720132205, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655361133, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655361133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let otherIdentifier;
                    return $.$is(obj, $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, { set $v(v){ otherIdentifier = v; } }) && this.Equals$2(otherIdentifier);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655361133, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(42950328429)
            /*bool */ Equals$2(/*FieldIdentifier*/ otherIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950328429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Object.ReferenceEquals(otherIdentifier.Model, this.Model) && $.$$.System.String.Equals$2(otherIdentifier.FieldName, this.FieldName, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(42950328429)
            
            //--TRIMMABLE-BOUNDARY-START(85900001389)
            static /*void */ ParseAccessor(T, /*Expression<Func<T>>*/ accessor, /*out object*/ model, /*out string*/ fieldName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900001389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let accessorBody = accessor.Body;
                let unaryExpression;
                if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.UnaryExpression, { set $v(v){ unaryExpression = v; } }) && unaryExpression.NodeType === 10/*ExpressionType.Convert*/ && $.$$.System.Type.op_Equality$1(unaryExpression.Type, $.$$.System.Object.$type))
                {
                    accessorBody = unaryExpression.Operand;
                }
                //switch (accessorBody)
                {
                    let memberExpression;
                    let methodCallExpression;
                    let binaryExpression;
                    $switchJumpStart1: 
                    //case MemberExpression memberExpression:
                    if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ memberExpression = v; } }))
                    {
                        fieldName.$v = memberExpression.Member.Name;
                        //switch (memberExpression.Expression)
                        let $switch2 = memberExpression.Expression;
                        {
                            let constant;
                            let member;
                            $switchJumpStart2: 
                            //case ConstantExpression constant when constant.Value == null:
                            if ($.$is($switch2, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constant = v; } }) && constant.Value === null)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.");
                            }
                            //case ConstantExpression constant when constant.Value != null:
                            else if ($.$is($switch2, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constant = v; } }) && constant.Value !== null)
                            {
                                model.$v = constant.Value;
                            }
                            //case MemberExpression member when member.Expression is ConstantExpression:
                            else if ($.$is($switch2, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ member = v; } }) && $.$is(member.Expression, $.$sle.System.Linq.Expressions.ConstantExpression))
                            {
                                model.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetModelFromMemberAccess(member, null);
                            }
                            //case not null:
                            else if ($switch2 != null && $switch2 === null)
                            {
                                /*var*/ let modelLambda = $.$sle.System.Linq.Expressions.Expression.Lambda$5($.$$.System.Func$$($.$$.System.Object).$type, memberExpression.Expression, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [  ], null, null));
                                /*var*/ let modelLambdaCompiled = $.$cast(modelLambda.Compile(), $.$$.System.Func$$($.$$.System.Object));
                                /*var*/ let result = $.$firstOf(modelLambdaCompiled.Invoke(), () => { throw new $.$$.System.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.") });
                                model.$v = result;
                            }
                            //default
                            else
                            {
                                throw new $.$$.System.ArgumentException().$ctor$14(`The provided expression contains a ${$.$$.System.Object.GetType.call(accessorBody).Name} which is not supported. ${"FieldIdentifier"} only supports simple member accessors (fields, properties) of an object.`);
                            }
                        }
                    }
                    //case MethodCallExpression methodCallExpression when ExpressionFormatter.IsSingleArgumentIndexer(accessorBody):
                    else if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.MethodCallExpression, { set $v(v){ methodCallExpression = v; } }) && $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.IsSingleArgumentIndexer(accessorBody))
                    {
                        fieldName.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument$1(methodCallExpression.Arguments.get_Item(0));
                        model.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetModelFromIndexer(methodCallExpression.Object);
                    }
                    //case BinaryExpression binaryExpression when binaryExpression.NodeType == ExpressionType.ArrayIndex:
                    else if ($.$is(accessorBody, $.$sle.System.Linq.Expressions.BinaryExpression, { set $v(v){ binaryExpression = v; } }) && binaryExpression.NodeType === 5/*ExpressionType.ArrayIndex*/)
                    {
                        fieldName.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument$1(binaryExpression.Right);
                        model.$v = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.GetModelFromIndexer(binaryExpression.Left);
                    }
                    //default
                    else
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14(`The provided expression contains a ${$.$$.System.Object.GetType.call(accessorBody).Name} which is not supported. ${"FieldIdentifier"} only supports simple member accessors (fields, properties) of an object.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900001389)
            
            //--TRIMMABLE-BOUNDARY-START(77310066797)
            static /*object */ GetModelFromMemberAccess(/*MemberExpression*/ member, /*ConcurrentDictionary<(Type ModelType, MemberInfo Member), Func<object, object>>?*/ cache)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310066797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cache ??= $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier._fieldAccessors;
                /*Func<object, object>?*/ let accessor = null;
                /*object?*/ let value = null;
                //switch (member.Expression)
                let $switch1 = member.Expression;
                {
                    let model;
                    $switchJumpStart1: 
                    //case ConstantExpression model:
                    if ($.$is($switch1, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ model = v; } }))
                    {
                        value = $.$firstOf(model.Value, () => { throw new $.$$.System.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.") });
                        accessor = cache.GetOrAdd(new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Reflection.MemberInfo))().$ctor$3($.$$.System.Object.GetType.call(value), member.Member), new ($.$$.System.Func$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Reflection.MemberInfo), $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object)))().$ctor($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier, CreateAccessor));
                    }
                    //default
                    else
                    {
                    }
                }
                if (accessor === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Unable to compile expression: ${$.$sle.System.Linq.Expressions.Expression.ToString.call(member)}`);
                }
                if (value === null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.");
                }
                /*var*/ let result = accessor.Invoke(value);
                return result;
                /*static Func<object, object>*/  function CreateAccessor(/*(Type model, MemberInfo member)*/ arg)
                {
                    /*var*/ let parameter = $.$sle.System.Linq.Expressions.Expression.Parameter($.$$.System.Object.$type, "value");
                    /*Expression*/ let expression = $.$sle.System.Linq.Expressions.Expression.Convert$1(parameter, arg.Item1);
                    expression = $.$sle.System.Linq.Expressions.Expression.MakeMemberAccess(expression, arg.Item2);
                    expression = $.$sle.System.Linq.Expressions.Expression.Convert$1(expression, $.$$.System.Object.$type);
                    /*var*/ let lambda = $.$sle.System.Linq.Expressions.Expression.Lambda$17($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object), expression, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ parameter ], null, null));
                    /*var*/ let func = lambda.Compile$3();
                    return func;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310066797)
            
            //--TRIMMABLE-BOUNDARY-START(73015099501)
            static /*object */ GetModelFromIndexer(/*Expression*/ methodCallExpression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015099501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let model;
                /*var*/ let methodCallObjectLambda = $.$sle.System.Linq.Expressions.Expression.Lambda$5($.$$.System.Func$$($.$$.System.Object).$type, methodCallExpression, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [  ], null, null));
                /*var*/ let methodCallObjectLambdaCompiled = $.$cast(methodCallObjectLambda.Compile(), $.$$.System.Func$$($.$$.System.Object));
                /*var*/ let result = methodCallObjectLambdaCompiled.Invoke();
                if (result === null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14("The provided expression must evaluate to a non-null value.");
                }
                model = result;
                return model;
            }
            //--TRIMMABLE-BOUNDARY-END(73015099501)
            
            //--TRIMMABLE-BOUNDARY-START(30065426541)
            static /*void */ ClearCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier._fieldAccessors.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(30065426541)
            
            //--TRIMMABLE-BOUNDARY-START(4385210369)
            //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.Forms.FieldIdentifier>.Equals(Microsoft.AspNetCore.Components.Forms.FieldIdentifier)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385210369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385210369)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Model = this.Model;
                copy.FieldName = this.FieldName;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(8590590061)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622765)
                    this._fieldAccessors = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Reflection.MemberInfo), $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4295622765)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590590061)
            
            static $h = 655469;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605034093),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425164909,
        "f": 50331649
      },
      "n": "Model",
      "d": 655469,
      "h": 81605034093,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605034093),
//--TRIMMABLE-BOUNDARY-START(47245295725),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835230317,
        "f": 50331649
      },
      "n": "FieldName",
      "d": 655469,
      "h": 47245295725,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245295725)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360393837),
    {
      "r": 655469,
      "p": [
        {
          "n": "accessor",
          "p": (TField) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$(TField)).$h
        }
      ],
      "g": [
        "TField"
      ],
      "n": "Create",
      "d": 655469,
      "h": 34360393837,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34360393837),
//--TRIMMABLE-BOUNDARY-START(ALL, 68720132205, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 655469,
      "h": 68720132205,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68720132205, 184683724801),
//--TRIMMABLE-BOUNDARY-START(ALL, 38655361133, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 655469,
      "h": 38655361133,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655361133, 34359869441),
//--TRIMMABLE-BOUNDARY-START(42950328429),
    {
      "r": 262145,
      "p": [
        {
          "n": "otherIdentifier",
          "p": 655469
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 655469,
      "h": 42950328429,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950328429),
//--TRIMMABLE-BOUNDARY-START(85900001389),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessor",
          "p": (T) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$(T)).$h
        },
        {
          "n": "model",
          "p": 131073,
          "f": 2
        },
        {
          "n": "fieldName",
          "p": 1310721,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "ParseAccessor",
      "d": 655469,
      "h": 85900001389,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(85900001389),
//--TRIMMABLE-BOUNDARY-START(77310066797),
    {
      "r": 131073,
      "p": [
        {
          "n": "member",
          "p": 39321637
        },
        {
          "n": "cache",
          "p": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Reflection.MemberInfo), $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object)).$h,
          "f": 65
        }
      ],
      "n": "GetModelFromMemberAccess",
      "d": 655469,
      "h": 77310066797,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77310066797),
//--TRIMMABLE-BOUNDARY-START(73015099501),
    {
      "r": 131073,
      "p": [
        {
          "n": "methodCallExpression",
          "p": 8781861
        }
      ],
      "n": "GetModelFromIndexer",
      "d": 655469,
      "h": 73015099501,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73015099501),
//--TRIMMABLE-BOUNDARY-START(30065426541),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 655469,
      "h": 30065426541,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065426541)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622765),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Reflection.MemberInfo), $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object)).$h,
      "n": "_fieldAccessors",
      "d": 655469,
      "h": 4295622765,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295622765)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557357),
    {
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "fieldName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655469,
      "h": 12885557357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557357),
//--TRIMMABLE-BOUNDARY-START(17180524653),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655469,
      "h": 17180524653,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524653)
  ],
  "i": [$.$$.System.IEquatable$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier).$h
  ],
  "h": 655469
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier) ]; }
            static get $fullName() { return `FieldIdentifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655469)
        
        
        //--TRIMMABLE-BOUNDARY-START(65645)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.DataAnnotationsValidator", ($self) => class DataAnnotationsValidator extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8590000237)
            /*IDisposable?*/ _subscriptions = null;
            //--TRIMMABLE-BOUNDARY-END(8590000237)
            
            //--TRIMMABLE-BOUNDARY-START(4295032941)
            /*EditContext?*/ _originalEditContext = null;
            //--TRIMMABLE-BOUNDARY-END(4295032941)
            
            //--TRIMMABLE-BOUNDARY-START(25769869421)
            /*EditContext?*/ CurrentEditContext = null;
            //--TRIMMABLE-BOUNDARY-END(25769869421)
            
            //--TRIMMABLE-BOUNDARY-START(60129607789)
            /*IServiceProvider*/ ServiceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(60129607789)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51539673197, 120260329580)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentEditContext === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"DataAnnotationsValidator"} requires a cascading ` + `parameter of type ${"EditContext"}. For example, you can use ${"DataAnnotationsValidator"} ` + `inside an EditForm.`);
                }
                this._subscriptions = $.$macf.Microsoft.AspNetCore.Components.Forms.EditContextDataAnnotationsExtensions.EnableDataAnnotationsValidation(this.CurrentEditContext, this.ServiceProvider);
                this._originalEditContext = this.CurrentEditContext;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51539673197, 120260329580)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55834640493, 128850264172)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentEditContext !== this._originalEditContext)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} does not support changing the ` + `${"EditContext"} dynamically.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55834640493, 128850264172)
            
            //--TRIMMABLE-BOUNDARY-START(30064836717)
            /*void */ Dispose(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30064836717)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81604444269, 4385144833)
            /*void */ System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._subscriptions?.System$IDisposable$Dispose();
                this._subscriptions = null;
                this.Dispose(true);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 81604444269, 4385144833)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ServiceProvider = null;
            }
            static $h = 65645;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25769869421),
    {
      "p": 131181,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654771309,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719542381,
        "f": 83886082
      },
      "n": "CurrentEditContext",
      "d": 65645,
      "h": 25769869421,
      "f": 2097154,
      "a": [
        {
          "t": 524396,
          "c": 4295491692
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25769869421),
//--TRIMMABLE-BOUNDARY-START(60129607789),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244705901,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309476973,
        "f": 83886082
      },
      "n": "ServiceProvider",
      "d": 65645,
      "h": 60129607789,
      "f": 2097154,
      "a": [
        {
          "t": 4259948,
          "c": 4299227244
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129607789)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 51539673197, 120260329580),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 65645,
      "h": 51539673197,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51539673197, 120260329580),
//--TRIMMABLE-BOUNDARY-START(ALL, 55834640493, 128850264172),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 65645,
      "h": 55834640493,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55834640493, 128850264172),
//--TRIMMABLE-BOUNDARY-START(30064836717),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "d": 65645,
      "h": 30064836717,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30064836717)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590000237),
    {
      "t": 90177537,
      "n": "_subscriptions",
      "d": 65645,
      "h": 8590000237,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000237),
//--TRIMMABLE-BOUNDARY-START(4295032941),
    {
      "t": 131181,
      "n": "_originalEditContext",
      "d": 65645,
      "h": 4295032941,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032941)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967533),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65645,
      "h": 12884967533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967533)
  ],
  "i": [2752620,3145836,3080300,90177537
  ],
  "h": 65645
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `DataAnnotationsValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65645)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048685)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs", ($self) => class ValidationStateChangedEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(12885950573)
            /*ValidationStateChangedEventArgs*/ static Empty$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885950573)
            
            //--TRIMMABLE-BOUNDARY-START(8590983277)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590983277);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983277)
            
            //--TRIMMABLE-BOUNDARY-START(4296015981)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885950573)
                    this.Empty$1 = new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(12885950573)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296015981)
            
            static $h = 1048685;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79626241,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885950573),
    {
      "t": 1048685,
      "n": "Empty",
      "o": "@$1",
      "d": 1048685,
      "h": 12885950573,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950573)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590983277),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048685,
      "h": 8590983277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590983277)
  ],
  "h": 1048685
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `ValidationStateChangedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048685)
        
        
        //--TRIMMABLE-BOUNDARY-START(589933)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.FieldChangedEventArgs", ($self) => class FieldChangedEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295557229)
            $ctor$2(/*in FieldIdentifier*/ fieldIdentifier)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557229);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FieldIdentifier = fieldIdentifier.$v;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557229)
            
            //--TRIMMABLE-BOUNDARY-START(12885491821)
            /*FieldIdentifier*/ FieldIdentifier;
            //--TRIMMABLE-BOUNDARY-END(12885491821)
            
            //default member initializer
            constructor()
            {
                super();
                this.FieldIdentifier = $.$default($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier);
            }
            static $h = 589933;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79626241,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885491821),
    {
      "p": 655469,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475426413,
        "f": 50331649
      },
      "n": "FieldIdentifier",
      "d": 589933,
      "h": 12885491821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885491821)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557229),
    {
      "p": [
        {
          "n": "fieldIdentifier",
          "p": 655469,
          "f": 8
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589933,
      "h": 4295557229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557229)
  ],
  "h": 589933
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `FieldChangedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589933)
        
        
        //--TRIMMABLE-BOUNDARY-START(983149)
        $asm.$cls("$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs", ($self) => class ValidationRequestedEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(12885885037)
            /*ValidationRequestedEventArgs*/ static Empty$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885885037)
            
            //--TRIMMABLE-BOUNDARY-START(8590917741)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917741);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917741)
            
            //--TRIMMABLE-BOUNDARY-START(4295950445)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885885037)
                    this.Empty$1 = new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(12885885037)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295950445)
            
            static $h = 983149;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79626241,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885885037),
    {
      "t": 983149,
      "n": "Empty",
      "o": "@$1",
      "d": 983149,
      "h": 12885885037,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885885037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917741),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983149,
      "h": 8590917741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917741)
  ],
  "h": 983149
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `ValidationRequestedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983149)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives"))
//--TRIMMABLE-BOUNDARY-END(109)
