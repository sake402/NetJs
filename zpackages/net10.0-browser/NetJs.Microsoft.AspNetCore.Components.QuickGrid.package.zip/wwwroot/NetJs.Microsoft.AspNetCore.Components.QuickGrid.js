
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $slq) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.QuickGrid", 
    {"h":11,"f":"Microsoft.AspNetCore.Components.QuickGrid","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Provides a simple and convenient data grid component for common grid rendering scenarios and serves as a reference architecture and performance baseline for building data grid components.\n      If you\u0027re using Entity Framework Core for your grid IQueryables, consider using the \u003Ca href=\u0022https://www.nuget.org/packages/Microsoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter\u0022\u003EMicrosoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter\u003C/a\u003E package.\n    ","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.QuickGrid","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.QuickGrid","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.AspNetCore.Components.QuickGrid.Tests","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.IAsyncQueryExecutor", ($self) => class IAsyncQueryExecutor
        {
            static $h = 589835;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"queryable","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"IsSupported","o":"Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$IsSupported","d":589835,"h":4295557131,"f":16908545},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"queryable","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"CountAsync","o":"Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$CountAsync","d":589835,"h":8590524427,"f":16908545},{"r":(T) => $.$$.System.Threading.Tasks.Task$$($.$typeArray(T)).$h,"p":[{"n":"queryable","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"ToArrayAsync","o":"Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$ToArrayAsync","d":589835,"h":12885491723,"f":16908545}],"h":589835}; }
            static get $fullName() { return `IAsyncQueryExecutor`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<>", [TGridItem], ($self) => class ColumnBase$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*InternalGridContext<TGridItem>*/ InternalGridContext = null;
            /*string?*/ Title = null;
            /*string?*/ Class = null;
            /*Align*/ Align = 0;
            /*RenderFragment<ColumnBase<TGridItem>>?*/ HeaderTemplate = null;
            /*RenderFragment?*/ ColumnOptions = null;
            /*bool?*/ Sortable = null;
            /*SortDirection*/ InitialSortDirection = 0;
            /*bool*/ IsDefaultSortColumn = false;
            /*RenderFragment<PlaceholderContext>?*/ PlaceholderTemplate = null;
            /*QuickGrid<TGridItem> */ get Grid()
            {
                return this.InternalGridContext.Grid;
            }
            /*RenderFragment*/ HeaderContent = null;
            /*bool */ IsSortableByDefault()
            {
                return false;
            }
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this.HeaderContent = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderDefaultHeaderContent);
                }
                return this;
            }
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                this.InternalGridContext.Grid.AddColumn(this, this.InitialSortDirection, this.IsDefaultSortColumn);
            }
            /*void */ RenderDefaultHeaderContent(/*RenderTreeBuilder*/ __builder)
            {
                if (!(this.HeaderTemplate === null))
                {
                    __builder.AddContent$4(0, this.HeaderTemplate.Invoke(this));
                }
                else 
                {
                    if (!(this.ColumnOptions === null) && (this.Align !== 4/*Align.Right*/ && this.Align !== 2/*Align.End*/))
                    {
                        __builder.OpenElement(1, "button");
                        __builder.AddAttribute$3(2, "class", "col-options-button");
                        __builder.AddAttribute$3(3, "type", "button");
                        __builder.AddAttribute$3(4, "title", "Column options");
                        __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 5, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.ShowColumnOptionsAsync(this);
                        }, {"r":133169153,"n":"","d":this.$h,"h":0,"f":17825794})));
                        __builder.CloseElement();
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(this.Sortable) ? $.$$.System.Nullable$$($.$$.System.Boolean).Value$get.call(this.Sortable) : this.IsSortableByDefault())
                    {
                        __builder.OpenElement(6, "button");
                        __builder.AddAttribute$3(7, "class", "col-title");
                        __builder.AddAttribute$3(8, "type", "button");
                        __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 9, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.SortByColumnAsync(this, 0);
                        }, {"r":133169153,"n":"","d":this.$h,"h":0,"f":17825794})));
                        __builder.OpenElement(10, "div");
                        __builder.AddAttribute$3(11, "class", "col-title-text");
                        __builder.AddContent$2(12, this.Title);
                        __builder.CloseElement();
                        __builder.AddMarkupContent(13, "\r\n                    <div class=\"sort-indicator\" aria-hidden=\"true\"></div>");
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.OpenElement(14, "div");
                        __builder.AddAttribute$3(15, "class", "col-title");
                        __builder.OpenElement(16, "div");
                        __builder.AddAttribute$3(17, "class", "col-title-text");
                        __builder.AddContent$2(18, this.Title);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    if (!(this.ColumnOptions === null) && (this.Align === 4/*Align.Right*/ || this.Align === 2/*Align.End*/))
                    {
                        __builder.OpenElement(19, "button");
                        __builder.AddAttribute$3(20, "class", "col-options-button");
                        __builder.AddAttribute$3(21, "type", "button");
                        __builder.AddAttribute$3(22, "title", "Column options");
                        __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 23, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.ShowColumnOptionsAsync(this);
                        }, {"r":133169153,"n":"","d":this.$h,"h":0,"f":17825794})));
                        __builder.CloseElement();
                    }
                }
            }
            /*void */ RenderPlaceholderContent(/*RenderTreeBuilder*/ __builder, /*PlaceholderContext*/ placeholderContext)
            {
                if (!(this.PlaceholderTemplate === null))
                {
                    __builder.AddContent$4(24, this.PlaceholderTemplate.Invoke(placeholderContext));
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.InternalGridContext = null;
                this.Align = 0;
                this.Sortable = null;
                this.InitialSortDirection = 0;
                this.IsDefaultSortColumn = false;
            }
            static $h = 196619;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331656},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":83886088},"n":"InternalGridContext","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097160,"a":[{"t":524296,"c":21475360776}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":83886081},"n":"Title","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":83886081},"n":"Class","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":131083,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":83886081},"n":"Align","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":83886081},"n":"HeaderTemplate","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":6881288,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1800000000n),"f":83886081},"n":"ColumnOptions","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$typeNullable($.$$.System.Boolean).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":83886081},"n":"Sortable","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":50331905},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":83886337},"n":"SortBy","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":2097409},{"p":1376267,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2200000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2300000000n),"f":83886081},"n":"InitialSortDirection","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2600000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2700000000n),"f":83886081},"n":"IsDefaultSortColumn","d":this.$h,"h":Number(BigInt(this.$h)|0x2500000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2A00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":83886081},"n":"PlaceholderTemplate","d":this.$h,"h":Number(BigInt(this.$h)|0x2900000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":50331649},"n":"Grid","d":this.$h,"h":Number(BigInt(this.$h)|0x2C00000000n),"f":2097153},{"p":6881288,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3100000000n),"f":50331664},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3200000000n),"f":83886084},"n":"HeaderContent","d":this.$h,"h":Number(BigInt(this.$h)|0x3000000000n),"f":2097168}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"item","p":TGridItem?.$h??1507328}],"n":"CellContent","d":this.$h,"h":Number(BigInt(this.$h)|0x2E00000000n),"f":16777488},{"r":262145,"n":"IsSortableByDefault","d":this.$h,"h":Number(BigInt(this.$h)|0x3300000000n),"f":16777348},{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0x3500000000n),"f":16809988},{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"RenderDefaultHeaderContent","d":this.$h,"h":Number(BigInt(this.$h)|0x3600000000n),"f":16777218},{"r":65537,"p":[{"n":"__builder","p":7536648},{"n":"placeholderContext","p":7733257}],"n":"RenderPlaceholderContent","d":this.$h,"h":Number(BigInt(this.$h)|0x3700000000n),"f":16777224}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x3400000000n),"f":16777217}],"i":[2752520,3145736,3080200],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `ColumnBase<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext<>", [TGridItem], ($self) => class InternalGridContext$$ extends $.$$.System.Object
        {
            /*QuickGrid<TGridItem>*/ Grid = null;
            /*EventCallbackSubscribable<object?>*/ ColumnsFirstCollected = null;
            $ctor$1(/*QuickGrid<TGridItem>*/ grid)
            {
                super.$ctor();
                {
                    this.Grid = grid;
                }
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ColumnsFirstCollected = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$$.System.Object))().$ctor$1();
            }
            static $h = 1048587;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"n":"Grid","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$$.System.Object).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"ColumnsFirstCollected","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153}],"c":[{"p":[{"n":"grid","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InternalGridContext<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable<>", (T) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable<>", [T], ($self) => class EventCallbackSubscribable$$ extends $.$$.System.Object
        {
            /*Dictionary<EventCallbackSubscriber<T>, EventCallback<T>>*/ _callbacks = null;
            /*Task *//*async*/  InvokeCallbacksAsync(/*T*/ eventArg)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    var $en3 = this._callbacks.Values.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var callback = $en3.Current;
                        {
                            await callback.InvokeAsync$1(eventArg);
                        }
                    }
                });
            }
            /*void */ Subscribe(/*EventCallbackSubscriber<T>*/ owner, /*EventCallback<T>*/ callback)
            {
                return this._callbacks.Add(owner, callback);
            }
            /*void */ Unsubscribe(/*EventCallbackSubscriber<T>*/ owner)
            {
                return this._callbacks.Remove$1(owner);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._callbacks = new ($.$$.System.Collections.Generic.Dictionary$$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T), $.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T)))().$ctor$1();
            }
            static $h = 851979;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"eventArg","p":T?.$h??1507328}],"n":"InvokeCallbacksAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16781313},{"r":65537,"p":[{"n":"owner","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T).$h},{"n":"callback","p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T).$h}],"n":"Subscribe","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217},{"r":65537,"p":[{"n":"owner","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T).$h}],"n":"Unsubscribe","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T), $.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T)).$h,"n":"_callbacks","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EventCallbackSubscribable<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventHandlers", ($self) => class EventHandlers
        {
            static $h = 983051;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":983051,"a":[{"t":2490376,"c":8592424968,"a":[{"v":"onclosecolumnoptions","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EventHandlers`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.Forms.AttributeUtilities", ($self) => class AttributeUtilities
        {
            static /*string? */ CombineClassNames(/*IReadOnlyDictionary<string, object>?*/ additionalAttributes, /*string?*/ classNames)
            {
                /*var*/ let $class;
                if (additionalAttributes === null || !additionalAttributes.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue("class", $.$ref(() => $class, ($v) => $class = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    return classNames;
                }
                /*var*/ let classAttributeValue = $.$$.System.Convert.ToString$23($class, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                if ($.$$.System.String.IsNullOrEmpty(classAttributeValue))
                {
                    return classNames;
                }
                if ($.$$.System.String.IsNullOrEmpty(classNames))
                {
                    return classAttributeValue;
                }
                return `${classAttributeValue} ${classNames}`;
            }
            static $h = 65547;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"additionalAttributes","p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"classNames","p":1310721}],"n":"CombineClassNames","d":65547,"h":4295032843,"f":16777249}],"h":65547}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AttributeUtilities`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult", ($self) => class GridItemsProviderResult
        {
            static /*GridItemsProviderResult<TGridItem> */ From(TGridItem, /*ICollection<TGridItem>*/ items, /*int*/ totalItemCount)
            {
                return (() =>
                {
                    //new $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)()
                    const $t1 = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem);
                    const $i1 = new $t1();
                    $i1.Items = items;
                    $i1.TotalItemCount = totalItemCount;
                    return $i1;
                })();
            }
            static $h = 393227;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TGridItem) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem).$h,"p":[{"n":"items","p":(TGridItem) => $.$$.System.Collections.Generic.ICollection$$(TGridItem).$h},{"n":"totalItemCount","p":655361}],"g":["TGridItem"],"n":"From","d":393227,"h":4295360523,"f":16908321}],"h":393227}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `GridItemsProviderResult`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState", ($self) => class PaginationState extends $.$$.System.Object
        {
            /*int*/ ItemsPerPage = 0;
            /*int*/ CurrentPageIndex = 0;
            /*int?*/ TotalItemCount = null;
            /*int? */ get LastPageIndex()
            {
                return $.trunc(($.$$.System.Int32.op_Subtraction$1(this.TotalItemCount, 1)) / this.ItemsPerPage);
            }
            /*EventHandler<int?>?*/ TotalItemCountChanged = null;
            add_TotalItemCountChanged(/*EventHandler<int?>?*/ value)
            {
                this.TotalItemCountChanged = $.$$.System.Delegate.Combine(this.TotalItemCountChanged, value);
            }
            remove_TotalItemCountChanged(/*EventHandler<int?>?*/ value)
            {
                this.TotalItemCountChanged = $.$$.System.Delegate.Remove(this.TotalItemCountChanged, value);
            }
            /*EventCallbackSubscribable<PaginationState>*/ CurrentPageItemsChanged = null;
            /*EventCallbackSubscribable<PaginationState>*/ TotalItemCountChangedSubscribable = null;
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$5($.$$.System.Int32, $.$$.System.Int32, $.$typeNullable($.$$.System.Int32), this.ItemsPerPage, this.CurrentPageIndex, this.TotalItemCount);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.apply(this, arguments); }
            /*Task */ SetCurrentPageIndexAsync(/*int*/ pageIndex)
            {
                this.CurrentPageIndex = pageIndex;
                return this.CurrentPageItemsChanged.InvokeCallbacksAsync(this);
            }
            /*Task */ SetTotalItemCountAsync(/*int*/ totalItemCount)
            {
                if (totalItemCount === this.TotalItemCount)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                this.TotalItemCount = totalItemCount;
                if (this.CurrentPageIndex > 0 && $.$$.System.Int32.op_GreaterThan(this.CurrentPageIndex, this.LastPageIndex))
                {
                    return this.SetCurrentPageIndexAsync($.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(this.LastPageIndex));
                }
                else 
                {
                    this.TotalItemCountChanged?.Invoke(this, this.TotalItemCount);
                    return this.TotalItemCountChangedSubscribable.InvokeCallbacksAsync(this);
                }
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ItemsPerPage = 10;
                this.TotalItemCount = null;
                this.CurrentPageItemsChanged = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1();
                this.TotalItemCountChangedSubscribable = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1();
            }
            static $h = 1114123;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886016011,"f":50331649},"s":{"r":0,"d":0,"h":17180983307,"f":83886081},"n":"ItemsPerPage","d":1114123,"h":8591048715,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30065885195,"f":50331649},"s":{"r":0,"d":0,"h":34360852491,"f":83886082},"n":"CurrentPageIndex","d":1114123,"h":25770917899,"f":2097153},{"p":$.$typeNullable($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":47245754379,"f":50331649},"s":{"r":0,"d":0,"h":51540721675,"f":83886082},"n":"TotalItemCount","d":1114123,"h":42950787083,"f":2097153},{"p":$.$typeNullable($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":60130656267,"f":50331649},"n":"LastPageIndex","d":1114123,"h":55835688971,"f":2097153},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,"g":{"r":0,"d":0,"h":85900460043,"f":50331656},"n":"CurrentPageItemsChanged","d":1114123,"h":81605492747,"f":2097160},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,"g":{"r":0,"d":0,"h":98785361931,"f":50331656},"n":"TotalItemCountChangedSubscribable","d":1114123,"h":94490394635,"f":2097160}],"m":[{"r":655361,"n":"GetHashCode","d":1114123,"h":103080329227,"f":16809985},{"r":133169153,"p":[{"n":"pageIndex","p":655361}],"n":"SetCurrentPageIndexAsync","d":1114123,"h":107375296523,"f":16777217},{"r":133169153,"p":[{"n":"totalItemCount","p":655361}],"n":"SetTotalItemCountAsync","d":1114123,"h":111670263819,"f":16777224}],"c":[{"n":".ctor","o":"$ctor$1","d":1114123,"h":115965231115,"f":16777217}],"e":[{"e":$.$$.System.EventHandler$$($.$$.System.Nullable$$($.$$.System.Int32)).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$$.System.Nullable$$($.$$.System.Int32)).$h}],"n":"add_TotalItemCountChanged","d":1114123,"h":64425623563,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$$.System.Nullable$$($.$$.System.Int32)).$h}],"n":"remove_TotalItemCountChanged","d":1114123,"h":68720590859,"f":285212673},"n":"TotalItemCountChanged","d":1114123,"h":73015558155,"f":8388609}],"h":1114123}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `PaginationState`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier", ($self) => class AsyncQueryExecutorSupplier
        {
            /*ConcurrentDictionary<Type, bool>*/ static IsEntityFrameworkProviderTypeCache = null;
            static /*IAsyncQueryExecutor? */ GetAsyncQueryExecutor(T, /*IServiceProvider*/ services, /*IQueryable<T>?*/ queryable)
            {
                if (!(queryable === null))
                {
                    /*var*/ let executor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$macq.Microsoft.AspNetCore.Components.QuickGrid.IAsyncQueryExecutor, services);
                    if (executor === null)
                    {
                        const $t1 = () => queryable.System$Linq$IQueryable$Provider;
                        /*var*/ let providerType = $.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t));
                        if (!(providerType === null) && $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier.IsEntityFrameworkProviderTypeCache.GetOrAdd(providerType, new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier, $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier.IsEntityFrameworkProviderType)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`The supplied ${"IQueryable"} is provided by Entity Framework. To query it efficiently, you must reference the package Microsoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter and call AddQuickGridEntityFrameworkAdapter on your service collection.`);
                        }
                    }
                    else if (executor.Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$IsSupported(T, queryable))
                    {
                        return executor;
                    }
                }
                return null;
            }
            static /*bool */ IsEntityFrameworkProviderType(/*Type*/ queryableProviderType)
            {
                return $.$sl.System.Linq.Enumerable.Any($.$$.System.Type, queryableProviderType.GetInterfaces(), new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.System.String.Equals$2(x.FullName, "Microsoft.EntityFrameworkCore.Query.IAsyncQueryProvider", 4/*StringComparison.Ordinal*/);
                }, {"r":262145,"p":[{"n":"x","p":142475265}],"n":"","d":655371,"h":0,"f":17825794})) === true;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.IsEntityFrameworkProviderTypeCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor$1();
                }
            }
            static $h = 655371;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":589835,"p":[{"n":"services","p":327717},{"n":"queryable","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"GetAsyncQueryExecutor","d":655371,"h":8590589963,"f":16908321},{"r":262145,"p":[{"n":"queryableProviderType","p":142475265}],"n":"IsEntityFrameworkProviderType","d":655371,"h":12885557259,"f":16777250}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Boolean).$h,"n":"IsEntityFrameworkProviderTypeCache","d":655371,"h":4295622667,"f":4194338}],"h":655371}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AsyncQueryExecutorSupplier`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort<>", [TGridItem], ($self) => class GridSort$$ extends $.$$.System.Object
        {
            /*string*/ static ExpressionNotRepresentableMessage = null;
            /*Func<IQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>*/ _first = null;
            /*List<Func<IOrderedQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>>?*/ _then = null;
            /*(LambdaExpression, bool)*/ _firstExpression;
            /*List<(LambdaExpression, bool)>?*/ _thenExpressions = null;
            /*IReadOnlyCollection<SortedProperty>?*/ _cachedPropertyListAscending = null;
            /*IReadOnlyCollection<SortedProperty>?*/ _cachedPropertyListDescending = null;
            $ctor$1(/*Func<IQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>*/ first, /*(LambdaExpression, bool)*/ firstExpression)
            {
                super.$ctor();
                {
                    this._first = first;
                    this._firstExpression = firstExpression.Clone();
                    this._then = null;
                    this._thenExpressions = null;
                }
                return this;
            }
            static /*GridSort<TGridItem> */ ByAscending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                return new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem))().$ctor$1(new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/**/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.System.Linq.Queryable.OrderBy$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.OrderByDescending$1(TGridItem, U, queryable, expression);
                }, {"r":$.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.System.Linq.IQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"h":0,"f":17825794}), new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, true));
            }
            static /*GridSort<TGridItem> */ ByDescending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                return new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem))().$ctor$1(new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.System.Linq.Queryable.OrderByDescending$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.OrderBy$1(TGridItem, U, queryable, expression);
                }, {"r":$.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.System.Linq.IQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"h":0,"f":17825794}), new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, false));
            }
            /*GridSort<TGridItem> */ ThenAscending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                this._then ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem))))().$ctor$1();
                this._thenExpressions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean)))().$ctor$1();
                this._then.Add(new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.System.Linq.Queryable.ThenBy$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.ThenByDescending$1(TGridItem, U, queryable, expression);
                }, {"r":$.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"h":0,"f":17825794}));
                this._thenExpressions.Add(new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, true));
                this._cachedPropertyListAscending = null;
                this._cachedPropertyListDescending = null;
                return this;
            }
            /*GridSort<TGridItem> */ ThenDescending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                this._then ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem))))().$ctor$1();
                this._thenExpressions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean)))().$ctor$1();
                this._then.Add(new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.System.Linq.Queryable.ThenByDescending$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.ThenBy$1(TGridItem, U, queryable, expression);
                }, {"r":$.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"h":0,"f":17825794}));
                this._thenExpressions.Add(new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, false));
                this._cachedPropertyListAscending = null;
                this._cachedPropertyListDescending = null;
                return this;
            }
            /*IOrderedQueryable<TGridItem> */ Apply(/*IQueryable<TGridItem>*/ queryable, /*bool*/ ascending)
            {
                /*var*/ let orderedQueryable = this._first.Invoke(queryable, ascending);
                if (!(this._then === null))
                {
                    var $en3 = this._then.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var clause = $en3.Current;
                        {
                            orderedQueryable = clause.Invoke(orderedQueryable, ascending);
                        }
                    }
                }
                return orderedQueryable;
            }
            /*IReadOnlyCollection<SortedProperty> */ ToPropertyList(/*bool*/ ascending)
            {
                if (ascending)
                {
                    this._cachedPropertyListAscending ??= this.BuildPropertyList(true);
                    return this._cachedPropertyListAscending;
                }
                else 
                {
                    this._cachedPropertyListDescending ??= this.BuildPropertyList(false);
                    return this._cachedPropertyListDescending;
                }
            }
            /*List<SortedProperty> */ BuildPropertyList(/*bool*/ ascending)
            {
                /*var*/ let result = (() =>
                {
                    //new $.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty)()
                    const $t1 = $.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add((() =>
                    {
                        //new $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty()
                        const $t2 = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty;
                        const $i2 = new $t2();
                        $i2.PropertyName = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).ToPropertyName(this._firstExpression.Item1);
                        $i2.Direction = ($.$$.System.Boolean.op_ExclusiveOr(this._firstExpression.Item2, ascending)) ? 2/*SortDirection.Descending*/ : 1/*SortDirection.Ascending*/;
                        return $i2;
                    })());
                    return $i1;
                })();
                if (!(this._thenExpressions === null))
                {
                    var $en3 = this._thenExpressions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        let [ thenLambda, thenAscending ] = $.$destructure($en3.Current);
                        {
                            result.Add((() =>
                            {
                                //new $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty()
                                const $t2 = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty;
                                const $i2 = new $t2();
                                $i2.PropertyName = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).ToPropertyName(thenLambda);
                                $i2.Direction = ($.$$.System.Boolean.op_ExclusiveOr(thenAscending, ascending)) ? 2/*SortDirection.Descending*/ : 1/*SortDirection.Ascending*/;
                                return $i2;
                            })());
                        }
                    }
                }
                return result;
            }
            static /*string */ ToPropertyName(/*LambdaExpression*/ expression)
            {
                /*var*/ let expressionBody = expression.Body;
                if (expressionBody.NodeType === 10/*ExpressionType.Convert*/ || expressionBody.NodeType === 11/*ExpressionType.ConvertChecked*/)
                {
                    expressionBody = ($.$cast(expressionBody, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                }
                let body;
                if (!$.$is(expressionBody, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ body = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14("The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names."/*ExpressionNotRepresentableMessage*/);
                }
                if ($.$is(body.Expression, $.$sle.System.Linq.Expressions.ParameterExpression))
                {
                    return body.Member.Name;
                }
                /*var*/ let length = body.Member.Name.length;
                /*var*/ let node = body;
                while(!(node.Expression === null))
                {
                    let parentMember;
                    if ($.$is(node.Expression, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ parentMember = v; } }))
                    {
                        length += ((parentMember.Member.Name.length + 1) | 0);
                        node = parentMember;
                    }
                    else if ($.$is(node.Expression, $.$sle.System.Linq.Expressions.ParameterExpression))
                    {
                        break;
                    }
                    else 
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14("The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names."/*ExpressionNotRepresentableMessage*/);
                    }
                }
                return $.$$.System.String.Create$10($.$sle.System.Linq.Expressions.MemberExpression, length, body, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$sle.System.Linq.Expressions.MemberExpression))().$ctor(this,  (/*chars*/ chars, /*body*/ body) =>
                {
                    /*var*/ let nextPos = chars.Length;
                    while(!(body === null))
                    {
                        nextPos -= body.Member.Name.length;
                        let $t1 = chars;
                        $.$$.System.String.CopyTo$1.call(body.Member.Name, $t1.Slice(nextPos, $t1.Length - nextPos));
                        if (nextPos > 0)
                        {
                            chars.get_Item(--nextPos).$v = /*.*/ 46;
                        }
                        body = ($.$as(body.Expression, $.$sle.System.Linq.Expressions.MemberExpression));
                    }
                }, {"r":65537,"p":[{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"body","p":38965109}],"n":"","d":this.$h,"h":0,"f":17825794}));
            }
            //default member initializer
            constructor()
            {
                super();
                this._firstExpression = $.$default($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ExpressionNotRepresentableMessage = "The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names.";
                }
            }
            static $h = 524299;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":this.$h,"p":[{"n":"expression","p":(U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h}],"g":["U"],"n":"ByAscending","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16908321},{"r":this.$h,"p":[{"n":"expression","p":(U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h}],"g":["U"],"n":"ByDescending","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16908321},{"r":this.$h,"p":[{"n":"expression","p":(U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h}],"g":["U"],"n":"ThenAscending","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16908289},{"r":this.$h,"p":[{"n":"expression","p":(U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h}],"g":["U"],"n":"ThenDescending","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16908289},{"r":$.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.System.Linq.IQueryable$$(TGridItem).$h},{"n":"ascending","p":262145}],"n":"Apply","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777224},{"r":$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,"p":[{"n":"ascending","p":262145}],"n":"ToPropertyList","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777224},{"r":$.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,"p":[{"n":"ascending","p":262145}],"n":"BuildPropertyList","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777218},{"r":1310721,"p":[{"n":"expression","p":38506357}],"n":"ToPropertyName","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777250}],"l":[{"t":1310721,"n":"ExpressionNotRepresentableMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338},{"t":$.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)).$h,"n":"_first","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem))).$h,"n":"_then","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":$.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean).$h,"n":"_firstExpression","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean)).$h,"n":"_thenExpressions","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,"n":"_cachedPropertyListAscending","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,"n":"_cachedPropertyListDescending","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194306}],"c":[{"p":[{"n":"first","p":$.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)).$h},{"n":"firstExpression","p":$.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777224}],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `GridSort<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.ColumnsCollectedNotifier<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.ColumnsCollectedNotifier<>", [TGridItem], ($self) => class ColumnsCollectedNotifier$$ extends $.$$.System.Object
        {
            /*bool*/ _isFirstRender = true;
            /*InternalGridContext<TGridItem>*/ InternalGridContext = null;
            /*void */ Attach(/*RenderHandle*/ renderHandle)
            {
            }
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                if (this._isFirstRender)
                {
                    this._isFirstRender = false;
                    parameters.SetParameterProperties(this);
                    return this.InternalGridContext.ColumnsFirstCollected.InvokeCallbacksAsync(null);
                }
                else 
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IComponent.Attach(Microsoft.AspNetCore.Components.RenderHandle)
            Microsoft$AspNetCore$Components$IComponent$Attach()
            {
                return this.Attach(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IComponent.SetParametersAsync(Microsoft.AspNetCore.Components.ParameterView)
            Microsoft$AspNetCore$Components$IComponent$SetParametersAsync()
            {
                return this.SetParametersAsync(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.InternalGridContext = null;
            }
            static $h = 720907;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331656},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":83886088},"n":"InternalGridContext","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097160,"a":[{"t":524296,"c":21475360776}]}],"m":[{"r":65537,"p":[{"n":"renderHandle","p":7012360}],"n":"Attach","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217},{"r":133169153,"p":[{"n":"parameters","p":5767176}],"n":"SetParametersAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"l":[{"t":262145,"n":"_isFirstRender","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217}],"i":[2752520],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent ]; }
            static get $fullName() { return `ColumnsCollectedNotifier<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber<>", (T) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber<>", [T], ($self) => class EventCallbackSubscriber$$ extends $.$$.System.Object
        {
            /*EventCallback<T>*/ _handler;
            /*EventCallbackSubscribable<T>?*/ _existingSubscription = null;
            $ctor$1(/*EventCallback<T>*/ handler)
            {
                super.$ctor();
                {
                    this._handler = handler;
                }
                return this;
            }
            /*void */ SubscribeOrMove(/*EventCallbackSubscribable<T>?*/ subscribable)
            {
                if (subscribable !== this._existingSubscription)
                {
                    this._existingSubscription?.Unsubscribe(this);
                    subscribable?.Subscribe(this, this._handler);
                    this._existingSubscription = subscribable;
                }
            }
            /*void */ Dispose()
            {
                this._existingSubscription?.Unsubscribe(this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._handler = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T));
            }
            static $h = 917515;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"subscribable","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$(T).$h}],"n":"SubscribeOrMove","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T).$h,"n":"_handler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$(T).$h,"n":"_existingSubscription","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"handler","p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"i":[57540609],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `EventCallbackSubscriber<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty", ($self) => class SortedProperty extends $.$$.System.ValueType
        {
            /*string*/ PropertyName = null;
            /*SortDirection*/ Direction = 0;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PropertyName = this.PropertyName;
                copy.Direction = this.Direction;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Direction = 0;
            }
            static $h = 1441803;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886343691,"f":50331649},"s":{"r":0,"d":0,"h":17181310987,"f":83886081},"n":"PropertyName","d":1441803,"h":8591376395,"f":2097153},{"p":1376267,"g":{"r":0,"d":0,"h":30066212875,"f":50331649},"s":{"r":0,"d":0,"h":34361180171,"f":83886081},"n":"Direction","d":1441803,"h":25771245579,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":1441803,"h":38656147467,"f":16777217}],"h":1441803}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `SortedProperty`; }
        });
        
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult<>", [TGridItem], ($self) => class GridItemsProviderResult$$ extends $.$$.System.ValueType
        {
            /*ICollection<TGridItem>*/ Items = null;
            /*int*/ TotalItemCount = 0;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Items = this.Items;
                copy.TotalItemCount = this.TotalItemCount;
                return copy;
            }
            static $h = 458763;
            static $g = 1;
            static $z = 8;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.Collections.Generic.ICollection$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":83886081},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":83886081},"n":"TotalItemCount","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217}],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `GridItemsProviderResult<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1572875;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":1572875,"h":4296540171,"f":16777217}],"h":1572875}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$macq.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1638411;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":1638411,"h":4296605707,"f":16777217}],"h":1638411,"a":[{"t":1572875,"c":4296540171},{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest<>", [TGridItem], ($self) => class GridItemsProviderRequest$$ extends $.$$.System.ValueType
        {
            /*int*/ StartIndex = 0;
            /*int?*/ Count = null;
            /*ColumnBase<TGridItem>?*/ SortByColumn = null;
            /*bool*/ SortByAscending = false;
            /*CancellationToken*/ CancellationToken;
            $ctor$3(/*int*/ startIndex, /*int?*/ count, /*ColumnBase<TGridItem>?*/ sortByColumn, /*bool*/ sortByAscending, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$1();
                {
                    this.StartIndex = startIndex;
                    this.Count = count;
                    this.SortByColumn = sortByColumn;
                    this.SortByAscending = sortByAscending;
                    this.CancellationToken = cancellationToken;
                }
                return this;
            }
            /*IQueryable<TGridItem> */ ApplySorting(/*IQueryable<TGridItem>*/ source)
            {
                /*Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<TGridItem>?*/ let __ca1__;
                /*Microsoft.AspNetCore.Components.QuickGrid.GridSort<TGridItem>?*/ let __ca2__;
                return ((__ca1__ = this.SortByColumn) !== null ? ((__ca2__ = __ca1__.SortBy) !== null ? __ca2__.Apply(source, this.SortByAscending) : source) : source);
            }
            /*IReadOnlyCollection<SortedProperty> */ GetSortByProperties()
            {
                /*Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<TGridItem>?*/ let __ca3__;
                /*Microsoft.AspNetCore.Components.QuickGrid.GridSort<TGridItem>?*/ let __ca4__;
                return ((__ca3__ = this.SortByColumn) !== null ? ((__ca4__ = __ca3__.SortBy) !== null ? __ca4__.ToPropertyList(this.SortByAscending) : $.$$.System.Array.Empty($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty)) : $.$$.System.Array.Empty($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty));
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.StartIndex = this.StartIndex;
                copy.Count = this.Count;
                copy.SortByColumn = this.SortByColumn;
                copy.SortByAscending = this.SortByAscending;
                copy.CancellationToken = this.CancellationToken.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Count = null;
                this.SortByAscending = false;
                this.CancellationToken = $.$default($.$$.System.Threading.CancellationToken);
            }
            static $h = 327691;
            static $g = 1;
            static $z = 18;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":83886081},"n":"StartIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153},{"p":$.$typeNullable($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":83886081},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":83886081},"n":"SortByColumn","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":83886081},"n":"SortByAscending","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2097153},{"p":125829121,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":83886081},"n":"CancellationToken","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097153}],"m":[{"r":$.$sle.System.Linq.IQueryable$$(TGridItem).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$(TGridItem).$h}],"n":"ApplySorting","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777217},{"r":$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,"n":"GetSortByProperties","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777217}],"c":[{"p":[{"n":"startIndex","p":655361},{"n":"count","p":$.$typeNullable($.$$.System.Int32).$h},{"n":"sortByColumn","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h},{"n":"sortByAscending","p":262145},{"n":"cancellationToken","p":125829121}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777224},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777217}],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `GridItemsProviderRequest<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.Defer", ($self) => class Defer extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*RenderFragment?*/ ChildContent = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.AddContent$4(0, this.ChildContent);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 786443;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":6881288,"g":{"r":0,"d":0,"h":12885688331,"f":50331649},"s":{"r":0,"d":0,"h":17180655627,"f":83886081},"n":"ChildContent","d":786443,"h":8590721035,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":786443,"h":21475622923,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":786443,"h":25770590219,"f":16777217}],"i":[2752520,3145736,3080200],"h":786443,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Defer`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Paginator", ($self) => class Paginator extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*EventCallbackSubscriber<PaginationState>*/ _totalItemCountChanged = null;
            /*PaginationState*/ State = null;
            /*RenderFragment?*/ SummaryTemplate = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._totalItemCountChanged = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1(new ($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$3(this, null));
                }
                return this;
            }
            /*Task */ GoFirstAsync()
            {
                return this.GoToPageAsync(0);
            }
            /*Task */ GoPreviousAsync()
            {
                return this.GoToPageAsync(((this.State.CurrentPageIndex - 1) | 0));
            }
            /*Task */ GoNextAsync()
            {
                return this.GoToPageAsync(((this.State.CurrentPageIndex + 1) | 0));
            }
            /*Task */ GoLastAsync()
            {
                return this.GoToPageAsync($.$$.System.Nullable$$($.$$.System.Int32).GetValueOrDefault$1.call(this.State.LastPageIndex, 0));
            }
            /*bool */ get CanGoBack()
            {
                return this.State.CurrentPageIndex > 0;
            }
            /*bool */ get CanGoForwards()
            {
                return $.$$.System.Int32.op_LessThan(this.State.CurrentPageIndex, this.State.LastPageIndex);
            }
            /*Task */ GoToPageAsync(/*int*/ pageIndex)
            {
                return this.State.SetCurrentPageIndexAsync(pageIndex);
            }
            /*void */ OnParametersSet()
            {
                return this._totalItemCountChanged.SubscribeOrMove(this.State.TotalItemCountChangedSubscribable);
            }
            /*void */ Dispose()
            {
                return this._totalItemCountChanged.Dispose();
            }
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$3(1, "class", "paginator");
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(this.State.TotalItemCount))
                {
                    __builder.OpenElement(2, "div");
                    __builder.AddAttribute$3(3, "class", "summary");
                    if (!(this.SummaryTemplate === null))
                    {
                        __builder.AddContent$4(4, this.SummaryTemplate);
                    }
                    else 
                    {
                        __builder.OpenElement(5, "strong");
                        __builder.AddContent$1(6, $.$box(this.State.TotalItemCount, $.$$.System.Nullable$$($.$$.System.Int32)));
                        __builder.CloseElement();
                        __builder.AddContent$2(7, " items");
                    }
                    __builder.CloseElement();
                    __builder.AddMarkupContent(8, "\r\n        ");
                    __builder.OpenElement(9, "nav");
                    __builder.AddAttribute$3(10, "role", "navigation");
                    __builder.OpenElement(11, "button");
                    __builder.AddAttribute$3(12, "class", "go-first");
                    __builder.AddAttribute$3(13, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 14, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoFirstAsync)));
                    __builder.AddAttribute(15, "disabled", !this.CanGoBack);
                    __builder.AddAttribute$3(16, "title", "Go to first page");
                    __builder.AddAttribute$3(17, "aria-label", "Go to first page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(18, "\r\n            ");
                    __builder.OpenElement(19, "button");
                    __builder.AddAttribute$3(20, "class", "go-previous");
                    __builder.AddAttribute$3(21, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 22, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoPreviousAsync)));
                    __builder.AddAttribute(23, "disabled", !this.CanGoBack);
                    __builder.AddAttribute$3(24, "title", "Go to previous page");
                    __builder.AddAttribute$3(25, "aria-label", "Go to previous page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(26, "\r\n            ");
                    __builder.OpenElement(27, "div");
                    __builder.AddAttribute$3(28, "class", "pagination-text");
                    __builder.AddMarkupContent(29, "\r\n                Page ");
                    __builder.OpenElement(30, "strong");
                    __builder.AddContent$1(31, $.$box(((this.State.CurrentPageIndex + 1) | 0), $.$$.System.Int32));
                    __builder.CloseElement();
                    __builder.AddMarkupContent(32, "\r\n                of ");
                    __builder.OpenElement(33, "strong");
                    __builder.AddContent$1(34, $.$box($.$$.System.Int32.op_Addition$1(this.State.LastPageIndex, 1), $.$$.System.Int32));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(35, "\r\n            ");
                    __builder.OpenElement(36, "button");
                    __builder.AddAttribute$3(37, "class", "go-next");
                    __builder.AddAttribute$3(38, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 39, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoNextAsync)));
                    __builder.AddAttribute(40, "disabled", !this.CanGoForwards);
                    __builder.AddAttribute$3(41, "title", "Go to next page");
                    __builder.AddAttribute$3(42, "aria-label", "Go to next page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(43, "\r\n            ");
                    __builder.OpenElement(44, "button");
                    __builder.AddAttribute$3(45, "class", "go-last");
                    __builder.AddAttribute$3(46, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 47, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoLastAsync)));
                    __builder.AddAttribute(48, "disabled", !this.CanGoForwards);
                    __builder.AddAttribute$3(49, "title", "Go to last page");
                    __builder.AddAttribute$3(50, "aria-label", "Go to last page");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.State = null;
            }
            static $h = 1179659;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1114123,"g":{"r":0,"d":0,"h":17181048843,"f":50331649},"s":{"r":0,"d":0,"h":21476016139,"f":83886081},"n":"State","d":1179659,"h":12886081547,"f":2097153,"a":[{"t":5636104,"c":21480472584},{"t":1835016,"c":4296802312}]},{"p":6881288,"g":{"r":0,"d":0,"h":34360918027,"f":50331649},"s":{"r":0,"d":0,"h":38655885323,"f":83886081},"n":"SummaryTemplate","d":1179659,"h":30065950731,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":262145,"g":{"r":0,"d":0,"h":68720656395,"f":50331650},"n":"CanGoBack","d":1179659,"h":64425689099,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":77310590987,"f":50331650},"n":"CanGoForwards","d":1179659,"h":73015623691,"f":2097154}],"m":[{"r":133169153,"n":"GoFirstAsync","d":1179659,"h":47245819915,"f":16777218},{"r":133169153,"n":"GoPreviousAsync","d":1179659,"h":51540787211,"f":16777218},{"r":133169153,"n":"GoNextAsync","d":1179659,"h":55835754507,"f":16777218},{"r":133169153,"n":"GoLastAsync","d":1179659,"h":60130721803,"f":16777218},{"r":133169153,"p":[{"n":"pageIndex","p":655361}],"n":"GoToPageAsync","d":1179659,"h":81605558283,"f":16777218},{"r":65537,"n":"OnParametersSet","d":1179659,"h":85900525579,"f":16809988},{"r":65537,"n":"Dispose","d":1179659,"h":90195492875,"f":16777217},{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1179659,"h":94490460171,"f":16809988}],"l":[{"t":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,"n":"_totalItemCountChanged","d":1179659,"h":4296146955,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1179659,"h":42950852619,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":1179659}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Paginator`; }
        });
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid<>", [TGridItem], ($self) => class QuickGrid$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.CascadingValue$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem)), 0);
                __builder.AddComponentParameter(1, "IsFixed", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Boolean, true), $.$$.System.Boolean));
                __builder.AddComponentParameter(2, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem), this._internalGridContext));
                __builder.AddAttribute$1(3, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    this.StartCollectingColumns();
                    __builder2.AddContent$4(4, this.ChildContent);
                    __builder2.AddMarkupContent(5, "\r\n    ");
                    __builder2.OpenComponent$1($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.Defer, 6);
                    __builder2.AddAttribute$1(7, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        this.FinishCollectingColumns();
                        __builder3.OpenComponent$1($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.ColumnsCollectedNotifier$$(TGridItem), 8);
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(9, "\r\n\r\n        ");
                        __builder3.OpenElement(10, "table");
                        __builder3.AddAttribute$3(11, "theme", this.Theme);
                        __builder3.AddAttribute$2(12, "aria-rowcount", $.$box(((this._ariaBodyRowCount + 1) | 0), $.$$.System.Int32));
                        __builder3.AddAttribute$7($.$$.System.EventArgs, 13, "onclosecolumnoptions", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$$.System.EventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.HideColumnOptionsAsync)));
                        __builder3.AddMultipleAttributes(14, $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), this.AdditionalAttributes));
                        __builder3.AddAttribute$3(15, "class", this.GridClass());
                        __builder3.AddElementReferenceCapture(16, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this._tableReference = __value;
                        }, {"r":65537,"p":[{"n":"__value","p":1900552}],"n":"","d":this.$h,"h":0,"f":17825794}));
                        __builder3.OpenElement(17, "thead");
                        __builder3.OpenElement(18, "tr");
                        __builder3.AddContent$4(19, this._renderColumnHeaders);
                        __builder3.CloseElement();
                        __builder3.CloseElement();
                        __builder3.AddMarkupContent(20, "\r\n            ");
                        __builder3.OpenElement(21, "tbody");
                        if (this.Virtualize)
                        {
                            __builder3.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)), 22);
                            __builder3.AddComponentParameter(23, "ItemSize", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Single, this.ItemSize), $.$$.System.Single));
                            __builder3.AddComponentParameter(24, "OverscanCount", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Int32, this.OverscanCount), $.$$.System.Int32));
                            __builder3.AddComponentParameter(25, "ItemsProvider", new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor(this, (this.ProvideVirtualizedItems)));
                            __builder3.AddComponentParameter(26, "ItemContent", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor(this, ( (/*item*/ item) =>
                            {
                                return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                                {
                                    return this.RenderRow(builder, item.Item1, item.Item2);
                                }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":this.$h,"h":0,"f":17825794});
                            })));
                            __builder3.AddComponentParameter(27, "Placeholder", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext))().$ctor(this, ( (/*placeholderContext*/ placeholderContext) =>
                            {
                                return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                                {
                                    return this.RenderPlaceholderRow(builder, placeholderContext);
                                }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":this.$h,"h":0,"f":17825794});
                            })));
                            __builder3.AddComponentReferenceCapture(28, new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this._virtualizeComponent = $.$cast(__value, $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)));
                            }, {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                        else 
                        {
                            __builder3.AddContent$4(29, this._renderNonVirtualizedRows);
                        }
                        __builder3.CloseElement();
                        __builder3.CloseElement();
                    })));
                    __builder2.CloseComponent();
                })));
                __builder.CloseComponent();
            }
            /*void */ RenderNonVirtualizedRows(/*RenderTreeBuilder*/ __builder)
            {
                /*var*/ let initialRowIndex = 2;
                /*var*/ let rowIndex = initialRowIndex;
                var $en2 = this._currentNonVirtualizedViewItems.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.RenderRow(__builder, rowIndex++, item);
                    }
                }
                if (!(this.Pagination === null))
                {
                    while(rowIndex++ < ((initialRowIndex + this.Pagination.ItemsPerPage) | 0))
                    {
                        __builder.OpenElement(30, "tr");
                        var $en4 = this._columns.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var col = $en4.Current;
                            {
                                __builder.OpenElement(31, "td");
                                __builder.AddAttribute$3(32, "class", $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(col));
                                __builder.SetKey(col);
                                __builder.CloseElement();
                            }
                        }
                        __builder.CloseElement();
                    }
                }
            }
            /*void */ RenderRow(/*RenderTreeBuilder*/ __builder, /*int*/ rowIndex, /*TGridItem*/ item)
            {
                /*var*/ let rowClass = (this.RowClass?.Invoke(item) ?? null);
                __builder.OpenElement(33, "tr");
                __builder.AddAttribute$2(34, "aria-rowindex", $.$box(rowIndex, $.$$.System.Int32));
                __builder.AddAttribute$3(35, "class", rowClass);
                __builder.SetKey(this.ItemKey.Invoke(item));
                var $en2 = this._columns.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var col = $en2.Current;
                    {
                        __builder.OpenElement(36, "td");
                        __builder.AddAttribute$3(37, "class", $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(col));
                        __builder.SetKey(col);
                        col.CellContent(__builder, item);
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
            }
            /*void */ RenderPlaceholderRow(/*RenderTreeBuilder*/ __builder, /*PlaceholderContext*/ placeholderContext)
            {
                __builder.OpenElement(38, "tr");
                __builder.AddAttribute$2(39, "aria-rowindex", $.$box(((placeholderContext.Index + 1) | 0), $.$$.System.Int32));
                var $en2 = this._columns.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var col = $en2.Current;
                    {
                        __builder.OpenElement(40, "td");
                        __builder.AddAttribute$3(41, "class", "grid-cell-placeholder" + " " + ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(col)));
                        __builder.SetKey(col);
                        col.RenderPlaceholderContent(__builder, placeholderContext);
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
            }
            /*void */ RenderColumnHeaders(/*RenderTreeBuilder*/ __builder)
            {
                var $en2 = this._columns.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var col = $en2.Current;
                    {
                        __builder.OpenElement(42, "th");
                        __builder.AddAttribute$3(43, "class", this.ColumnHeaderClass(col));
                        __builder.AddAttribute$3(44, "aria-sort", this.AriaSortValue(col));
                        __builder.AddAttribute$3(45, "scope", "col");
                        __builder.SetKey(col);
                        __builder.OpenElement(46, "div");
                        __builder.AddAttribute$3(47, "class", "col-header-content");
                        __builder.AddContent$4(48, col.HeaderContent);
                        __builder.CloseElement();
                        if (col === this._displayOptionsForColumn)
                        {
                            __builder.OpenElement(49, "div");
                            __builder.AddAttribute$3(50, "class", "col-options");
                            __builder.AddContent$4(51, col.ColumnOptions);
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                    }
                }
            }
            /*IQueryable<TGridItem>?*/ Items = null;
            /*GridItemsProvider<TGridItem>?*/ ItemsProvider = null;
            /*string?*/ Class = null;
            /*string?*/ Theme = null;
            /*RenderFragment?*/ ChildContent = null;
            /*bool*/ Virtualize = false;
            /*int*/ OverscanCount = 0;
            /*float*/ ItemSize = 0;
            /*Func<TGridItem, object>*/ ItemKey = null;
            /*PaginationState?*/ Pagination = null;
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            /*Func<TGridItem, string?>?*/ RowClass = null;
            /*IServiceProvider*/ Services = null;
            /*IJSRuntime*/ JS = null;
            /*ElementReference*/ _tableReference;
            /*Virtualize<(int, TGridItem)>?*/ _virtualizeComponent = null;
            /*int*/ _ariaBodyRowCount = 0;
            /*ICollection<TGridItem>*/ _currentNonVirtualizedViewItems = null;
            /*IAsyncQueryExecutor?*/ _asyncQueryExecutor = null;
            /*InternalGridContext<TGridItem>*/ _internalGridContext = null;
            /*List<ColumnBase<TGridItem>>*/ _columns = null;
            /*bool*/ _collectingColumns = false;
            /*ColumnBase<TGridItem>?*/ _displayOptionsForColumn = null;
            /*ColumnBase<TGridItem>?*/ _sortByColumn = null;
            /*bool*/ _sortByAscending = false;
            /*bool*/ _checkColumnOptionsPosition = false;
            /*IJSObjectReference?*/ _jsModule = null;
            /*IJSObjectReference?*/ _jsEventDisposable = null;
            /*RenderFragment*/ _renderColumnHeaders = null;
            /*RenderFragment*/ _renderNonVirtualizedRows = null;
            /*int?*/ _lastRefreshedPaginationStateHash = null;
            /*object?*/ _lastAssignedItemsOrProvider = null;
            /*CancellationTokenSource?*/ _pendingDataLoadCancellationTokenSource = null;
            /*EventCallbackSubscriber<PaginationState>*/ _currentPageItemsChanged = null;
            /*bool*/ _wasDisposed = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._columns = new ($.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)))().$ctor$1();
                    this._internalGridContext = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem))().$ctor$1(this);
                    this._currentPageItemsChanged = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.RefreshDataCoreAsync)));
                    this._renderColumnHeaders = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderColumnHeaders);
                    this._renderNonVirtualizedRows = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderNonVirtualizedRows);
                    /*var*/ let columnsFirstCollectedSubscriber = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$$.System.Object))().$ctor$1($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$$.System.Object, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.RefreshDataCoreAsync)));
                    columnsFirstCollectedSubscriber.SubscribeOrMove(this._internalGridContext.ColumnsFirstCollected);
                }
                return this;
            }
            /*Task */ OnParametersSetAsync()
            {
                this._currentPageItemsChanged.SubscribeOrMove((this.Pagination?.CurrentPageItemsChanged ?? null));
                if (!(this.Items === null) && !(this.ItemsProvider === null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"QuickGrid"} requires one of ${"Items"} or ${"ItemsProvider"}, but both were specified.`);
                }
                /*var*/ let _newItemsOrItemsProvider = this.Items ?? $.$cast(this.ItemsProvider, $.$$.System.Object);
                /*var*/ let dataSourceHasChanged = _newItemsOrItemsProvider !== this._lastAssignedItemsOrProvider;
                if (dataSourceHasChanged)
                {
                    this._lastAssignedItemsOrProvider = _newItemsOrItemsProvider;
                    this._asyncQueryExecutor = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier.GetAsyncQueryExecutor(TGridItem, this.Services, this.Items);
                }
                const $t1 = this.Pagination;
                /*var*/ let mustRefreshData = dataSourceHasChanged || ($.$ifnn($t1, ($t) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.call($t)) !== this._lastRefreshedPaginationStateHash);
                return (this._columns.Count > 0 && mustRefreshData) ? this.RefreshDataCoreAsync() : $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        this._jsModule = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, this.JS, "import", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "./_content/Microsoft.AspNetCore.Components.QuickGrid/QuickGrid.razor.js" ], null, null));
                        if (this._wasDisposed)
                        {
                            await this._jsModule.System$IAsyncDisposable$DisposeAsync();
                            return;
                        }
                        this._jsEventDisposable = await $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, this._jsModule, "init", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._tableReference ], null, null));
                    }
                    if (this._checkColumnOptionsPosition && !(this._displayOptionsForColumn === null))
                    {
                        this._checkColumnOptionsPosition = false;
                        /*Microsoft.JSInterop.IJSObjectReference?*/ let __ca1__;
                        _ = ((__ca1__ = this._jsModule) !== null ? $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeVoidAsync(__ca1__, "checkColumnOptionsPosition", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._tableReference ], null, null)).AsTask() : null);
                    }
                });
            }
            /*void */ AddColumn(/*ColumnBase<TGridItem>*/ column, /*SortDirection?*/ initialSortDirection, /*bool*/ isDefaultSortColumn)
            {
                if (this._collectingColumns)
                {
                    this._columns.Add(column);
                    if (isDefaultSortColumn && this._sortByColumn === null && $.$$.System.Nullable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection).HasValue$get.call(initialSortDirection))
                    {
                        this._sortByColumn = column;
                        this._sortByAscending = $.$$.System.Nullable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection).Value$get.call(initialSortDirection) !== 2/*SortDirection.Descending*/;
                    }
                }
            }
            /*void */ StartCollectingColumns()
            {
                this._columns.Clear();
                this._collectingColumns = true;
            }
            /*void */ FinishCollectingColumns()
            {
                this._collectingColumns = false;
            }
            /*Task */ SortByColumnAsync(/*ColumnBase<TGridItem>*/ column, /*SortDirection*/ direction)
            {
                this._sortByAscending = (() =>
                {
                    if (direction === 1/*SortDirection.Ascending*/)
                    {
                        return true;
                    }
                    if (direction === 2/*SortDirection.Descending*/)
                    {
                        return false;
                    }
                    if (direction === 0/*SortDirection.Auto*/)
                    {
                        return this._sortByColumn !== column || !this._sortByAscending;
                    }
                    throw new $.$$.System.NotSupportedException().$ctor$12(`Unknown sort direction ${direction}`);
                })();
                this._sortByColumn = column;
                this.StateHasChanged();
                return this.RefreshDataAsync();
            }
            /*Task */ ShowColumnOptionsAsync(/*ColumnBase<TGridItem>*/ column)
            {
                this._displayOptionsForColumn = column;
                this._checkColumnOptionsPosition = true;
                this.StateHasChanged();
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            /*Task */ HideColumnOptionsAsync()
            {
                this._displayOptionsForColumn = null;
                this.StateHasChanged();
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            /*Task *//*async*/  RefreshDataAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.RefreshDataCoreAsync();
                    this.StateHasChanged();
                });
            }
            /*Task *//*async*/  RefreshDataCoreAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this._pendingDataLoadCancellationTokenSource?.Cancel();
                    /*var*/ let thisLoadCts = this._pendingDataLoadCancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    if (!(this._virtualizeComponent === null))
                    {
                        await this._virtualizeComponent.RefreshDataAsync();
                        this._pendingDataLoadCancellationTokenSource = null;
                    }
                    else 
                    {
                        const $t1 = this.Pagination;
                        this._lastRefreshedPaginationStateHash = $.$ifnn($t1, ($t) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.call($t));
                        /*var*/ let startIndex = this.Pagination === null ? 0 : (((this.Pagination.CurrentPageIndex * this.Pagination.ItemsPerPage) | 0));
                        /*var*/ let request = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem))().$ctor$3(startIndex, (this.Pagination?.ItemsPerPage ?? null), this._sortByColumn, this._sortByAscending, thisLoadCts.Token);
                        /*var*/ let result = await this.ResolveItemsRequestAsync(request);
                        if (!thisLoadCts.IsCancellationRequested)
                        {
                            this._currentNonVirtualizedViewItems = result.Items;
                            this._ariaBodyRowCount = this._currentNonVirtualizedViewItems.System$Collections$Generic$ICollection$$$Count;
                            this.Pagination?.SetTotalItemCountAsync(result.TotalItemCount);
                            this._pendingDataLoadCancellationTokenSource = null;
                        }
                    }
                });
            }
            /*ValueTask<ItemsProviderResult<(int, TGridItem)>> *//*async*/  ProvideVirtualizedItems(/*ItemsProviderRequest*/ request)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem))), $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)), async () => 
                {
                    const $t1 = this.Pagination;
                    this._lastRefreshedPaginationStateHash = $.$ifnn($t1, ($t) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.call($t));
                    await $.$$.System.Threading.Tasks.Task.Delay$1(100);
                    if (request.CancellationToken.IsCancellationRequested)
                    {
                        return new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))();
                    }
                    /*var*/ let startIndex = request.StartIndex;
                    /*var*/ let count = request.Count;
                    if (!(this.Pagination === null))
                    {
                        startIndex += ((this.Pagination.CurrentPageIndex * this.Pagination.ItemsPerPage) | 0);
                        count = $.$$.System.Math.Min$4(request.Count, ((this.Pagination.ItemsPerPage - request.StartIndex) | 0));
                    }
                    /*var*/ let providerRequest = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem))().$ctor$3(startIndex, count, this._sortByColumn, this._sortByAscending, request.CancellationToken);
                    /*var*/ let providerResult = await this.ResolveItemsRequestAsync(providerRequest);
                    if (!request.CancellationToken.IsCancellationRequested)
                    {
                        this._ariaBodyRowCount = this.Pagination === null ? providerResult.TotalItemCount : this.Pagination.ItemsPerPage;
                        this.Pagination?.SetTotalItemCountAsync(providerResult.TotalItemCount);
                        return new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor$3($.$sl.System.Linq.Enumerable.Select(TGridItem, $.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem), providerResult.Items, new ($.$$.System.Func$$$$(TGridItem, $.$$.System.Int32, $.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor(this,  (/*x*/ x, /*i*/ i) =>
                        {
                            return $.$$.System.ValueTuple.Create$7($.$$.System.Int32, TGridItem, ((((i + request.StartIndex) | 0) + 2) | 0), x);
                        }, {"r":$.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem).$h,"p":[{"n":"x","p":TGridItem?.$h??1507328},{"n":"i","p":655361}],"n":"","d":this.$h,"h":0,"f":17825794})), this._ariaBodyRowCount);
                    }
                    return new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))();
                });
            }
            /*ValueTask<GridItemsProviderResult<TGridItem>> *//*async*/  ResolveItemsRequestAsync(/*GridItemsProviderRequest<TGridItem>*/ request)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)), $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem), async () => 
                {
                    if (!(this.ItemsProvider === null))
                    {
                        return await this.ItemsProvider.Invoke(request);
                    }
                    else if (!(this.Items === null))
                    {
                        /*var*/ let totalItemCount = this._asyncQueryExecutor === null ? $.$slq.System.Linq.Queryable.Count$1(TGridItem, this.Items) : await this._asyncQueryExecutor.Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$CountAsync(TGridItem, this.Items);
                        /*var*/ let result = $.$slq.System.Linq.Queryable.Skip(TGridItem, request.ApplySorting(this.Items), request.StartIndex);
                        if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(request.Count))
                        {
                            result = $.$slq.System.Linq.Queryable.Take(TGridItem, result, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(request.Count));
                        }
                        /*var*/ let resultArray = this._asyncQueryExecutor === null ? $.$sl.System.Linq.Enumerable.ToArray(TGridItem, result) : await this._asyncQueryExecutor.Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$ToArrayAsync(TGridItem, result);
                        return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult.From(TGridItem, resultArray, totalItemCount);
                    }
                    else 
                    {
                        return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult.From(TGridItem, $.$$.System.Array.Empty(TGridItem), 0);
                    }
                });
            }
            /*string */ AriaSortValue(/*ColumnBase<TGridItem>*/ column)
            {
                return this._sortByColumn === column ? (this._sortByAscending ? "ascending" : "descending") : "none";
            }
            /*string? */ ColumnHeaderClass(/*ColumnBase<TGridItem>*/ column)
            {
                return this._sortByColumn === column ? `${$.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(column)} ${(this._sortByAscending ? "col-sort-asc" : "col-sort-desc")}` : $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(column);
            }
            /*string */ GridClass()
            {
                /*var*/ let gridClass = `quickgrid ${this.Class} ${(this._pendingDataLoadCancellationTokenSource === null ? null : "loading")}`;
                return $.$macq.Microsoft.AspNetCore.Components.Forms.AttributeUtilities.CombineClassNames(this.AdditionalAttributes, gridClass) ?? $.$$.System.String.Empty;
            }
            static /*string? */ ColumnClass(/*ColumnBase<TGridItem>*/ column)
            {
                return (() =>
                {
                    let $switch1 = column.Align;
                    if ($switch1 === 0/*Align.Start*/)
                    {
                        return `col-justify-start ${column.Class}`;
                    }
                    if ($switch1 === 1/*Align.Center*/)
                    {
                        return `col-justify-center ${column.Class}`;
                    }
                    if ($switch1 === 2/*Align.End*/)
                    {
                        return `col-justify-end ${column.Class}`;
                    }
                    if ($switch1 === 3/*Align.Left*/)
                    {
                        return `col-justify-left ${column.Class}`;
                    }
                    if ($switch1 === 4/*Align.Right*/)
                    {
                        return `col-justify-right ${column.Class}`;
                    }
                    return column.Class;
                })();
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    this._wasDisposed = true;
                    this._currentPageItemsChanged.Dispose();
                    try
                    {
                        if (!(this._jsEventDisposable === null))
                        {
                            await $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeVoidAsync(this._jsEventDisposable, "stop", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            await this._jsEventDisposable.System$IAsyncDisposable$DisposeAsync();
                        }
                        if (!(this._jsModule === null))
                        {
                            await this._jsModule.System$IAsyncDisposable$DisposeAsync();
                        }
                    }
                    catch($e)
                    {
                    }
                });
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Theme = "default";
                this.Virtualize = false;
                this.OverscanCount = 3;
                this.ItemSize = 50;
                this.ItemKey = new ($.$$.System.Func$$$(TGridItem, $.$$.System.Object))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$box(x, TGridItem);
                }, {"r":131073,"p":[{"n":"x","p":TGridItem?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":17825794});
                this.Services = null;
                this.JS = null;
                this._tableReference = $.$default($.$mac.Microsoft.AspNetCore.Components.ElementReference);
                this._currentNonVirtualizedViewItems = $.$$.System.Array.Empty(TGridItem);
            }
            static $h = 1310731;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$sle.System.Linq.IQueryable$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":83886081},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProvider$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":83886081},"n":"ItemsProvider","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":83886081},"n":"Class","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1500000000n),"f":83886081},"n":"Theme","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":6881288,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1800000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1900000000n),"f":83886081},"n":"ChildContent","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":83886081},"n":"Virtualize","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2000000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2100000000n),"f":83886081},"n":"OverscanCount","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1114113,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2500000000n),"f":83886081},"n":"ItemSize","d":this.$h,"h":Number(BigInt(this.$h)|0x2300000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Func$$$(TGridItem, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2800000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2900000000n),"f":83886081},"n":"ItemKey","d":this.$h,"h":Number(BigInt(this.$h)|0x2700000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1114123,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2C00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":83886081},"n":"Pagination","d":this.$h,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3000000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3100000000n),"f":83886081},"n":"AdditionalAttributes","d":this.$h,"h":Number(BigInt(this.$h)|0x2F00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":$.$$.System.Func$$$(TGridItem, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3500000000n),"f":83886081},"n":"RowClass","d":this.$h,"h":Number(BigInt(this.$h)|0x3300000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":327717,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3800000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3900000000n),"f":83886082},"n":"Services","d":this.$h,"h":Number(BigInt(this.$h)|0x3700000000n),"f":2097154,"a":[{"t":4259848,"c":21479096328}]},{"p":524318,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3C00000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3D00000000n),"f":83886082},"n":"JS","d":this.$h,"h":Number(BigInt(this.$h)|0x3B00000000n),"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16809988},{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"RenderNonVirtualizedRows","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777218},{"r":65537,"p":[{"n":"__builder","p":7536648},{"n":"rowIndex","p":655361},{"n":"item","p":TGridItem?.$h??1507328}],"n":"RenderRow","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777218},{"r":65537,"p":[{"n":"__builder","p":7536648},{"n":"placeholderContext","p":7733257}],"n":"RenderPlaceholderRow","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777218},{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"RenderColumnHeaders","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777218},{"r":133169153,"n":"OnParametersSetAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5400000000n),"f":16809988},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5500000000n),"f":16814084},{"r":65537,"p":[{"n":"column","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h},{"n":"initialSortDirection","p":$.$typeNullable($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection).$h},{"n":"isDefaultSortColumn","p":262145}],"n":"AddColumn","d":this.$h,"h":Number(BigInt(this.$h)|0x5600000000n),"f":16777224},{"r":65537,"n":"StartCollectingColumns","d":this.$h,"h":Number(BigInt(this.$h)|0x5700000000n),"f":16777218},{"r":65537,"n":"FinishCollectingColumns","d":this.$h,"h":Number(BigInt(this.$h)|0x5800000000n),"f":16777218},{"r":133169153,"p":[{"n":"column","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h},{"n":"direction","p":1376267,"f":65,"v":0}],"n":"SortByColumnAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5900000000n),"f":16777217},{"r":133169153,"p":[{"n":"column","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h}],"n":"ShowColumnOptionsAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5A00000000n),"f":16777217},{"r":133169153,"n":"HideColumnOptionsAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5B00000000n),"f":16777217},{"r":133169153,"n":"RefreshDataAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5C00000000n),"f":16781313},{"r":133169153,"n":"RefreshDataCoreAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5D00000000n),"f":16781314},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem))).$h,"p":[{"n":"request","p":7536649}],"n":"ProvideVirtualizedItems","d":this.$h,"h":Number(BigInt(this.$h)|0x5E00000000n),"f":16781314},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)).$h,"p":[{"n":"request","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem).$h}],"n":"ResolveItemsRequestAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x5F00000000n),"f":16781314},{"r":1310721,"p":[{"n":"column","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h}],"n":"AriaSortValue","d":this.$h,"h":Number(BigInt(this.$h)|0x6000000000n),"f":16777218},{"r":1310721,"p":[{"n":"column","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h}],"n":"ColumnHeaderClass","d":this.$h,"h":Number(BigInt(this.$h)|0x6100000000n),"f":16777218},{"r":1310721,"n":"GridClass","d":this.$h,"h":Number(BigInt(this.$h)|0x6200000000n),"f":16777218},{"r":1310721,"p":[{"n":"column","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h}],"n":"ColumnClass","d":this.$h,"h":Number(BigInt(this.$h)|0x6300000000n),"f":16777250},{"r":135987201,"n":"DisposeAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x6400000000n),"f":16781313}],"l":[{"t":1900552,"n":"_tableReference","d":this.$h,"h":Number(BigInt(this.$h)|0x3E00000000n),"f":4194306},{"t":$.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)).$h,"n":"_virtualizeComponent","d":this.$h,"h":Number(BigInt(this.$h)|0x3F00000000n),"f":4194306},{"t":655361,"n":"_ariaBodyRowCount","d":this.$h,"h":Number(BigInt(this.$h)|0x4000000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.ICollection$$(TGridItem).$h,"n":"_currentNonVirtualizedViewItems","d":this.$h,"h":Number(BigInt(this.$h)|0x4100000000n),"f":4194306},{"t":589835,"n":"_asyncQueryExecutor","d":this.$h,"h":Number(BigInt(this.$h)|0x4200000000n),"f":4194306},{"t":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem).$h,"n":"_internalGridContext","d":this.$h,"h":Number(BigInt(this.$h)|0x4300000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)).$h,"n":"_columns","d":this.$h,"h":Number(BigInt(this.$h)|0x4400000000n),"f":4194306},{"t":262145,"n":"_collectingColumns","d":this.$h,"h":Number(BigInt(this.$h)|0x4500000000n),"f":4194306},{"t":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h,"n":"_displayOptionsForColumn","d":this.$h,"h":Number(BigInt(this.$h)|0x4600000000n),"f":4194306},{"t":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h,"n":"_sortByColumn","d":this.$h,"h":Number(BigInt(this.$h)|0x4700000000n),"f":4194306},{"t":262145,"n":"_sortByAscending","d":this.$h,"h":Number(BigInt(this.$h)|0x4800000000n),"f":4194306},{"t":262145,"n":"_checkColumnOptionsPosition","d":this.$h,"h":Number(BigInt(this.$h)|0x4900000000n),"f":4194306},{"t":458782,"n":"_jsModule","d":this.$h,"h":Number(BigInt(this.$h)|0x4A00000000n),"f":4194306},{"t":458782,"n":"_jsEventDisposable","d":this.$h,"h":Number(BigInt(this.$h)|0x4B00000000n),"f":4194306},{"t":6881288,"n":"_renderColumnHeaders","d":this.$h,"h":Number(BigInt(this.$h)|0x4C00000000n),"f":4194306},{"t":6881288,"n":"_renderNonVirtualizedRows","d":this.$h,"h":Number(BigInt(this.$h)|0x4D00000000n),"f":4194306},{"t":$.$typeNullable($.$$.System.Int32).$h,"n":"_lastRefreshedPaginationStateHash","d":this.$h,"h":Number(BigInt(this.$h)|0x4E00000000n),"f":4194306},{"t":131073,"n":"_lastAssignedItemsOrProvider","d":this.$h,"h":Number(BigInt(this.$h)|0x4F00000000n),"f":4194306},{"t":125960193,"n":"_pendingDataLoadCancellationTokenSource","d":this.$h,"h":Number(BigInt(this.$h)|0x5000000000n),"f":4194306},{"t":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,"n":"_currentPageItemsChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x5100000000n),"f":4194306},{"t":262145,"n":"_wasDisposed","d":this.$h,"h":Number(BigInt(this.$h)|0x5200000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x5300000000n),"f":16777217}],"i":[2752520,3145736,3080200,56950785],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":786440,"c":4295753736,"a":[{"v":"TGridItem","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.QuickGrid.QuickGrid<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProvider<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProvider<>", [TGridItem], ($self) => class GridItemsProvider$$ extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*ValueTask<GridItemsProviderResult<TGridItem>>*/ Invoke(/**/ request)
            {
                return this.$nativeFunction.call(this.$target, request);
            }
            static $h = 262155;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)).$h,"p":[{"n":"request","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem).$h}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777345},{"r":57016321,"p":[{"n":"request","p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem).$h},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)).$h,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[57212929,113246209],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `GridItemsProvider<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn<>", [TGridItem], ($self) => class TemplateColumn$$ extends $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)
        {
            /*RenderFragment<TGridItem>*/ static EmptyChildContent = null;
            /*RenderFragment<TGridItem>*/ ChildContent = null;
            /*GridSort<TGridItem>?*/ SortBy = null;
            /*void */ CellContent(/*RenderTreeBuilder*/ builder, /*TGridItem*/ item)
            {
                return builder.AddContent$4(0, this.ChildContent.Invoke(item));
            }
            /*bool */ IsSortableByDefault()
            {
                return !(this.SortBy === null);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ChildContent = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn$$(TGridItem).EmptyChildContent;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EmptyChildContent = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TGridItem))().$ctor(this,  (/*_*/ _0) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                        }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":this.$h,"h":0,"f":17825794});
                    }, {"r":6881288,"p":[{"n":"_","p":TGridItem?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":17825794});
                }
            }
            static $h = 1507339;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":83886081},"n":"ChildContent","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50364417},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":83918849},"n":"SortBy","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2129921,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"item","p":TGridItem?.$h??1507328}],"n":"CellContent","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16810000},{"r":262145,"n":"IsSortableByDefault","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16809988}],"l":[{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TGridItem).$h,"n":"EmptyChildContent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217}],"i":[2752520,3145736,3080200],"g":[TGridItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `TemplateColumn<${TGridItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.PropertyColumn<,>", (TGridItem, TProp) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.PropertyColumn<,>", [TGridItem, TProp], ($self) => class PropertyColumn$$$ extends $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)
        {
            /*Expression<Func<TGridItem, TProp>>?*/ _lastAssignedProperty = null;
            /*Func<TGridItem, string?>?*/ _cellTextFunc = null;
            /*GridSort<TGridItem>?*/ _sortBuilder = null;
            /*Expression<Func<TGridItem, TProp>>*/ Property = null;
            /*string?*/ Format = null;
            /*GridSort<TGridItem>? */ get SortBy()
            {
                return this._sortBuilder;
            }
            /*GridSort<TGridItem>? */ set SortBy(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12(`PropertyColumn generates this member internally. For custom sorting rules, see '${$.$$.System.Type.ToString.call($.$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn$$(TGridItem).$type)}'.`);
            }
            /*void */ OnParametersSet()
            {
                if (this._lastAssignedProperty !== this.Property)
                {
                    this._lastAssignedProperty = this.Property;
                    /*var*/ let compiledPropertyExpression = this.Property.Compile$3();
                    if (!$.$$.System.String.IsNullOrEmpty(this.Format))
                    {
                        /*var*/ let nullableUnderlyingTypeOrNull = $.$$.System.Nullable.GetUnderlyingType(TProp.$type);
                        if (!$.$$.System.IFormattable.$type.IsAssignableFrom(nullableUnderlyingTypeOrNull ?? TProp.$type))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`A '${"Format"}' parameter was supplied, but the type '${$.$$.System.Type.ToString.call(TProp.$type)}' does not implement '${$.$$.System.Type.ToString.call($.$$.System.IFormattable.$type)}'.`);
                        }
                        this._cellTextFunc = new ($.$$.System.Func$$$(TGridItem, $.$$.System.String))().$ctor(this,  (/*item*/ item) =>
                        {
                            return (($.$box(compiledPropertyExpression.Invoke(item), TProp))?.System$IFormattable$ToString(this.Format, null) ?? null);
                        }, {"r":1310721,"p":[{"n":"item","p":TGridItem?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":17825794});
                    }
                    else 
                    {
                        this._cellTextFunc = new ($.$$.System.Func$$$(TGridItem, $.$$.System.String))().$ctor(this,  (/*item*/ item) =>
                        {
                            const $t1 = () => compiledPropertyExpression.Invoke(item);
                            return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
                        }, {"r":1310721,"p":[{"n":"item","p":TGridItem?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":17825794});
                    }
                    this._sortBuilder = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).ByAscending(TProp, this.Property);
                }
                let memberExpression;
                if (this.Title === null && $.$is(this.Property.Body, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ memberExpression = v; } }))
                {
                    this.Title = memberExpression.Member.Name;
                }
            }
            /*void */ CellContent(/*RenderTreeBuilder*/ builder, /*TGridItem*/ item)
            {
                return builder.AddContent$2(0, this._cellTextFunc.Invoke(item));
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Property = null;
            }
            static $h = 1245195;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, TProp)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":83886081},"n":"Property","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584},{"t":1835016,"c":4296802312}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":83886081},"n":"Format","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50364417},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":83918849},"n":"SortBy","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2129921}],"m":[{"r":65537,"n":"OnParametersSet","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"item","p":TGridItem?.$h??1507328}],"n":"CellContent","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16810000}],"l":[{"t":$.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, TProp)).$h,"n":"_lastAssignedProperty","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$$.System.Func$$$(TGridItem, $.$$.System.String).$h,"n":"_cellTextFunc","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,"n":"_sortBuilder","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777217}],"i":[2752520,3145736,3080200],"g":[TGridItem?.$h??1507328,TProp?.$h??1572864],"r":2,"h":this.$h}; }
            static get $b() { return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `PropertyColumn<${TGridItem?.$fullName},${TProp?.$fullName}>`; }
        }));
        
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection", ($self) => class SortDirection extends $.$$.System.Enum
        {
            static Auto = 0;
            static Ascending = 1;
            static Descending = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Auto": 0n,
                    "Ascending": 1n,
                    "Descending": 2n
                };
            }
            static $h = 1376267;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1376267,"n":"Auto","d":1376267,"h":4296343563,"f":4194337},{"t":1376267,"n":"Ascending","d":1376267,"h":8591310859,"f":4194337},{"t":1376267,"n":"Descending","d":1376267,"h":12886278155,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1376267,"h":17181245451,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1376267}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `SortDirection`; }
        });
        
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.Align", ($self) => class Align extends $.$$.System.Enum
        {
            static Start = 0;
            static Center = 1;
            static End = 2;
            static Left = 3;
            static Right = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Start": 0n,
                    "Center": 1n,
                    "End": 2n,
                    "Left": 3n,
                    "Right": 4n
                };
            }
            static $h = 131083;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":131083,"n":"Start","d":131083,"h":4295098379,"f":4194337},{"t":131083,"n":"Center","d":131083,"h":8590065675,"f":4194337},{"t":131083,"n":"End","d":131083,"h":12885032971,"f":4194337},{"t":131083,"n":"Left","d":131083,"h":17180000267,"f":4194337},{"t":131083,"n":"Right","d":131083,"h":21474967563,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":131083,"h":25769934859,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":131083}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Align`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.System.Linq.Queryable"))