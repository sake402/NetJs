
//--TRIMMABLE-BOUNDARY-START(111)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mexla, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $slq) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.QuickGrid", 
    {
  "h": 111,
  "f": "Microsoft.AspNetCore.Components.QuickGrid",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Provides a simple and convenient data grid component for common grid rendering scenarios and serves as a reference architecture and performance baseline for building data grid components.\n      If you\u0027re using Entity Framework Core for your grid IQueryables, consider using the \u003Ca href=\u0022https://www.nuget.org/packages/Microsoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter\u0022\u003EMicrosoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter\u003C/a\u003E package.\n    ",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.QuickGrid",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.QuickGrid",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.QuickGrid.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(589935)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.IAsyncQueryExecutor", ($self) => class IAsyncQueryExecutor
        {
            static $h = 589935;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590524527),
    {
      "r": 262145,
      "p": [
        {
          "n": "queryable",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "IsSupported",
      "o": "Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$IsSupported",
      "d": 589935,
      "h": 8590524527,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590524527),
//--TRIMMABLE-BOUNDARY-START(4295557231),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "queryable",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CountAsync",
      "o": "Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$CountAsync",
      "d": 589935,
      "h": 4295557231,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(4295557231),
//--TRIMMABLE-BOUNDARY-START(12885491823),
    {
      "r": (T) => $.$$.System.Threading.Tasks.Task$$($.$typeArray(T)).$h,
      "p": [
        {
          "n": "queryable",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToArrayAsync",
      "o": "Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$ToArrayAsync",
      "d": 589935,
      "h": 12885491823,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(12885491823)
  ],
  "h": 589935
}; }
            static get $fullName() { return `IAsyncQueryExecutor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589935)
        
        
        //--TRIMMABLE-BOUNDARY-START(196719)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<>", [TGridItem], ($self) => class ColumnBase$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(206158626927)
            /*InternalGridContext<TGridItem>*/ InternalGridContext = null;
            //--TRIMMABLE-BOUNDARY-END(206158626927)
            
            //--TRIMMABLE-BOUNDARY-START(343597580399)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(343597580399)
            
            //--TRIMMABLE-BOUNDARY-START(68719673455)
            /*string?*/ Class = null;
            //--TRIMMABLE-BOUNDARY-END(68719673455)
            
            //--TRIMMABLE-BOUNDARY-START(55834771567)
            /*Align*/ Align = 0;
            //--TRIMMABLE-BOUNDARY-END(55834771567)
            
            //--TRIMMABLE-BOUNDARY-START(197568692335)
            /*RenderFragment<ColumnBase<TGridItem>>?*/ HeaderTemplate = null;
            //--TRIMMABLE-BOUNDARY-END(197568692335)
            
            //--TRIMMABLE-BOUNDARY-START(73014640751)
            /*RenderFragment?*/ ColumnOptions = null;
            //--TRIMMABLE-BOUNDARY-END(73014640751)
            
            //--TRIMMABLE-BOUNDARY-START(335007645807)
            /*bool?*/ Sortable = null;
            //--TRIMMABLE-BOUNDARY-END(335007645807)
            
            //--TRIMMABLE-BOUNDARY-START(201863659631)
            /*SortDirection*/ InitialSortDirection = 0;
            //--TRIMMABLE-BOUNDARY-END(201863659631)
            
            //--TRIMMABLE-BOUNDARY-START(210453594223)
            /*bool*/ IsDefaultSortColumn = false;
            //--TRIMMABLE-BOUNDARY-END(210453594223)
            
            //--TRIMMABLE-BOUNDARY-START(219043528815)
            /*RenderFragment<PlaceholderContext>?*/ PlaceholderTemplate = null;
            //--TRIMMABLE-BOUNDARY-END(219043528815)
            
            //--TRIMMABLE-BOUNDARY-START(188978757743)
            /*QuickGrid<TGridItem> */ get Grid()
            {
                return this.InternalGridContext.Grid;
            }
            //--TRIMMABLE-BOUNDARY-END(188978757743)
            
            //--TRIMMABLE-BOUNDARY-START(193273725039)
            /*RenderFragment*/ HeaderContent = null;
            //--TRIMMABLE-BOUNDARY-END(193273725039)
            
            //--TRIMMABLE-BOUNDARY-START(214748561519)
            /*bool */ IsSortableByDefault()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748561519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748561519)
            
            //--TRIMMABLE-BOUNDARY-START(51539804271)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539804271);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.HeaderContent = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderDefaultHeaderContent);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804271)
            
            //--TRIMMABLE-BOUNDARY-START(60129738863)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InternalGridContext.Grid.AddColumn(this, this.InitialSortDirection, this.IsDefaultSortColumn);
            }
            //--TRIMMABLE-BOUNDARY-END(60129738863)
            
            //--TRIMMABLE-BOUNDARY-START(223338496111)
            /*void */ RenderDefaultHeaderContent(/*RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338496111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this.HeaderTemplate === null))
                {
                    __builder.AddContent$4(0, this.HeaderTemplate.Invoke(this));
                }
                else 
                {
                    if (!(this.ColumnOptions === null) && (this.Align !== 4/*Align.Right*/ && this.Align !== 2/*Align.End*/))
                    {
                        __builder.OpenElement(1, "button");
                        __builder.AddAttribute$3(2, "class", "col-options-button");
                        __builder.AddAttribute$3(3, "type", "button");
                        __builder.AddAttribute$3(4, "title", "Column options");
                        __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 5, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.ShowColumnOptionsAsync(this);
                        }, {
  "r": 177668097,
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
})));
                        __builder.CloseElement();
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(this.Sortable) ? $.$$.System.Nullable$$($.$$.System.Boolean).Value$get.call(this.Sortable) : this.IsSortableByDefault())
                    {
                        __builder.OpenElement(6, "button");
                        __builder.AddAttribute$3(7, "class", "col-title");
                        __builder.AddAttribute$3(8, "type", "button");
                        __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 9, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.SortByColumnAsync(this, 0);
                        }, {
  "r": 177668097,
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
})));
                        __builder.OpenElement(10, "div");
                        __builder.AddAttribute$3(11, "class", "col-title-text");
                        __builder.AddContent$2(12, this.Title);
                        __builder.CloseElement();
                        __builder.AddMarkupContent(13, "\r\n                    <div class=\"sort-indicator\" aria-hidden=\"true\"></div>");
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.OpenElement(14, "div");
                        __builder.AddAttribute$3(15, "class", "col-title");
                        __builder.OpenElement(16, "div");
                        __builder.AddAttribute$3(17, "class", "col-title-text");
                        __builder.AddContent$2(18, this.Title);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    if (!(this.ColumnOptions === null) && (this.Align === 4/*Align.Right*/ || this.Align === 2/*Align.End*/))
                    {
                        __builder.OpenElement(19, "button");
                        __builder.AddAttribute$3(20, "class", "col-options-button");
                        __builder.AddAttribute$3(21, "type", "button");
                        __builder.AddAttribute$3(22, "title", "Column options");
                        __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 23, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.ShowColumnOptionsAsync(this);
                        }, {
  "r": 177668097,
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
})));
                        __builder.CloseElement();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338496111)
            
            //--TRIMMABLE-BOUNDARY-START(227633463407)
            /*void */ RenderPlaceholderContent(/*RenderTreeBuilder*/ __builder, /*PlaceholderContext*/ placeholderContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633463407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this.PlaceholderTemplate === null))
                {
                    __builder.AddContent$4(24, this.PlaceholderTemplate.Invoke(placeholderContext));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633463407)
            
            //default member initializer
            constructor()
            {
                super();
                this.InternalGridContext = null;
                this.InitialSortDirection = 0;
                this.IsDefaultSortColumn = false;
            }
            static $h = 196719;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "p": [
//--TRIMMABLE-BOUNDARY-START(206158626927),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4300000000n),
        "f": 83886088
      },
      "n": "InternalGridContext",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 2097160,
      "a": [
        {
          "t": 524396,
          "c": 8590458988
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206158626927),
//--TRIMMABLE-BOUNDARY-START(343597580399),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4D00000000n),
        "f": 83886081
      },
      "n": "Title",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(343597580399),
//--TRIMMABLE-BOUNDARY-START(68719673455),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3900000000n),
        "f": 83886081
      },
      "n": "Class",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719673455),
//--TRIMMABLE-BOUNDARY-START(55834771567),
    {
      "p": 131183,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3700000000n),
        "f": 83886081
      },
      "n": "Align",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834771567),
//--TRIMMABLE-BOUNDARY-START(197568692335),
    {
      "p": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3F00000000n),
        "f": 83886081
      },
      "n": "HeaderTemplate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197568692335),
//--TRIMMABLE-BOUNDARY-START(73014640751),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3B00000000n),
        "f": 83886081
      },
      "n": "ColumnOptions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014640751),
//--TRIMMABLE-BOUNDARY-START(335007645807),
    {
      "p": $.$typeNullable($.$$.System.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4900000000n),
        "f": 83886081
      },
      "n": "Sortable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335007645807),
//--TRIMMABLE-BOUNDARY-START(339302613103),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4B00000000n),
        "f": 83886337
      },
      "n": "SortBy",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(339302613103),
//--TRIMMABLE-BOUNDARY-START(201863659631),
    {
      "p": 1376367,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4100000000n),
        "f": 83886081
      },
      "n": "InitialSortDirection",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201863659631),
//--TRIMMABLE-BOUNDARY-START(210453594223),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4500000000n),
        "f": 83886081
      },
      "n": "IsDefaultSortColumn",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210453594223),
//--TRIMMABLE-BOUNDARY-START(219043528815),
    {
      "p": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4700000000n),
        "f": 83886081
      },
      "n": "PlaceholderTemplate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219043528815),
//--TRIMMABLE-BOUNDARY-START(188978757743),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "Grid",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978757743),
//--TRIMMABLE-BOUNDARY-START(193273725039),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331664
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3D00000000n),
        "f": 83886084
      },
      "n": "HeaderContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(193273725039)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424706159),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1507328
        }
      ],
      "n": "CellContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777488
    },
//--TRIMMABLE-BOUNDARY-END(64424706159),
//--TRIMMABLE-BOUNDARY-START(214748561519),
    {
      "r": 262145,
      "n": "IsSortableByDefault",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(214748561519),
//--TRIMMABLE-BOUNDARY-START(60129738863),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60129738863),
//--TRIMMABLE-BOUNDARY-START(223338496111),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "RenderDefaultHeaderContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223338496111),
//--TRIMMABLE-BOUNDARY-START(227633463407),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        },
        {
          "n": "placeholderContext",
          "p": 7733358
        }
      ],
      "n": "RenderPlaceholderContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(227633463407)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51539804271),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539804271)
  ],
  "i": [2752620,3145836,3080300
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `ColumnBase<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196719)
        
        
        //--TRIMMABLE-BOUNDARY-START(852079)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable<>", (T) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable<>", [T], ($self) => class EventCallbackSubscribable$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295819375)
            /*Dictionary<EventCallbackSubscriber<T>, EventCallback<T>>*/ _callbacks = null;
            //--TRIMMABLE-BOUNDARY-END(4295819375)
            
            //--TRIMMABLE-BOUNDARY-START(12885753967)
            /*Task *//*async*/  InvokeCallbacksAsync(/*T*/ eventArg)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885753967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    var $en3 = this._callbacks.Values.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var callback = $en3.Current;
                        {
                            await callback.InvokeAsync$1(eventArg);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885753967)
            
            //--TRIMMABLE-BOUNDARY-START(17180721263)
            /*void */ Subscribe(/*EventCallbackSubscriber<T>*/ owner, /*EventCallback<T>*/ callback)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180721263);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._callbacks.Add(owner, callback);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180721263)
            
            //--TRIMMABLE-BOUNDARY-START(21475688559)
            /*void */ Unsubscribe(/*EventCallbackSubscriber<T>*/ owner)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475688559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._callbacks.Remove$1(owner);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475688559)
            
            //--TRIMMABLE-BOUNDARY-START(8590786671)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786671)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295819375)
                this._callbacks = new ($.$$.System.Collections.Generic.Dictionary$$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T), $.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295819375)
                
            }
            static $h = 852079;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753967),
    {
      "r": 177668097,
      "p": [
        {
          "n": "eventArg",
          "p": T?.$h??1507328
        }
      ],
      "n": "InvokeCallbacksAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12885753967),
//--TRIMMABLE-BOUNDARY-START(17180721263),
    {
      "r": 65537,
      "p": [
        {
          "n": "owner",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T).$h
        },
        {
          "n": "callback",
          "p": $.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T).$h
        }
      ],
      "n": "Subscribe",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721263),
//--TRIMMABLE-BOUNDARY-START(21475688559),
    {
      "r": 65537,
      "p": [
        {
          "n": "owner",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T).$h
        }
      ],
      "n": "Unsubscribe",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688559)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819375),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$(T), $.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T)).$h,
      "n": "_callbacks",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786671),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786671)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EventCallbackSubscribable<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(852079)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048687)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext<>", [TGridItem], ($self) => class InternalGridContext$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655754351)
            /*QuickGrid<TGridItem>*/ Grid = null;
            //--TRIMMABLE-BOUNDARY-END(38655754351)
            
            //--TRIMMABLE-BOUNDARY-START(17180917871)
            /*EventCallbackSubscribable<object?>*/ ColumnsFirstCollected = null;
            //--TRIMMABLE-BOUNDARY-END(17180917871)
            
            //--TRIMMABLE-BOUNDARY-START(12885950575)
            $ctor$1(/*QuickGrid<TGridItem>*/ grid)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885950575);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Grid = grid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950575)
            
            //default member initializer
            constructor()
            {
                super();
                this.ColumnsFirstCollected = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$$.System.Object))().$ctor$1();
            }
            static $h = 1048687;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655754351),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Grid",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655754351),
//--TRIMMABLE-BOUNDARY-START(17180917871),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "ColumnsFirstCollected",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180917871)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950575),
    {
      "p": [
        {
          "n": "grid",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885950575)
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InternalGridContext<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1048687)
        
        
        //--TRIMMABLE-BOUNDARY-START(65647)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.Forms.AttributeUtilities", ($self) => class AttributeUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(4295032943)
            static /*string? */ CombineClassNames(/*IReadOnlyDictionary<string, object>?*/ additionalAttributes, /*string?*/ classNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let $class;
                if (additionalAttributes === null || !additionalAttributes.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue("class", $.$ref(() => $class, ($v) => $class = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    return classNames;
                }
                /*var*/ let classAttributeValue = $.$$.System.Convert.ToString$23($class, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                if ($.$$.System.String.IsNullOrEmpty(classAttributeValue))
                {
                    return classNames;
                }
                if ($.$$.System.String.IsNullOrEmpty(classNames))
                {
                    return classAttributeValue;
                }
                return `${classAttributeValue} ${classNames}`;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032943)
            
            static $h = 65647;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032943),
    {
      "r": 1310721,
      "p": [
        {
          "n": "additionalAttributes",
          "p": $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "classNames",
          "p": 1310721
        }
      ],
      "n": "CombineClassNames",
      "d": 65647,
      "h": 4295032943,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032943)
  ],
  "h": 65647
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AttributeUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65647)
        
        
        //--TRIMMABLE-BOUNDARY-START(983151)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventHandlers", ($self) => class EventHandlers
        {
            static $h = 983151;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 983151,
  "a": [
    {
      "t": 2490476,
      "c": 21477326956,
      "a": [
        {
          "v": "onclosecolumnoptions",
          "t": 1310721
        },
        {
          "v": 79757313,
          "t": 187760641
        },
        {
          "v": true,
          "t": 262145
        },
        {
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EventHandlers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983151)
        
        
        //--TRIMMABLE-BOUNDARY-START(393327)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult", ($self) => class GridItemsProviderResult
        {
            //--TRIMMABLE-BOUNDARY-START(4295360623)
            static /*GridItemsProviderResult<TGridItem> */ From(TGridItem, /*ICollection<TGridItem>*/ items, /*int*/ totalItemCount)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)()
                        const $t1 = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem);
                        const $i1 = new $t1();
                        $i1.Items = items;
                        $i1.TotalItemCount = totalItemCount;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360623)
            
            static $h = 393327;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360623),
    {
      "r": (TGridItem) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem).$h,
      "p": [
        {
          "n": "items",
          "p": (TGridItem) => $.$$.System.Collections.Generic.ICollection$$(TGridItem).$h
        },
        {
          "n": "totalItemCount",
          "p": 655361
        }
      ],
      "g": [
        "TGridItem"
      ],
      "n": "From",
      "d": 393327,
      "h": 4295360623,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295360623)
  ],
  "h": 393327
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `GridItemsProviderResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393327)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114223)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState", ($self) => class PaginationState extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103080329327)
            /*int*/ ItemsPerPage = 0;
            //--TRIMMABLE-BOUNDARY-END(103080329327)
            
            //--TRIMMABLE-BOUNDARY-START(38655819887)
            /*int*/ CurrentPageIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(38655819887)
            
            //--TRIMMABLE-BOUNDARY-START(154619936879)
            /*int?*/ TotalItemCount = null;
            //--TRIMMABLE-BOUNDARY-END(154619936879)
            
            //--TRIMMABLE-BOUNDARY-START(107375296623)
            /*int? */ get LastPageIndex()
            {
                return $.trunc(($.$$.System.Int32.op_Subtraction$1(this.TotalItemCount, 1)) / this.ItemsPerPage);
            }
            //--TRIMMABLE-BOUNDARY-END(107375296623)
            
            //--TRIMMABLE-BOUNDARY-START(158914904175)
            /*EventHandler<int?>?*/ TotalItemCountChanged = null;
            //--TRIMMABLE-BOUNDARY-END(158914904175)
            
            //--TRIMMABLE-BOUNDARY-START(158914904175)
            //--TRIMMABLE-BOUNDARY-START(34360852591)
            add_TotalItemCountChanged(/*EventHandler<int?>?*/ value)
            {
                this.TotalItemCountChanged = $.$$.System.Delegate.Combine(this.TotalItemCountChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360852591)
            
            //--TRIMMABLE-BOUNDARY-START(115965231215)
            remove_TotalItemCountChanged(/*EventHandler<int?>?*/ value)
            {
                this.TotalItemCountChanged = $.$$.System.Delegate.Remove(this.TotalItemCountChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(115965231215)
            
            //--TRIMMABLE-BOUNDARY-END(158914904175)
            
            //--TRIMMABLE-BOUNDARY-START(42950787183)
            /*EventCallbackSubscribable<PaginationState>*/ CurrentPageItemsChanged = null;
            //--TRIMMABLE-BOUNDARY-END(42950787183)
            
            //--TRIMMABLE-BOUNDARY-START(163209871471)
            /*EventCallbackSubscribable<PaginationState>*/ TotalItemCountChangedSubscribable = null;
            //--TRIMMABLE-BOUNDARY-END(163209871471)
            
            //--TRIMMABLE-BOUNDARY-START(98785362031)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785362031);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$5($.$$.System.Int32, $.$$.System.Int32, $.$typeNullable($.$$.System.Int32), this.ItemsPerPage, this.CurrentPageIndex, this.TotalItemCount);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(98785362031)
            
            //--TRIMMABLE-BOUNDARY-START(146030002287)
            /*Task */ SetCurrentPageIndexAsync(/*int*/ pageIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030002287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentPageIndex = pageIndex;
                return this.CurrentPageItemsChanged.InvokeCallbacksAsync(this);
            }
            //--TRIMMABLE-BOUNDARY-END(146030002287)
            
            //--TRIMMABLE-BOUNDARY-START(150324969583)
            /*Task */ SetTotalItemCountAsync(/*int*/ totalItemCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324969583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (totalItemCount === this.TotalItemCount)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                this.TotalItemCount = totalItemCount;
                if (this.CurrentPageIndex > 0 && $.$$.System.Int32.op_GreaterThan(this.CurrentPageIndex, this.LastPageIndex))
                {
                    return this.SetCurrentPageIndexAsync($.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(this.LastPageIndex));
                }
                else 
                {
                    this.TotalItemCountChanged?.Invoke(this, this.TotalItemCount);
                    return this.TotalItemCountChangedSubscribable.InvokeCallbacksAsync(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324969583)
            
            //--TRIMMABLE-BOUNDARY-START(25770917999)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770917999)
            
            //default member initializer
            constructor()
            {
                super();
                this.ItemsPerPage = 10;
                this.CurrentPageItemsChanged = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1();
                this.TotalItemCountChangedSubscribable = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1();
            }
            static $h = 1114223;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080329327),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720590959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145100399,
        "f": 83886081
      },
      "n": "ItemsPerPage",
      "d": 1114223,
      "h": 103080329327,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080329327),
//--TRIMMABLE-BOUNDARY-START(38655819887),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721775,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555165807,
        "f": 83886082
      },
      "n": "CurrentPageIndex",
      "d": 1114223,
      "h": 38655819887,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655819887),
//--TRIMMABLE-BOUNDARY-START(154619936879),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900460143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735034991,
        "f": 83886082
      },
      "n": "TotalItemCount",
      "d": 1114223,
      "h": 154619936879,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619936879),
//--TRIMMABLE-BOUNDARY-START(107375296623),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310525551,
        "f": 50331649
      },
      "n": "LastPageIndex",
      "d": 1114223,
      "h": 107375296623,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375296623),
//--TRIMMABLE-BOUNDARY-START(42950787183),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130656367,
        "f": 50331656
      },
      "n": "CurrentPageItemsChanged",
      "d": 1114223,
      "h": 42950787183,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42950787183),
//--TRIMMABLE-BOUNDARY-START(163209871471),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490394735,
        "f": 50331656
      },
      "n": "TotalItemCountChangedSubscribable",
      "d": 1114223,
      "h": 163209871471,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(163209871471)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98785362031),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1114223,
      "h": 98785362031,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785362031),
//--TRIMMABLE-BOUNDARY-START(146030002287),
    {
      "r": 177668097,
      "p": [
        {
          "n": "pageIndex",
          "p": 655361
        }
      ],
      "n": "SetCurrentPageIndexAsync",
      "d": 1114223,
      "h": 146030002287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030002287),
//--TRIMMABLE-BOUNDARY-START(150324969583),
    {
      "r": 177668097,
      "p": [
        {
          "n": "totalItemCount",
          "p": 655361
        }
      ],
      "n": "SetTotalItemCountAsync",
      "d": 1114223,
      "h": 150324969583,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150324969583)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770917999),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114223,
      "h": 25770917999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770917999)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(158914904175),
    {
      "e": $.$$.System.EventHandler$$($.$$.System.Nullable$$($.$$.System.Int32)).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$$.System.Nullable$$($.$$.System.Int32)).$h
          }
        ],
        "n": "add_TotalItemCountChanged",
        "d": 1114223,
        "h": 34360852591,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$$.System.Nullable$$($.$$.System.Int32)).$h
          }
        ],
        "n": "remove_TotalItemCountChanged",
        "d": 1114223,
        "h": 115965231215,
        "f": 285212673
      },
      "n": "TotalItemCountChanged",
      "d": 1114223,
      "h": 158914904175,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(158914904175)
  ],
  "h": 1114223
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `PaginationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114223)
        
        
        //--TRIMMABLE-BOUNDARY-START(655471)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier", ($self) => class AsyncQueryExecutorSupplier
        {
            //--TRIMMABLE-BOUNDARY-START(17180524655)
            /*ConcurrentDictionary<Type, bool>*/ static IsEntityFrameworkProviderTypeCache = null;
            //--TRIMMABLE-BOUNDARY-END(17180524655)
            
            //--TRIMMABLE-BOUNDARY-START(8590590063)
            static /*IAsyncQueryExecutor? */ GetAsyncQueryExecutor(T, /*IServiceProvider*/ services, /*IQueryable<T>?*/ queryable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590590063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(queryable === null))
                {
                    /*var*/ let executor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$macq.Microsoft.AspNetCore.Components.QuickGrid.IAsyncQueryExecutor, services);
                    if (executor === null)
                    {
                        const $t1 = () => queryable.System$Linq$IQueryable$Provider;
                        /*var*/ let providerType = $.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t));
                        if (!(providerType === null) && $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier.IsEntityFrameworkProviderTypeCache.GetOrAdd(providerType, new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier, $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier.IsEntityFrameworkProviderType)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`The supplied ${"IQueryable"} is provided by Entity Framework. To query it efficiently, you must reference the package Microsoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter and call AddQuickGridEntityFrameworkAdapter on your service collection.`);
                        }
                    }
                    else if (executor.Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$IsSupported(T, queryable))
                    {
                        return executor;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590063)
            
            //--TRIMMABLE-BOUNDARY-START(12885557359)
            static /*bool */ IsEntityFrameworkProviderType(/*Type*/ queryableProviderType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557359);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.System.Linq.Enumerable.Any($.$$.System.Type, queryableProviderType.GetInterfaces(), new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$$.System.String.Equals$2(x.FullName, "Microsoft.EntityFrameworkCore.Query.IAsyncQueryProvider", 4/*StringComparison.Ordinal*/);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "x",
      "p": 187760641
    }
  ],
  "n": "",
  "d": 655471,
  "h": 0,
  "f": 17825794
})) === true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885557359)
            
            //--TRIMMABLE-BOUNDARY-START(4295622767)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524655)
                    this.IsEntityFrameworkProviderTypeCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17180524655)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295622767)
            
            static $h = 655471;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590590063),
    {
      "r": 589935,
      "p": [
        {
          "n": "services",
          "p": 327718
        },
        {
          "n": "queryable",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetAsyncQueryExecutor",
      "d": 655471,
      "h": 8590590063,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590590063),
//--TRIMMABLE-BOUNDARY-START(12885557359),
    {
      "r": 262145,
      "p": [
        {
          "n": "queryableProviderType",
          "p": 187760641
        }
      ],
      "n": "IsEntityFrameworkProviderType",
      "d": 655471,
      "h": 12885557359,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885557359)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524655),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Boolean).$h,
      "n": "IsEntityFrameworkProviderTypeCache",
      "d": 655471,
      "h": 17180524655,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180524655)
  ],
  "h": 655471
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AsyncQueryExecutorSupplier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655471)
        
        
        //--TRIMMABLE-BOUNDARY-START(524399)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort<>", [TGridItem], ($self) => class GridSort$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540131951)
            /*string*/ static ExpressionNotRepresentableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51540131951)
            
            //--TRIMMABLE-BOUNDARY-START(12885426287)
            /*Func<IQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>*/ _first = null;
            //--TRIMMABLE-BOUNDARY-END(12885426287)
            
            //--TRIMMABLE-BOUNDARY-START(21475360879)
            /*List<Func<IOrderedQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>>?*/ _then = null;
            //--TRIMMABLE-BOUNDARY-END(21475360879)
            
            //--TRIMMABLE-BOUNDARY-START(17180393583)
            /*(LambdaExpression, bool)*/ _firstExpression;
            //--TRIMMABLE-BOUNDARY-END(17180393583)
            
            //--TRIMMABLE-BOUNDARY-START(25770328175)
            /*List<(LambdaExpression, bool)>?*/ _thenExpressions = null;
            //--TRIMMABLE-BOUNDARY-END(25770328175)
            
            //--TRIMMABLE-BOUNDARY-START(4295491695)
            /*IReadOnlyCollection<SortedProperty>?*/ _cachedPropertyListAscending = null;
            //--TRIMMABLE-BOUNDARY-END(4295491695)
            
            //--TRIMMABLE-BOUNDARY-START(8590458991)
            /*IReadOnlyCollection<SortedProperty>?*/ _cachedPropertyListDescending = null;
            //--TRIMMABLE-BOUNDARY-END(8590458991)
            
            //--TRIMMABLE-BOUNDARY-START(30065295471)
            $ctor$1(/*Func<IQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>*/ first, /*(LambdaExpression, bool)*/ firstExpression)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295471);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._first = first;
                    this._firstExpression = firstExpression.Clone();
                    this._then = null;
                    this._thenExpressions = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295471)
            
            //--TRIMMABLE-BOUNDARY-START(42950197359)
            static /*GridSort<TGridItem> */ ByAscending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950197359);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem))().$ctor$1(new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                    {
                        return asc ? $.$slq.System.Linq.Queryable.OrderBy$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.OrderByDescending$1(TGridItem, U, queryable, expression);
                    }, {
  "r": $.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,
  "p": [
    {
      "n": "queryable",
      "p": $.$sle.System.Linq.IQueryable$$(TGridItem).$h
    },
    {
      "n": "asc",
      "p": 262145
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}), new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, true));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950197359)
            
            //--TRIMMABLE-BOUNDARY-START(47245164655)
            static /*GridSort<TGridItem> */ ByDescending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245164655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem))().$ctor$1(new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/**/ queryable, /*asc*/ asc) =>
                    {
                        return asc ? $.$slq.System.Linq.Queryable.OrderByDescending$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.OrderBy$1(TGridItem, U, queryable, expression);
                    }, {
  "r": $.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,
  "p": [
    {
      "n": "queryable",
      "p": $.$sle.System.Linq.IQueryable$$(TGridItem).$h
    },
    {
      "n": "asc",
      "p": 262145
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}), new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, false));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245164655)
            
            //--TRIMMABLE-BOUNDARY-START(55835099247)
            /*GridSort<TGridItem> */ ThenAscending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._then ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem))))().$ctor$1();
                this._thenExpressions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean)))().$ctor$1();
                this._then.Add(new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.System.Linq.Queryable.ThenBy$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.ThenByDescending$1(TGridItem, U, queryable, expression);
                }, {
  "r": $.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,
  "p": [
    {
      "n": "queryable",
      "p": $.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h
    },
    {
      "n": "asc",
      "p": 262145
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                this._thenExpressions.Add(new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, true));
                this._cachedPropertyListAscending = null;
                this._cachedPropertyListDescending = null;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835099247)
            
            //--TRIMMABLE-BOUNDARY-START(60130066543)
            /*GridSort<TGridItem> */ ThenDescending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._then ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem))))().$ctor$1();
                this._thenExpressions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean)))().$ctor$1();
                this._then.Add(new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.System.Linq.Queryable.ThenByDescending$1(TGridItem, U, queryable, expression) : $.$slq.System.Linq.Queryable.ThenBy$1(TGridItem, U, queryable, expression);
                }, {
  "r": $.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,
  "p": [
    {
      "n": "queryable",
      "p": $.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h
    },
    {
      "n": "asc",
      "p": 262145
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                this._thenExpressions.Add(new ($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean))().$ctor$3(expression, false));
                this._cachedPropertyListAscending = null;
                this._cachedPropertyListDescending = null;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130066543)
            
            //--TRIMMABLE-BOUNDARY-START(34360262767)
            /*IOrderedQueryable<TGridItem> */ Apply(/*IQueryable<TGridItem>*/ queryable, /*bool*/ ascending)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let orderedQueryable = this._first.Invoke(queryable, ascending);
                if (!(this._then === null))
                {
                    var $en3 = this._then.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var clause = $en3.Current;
                        {
                            orderedQueryable = clause.Invoke(orderedQueryable, ascending);
                        }
                    }
                }
                return orderedQueryable;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262767)
            
            //--TRIMMABLE-BOUNDARY-START(64425033839)
            /*IReadOnlyCollection<SortedProperty> */ ToPropertyList(/*bool*/ ascending)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ascending)
                {
                    this._cachedPropertyListAscending ??= this.BuildPropertyList(true);
                    return this._cachedPropertyListAscending;
                }
                else 
                {
                    this._cachedPropertyListDescending ??= this.BuildPropertyList(false);
                    return this._cachedPropertyListDescending;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425033839)
            
            //--TRIMMABLE-BOUNDARY-START(38655230063)
            /*List<SortedProperty> */ BuildPropertyList(/*bool*/ ascending)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655230063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = (() =>
                {
                    //new $.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty)()
                    const $t1 = $.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add((() =>
                    {
                        //new $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty()
                        const $t2 = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty;
                        const $i2 = new $t2();
                        $i2.PropertyName = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).ToPropertyName(this._firstExpression.Item1);
                        $i2.Direction = ($.$$.System.Boolean.op_ExclusiveOr(this._firstExpression.Item2, ascending)) ? 2/*SortDirection.Descending*/ : 1/*SortDirection.Ascending*/;
                        return $i2;
                    })());
                    return $i1;
                })();
                if (!(this._thenExpressions === null))
                {
                    var $en3 = this._thenExpressions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        let [ thenLambda, thenAscending ] = $.$destructure($en3.Current);
                        {
                            result.Add((() =>
                            {
                                //new $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty()
                                const $t2 = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty;
                                const $i2 = new $t2();
                                $i2.PropertyName = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).ToPropertyName(thenLambda);
                                $i2.Direction = ($.$$.System.Boolean.op_ExclusiveOr(thenAscending, ascending)) ? 2/*SortDirection.Descending*/ : 1/*SortDirection.Ascending*/;
                                return $i2;
                            })());
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(38655230063)
            
            //--TRIMMABLE-BOUNDARY-START(68720001135)
            static /*string */ ToPropertyName(/*LambdaExpression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let expressionBody = expression.Body;
                if (expressionBody.NodeType === 10/*ExpressionType.Convert*/ || expressionBody.NodeType === 11/*ExpressionType.ConvertChecked*/)
                {
                    expressionBody = ($.$cast(expressionBody, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                }
                let body;
                if (!$.$is(expressionBody, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ body = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14("The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names."/*ExpressionNotRepresentableMessage*/);
                }
                if ($.$is(body.Expression, $.$sle.System.Linq.Expressions.ParameterExpression))
                {
                    return body.Member.Name;
                }
                /*var*/ let length = body.Member.Name.length;
                /*var*/ let node = body;
                while(!(node.Expression === null))
                {
                    let parentMember;
                    if ($.$is(node.Expression, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ parentMember = v; } }))
                    {
                        length += ((parentMember.Member.Name.length + 1) | 0);
                        node = parentMember;
                    }
                    else if ($.$is(node.Expression, $.$sle.System.Linq.Expressions.ParameterExpression))
                    {
                        break;
                    }
                    else 
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14("The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names."/*ExpressionNotRepresentableMessage*/);
                    }
                }
                return $.$$.System.String.Create$10($.$sle.System.Linq.Expressions.MemberExpression, length, body, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$sle.System.Linq.Expressions.MemberExpression))().$ctor(this,  (/*chars*/ chars, /*body*/ body) =>
                {
                    /*var*/ let nextPos = chars.Length;
                    while(!(body === null))
                    {
                        nextPos -= body.Member.Name.length;
                        let $t1 = chars;
                        $.$$.System.String.CopyTo$1.call(body.Member.Name, $t1.Slice(nextPos, $t1.Length - nextPos));
                        if (nextPos > 0)
                        {
                            chars.get_Item(--nextPos).$v = /*.*/ 46;
                        }
                        body = ($.$as(body.Expression, $.$sle.System.Linq.Expressions.MemberExpression));
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "chars",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "body",
      "p": 39321637
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(68720001135)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180393583)
                this._firstExpression = $.$default($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean));
                //--TRIMMABLE-BOUNDARY-END(17180393583)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51540131951)
                    this.ExpressionNotRepresentableMessage = "The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names.";
                    //--TRIMMABLE-BOUNDARY-END(51540131951)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524399;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950197359),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ByAscending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42950197359),
//--TRIMMABLE-BOUNDARY-START(47245164655),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ByDescending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47245164655),
//--TRIMMABLE-BOUNDARY-START(55835099247),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ThenAscending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(55835099247),
//--TRIMMABLE-BOUNDARY-START(60130066543),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ThenDescending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60130066543),
//--TRIMMABLE-BOUNDARY-START(34360262767),
    {
      "r": $.$sle.System.Linq.IOrderedQueryable$$(TGridItem).$h,
      "p": [
        {
          "n": "queryable",
          "p": $.$sle.System.Linq.IQueryable$$(TGridItem).$h
        },
        {
          "n": "ascending",
          "p": 262145
        }
      ],
      "n": "Apply",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360262767),
//--TRIMMABLE-BOUNDARY-START(64425033839),
    {
      "r": $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,
      "p": [
        {
          "n": "ascending",
          "p": 262145
        }
      ],
      "n": "ToPropertyList",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64425033839),
//--TRIMMABLE-BOUNDARY-START(38655230063),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,
      "p": [
        {
          "n": "ascending",
          "p": 262145
        }
      ],
      "n": "BuildPropertyList",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655230063),
//--TRIMMABLE-BOUNDARY-START(68720001135),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 38797349
        }
      ],
      "n": "ToPropertyName",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720001135)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540131951),
    {
      "t": 1310721,
      "n": "ExpressionNotRepresentableMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540131951),
//--TRIMMABLE-BOUNDARY-START(12885426287),
    {
      "t": $.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)).$h,
      "n": "_first",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426287),
//--TRIMMABLE-BOUNDARY-START(21475360879),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem))).$h,
      "n": "_then",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475360879),
//--TRIMMABLE-BOUNDARY-START(17180393583),
    {
      "t": $.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean).$h,
      "n": "_firstExpression",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180393583),
//--TRIMMABLE-BOUNDARY-START(25770328175),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean)).$h,
      "n": "_thenExpressions",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770328175),
//--TRIMMABLE-BOUNDARY-START(4295491695),
    {
      "t": $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,
      "n": "_cachedPropertyListAscending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491695),
//--TRIMMABLE-BOUNDARY-START(8590458991),
    {
      "t": $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,
      "n": "_cachedPropertyListDescending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065295471),
    {
      "p": [
        {
          "n": "first",
          "p": $.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TGridItem), $.$$.System.Boolean, $.$sle.System.Linq.IOrderedQueryable$$(TGridItem)).$h
        },
        {
          "n": "firstExpression",
          "p": $.$$.System.ValueTuple$$$($.$sle.System.Linq.Expressions.LambdaExpression, $.$$.System.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065295471)
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `GridSort<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(524399)
        
        
        //--TRIMMABLE-BOUNDARY-START(721007)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.ColumnsCollectedNotifier<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.ColumnsCollectedNotifier<>", [TGridItem], ($self) => class ColumnsCollectedNotifier$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688303)
            /*bool*/ _isFirstRender = true;
            //--TRIMMABLE-BOUNDARY-END(4295688303)
            
            //--TRIMMABLE-BOUNDARY-START(30065492079)
            /*InternalGridContext<TGridItem>*/ InternalGridContext = null;
            //--TRIMMABLE-BOUNDARY-END(30065492079)
            
            //--TRIMMABLE-BOUNDARY-START(17180590191)
            /*void */ Attach(/*RenderHandle*/ renderHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180590191)
            
            //--TRIMMABLE-BOUNDARY-START(42950393967)
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isFirstRender)
                {
                    this._isFirstRender = false;
                    parameters.SetParameterProperties(this);
                    return this.InternalGridContext.ColumnsFirstCollected.InvokeCallbacksAsync(null);
                }
                else 
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393967)
            
            //--TRIMMABLE-BOUNDARY-START(4297719916)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IComponent.Attach(Microsoft.AspNetCore.Components.RenderHandle)
            Microsoft$AspNetCore$Components$IComponent$Attach()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297719916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Attach(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297719916)
            
            //--TRIMMABLE-BOUNDARY-START(8592687212)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IComponent.SetParametersAsync(Microsoft.AspNetCore.Components.ParameterView)
            Microsoft$AspNetCore$Components$IComponent$SetParametersAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592687212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetParametersAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8592687212)
            
            //--TRIMMABLE-BOUNDARY-START(12885622895)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622895)
            
            //default member initializer
            constructor()
            {
                super();
                this.InternalGridContext = null;
            }
            static $h = 721007;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065492079),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 83886088
      },
      "n": "InternalGridContext",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097160,
      "a": [
        {
          "t": 524396,
          "c": 8590458988
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065492079)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590191),
    {
      "r": 65537,
      "p": [
        {
          "n": "renderHandle",
          "p": 7012460
        }
      ],
      "n": "Attach",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590191),
//--TRIMMABLE-BOUNDARY-START(42950393967),
    {
      "r": 177668097,
      "p": [
        {
          "n": "parameters",
          "p": 5767276
        }
      ],
      "n": "SetParametersAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393967)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688303),
    {
      "t": 262145,
      "n": "_isFirstRender",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622895),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622895)
  ],
  "i": [2752620
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent ]; }
            static get $fullName() { return `ColumnsCollectedNotifier<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(721007)
        
        
        //--TRIMMABLE-BOUNDARY-START(917615)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber<>", (T) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber<>", [T], ($self) => class EventCallbackSubscriber$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590852207)
            /*EventCallback<T>*/ _handler;
            //--TRIMMABLE-BOUNDARY-END(8590852207)
            
            //--TRIMMABLE-BOUNDARY-START(4295884911)
            /*EventCallbackSubscribable<T>?*/ _existingSubscription = null;
            //--TRIMMABLE-BOUNDARY-END(4295884911)
            
            //--TRIMMABLE-BOUNDARY-START(12885819503)
            $ctor$1(/*EventCallback<T>*/ handler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885819503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._handler = handler;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819503)
            
            //--TRIMMABLE-BOUNDARY-START(21475754095)
            /*void */ SubscribeOrMove(/*EventCallbackSubscribable<T>?*/ subscribable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (subscribable !== this._existingSubscription)
                {
                    this._existingSubscription?.Unsubscribe(this);
                    subscribable?.Subscribe(this, this._handler);
                    this._existingSubscription = subscribable;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475754095)
            
            //--TRIMMABLE-BOUNDARY-START(17180786799)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180786799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._existingSubscription?.Unsubscribe(this);
            }
            //--TRIMMABLE-BOUNDARY-END(17180786799)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590852207)
                this._handler = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T));
                //--TRIMMABLE-BOUNDARY-END(8590852207)
                
            }
            static $h = 917615;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475754095),
    {
      "r": 65537,
      "p": [
        {
          "n": "subscribable",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$(T).$h
        }
      ],
      "n": "SubscribeOrMove",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754095),
//--TRIMMABLE-BOUNDARY-START(17180786799),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786799)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852207),
    {
      "t": $.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T).$h,
      "n": "_handler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852207),
//--TRIMMABLE-BOUNDARY-START(4295884911),
    {
      "t": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable$$(T).$h,
      "n": "_existingSubscription",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884911)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819503),
    {
      "p": [
        {
          "n": "handler",
          "p": $.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819503)
  ],
  "i": [90308609
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `EventCallbackSubscriber<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917615)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441903)
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty", ($self) => class SortedProperty extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38656147567)
            /*string*/ PropertyName = null;
            //--TRIMMABLE-BOUNDARY-END(38656147567)
            
            //--TRIMMABLE-BOUNDARY-START(17181311087)
            /*SortDirection*/ Direction = 0;
            //--TRIMMABLE-BOUNDARY-END(17181311087)
            
            //--TRIMMABLE-BOUNDARY-START(12886343791)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343791)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PropertyName = this.PropertyName;
                copy.Direction = this.Direction;
                return copy;
            }
            static $h = 1441903;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656147567),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361180271,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836016751,
        "f": 83886081
      },
      "n": "PropertyName",
      "d": 1441903,
      "h": 38656147567,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656147567),
//--TRIMMABLE-BOUNDARY-START(17181311087),
    {
      "p": 1376367,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771245679,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246082159,
        "f": 83886081
      },
      "n": "Direction",
      "d": 1441903,
      "h": 17181311087,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181311087)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886343791),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441903,
      "h": 12886343791,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886343791)
  ],
  "h": 1441903
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `SortedProperty`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441903)
        
        
        //--TRIMMABLE-BOUNDARY-START(458863)
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult<>", [TGridItem], ($self) => class GridItemsProviderResult$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34360197231)
            /*ICollection<TGridItem>*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(34360197231)
            
            //--TRIMMABLE-BOUNDARY-START(55835033711)
            /*int*/ TotalItemCount = 0;
            //--TRIMMABLE-BOUNDARY-END(55835033711)
            
            //--TRIMMABLE-BOUNDARY-START(12885360751)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360751)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Items = this.Items;
                copy.TotalItemCount = this.TotalItemCount;
                return copy;
            }
            static $h = 458863;
            static $g = 1;
            static $z = 8;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360197231),
    {
      "p": $.$$.System.Collections.Generic.ICollection$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 83886081
      },
      "n": "Items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360197231),
//--TRIMMABLE-BOUNDARY-START(55835033711),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 83886081
      },
      "n": "TotalItemCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835033711)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360751),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360751)
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `GridItemsProviderResult<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458863)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572975)
        $asm.$cls("$macq.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296540271)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540271)
            
            static $h = 1572975;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540271),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572975,
      "h": 4296540271,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540271)
  ],
  "h": 1572975
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572975)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638511)
        $asm.$cls("$macq.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296605807)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605807)
            
            static $h = 1638511;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605807),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638511,
      "h": 4296605807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605807)
  ],
  "h": 1638511,
  "a": [
    {
      "t": 1572975,
      "c": 4296540271
    },
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638511)
        
        
        //--TRIMMABLE-BOUNDARY-START(327791)
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest<>", [TGridItem], ($self) => class GridItemsProviderRequest$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(146029215855)
            /*int*/ StartIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(146029215855)
            
            //--TRIMMABLE-BOUNDARY-START(42950000751)
            /*int?*/ Count = null;
            //--TRIMMABLE-BOUNDARY-END(42950000751)
            
            //--TRIMMABLE-BOUNDARY-START(141734248559)
            /*ColumnBase<TGridItem>?*/ SortByColumn = null;
            //--TRIMMABLE-BOUNDARY-END(141734248559)
            
            //--TRIMMABLE-BOUNDARY-START(137439281263)
            /*bool*/ SortByAscending = false;
            //--TRIMMABLE-BOUNDARY-END(137439281263)
            
            //--TRIMMABLE-BOUNDARY-START(38655033455)
            /*CancellationToken*/ CancellationToken;
            //--TRIMMABLE-BOUNDARY-END(38655033455)
            
            //--TRIMMABLE-BOUNDARY-START(30065098863)
            $ctor$3(/*int*/ startIndex, /*int?*/ count, /*ColumnBase<TGridItem>?*/ sortByColumn, /*bool*/ sortByAscending, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098863);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.StartIndex = startIndex;
                    this.Count = count;
                    this.SortByColumn = sortByColumn;
                    this.SortByAscending = sortByAscending;
                    this.CancellationToken = cancellationToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098863)
            
            //--TRIMMABLE-BOUNDARY-START(34360066159)
            /*IQueryable<TGridItem> */ ApplySorting(/*IQueryable<TGridItem>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<TGridItem>?*/ let __ca1__;
                /*Microsoft.AspNetCore.Components.QuickGrid.GridSort<TGridItem>?*/ let __ca2__;
                return ((__ca1__ = this.SortByColumn) !== null ? ((__ca2__ = __ca1__.SortBy) !== null ? __ca2__.Apply(source, this.SortByAscending) : source) : source);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066159)
            
            //--TRIMMABLE-BOUNDARY-START(90194641007)
            /*IReadOnlyCollection<SortedProperty> */ GetSortByProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194641007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<TGridItem>?*/ let __ca3__;
                /*Microsoft.AspNetCore.Components.QuickGrid.GridSort<TGridItem>?*/ let __ca4__;
                return ((__ca3__ = this.SortByColumn) !== null ? ((__ca4__ = __ca3__.SortBy) !== null ? __ca4__.ToPropertyList(this.SortByAscending) : $.$$.System.Array.Empty($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty)) : $.$$.System.Array.Empty($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty));
            }
            //--TRIMMABLE-BOUNDARY-END(90194641007)
            
            //--TRIMMABLE-BOUNDARY-START(25770131567)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131567)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.StartIndex = this.StartIndex;
                copy.Count = this.Count;
                copy.SortByColumn = this.SortByColumn;
                copy.SortByAscending = this.SortByAscending;
                copy.CancellationToken = this.CancellationToken.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.CancellationToken = $.$default($.$$.System.Threading.CancellationToken);
            }
            static $h = 327791;
            static $g = 1;
            static $z = 18;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(146029215855),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 83886081
      },
      "n": "StartIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029215855),
//--TRIMMABLE-BOUNDARY-START(42950000751),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 83886081
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950000751),
//--TRIMMABLE-BOUNDARY-START(141734248559),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 83886081
      },
      "n": "SortByColumn",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734248559),
//--TRIMMABLE-BOUNDARY-START(137439281263),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 83886081
      },
      "n": "SortByAscending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439281263),
//--TRIMMABLE-BOUNDARY-START(38655033455),
    {
      "p": 170065921,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 83886081
      },
      "n": "CancellationToken",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655033455)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066159),
    {
      "r": $.$sle.System.Linq.IQueryable$$(TGridItem).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$(TGridItem).$h
        }
      ],
      "n": "ApplySorting",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066159),
//--TRIMMABLE-BOUNDARY-START(90194641007),
    {
      "r": $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortedProperty).$h,
      "n": "GetSortByProperties",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194641007)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065098863),
    {
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": $.$typeNullable($.$$.System.Int32).$h
        },
        {
          "n": "sortByColumn",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h
        },
        {
          "n": "sortByAscending",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065098863),
//--TRIMMABLE-BOUNDARY-START(25770131567),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131567)
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `GridItemsProviderRequest<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327791)
        
        
        //--TRIMMABLE-BOUNDARY-START(786543)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.Defer", ($self) => class Defer extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(17180655727)
            /*RenderFragment?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(17180655727)
            
            //--TRIMMABLE-BOUNDARY-START(12885688431)
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.AddContent$4(0, this.ChildContent);
            }
            //--TRIMMABLE-BOUNDARY-END(12885688431)
            
            //--TRIMMABLE-BOUNDARY-START(8590721135)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721135)
            
            static $h = 786543;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180655727),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770590319,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360524911,
        "f": 83886081
      },
      "n": "ChildContent",
      "d": 786543,
      "h": 17180655727,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180655727)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885688431),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        }
      ],
      "n": "BuildRenderTree",
      "d": 786543,
      "h": 12885688431,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885688431)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590721135),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786543,
      "h": 8590721135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721135)
  ],
  "i": [2752620,3145836,3080300
  ],
  "h": 786543,
  "a": [
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Defer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786543)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179759)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.Paginator", ($self) => class Paginator extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296147055)
            /*EventCallbackSubscriber<PaginationState>*/ _totalItemCountChanged = null;
            //--TRIMMABLE-BOUNDARY-END(4296147055)
            
            //--TRIMMABLE-BOUNDARY-START(115965296751)
            /*PaginationState*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(115965296751)
            
            //--TRIMMABLE-BOUNDARY-START(120260264047)
            /*RenderFragment?*/ SummaryTemplate = null;
            //--TRIMMABLE-BOUNDARY-END(120260264047)
            
            //--TRIMMABLE-BOUNDARY-START(17181048943)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181048943);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._totalItemCountChanged = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1(new ($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$3(this, null));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048943)
            
            //--TRIMMABLE-BOUNDARY-START(73015623791)
            /*Task */ GoFirstAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015623791);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync(0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015623791)
            
            //--TRIMMABLE-BOUNDARY-START(85900525679)
            /*Task */ GoPreviousAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900525679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync(((this.State.CurrentPageIndex - 1) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900525679)
            
            //--TRIMMABLE-BOUNDARY-START(81605558383)
            /*Task */ GoNextAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605558383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync(((this.State.CurrentPageIndex + 1) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605558383)
            
            //--TRIMMABLE-BOUNDARY-START(77310591087)
            /*Task */ GoLastAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310591087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync($.$$.System.Nullable$$($.$$.System.Int32).GetValueOrDefault$1.call(this.State.LastPageIndex, 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310591087)
            
            //--TRIMMABLE-BOUNDARY-START(25770983535)
            /*bool */ get CanGoBack()
            {
                return this.State.CurrentPageIndex > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983535)
            
            //--TRIMMABLE-BOUNDARY-START(30065950831)
            /*bool */ get CanGoForwards()
            {
                return $.$$.System.Int32.op_LessThan(this.State.CurrentPageIndex, this.State.LastPageIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(30065950831)
            
            //--TRIMMABLE-BOUNDARY-START(90195492975)
            /*Task */ GoToPageAsync(/*int*/ pageIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195492975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.State.SetCurrentPageIndexAsync(pageIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195492975)
            
            //--TRIMMABLE-BOUNDARY-START(94490460271)
            /*void */ OnParametersSet()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490460271);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._totalItemCountChanged.SubscribeOrMove(this.State.TotalItemCountChangedSubscribable);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490460271)
            
            //--TRIMMABLE-BOUNDARY-START(34360918127)
            /*void */ Dispose()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918127);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._totalItemCountChanged.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360918127)
            
            //--TRIMMABLE-BOUNDARY-START(21476016239)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$3(1, "class", "paginator");
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(this.State.TotalItemCount))
                {
                    __builder.OpenElement(2, "div");
                    __builder.AddAttribute$3(3, "class", "summary");
                    if (!(this.SummaryTemplate === null))
                    {
                        __builder.AddContent$4(4, this.SummaryTemplate);
                    }
                    else 
                    {
                        __builder.OpenElement(5, "strong");
                        __builder.AddContent$1(6, $.$box(this.State.TotalItemCount, $.$$.System.Nullable$$($.$$.System.Int32)));
                        __builder.CloseElement();
                        __builder.AddContent$2(7, " items");
                    }
                    __builder.CloseElement();
                    __builder.AddMarkupContent(8, "\r\n        ");
                    __builder.OpenElement(9, "nav");
                    __builder.AddAttribute$3(10, "role", "navigation");
                    __builder.OpenElement(11, "button");
                    __builder.AddAttribute$3(12, "class", "go-first");
                    __builder.AddAttribute$3(13, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 14, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoFirstAsync)));
                    __builder.AddAttribute(15, "disabled", !this.CanGoBack);
                    __builder.AddAttribute$3(16, "title", "Go to first page");
                    __builder.AddAttribute$3(17, "aria-label", "Go to first page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(18, "\r\n            ");
                    __builder.OpenElement(19, "button");
                    __builder.AddAttribute$3(20, "class", "go-previous");
                    __builder.AddAttribute$3(21, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 22, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoPreviousAsync)));
                    __builder.AddAttribute(23, "disabled", !this.CanGoBack);
                    __builder.AddAttribute$3(24, "title", "Go to previous page");
                    __builder.AddAttribute$3(25, "aria-label", "Go to previous page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(26, "\r\n            ");
                    __builder.OpenElement(27, "div");
                    __builder.AddAttribute$3(28, "class", "pagination-text");
                    __builder.AddMarkupContent(29, "\r\n                Page ");
                    __builder.OpenElement(30, "strong");
                    __builder.AddContent$1(31, $.$box(((this.State.CurrentPageIndex + 1) | 0), $.$$.System.Int32));
                    __builder.CloseElement();
                    __builder.AddMarkupContent(32, "\r\n                of ");
                    __builder.OpenElement(33, "strong");
                    __builder.AddContent$1(34, $.$box($.$$.System.Int32.op_Addition$1(this.State.LastPageIndex, 1), $.$$.System.Int32));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(35, "\r\n            ");
                    __builder.OpenElement(36, "button");
                    __builder.AddAttribute$3(37, "class", "go-next");
                    __builder.AddAttribute$3(38, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 39, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoNextAsync)));
                    __builder.AddAttribute(40, "disabled", !this.CanGoForwards);
                    __builder.AddAttribute$3(41, "title", "Go to next page");
                    __builder.AddAttribute$3(42, "aria-label", "Go to next page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(43, "\r\n            ");
                    __builder.OpenElement(44, "button");
                    __builder.AddAttribute$3(45, "class", "go-last");
                    __builder.AddAttribute$3(46, "type", "button");
                    __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 47, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.GoLastAsync)));
                    __builder.AddAttribute(48, "disabled", !this.CanGoForwards);
                    __builder.AddAttribute$3(49, "title", "Go to last page");
                    __builder.AddAttribute$3(50, "aria-label", "Go to last page");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21476016239)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                this.State = null;
            }
            static $h = 1179759;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "p": [
//--TRIMMABLE-BOUNDARY-START(115965296751),
    {
      "p": 1114223,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130721903,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080394863,
        "f": 83886081
      },
      "n": "State",
      "d": 1179759,
      "h": 115965296751,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        },
        {
          "t": 1835116,
          "c": 4296802412
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965296751),
//--TRIMMABLE-BOUNDARY-START(120260264047),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720656495,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670329455,
        "f": 83886081
      },
      "n": "SummaryTemplate",
      "d": 1179759,
      "h": 120260264047,
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260264047),
//--TRIMMABLE-BOUNDARY-START(25770983535),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950852719,
        "f": 50331650
      },
      "n": "CanGoBack",
      "d": 1179759,
      "h": 25770983535,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25770983535),
//--TRIMMABLE-BOUNDARY-START(30065950831),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540787311,
        "f": 50331650
      },
      "n": "CanGoForwards",
      "d": 1179759,
      "h": 30065950831,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30065950831)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015623791),
    {
      "r": 177668097,
      "n": "GoFirstAsync",
      "d": 1179759,
      "h": 73015623791,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015623791),
//--TRIMMABLE-BOUNDARY-START(85900525679),
    {
      "r": 177668097,
      "n": "GoPreviousAsync",
      "d": 1179759,
      "h": 85900525679,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900525679),
//--TRIMMABLE-BOUNDARY-START(81605558383),
    {
      "r": 177668097,
      "n": "GoNextAsync",
      "d": 1179759,
      "h": 81605558383,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605558383),
//--TRIMMABLE-BOUNDARY-START(77310591087),
    {
      "r": 177668097,
      "n": "GoLastAsync",
      "d": 1179759,
      "h": 77310591087,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310591087),
//--TRIMMABLE-BOUNDARY-START(90195492975),
    {
      "r": 177668097,
      "p": [
        {
          "n": "pageIndex",
          "p": 655361
        }
      ],
      "n": "GoToPageAsync",
      "d": 1179759,
      "h": 90195492975,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195492975),
//--TRIMMABLE-BOUNDARY-START(94490460271),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 1179759,
      "h": 94490460271,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(94490460271),
//--TRIMMABLE-BOUNDARY-START(34360918127),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1179759,
      "h": 34360918127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918127),
//--TRIMMABLE-BOUNDARY-START(21476016239),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "BuildRenderTree",
      "d": 1179759,
      "h": 21476016239,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476016239)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147055),
    {
      "t": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,
      "n": "_totalItemCountChanged",
      "d": 1179759,
      "h": 4296147055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048943),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179759,
      "h": 17181048943,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048943)
  ],
  "i": [2752620,3145836,3080300,90308609
  ],
  "h": 1179759
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Paginator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179759)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310831)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid<>", [TGridItem], ($self) => class QuickGrid$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(171800002671)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800002671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.CascadingValue$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem)), 0);
                __builder.AddComponentParameter(1, "IsFixed", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Boolean, true), $.$$.System.Boolean));
                __builder.AddComponentParameter(2, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem), this._internalGridContext));
                __builder.AddAttribute$1(3, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    this.StartCollectingColumns();
                    __builder2.AddContent$4(4, this.ChildContent);
                    __builder2.AddMarkupContent(5, "\r\n    ");
                    __builder2.OpenComponent$1($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.Defer, 6);
                    __builder2.AddAttribute$1(7, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        this.FinishCollectingColumns();
                        __builder3.OpenComponent$1($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.ColumnsCollectedNotifier$$(TGridItem), 8);
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(9, "\r\n\r\n        ");
                        __builder3.OpenElement(10, "table");
                        __builder3.AddAttribute$3(11, "theme", this.Theme);
                        __builder3.AddAttribute$2(12, "aria-rowcount", $.$box(((this._ariaBodyRowCount + 1) | 0), $.$$.System.Int32));
                        __builder3.AddAttribute$7($.$$.System.EventArgs, 13, "onclosecolumnoptions", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$$.System.EventArgs, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.HideColumnOptionsAsync)));
                        __builder3.AddMultipleAttributes(14, $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), this.AdditionalAttributes));
                        __builder3.AddAttribute$3(15, "class", this.GridClass());
                        __builder3.AddElementReferenceCapture(16, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this._tableReference = __value;
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "__value",
      "p": 1900652
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                        __builder3.OpenElement(17, "thead");
                        __builder3.OpenElement(18, "tr");
                        __builder3.AddContent$4(19, this._renderColumnHeaders);
                        __builder3.CloseElement();
                        __builder3.CloseElement();
                        __builder3.AddMarkupContent(20, "\r\n            ");
                        __builder3.OpenElement(21, "tbody");
                        if (this.Virtualize)
                        {
                            __builder3.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)), 22);
                            __builder3.AddComponentParameter(23, "ItemSize", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Single, this.ItemSize), $.$$.System.Single));
                            __builder3.AddComponentParameter(24, "OverscanCount", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Int32, this.OverscanCount), $.$$.System.Int32));
                            __builder3.AddComponentParameter(25, "ItemsProvider", new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor(this, (this.ProvideVirtualizedItems)));
                            __builder3.AddComponentParameter(26, "ItemContent", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor(this, ( (/*item*/ item) =>
                            {
                                return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                                {
                                    return this.RenderRow(builder, item.Item1, item.Item2);
                                }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 7536748
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            })));
                            __builder3.AddComponentParameter(27, "Placeholder", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext))().$ctor(this, ( (/*placeholderContext*/ placeholderContext) =>
                            {
                                return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                                {
                                    return this.RenderPlaceholderRow(builder, placeholderContext);
                                }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 7536748
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            })));
                            __builder3.AddComponentReferenceCapture(28, new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this._virtualizeComponent = $.$cast(__value, $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)));
                            }, {
  "r": 65537,
  "p": [
    {
      "n": "__value",
      "p": 131073
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                            __builder3.CloseComponent();
                        }
                        else 
                        {
                            __builder3.AddContent$4(29, this._renderNonVirtualizedRows);
                        }
                        __builder3.CloseElement();
                        __builder3.CloseElement();
                    })));
                    __builder2.CloseComponent();
                })));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(171800002671)
            
            //--TRIMMABLE-BOUNDARY-START(386548367471)
            /*void */ RenderNonVirtualizedRows(/*RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548367471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let initialRowIndex = 2;
                /*var*/ let rowIndex = initialRowIndex;
                var $en2 = this._currentNonVirtualizedViewItems.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.RenderRow(__builder, rowIndex++, item);
                    }
                }
                if (!(this.Pagination === null))
                {
                    while(rowIndex++ < ((initialRowIndex + this.Pagination.ItemsPerPage) | 0))
                    {
                        __builder.OpenElement(30, "tr");
                        var $en4 = this._columns.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var col = $en4.Current;
                            {
                                __builder.OpenElement(31, "td");
                                __builder.AddAttribute$3(32, "class", $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(col));
                                __builder.SetKey(col);
                                __builder.CloseElement();
                            }
                        }
                        __builder.CloseElement();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(386548367471)
            
            //--TRIMMABLE-BOUNDARY-START(395138302063)
            /*void */ RenderRow(/*RenderTreeBuilder*/ __builder, /*int*/ rowIndex, /*TGridItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138302063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rowClass = (this.RowClass?.Invoke(item) ?? null);
                __builder.OpenElement(33, "tr");
                __builder.AddAttribute$2(34, "aria-rowindex", $.$box(rowIndex, $.$$.System.Int32));
                __builder.AddAttribute$3(35, "class", rowClass);
                __builder.SetKey(this.ItemKey.Invoke(item));
                var $en2 = this._columns.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var col = $en2.Current;
                    {
                        __builder.OpenElement(36, "td");
                        __builder.AddAttribute$3(37, "class", $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(col));
                        __builder.SetKey(col);
                        col.CellContent(__builder, item);
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(395138302063)
            
            //--TRIMMABLE-BOUNDARY-START(390843334767)
            /*void */ RenderPlaceholderRow(/*RenderTreeBuilder*/ __builder, /*PlaceholderContext*/ placeholderContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843334767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(38, "tr");
                __builder.AddAttribute$2(39, "aria-rowindex", $.$box(((placeholderContext.Index + 1) | 0), $.$$.System.Int32));
                var $en2 = this._columns.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var col = $en2.Current;
                    {
                        __builder.OpenElement(40, "td");
                        __builder.AddAttribute$3(41, "class", "grid-cell-placeholder" + " " + ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(col)));
                        __builder.SetKey(col);
                        col.RenderPlaceholderContent(__builder, placeholderContext);
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(390843334767)
            
            //--TRIMMABLE-BOUNDARY-START(382253400175)
            /*void */ RenderColumnHeaders(/*RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253400175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._columns.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var col = $en2.Current;
                    {
                        __builder.OpenElement(42, "th");
                        __builder.AddAttribute$3(43, "class", this.ColumnHeaderClass(col));
                        __builder.AddAttribute$3(44, "aria-sort", this.AriaSortValue(col));
                        __builder.AddAttribute$3(45, "scope", "col");
                        __builder.SetKey(col);
                        __builder.OpenElement(46, "div");
                        __builder.AddAttribute$3(47, "class", "col-header-content");
                        __builder.AddContent$4(48, col.HeaderContent);
                        __builder.CloseElement();
                        if (col === this._displayOptionsForColumn)
                        {
                            __builder.OpenElement(49, "div");
                            __builder.AddAttribute$3(50, "class", "col-options");
                            __builder.AddContent$4(51, col.ColumnOptions);
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(382253400175)
            
            //--TRIMMABLE-BOUNDARY-START(335008759919)
            /*IQueryable<TGridItem>?*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(335008759919)
            
            //--TRIMMABLE-BOUNDARY-START(343598694511)
            /*GridItemsProvider<TGridItem>?*/ ItemsProvider = null;
            //--TRIMMABLE-BOUNDARY-END(343598694511)
            
            //--TRIMMABLE-BOUNDARY-START(180389937263)
            /*string?*/ Class = null;
            //--TRIMMABLE-BOUNDARY-END(180389937263)
            
            //--TRIMMABLE-BOUNDARY-START(545462157423)
            /*string?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(545462157423)
            
            //--TRIMMABLE-BOUNDARY-START(176094969967)
            /*RenderFragment?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(176094969967)
            
            //--TRIMMABLE-BOUNDARY-START(549757124719)
            /*bool*/ Virtualize = false;
            //--TRIMMABLE-BOUNDARY-END(549757124719)
            
            //--TRIMMABLE-BOUNDARY-START(360778563695)
            /*int*/ OverscanCount = 0;
            //--TRIMMABLE-BOUNDARY-END(360778563695)
            
            //--TRIMMABLE-BOUNDARY-START(339303727215)
            /*float*/ ItemSize = 0;
            //--TRIMMABLE-BOUNDARY-END(339303727215)
            
            //--TRIMMABLE-BOUNDARY-START(330713792623)
            /*Func<TGridItem, object>*/ ItemKey = null;
            //--TRIMMABLE-BOUNDARY-END(330713792623)
            
            //--TRIMMABLE-BOUNDARY-START(365073530991)
            /*PaginationState?*/ Pagination = null;
            //--TRIMMABLE-BOUNDARY-END(365073530991)
            
            //--TRIMMABLE-BOUNDARY-START(163210068079)
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(163210068079)
            
            //--TRIMMABLE-BOUNDARY-START(403728236655)
            /*Func<TGridItem, string?>?*/ RowClass = null;
            //--TRIMMABLE-BOUNDARY-END(403728236655)
            
            //--TRIMMABLE-BOUNDARY-START(408023203951)
            /*IServiceProvider*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(408023203951)
            
            //--TRIMMABLE-BOUNDARY-START(347893661807)
            /*IJSRuntime*/ JS = null;
            //--TRIMMABLE-BOUNDARY-END(347893661807)
            
            //--TRIMMABLE-BOUNDARY-START(81605689455)
            /*ElementReference*/ _tableReference;
            //--TRIMMABLE-BOUNDARY-END(81605689455)
            
            //--TRIMMABLE-BOUNDARY-START(85900656751)
            /*Virtualize<(int, TGridItem)>?*/ _virtualizeComponent = null;
            //--TRIMMABLE-BOUNDARY-END(85900656751)
            
            //--TRIMMABLE-BOUNDARY-START(4296278127)
            /*int*/ _ariaBodyRowCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4296278127)
            
            //--TRIMMABLE-BOUNDARY-START(25771114607)
            /*ICollection<TGridItem>*/ _currentNonVirtualizedViewItems = null;
            //--TRIMMABLE-BOUNDARY-END(25771114607)
            
            //--TRIMMABLE-BOUNDARY-START(8591245423)
            /*IAsyncQueryExecutor?*/ _asyncQueryExecutor = null;
            //--TRIMMABLE-BOUNDARY-END(8591245423)
            
            //--TRIMMABLE-BOUNDARY-START(38656016495)
            /*InternalGridContext<TGridItem>*/ _internalGridContext = null;
            //--TRIMMABLE-BOUNDARY-END(38656016495)
            
            //--TRIMMABLE-BOUNDARY-START(21476147311)
            /*List<ColumnBase<TGridItem>>*/ _columns = null;
            //--TRIMMABLE-BOUNDARY-END(21476147311)
            
            //--TRIMMABLE-BOUNDARY-START(17181180015)
            /*bool*/ _collectingColumns = false;
            //--TRIMMABLE-BOUNDARY-END(17181180015)
            
            //--TRIMMABLE-BOUNDARY-START(34361049199)
            /*ColumnBase<TGridItem>?*/ _displayOptionsForColumn = null;
            //--TRIMMABLE-BOUNDARY-END(34361049199)
            
            //--TRIMMABLE-BOUNDARY-START(77310722159)
            /*ColumnBase<TGridItem>?*/ _sortByColumn = null;
            //--TRIMMABLE-BOUNDARY-END(77310722159)
            
            //--TRIMMABLE-BOUNDARY-START(73015754863)
            /*bool*/ _sortByAscending = false;
            //--TRIMMABLE-BOUNDARY-END(73015754863)
            
            //--TRIMMABLE-BOUNDARY-START(12886212719)
            /*bool*/ _checkColumnOptionsPosition = false;
            //--TRIMMABLE-BOUNDARY-END(12886212719)
            
            //--TRIMMABLE-BOUNDARY-START(47245951087)
            /*IJSObjectReference?*/ _jsModule = null;
            //--TRIMMABLE-BOUNDARY-END(47245951087)
            
            //--TRIMMABLE-BOUNDARY-START(42950983791)
            /*IJSObjectReference?*/ _jsEventDisposable = null;
            //--TRIMMABLE-BOUNDARY-END(42950983791)
            
            //--TRIMMABLE-BOUNDARY-START(64425820271)
            /*RenderFragment*/ _renderColumnHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(64425820271)
            
            //--TRIMMABLE-BOUNDARY-START(68720787567)
            /*RenderFragment*/ _renderNonVirtualizedRows = null;
            //--TRIMMABLE-BOUNDARY-END(68720787567)
            
            //--TRIMMABLE-BOUNDARY-START(55835885679)
            /*int?*/ _lastRefreshedPaginationStateHash = null;
            //--TRIMMABLE-BOUNDARY-END(55835885679)
            
            //--TRIMMABLE-BOUNDARY-START(51540918383)
            /*object?*/ _lastAssignedItemsOrProvider = null;
            //--TRIMMABLE-BOUNDARY-END(51540918383)
            
            //--TRIMMABLE-BOUNDARY-START(60130852975)
            /*CancellationTokenSource?*/ _pendingDataLoadCancellationTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(60130852975)
            
            //--TRIMMABLE-BOUNDARY-START(30066081903)
            /*EventCallbackSubscriber<PaginationState>*/ _currentPageItemsChanged = null;
            //--TRIMMABLE-BOUNDARY-END(30066081903)
            
            //--TRIMMABLE-BOUNDARY-START(90195624047)
            /*bool*/ _wasDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(90195624047)
            
            //--TRIMMABLE-BOUNDARY-START(154620133487)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154620133487);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._columns = new ($.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)))().$ctor$1();
                    this._internalGridContext = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem))().$ctor$1(this);
                    this._currentPageItemsChanged = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState))().$ctor$1($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.RefreshDataCoreAsync)));
                    this._renderColumnHeaders = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderColumnHeaders);
                    this._renderNonVirtualizedRows = new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderNonVirtualizedRows);
                    /*var*/ let columnsFirstCollectedSubscriber = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$$.System.Object))().$ctor$1($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$$.System.Object, this, new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.RefreshDataCoreAsync)));
                    columnsFirstCollectedSubscriber.SubscribeOrMove(this._internalGridContext.ColumnsFirstCollected);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(154620133487)
            
            //--TRIMMABLE-BOUNDARY-START(356483596399)
            /*Task */ OnParametersSetAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483596399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._currentPageItemsChanged.SubscribeOrMove((this.Pagination?.CurrentPageItemsChanged ?? null));
                if (!(this.Items === null) && !(this.ItemsProvider === null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"QuickGrid"} requires one of ${"Items"} or ${"ItemsProvider"}, but both were specified.`);
                }
                /*var*/ let _newItemsOrItemsProvider = this.Items ?? $.$cast(this.ItemsProvider, $.$$.System.Object);
                /*var*/ let dataSourceHasChanged = _newItemsOrItemsProvider !== this._lastAssignedItemsOrProvider;
                if (dataSourceHasChanged)
                {
                    this._lastAssignedItemsOrProvider = _newItemsOrItemsProvider;
                    this._asyncQueryExecutor = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier.GetAsyncQueryExecutor(TGridItem, this.Services, this.Items);
                }
                const $t1 = this.Pagination;
                /*var*/ let mustRefreshData = dataSourceHasChanged || ($.$ifnn($t1, ($t) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.call($t)) !== this._lastRefreshedPaginationStateHash);
                return (this._columns.Count > 0 && mustRefreshData) ? this.RefreshDataCoreAsync() : $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(356483596399)
            
            //--TRIMMABLE-BOUNDARY-START(352188629103)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(352188629103);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender)
                    {
                        this._jsModule = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, this.JS, "import", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "./_content/Microsoft.AspNetCore.Components.QuickGrid/QuickGrid.razor.js" ], null, null));
                        if (this._wasDisposed)
                        {
                            await this._jsModule.System$IAsyncDisposable$DisposeAsync();
                            return;
                        }
                        this._jsEventDisposable = await $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, this._jsModule, "init", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._tableReference ], null, null));
                    }
                    if (this._checkColumnOptionsPosition && !(this._displayOptionsForColumn === null))
                    {
                        this._checkColumnOptionsPosition = false;
                        /*Microsoft.JSInterop.IJSObjectReference?*/ let __ca1__;
                        _ = ((__ca1__ = this._jsModule) !== null ? $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeVoidAsync(__ca1__, "checkColumnOptionsPosition", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._tableReference ], null, null)).AsTask() : null);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(352188629103)
            
            //--TRIMMABLE-BOUNDARY-START(158915100783)
            /*void */ AddColumn(/*ColumnBase<TGridItem>*/ column, /*SortDirection?*/ initialSortDirection, /*bool*/ isDefaultSortColumn)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._collectingColumns)
                {
                    this._columns.Add(column);
                    if (isDefaultSortColumn && this._sortByColumn === null && $.$$.System.Nullable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection).HasValue$get.call(initialSortDirection))
                    {
                        this._sortByColumn = column;
                        this._sortByAscending = $.$$.System.Nullable$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection).Value$get.call(initialSortDirection) !== 2/*SortDirection.Descending*/;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915100783)
            
            //--TRIMMABLE-BOUNDARY-START(541167190127)
            /*void */ StartCollectingColumns()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167190127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._columns.Clear();
                this._collectingColumns = true;
            }
            //--TRIMMABLE-BOUNDARY-END(541167190127)
            
            //--TRIMMABLE-BOUNDARY-START(197569806447)
            /*void */ FinishCollectingColumns()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569806447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._collectingColumns = false;
            }
            //--TRIMMABLE-BOUNDARY-END(197569806447)
            
            //--TRIMMABLE-BOUNDARY-START(536872222831)
            /*Task */ SortByColumnAsync(/*ColumnBase<TGridItem>*/ column, /*SortDirection*/ direction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872222831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sortByAscending = (() =>
                {
                    if (direction === 1/*SortDirection.Ascending*/)
                    {
                        return true;
                    }
                    if (direction === 2/*SortDirection.Descending*/)
                    {
                        return false;
                    }
                    if (direction === 0/*SortDirection.Auto*/)
                    {
                        return this._sortByColumn !== column || !this._sortByAscending;
                    }
                    throw new $.$$.System.NotSupportedException().$ctor$12(`Unknown sort direction ${direction}`);
                })();
                this._sortByColumn = column;
                this.StateHasChanged();
                return this.RefreshDataAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(536872222831)
            
            //--TRIMMABLE-BOUNDARY-START(532577255535)
            /*Task */ ShowColumnOptionsAsync(/*ColumnBase<TGridItem>*/ column)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532577255535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._displayOptionsForColumn = column;
                this._checkColumnOptionsPosition = true;
                this.StateHasChanged();
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(532577255535)
            
            //--TRIMMABLE-BOUNDARY-START(326418825327)
            /*Task */ HideColumnOptionsAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418825327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._displayOptionsForColumn = null;
                this.StateHasChanged();
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(326418825327)
            
            //--TRIMMABLE-BOUNDARY-START(373663465583)
            /*Task *//*async*/  RefreshDataAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(373663465583);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await this.RefreshDataCoreAsync();
                    this.StateHasChanged();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(373663465583)
            
            //--TRIMMABLE-BOUNDARY-START(377958432879)
            /*Task *//*async*/  RefreshDataCoreAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(377958432879);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._pendingDataLoadCancellationTokenSource?.Cancel();
                    /*var*/ let thisLoadCts = this._pendingDataLoadCancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    if (!(this._virtualizeComponent === null))
                    {
                        await this._virtualizeComponent.RefreshDataAsync();
                        this._pendingDataLoadCancellationTokenSource = null;
                    }
                    else 
                    {
                        const $t1 = this.Pagination;
                        this._lastRefreshedPaginationStateHash = $.$ifnn($t1, ($t) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.call($t));
                        /*var*/ let startIndex = this.Pagination === null ? 0 : (((this.Pagination.CurrentPageIndex * this.Pagination.ItemsPerPage) | 0));
                        /*var*/ let request = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem))().$ctor$3(startIndex, (this.Pagination?.ItemsPerPage ?? null), this._sortByColumn, this._sortByAscending, thisLoadCts.Token);
                        /*var*/ let result = await this.ResolveItemsRequestAsync(request);
                        if (!thisLoadCts.IsCancellationRequested)
                        {
                            this._currentNonVirtualizedViewItems = result.Items;
                            this._ariaBodyRowCount = this._currentNonVirtualizedViewItems.System$Collections$Generic$ICollection$$$Count;
                            this.Pagination?.SetTotalItemCountAsync(result.TotalItemCount);
                            this._pendingDataLoadCancellationTokenSource = null;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(377958432879)
            
            //--TRIMMABLE-BOUNDARY-START(369368498287)
            /*ValueTask<ItemsProviderResult<(int, TGridItem)>> *//*async*/  ProvideVirtualizedItems(/*ItemsProviderRequest*/ request)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem))), $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(369368498287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    const $t1 = this.Pagination;
                    this._lastRefreshedPaginationStateHash = $.$ifnn($t1, ($t) => $.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState.GetHashCode.call($t));
                    await $.$$.System.Threading.Tasks.Task.Delay$1(100);
                    if (request.CancellationToken.IsCancellationRequested)
                    {
                        return new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))();
                    }
                    /*var*/ let startIndex = request.StartIndex;
                    /*var*/ let count = request.Count;
                    if (!(this.Pagination === null))
                    {
                        startIndex += ((this.Pagination.CurrentPageIndex * this.Pagination.ItemsPerPage) | 0);
                        count = $.$$.System.Math.Min$4(request.Count, ((this.Pagination.ItemsPerPage - request.StartIndex) | 0));
                    }
                    /*var*/ let providerRequest = new ($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem))().$ctor$3(startIndex, count, this._sortByColumn, this._sortByAscending, request.CancellationToken);
                    /*var*/ let providerResult = await this.ResolveItemsRequestAsync(providerRequest);
                    if (!request.CancellationToken.IsCancellationRequested)
                    {
                        this._ariaBodyRowCount = this.Pagination === null ? providerResult.TotalItemCount : this.Pagination.ItemsPerPage;
                        this.Pagination?.SetTotalItemCountAsync(providerResult.TotalItemCount);
                        return new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor$3($.$sl.System.Linq.Enumerable.Select(TGridItem, $.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem), providerResult.Items, new ($.$$.System.Func$$$$(TGridItem, $.$$.System.Int32, $.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))().$ctor(this,  (/*x*/ x, /*i*/ i) =>
                        {
                            return $.$$.System.ValueTuple.Create$7($.$$.System.Int32, TGridItem, ((((i + request.StartIndex) | 0) + 2) | 0), x);
                        }, {
  "r": $.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem).$h,
  "p": [
    {
      "n": "x",
      "p": TGridItem?.$h??1507328
    },
    {
      "n": "i",
      "p": 655361
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
})), this._ariaBodyRowCount);
                    }
                    return new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)))();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(369368498287)
            
            //--TRIMMABLE-BOUNDARY-START(399433269359)
            /*ValueTask<GridItemsProviderResult<TGridItem>> *//*async*/  ResolveItemsRequestAsync(/*GridItemsProviderRequest<TGridItem>*/ request)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)), $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(399433269359);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!(this.ItemsProvider === null))
                    {
                        return await this.ItemsProvider.Invoke(request);
                    }
                    else if (!(this.Items === null))
                    {
                        /*var*/ let totalItemCount = this._asyncQueryExecutor === null ? $.$slq.System.Linq.Queryable.Count$1(TGridItem, this.Items) : await this._asyncQueryExecutor.Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$CountAsync(TGridItem, this.Items);
                        /*var*/ let result = $.$slq.System.Linq.Queryable.Skip(TGridItem, request.ApplySorting(this.Items), request.StartIndex);
                        if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(request.Count))
                        {
                            result = $.$slq.System.Linq.Queryable.Take(TGridItem, result, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(request.Count));
                        }
                        /*var*/ let resultArray = this._asyncQueryExecutor === null ? $.$sl.System.Linq.Enumerable.ToArray(TGridItem, result) : await this._asyncQueryExecutor.Microsoft$AspNetCore$Components$QuickGrid$IAsyncQueryExecutor$ToArrayAsync(TGridItem, result);
                        return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult.From(TGridItem, resultArray, totalItemCount);
                    }
                    else 
                    {
                        return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult.From(TGridItem, $.$$.System.Array.Empty(TGridItem), 0);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(399433269359)
            
            //--TRIMMABLE-BOUNDARY-START(167505035375)
            /*string */ AriaSortValue(/*ColumnBase<TGridItem>*/ column)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167505035375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._sortByColumn === column ? (this._sortByAscending ? "ascending" : "descending") : "none";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505035375)
            
            //--TRIMMABLE-BOUNDARY-START(188979871855)
            /*string? */ ColumnHeaderClass(/*ColumnBase<TGridItem>*/ column)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979871855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._sortByColumn === column ? `${$.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(column)} ${(this._sortByAscending ? "col-sort-asc" : "col-sort-desc")}` : $.$macq.Microsoft.AspNetCore.Components.QuickGrid.QuickGrid$$(TGridItem).ColumnClass(column);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979871855)
            
            //--TRIMMABLE-BOUNDARY-START(322123858031)
            /*string */ GridClass()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123858031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let gridClass = `quickgrid ${this.Class} ${(this._pendingDataLoadCancellationTokenSource === null ? null : "loading")}`;
                return $.$macq.Microsoft.AspNetCore.Components.Forms.AttributeUtilities.CombineClassNames(this.AdditionalAttributes, gridClass) ?? $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(322123858031)
            
            //--TRIMMABLE-BOUNDARY-START(184684904559)
            static /*string? */ ColumnClass(/*ColumnBase<TGridItem>*/ column)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684904559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        let $switch1 = column.Align;
                        if ($switch1 === 0/*Align.Start*/)
                        {
                            return `col-justify-start ${column.Class}`;
                        }
                        if ($switch1 === 1/*Align.Center*/)
                        {
                            return `col-justify-center ${column.Class}`;
                        }
                        if ($switch1 === 2/*Align.End*/)
                        {
                            return `col-justify-end ${column.Class}`;
                        }
                        if ($switch1 === 3/*Align.Left*/)
                        {
                            return `col-justify-left ${column.Class}`;
                        }
                        if ($switch1 === 4/*Align.Right*/)
                        {
                            return `col-justify-right ${column.Class}`;
                        }
                        return column.Class;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684904559)
            
            //--TRIMMABLE-BOUNDARY-START(193274839151)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274839151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._wasDisposed = true;
                    this._currentPageItemsChanged.Dispose();
                    try
                    {
                        if (!(this._jsEventDisposable === null))
                        {
                            await $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeVoidAsync(this._jsEventDisposable, "stop", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            await this._jsEventDisposable.System$IAsyncDisposable$DisposeAsync();
                        }
                        if (!(this._jsModule === null))
                        {
                            await this._jsModule.System$IAsyncDisposable$DisposeAsync();
                        }
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(193274839151)
            
            //--TRIMMABLE-BOUNDARY-START(4384686081)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384686081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384686081)
            
            //default member initializer
            constructor()
            {
                super();
                this.Theme = "default";
                this.OverscanCount = 3;
                this.ItemSize = 50;
                this.ItemKey = new ($.$$.System.Func$$$(TGridItem, $.$$.System.Object))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$box(x, TGridItem);
                }, {
  "r": 131073,
  "p": [
    {
      "n": "x",
      "p": TGridItem?.$h??1507328
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                this.Services = null;
                this.JS = null;
                //--TRIMMABLE-BOUNDARY-START(81605689455)
                this._tableReference = $.$default($.$mac.Microsoft.AspNetCore.Components.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(81605689455)
                
                //--TRIMMABLE-BOUNDARY-START(25771114607)
                this._currentNonVirtualizedViewItems = $.$$.System.Array.Empty(TGridItem);
                //--TRIMMABLE-BOUNDARY-END(25771114607)
                
            }
            static $h = 1310831;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "p": [
//--TRIMMABLE-BOUNDARY-START(335008759919),
    {
      "p": $.$sle.System.Linq.IQueryable$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6900000000n),
        "f": 83886081
      },
      "n": "Items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335008759919),
//--TRIMMABLE-BOUNDARY-START(343598694511),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProvider$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6D00000000n),
        "f": 83886081
      },
      "n": "ItemsProvider",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(343598694511),
//--TRIMMABLE-BOUNDARY-START(180389937263),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6500000000n),
        "f": 83886081
      },
      "n": "Class",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2A00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389937263),
//--TRIMMABLE-BOUNDARY-START(545462157423),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x7900000000n),
        "f": 83886081
      },
      "n": "Theme",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(545462157423),
//--TRIMMABLE-BOUNDARY-START(176094969967),
    {
      "p": 6881388,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6300000000n),
        "f": 83886081
      },
      "n": "ChildContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094969967),
//--TRIMMABLE-BOUNDARY-START(549757124719),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x7B00000000n),
        "f": 83886081
      },
      "n": "Virtualize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x8000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(549757124719),
//--TRIMMABLE-BOUNDARY-START(360778563695),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x7100000000n),
        "f": 83886081
      },
      "n": "OverscanCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(360778563695),
//--TRIMMABLE-BOUNDARY-START(339303727215),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6B00000000n),
        "f": 83886081
      },
      "n": "ItemSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339303727215),
//--TRIMMABLE-BOUNDARY-START(330713792623),
    {
      "p": $.$$.System.Func$$$(TGridItem, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6700000000n),
        "f": 83886081
      },
      "n": "ItemKey",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4D00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330713792623),
//--TRIMMABLE-BOUNDARY-START(365073530991),
    {
      "p": 1114223,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x7300000000n),
        "f": 83886081
      },
      "n": "Pagination",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(365073530991),
//--TRIMMABLE-BOUNDARY-START(163210068079),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6100000000n),
        "f": 83886081
      },
      "n": "AdditionalAttributes",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796,
          "n": [
            {
              "n": "CaptureUnmatchedValues",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210068079),
//--TRIMMABLE-BOUNDARY-START(403728236655),
    {
      "p": $.$$.System.Func$$$(TGridItem, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x7500000000n),
        "f": 83886081
      },
      "n": "RowClass",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403728236655),
//--TRIMMABLE-BOUNDARY-START(408023203951),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x4600000000n),
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x7700000000n),
        "f": 83886082
      },
      "n": "Services",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5F00000000n),
      "f": 2097154,
      "a": [
        {
          "t": 4259948,
          "c": 8594194540
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(408023203951),
//--TRIMMABLE-BOUNDARY-START(347893661807),
    {
      "p": 524395,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3E00000000n),
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x6F00000000n),
        "f": 83886082
      },
      "n": "JS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 2097154,
      "a": [
        {
          "t": 4259948,
          "c": 8594194540
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347893661807)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171800002671),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(171800002671),
//--TRIMMABLE-BOUNDARY-START(386548367471),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "RenderNonVirtualizedRows",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(386548367471),
//--TRIMMABLE-BOUNDARY-START(395138302063),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        },
        {
          "n": "rowIndex",
          "p": 655361
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1507328
        }
      ],
      "n": "RenderRow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(395138302063),
//--TRIMMABLE-BOUNDARY-START(390843334767),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        },
        {
          "n": "placeholderContext",
          "p": 7733358
        }
      ],
      "n": "RenderPlaceholderRow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5B00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390843334767),
//--TRIMMABLE-BOUNDARY-START(382253400175),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "RenderColumnHeaders",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(382253400175),
//--TRIMMABLE-BOUNDARY-START(356483596399),
    {
      "r": 177668097,
      "n": "OnParametersSetAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(356483596399),
//--TRIMMABLE-BOUNDARY-START(352188629103),
    {
      "r": 177668097,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5200000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(352188629103),
//--TRIMMABLE-BOUNDARY-START(158915100783),
    {
      "r": 65537,
      "p": [
        {
          "n": "column",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h
        },
        {
          "n": "initialSortDirection",
          "p": $.$typeNullable($.$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection).$h
        },
        {
          "n": "isDefaultSortColumn",
          "p": 262145
        }
      ],
      "n": "AddColumn",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158915100783),
//--TRIMMABLE-BOUNDARY-START(541167190127),
    {
      "r": 65537,
      "n": "StartCollectingColumns",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(541167190127),
//--TRIMMABLE-BOUNDARY-START(197569806447),
    {
      "r": 65537,
      "n": "FinishCollectingColumns",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197569806447),
//--TRIMMABLE-BOUNDARY-START(536872222831),
    {
      "r": 177668097,
      "p": [
        {
          "n": "column",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h
        },
        {
          "n": "direction",
          "p": 1376367,
          "f": 65,
          "v": 0
        }
      ],
      "n": "SortByColumnAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(536872222831),
//--TRIMMABLE-BOUNDARY-START(532577255535),
    {
      "r": 177668097,
      "p": [
        {
          "n": "column",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "ShowColumnOptionsAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x7C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(532577255535),
//--TRIMMABLE-BOUNDARY-START(326418825327),
    {
      "r": 177668097,
      "n": "HideColumnOptionsAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326418825327),
//--TRIMMABLE-BOUNDARY-START(373663465583),
    {
      "r": 177668097,
      "n": "RefreshDataAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5700000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(373663465583),
//--TRIMMABLE-BOUNDARY-START(377958432879),
    {
      "r": 177668097,
      "n": "RefreshDataCoreAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5800000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(377958432879),
//--TRIMMABLE-BOUNDARY-START(369368498287),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem))).$h,
      "p": [
        {
          "n": "request",
          "p": 7536750
        }
      ],
      "n": "ProvideVirtualizedItems",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5600000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(369368498287),
//--TRIMMABLE-BOUNDARY-START(399433269359),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)).$h,
      "p": [
        {
          "n": "request",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem).$h
        }
      ],
      "n": "ResolveItemsRequestAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5D00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(399433269359),
//--TRIMMABLE-BOUNDARY-START(167505035375),
    {
      "r": 1310721,
      "p": [
        {
          "n": "column",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "AriaSortValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167505035375),
//--TRIMMABLE-BOUNDARY-START(188979871855),
    {
      "r": 1310721,
      "p": [
        {
          "n": "column",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "ColumnHeaderClass",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188979871855),
//--TRIMMABLE-BOUNDARY-START(322123858031),
    {
      "r": 1310721,
      "n": "GridClass",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4B00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(322123858031),
//--TRIMMABLE-BOUNDARY-START(184684904559),
    {
      "r": 1310721,
      "p": [
        {
          "n": "column",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "ColumnClass",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(184684904559),
//--TRIMMABLE-BOUNDARY-START(193274839151),
    {
      "r": 180551681,
      "n": "DisposeAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(193274839151)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81605689455),
    {
      "t": 1900652,
      "n": "_tableReference",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81605689455),
//--TRIMMABLE-BOUNDARY-START(85900656751),
    {
      "t": $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TGridItem)).$h,
      "n": "_virtualizeComponent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85900656751),
//--TRIMMABLE-BOUNDARY-START(4296278127),
    {
      "t": 655361,
      "n": "_ariaBodyRowCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278127),
//--TRIMMABLE-BOUNDARY-START(25771114607),
    {
      "t": $.$$.System.Collections.Generic.ICollection$$(TGridItem).$h,
      "n": "_currentNonVirtualizedViewItems",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771114607),
//--TRIMMABLE-BOUNDARY-START(8591245423),
    {
      "t": 589935,
      "n": "_asyncQueryExecutor",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245423),
//--TRIMMABLE-BOUNDARY-START(38656016495),
    {
      "t": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext$$(TGridItem).$h,
      "n": "_internalGridContext",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656016495),
//--TRIMMABLE-BOUNDARY-START(21476147311),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)).$h,
      "n": "_columns",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476147311),
//--TRIMMABLE-BOUNDARY-START(17181180015),
    {
      "t": 262145,
      "n": "_collectingColumns",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181180015),
//--TRIMMABLE-BOUNDARY-START(34361049199),
    {
      "t": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h,
      "n": "_displayOptionsForColumn",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361049199),
//--TRIMMABLE-BOUNDARY-START(77310722159),
    {
      "t": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem).$h,
      "n": "_sortByColumn",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310722159),
//--TRIMMABLE-BOUNDARY-START(73015754863),
    {
      "t": 262145,
      "n": "_sortByAscending",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015754863),
//--TRIMMABLE-BOUNDARY-START(12886212719),
    {
      "t": 262145,
      "n": "_checkColumnOptionsPosition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886212719),
//--TRIMMABLE-BOUNDARY-START(47245951087),
    {
      "t": 458859,
      "n": "_jsModule",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245951087),
//--TRIMMABLE-BOUNDARY-START(42950983791),
    {
      "t": 458859,
      "n": "_jsEventDisposable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950983791),
//--TRIMMABLE-BOUNDARY-START(64425820271),
    {
      "t": 6881388,
      "n": "_renderColumnHeaders",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425820271),
//--TRIMMABLE-BOUNDARY-START(68720787567),
    {
      "t": 6881388,
      "n": "_renderNonVirtualizedRows",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720787567),
//--TRIMMABLE-BOUNDARY-START(55835885679),
    {
      "t": $.$typeNullable($.$$.System.Int32).$h,
      "n": "_lastRefreshedPaginationStateHash",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835885679),
//--TRIMMABLE-BOUNDARY-START(51540918383),
    {
      "t": 131073,
      "n": "_lastAssignedItemsOrProvider",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540918383),
//--TRIMMABLE-BOUNDARY-START(60130852975),
    {
      "t": 170196993,
      "n": "_pendingDataLoadCancellationTokenSource",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130852975),
//--TRIMMABLE-BOUNDARY-START(30066081903),
    {
      "t": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.PaginationState).$h,
      "n": "_currentPageItemsChanged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066081903),
//--TRIMMABLE-BOUNDARY-START(90195624047),
    {
      "t": 262145,
      "n": "_wasDisposed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90195624047)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(154620133487),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154620133487)
  ],
  "i": [2752620,3145836,3080300,89718785
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 786540,
      "c": 8590721132,
      "a": [
        {
          "v": "TGridItem",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.QuickGrid.QuickGrid<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1310831)
        
        
        //--TRIMMABLE-BOUNDARY-START(262255)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProvider<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProvider<>", [TGridItem], ($self) => class GridItemsProvider$$ extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*ValueTask<GridItemsProviderResult<TGridItem>>*/ Invoke(/**/ request)
            {
                return this.$nativeFunction.call(this.$target, request);
            }
            static $h = 262255;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131439),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)).$h,
      "p": [
        {
          "n": "request",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem).$h
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180131439),
//--TRIMMABLE-BOUNDARY-START(8590196847),
    {
      "r": 89784321,
      "p": [
        {
          "n": "request",
          "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest$$(TGridItem).$h
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590196847),
//--TRIMMABLE-BOUNDARY-START(12885164143),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult$$(TGridItem)).$h,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885164143)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229551),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229551)
  ],
  "i": [89980929,157483009
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `GridItemsProvider<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262255)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507439)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn<>", (TGridItem) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn<>", [TGridItem], ($self) => class TemplateColumn$$ extends $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)
        {
            //--TRIMMABLE-BOUNDARY-START(30066278511)
            /*RenderFragment<TGridItem>*/ static EmptyChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(30066278511)
            
            //--TRIMMABLE-BOUNDARY-START(25771311215)
            /*RenderFragment<TGridItem>*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(25771311215)
            
            //--TRIMMABLE-BOUNDARY-START(73015951471)
            /*GridSort<TGridItem>?*/ SortBy = null;
            //--TRIMMABLE-BOUNDARY-END(73015951471)
            
            //--TRIMMABLE-BOUNDARY-START(21476343919)
            /*void */ CellContent(/*RenderTreeBuilder*/ builder, /*TGridItem*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return builder.AddContent$4(0, this.ChildContent.Invoke(item));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476343919)
            
            //--TRIMMABLE-BOUNDARY-START(51541114991)
            /*bool */ IsSortableByDefault()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541114991);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !(this.SortBy === null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541114991)
            
            //--TRIMMABLE-BOUNDARY-START(17181376623)
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376623)
            
            //default member initializer
            constructor()
            {
                super();
                this.ChildContent = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn$$(TGridItem).EmptyChildContent;
            }
            //--TRIMMABLE-BOUNDARY-START(12886409327)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(30066278511)
                    this.EmptyChildContent = new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TGridItem))().$ctor(this,  (/*_*/ _0) =>
                    {
                        return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                        {
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 7536748
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                    }, {
  "r": 6881388,
  "p": [
    {
      "n": "_",
      "p": TGridItem?.$h??1507328
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                    //--TRIMMABLE-BOUNDARY-END(30066278511)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409327)
            
            static $h = 1507439;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771311215),
    {
      "p": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83886081
      },
      "n": "ChildContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771311215),
//--TRIMMABLE-BOUNDARY-START(73015951471),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 83918849
      },
      "n": "SortBy",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2129921,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015951471)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476343919),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1507328
        }
      ],
      "n": "CellContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16810000
    },
//--TRIMMABLE-BOUNDARY-END(21476343919),
//--TRIMMABLE-BOUNDARY-START(51541114991),
    {
      "r": 262145,
      "n": "IsSortableByDefault",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51541114991)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066278511),
    {
      "t": $.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TGridItem).$h,
      "n": "EmptyChildContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30066278511)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181376623),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376623)
  ],
  "i": [2752620,3145836,3080300
  ],
  "g": [TGridItem?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `TemplateColumn<${TGridItem?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1507439)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245295)
        $asm.$cls("$macq.Microsoft.AspNetCore.Components.QuickGrid.PropertyColumn<,>", (TGridItem, TProp) => $asm.$gt("$macq.Microsoft.AspNetCore.Components.QuickGrid.PropertyColumn<,>", [TGridItem, TProp], ($self) => class PropertyColumn$$$ extends $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem)
        {
            //--TRIMMABLE-BOUNDARY-START(8591179887)
            /*Expression<Func<TGridItem, TProp>>?*/ _lastAssignedProperty = null;
            //--TRIMMABLE-BOUNDARY-END(8591179887)
            
            //--TRIMMABLE-BOUNDARY-START(4296212591)
            /*Func<TGridItem, string?>?*/ _cellTextFunc = null;
            //--TRIMMABLE-BOUNDARY-END(4296212591)
            
            //--TRIMMABLE-BOUNDARY-START(12886147183)
            /*GridSort<TGridItem>?*/ _sortBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(12886147183)
            
            //--TRIMMABLE-BOUNDARY-START(68720722031)
            /*Expression<Func<TGridItem, TProp>>*/ Property = null;
            //--TRIMMABLE-BOUNDARY-END(68720722031)
            
            //--TRIMMABLE-BOUNDARY-START(34360983663)
            /*string?*/ Format = null;
            //--TRIMMABLE-BOUNDARY-END(34360983663)
            
            //--TRIMMABLE-BOUNDARY-START(98785493103)
            /*GridSort<TGridItem>? */ get SortBy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._sortBuilder;
            }
            /*GridSort<TGridItem>? */ set SortBy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12(`PropertyColumn generates this member internally. For custom sorting rules, see '${$.$$.System.Type.ToString.call($.$macq.Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn$$(TGridItem).$type)}'.`);
            }
            //--TRIMMABLE-BOUNDARY-END(98785493103)
            
            //--TRIMMABLE-BOUNDARY-START(64425754735)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._lastAssignedProperty !== this.Property)
                {
                    this._lastAssignedProperty = this.Property;
                    /*var*/ let compiledPropertyExpression = this.Property.Compile$3();
                    if (!$.$$.System.String.IsNullOrEmpty(this.Format))
                    {
                        /*var*/ let nullableUnderlyingTypeOrNull = $.$$.System.Nullable.GetUnderlyingType(TProp.$type);
                        if (!$.$$.System.IFormattable.$type.IsAssignableFrom(nullableUnderlyingTypeOrNull ?? TProp.$type))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`A '${"Format"}' parameter was supplied, but the type '${$.$$.System.Type.ToString.call(TProp.$type)}' does not implement '${$.$$.System.Type.ToString.call($.$$.System.IFormattable.$type)}'.`);
                        }
                        this._cellTextFunc = new ($.$$.System.Func$$$(TGridItem, $.$$.System.String))().$ctor(this,  (/*item*/ item) =>
                        {
                            return (($.$box(compiledPropertyExpression.Invoke(item), TProp))?.System$IFormattable$ToString(this.Format, null) ?? null);
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "item",
      "p": TGridItem?.$h??1507328
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                    }
                    else 
                    {
                        this._cellTextFunc = new ($.$$.System.Func$$$(TGridItem, $.$$.System.String))().$ctor(this,  (/*item*/ item) =>
                        {
                            const $t1 = () => compiledPropertyExpression.Invoke(item);
                            return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "item",
      "p": TGridItem?.$h??1507328
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                    }
                    this._sortBuilder = $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).ByAscending(TProp, this.Property);
                }
                let memberExpression;
                if (this.Title === null && $.$is(this.Property.Body, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ memberExpression = v; } }))
                {
                    this.Title = memberExpression.Member.Name;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425754735)
            
            //--TRIMMABLE-BOUNDARY-START(30066016367)
            /*void */ CellContent(/*RenderTreeBuilder*/ builder, /*TGridItem*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066016367);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return builder.AddContent$2(0, this._cellTextFunc.Invoke(item));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066016367)
            
            //--TRIMMABLE-BOUNDARY-START(25771049071)
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771049071)
            
            //default member initializer
            constructor()
            {
                super();
                this.Property = null;
            }
            static $h = 1245295;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720722031),
    {
      "p": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, TProp)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 83886081
      },
      "n": "Property",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        },
        {
          "t": 1835116,
          "c": 4296802412
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720722031),
//--TRIMMABLE-BOUNDARY-START(34360983663),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 83886081
      },
      "n": "Format",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636204,
          "c": 8595570796
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360983663),
//--TRIMMABLE-BOUNDARY-START(98785493103),
    {
      "p": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83918849
      },
      "n": "SortBy",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98785493103)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425754735),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64425754735),
//--TRIMMABLE-BOUNDARY-START(30066016367),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536748
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1507328
        }
      ],
      "n": "CellContent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16810000
    },
//--TRIMMABLE-BOUNDARY-END(30066016367)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591179887),
    {
      "t": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TGridItem, TProp)).$h,
      "n": "_lastAssignedProperty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179887),
//--TRIMMABLE-BOUNDARY-START(4296212591),
    {
      "t": $.$$.System.Func$$$(TGridItem, $.$$.System.String).$h,
      "n": "_cellTextFunc",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212591),
//--TRIMMABLE-BOUNDARY-START(12886147183),
    {
      "t": $.$macq.Microsoft.AspNetCore.Components.QuickGrid.GridSort$$(TGridItem).$h,
      "n": "_sortBuilder",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771049071),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771049071)
  ],
  "i": [2752620,3145836,3080300
  ],
  "g": [TGridItem?.$h??1507328,TProp?.$h??1572864
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$macq.Microsoft.AspNetCore.Components.QuickGrid.ColumnBase$$(TGridItem); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `PropertyColumn<${TGridItem?.$fullName},${TProp?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1245295)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376367)
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.SortDirection", ($self) => class SortDirection extends $.$$.System.Enum
        {
            static Auto = 0;
            static Ascending = 1;
            static Descending = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Auto": 0n,
                    "Ascending": 1n,
                    "Descending": 2n
                };
            }
            static $h = 1376367;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886278255),
    {
      "t": 1376367,
      "n": "Auto",
      "d": 1376367,
      "h": 12886278255,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278255),
//--TRIMMABLE-BOUNDARY-START(8591310959),
    {
      "t": 1376367,
      "n": "Ascending",
      "d": 1376367,
      "h": 8591310959,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310959),
//--TRIMMABLE-BOUNDARY-START(17181245551),
    {
      "t": 1376367,
      "n": "Descending",
      "d": 1376367,
      "h": 17181245551,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245551)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343663),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376367,
      "h": 4296343663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343663)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1376367
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `SortDirection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376367)
        
        
        //--TRIMMABLE-BOUNDARY-START(131183)
        $asm.$str("$macq.Microsoft.AspNetCore.Components.QuickGrid.Align", ($self) => class Align extends $.$$.System.Enum
        {
            static Start = 0;
            static Center = 1;
            static End = 2;
            static Left = 3;
            static Right = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Start": 0n,
                    "Center": 1n,
                    "End": 2n,
                    "Left": 3n,
                    "Right": 4n
                };
            }
            static $h = 131183;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25769934959),
    {
      "t": 131183,
      "n": "Start",
      "d": 131183,
      "h": 25769934959,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769934959),
//--TRIMMABLE-BOUNDARY-START(8590065775),
    {
      "t": 131183,
      "n": "Center",
      "d": 131183,
      "h": 8590065775,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065775),
//--TRIMMABLE-BOUNDARY-START(12885033071),
    {
      "t": 131183,
      "n": "End",
      "d": 131183,
      "h": 12885033071,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033071),
//--TRIMMABLE-BOUNDARY-START(17180000367),
    {
      "t": 131183,
      "n": "Left",
      "d": 131183,
      "h": 17180000367,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180000367),
//--TRIMMABLE-BOUNDARY-START(21474967663),
    {
      "t": 131183,
      "n": "Right",
      "d": 131183,
      "h": 21474967663,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474967663)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098479),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131183,
      "h": 4295098479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098479)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 131183
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Align`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131183)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.System.Linq.Queryable"))
//--TRIMMABLE-BOUNDARY-END(111)
