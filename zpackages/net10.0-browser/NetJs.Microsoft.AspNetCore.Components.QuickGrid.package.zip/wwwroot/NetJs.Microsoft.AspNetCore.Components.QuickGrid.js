
//--TRIMMABLE-BOUNDARY-START(118)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $mecga, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mexla, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $slq) {
    "use strict";
    let _;
    let $rqTEpc;
    let $TZAUHg;
    let $JfWlOb;
    let $RiXMZg;
    let $XHMhhh;
    let $RTMCMj;
    let $BlDyBd;
    let $SKeuoc;
    let $asDvCb;
    let $kiCxDe;
    let $ujYydg;
    let $EhbxYc;
    let $opWepl;
    let $glqBrb;
    let $GCmeFe;
    let $MBFhvc;
    let $vJlLdk;
    let $cXiNPj;
    let $WAxBaf;
    let $NLRuBj;
    let $tXpMuf;
    let $nhNzSi;
    let $noLWaj;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.QuickGrid", 
    {
  "h": 118,
  "f": "Microsoft.AspNetCore.Components.QuickGrid",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Provides a simple and convenient data grid component for common grid rendering scenarios and serves as a reference architecture and performance baseline for building data grid components.\n      If you\u0027re using Entity Framework Core for your grid IQueryables, consider using the \u003Ca href=\u0022https://www.nuget.org/packages/Microsoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter\u0022\u003EMicrosoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter\u003C/a\u003E package.\n    ",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.QuickGrid",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.QuickGrid",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.QuickGrid.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(589942)
        $asm.$cls(`$macq.MACQ.IAsyncQueryExecutor`, ($self) => class IAsyncQueryExecutor
        {
            static $h = 589942;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590524534),
    {
      "r": 262145,
      "p": [
        {
          "n": "queryable",
          "p": (T) => $.$sle.SL.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "IsSupported",
      "o": "MACQ$IAsyncQueryExecutor$IsSupported",
      "d": 589942,
      "h": 8590524534,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590524534),
//--TRIMMABLE-BOUNDARY-START(4295557238),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "queryable",
          "p": (T) => $.$sle.SL.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CountAsync",
      "o": "MACQ$IAsyncQueryExecutor$CountAsync",
      "d": 589942,
      "h": 4295557238,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(4295557238),
//--TRIMMABLE-BOUNDARY-START(12885491830),
    {
      "r": (T) => $.$$.STT.Task$$($.$typeArray(T)).$h,
      "p": [
        {
          "n": "queryable",
          "p": (T) => $.$sle.SL.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToArrayAsync",
      "o": "MACQ$IAsyncQueryExecutor$ToArrayAsync",
      "d": 589942,
      "h": 12885491830,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(12885491830)
  ],
  "h": 589942
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.IAsyncQueryExecutor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}IAsyncQueryExecutor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589942)
        
        

        //--TRIMMABLE-BOUNDARY-START(196726)
        $asm.$cls(`$macq.MACQ.ColumnBase<>`, (TGridItem) => $asm.$gt(`$macq.MACQ.ColumnBase<>`, [TGridItem], ($self) => class ColumnBase$$ extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(206158626934)
            /*InternalGridContext<TGridItem>*/ InternalGridContext = null;
            //--TRIMMABLE-BOUNDARY-END(206158626934)
            
            //--TRIMMABLE-BOUNDARY-START(343597580406)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(343597580406)
            
            //--TRIMMABLE-BOUNDARY-START(68719673462)
            /*string?*/ Class = null;
            //--TRIMMABLE-BOUNDARY-END(68719673462)
            
            //--TRIMMABLE-BOUNDARY-START(55834771574)
            /*Align*/ Align = 0;
            //--TRIMMABLE-BOUNDARY-END(55834771574)
            
            //--TRIMMABLE-BOUNDARY-START(197568692342)
            /*RenderFragment<ColumnBase<TGridItem>>?*/ HeaderTemplate = null;
            //--TRIMMABLE-BOUNDARY-END(197568692342)
            
            //--TRIMMABLE-BOUNDARY-START(73014640758)
            /*RenderFragment?*/ ColumnOptions = null;
            //--TRIMMABLE-BOUNDARY-END(73014640758)
            
            //--TRIMMABLE-BOUNDARY-START(335007645814)
            /*bool?*/ Sortable = null;
            //--TRIMMABLE-BOUNDARY-END(335007645814)
            
            //--TRIMMABLE-BOUNDARY-START(201863659638)
            /*SortDirection*/ InitialSortDirection = 0;
            //--TRIMMABLE-BOUNDARY-END(201863659638)
            
            //--TRIMMABLE-BOUNDARY-START(210453594230)
            /*bool*/ IsDefaultSortColumn = false;
            //--TRIMMABLE-BOUNDARY-END(210453594230)
            
            //--TRIMMABLE-BOUNDARY-START(219043528822)
            /*RenderFragment<PlaceholderContext>?*/ PlaceholderTemplate = null;
            //--TRIMMABLE-BOUNDARY-END(219043528822)
            
            //--TRIMMABLE-BOUNDARY-START(188978757750)
            /*QuickGrid<TGridItem> */ get Grid()
            {
                return this.InternalGridContext.Grid;
            }
            //--TRIMMABLE-BOUNDARY-END(188978757750)
            
            //--TRIMMABLE-BOUNDARY-START(193273725046)
            /*RenderFragment*/ HeaderContent = null;
            //--TRIMMABLE-BOUNDARY-END(193273725046)
            
            //--TRIMMABLE-BOUNDARY-START(214748561526)
            /*bool */ IsSortableByDefault()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748561526);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748561526)
            
            //--TRIMMABLE-BOUNDARY-START(51539804278)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539804278);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.HeaderContent = new $.$mac.MAC.RenderFragment().$ctor(this, this.RenderDefaultHeaderContent);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804278)
            
            //--TRIMMABLE-BOUNDARY-START(60129738870)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InternalGridContext.Grid.AddColumn(this, this.InitialSortDirection, this.IsDefaultSortColumn);
            }
            //--TRIMMABLE-BOUNDARY-END(60129738870)
            
            //--TRIMMABLE-BOUNDARY-START(223338496118)
            /*void */ RenderDefaultHeaderContent(/*RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338496118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this.HeaderTemplate === null))
                {
                    __builder.AddContent$1(0, this.HeaderTemplate.Invoke(this));
                }
                else 
                {
                    if (!(this.ColumnOptions === null) && (this.Align !== 4/*Align.Right*/ && this.Align !== 2/*Align.End*/))
                    {
                        __builder.OpenElement(1, "button");
                        __builder.AddAttribute$5(2, "class", "col-options-button");
                        __builder.AddAttribute$5(3, "type", "button");
                        __builder.AddAttribute$5(4, "title", "Column options");
                        __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.ShowColumnOptionsAsync(this);
                        }, $RTMCMj ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                        __builder.CloseElement();
                    }
                    if ($.$$.S.Nullable$$($.$$.S.Boolean).HasValue$get.call(this.Sortable) ? $.$$.S.Nullable$$($.$$.S.Boolean).Value$get.call(this.Sortable) : this.IsSortableByDefault())
                    {
                        __builder.OpenElement(6, "button");
                        __builder.AddAttribute$5(7, "class", "col-title");
                        __builder.AddAttribute$5(8, "type", "button");
                        __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 9, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.SortByColumnAsync(this, 0);
                        }, $BlDyBd ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                        __builder.OpenElement(10, "div");
                        __builder.AddAttribute$5(11, "class", "col-title-text");
                        __builder.AddContent$4(12, this.Title);
                        __builder.CloseElement();
                        __builder.AddMarkupContent(13, "\r\n                    <div class=\"sort-indicator\" aria-hidden=\"true\"></div>");
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.OpenElement(14, "div");
                        __builder.AddAttribute$5(15, "class", "col-title");
                        __builder.OpenElement(16, "div");
                        __builder.AddAttribute$5(17, "class", "col-title-text");
                        __builder.AddContent$4(18, this.Title);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    if (!(this.ColumnOptions === null) && (this.Align === 4/*Align.Right*/ || this.Align === 2/*Align.End*/))
                    {
                        __builder.OpenElement(19, "button");
                        __builder.AddAttribute$5(20, "class", "col-options-button");
                        __builder.AddAttribute$5(21, "type", "button");
                        __builder.AddAttribute$5(22, "title", "Column options");
                        __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 23, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                        {
                            return this.Grid.ShowColumnOptionsAsync(this);
                        }, $SKeuoc ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                        __builder.CloseElement();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338496118)
            
            //--TRIMMABLE-BOUNDARY-START(227633463414)
            /*void */ RenderPlaceholderContent(/*RenderTreeBuilder*/ __builder, /*PlaceholderContext*/ placeholderContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633463414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this.PlaceholderTemplate === null))
                {
                    __builder.AddContent$1(24, this.PlaceholderTemplate.Invoke(placeholderContext));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633463414)
            
            //--TRIMMABLE-BOUNDARY-START(51539804278)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(51539804278)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(206158626934)
                this.InternalGridContext = null;
                //--TRIMMABLE-BOUNDARY-END(206158626934)
                
                //--TRIMMABLE-BOUNDARY-START(201863659638)
                this.InitialSortDirection = 0;
                //--TRIMMABLE-BOUNDARY-END(201863659638)
                
                //--TRIMMABLE-BOUNDARY-START(210453594230)
                this.IsDefaultSortColumn = false;
                //--TRIMMABLE-BOUNDARY-END(210453594230)
                
            }
            static $H = 196726;
            static $h = 196726;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(206158626934),
    {
      "p": $.$macq.MACQI.InternalGridContext$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 141734117494,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 287763005558,
        "h": Number(BigInt(this.$h)|0x4300000000n),
        "f": 83886088
      },
      "n": "InternalGridContext",
      "d": this.$h,
      "H": 206158626934,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 2097160,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206158626934),
//--TRIMMABLE-BOUNDARY-START(343597580406),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 184683790454,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 330712678518,
        "h": Number(BigInt(this.$h)|0x4D00000000n),
        "f": 83886081
      },
      "n": "Title",
      "d": this.$h,
      "H": 343597580406,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(343597580406),
//--TRIMMABLE-BOUNDARY-START(68719673462),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90194509942,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 244813332598,
        "h": Number(BigInt(this.$h)|0x3900000000n),
        "f": 83886081
      },
      "n": "Class",
      "d": this.$h,
      "H": 68719673462,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719673462),
//--TRIMMABLE-BOUNDARY-START(55834771574),
    {
      "p": 131190,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81604575350,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 236223398006,
        "h": Number(BigInt(this.$h)|0x3700000000n),
        "f": 83886081
      },
      "n": "Align",
      "d": this.$h,
      "H": 55834771574,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834771574),
//--TRIMMABLE-BOUNDARY-START(197568692342),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$macq.MACQ.ColumnBase$$(TGridItem)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124554248310,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 270583136374,
        "h": Number(BigInt(this.$h)|0x3F00000000n),
        "f": 83886081
      },
      "n": "HeaderTemplate",
      "d": this.$h,
      "H": 197568692342,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197568692342),
//--TRIMMABLE-BOUNDARY-START(73014640758),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98784444534,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 253403267190,
        "h": Number(BigInt(this.$h)|0x3B00000000n),
        "f": 83886081
      },
      "n": "ColumnOptions",
      "d": this.$h,
      "H": 73014640758,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014640758),
//--TRIMMABLE-BOUNDARY-START(335007645814),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 167503921270,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 313532809334,
        "h": Number(BigInt(this.$h)|0x4900000000n),
        "f": 83886081
      },
      "n": "Sortable",
      "d": this.$h,
      "H": 335007645814,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335007645814),
//--TRIMMABLE-BOUNDARY-START(339302613110),
    {
      "p": $.$macq.MACQ.GridSort$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 176093855862,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 322122743926,
        "h": Number(BigInt(this.$h)|0x4B00000000n),
        "f": 83886337
      },
      "n": "SortBy",
      "d": this.$h,
      "H": 339302613110,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(339302613110),
//--TRIMMABLE-BOUNDARY-START(201863659638),
    {
      "p": 1376374,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133144182902,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 279173070966,
        "h": Number(BigInt(this.$h)|0x4100000000n),
        "f": 83886081
      },
      "n": "InitialSortDirection",
      "d": this.$h,
      "H": 201863659638,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201863659638),
//--TRIMMABLE-BOUNDARY-START(210453594230),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 150324052086,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 296352940150,
        "h": Number(BigInt(this.$h)|0x4500000000n),
        "f": 83886081
      },
      "n": "IsDefaultSortColumn",
      "d": this.$h,
      "H": 210453594230,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210453594230),
//--TRIMMABLE-BOUNDARY-START(219043528822),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$macw.MACWV.PlaceholderContext).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 158913986678,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 304942874742,
        "h": Number(BigInt(this.$h)|0x4700000000n),
        "f": 83886081
      },
      "n": "PlaceholderTemplate",
      "d": this.$h,
      "H": 219043528822,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219043528822),
//--TRIMMABLE-BOUNDARY-START(188978757750),
    {
      "p": $.$macq.MACQ.QuickGrid$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107374379126,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "Grid",
      "d": this.$h,
      "H": 188978757750,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978757750),
//--TRIMMABLE-BOUNDARY-START(193273725046),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115964313718,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331664
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 261993201782,
        "h": Number(BigInt(this.$h)|0x3D00000000n),
        "f": 83886084
      },
      "n": "HeaderContent",
      "d": this.$h,
      "H": 193273725046,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(193273725046)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424706166),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1572864
        }
      ],
      "n": "CellContent",
      "d": this.$h,
      "H": 64424706166,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777488
    },
//--TRIMMABLE-BOUNDARY-END(64424706166),
//--TRIMMABLE-BOUNDARY-START(214748561526),
    {
      "r": 262145,
      "n": "IsSortableByDefault",
      "d": this.$h,
      "H": 214748561526,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(214748561526),
//--TRIMMABLE-BOUNDARY-START(60129738870),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 60129738870,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60129738870),
//--TRIMMABLE-BOUNDARY-START(223338496118),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "RenderDefaultHeaderContent",
      "d": this.$h,
      "H": 223338496118,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223338496118),
//--TRIMMABLE-BOUNDARY-START(227633463414),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "placeholderContext",
          "p": 7733365
        }
      ],
      "n": "RenderPlaceholderContent",
      "d": this.$h,
      "H": 227633463414,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(227633463414)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51539804278),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 51539804278,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539804278)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 196726,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.ColumnBase<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}ColumnBase$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196726)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048694)
        $asm.$cls(`$macq.MACQI.InternalGridContext<>`, (TGridItem) => $asm.$gt(`$macq.MACQI.InternalGridContext<>`, [TGridItem], ($self) => class InternalGridContext$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655754358)
            /*QuickGrid<TGridItem>*/ Grid = null;
            //--TRIMMABLE-BOUNDARY-END(38655754358)
            
            //--TRIMMABLE-BOUNDARY-START(17180917878)
            /*EventCallbackSubscribable<object?>*/ ColumnsFirstCollected = null;
            //--TRIMMABLE-BOUNDARY-END(17180917878)
            
            //--TRIMMABLE-BOUNDARY-START(12885950582)
            $ctor$1(/*QuickGrid<TGridItem>*/ grid)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885950582);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Grid = grid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950582)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180917878)
                this.ColumnsFirstCollected = new ($.$macq.MACQI.EventCallbackSubscribable$$($.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180917878)
                
            }
            static $H = 1048694;
            static $h = 1048694;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655754358),
    {
      "p": $.$macq.MACQ.QuickGrid$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360787062,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Grid",
      "d": this.$h,
      "H": 38655754358,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655754358),
//--TRIMMABLE-BOUNDARY-START(17180917878),
    {
      "p": $.$macq.MACQI.EventCallbackSubscribable$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770852470,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "ColumnsFirstCollected",
      "d": this.$h,
      "H": 17180917878,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180917878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950582),
    {
      "p": [
        {
          "n": "grid",
          "p": $.$macq.MACQ.QuickGrid$$(TGridItem).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12885950582,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885950582)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 1048694,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.InternalGridContext<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Infrastructure${separator}InternalGridContext$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1048694)
        
        

        //--TRIMMABLE-BOUNDARY-START(65654)
        $asm.$cls(`$macq.MACF.AttributeUtilities`, ($self) => class AttributeUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(4295032950)
            static /*string? */ CombineClassNames(/*IReadOnlyDictionary<string, object>?*/ additionalAttributes, /*string?*/ classNames)
            {
                /*var*/ let $class;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (additionalAttributes === null || !additionalAttributes.SCG$IReadOnlyDictionary$$$$TryGetValue("class", $.$ref(() => $class, ($v) => $class = $v, $.$$.S.Object)))
                {
                    return classNames;
                }
                /*var*/ let classAttributeValue = $.$$.S.Convert.ToString$23($class, $.$$.SG.CultureInfo.InvariantCulture);
                if ($.$$.S.String.IsNullOrEmpty(classAttributeValue))
                {
                    return classNames;
                }
                if ($.$$.S.String.IsNullOrEmpty(classNames))
                {
                    return classAttributeValue;
                }
                return `${$.$strNN(classAttributeValue)} ${$.$strNN(classNames)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032950)
            
            static $h = 65654;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032950),
    {
      "r": 1310721,
      "p": [
        {
          "n": "additionalAttributes",
          "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "classNames",
          "p": 1310721
        }
      ],
      "n": "CombineClassNames",
      "d": 65654,
      "h": 4295032950,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032950)
  ],
  "h": 65654
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.AttributeUtilities`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}AttributeUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65654)
        
        

        //--TRIMMABLE-BOUNDARY-START(983158)
        $asm.$cls(`$macq.MACQI.EventHandlers`, ($self) => class EventHandlers
        {
            static $h = 983158;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 983158,
  "a": [
    {
      "t": 2490483,
      "c": 21477326963,
      "a": [
        {
          "v": "onclosecolumnoptions",
          "t": 1310721
        },
        {
          "v": 80543745,
          "t": 188547073
        },
        {
          "v": true,
          "t": 262145
        },
        {
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventHandlers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Infrastructure${separator}EventHandlers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983158)
        
        

        //--TRIMMABLE-BOUNDARY-START(852086)
        $asm.$cls(`$macq.MACQI.EventCallbackSubscribable<>`, (T) => $asm.$gt(`$macq.MACQI.EventCallbackSubscribable<>`, [T], ($self) => class EventCallbackSubscribable$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295819382)
            /*Dictionary<EventCallbackSubscriber<T>, EventCallback<T>>*/ _callbacks = null;
            //--TRIMMABLE-BOUNDARY-END(4295819382)
            
            //--TRIMMABLE-BOUNDARY-START(12885753974)
            /*Task *//*async*/  InvokeCallbacksAsync(/*T*/ eventArg)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885753974);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = this._callbacks.Values.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let callback = $en1.Current;
                        {
                            let $t2, $r2;
                            ($t2 = callback.InvokeAsync$1(eventArg), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885753974)
            
            //--TRIMMABLE-BOUNDARY-START(17180721270)
            /*void */ Subscribe(/*EventCallbackSubscriber<T>*/ owner, /*EventCallback<T>*/ callback)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180721270);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._callbacks.Add(owner, callback);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180721270)
            
            //--TRIMMABLE-BOUNDARY-START(21475688566)
            /*void */ Unsubscribe(/*EventCallbackSubscriber<T>*/ owner)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475688566);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._callbacks.Remove$1(owner);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475688566)
            
            //--TRIMMABLE-BOUNDARY-START(8590786678)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786678)
            
            //--TRIMMABLE-BOUNDARY-START(8590786678)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590786678)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295819382)
                this._callbacks = new ($.$$.SCG.Dictionary$$$($.$macq.MACQI.EventCallbackSubscriber$$(T), $.$mac.MAC.EventCallback$$(T)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295819382)
                
            }
            static $H = 852086;
            static $h = 852086;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753974),
    {
      "r": 178454529,
      "p": [
        {
          "n": "eventArg",
          "p": T?.$h??1572864
        }
      ],
      "n": "InvokeCallbacksAsync",
      "d": this.$h,
      "H": 12885753974,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12885753974),
//--TRIMMABLE-BOUNDARY-START(17180721270),
    {
      "r": 65537,
      "p": [
        {
          "n": "owner",
          "p": $.$macq.MACQI.EventCallbackSubscriber$$(T).$h
        },
        {
          "n": "callback",
          "p": $.$mac.MAC.EventCallback$$(T).$h
        }
      ],
      "n": "Subscribe",
      "d": this.$h,
      "H": 17180721270,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721270),
//--TRIMMABLE-BOUNDARY-START(21475688566),
    {
      "r": 65537,
      "p": [
        {
          "n": "owner",
          "p": $.$macq.MACQI.EventCallbackSubscriber$$(T).$h
        }
      ],
      "n": "Unsubscribe",
      "d": this.$h,
      "H": 21475688566,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688566)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819382),
    {
      "t": $.$$.SCG.Dictionary$$$($.$macq.MACQI.EventCallbackSubscriber$$(T), $.$mac.MAC.EventCallback$$(T)).$h,
      "n": "_callbacks",
      "d": this.$h,
      "H": 4295819382,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819382)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786678),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590786678,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786678)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 852086,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscribable<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Infrastructure${separator}EventCallbackSubscribable$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(852086)
        
        

        //--TRIMMABLE-BOUNDARY-START(655478)
        $asm.$cls(`$macq.MACQI.AsyncQueryExecutorSupplier`, ($self) => class AsyncQueryExecutorSupplier
        {
            //--TRIMMABLE-BOUNDARY-START(17180524662)
            /*ConcurrentDictionary<Type, bool>*/ static IsEntityFrameworkProviderTypeCache = null;
            //--TRIMMABLE-BOUNDARY-END(17180524662)
            
            //--TRIMMABLE-BOUNDARY-START(8590590070)
            static /*IAsyncQueryExecutor? */ GetAsyncQueryExecutor(T, /*IServiceProvider*/ services, /*IQueryable<T>?*/ queryable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590590070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(queryable === null))
                {
                    /*var*/ let executor = $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$macq.MACQ.IAsyncQueryExecutor, services);
                    if (executor === null)
                    {
                        /*System.Linq.IQueryProvider*/ let __ca1__;
                        /*var*/ let providerType = ((__ca1__ = queryable.SL$IQueryable$Provider) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null);
                        if (!(providerType === null) && $.$macq.MACQI.AsyncQueryExecutorSupplier.IsEntityFrameworkProviderTypeCache.GetOrAdd(providerType, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor($.$macq.MACQI.AsyncQueryExecutorSupplier, $.$macq.MACQI.AsyncQueryExecutorSupplier.IsEntityFrameworkProviderType)))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`The supplied ${$.$strNN("IQueryable")} is provided by Entity Framework. To query it efficiently, you must reference the package Microsoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter and call AddQuickGridEntityFrameworkAdapter on your service collection.`);
                        }
                    }
                    else if (executor.MACQ$IAsyncQueryExecutor$IsSupported(T, queryable))
                    {
                        return executor;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590070)
            
            //--TRIMMABLE-BOUNDARY-START(12885557366)
            static /*bool */ IsEntityFrameworkProviderType(/*Type*/ queryableProviderType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557366);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Any($.$$.S.Type, queryableProviderType.GetInterfaces(), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/**/ x) =>
                    {
                        return $.$$.S.String.Equals$3(x.FullName, "Microsoft.EntityFrameworkCore.Query.IAsyncQueryProvider", 4/*StringComparison.Ordinal*/);
                    }, $JfWlOb ??= {"r":262145,"p":[{"n":"x","p":188547073}],"n":"","d":655478,"h":0,"f":17825794})) === true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885557366)
            
            //--TRIMMABLE-BOUNDARY-START(4295622774)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524662)
                    this.IsEntityFrameworkProviderTypeCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17180524662)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295622774)
            
            static $h = 655478;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590590070),
    {
      "r": 589942,
      "p": [
        {
          "n": "services",
          "p": 327718
        },
        {
          "n": "queryable",
          "p": (T) => $.$sle.SL.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetAsyncQueryExecutor",
      "d": 655478,
      "h": 8590590070,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590590070),
//--TRIMMABLE-BOUNDARY-START(12885557366),
    {
      "r": 262145,
      "p": [
        {
          "n": "queryableProviderType",
          "p": 188547073
        }
      ],
      "n": "IsEntityFrameworkProviderType",
      "d": 655478,
      "h": 12885557366,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885557366)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524662),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Boolean).$h,
      "n": "IsEntityFrameworkProviderTypeCache",
      "d": 655478,
      "h": 17180524662,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180524662)
  ],
  "h": 655478
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.AsyncQueryExecutorSupplier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Infrastructure${separator}AsyncQueryExecutorSupplier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655478)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114230)
        $asm.$cls(`$macq.MACQ.PaginationState`, ($self) => class PaginationState extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103080329334)
            /*int*/ ItemsPerPage = 0;
            //--TRIMMABLE-BOUNDARY-END(103080329334)
            
            //--TRIMMABLE-BOUNDARY-START(38655819894)
            /*int*/ CurrentPageIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(38655819894)
            
            //--TRIMMABLE-BOUNDARY-START(154619936886)
            /*int?*/ TotalItemCount = null;
            //--TRIMMABLE-BOUNDARY-END(154619936886)
            
            //--TRIMMABLE-BOUNDARY-START(107375296630)
            /*int? */ get LastPageIndex()
            {
                return $.trunc(($.$$.S.Int32.op_Subtraction(this.TotalItemCount, 1)) / this.ItemsPerPage);
            }
            //--TRIMMABLE-BOUNDARY-END(107375296630)
            
            //--TRIMMABLE-BOUNDARY-START(158914904182)
            /*EventHandler<int?>?*/ TotalItemCountChanged = null;
            //--TRIMMABLE-BOUNDARY-END(158914904182)
            
            //--TRIMMABLE-BOUNDARY-START(158914904182)
            //--TRIMMABLE-BOUNDARY-START(34360852598)
            add_TotalItemCountChanged(/*EventHandler<int?>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360852598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.TotalItemCountChanged = $.$$.S.Delegate.Combine$2(this.TotalItemCountChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360852598)
            
            //--TRIMMABLE-BOUNDARY-START(115965231222)
            remove_TotalItemCountChanged(/*EventHandler<int?>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965231222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.TotalItemCountChanged = $.$$.S.Delegate.Remove(this.TotalItemCountChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(115965231222)
            
            //--TRIMMABLE-BOUNDARY-END(158914904182)
            
            //--TRIMMABLE-BOUNDARY-START(42950787190)
            /*EventCallbackSubscribable<PaginationState>*/ CurrentPageItemsChanged = null;
            //--TRIMMABLE-BOUNDARY-END(42950787190)
            
            //--TRIMMABLE-BOUNDARY-START(163209871478)
            /*EventCallbackSubscribable<PaginationState>*/ TotalItemCountChangedSubscribable = null;
            //--TRIMMABLE-BOUNDARY-END(163209871478)
            
            //--TRIMMABLE-BOUNDARY-START(98785362038)
            /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785362038);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.HashCode.Combine$5($.$$.S.Int32, $.$$.S.Int32, $.$typeNullable($.$$.S.Int32), this.ItemsPerPage, this.CurrentPageIndex, this.TotalItemCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785362038)
            
            //--TRIMMABLE-BOUNDARY-START(146030002294)
            /*Task */ SetCurrentPageIndexAsync(/*int*/ pageIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030002294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentPageIndex = pageIndex;
                return this.CurrentPageItemsChanged.InvokeCallbacksAsync(this);
            }
            //--TRIMMABLE-BOUNDARY-END(146030002294)
            
            //--TRIMMABLE-BOUNDARY-START(150324969590)
            /*Task */ SetTotalItemCountAsync(/*int*/ totalItemCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324969590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (totalItemCount === this.TotalItemCount)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                this.TotalItemCount = totalItemCount;
                if (this.CurrentPageIndex > 0 && $.$$.S.Int32.op_GreaterThan$1(this.CurrentPageIndex, this.LastPageIndex))
                {
                    return this.SetCurrentPageIndexAsync($.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(this.LastPageIndex));
                }
                else 
                {
                    this.TotalItemCountChanged?.Invoke(this, this.TotalItemCount);
                    return this.TotalItemCountChangedSubscribable.InvokeCallbacksAsync(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324969590)
            
            //--TRIMMABLE-BOUNDARY-START(25770918006)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770918006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770918006)
            
            //--TRIMMABLE-BOUNDARY-START(25770918006)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770918006)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(103080329334)
                this.ItemsPerPage = 10;
                //--TRIMMABLE-BOUNDARY-END(103080329334)
                
                //--TRIMMABLE-BOUNDARY-START(42950787190)
                this.CurrentPageItemsChanged = new ($.$macq.MACQI.EventCallbackSubscribable$$($.$macq.MACQ.PaginationState))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(42950787190)
                
                //--TRIMMABLE-BOUNDARY-START(163209871478)
                this.TotalItemCountChangedSubscribable = new ($.$macq.MACQI.EventCallbackSubscribable$$($.$macq.MACQ.PaginationState))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(163209871478)
                
            }
            static $h = 1114230;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080329334),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720590966,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145100406,
        "f": 83886081
      },
      "n": "ItemsPerPage",
      "d": 1114230,
      "h": 103080329334,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080329334),
//--TRIMMABLE-BOUNDARY-START(38655819894),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721782,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555165814,
        "f": 83886082
      },
      "n": "CurrentPageIndex",
      "d": 1114230,
      "h": 38655819894,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655819894),
//--TRIMMABLE-BOUNDARY-START(154619936886),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900460150,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735034998,
        "f": 83886082
      },
      "n": "TotalItemCount",
      "d": 1114230,
      "h": 154619936886,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619936886),
//--TRIMMABLE-BOUNDARY-START(107375296630),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310525558,
        "f": 50331649
      },
      "n": "LastPageIndex",
      "d": 1114230,
      "h": 107375296630,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375296630),
//--TRIMMABLE-BOUNDARY-START(42950787190),
    {
      "p": $.$macq.MACQI.EventCallbackSubscribable$$($.$macq.MACQ.PaginationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130656374,
        "f": 50331656
      },
      "n": "CurrentPageItemsChanged",
      "d": 1114230,
      "h": 42950787190,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42950787190),
//--TRIMMABLE-BOUNDARY-START(163209871478),
    {
      "p": $.$macq.MACQI.EventCallbackSubscribable$$($.$macq.MACQ.PaginationState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490394742,
        "f": 50331656
      },
      "n": "TotalItemCountChangedSubscribable",
      "d": 1114230,
      "h": 163209871478,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(163209871478)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98785362038),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1114230,
      "h": 98785362038,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785362038),
//--TRIMMABLE-BOUNDARY-START(146030002294),
    {
      "r": 178454529,
      "p": [
        {
          "n": "pageIndex",
          "p": 655361
        }
      ],
      "n": "SetCurrentPageIndexAsync",
      "d": 1114230,
      "h": 146030002294,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030002294),
//--TRIMMABLE-BOUNDARY-START(150324969590),
    {
      "r": 178454529,
      "p": [
        {
          "n": "totalItemCount",
          "p": 655361
        }
      ],
      "n": "SetTotalItemCountAsync",
      "d": 1114230,
      "h": 150324969590,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150324969590)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770918006),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114230,
      "h": 25770918006,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770918006)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(158914904182),
    {
      "e": $.$$.S.EventHandler$$($.$$.S.Nullable$$($.$$.S.Int32)).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$$.S.Nullable$$($.$$.S.Int32)).$h
          }
        ],
        "n": "add_TotalItemCountChanged",
        "d": 1114230,
        "h": 34360852598,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$$.S.Nullable$$($.$$.S.Int32)).$h
          }
        ],
        "n": "remove_TotalItemCountChanged",
        "d": 1114230,
        "h": 115965231222,
        "f": 285212673
      },
      "n": "TotalItemCountChanged",
      "d": 1114230,
      "h": 158914904182,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(158914904182)
  ],
  "h": 1114230
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.PaginationState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}PaginationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114230)
        
        

        //--TRIMMABLE-BOUNDARY-START(393334)
        $asm.$cls(`$macq.MACQ.GridItemsProviderResult`, ($self) => class GridItemsProviderResult
        {
            //--TRIMMABLE-BOUNDARY-START(4295360630)
            static /*GridItemsProviderResult<TGridItem> */ From(TGridItem, /*ICollection<TGridItem>*/ items, /*int*/ totalItemCount)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360630);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$macq.MACQ.GridItemsProviderResult$$(TGridItem)()
                        const $t1 = $.$macq.MACQ.GridItemsProviderResult$$(TGridItem);
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Items = items;
                        $i1.TotalItemCount = totalItemCount;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360630)
            
            static $h = 393334;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360630),
    {
      "r": (TGridItem) => $.$macq.MACQ.GridItemsProviderResult$$(TGridItem).$h,
      "p": [
        {
          "n": "items",
          "p": (TGridItem) => $.$$.SCG.ICollection$$(TGridItem).$h
        },
        {
          "n": "totalItemCount",
          "p": 655361
        }
      ],
      "g": [
        "TGridItem"
      ],
      "n": "From",
      "d": 393334,
      "h": 4295360630,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295360630)
  ],
  "h": 393334
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}GridItemsProviderResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393334)
        
        

        //--TRIMMABLE-BOUNDARY-START(524406)
        $asm.$cls(`$macq.MACQ.GridSort<>`, (TGridItem) => $asm.$gt(`$macq.MACQ.GridSort<>`, [TGridItem], ($self) => class GridSort$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540131958)
            /*string*/ static ExpressionNotRepresentableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51540131958)
            
            //--TRIMMABLE-BOUNDARY-START(12885426294)
            /*Func<IQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>*/ _first = null;
            //--TRIMMABLE-BOUNDARY-END(12885426294)
            
            //--TRIMMABLE-BOUNDARY-START(21475360886)
            /*List<Func<IOrderedQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>>?*/ _then = null;
            //--TRIMMABLE-BOUNDARY-END(21475360886)
            
            //--TRIMMABLE-BOUNDARY-START(17180393590)
            /*(LambdaExpression, bool)*/ _firstExpression;
            //--TRIMMABLE-BOUNDARY-END(17180393590)
            
            //--TRIMMABLE-BOUNDARY-START(25770328182)
            /*List<(LambdaExpression, bool)>?*/ _thenExpressions = null;
            //--TRIMMABLE-BOUNDARY-END(25770328182)
            
            //--TRIMMABLE-BOUNDARY-START(4295491702)
            /*IReadOnlyCollection<SortedProperty>?*/ _cachedPropertyListAscending = null;
            //--TRIMMABLE-BOUNDARY-END(4295491702)
            
            //--TRIMMABLE-BOUNDARY-START(8590458998)
            /*IReadOnlyCollection<SortedProperty>?*/ _cachedPropertyListDescending = null;
            //--TRIMMABLE-BOUNDARY-END(8590458998)
            
            //--TRIMMABLE-BOUNDARY-START(30065295478)
            $ctor$1(/*Func<IQueryable<TGridItem>, bool, IOrderedQueryable<TGridItem>>*/ first, /*(LambdaExpression, bool)*/ firstExpression)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295478);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._first = first;
                    this._firstExpression = $.$clone(firstExpression);
                    this._then = null;
                    this._thenExpressions = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295478)
            
            //--TRIMMABLE-BOUNDARY-START(42950197366)
            static /*GridSort<TGridItem> */ ByAscending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950197366);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$macq.MACQ.GridSort$$(TGridItem))().$ctor$1(new ($.$$.S.Func$$$$($.$sle.SL.IQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                    {
                        return asc ? $.$slq.SL.Queryable.OrderBy$1(TGridItem, U, queryable, expression) : $.$slq.SL.Queryable.OrderByDescending$1(TGridItem, U, queryable, expression);
                    }, $asDvCb ??= {"r":$.$sle.SL.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.SL.IQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), new ($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean))().$ctor$3(expression, true));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950197366)
            
            //--TRIMMABLE-BOUNDARY-START(47245164662)
            static /*GridSort<TGridItem> */ ByDescending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245164662);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$macq.MACQ.GridSort$$(TGridItem))().$ctor$1(new ($.$$.S.Func$$$$($.$sle.SL.IQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                    {
                        return asc ? $.$slq.SL.Queryable.OrderByDescending$1(TGridItem, U, queryable, expression) : $.$slq.SL.Queryable.OrderBy$1(TGridItem, U, queryable, expression);
                    }, $kiCxDe ??= {"r":$.$sle.SL.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.SL.IQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), new ($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean))().$ctor$3(expression, false));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245164662)
            
            //--TRIMMABLE-BOUNDARY-START(55835099254)
            /*GridSort<TGridItem> */ ThenAscending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._then ??= new ($.$$.SCG.List$$($.$$.S.Func$$$$($.$sle.SL.IOrderedQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem))))().$ctor$1();
                this._thenExpressions ??= new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean)))().$ctor$1();
                this._then.Add(new ($.$$.S.Func$$$$($.$sle.SL.IOrderedQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.SL.Queryable.ThenBy$1(TGridItem, U, queryable, expression) : $.$slq.SL.Queryable.ThenByDescending$1(TGridItem, U, queryable, expression);
                }, $ujYydg ??= {"r":$.$sle.SL.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.SL.IOrderedQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                this._thenExpressions.Add(new ($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean))().$ctor$3(expression, true));
                this._cachedPropertyListAscending = null;
                this._cachedPropertyListDescending = null;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835099254)
            
            //--TRIMMABLE-BOUNDARY-START(60130066550)
            /*GridSort<TGridItem> */ ThenDescending(U, /*Expression<Func<TGridItem, U>>*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._then ??= new ($.$$.SCG.List$$($.$$.S.Func$$$$($.$sle.SL.IOrderedQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem))))().$ctor$1();
                this._thenExpressions ??= new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean)))().$ctor$1();
                this._then.Add(new ($.$$.S.Func$$$$($.$sle.SL.IOrderedQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem)))().$ctor(this,  (/*queryable*/ queryable, /*asc*/ asc) =>
                {
                    return asc ? $.$slq.SL.Queryable.ThenByDescending$1(TGridItem, U, queryable, expression) : $.$slq.SL.Queryable.ThenBy$1(TGridItem, U, queryable, expression);
                }, $EhbxYc ??= {"r":$.$sle.SL.IOrderedQueryable$$(TGridItem).$h,"p":[{"n":"queryable","p":$.$sle.SL.IOrderedQueryable$$(TGridItem).$h},{"n":"asc","p":262145}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                this._thenExpressions.Add(new ($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean))().$ctor$3(expression, false));
                this._cachedPropertyListAscending = null;
                this._cachedPropertyListDescending = null;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130066550)
            
            //--TRIMMABLE-BOUNDARY-START(34360262774)
            /*IOrderedQueryable<TGridItem> */ Apply(/*IQueryable<TGridItem>*/ queryable, /*bool*/ ascending)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let orderedQueryable = this._first.Invoke(queryable, ascending);
                if (!(this._then === null))
                {
                    let $en1 = this._then.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let clause = $en1.Current;
                        {
                            orderedQueryable = clause.Invoke(orderedQueryable, ascending);
                        }
                    }
                }
                return orderedQueryable;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262774)
            
            //--TRIMMABLE-BOUNDARY-START(64425033846)
            /*IReadOnlyCollection<SortedProperty> */ ToPropertyList(/*bool*/ ascending)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ascending)
                {
                    this._cachedPropertyListAscending ??= this.BuildPropertyList(true);
                    return this._cachedPropertyListAscending;
                }
                else 
                {
                    this._cachedPropertyListDescending ??= this.BuildPropertyList(false);
                    return this._cachedPropertyListDescending;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425033846)
            
            //--TRIMMABLE-BOUNDARY-START(38655230070)
            /*List<SortedProperty> */ BuildPropertyList(/*bool*/ ascending)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655230070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = (() =>
                {
                    //new $.$$.SCG.List$$($.$macq.MACQ.SortedProperty)()
                    const $t2 = $.$$.SCG.List$$($.$macq.MACQ.SortedProperty);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Add((() =>
                    {
                        //new $.$macq.MACQ.SortedProperty()
                        const $t3 = $.$macq.MACQ.SortedProperty;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.PropertyName = $.$macq.MACQ.GridSort$$(TGridItem).ToPropertyName(this._firstExpression.Item1);
                        $i3.Direction = ($.$$.S.Boolean.op_ExclusiveOr$2(this._firstExpression.Item2, ascending)) ? 2/*SortDirection.Descending*/ : 1/*SortDirection.Ascending*/;
                        return $i3;
                    })());
                    return $i2;
                })();
                if (!(this._thenExpressions === null))
                {
                    let $en4 = this._thenExpressions.GetEnumerator();
                    while ($en4.MoveNext())
                    {
                        let [ thenLambda, thenAscending ] = $.$destructure($en4.Current, 2);
                        {
                            result.Add((() =>
                            {
                                //new $.$macq.MACQ.SortedProperty()
                                const $t5 = $.$macq.MACQ.SortedProperty;
                                const $i5 = new $t5();
                                $i5.$ctor$2();
                                $i5.PropertyName = $.$macq.MACQ.GridSort$$(TGridItem).ToPropertyName(thenLambda);
                                $i5.Direction = ($.$$.S.Boolean.op_ExclusiveOr$2(thenAscending, ascending)) ? 2/*SortDirection.Descending*/ : 1/*SortDirection.Ascending*/;
                                return $i5;
                            })());
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(38655230070)
            
            //--TRIMMABLE-BOUNDARY-START(68720001142)
            static /*string */ ToPropertyName(/*LambdaExpression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let expressionBody = expression.Body;
                if (expressionBody.NodeType === 10/*ExpressionType.Convert*/ || expressionBody.NodeType === 11/*ExpressionType.ConvertChecked*/)
                {
                    expressionBody = ($.$cast(expressionBody, $.$sle.SLE.UnaryExpression)).Operand;
                }
                let body;
                if (!$.$is(expressionBody, $.$sle.SLE.MemberExpression, { set $v($v){ body = $v; } }))
                {
                    throw new $.$$.S.ArgumentException().$ctor$14("The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names."/*ExpressionNotRepresentableMessage*/);
                }
                if ($.$is(body.Expression, $.$sle.SLE.ParameterExpression))
                {
                    return body.Member.Name;
                }
                /*var*/ let length = body.Member.Name.length;
                /*var*/ let node = body;
                while(!(node.Expression === null))
                {
                    let parentMember;
                    if ($.$is(node.Expression, $.$sle.SLE.MemberExpression, { set $v($v){ parentMember = $v; } }))
                    {
                        length += ((parentMember.Member.Name.length + 1) | 0);
                        node = parentMember;
                    }
                    else if ($.$is(node.Expression, $.$sle.SLE.ParameterExpression))
                    {
                        break;
                    }
                    else 
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14("The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names."/*ExpressionNotRepresentableMessage*/);
                    }
                }
                return $.$$.S.String.Create$10($.$sle.SLE.MemberExpression, length, body, new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$sle.SLE.MemberExpression))().$ctor(this,  (/*chars*/ chars, /*body*/ body) =>
                {
                    /*var*/ let nextPos = chars.Length;
                    while(!(body === null))
                    {
                        nextPos -= body.Member.Name.length;
                        let $t6 = chars;
                        $.$$.S.String.CopyTo$1.call(body.Member.Name, $t6.Slice(nextPos, $t6.Length - nextPos));
                        if (nextPos > 0)
                        {
                            chars._reference.SetAt(/*.*/ 46, --nextPos);
                        }
                        body = ($.$as(body.Expression, $.$sle.SLE.MemberExpression));
                    }
                }, $opWepl ??= {"r":65537,"p":[{"n":"chars","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"body","p":39321637}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(68720001142)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180393590)
                this._firstExpression = $.$default($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean));
                //--TRIMMABLE-BOUNDARY-END(17180393590)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51540131958)
                    this.ExpressionNotRepresentableMessage = "The supplied expression can't be represented as a property name for sorting. Only simple member expressions, such as @(x => x.SomeProperty), can be converted to property names.";
                    //--TRIMMABLE-BOUNDARY-END(51540131958)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $H = 524406;
            static $h = 524406;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950197366),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.SLE.Expression$$($.$$.S.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ByAscending",
      "d": this.$h,
      "H": 42950197366,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42950197366),
//--TRIMMABLE-BOUNDARY-START(47245164662),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.SLE.Expression$$($.$$.S.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ByDescending",
      "d": this.$h,
      "H": 47245164662,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47245164662),
//--TRIMMABLE-BOUNDARY-START(55835099254),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.SLE.Expression$$($.$$.S.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ThenAscending",
      "d": this.$h,
      "H": 55835099254,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(55835099254),
//--TRIMMABLE-BOUNDARY-START(60130066550),
    {
      "r": this.$h,
      "p": [
        {
          "n": "expression",
          "p": (U) => $.$sle.SLE.Expression$$($.$$.S.Func$$$(TGridItem, U)).$h
        }
      ],
      "g": [
        "U"
      ],
      "n": "ThenDescending",
      "d": this.$h,
      "H": 60130066550,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60130066550),
//--TRIMMABLE-BOUNDARY-START(34360262774),
    {
      "r": $.$sle.SL.IOrderedQueryable$$(TGridItem).$h,
      "p": [
        {
          "n": "queryable",
          "p": $.$sle.SL.IQueryable$$(TGridItem).$h
        },
        {
          "n": "ascending",
          "p": 262145
        }
      ],
      "n": "Apply",
      "d": this.$h,
      "H": 34360262774,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360262774),
//--TRIMMABLE-BOUNDARY-START(64425033846),
    {
      "r": $.$$.SCG.IReadOnlyCollection$$($.$macq.MACQ.SortedProperty).$h,
      "p": [
        {
          "n": "ascending",
          "p": 262145
        }
      ],
      "n": "ToPropertyList",
      "d": this.$h,
      "H": 64425033846,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64425033846),
//--TRIMMABLE-BOUNDARY-START(38655230070),
    {
      "r": $.$$.SCG.List$$($.$macq.MACQ.SortedProperty).$h,
      "p": [
        {
          "n": "ascending",
          "p": 262145
        }
      ],
      "n": "BuildPropertyList",
      "d": this.$h,
      "H": 38655230070,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655230070),
//--TRIMMABLE-BOUNDARY-START(68720001142),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 38797349
        }
      ],
      "n": "ToPropertyName",
      "d": this.$h,
      "H": 68720001142,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720001142)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540131958),
    {
      "t": 1310721,
      "n": "ExpressionNotRepresentableMessage",
      "d": this.$h,
      "H": 51540131958,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540131958),
//--TRIMMABLE-BOUNDARY-START(12885426294),
    {
      "t": $.$$.S.Func$$$$($.$sle.SL.IQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem)).$h,
      "n": "_first",
      "d": this.$h,
      "H": 12885426294,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426294),
//--TRIMMABLE-BOUNDARY-START(21475360886),
    {
      "t": $.$$.SCG.List$$($.$$.S.Func$$$$($.$sle.SL.IOrderedQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem))).$h,
      "n": "_then",
      "d": this.$h,
      "H": 21475360886,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475360886),
//--TRIMMABLE-BOUNDARY-START(17180393590),
    {
      "t": $.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean).$h,
      "n": "_firstExpression",
      "d": this.$h,
      "H": 17180393590,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180393590),
//--TRIMMABLE-BOUNDARY-START(25770328182),
    {
      "t": $.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean)).$h,
      "n": "_thenExpressions",
      "d": this.$h,
      "H": 25770328182,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770328182),
//--TRIMMABLE-BOUNDARY-START(4295491702),
    {
      "t": $.$$.SCG.IReadOnlyCollection$$($.$macq.MACQ.SortedProperty).$h,
      "n": "_cachedPropertyListAscending",
      "d": this.$h,
      "H": 4295491702,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491702),
//--TRIMMABLE-BOUNDARY-START(8590458998),
    {
      "t": $.$$.SCG.IReadOnlyCollection$$($.$macq.MACQ.SortedProperty).$h,
      "n": "_cachedPropertyListDescending",
      "d": this.$h,
      "H": 8590458998,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458998)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065295478),
    {
      "p": [
        {
          "n": "first",
          "p": $.$$.S.Func$$$$($.$sle.SL.IQueryable$$(TGridItem), $.$$.S.Boolean, $.$sle.SL.IOrderedQueryable$$(TGridItem)).$h
        },
        {
          "n": "firstExpression",
          "p": $.$$.S.ValueTuple$$$($.$sle.SLE.LambdaExpression, $.$$.S.Boolean).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30065295478,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065295478)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 524406,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.GridSort<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}GridSort$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(524406)
        
        

        //--TRIMMABLE-BOUNDARY-START(721014)
        $asm.$cls(`$macq.MACQI.ColumnsCollectedNotifier<>`, (TGridItem) => $asm.$gt(`$macq.MACQI.ColumnsCollectedNotifier<>`, [TGridItem], ($self) => class ColumnsCollectedNotifier$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688310)
            /*bool*/ _isFirstRender = true;
            //--TRIMMABLE-BOUNDARY-END(4295688310)
            
            //--TRIMMABLE-BOUNDARY-START(30065492086)
            /*InternalGridContext<TGridItem>*/ InternalGridContext = null;
            //--TRIMMABLE-BOUNDARY-END(30065492086)
            
            //--TRIMMABLE-BOUNDARY-START(17180590198)
            /*void */ Attach(/*RenderHandle*/ renderHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180590198)
            
            //--TRIMMABLE-BOUNDARY-START(42950393974)
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isFirstRender)
                {
                    this._isFirstRender = false;
                    parameters.SetParameterProperties(this);
                    return this.InternalGridContext.ColumnsFirstCollected.InvokeCallbacksAsync(null);
                }
                else 
                {
                    return $.$$.STT.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393974)
            
            //--TRIMMABLE-BOUNDARY-START(4297719923)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IComponent.Attach(Microsoft.AspNetCore.Components.RenderHandle)
            MAC$IComponent$Attach()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297719923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Attach(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297719923)
            
            //--TRIMMABLE-BOUNDARY-START(8592687219)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IComponent.SetParametersAsync(Microsoft.AspNetCore.Components.ParameterView)
            MAC$IComponent$SetParametersAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592687219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetParametersAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8592687219)
            
            //--TRIMMABLE-BOUNDARY-START(12885622902)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622902)
            
            //--TRIMMABLE-BOUNDARY-START(12885622902)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885622902)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065492086)
                this.InternalGridContext = null;
                //--TRIMMABLE-BOUNDARY-END(30065492086)
                
            }
            static $H = 721014;
            static $h = 721014;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065492086),
    {
      "p": $.$macq.MACQI.InternalGridContext$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770524790,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 38655426678,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 83886088
      },
      "n": "InternalGridContext",
      "d": this.$h,
      "H": 30065492086,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097160,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065492086)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590198),
    {
      "r": 65537,
      "p": [
        {
          "n": "renderHandle",
          "p": 7012467
        }
      ],
      "n": "Attach",
      "d": this.$h,
      "H": 17180590198,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590198),
//--TRIMMABLE-BOUNDARY-START(42950393974),
    {
      "r": 178454529,
      "p": [
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": "SetParametersAsync",
      "d": this.$h,
      "H": 42950393974,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393974)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688310),
    {
      "t": 262145,
      "n": "_isFirstRender",
      "d": this.$h,
      "H": 4295688310,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688310)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622902),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12885622902,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622902)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 721014,
  "h": this.$h,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.ColumnsCollectedNotifier<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Infrastructure${separator}ColumnsCollectedNotifier$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(721014)
        
        

        //--TRIMMABLE-BOUNDARY-START(917622)
        $asm.$cls(`$macq.MACQI.EventCallbackSubscriber<>`, (T) => $asm.$gt(`$macq.MACQI.EventCallbackSubscriber<>`, [T], ($self) => class EventCallbackSubscriber$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590852214)
            /*EventCallback<T>*/ _handler;
            //--TRIMMABLE-BOUNDARY-END(8590852214)
            
            //--TRIMMABLE-BOUNDARY-START(4295884918)
            /*EventCallbackSubscribable<T>?*/ _existingSubscription = null;
            //--TRIMMABLE-BOUNDARY-END(4295884918)
            
            //--TRIMMABLE-BOUNDARY-START(12885819510)
            $ctor$1(/*EventCallback<T>*/ handler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885819510);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._handler = handler;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819510)
            
            //--TRIMMABLE-BOUNDARY-START(21475754102)
            /*void */ SubscribeOrMove(/*EventCallbackSubscribable<T>?*/ subscribable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (subscribable !== this._existingSubscription)
                {
                    this._existingSubscription?.Unsubscribe(this);
                    subscribable?.Subscribe(this, this._handler);
                    this._existingSubscription = subscribable;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475754102)
            
            //--TRIMMABLE-BOUNDARY-START(17180786806)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180786806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._existingSubscription?.Unsubscribe(this);
            }
            //--TRIMMABLE-BOUNDARY-END(17180786806)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590852214)
                this._handler = $.$default($.$mac.MAC.EventCallback$$(T));
                //--TRIMMABLE-BOUNDARY-END(8590852214)
                
            }
            static $H = 917622;
            static $h = 917622;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475754102),
    {
      "r": 65537,
      "p": [
        {
          "n": "subscribable",
          "p": $.$macq.MACQI.EventCallbackSubscribable$$(T).$h
        }
      ],
      "n": "SubscribeOrMove",
      "d": this.$h,
      "H": 21475754102,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754102),
//--TRIMMABLE-BOUNDARY-START(17180786806),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 17180786806,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786806)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852214),
    {
      "t": $.$mac.MAC.EventCallback$$(T).$h,
      "n": "_handler",
      "d": this.$h,
      "H": 8590852214,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852214),
//--TRIMMABLE-BOUNDARY-START(4295884918),
    {
      "t": $.$macq.MACQI.EventCallbackSubscribable$$(T).$h,
      "n": "_existingSubscription",
      "d": this.$h,
      "H": 4295884918,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884918)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819510),
    {
      "p": [
        {
          "n": "handler",
          "p": $.$mac.MAC.EventCallback$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12885819510,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819510)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 917622,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.EventCallbackSubscriber<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Infrastructure${separator}EventCallbackSubscriber$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917622)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572982)
        $asm.$cls(`$macq.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296540278)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540278)
            
            //--TRIMMABLE-BOUNDARY-START(4296540278)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540278)
            
            static $h = 1572982;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540278),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572982,
      "h": 4296540278,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540278)
  ],
  "h": 1572982
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572982)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638518)
        $asm.$cls(`$macq.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296605814)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605814)
            
            //--TRIMMABLE-BOUNDARY-START(4296605814)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605814)
            
            static $h = 1638518;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605814),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638518,
      "h": 4296605814,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605814)
  ],
  "h": 1638518,
  "a": [
    {
      "t": 1572982,
      "c": 4296540278
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638518)
        
        

        //--TRIMMABLE-BOUNDARY-START(458870)
        $asm.$str(`$macq.MACQ.GridItemsProviderResult<>`, (TGridItem) => $asm.$gt(`$macq.MACQ.GridItemsProviderResult<>`, [TGridItem], ($self) => class GridItemsProviderResult$$ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34360197238)
            /*ICollection<TGridItem>*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(34360197238)
            
            //--TRIMMABLE-BOUNDARY-START(55835033718)
            /*int*/ TotalItemCount = 0;
            //--TRIMMABLE-BOUNDARY-END(55835033718)
            
            //--TRIMMABLE-BOUNDARY-START(12885360758)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360758)
            
            //--TRIMMABLE-BOUNDARY-START(12885360758)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885360758)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Items = this.Items;
                copy.TotalItemCount = this.TotalItemCount;
                return copy;
            }
            static $H = 458870;
            static $h = 458870;
            static $g = 1;
            static $z = 8;
            static $f = 0b1011000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360197238),
    {
      "p": $.$$.SCG.ICollection$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21475295350,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 42950131830,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 83886081
      },
      "n": "Items",
      "d": this.$h,
      "H": 34360197238,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360197238),
//--TRIMMABLE-BOUNDARY-START(55835033718),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30065229942,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 51540066422,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 83886081
      },
      "n": "TotalItemCount",
      "d": this.$h,
      "H": 55835033718,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835033718)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360758),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 12885360758,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360758)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 458870,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderResult<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}GridItemsProviderResult$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458870)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441910)
        $asm.$str(`$macq.MACQ.SortedProperty`, ($self) => class SortedProperty extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38656147574)
            /*string*/ PropertyName = null;
            //--TRIMMABLE-BOUNDARY-END(38656147574)
            
            //--TRIMMABLE-BOUNDARY-START(17181311094)
            /*SortDirection*/ Direction = 0;
            //--TRIMMABLE-BOUNDARY-END(17181311094)
            
            //--TRIMMABLE-BOUNDARY-START(12886343798)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343798)
            
            //--TRIMMABLE-BOUNDARY-START(12886343798)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886343798)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PropertyName = this.PropertyName;
                copy.Direction = this.Direction;
                return copy;
            }
            static $h = 1441910;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656147574),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361180278,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836016758,
        "f": 83886081
      },
      "n": "PropertyName",
      "d": 1441910,
      "h": 38656147574,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656147574),
//--TRIMMABLE-BOUNDARY-START(17181311094),
    {
      "p": 1376374,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771245686,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246082166,
        "f": 83886081
      },
      "n": "Direction",
      "d": 1441910,
      "h": 17181311094,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181311094)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886343798),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441910,
      "h": 12886343798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886343798)
  ],
  "h": 1441910
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.SortedProperty`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}SortedProperty`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441910)
        
        

        //--TRIMMABLE-BOUNDARY-START(327798)
        $asm.$str(`$macq.MACQ.GridItemsProviderRequest<>`, (TGridItem) => $asm.$gt(`$macq.MACQ.GridItemsProviderRequest<>`, [TGridItem], ($self) => class GridItemsProviderRequest$$ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(146029215862)
            /*int*/ StartIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(146029215862)
            
            //--TRIMMABLE-BOUNDARY-START(42950000758)
            /*int?*/ Count = null;
            //--TRIMMABLE-BOUNDARY-END(42950000758)
            
            //--TRIMMABLE-BOUNDARY-START(141734248566)
            /*ColumnBase<TGridItem>?*/ SortByColumn = null;
            //--TRIMMABLE-BOUNDARY-END(141734248566)
            
            //--TRIMMABLE-BOUNDARY-START(137439281270)
            /*bool*/ SortByAscending = false;
            //--TRIMMABLE-BOUNDARY-END(137439281270)
            
            //--TRIMMABLE-BOUNDARY-START(38655033462)
            /*CancellationToken*/ CancellationToken;
            //--TRIMMABLE-BOUNDARY-END(38655033462)
            
            //--TRIMMABLE-BOUNDARY-START(30065098870)
            $ctor$3(/*int*/ startIndex, /*int?*/ count, /*ColumnBase<TGridItem>?*/ sortByColumn, /*bool*/ sortByAscending, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098870);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.StartIndex = startIndex;
                    this.Count = count;
                    this.SortByColumn = sortByColumn;
                    this.SortByAscending = sortByAscending;
                    this.CancellationToken = cancellationToken;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098870)
            
            //--TRIMMABLE-BOUNDARY-START(34360066166)
            /*IQueryable<TGridItem> */ ApplySorting(/*IQueryable<TGridItem>*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360066166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.SortByColumn?.SortBy?.Apply(source, this.SortByAscending) ?? null) ?? source;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066166)
            
            //--TRIMMABLE-BOUNDARY-START(90194641014)
            /*IReadOnlyCollection<SortedProperty> */ GetSortByProperties()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194641014);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.SortByColumn?.SortBy?.ToPropertyList(this.SortByAscending) ?? null) ?? $.$$.S.Array.Empty($.$macq.MACQ.SortedProperty);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194641014)
            
            //--TRIMMABLE-BOUNDARY-START(25770131574)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131574)
            
            //--TRIMMABLE-BOUNDARY-START(25770131574)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25770131574)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.StartIndex = this.StartIndex;
                copy.Count = this.Count;
                copy.SortByColumn = this.SortByColumn;
                copy.SortByAscending = this.SortByAscending;
                copy.CancellationToken = this.CancellationToken.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655033462)
                this.CancellationToken = $.$default($.$$.ST$1.CancellationToken);
                //--TRIMMABLE-BOUNDARY-END(38655033462)
                
            }
            static $H = 327798;
            static $h = 327798;
            static $g = 1;
            static $z = 18;
            static $f = 0b1011000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(146029215862),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85899673718,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 133144313974,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 83886081
      },
      "n": "StartIndex",
      "d": this.$h,
      "H": 146029215862,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029215862),
//--TRIMMABLE-BOUNDARY-START(42950000758),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60129869942,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 107374510198,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 83886081
      },
      "n": "Count",
      "d": this.$h,
      "H": 42950000758,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950000758),
//--TRIMMABLE-BOUNDARY-START(141734248566),
    {
      "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309739126,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 124554379382,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 83886081
      },
      "n": "SortByColumn",
      "d": this.$h,
      "H": 141734248566,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734248566),
//--TRIMMABLE-BOUNDARY-START(137439281270),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719804534,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 115964444790,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 83886081
      },
      "n": "SortByAscending",
      "d": this.$h,
      "H": 137439281270,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439281270),
//--TRIMMABLE-BOUNDARY-START(38655033462),
    {
      "p": 170852353,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51539935350,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 98784575606,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 83886081
      },
      "n": "CancellationToken",
      "d": this.$h,
      "H": 38655033462,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655033462)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066166),
    {
      "r": $.$sle.SL.IQueryable$$(TGridItem).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.SL.IQueryable$$(TGridItem).$h
        }
      ],
      "n": "ApplySorting",
      "d": this.$h,
      "H": 34360066166,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066166),
//--TRIMMABLE-BOUNDARY-START(90194641014),
    {
      "r": $.$$.SCG.IReadOnlyCollection$$($.$macq.MACQ.SortedProperty).$h,
      "n": "GetSortByProperties",
      "d": this.$h,
      "H": 90194641014,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194641014)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065098870),
    {
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "sortByColumn",
          "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h
        },
        {
          "n": "sortByAscending",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 30065098870,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065098870),
//--TRIMMABLE-BOUNDARY-START(25770131574),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 25770131574,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131574)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 327798,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.GridItemsProviderRequest<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}GridItemsProviderRequest$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327798)
        
        

        //--TRIMMABLE-BOUNDARY-START(786550)
        $asm.$cls(`$macq.MACQI.Defer`, ($self) => class Defer extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(17180655734)
            /*RenderFragment?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(17180655734)
            
            //--TRIMMABLE-BOUNDARY-START(12885688438)
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.AddContent$1(0, this.ChildContent);
            }
            //--TRIMMABLE-BOUNDARY-END(12885688438)
            
            //--TRIMMABLE-BOUNDARY-START(8590721142)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590721142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721142)
            
            //--TRIMMABLE-BOUNDARY-START(8590721142)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590721142)
            
            static $h = 786550;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180655734),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770590326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360524918,
        "f": 83886081
      },
      "n": "ChildContent",
      "d": 786550,
      "h": 17180655734,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180655734)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885688438),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 786550,
      "h": 12885688438,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885688438)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590721142),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786550,
      "h": 8590721142,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721142)
  ],
  "h": 786550,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Infrastructure.Defer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Infrastructure${separator}Defer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786550)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179766)
        $asm.$cls(`$macq.MACQ.Paginator`, ($self) => class Paginator extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296147062)
            /*EventCallbackSubscriber<PaginationState>*/ _totalItemCountChanged = null;
            //--TRIMMABLE-BOUNDARY-END(4296147062)
            
            //--TRIMMABLE-BOUNDARY-START(115965296758)
            /*PaginationState*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(115965296758)
            
            //--TRIMMABLE-BOUNDARY-START(120260264054)
            /*RenderFragment?*/ SummaryTemplate = null;
            //--TRIMMABLE-BOUNDARY-END(120260264054)
            
            //--TRIMMABLE-BOUNDARY-START(17181048950)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181048950);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._totalItemCountChanged = new ($.$macq.MACQI.EventCallbackSubscriber$$($.$macq.MACQ.PaginationState))().$ctor$1(new ($.$mac.MAC.EventCallback$$($.$macq.MACQ.PaginationState))().$ctor$3(this, null));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048950)
            
            //--TRIMMABLE-BOUNDARY-START(73015623798)
            /*Task */ GoFirstAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015623798);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync(0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015623798)
            
            //--TRIMMABLE-BOUNDARY-START(85900525686)
            /*Task */ GoPreviousAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900525686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync(((this.State.CurrentPageIndex - 1) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900525686)
            
            //--TRIMMABLE-BOUNDARY-START(81605558390)
            /*Task */ GoNextAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605558390);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync(((this.State.CurrentPageIndex + 1) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605558390)
            
            //--TRIMMABLE-BOUNDARY-START(77310591094)
            /*Task */ GoLastAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310591094);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GoToPageAsync($.$$.S.Nullable$$($.$$.S.Int32).GetValueOrDefault$1.call(this.State.LastPageIndex, 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310591094)
            
            //--TRIMMABLE-BOUNDARY-START(25770983542)
            /*bool */ get CanGoBack()
            {
                return this.State.CurrentPageIndex > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983542)
            
            //--TRIMMABLE-BOUNDARY-START(30065950838)
            /*bool */ get CanGoForwards()
            {
                return $.$$.S.Int32.op_LessThan$1(this.State.CurrentPageIndex, this.State.LastPageIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(30065950838)
            
            //--TRIMMABLE-BOUNDARY-START(90195492982)
            /*Task */ GoToPageAsync(/*int*/ pageIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195492982);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.State.SetCurrentPageIndexAsync(pageIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195492982)
            
            //--TRIMMABLE-BOUNDARY-START(94490460278)
            /*void */ OnParametersSet()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490460278);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._totalItemCountChanged.SubscribeOrMove(this.State.TotalItemCountChangedSubscribable);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490460278)
            
            //--TRIMMABLE-BOUNDARY-START(34360918134)
            /*void */ Dispose()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918134);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._totalItemCountChanged.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360918134)
            
            //--TRIMMABLE-BOUNDARY-START(21476016246)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "paginator");
                if ($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(this.State.TotalItemCount))
                {
                    __builder.OpenElement(2, "div");
                    __builder.AddAttribute$5(3, "class", "summary");
                    if (!(this.SummaryTemplate === null))
                    {
                        __builder.AddContent$1(4, this.SummaryTemplate);
                    }
                    else 
                    {
                        __builder.OpenElement(5, "strong");
                        __builder.AddContent$3(6, $.$box(this.State.TotalItemCount, $.$$.S.Int32));
                        __builder.CloseElement();
                        __builder.AddContent$4(7, " items");
                    }
                    __builder.CloseElement();
                    __builder.AddMarkupContent(8, "\r\n        ");
                    __builder.OpenElement(9, "nav");
                    __builder.AddAttribute$5(10, "role", "navigation");
                    __builder.OpenElement(11, "button");
                    __builder.AddAttribute$5(12, "class", "go-first");
                    __builder.AddAttribute$5(13, "type", "button");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 14, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.GoFirstAsync)));
                    __builder.AddAttribute$2(15, "disabled", !this.CanGoBack);
                    __builder.AddAttribute$5(16, "title", "Go to first page");
                    __builder.AddAttribute$5(17, "aria-label", "Go to first page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(18, "\r\n            ");
                    __builder.OpenElement(19, "button");
                    __builder.AddAttribute$5(20, "class", "go-previous");
                    __builder.AddAttribute$5(21, "type", "button");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 22, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.GoPreviousAsync)));
                    __builder.AddAttribute$2(23, "disabled", !this.CanGoBack);
                    __builder.AddAttribute$5(24, "title", "Go to previous page");
                    __builder.AddAttribute$5(25, "aria-label", "Go to previous page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(26, "\r\n            ");
                    __builder.OpenElement(27, "div");
                    __builder.AddAttribute$5(28, "class", "pagination-text");
                    __builder.AddMarkupContent(29, "\r\n                Page ");
                    __builder.OpenElement(30, "strong");
                    __builder.AddContent$3(31, $.$box(((this.State.CurrentPageIndex + 1) | 0), $.$$.S.Int32));
                    __builder.CloseElement();
                    __builder.AddMarkupContent(32, "\r\n                of ");
                    __builder.OpenElement(33, "strong");
                    __builder.AddContent$3(34, $.$box($.$$.S.Int32.op_Addition(this.State.LastPageIndex, 1), $.$$.S.Int32));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(35, "\r\n            ");
                    __builder.OpenElement(36, "button");
                    __builder.AddAttribute$5(37, "class", "go-next");
                    __builder.AddAttribute$5(38, "type", "button");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 39, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.GoNextAsync)));
                    __builder.AddAttribute$2(40, "disabled", !this.CanGoForwards);
                    __builder.AddAttribute$5(41, "title", "Go to next page");
                    __builder.AddAttribute$5(42, "aria-label", "Go to next page");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(43, "\r\n            ");
                    __builder.OpenElement(44, "button");
                    __builder.AddAttribute$5(45, "class", "go-last");
                    __builder.AddAttribute$5(46, "type", "button");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 47, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.GoLastAsync)));
                    __builder.AddAttribute$2(48, "disabled", !this.CanGoForwards);
                    __builder.AddAttribute$5(49, "title", "Go to last page");
                    __builder.AddAttribute$5(50, "aria-label", "Go to last page");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21476016246)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(17181048950)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181048950)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(115965296758)
                this.State = null;
                //--TRIMMABLE-BOUNDARY-END(115965296758)
                
            }
            static $h = 1179766;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115965296758),
    {
      "p": 1114230,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130721910,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080394870,
        "f": 83886081
      },
      "n": "State",
      "d": 1179766,
      "h": 115965296758,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965296758),
//--TRIMMABLE-BOUNDARY-START(120260264054),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720656502,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670329462,
        "f": 83886081
      },
      "n": "SummaryTemplate",
      "d": 1179766,
      "h": 120260264054,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260264054),
//--TRIMMABLE-BOUNDARY-START(25770983542),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950852726,
        "f": 50331650
      },
      "n": "CanGoBack",
      "d": 1179766,
      "h": 25770983542,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25770983542),
//--TRIMMABLE-BOUNDARY-START(30065950838),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540787318,
        "f": 50331650
      },
      "n": "CanGoForwards",
      "d": 1179766,
      "h": 30065950838,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30065950838)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015623798),
    {
      "r": 178454529,
      "n": "GoFirstAsync",
      "d": 1179766,
      "h": 73015623798,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015623798),
//--TRIMMABLE-BOUNDARY-START(85900525686),
    {
      "r": 178454529,
      "n": "GoPreviousAsync",
      "d": 1179766,
      "h": 85900525686,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900525686),
//--TRIMMABLE-BOUNDARY-START(81605558390),
    {
      "r": 178454529,
      "n": "GoNextAsync",
      "d": 1179766,
      "h": 81605558390,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605558390),
//--TRIMMABLE-BOUNDARY-START(77310591094),
    {
      "r": 178454529,
      "n": "GoLastAsync",
      "d": 1179766,
      "h": 77310591094,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310591094),
//--TRIMMABLE-BOUNDARY-START(90195492982),
    {
      "r": 178454529,
      "p": [
        {
          "n": "pageIndex",
          "p": 655361
        }
      ],
      "n": "GoToPageAsync",
      "d": 1179766,
      "h": 90195492982,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195492982),
//--TRIMMABLE-BOUNDARY-START(94490460278),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 1179766,
      "h": 94490460278,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(94490460278),
//--TRIMMABLE-BOUNDARY-START(34360918134),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1179766,
      "h": 34360918134,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918134),
//--TRIMMABLE-BOUNDARY-START(21476016246),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1179766,
      "h": 21476016246,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476016246)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147062),
    {
      "t": $.$macq.MACQI.EventCallbackSubscriber$$($.$macq.MACQ.PaginationState).$h,
      "n": "_totalItemCountChanged",
      "d": 1179766,
      "h": 4296147062,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147062)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048950),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179766,
      "h": 17181048950,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048950)
  ],
  "h": 1179766
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Paginator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Paginator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179766)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310838)
        $asm.$cls(`$macq.MACQ.QuickGrid<>`, (TGridItem) => $asm.$gt(`$macq.MACQ.QuickGrid<>`, [TGridItem], ($self) => class QuickGrid$$ extends $.$mac.MAC.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(335008759926)
            /*IQueryable<TGridItem>?*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(335008759926)
            
            //--TRIMMABLE-BOUNDARY-START(343598694518)
            /*GridItemsProvider<TGridItem>?*/ ItemsProvider = null;
            //--TRIMMABLE-BOUNDARY-END(343598694518)
            
            //--TRIMMABLE-BOUNDARY-START(180389937270)
            /*string?*/ Class = null;
            //--TRIMMABLE-BOUNDARY-END(180389937270)
            
            //--TRIMMABLE-BOUNDARY-START(545462157430)
            /*string?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(545462157430)
            
            //--TRIMMABLE-BOUNDARY-START(176094969974)
            /*RenderFragment?*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(176094969974)
            
            //--TRIMMABLE-BOUNDARY-START(549757124726)
            /*bool*/ Virtualize = false;
            //--TRIMMABLE-BOUNDARY-END(549757124726)
            
            //--TRIMMABLE-BOUNDARY-START(360778563702)
            /*int*/ OverscanCount = 0;
            //--TRIMMABLE-BOUNDARY-END(360778563702)
            
            //--TRIMMABLE-BOUNDARY-START(339303727222)
            /*float*/ ItemSize = 0;
            //--TRIMMABLE-BOUNDARY-END(339303727222)
            
            //--TRIMMABLE-BOUNDARY-START(330713792630)
            /*Func<TGridItem, object>*/ ItemKey = null;
            //--TRIMMABLE-BOUNDARY-END(330713792630)
            
            //--TRIMMABLE-BOUNDARY-START(365073530998)
            /*PaginationState?*/ Pagination = null;
            //--TRIMMABLE-BOUNDARY-END(365073530998)
            
            //--TRIMMABLE-BOUNDARY-START(163210068086)
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(163210068086)
            
            //--TRIMMABLE-BOUNDARY-START(403728236662)
            /*Func<TGridItem, string?>?*/ RowClass = null;
            //--TRIMMABLE-BOUNDARY-END(403728236662)
            
            //--TRIMMABLE-BOUNDARY-START(408023203958)
            /*IServiceProvider*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(408023203958)
            
            //--TRIMMABLE-BOUNDARY-START(347893661814)
            /*IJSRuntime*/ JS = null;
            //--TRIMMABLE-BOUNDARY-END(347893661814)
            
            //--TRIMMABLE-BOUNDARY-START(81605689462)
            /*ElementReference*/ _tableReference;
            //--TRIMMABLE-BOUNDARY-END(81605689462)
            
            //--TRIMMABLE-BOUNDARY-START(85900656758)
            /*Virtualize<(int, TGridItem)>?*/ _virtualizeComponent = null;
            //--TRIMMABLE-BOUNDARY-END(85900656758)
            
            //--TRIMMABLE-BOUNDARY-START(4296278134)
            /*int*/ _ariaBodyRowCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4296278134)
            
            //--TRIMMABLE-BOUNDARY-START(25771114614)
            /*ICollection<TGridItem>*/ _currentNonVirtualizedViewItems = null;
            //--TRIMMABLE-BOUNDARY-END(25771114614)
            
            //--TRIMMABLE-BOUNDARY-START(8591245430)
            /*IAsyncQueryExecutor?*/ _asyncQueryExecutor = null;
            //--TRIMMABLE-BOUNDARY-END(8591245430)
            
            //--TRIMMABLE-BOUNDARY-START(38656016502)
            /*InternalGridContext<TGridItem>*/ _internalGridContext = null;
            //--TRIMMABLE-BOUNDARY-END(38656016502)
            
            //--TRIMMABLE-BOUNDARY-START(21476147318)
            /*List<ColumnBase<TGridItem>>*/ _columns = null;
            //--TRIMMABLE-BOUNDARY-END(21476147318)
            
            //--TRIMMABLE-BOUNDARY-START(17181180022)
            /*bool*/ _collectingColumns = false;
            //--TRIMMABLE-BOUNDARY-END(17181180022)
            
            //--TRIMMABLE-BOUNDARY-START(34361049206)
            /*ColumnBase<TGridItem>?*/ _displayOptionsForColumn = null;
            //--TRIMMABLE-BOUNDARY-END(34361049206)
            
            //--TRIMMABLE-BOUNDARY-START(77310722166)
            /*ColumnBase<TGridItem>?*/ _sortByColumn = null;
            //--TRIMMABLE-BOUNDARY-END(77310722166)
            
            //--TRIMMABLE-BOUNDARY-START(73015754870)
            /*bool*/ _sortByAscending = false;
            //--TRIMMABLE-BOUNDARY-END(73015754870)
            
            //--TRIMMABLE-BOUNDARY-START(12886212726)
            /*bool*/ _checkColumnOptionsPosition = false;
            //--TRIMMABLE-BOUNDARY-END(12886212726)
            
            //--TRIMMABLE-BOUNDARY-START(47245951094)
            /*IJSObjectReference?*/ _jsModule = null;
            //--TRIMMABLE-BOUNDARY-END(47245951094)
            
            //--TRIMMABLE-BOUNDARY-START(42950983798)
            /*IJSObjectReference?*/ _jsEventDisposable = null;
            //--TRIMMABLE-BOUNDARY-END(42950983798)
            
            //--TRIMMABLE-BOUNDARY-START(64425820278)
            /*RenderFragment*/ _renderColumnHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(64425820278)
            
            //--TRIMMABLE-BOUNDARY-START(68720787574)
            /*RenderFragment*/ _renderNonVirtualizedRows = null;
            //--TRIMMABLE-BOUNDARY-END(68720787574)
            
            //--TRIMMABLE-BOUNDARY-START(55835885686)
            /*int?*/ _lastRefreshedPaginationStateHash = null;
            //--TRIMMABLE-BOUNDARY-END(55835885686)
            
            //--TRIMMABLE-BOUNDARY-START(51540918390)
            /*object?*/ _lastAssignedItemsOrProvider = null;
            //--TRIMMABLE-BOUNDARY-END(51540918390)
            
            //--TRIMMABLE-BOUNDARY-START(60130852982)
            /*CancellationTokenSource?*/ _pendingDataLoadCancellationTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(60130852982)
            
            //--TRIMMABLE-BOUNDARY-START(30066081910)
            /*EventCallbackSubscriber<PaginationState>*/ _currentPageItemsChanged = null;
            //--TRIMMABLE-BOUNDARY-END(30066081910)
            
            //--TRIMMABLE-BOUNDARY-START(90195624054)
            /*bool*/ _wasDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(90195624054)
            
            //--TRIMMABLE-BOUNDARY-START(154620133494)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154620133494);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._columns = new ($.$$.SCG.List$$($.$macq.MACQ.ColumnBase$$(TGridItem)))().$ctor$1();
                    this._internalGridContext = new ($.$macq.MACQI.InternalGridContext$$(TGridItem))().$ctor$1(this);
                    this._currentPageItemsChanged = new ($.$macq.MACQI.EventCallbackSubscriber$$($.$macq.MACQ.PaginationState))().$ctor$1($.$mac.MAC.EventCallback.Factory.Create$9($.$macq.MACQ.PaginationState, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.RefreshDataCoreAsync)));
                    this._renderColumnHeaders = new $.$mac.MAC.RenderFragment().$ctor(this, this.RenderColumnHeaders);
                    this._renderNonVirtualizedRows = new $.$mac.MAC.RenderFragment().$ctor(this, this.RenderNonVirtualizedRows);
                    /*var*/ let columnsFirstCollectedSubscriber = new ($.$macq.MACQI.EventCallbackSubscriber$$($.$$.S.Object))().$ctor$1($.$mac.MAC.EventCallback.Factory.Create$9($.$$.S.Object, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.RefreshDataCoreAsync)));
                    columnsFirstCollectedSubscriber.SubscribeOrMove(this._internalGridContext.ColumnsFirstCollected);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(154620133494)
            
            //--TRIMMABLE-BOUNDARY-START(356483596406)
            /*Task */ OnParametersSetAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483596406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._currentPageItemsChanged.SubscribeOrMove((this.Pagination?.CurrentPageItemsChanged ?? null));
                if (!(this.Items === null) && !(this.ItemsProvider === null))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN("QuickGrid")} requires one of ${$.$strNN("Items")} or ${$.$strNN("ItemsProvider")}, but both were specified.`);
                }
                /*var*/ let _newItemsOrItemsProvider = this.Items ?? $.$cast(this.ItemsProvider, $.$$.S.Object);
                /*var*/ let dataSourceHasChanged = _newItemsOrItemsProvider !== this._lastAssignedItemsOrProvider;
                if (dataSourceHasChanged)
                {
                    this._lastAssignedItemsOrProvider = _newItemsOrItemsProvider;
                    this._asyncQueryExecutor = $.$macq.MACQI.AsyncQueryExecutorSupplier.GetAsyncQueryExecutor(TGridItem, this.Services, this.Items);
                }
                /*var*/ let mustRefreshData = dataSourceHasChanged || ((this.Pagination?.GetHashCode() ?? null) !== this._lastRefreshedPaginationStateHash);
                return (this._columns.Count > 0 && mustRefreshData) ? this.RefreshDataCoreAsync() : $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(356483596406)
            
            //--TRIMMABLE-BOUNDARY-START(352188629110)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(352188629110);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender)
                    {
                        let $t1, $r1;
                        let $t3, $r3;
                        this._jsModule = ($t1 = $.$mj.MJ.JSRuntimeExtensions.InvokeAsync($.$mj.MJ.IJSObjectReference, this.JS, "import", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "./_content/Microsoft.AspNetCore.Components.QuickGrid/QuickGrid.razor.js" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (this._wasDisposed)
                        {
                            let $t2, $r2;
                            ($t2 = this._jsModule.S$IAsyncDisposable$DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        this._jsEventDisposable = ($t3 = $.$mj.MJ.JSObjectReferenceExtensions.InvokeAsync($.$mj.MJ.IJSObjectReference, this._jsModule, "init", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ this._tableReference ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    if (this._checkColumnOptionsPosition && !(this._displayOptionsForColumn === null))
                    {
                        this._checkColumnOptionsPosition = false;
                        /*Microsoft.JSInterop.IJSObjectReference?*/ let __ca1__;
                        _ = ((__ca1__ = this._jsModule) !== null ? $.$mj.MJ.JSObjectReferenceExtensions.InvokeVoidAsync(__ca1__, "checkColumnOptionsPosition", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ this._tableReference ], null, null)).AsTask() : null);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(352188629110)
            
            //--TRIMMABLE-BOUNDARY-START(158915100790)
            /*void */ AddColumn(/*ColumnBase<TGridItem>*/ column, /*SortDirection?*/ initialSortDirection, /*bool*/ isDefaultSortColumn)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._collectingColumns)
                {
                    this._columns.Add(column);
                    if (isDefaultSortColumn && this._sortByColumn === null && $.$$.S.Nullable$$($.$macq.MACQ.SortDirection).HasValue$get.call(initialSortDirection))
                    {
                        this._sortByColumn = column;
                        this._sortByAscending = $.$$.S.Nullable$$($.$macq.MACQ.SortDirection).Value$get.call(initialSortDirection) !== 2/*SortDirection.Descending*/;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915100790)
            
            //--TRIMMABLE-BOUNDARY-START(541167190134)
            /*void */ StartCollectingColumns()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167190134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._columns.Clear();
                this._collectingColumns = true;
            }
            //--TRIMMABLE-BOUNDARY-END(541167190134)
            
            //--TRIMMABLE-BOUNDARY-START(197569806454)
            /*void */ FinishCollectingColumns()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569806454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._collectingColumns = false;
            }
            //--TRIMMABLE-BOUNDARY-END(197569806454)
            
            //--TRIMMABLE-BOUNDARY-START(536872222838)
            /*Task */ SortByColumnAsync(/*ColumnBase<TGridItem>*/ column, /*SortDirection*/ direction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872222838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sortByAscending = (() =>
                {
                    if (direction === 1/*SortDirection.Ascending*/)
                    {
                        return true;
                    }
                    if (direction === 2/*SortDirection.Descending*/)
                    {
                        return false;
                    }
                    if (direction === 0/*SortDirection.Auto*/)
                    {
                        return this._sortByColumn !== column || !this._sortByAscending;
                    }
                    throw new $.$$.S.NotSupportedException().$ctor$12(`Unknown sort direction ${$.$strNN($.$$.S.Enum.ToStringT($.$macq.MACQ.SortDirection, $.$$.S.UInt32, direction))}`);
                })();
                this._sortByColumn = column;
                this.StateHasChanged();
                return this.RefreshDataAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(536872222838)
            
            //--TRIMMABLE-BOUNDARY-START(532577255542)
            /*Task */ ShowColumnOptionsAsync(/*ColumnBase<TGridItem>*/ column)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532577255542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._displayOptionsForColumn = column;
                this._checkColumnOptionsPosition = true;
                this.StateHasChanged();
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(532577255542)
            
            //--TRIMMABLE-BOUNDARY-START(326418825334)
            /*Task */ HideColumnOptionsAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418825334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._displayOptionsForColumn = null;
                this.StateHasChanged();
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(326418825334)
            
            //--TRIMMABLE-BOUNDARY-START(373663465590)
            /*Task *//*async*/  RefreshDataAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(373663465590);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.RefreshDataCoreAsync(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    this.StateHasChanged();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(373663465590)
            
            //--TRIMMABLE-BOUNDARY-START(377958432886)
            /*Task *//*async*/  RefreshDataCoreAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(377958432886);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._pendingDataLoadCancellationTokenSource?.Cancel();
                    /*var*/ let thisLoadCts = this._pendingDataLoadCancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    if (!(this._virtualizeComponent === null))
                    {
                        let $t5, $r5;
                        ($t5 = this._virtualizeComponent.RefreshDataAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        this._pendingDataLoadCancellationTokenSource = null;
                    }
                    else 
                    {
                        let $t6, $r6;
                        this._lastRefreshedPaginationStateHash = (this.Pagination?.GetHashCode() ?? null);
                        /*var*/ let startIndex = this.Pagination === null ? 0 : (((this.Pagination.CurrentPageIndex * this.Pagination.ItemsPerPage) | 0));
                        /*var*/ let request = new ($.$macq.MACQ.GridItemsProviderRequest$$(TGridItem))().$ctor$3(startIndex, (this.Pagination?.ItemsPerPage ?? null), this._sortByColumn, this._sortByAscending, thisLoadCts.Token);
                        /*var*/ let result = ($t6 = this.ResolveItemsRequestAsync(request), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        if (!thisLoadCts.IsCancellationRequested)
                        {
                            this._currentNonVirtualizedViewItems = result.Items;
                            this._ariaBodyRowCount = this._currentNonVirtualizedViewItems.SCG$ICollection$$$Count;
                            this.Pagination?.SetTotalItemCountAsync(result.TotalItemCount);
                            this._pendingDataLoadCancellationTokenSource = null;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(377958432886)
            
            //--TRIMMABLE-BOUNDARY-START(369368498294)
            /*ValueTask<ItemsProviderResult<(int, TGridItem)>> *//*async*/  ProvideVirtualizedItems(/*ItemsProviderRequest*/ request)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$macw.MACWV.ItemsProviderResult$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem))), $.$macw.MACWV.ItemsProviderResult$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)), async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(369368498294);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._lastRefreshedPaginationStateHash = (this.Pagination?.GetHashCode() ?? null);
                    ($t7 = $.$$.STT.Task.Delay$1(100), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    if (request.CancellationToken.IsCancellationRequested)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$macw.MACWV.ItemsProviderResult$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)))());
                    }
                    /*var*/ let startIndex = request.StartIndex;
                    /*var*/ let count = request.Count;
                    if (!(this.Pagination === null))
                    {
                        startIndex += ((this.Pagination.CurrentPageIndex * this.Pagination.ItemsPerPage) | 0);
                        count = $.$$.S.Math.Min$4(request.Count, ((this.Pagination.ItemsPerPage - request.StartIndex) | 0));
                    }
                    /*var*/ let providerRequest = new ($.$macq.MACQ.GridItemsProviderRequest$$(TGridItem))().$ctor$3(startIndex, count, this._sortByColumn, this._sortByAscending, request.CancellationToken);
                    /*var*/ let providerResult = ($t8 = this.ResolveItemsRequestAsync(providerRequest), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    if (!request.CancellationToken.IsCancellationRequested)
                    {
                        this._ariaBodyRowCount = this.Pagination === null ? providerResult.TotalItemCount : this.Pagination.ItemsPerPage;
                        this.Pagination?.SetTotalItemCountAsync(providerResult.TotalItemCount);
                        return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$macw.MACWV.ItemsProviderResult$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)))().$ctor$3($.$sl.SL.Enumerable.Select(TGridItem, $.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem), providerResult.Items, new ($.$$.S.Func$$$$(TGridItem, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)))().$ctor(this,  (/*x*/ x, /*i*/ i) =>
                        {
                            return $.$$.S.ValueTuple.Create$7($.$$.S.Int32, TGridItem, ((((i + request.StartIndex) | 0) + 2) | 0), x);
                        }, $glqBrb ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem).$h,"p":[{"n":"x","p":TGridItem?.$h??1572864},{"n":"i","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), this._ariaBodyRowCount));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$macw.MACWV.ItemsProviderResult$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)))());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(369368498294)
            
            //--TRIMMABLE-BOUNDARY-START(399433269366)
            /*ValueTask<GridItemsProviderResult<TGridItem>> *//*async*/  ResolveItemsRequestAsync(/*GridItemsProviderRequest<TGridItem>*/ request)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$macq.MACQ.GridItemsProviderResult$$(TGridItem)), $.$macq.MACQ.GridItemsProviderResult$$(TGridItem), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(399433269366);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!(this.ItemsProvider === null))
                    {
                        let $t9, $r9;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t9 = this.ItemsProvider.Invoke(request), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9))));
                    }
                    else if (!(this.Items === null))
                    {
                        let $t10, $r10;
                        let $t11, $r11;
                        /*var*/ let totalItemCount = this._asyncQueryExecutor === null ? $.$slq.SL.Queryable.Count$1(TGridItem, this.Items) : ($t10 = this._asyncQueryExecutor.MACQ$IAsyncQueryExecutor$CountAsync(TGridItem, this.Items), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        /*var*/ let result = $.$slq.SL.Queryable.Skip(TGridItem, request.ApplySorting(this.Items), request.StartIndex);
                        if ($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(request.Count))
                        {
                            result = $.$slq.SL.Queryable.Take(TGridItem, result, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(request.Count));
                        }
                        /*var*/ let resultArray = this._asyncQueryExecutor === null ? $.$sl.SL.Enumerable.ToArray(TGridItem, result) : ($t11 = this._asyncQueryExecutor.MACQ$IAsyncQueryExecutor$ToArrayAsync(TGridItem, result), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$macq.MACQ.GridItemsProviderResult.From(TGridItem, resultArray, totalItemCount));
                    }
                    else 
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$macq.MACQ.GridItemsProviderResult.From(TGridItem, $.$$.S.Array.Empty(TGridItem), 0));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(399433269366)
            
            //--TRIMMABLE-BOUNDARY-START(167505035382)
            /*string */ AriaSortValue(/*ColumnBase<TGridItem>*/ column)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167505035382);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._sortByColumn === column ? (this._sortByAscending ? "ascending" : "descending") : "none";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505035382)
            
            //--TRIMMABLE-BOUNDARY-START(188979871862)
            /*string? */ ColumnHeaderClass(/*ColumnBase<TGridItem>*/ column)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979871862);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._sortByColumn === column ? `${$.$strNN($.$macq.MACQ.QuickGrid$$(TGridItem).ColumnClass(column))} ${$.$strNN((this._sortByAscending ? "col-sort-asc" : "col-sort-desc"))}` : $.$macq.MACQ.QuickGrid$$(TGridItem).ColumnClass(column);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979871862)
            
            //--TRIMMABLE-BOUNDARY-START(322123858038)
            /*string */ GridClass()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123858038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let gridClass = `quickgrid ${$.$strNN(this.Class)} ${$.$strNN((this._pendingDataLoadCancellationTokenSource === null ? null : "loading"))}`;
                return $.$macq.MACF.AttributeUtilities.CombineClassNames(this.AdditionalAttributes, gridClass) ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(322123858038)
            
            //--TRIMMABLE-BOUNDARY-START(184684904566)
            static /*string? */ ColumnClass(/*ColumnBase<TGridItem>*/ column)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684904566);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        let $switch12 = column.Align;
                        if ($switch12 === 0/*Align.Start*/)
                        {
                            return `col-justify-start ${$.$strNN(column.Class)}`;
                        }
                        if ($switch12 === 1/*Align.Center*/)
                        {
                            return `col-justify-center ${$.$strNN(column.Class)}`;
                        }
                        if ($switch12 === 2/*Align.End*/)
                        {
                            return `col-justify-end ${$.$strNN(column.Class)}`;
                        }
                        if ($switch12 === 3/*Align.Left*/)
                        {
                            return `col-justify-left ${$.$strNN(column.Class)}`;
                        }
                        if ($switch12 === 4/*Align.Right*/)
                        {
                            return `col-justify-right ${$.$strNN(column.Class)}`;
                        }
                        return column.Class;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684904566)
            
            //--TRIMMABLE-BOUNDARY-START(193274839158)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274839158);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._wasDisposed = true;
                    this._currentPageItemsChanged.Dispose();
                    try
                    {
                        if (!(this._jsEventDisposable === null))
                        {
                            let $t13, $r13;
                            let $t14, $r14;
                            ($t13 = $.$mj.MJ.JSObjectReferenceExtensions.InvokeVoidAsync(this._jsEventDisposable, "stop", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                            ($t14 = this._jsEventDisposable.S$IAsyncDisposable$DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                        }
                        if (!(this._jsModule === null))
                        {
                            let $t15, $r15;
                            ($t15 = this._jsModule.S$IAsyncDisposable$DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                        }
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(193274839158)
            
            //--TRIMMABLE-BOUNDARY-START(171800002678)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800002678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$macq.MACQI.InternalGridContext$$(TGridItem)), 0);
                __builder.AddComponentParameter(1, "IsFixed", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddComponentParameter(2, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$macq.MACQI.InternalGridContext$$(TGridItem), this._internalGridContext));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    this.StartCollectingColumns();
                    __builder2.AddContent$1(4, this.ChildContent);
                    __builder2.AddMarkupContent(5, "\r\n    ");
                    __builder2.OpenComponent$1($.$macq.MACQI.Defer, 6);
                    __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        this.FinishCollectingColumns();
                        __builder3.OpenComponent$1($.$macq.MACQI.ColumnsCollectedNotifier$$(TGridItem), 8);
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(9, "\r\n\r\n        ");
                        __builder3.OpenElement(10, "table");
                        __builder3.AddAttribute$5(11, "theme", this.Theme);
                        __builder3.AddAttribute$4(12, "aria-rowcount", $.$box(((this._ariaBodyRowCount + 1) | 0), $.$$.S.Int32));
                        __builder3.AddAttribute$7($.$$.S.EventArgs, 13, "onclosecolumnoptions", $.$mac.MAC.EventCallback.Factory.Create$9($.$$.S.EventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.HideColumnOptionsAsync)));
                        __builder3.AddMultipleAttributes(14, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), this.AdditionalAttributes));
                        __builder3.AddAttribute$5(15, "class", this.GridClass());
                        __builder3.AddElementReferenceCapture(16, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this._tableReference = __value;
                        }, $GCmeFe ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder3.OpenElement(17, "thead");
                        __builder3.OpenElement(18, "tr");
                        __builder3.AddContent$1(19, this._renderColumnHeaders);
                        __builder3.CloseElement();
                        __builder3.CloseElement();
                        __builder3.AddMarkupContent(20, "\r\n            ");
                        __builder3.OpenElement(21, "tbody");
                        if (this.Virtualize)
                        {
                            __builder3.OpenComponent$1($.$macw.MACWV.Virtualize$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)), 22);
                            __builder3.AddComponentParameter(23, "ItemSize", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Single, this.ItemSize), $.$$.S.Single));
                            __builder3.AddComponentParameter(24, "OverscanCount", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, this.OverscanCount), $.$$.S.Int32));
                            __builder3.AddComponentParameter(25, "ItemsProvider", new ($.$macw.MACWV.ItemsProviderDelegate$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)))().$ctor(this, (this.ProvideVirtualizedItems)));
                            __builder3.AddComponentParameter(26, "ItemContent", new ($.$mac.MAC.RenderFragment$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)))().$ctor(this, ( (/*item*/ item) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                                {
                                    return this.RenderRow(builder, item.Item1, item.Item2);
                                }, $MBFhvc ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $vJlLdk ??= {"r":6881395,"p":[{"n":"item","p":$.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder3.AddComponentParameter(27, "Placeholder", new ($.$mac.MAC.RenderFragment$$($.$macw.MACWV.PlaceholderContext))().$ctor(this, ( (/*placeholderContext*/ placeholderContext) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                                {
                                    return this.RenderPlaceholderRow(builder, placeholderContext);
                                }, $cXiNPj ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $WAxBaf ??= {"r":6881395,"p":[{"n":"placeholderContext","p":7733365}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder3.AddComponentReferenceCapture(28, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this._virtualizeComponent = $.$cast(__value, $.$macw.MACWV.Virtualize$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)));
                            }, $NLRuBj ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }
                        else 
                        {
                            __builder3.AddContent$1(29, this._renderNonVirtualizedRows);
                        }
                        __builder3.CloseElement();
                        __builder3.CloseElement();
                    }), $tXpMuf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $nhNzSi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(171800002678)
            
            //--TRIMMABLE-BOUNDARY-START(386548367478)
            /*void */ RenderNonVirtualizedRows(/*RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548367478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let initialRowIndex = 2;
                /*var*/ let rowIndex = initialRowIndex;
                let $en16 = this._currentNonVirtualizedViewItems.SCG$IEnumerable$$$GetEnumerator();
                while ($en16.SC$1$IEnumerator$MoveNext())
                {
                    let item = $en16.SCG$IEnumerator$$$Current;
                    {
                        this.RenderRow(__builder, rowIndex++, item);
                    }
                }
                if (!(this.Pagination === null))
                {
                    while(rowIndex++ < ((initialRowIndex + this.Pagination.ItemsPerPage) | 0))
                    {
                        __builder.OpenElement(30, "tr");
                        let $en17 = this._columns.GetEnumerator();
                        while ($en17.MoveNext())
                        {
                            let col = $en17.Current;
                            {
                                __builder.OpenElement(31, "td");
                                __builder.AddAttribute$5(32, "class", $.$macq.MACQ.QuickGrid$$(TGridItem).ColumnClass(col));
                                __builder.SetKey(col);
                                __builder.CloseElement();
                            }
                        }
                        __builder.CloseElement();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(386548367478)
            
            //--TRIMMABLE-BOUNDARY-START(395138302070)
            /*void */ RenderRow(/*RenderTreeBuilder*/ __builder, /*int*/ rowIndex, /*TGridItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138302070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rowClass = (this.RowClass?.Invoke(item) ?? null);
                __builder.OpenElement(33, "tr");
                __builder.AddAttribute$4(34, "aria-rowindex", $.$box(rowIndex, $.$$.S.Int32));
                __builder.AddAttribute$5(35, "class", rowClass);
                __builder.SetKey(this.ItemKey.Invoke(item));
                let $en18 = this._columns.GetEnumerator();
                while ($en18.MoveNext())
                {
                    let col = $en18.Current;
                    {
                        __builder.OpenElement(36, "td");
                        __builder.AddAttribute$5(37, "class", $.$macq.MACQ.QuickGrid$$(TGridItem).ColumnClass(col));
                        __builder.SetKey(col);
                        col.CellContent(__builder, item);
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(395138302070)
            
            //--TRIMMABLE-BOUNDARY-START(390843334774)
            /*void */ RenderPlaceholderRow(/*RenderTreeBuilder*/ __builder, /*PlaceholderContext*/ placeholderContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843334774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(38, "tr");
                __builder.AddAttribute$4(39, "aria-rowindex", $.$box(((placeholderContext.Index + 1) | 0), $.$$.S.Int32));
                let $en19 = this._columns.GetEnumerator();
                while ($en19.MoveNext())
                {
                    let col = $en19.Current;
                    {
                        __builder.OpenElement(40, "td");
                        __builder.AddAttribute$5(41, "class", $.$strNN("grid-cell-placeholder" + " ") + $.$strNN(($.$macq.MACQ.QuickGrid$$(TGridItem).ColumnClass(col))));
                        __builder.SetKey(col);
                        col.RenderPlaceholderContent(__builder, placeholderContext);
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(390843334774)
            
            //--TRIMMABLE-BOUNDARY-START(382253400182)
            /*void */ RenderColumnHeaders(/*RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253400182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en20 = this._columns.GetEnumerator();
                while ($en20.MoveNext())
                {
                    let col = $en20.Current;
                    {
                        __builder.OpenElement(42, "th");
                        __builder.AddAttribute$5(43, "class", this.ColumnHeaderClass(col));
                        __builder.AddAttribute$5(44, "aria-sort", this.AriaSortValue(col));
                        __builder.AddAttribute$5(45, "scope", "col");
                        __builder.SetKey(col);
                        __builder.OpenElement(46, "div");
                        __builder.AddAttribute$5(47, "class", "col-header-content");
                        __builder.AddContent$1(48, col.HeaderContent);
                        __builder.CloseElement();
                        if (col === this._displayOptionsForColumn)
                        {
                            __builder.OpenElement(49, "div");
                            __builder.AddAttribute$5(50, "class", "col-options");
                            __builder.AddContent$1(51, col.ColumnOptions);
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(382253400182)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            //--TRIMMABLE-BOUNDARY-START(154620133494)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(154620133494)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(545462157430)
                this.Theme = "default";
                //--TRIMMABLE-BOUNDARY-END(545462157430)
                
                //--TRIMMABLE-BOUNDARY-START(360778563702)
                this.OverscanCount = 3;
                //--TRIMMABLE-BOUNDARY-END(360778563702)
                
                //--TRIMMABLE-BOUNDARY-START(339303727222)
                this.ItemSize = 50;
                //--TRIMMABLE-BOUNDARY-END(339303727222)
                
                //--TRIMMABLE-BOUNDARY-START(330713792630)
                this.ItemKey = new ($.$$.S.Func$$$(TGridItem, $.$$.S.Object))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$box(x, TGridItem);
                }, $noLWaj ??= {"r":131073,"p":[{"n":"x","p":TGridItem?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                //--TRIMMABLE-BOUNDARY-END(330713792630)
                
                //--TRIMMABLE-BOUNDARY-START(408023203958)
                this.Services = null;
                //--TRIMMABLE-BOUNDARY-END(408023203958)
                
                //--TRIMMABLE-BOUNDARY-START(347893661814)
                this.JS = null;
                //--TRIMMABLE-BOUNDARY-END(347893661814)
                
                //--TRIMMABLE-BOUNDARY-START(81605689462)
                this._tableReference = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(81605689462)
                
                //--TRIMMABLE-BOUNDARY-START(25771114614)
                this._currentNonVirtualizedViewItems = $.$$.S.Array.Empty(TGridItem);
                //--TRIMMABLE-BOUNDARY-END(25771114614)
                
            }
            static $H = 1310838;
            static $h = 1310838;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.ComponentBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(335008759926),
    {
      "p": $.$sle.SL.IQueryable$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 240519479414,
        "h": Number(BigInt(this.$h)|0x3800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 450972876918,
        "h": Number(BigInt(this.$h)|0x6900000000n),
        "f": 83886081
      },
      "n": "Items",
      "d": this.$h,
      "H": 335008759926,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335008759926),
//--TRIMMABLE-BOUNDARY-START(343598694518),
    {
      "p": $.$macq.MACQ.GridItemsProvider$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 257699348598,
        "h": Number(BigInt(this.$h)|0x3C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 468152746102,
        "h": Number(BigInt(this.$h)|0x6D00000000n),
        "f": 83886081
      },
      "n": "ItemsProvider",
      "d": this.$h,
      "H": 343598694518,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(343598694518),
//--TRIMMABLE-BOUNDARY-START(180389937270),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 223339610230,
        "h": Number(BigInt(this.$h)|0x3400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 433793007734,
        "h": Number(BigInt(this.$h)|0x6500000000n),
        "f": 83886081
      },
      "n": "Class",
      "d": this.$h,
      "H": 180389937270,
      "h": Number(BigInt(this.$h)|0x2A00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389937270),
//--TRIMMABLE-BOUNDARY-START(545462157430),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 309238956150,
        "h": Number(BigInt(this.$h)|0x4800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 519692353654,
        "h": Number(BigInt(this.$h)|0x7900000000n),
        "f": 83886081
      },
      "n": "Theme",
      "d": this.$h,
      "H": 545462157430,
      "h": Number(BigInt(this.$h)|0x7F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(545462157430),
//--TRIMMABLE-BOUNDARY-START(176094969974),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "H": 214749675638,
        "h": Number(BigInt(this.$h)|0x3200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 425203073142,
        "h": Number(BigInt(this.$h)|0x6300000000n),
        "f": 83886081
      },
      "n": "ChildContent",
      "d": this.$h,
      "H": 176094969974,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094969974),
//--TRIMMABLE-BOUNDARY-START(549757124726),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 317828890742,
        "h": Number(BigInt(this.$h)|0x4A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 528282288246,
        "h": Number(BigInt(this.$h)|0x7B00000000n),
        "f": 83886081
      },
      "n": "Virtualize",
      "d": this.$h,
      "H": 549757124726,
      "h": Number(BigInt(this.$h)|0x8000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(549757124726),
//--TRIMMABLE-BOUNDARY-START(360778563702),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 274879217782,
        "h": Number(BigInt(this.$h)|0x4000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 485332615286,
        "h": Number(BigInt(this.$h)|0x7100000000n),
        "f": 83886081
      },
      "n": "OverscanCount",
      "d": this.$h,
      "H": 360778563702,
      "h": Number(BigInt(this.$h)|0x5400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(360778563702),
//--TRIMMABLE-BOUNDARY-START(339303727222),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "H": 249109414006,
        "h": Number(BigInt(this.$h)|0x3A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 459562811510,
        "h": Number(BigInt(this.$h)|0x6B00000000n),
        "f": 83886081
      },
      "n": "ItemSize",
      "d": this.$h,
      "H": 339303727222,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339303727222),
//--TRIMMABLE-BOUNDARY-START(330713792630),
    {
      "p": $.$$.S.Func$$$(TGridItem, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 231929544822,
        "h": Number(BigInt(this.$h)|0x3600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 442382942326,
        "h": Number(BigInt(this.$h)|0x6700000000n),
        "f": 83886081
      },
      "n": "ItemKey",
      "d": this.$h,
      "H": 330713792630,
      "h": Number(BigInt(this.$h)|0x4D00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330713792630),
//--TRIMMABLE-BOUNDARY-START(365073530998),
    {
      "p": 1114230,
      "g": {
        "r": 0,
        "d": 0,
        "H": 283469152374,
        "h": Number(BigInt(this.$h)|0x4200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 493922549878,
        "h": Number(BigInt(this.$h)|0x7300000000n),
        "f": 83886081
      },
      "n": "Pagination",
      "d": this.$h,
      "H": 365073530998,
      "h": Number(BigInt(this.$h)|0x5500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(365073530998),
//--TRIMMABLE-BOUNDARY-START(163210068086),
    {
      "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 206159741046,
        "h": Number(BigInt(this.$h)|0x3000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 416613138550,
        "h": Number(BigInt(this.$h)|0x6100000000n),
        "f": 83886081
      },
      "n": "AdditionalAttributes",
      "d": this.$h,
      "H": 163210068086,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803,
          "n": [
            {
              "n": "CaptureUnmatchedValues",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210068086),
//--TRIMMABLE-BOUNDARY-START(403728236662),
    {
      "p": $.$$.S.Func$$$(TGridItem, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 292059086966,
        "h": Number(BigInt(this.$h)|0x4400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 502512484470,
        "h": Number(BigInt(this.$h)|0x7500000000n),
        "f": 83886081
      },
      "n": "RowClass",
      "d": this.$h,
      "H": 403728236662,
      "h": Number(BigInt(this.$h)|0x5E00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403728236662),
//--TRIMMABLE-BOUNDARY-START(408023203958),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "H": 300649021558,
        "h": Number(BigInt(this.$h)|0x4600000000n),
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 511102419062,
        "h": Number(BigInt(this.$h)|0x7700000000n),
        "f": 83886082
      },
      "n": "Services",
      "d": this.$h,
      "H": 408023203958,
      "h": Number(BigInt(this.$h)|0x5F00000000n),
      "f": 2097154,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(408023203958),
//--TRIMMABLE-BOUNDARY-START(347893661814),
    {
      "p": 524402,
      "g": {
        "r": 0,
        "d": 0,
        "H": 266289283190,
        "h": Number(BigInt(this.$h)|0x3E00000000n),
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 476742680694,
        "h": Number(BigInt(this.$h)|0x6F00000000n),
        "f": 83886082
      },
      "n": "JS",
      "d": this.$h,
      "H": 347893661814,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 2097154,
      "a": [
        {
          "t": 4259955,
          "c": 8594194547
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347893661814)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(356483596406),
    {
      "r": 178454529,
      "n": "OnParametersSetAsync",
      "d": this.$h,
      "H": 356483596406,
      "h": Number(BigInt(this.$h)|0x5300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(356483596406),
//--TRIMMABLE-BOUNDARY-START(352188629110),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": this.$h,
      "H": 352188629110,
      "h": Number(BigInt(this.$h)|0x5200000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(352188629110),
//--TRIMMABLE-BOUNDARY-START(158915100790),
    {
      "r": 65537,
      "p": [
        {
          "n": "column",
          "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h
        },
        {
          "n": "initialSortDirection",
          "p": $.$typeNullable($.$macq.MACQ.SortDirection).$h
        },
        {
          "n": "isDefaultSortColumn",
          "p": 262145
        }
      ],
      "n": "AddColumn",
      "d": this.$h,
      "H": 158915100790,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158915100790),
//--TRIMMABLE-BOUNDARY-START(541167190134),
    {
      "r": 65537,
      "n": "StartCollectingColumns",
      "d": this.$h,
      "H": 541167190134,
      "h": Number(BigInt(this.$h)|0x7E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(541167190134),
//--TRIMMABLE-BOUNDARY-START(197569806454),
    {
      "r": 65537,
      "n": "FinishCollectingColumns",
      "d": this.$h,
      "H": 197569806454,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197569806454),
//--TRIMMABLE-BOUNDARY-START(536872222838),
    {
      "r": 178454529,
      "p": [
        {
          "n": "column",
          "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h
        },
        {
          "n": "direction",
          "p": 1376374,
          "f": 65,
          "v": 0
        }
      ],
      "n": "SortByColumnAsync",
      "d": this.$h,
      "H": 536872222838,
      "h": Number(BigInt(this.$h)|0x7D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(536872222838),
//--TRIMMABLE-BOUNDARY-START(532577255542),
    {
      "r": 178454529,
      "p": [
        {
          "n": "column",
          "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "ShowColumnOptionsAsync",
      "d": this.$h,
      "H": 532577255542,
      "h": Number(BigInt(this.$h)|0x7C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(532577255542),
//--TRIMMABLE-BOUNDARY-START(326418825334),
    {
      "r": 178454529,
      "n": "HideColumnOptionsAsync",
      "d": this.$h,
      "H": 326418825334,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326418825334),
//--TRIMMABLE-BOUNDARY-START(373663465590),
    {
      "r": 178454529,
      "n": "RefreshDataAsync",
      "d": this.$h,
      "H": 373663465590,
      "h": Number(BigInt(this.$h)|0x5700000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(373663465590),
//--TRIMMABLE-BOUNDARY-START(377958432886),
    {
      "r": 178454529,
      "n": "RefreshDataCoreAsync",
      "d": this.$h,
      "H": 377958432886,
      "h": Number(BigInt(this.$h)|0x5800000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(377958432886),
//--TRIMMABLE-BOUNDARY-START(369368498294),
    {
      "r": $.$$.STT.ValueTask$$($.$macw.MACWV.ItemsProviderResult$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem))).$h,
      "p": [
        {
          "n": "request",
          "p": 7536757
        }
      ],
      "n": "ProvideVirtualizedItems",
      "d": this.$h,
      "H": 369368498294,
      "h": Number(BigInt(this.$h)|0x5600000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(369368498294),
//--TRIMMABLE-BOUNDARY-START(399433269366),
    {
      "r": $.$$.STT.ValueTask$$($.$macq.MACQ.GridItemsProviderResult$$(TGridItem)).$h,
      "p": [
        {
          "n": "request",
          "p": $.$macq.MACQ.GridItemsProviderRequest$$(TGridItem).$h
        }
      ],
      "n": "ResolveItemsRequestAsync",
      "d": this.$h,
      "H": 399433269366,
      "h": Number(BigInt(this.$h)|0x5D00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(399433269366),
//--TRIMMABLE-BOUNDARY-START(167505035382),
    {
      "r": 1310721,
      "p": [
        {
          "n": "column",
          "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "AriaSortValue",
      "d": this.$h,
      "H": 167505035382,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167505035382),
//--TRIMMABLE-BOUNDARY-START(188979871862),
    {
      "r": 1310721,
      "p": [
        {
          "n": "column",
          "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "ColumnHeaderClass",
      "d": this.$h,
      "H": 188979871862,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188979871862),
//--TRIMMABLE-BOUNDARY-START(322123858038),
    {
      "r": 1310721,
      "n": "GridClass",
      "d": this.$h,
      "H": 322123858038,
      "h": Number(BigInt(this.$h)|0x4B00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(322123858038),
//--TRIMMABLE-BOUNDARY-START(184684904566),
    {
      "r": 1310721,
      "p": [
        {
          "n": "column",
          "p": $.$macq.MACQ.ColumnBase$$(TGridItem).$h
        }
      ],
      "n": "ColumnClass",
      "d": this.$h,
      "H": 184684904566,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(184684904566),
//--TRIMMABLE-BOUNDARY-START(193274839158),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": this.$h,
      "H": 193274839158,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(193274839158),
//--TRIMMABLE-BOUNDARY-START(171800002678),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 171800002678,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(171800002678),
//--TRIMMABLE-BOUNDARY-START(386548367478),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "RenderNonVirtualizedRows",
      "d": this.$h,
      "H": 386548367478,
      "h": Number(BigInt(this.$h)|0x5A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(386548367478),
//--TRIMMABLE-BOUNDARY-START(395138302070),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "rowIndex",
          "p": 655361
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1572864
        }
      ],
      "n": "RenderRow",
      "d": this.$h,
      "H": 395138302070,
      "h": Number(BigInt(this.$h)|0x5C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(395138302070),
//--TRIMMABLE-BOUNDARY-START(390843334774),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "placeholderContext",
          "p": 7733365
        }
      ],
      "n": "RenderPlaceholderRow",
      "d": this.$h,
      "H": 390843334774,
      "h": Number(BigInt(this.$h)|0x5B00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390843334774),
//--TRIMMABLE-BOUNDARY-START(382253400182),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "RenderColumnHeaders",
      "d": this.$h,
      "H": 382253400182,
      "h": Number(BigInt(this.$h)|0x5900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(382253400182)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81605689462),
    {
      "t": 1900659,
      "n": "_tableReference",
      "d": this.$h,
      "H": 81605689462,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81605689462),
//--TRIMMABLE-BOUNDARY-START(85900656758),
    {
      "t": $.$macw.MACWV.Virtualize$$($.$$.S.ValueTuple$$$($.$$.S.Int32, TGridItem)).$h,
      "n": "_virtualizeComponent",
      "d": this.$h,
      "H": 85900656758,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85900656758),
//--TRIMMABLE-BOUNDARY-START(4296278134),
    {
      "t": 655361,
      "n": "_ariaBodyRowCount",
      "d": this.$h,
      "H": 4296278134,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278134),
//--TRIMMABLE-BOUNDARY-START(25771114614),
    {
      "t": $.$$.SCG.ICollection$$(TGridItem).$h,
      "n": "_currentNonVirtualizedViewItems",
      "d": this.$h,
      "H": 25771114614,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771114614),
//--TRIMMABLE-BOUNDARY-START(8591245430),
    {
      "t": 589942,
      "n": "_asyncQueryExecutor",
      "d": this.$h,
      "H": 8591245430,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245430),
//--TRIMMABLE-BOUNDARY-START(38656016502),
    {
      "t": $.$macq.MACQI.InternalGridContext$$(TGridItem).$h,
      "n": "_internalGridContext",
      "d": this.$h,
      "H": 38656016502,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656016502),
//--TRIMMABLE-BOUNDARY-START(21476147318),
    {
      "t": $.$$.SCG.List$$($.$macq.MACQ.ColumnBase$$(TGridItem)).$h,
      "n": "_columns",
      "d": this.$h,
      "H": 21476147318,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476147318),
//--TRIMMABLE-BOUNDARY-START(17181180022),
    {
      "t": 262145,
      "n": "_collectingColumns",
      "d": this.$h,
      "H": 17181180022,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181180022),
//--TRIMMABLE-BOUNDARY-START(34361049206),
    {
      "t": $.$macq.MACQ.ColumnBase$$(TGridItem).$h,
      "n": "_displayOptionsForColumn",
      "d": this.$h,
      "H": 34361049206,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361049206),
//--TRIMMABLE-BOUNDARY-START(77310722166),
    {
      "t": $.$macq.MACQ.ColumnBase$$(TGridItem).$h,
      "n": "_sortByColumn",
      "d": this.$h,
      "H": 77310722166,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310722166),
//--TRIMMABLE-BOUNDARY-START(73015754870),
    {
      "t": 262145,
      "n": "_sortByAscending",
      "d": this.$h,
      "H": 73015754870,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015754870),
//--TRIMMABLE-BOUNDARY-START(12886212726),
    {
      "t": 262145,
      "n": "_checkColumnOptionsPosition",
      "d": this.$h,
      "H": 12886212726,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886212726),
//--TRIMMABLE-BOUNDARY-START(47245951094),
    {
      "t": 458866,
      "n": "_jsModule",
      "d": this.$h,
      "H": 47245951094,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245951094),
//--TRIMMABLE-BOUNDARY-START(42950983798),
    {
      "t": 458866,
      "n": "_jsEventDisposable",
      "d": this.$h,
      "H": 42950983798,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950983798),
//--TRIMMABLE-BOUNDARY-START(64425820278),
    {
      "t": 6881395,
      "n": "_renderColumnHeaders",
      "d": this.$h,
      "H": 64425820278,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425820278),
//--TRIMMABLE-BOUNDARY-START(68720787574),
    {
      "t": 6881395,
      "n": "_renderNonVirtualizedRows",
      "d": this.$h,
      "H": 68720787574,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720787574),
//--TRIMMABLE-BOUNDARY-START(55835885686),
    {
      "t": $.$typeNullable($.$$.S.Int32).$h,
      "n": "_lastRefreshedPaginationStateHash",
      "d": this.$h,
      "H": 55835885686,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835885686),
//--TRIMMABLE-BOUNDARY-START(51540918390),
    {
      "t": 131073,
      "n": "_lastAssignedItemsOrProvider",
      "d": this.$h,
      "H": 51540918390,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540918390),
//--TRIMMABLE-BOUNDARY-START(60130852982),
    {
      "t": 170983425,
      "n": "_pendingDataLoadCancellationTokenSource",
      "d": this.$h,
      "H": 60130852982,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130852982),
//--TRIMMABLE-BOUNDARY-START(30066081910),
    {
      "t": $.$macq.MACQI.EventCallbackSubscriber$$($.$macq.MACQ.PaginationState).$h,
      "n": "_currentPageItemsChanged",
      "d": this.$h,
      "H": 30066081910,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066081910),
//--TRIMMABLE-BOUNDARY-START(90195624054),
    {
      "t": 262145,
      "n": "_wasDisposed",
      "d": this.$h,
      "H": 90195624054,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90195624054)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(154620133494),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 154620133494,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154620133494)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 1310838,
  "h": this.$h,
  "a": [
    {
      "t": 786547,
      "c": 8590721139,
      "a": [
        {
          "v": "TGridItem",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.QuickGrid<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}QuickGrid$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1310838)
        
        

        //--TRIMMABLE-BOUNDARY-START(262262)
        $asm.$cls(`$macq.MACQ.GridItemsProvider<>`, (TGridItem) => $asm.$gt(`$macq.MACQ.GridItemsProvider<>`, [TGridItem], ($self) => class GridItemsProvider$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*ValueTask<GridItemsProviderResult<TGridItem>>*/ Invoke(/**/ request)
            {
                return this.$nativeFunction.call(this.$target, request);
            }
            static $H = 262262;
            static $h = 262262;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131446),
    {
      "r": $.$$.STT.ValueTask$$($.$macq.MACQ.GridItemsProviderResult$$(TGridItem)).$h,
      "p": [
        {
          "n": "request",
          "p": $.$macq.MACQ.GridItemsProviderRequest$$(TGridItem).$h
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17180131446,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180131446),
//--TRIMMABLE-BOUNDARY-START(8590196854),
    {
      "r": 90570753,
      "p": [
        {
          "n": "request",
          "p": $.$macq.MACQ.GridItemsProviderRequest$$(TGridItem).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8590196854,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590196854),
//--TRIMMABLE-BOUNDARY-START(12885164150),
    {
      "r": $.$$.STT.ValueTask$$($.$macq.MACQ.GridItemsProviderResult$$(TGridItem)).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12885164150,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885164150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229558),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4295229558,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229558)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 262262,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.GridItemsProvider<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}GridItemsProvider$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262262)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507446)
        $asm.$cls(`$macq.MACQ.TemplateColumn<>`, (TGridItem) => $asm.$gt(`$macq.MACQ.TemplateColumn<>`, [TGridItem], ($self) => class TemplateColumn$$ extends $.$macq.MACQ.ColumnBase$$(TGridItem)
        {
            //--TRIMMABLE-BOUNDARY-START(30066278518)
            /*RenderFragment<TGridItem>*/ static EmptyChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(30066278518)
            
            //--TRIMMABLE-BOUNDARY-START(25771311222)
            /*RenderFragment<TGridItem>*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(25771311222)
            
            //--TRIMMABLE-BOUNDARY-START(73015951478)
            /*GridSort<TGridItem>?*/ SortBy = null;
            //--TRIMMABLE-BOUNDARY-END(73015951478)
            
            //--TRIMMABLE-BOUNDARY-START(21476343926)
            /*void */ CellContent(/*RenderTreeBuilder*/ builder, /*TGridItem*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343926);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return builder.AddContent$1(0, this.ChildContent.Invoke(item));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476343926)
            
            //--TRIMMABLE-BOUNDARY-START(51541114998)
            /*bool */ IsSortableByDefault()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541114998);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !(this.SortBy === null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541114998)
            
            //--TRIMMABLE-BOUNDARY-START(17181376630)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376630);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376630)
            
            //--TRIMMABLE-BOUNDARY-START(17181376630)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17181376630)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771311222)
                this.ChildContent = $.$macq.MACQ.TemplateColumn$$(TGridItem).EmptyChildContent;
                //--TRIMMABLE-BOUNDARY-END(25771311222)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886409334)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30066278518)
                    this.EmptyChildContent = new ($.$mac.MAC.RenderFragment$$(TGridItem))().$ctor(this,  (/**/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                        {
                        }, $rqTEpc ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }, $TZAUHg ??= {"r":6881395,"p":[{"n":"_","p":TGridItem?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(30066278518)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409334)
            
            static $H = 1507446;
            static $h = 1507446;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$macq.MACQ.ColumnBase$$(TGridItem); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771311222),
    {
      "p": $.$mac.MAC.RenderFragment$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38656213110,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 60131049590,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83886081
      },
      "n": "ChildContent",
      "d": this.$h,
      "H": 25771311222,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771311222),
//--TRIMMABLE-BOUNDARY-START(73015951478),
    {
      "p": $.$macq.MACQ.GridSort$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246147702,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 68720984182,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 83918849
      },
      "n": "SortBy",
      "d": this.$h,
      "H": 73015951478,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015951478)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476343926),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1572864
        }
      ],
      "n": "CellContent",
      "d": this.$h,
      "H": 21476343926,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16810000
    },
//--TRIMMABLE-BOUNDARY-END(21476343926),
//--TRIMMABLE-BOUNDARY-START(51541114998),
    {
      "r": 262145,
      "n": "IsSortableByDefault",
      "d": this.$h,
      "H": 51541114998,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51541114998)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066278518),
    {
      "t": $.$mac.MAC.RenderFragment$$(TGridItem).$h,
      "n": "EmptyChildContent",
      "d": this.$h,
      "H": 30066278518,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30066278518)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181376630),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 17181376630,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376630)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    }
  ],
  "r": 1,
  "H": 1507446,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.TemplateColumn<${TGridItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}TemplateColumn$${TGridItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1507446)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245302)
        $asm.$cls(`$macq.MACQ.PropertyColumn<,>`, (TGridItem, TProp) => $asm.$gt(`$macq.MACQ.PropertyColumn<,>`, [TGridItem, TProp], ($self) => class PropertyColumn$$$ extends $.$macq.MACQ.ColumnBase$$(TGridItem)
        {
            //--TRIMMABLE-BOUNDARY-START(8591179894)
            /*Expression<Func<TGridItem, TProp>>?*/ _lastAssignedProperty = null;
            //--TRIMMABLE-BOUNDARY-END(8591179894)
            
            //--TRIMMABLE-BOUNDARY-START(4296212598)
            /*Func<TGridItem, string?>?*/ _cellTextFunc = null;
            //--TRIMMABLE-BOUNDARY-END(4296212598)
            
            //--TRIMMABLE-BOUNDARY-START(12886147190)
            /*GridSort<TGridItem>?*/ _sortBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(12886147190)
            
            //--TRIMMABLE-BOUNDARY-START(68720722038)
            /*Expression<Func<TGridItem, TProp>>*/ Property = null;
            //--TRIMMABLE-BOUNDARY-END(68720722038)
            
            //--TRIMMABLE-BOUNDARY-START(34360983670)
            /*string?*/ Format = null;
            //--TRIMMABLE-BOUNDARY-END(34360983670)
            
            //--TRIMMABLE-BOUNDARY-START(98785493110)
            /*GridSort<TGridItem>? */ get SortBy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._sortBuilder;
            }
            /*GridSort<TGridItem>? */ set SortBy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12(`PropertyColumn generates this member internally. For custom sorting rules, see '${$.$strNN($.$macq.MACQ.TemplateColumn$$(TGridItem).$type.ToString())}'.`);
            }
            //--TRIMMABLE-BOUNDARY-END(98785493110)
            
            //--TRIMMABLE-BOUNDARY-START(64425754742)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._lastAssignedProperty !== this.Property)
                {
                    this._lastAssignedProperty = this.Property;
                    /*var*/ let compiledPropertyExpression = this.Property.Compile$3();
                    if (!$.$$.S.String.IsNullOrEmpty(this.Format))
                    {
                        /*var*/ let nullableUnderlyingTypeOrNull = $.$$.S.Nullable.GetUnderlyingType(TProp.$type);
                        if (!$.$$.S.IFormattable.$type.IsAssignableFrom(nullableUnderlyingTypeOrNull ?? TProp.$type))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`A '${$.$strNN("Format")}' parameter was supplied, but the type '${$.$strNN(TProp.$type.ToString())}' does not implement '${$.$strNN($.$$.S.IFormattable.$type.ToString())}'.`);
                        }
                        this._cellTextFunc = new ($.$$.S.Func$$$(TGridItem, $.$$.S.String))().$ctor(this,  (/*item*/ item) =>
                        {
                            return (($.$box(compiledPropertyExpression.Invoke(item), TProp))?.S$IFormattable$ToString(this.Format, null) ?? null);
                        }, $RiXMZg ??= {"r":1310721,"p":[{"n":"item","p":TGridItem?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }
                    else 
                    {
                        this._cellTextFunc = new ($.$$.S.Func$$$(TGridItem, $.$$.S.String))().$ctor(this,  (/*item*/ item) =>
                        {
                            /*TProp?*/ let __ca1__;
                            return ((__ca1__ = compiledPropertyExpression.Invoke(item)) !== null ? $.$dspc(__ca1__, TProp, ($t) => $t.ToString) : null);
                        }, $XHMhhh ??= {"r":1310721,"p":[{"n":"item","p":TGridItem?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }
                    this._sortBuilder = $.$macq.MACQ.GridSort$$(TGridItem).ByAscending(TProp, this.Property);
                }
                let memberExpression;
                if (this.Title === null && $.$is(this.Property.Body, $.$sle.SLE.MemberExpression, { set $v($v){ memberExpression = $v; } }))
                {
                    this.Title = memberExpression.Member.Name;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425754742)
            
            //--TRIMMABLE-BOUNDARY-START(30066016374)
            /*void */ CellContent(/*RenderTreeBuilder*/ builder, /*TGridItem*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066016374);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return builder.AddContent$4(0, this._cellTextFunc.Invoke(item));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066016374)
            
            //--TRIMMABLE-BOUNDARY-START(25771049078)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771049078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771049078)
            
            //--TRIMMABLE-BOUNDARY-START(25771049078)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25771049078)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(68720722038)
                this.Property = null;
                //--TRIMMABLE-BOUNDARY-END(68720722038)
                
            }
            static $H = 1245302;
            static $h = 1245302;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$macq.MACQ.ColumnBase$$(TGridItem); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720722038),
    {
      "p": $.$sle.SLE.Expression$$($.$$.S.Func$$$(TGridItem, TProp)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540852854,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 85900591222,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 83886081
      },
      "n": "Property",
      "d": this.$h,
      "H": 68720722038,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720722038),
//--TRIMMABLE-BOUNDARY-START(34360983670),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950918262,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 77310656630,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 83886081
      },
      "n": "Format",
      "d": this.$h,
      "H": 34360983670,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360983670),
//--TRIMMABLE-BOUNDARY-START(98785493110),
    {
      "p": $.$macq.MACQ.GridSort$$(TGridItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60130787446,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 94490525814,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83918849
      },
      "n": "SortBy",
      "d": this.$h,
      "H": 98785493110,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98785493110)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425754742),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": this.$h,
      "H": 64425754742,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64425754742),
//--TRIMMABLE-BOUNDARY-START(30066016374),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 7536755
        },
        {
          "n": "item",
          "p": TGridItem?.$h??1572864
        }
      ],
      "n": "CellContent",
      "d": this.$h,
      "H": 30066016374,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16810000
    },
//--TRIMMABLE-BOUNDARY-END(30066016374)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591179894),
    {
      "t": $.$sle.SLE.Expression$$($.$$.S.Func$$$(TGridItem, TProp)).$h,
      "n": "_lastAssignedProperty",
      "d": this.$h,
      "H": 8591179894,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179894),
//--TRIMMABLE-BOUNDARY-START(4296212598),
    {
      "t": $.$$.S.Func$$$(TGridItem, $.$$.S.String).$h,
      "n": "_cellTextFunc",
      "d": this.$h,
      "H": 4296212598,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212598),
//--TRIMMABLE-BOUNDARY-START(12886147190),
    {
      "t": $.$macq.MACQ.GridSort$$(TGridItem).$h,
      "n": "_sortBuilder",
      "d": this.$h,
      "H": 12886147190,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147190)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771049078),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 25771049078,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771049078)
  ],
  "s": [
    {
      "h": TGridItem?.$h??1572864,
      "n": "TGridItem"
    },
    {
      "h": TProp?.$h??1638400,
      "n": "TProp"
    }
  ],
  "r": 2,
  "H": 1245302,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.PropertyColumn<${TGridItem?.$fullName},${TProp?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}PropertyColumn$${TGridItem?.$getFullName(separator)}$${TProp?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1245302)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376374)
        $asm.$str(`$macq.MACQ.SortDirection`, ($self) => class SortDirection extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Auto = 0;
            static Ascending = 1;
            static Descending = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Auto": 0n,
                    "Ascending": 1n,
                    "Descending": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296343670)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343670)
            
            //--TRIMMABLE-BOUNDARY-START(4296343670)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296343670)
            
            static $h = 1376374;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886278262),
    {
      "t": 1376374,
      "n": "Auto",
      "d": 1376374,
      "h": 12886278262,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278262),
//--TRIMMABLE-BOUNDARY-START(8591310966),
    {
      "t": 1376374,
      "n": "Ascending",
      "d": 1376374,
      "h": 8591310966,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310966),
//--TRIMMABLE-BOUNDARY-START(17181245558),
    {
      "t": 1376374,
      "n": "Descending",
      "d": 1376374,
      "h": 17181245558,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245558)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343670),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376374,
      "h": 4296343670,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343670)
  ],
  "h": 1376374
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.SortDirection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}SortDirection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376374)
        
        

        //--TRIMMABLE-BOUNDARY-START(131190)
        $asm.$str(`$macq.MACQ.Align`, ($self) => class Align extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Start = 0;
            static Center = 1;
            static End = 2;
            static Left = 3;
            static Right = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Start": 0n,
                    "Center": 1n,
                    "End": 2n,
                    "Left": 3n,
                    "Right": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295098486)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098486)
            
            //--TRIMMABLE-BOUNDARY-START(4295098486)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098486)
            
            static $h = 131190;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25769934966),
    {
      "t": 131190,
      "n": "Start",
      "d": 131190,
      "h": 25769934966,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769934966),
//--TRIMMABLE-BOUNDARY-START(8590065782),
    {
      "t": 131190,
      "n": "Center",
      "d": 131190,
      "h": 8590065782,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065782),
//--TRIMMABLE-BOUNDARY-START(12885033078),
    {
      "t": 131190,
      "n": "End",
      "d": 131190,
      "h": 12885033078,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033078),
//--TRIMMABLE-BOUNDARY-START(17180000374),
    {
      "t": 131190,
      "n": "Left",
      "d": 131190,
      "h": 17180000374,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180000374),
//--TRIMMABLE-BOUNDARY-START(21474967670),
    {
      "t": 131190,
      "n": "Right",
      "d": 131190,
      "h": 21474967670,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474967670)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098486),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131190,
      "h": 4295098486,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098486)
  ],
  "h": 131190
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.QuickGrid.Align`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}QuickGrid${separator}Align`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131190)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.System.Linq.Queryable"));
})();
//--TRIMMABLE-BOUNDARY-END(118)
