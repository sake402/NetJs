
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.Web", 
    {"h":9,"f":"Microsoft.AspNetCore.Components.Web","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Support for rendering ASP.NET Core components for browsers.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft.AspNetCore.Components.Web","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"Microsoft.AspNetCore.Components.Web","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.AspNetCore.Components.Endpoints.Tests","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.AspNetCore.Components.Server.Tests","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.AspNetCore.Components.Web.Tests","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.IInputRadioValueProvider", ($self) => class IInputRadioValueProvider
        {
            static $h = 3604489;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"g":{"r":0,"d":0,"h":8593539081,"f":50331905},"n":"CurrentValue","o":"Microsoft$AspNetCore$Components$IInputRadioValueProvider$CurrentValue","d":3604489,"h":4298571785,"f":2097409}],"h":3604489}; }
            static get $fullName() { return `IInputRadioValueProvider`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.IJSComponentConfiguration", ($self) => class IJSComponentConfiguration
        {
            static $h = 5832713;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":6488073,"g":{"r":0,"d":0,"h":8595767305,"f":50331905},"n":"JSComponents","o":"Microsoft$AspNetCore$Components$Web$IJSComponentConfiguration$JSComponents","d":5832713,"h":4300800009,"f":2097409}],"h":5832713}; }
            static get $fullName() { return `IJSComponentConfiguration`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.IVirtualizeJsCallbacks", ($self) => class IVirtualizeJsCallbacks
        {
            static $h = 7667721;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"spacerSize","p":1114113},{"n":"spacerSeparation","p":1114113},{"n":"containerSize","p":1114113}],"n":"OnBeforeSpacerVisible","o":"Microsoft$AspNetCore$Components$Web$Virtualization$IVirtualizeJsCallbacks$OnBeforeSpacerVisible","d":7667721,"h":4302635017,"f":16777473},{"r":65537,"p":[{"n":"spacerSize","p":1114113},{"n":"spacerSeparation","p":1114113},{"n":"containerSize","p":1114113}],"n":"OnAfterSpacerVisible","o":"Microsoft$AspNetCore$Components$Web$Virtualization$IVirtualizeJsCallbacks$OnAfterSpacerVisible","d":7667721,"h":8597602313,"f":16777473}],"h":7667721}; }
            static get $fullName() { return `IVirtualizeJsCallbacks`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger", ($self) => class IErrorBoundaryLogger
        {
            static $h = 5767177;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":135987201,"p":[{"n":"exception","p":47251457}],"n":"LogErrorAsync","o":"Microsoft$AspNetCore$Components$Web$IErrorBoundaryLogger$LogErrorAsync","d":5767177,"h":4300734473,"f":16777473}],"h":5767177}; }
            static get $fullName() { return `IErrorBoundaryLogger`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.Internal.IInternalWebJSInProcessRuntime", ($self) => class IInternalWebJSInProcessRuntime
        {
            /*string */ Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS$1(/*in JSInvocationInfo*/ invocationInfo)
            {
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            static $h = 6357001;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1310721,"p":[{"n":"identifier","p":1310721},{"n":"argsJson","p":1310721},{"n":"resultType","p":2359326},{"n":"targetInstanceId","p":917505}],"n":"InvokeJS","o":"Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS","d":6357001,"h":4301324297,"f":16777473},{"r":1310721,"p":[{"n":"invocationInfo","p":1769502,"f":8}],"n":"InvokeJS","o":"Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS$1","d":6357001,"h":8596291593,"f":16777345}],"h":6357001,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $fullName() { return `IInternalWebJSInProcessRuntime`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.IFormValueMapper", ($self) => class IFormValueMapper
        {
            static $h = 3014665;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"valueType","p":142475265},{"n":"scopeName","p":1310721},{"n":"formName","p":1310721}],"n":"CanMap","o":"Microsoft$AspNetCore$Components$Forms$Mapping$IFormValueMapper$CanMap","d":3014665,"h":4297981961,"f":16777473},{"r":65537,"p":[{"n":"context","p":2949129}],"n":"Map","o":"Microsoft$AspNetCore$Components$Forms$Mapping$IFormValueMapper$Map","d":3014665,"h":8592949257,"f":16777473}],"h":3014665}; }
            static get $fullName() { return `IFormValueMapper`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.IInputFileJsCallbacks", ($self) => class IInputFileJsCallbacks
        {
            static $h = 1507337;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133169153,"p":[{"n":"files","p":$.$typeArray($.$macw.Microsoft.AspNetCore.Components.Forms.BrowserFile).$h}],"n":"NotifyChange","o":"Microsoft$AspNetCore$Components$Forms$IInputFileJsCallbacks$NotifyChange","d":1507337,"h":4296474633,"f":16777473}],"h":1507337}; }
            static get $fullName() { return `IInputFileJsCallbacks`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile", ($self) => class IBrowserFile
        {
            static $h = 1441801;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8591376393,"f":50331905},"n":"Name","o":"Microsoft$AspNetCore$Components$Forms$IBrowserFile$Name","d":1441801,"h":4296409097,"f":2097409},{"p":34471937,"g":{"r":0,"d":0,"h":17181310985,"f":50331905},"n":"LastModified","o":"Microsoft$AspNetCore$Components$Forms$IBrowserFile$LastModified","d":1441801,"h":12886343689,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":25771245577,"f":50331905},"n":"Size","o":"Microsoft$AspNetCore$Components$Forms$IBrowserFile$Size","d":1441801,"h":21476278281,"f":2097409},{"p":1310721,"g":{"r":0,"d":0,"h":34361180169,"f":50331905},"n":"ContentType","o":"Microsoft$AspNetCore$Components$Forms$IBrowserFile$ContentType","d":1441801,"h":30066212873,"f":2097409}],"m":[{"r":62193665,"p":[{"n":"maxAllowedSize","p":917505,"f":65,"v":512000},{"n":"cancellationToken","p":125829121,"f":65}],"n":"OpenReadStream","o":"Microsoft$AspNetCore$Components$Forms$IBrowserFile$OpenReadStream","d":1441801,"h":38656147465,"f":16777473}],"h":1441801}; }
            static get $fullName() { return `IBrowserFile`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider", ($self) => class AntiforgeryStateProvider extends $.$$.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 327689;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262153,"n":"GetAntiforgeryToken","d":327689,"h":4295294985,"f":16777473}],"c":[{"n":".ctor","o":"$ctor$1","d":327689,"h":8590262281,"f":16777220}],"h":327689}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AntiforgeryStateProvider`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer", ($self) => class WebRenderer extends $.$mac.Microsoft.AspNetCore.Components.RenderTree.Renderer
        {
            /*DotNetObjectReference<WebRendererInteropMethods>*/ _interopMethodsReference = null;
            /*int*/ _rendererId = 0;
            $ctor$3(/*IServiceProvider*/ serviceProvider, /*ILoggerFactory*/ loggerFactory, /*JsonSerializerOptions*/ jsonOptions, /*JSComponentInterop*/ jsComponentInterop)
            {
                super.$ctor$2(serviceProvider, loggerFactory);
                {
                    this._interopMethodsReference = $.$mj.Microsoft.JSInterop.DotNetObjectReference.Create($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer.WebRendererInteropMethods, new $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer.WebRendererInteropMethods().$ctor$1(this, jsonOptions, jsComponentInterop));
                    this._rendererId = this.GetWebRendererId();
                    jsComponentInterop.AttachToRenderer(this);
                    /*var*/ let jsRuntime = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mj.Microsoft.JSInterop.IJSRuntime, serviceProvider);
                    this.AttachWebRendererInterop(jsRuntime, jsonOptions, jsComponentInterop);
                }
                return this;
            }
            /*int */ get RendererId()
            {
                return this._rendererId;
            }
            /*int */ set RendererId(value)
            {
            }
            /*int */ GetWebRendererId()
            {
                return 0;
            }
            /*int */ AddRootComponent(/*Type*/ componentType, /*string*/ domElementSelector)
            {
                /*var*/ let component = this.InstantiateComponent(componentType);
                /*var*/ let componentId = this.AssignRootComponentId(component);
                this.AttachRootComponentToBrowser(componentId, domElementSelector);
                return componentId;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this._interopMethodsReference.Dispose();
                }
                super.Dispose$1(disposing);
            }
            /*void */ AttachWebRendererInterop(/*IJSRuntime*/ jsRuntime, /*JsonSerializerOptions*/ jsonOptions, /*JSComponentInterop*/ jsComponentInterop)
            {
                /*string*/ let JSMethodIdentifier = "Blazor._internal.attachWebRendererInterop";
                /*object[]*/ let args = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.Object.$type, [ $.$box(this._rendererId, $.$$.System.Int32), this._interopMethodsReference, jsComponentInterop.Configuration.JSComponentParametersByIdentifier, jsComponentInterop.Configuration.JSComponentIdentifiersByInitializer ], null, null);
                let inProcessRuntime;
                if ($.$is(jsRuntime, $.$macw.Microsoft.AspNetCore.Components.Web.Internal.IInternalWebJSInProcessRuntime, { set $v(v){ inProcessRuntime = v; } }))
                {
                    /*var*/ let newJsonOptions = new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$3(jsonOptions);
                    newJsonOptions.TypeInfoResolverChain.System$Collections$Generic$ICollection$$$Clear([$.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver]);
                    newJsonOptions.TypeInfoResolverChain.System$Collections$Generic$ICollection$$$Add($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.Default, [$.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver]);
                    newJsonOptions.TypeInfoResolverChain.System$Collections$Generic$ICollection$$$Add($.$macw.Microsoft.AspNetCore.Components.JsonConverterFactoryTypeInfoResolver$$($.$mj.Microsoft.JSInterop.DotNetObjectReference$$($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer.WebRendererInteropMethods)).Instance, [$.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver]);
                    /*var*/ let argsJson = $.$stj.System.Text.Json.JsonSerializer.Serialize$13($.$typeArray($.$$.System.Object), args, newJsonOptions);
                    inProcessRuntime.Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS(JSMethodIdentifier, argsJson, 3/*JSCallResultType.JSVoidResult*/, 0n);
                }
                else 
                {
                    $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(jsRuntime, JSMethodIdentifier, args).Preserve();
                }
            }
            static $_WebRendererInteropMethods;
            static get WebRendererInteropMethods()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer;
                return $cls.$_WebRendererInteropMethods ??= $asm.$ncls("$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer.WebRendererInteropMethods", ($self) => class WebRendererInteropMethods extends $.$$.System.Object
                {
                    /*WebRenderer*/ _renderer = null;
                    /*JsonSerializerOptions*/ _jsonOptions = null;
                    /*JSComponentInterop*/ _jsComponentInterop = null;
                    $ctor$1(/*WebRenderer*/ renderer, /*JsonSerializerOptions*/ jsonOptions, /*JSComponentInterop*/ jsComponentInterop)
                    {
                        super.$ctor();
                        {
                            this._renderer = renderer;
                            this._jsonOptions = jsonOptions;
                            this._jsComponentInterop = jsComponentInterop;
                        }
                        return this;
                    }
                    /*Task */ DispatchEventAsync(/*JsonElement*/ eventDescriptor, /*JsonElement*/ eventArgs)
                    {
                        /*var*/ let webEventData = $.$macw.Microsoft.AspNetCore.Components.Web.WebEventData.Parse$1(this._renderer, this._jsonOptions, eventDescriptor, eventArgs);
                        return this._renderer.DispatchEventAsync$1(webEventData.EventHandlerId, webEventData.EventFieldInfo, webEventData.EventArgs);
                    }
                    /*int */ AddRootComponent(/*string*/ identifier, /*string*/ domElementSelector)
                    {
                        return this._jsComponentInterop.AddRootComponent(identifier, domElementSelector);
                    }
                    /*void */ SetRootComponentParameters(/*int*/ componentId, /*int*/ parameterCount, /*JsonElement*/ parametersJson)
                    {
                        return this._jsComponentInterop.SetRootComponentParameters(componentId, parameterCount, parametersJson, this._jsonOptions);
                    }
                    /*void */ RemoveRootComponent(/*int*/ componentId)
                    {
                        return this._jsComponentInterop.RemoveRootComponent(componentId);
                    }
                    static $h = 3932169;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"eventDescriptor","p":2143171},{"n":"eventArgs","p":2143171}],"n":"DispatchEventAsync","d":3932169,"h":21478768649,"f":16777217,"a":[{"t":2818078,"c":17182687262}]},{"r":655361,"p":[{"n":"identifier","p":1310721},{"n":"domElementSelector","p":1310721}],"n":"AddRootComponent","d":3932169,"h":25773735945,"f":16777217,"a":[{"t":2818078,"c":17182687262}]},{"r":65537,"p":[{"n":"componentId","p":655361},{"n":"parameterCount","p":655361},{"n":"parametersJson","p":2143171}],"n":"SetRootComponentParameters","d":3932169,"h":30068703241,"f":16777217,"a":[{"t":2818078,"c":17182687262}]},{"r":65537,"p":[{"n":"componentId","p":655361}],"n":"RemoveRootComponent","d":3932169,"h":34363670537,"f":16777217,"a":[{"t":2818078,"c":17182687262}]}],"l":[{"t":3866633,"n":"_renderer","d":3932169,"h":4298899465,"f":4194306},{"t":3388355,"n":"_jsonOptions","d":3932169,"h":8593866761,"f":4194306},{"t":5898249,"n":"_jsComponentInterop","d":3932169,"h":12888834057,"f":4194306}],"c":[{"p":[{"n":"renderer","p":3866633},{"n":"jsonOptions","p":3388355},{"n":"jsComponentInterop","p":5898249}],"n":".ctor","o":"$ctor$1","d":3932169,"h":17183801353,"f":16777217}],"d":3866633,"h":3932169}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `WebRenderer.WebRendererInteropMethods`; }
                }, $cls, ($v) => $cls.$_WebRendererInteropMethods = $v);
            }
            static $h = 3866633;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8454152,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21478703113,"f":50331652},"s":{"r":0,"d":0,"h":25773670409,"f":83886084,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"The renderer ID can be assigned by overriding \u0027GetWebRendererId\u0027.","t":1310721}]}]},"n":"RendererId","d":3866633,"h":17183735817,"f":2097156}],"m":[{"r":655361,"n":"GetWebRendererId","d":3866633,"h":30068637705,"f":16777348},{"r":655361,"p":[{"n":"componentType","p":142475265},{"n":"domElementSelector","p":1310721}],"n":"AddRootComponent","d":3866633,"h":34363605001,"f":16777232},{"r":65537,"p":[{"n":"componentId","p":655361},{"n":"domElementSelector","p":1310721}],"n":"AttachRootComponentToBrowser","d":3866633,"h":38658572297,"f":16777476},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":3866633,"h":42953539593,"f":16809988},{"r":65537,"p":[{"n":"jsRuntime","p":524318},{"n":"jsonOptions","p":3388355},{"n":"jsComponentInterop","p":5898249}],"n":"AttachWebRendererInterop","d":3866633,"h":47248506889,"f":16777218}],"l":[{"t":$.$mj.Microsoft.JSInterop.DotNetObjectReference$$($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer.WebRendererInteropMethods).$h,"n":"_interopMethodsReference","d":3866633,"h":4298833929,"f":4194306},{"t":655361,"n":"_rendererId","d":3866633,"h":8593801225,"f":4194306}],"c":[{"p":[{"n":"serviceProvider","p":327717},{"n":"loggerFactory","p":1048597},{"n":"jsonOptions","p":3388355},{"n":"jsComponentInterop","p":5898249}],"n":".ctor","o":"$ctor$3","d":3866633,"h":12888768521,"f":16777217}],"i":[57540609,56950785],"j":[3932169],"h":3866633}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.RenderTree.Renderer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `WebRenderer`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Editor<>", (T) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.Editor<>", [T], ($self) => class Editor$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*HtmlFieldPrefix?*/ _value = null;
            /*T*/ Value = $.$default(T);
            /*Expression<Func<T>>*/ ValueExpression = null;
            /*EventCallback<T>*/ ValueChanged;
            /*HtmlFieldPrefix*/ FieldPrefix = null;
            /*bool */ get Microsoft$AspNetCore$Components$ICascadingValueSupplier$IsFixed()
            {
                return true;
            }
            /*string */ NameFor(/*LambdaExpression*/ expression)
            {
                return this._value.GetFieldName(expression);
            }
            /*void */ OnParametersSet()
            {
                if (this.ValueExpression === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} requires a value for the 'ValueExpression' ` + "parameter. Normally this is provided automatically when using 'bind-Value'.");
                }
                this._value = this.FieldPrefix !== null ? this.FieldPrefix.Combine(this.ValueExpression) : new $.$macw.Microsoft.AspNetCore.Components.Forms.HtmlFieldPrefix().$ctor$2(this.ValueExpression);
            }
            /*bool */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$CanSupplyValue(/*in CascadingParameterInfo*/ parameterInfo)
            {
                return $.$$.System.Type.op_Equality$1(parameterInfo.$v.PropertyType, $.$macw.Microsoft.AspNetCore.Components.Forms.HtmlFieldPrefix.$type);
            }
            /*object? */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$GetCurrentValue(/*object?*/ key, /*in CascadingParameterInfo*/ parameterInfo)
            {
                return (this).Microsoft$AspNetCore$Components$ICascadingValueSupplier$CanSupplyValue(parameterInfo) ? this._value : null;
            }
            /*void */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$Subscribe(/*ComponentState*/ subscriber, /*in CascadingParameterInfo*/ parameterInfo)
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12(`Cannot subscribe to a ${$.$macw.Microsoft.AspNetCore.Components.Forms.HtmlFieldPrefix.$type.Name}.`);
            }
            /*void */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$Unsubscribe(/*ComponentState*/ subscriber, /*in CascadingParameterInfo*/ parameterInfo)
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12(`Cannot subscribe to a ${$.$macw.Microsoft.AspNetCore.Components.Forms.HtmlFieldPrefix.$type.Name}.`);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value = $.$default(T);
                this.ValueExpression = null;
                this.ValueChanged = new ($.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T))();
                this.FieldPrefix = null;
            }
            static $h = 917513;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":83886081},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$(T)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":83886081},"n":"ValueExpression","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":83886081},"n":"ValueChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1376265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":83886082},"n":"FieldPrefix","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097154,"a":[{"t":524296,"c":21475360776}]},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331650},"n":"{2686984}.IsFixed","o":"Microsoft$AspNetCore$Components$ICascadingValueSupplier$IsFixed","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097154}],"m":[{"r":1310721,"p":[{"n":"expression","p":38506357}],"n":"NameFor","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777220},{"r":65537,"n":"OnParametersSet","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16809988}],"l":[{"t":1376265,"n":"_value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777220}],"i":[2752520,3145736,3080200,2686984],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$mac.Microsoft.AspNetCore.Components.ICascadingValueSupplier ]; }
            static get $fullName() { return `Editor<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputBase<>", (TValue) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.InputBase<>", [TValue], ($self) => class InputBase$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*EventHandler<ValidationStateChangedEventArgs>*/ _validationStateChangedHandler = null;
            /*bool*/ _hasInitializedParameters = false;
            /*bool*/ _parsingFailed = false;
            /*string?*/ _incomingValueBeforeParsing = null;
            /*string?*/ _formattedValueExpression = null;
            /*bool*/ _previousParsingAttemptFailed = false;
            /*ValidationMessageStore?*/ _parsingValidationMessages = null;
            /*Type?*/ _nullableUnderlyingType = null;
            /*bool*/ _shouldGenerateFieldNames = false;
            /*EditContext?*/ CascadedEditContext = null;
            /*HtmlFieldPrefix*/ FieldPrefix = null;
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            /*TValue?*/ Value = null;
            /*EventCallback<TValue>*/ ValueChanged;
            /*Expression<Func<TValue>>?*/ ValueExpression = null;
            /*string?*/ DisplayName = null;
            /*EditContext*/ EditContext = null;
            /*FieldIdentifier*/ FieldIdentifier;
            /*TValue? */ get CurrentValue()
            {
                return this.Value;
            }
            /*TValue? */ set CurrentValue(value)
            {
                /*var*/ let hasChanged = !$.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, this.Value);
                if (hasChanged)
                {
                    this._parsingFailed = false;
                    this.Value = value;
                    _ = this.ValueChanged.InvokeAsync$1(this.Value);
                    this.EditContext?.NotifyFieldChanged($.$ref(() => this.FieldIdentifier, ));
                }
            }
            /*string? */ get CurrentValueAsString()
            {
                return this._parsingFailed ? this._incomingValueBeforeParsing : this.FormatValueAsString(this.CurrentValue);
            }
            /*string? */ set CurrentValueAsString(value)
            {
                this._incomingValueBeforeParsing = value;
                this._parsingValidationMessages?.Clear();
                /*var*/ let parsedValue;
                /*var*/ let validationErrorMessage;
                if ($.$$.System.Type.op_Inequality$1(this._nullableUnderlyingType, null) && $.$$.System.String.IsNullOrEmpty(value))
                {
                    this._parsingFailed = false;
                    this.CurrentValue = $.$default(TValue);
                }
                else if (this.TryParseValueFromString(value, $.$ref(() => parsedValue, ($v) => parsedValue = $v, TValue), $.$ref(() => validationErrorMessage, ($v) => validationErrorMessage = $v, $.$$.System.String)))
                {
                    this._parsingFailed = false;
                    this.CurrentValue = parsedValue;
                }
                else 
                {
                    this._parsingFailed = true;
                    if (!(this.EditContext === null))
                    {
                        this._parsingValidationMessages ??= new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore().$ctor$1(this.EditContext);
                        this._parsingValidationMessages.Add$3($.$ref(() => this.FieldIdentifier, ), validationErrorMessage);
                        this.EditContext.NotifyFieldChanged($.$ref(() => this.FieldIdentifier, ));
                    }
                }
                if (this._parsingFailed || this._previousParsingAttemptFailed)
                {
                    this.EditContext?.NotifyValidationStateChanged();
                    this._previousParsingAttemptFailed = this._parsingFailed;
                }
            }
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._validationStateChangedHandler = new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs))().$ctor(this, this.OnValidateStateChanged);
                }
                return this;
            }
            /*string? */ FormatValueAsString(/*TValue?*/ value)
            {
                const $t1 = value;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
            }
            /*string */ get CssClass()
            {
                /*Microsoft.AspNetCore.Components.Forms.EditContext*/ let __ca1__;
                /*var*/ let fieldClass = ((__ca1__ = this.EditContext) !== null ? $.$macw.Microsoft.AspNetCore.Components.Forms.EditContextFieldClassExtensions.FieldCssClass(__ca1__, $.$ref(() => this.FieldIdentifier, )) : null);
                return $.$macw.Microsoft.AspNetCore.Components.Forms.AttributeUtilities.CombineClassNames(this.AdditionalAttributes, fieldClass) ?? $.$$.System.String.Empty;
            }
            /*string */ get NameAttributeValue()
            {
                /*var*/ let nameAttributeValue;
                if ((this.AdditionalAttributes?.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue("name", $.$ref(() => nameAttributeValue, ($v) => nameAttributeValue = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]) ?? null) ?? false)
                {
                    return $.$$.System.Convert.ToString$23(nameAttributeValue, $.$$.System.Globalization.CultureInfo.InvariantCulture) ?? $.$$.System.String.Empty;
                }
                if (this._shouldGenerateFieldNames)
                {
                    if (this._formattedValueExpression === null && !(this.ValueExpression === null))
                    {
                        this._formattedValueExpression = this.FieldPrefix !== null ? this.FieldPrefix.GetFieldName(this.ValueExpression) : $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatLambda$1(this.ValueExpression);
                    }
                    return this._formattedValueExpression ?? $.$$.System.String.Empty;
                }
                return $.$$.System.String.Empty;
            }
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                parameters.SetParameterProperties(this);
                if (!this._hasInitializedParameters)
                {
                    if (this.ValueExpression === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} requires a value for the 'ValueExpression' ` + `parameter. Normally this is provided automatically when using 'bind-Value'.`);
                    }
                    this.FieldIdentifier = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create(TValue, this.ValueExpression);
                    if (this.CascadedEditContext !== null)
                    {
                        this.EditContext = this.CascadedEditContext;
                        this.EditContext.add_OnValidationStateChanged(this._validationStateChangedHandler);
                        this._shouldGenerateFieldNames = this.EditContext.ShouldUseFieldIdentifiers;
                    }
                    else 
                    {
                        this._shouldGenerateFieldNames = !$.$$.System.OperatingSystem.IsBrowser();
                    }
                    this._nullableUnderlyingType = $.$$.System.Nullable.GetUnderlyingType(TValue.$type);
                    this._hasInitializedParameters = true;
                }
                else if (this.CascadedEditContext !== this.EditContext)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} does not support changing the ` + `${"EditContext"} dynamically.`);
                }
                this.UpdateAdditionalValidationAttributes();
                return super.SetParametersAsync($.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty);
            }
            /*void */ OnValidateStateChanged(/*object?*/ sender, /*ValidationStateChangedEventArgs*/ eventArgs)
            {
                this.UpdateAdditionalValidationAttributes();
                this.StateHasChanged();
            }
            /*void */ UpdateAdditionalValidationAttributes()
            {
                if (this.EditContext === null)
                {
                    return;
                }
                /*var*/ let hasAriaInvalidAttribute = this.AdditionalAttributes !== null && this.AdditionalAttributes.System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey("aria-invalid", [$.$$.System.String, $.$$.System.Object]);
                if ($.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, this.EditContext.GetValidationMessages$1(this.FieldIdentifier)))
                {
                    /*var*/ let attemptedValue = $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions.GetAttemptedValue(this.EditContext, this.NameAttributeValue);
                    if ($.$$.System.String.op_Inequality(attemptedValue, null))
                    {
                        this._parsingFailed = true;
                        this._incomingValueBeforeParsing = attemptedValue;
                    }
                    if (hasAriaInvalidAttribute)
                    {
                        return;
                    }
                    /*var*/ let additionalAttributes;
                    if ($.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue).ConvertToDictionary(this.AdditionalAttributes, $.$ref(() => additionalAttributes, ($v) => additionalAttributes = $v, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))))
                    {
                        this.AdditionalAttributes = additionalAttributes;
                    }
                    additionalAttributes.set_Item("aria-invalid", "true");
                }
                else if (hasAriaInvalidAttribute)
                {
                    if (this.AdditionalAttributes.System$Collections$Generic$IReadOnlyCollection$$$Count === 1)
                    {
                        this.AdditionalAttributes = null;
                    }
                    else 
                    {
                        /*var*/ let additionalAttributes;
                        if ($.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue).ConvertToDictionary(this.AdditionalAttributes, $.$ref(() => additionalAttributes, ($v) => additionalAttributes = $v, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))))
                        {
                            this.AdditionalAttributes = additionalAttributes;
                        }
                        additionalAttributes.Remove$1("aria-invalid");
                    }
                }
            }
            static /*bool */ ConvertToDictionary(/*IReadOnlyDictionary<string, object>?*/ source, /*out Dictionary<string, object>*/ result)
            {
                /*var*/ let newDictionaryCreated = true;
                let currentDictionary;
                if (source === null)
                {
                    result.$v = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                }
                else if ($.$is(source, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object), { set $v(v){ currentDictionary = v; } }))
                {
                    result.$v = currentDictionary;
                    newDictionaryCreated = false;
                }
                else 
                {
                    result.$v = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result.$v.Add(item.Key, item.Value);
                        }
                    }
                }
                return newDictionaryCreated;
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
            }
            /*void */ System$IDisposable$Dispose()
            {
                if (!(this.EditContext === null))
                {
                    this.EditContext.remove_OnValidationStateChanged(this._validationStateChangedHandler);
                }
                if (this._parsingValidationMessages !== null)
                {
                    this._parsingValidationMessages.Clear();
                    this.EditContext.NotifyValidationStateChanged();
                }
                this.Dispose(true);
            }
            //default member initializer
            constructor()
            {
                super();
                this.FieldPrefix = null;
                this.ValueChanged = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$(TValue));
                this.EditContext = null;
                this.FieldIdentifier = $.$default($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier);
            }
            static $h = 1572873;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":131082,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":83886082},"n":"CascadedEditContext","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097154,"a":[{"t":524296,"c":21475360776}]},{"p":1376265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":83886082},"n":"FieldPrefix","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097154,"a":[{"t":524296,"c":21475360776}]},{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1500000000n),"f":83886081},"n":"AdditionalAttributes","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":TValue?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1800000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1900000000n),"f":83886081},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$(TValue).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":83886081},"n":"ValueChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$(TValue)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2000000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2100000000n),"f":83886081},"n":"ValueExpression","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2500000000n),"f":83886081},"n":"DisplayName","d":this.$h,"h":Number(BigInt(this.$h)|0x2300000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":131082,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2800000000n),"f":50331652},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2900000000n),"f":83886084},"n":"EditContext","d":this.$h,"h":Number(BigInt(this.$h)|0x2700000000n),"f":2097156},{"p":655370,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2C00000000n),"f":50331664},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":83886096},"n":"FieldIdentifier","d":this.$h,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":2097168},{"p":TValue?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2F00000000n),"f":50331652},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3000000000n),"f":83886084},"n":"CurrentValue","d":this.$h,"h":Number(BigInt(this.$h)|0x2E00000000n),"f":2097156},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3200000000n),"f":50331652},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3300000000n),"f":83886084},"n":"CurrentValueAsString","d":this.$h,"h":Number(BigInt(this.$h)|0x3100000000n),"f":2097156},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3800000000n),"f":50331652},"n":"CssClass","d":this.$h,"h":Number(BigInt(this.$h)|0x3700000000n),"f":2097156},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3A00000000n),"f":50331652},"n":"NameAttributeValue","d":this.$h,"h":Number(BigInt(this.$h)|0x3900000000n),"f":2097156}],"m":[{"r":1310721,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"FormatValueAsString","d":this.$h,"h":Number(BigInt(this.$h)|0x3500000000n),"f":16777348},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":TValue?.$h??1507328,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":this.$h,"h":Number(BigInt(this.$h)|0x3600000000n),"f":16777476},{"r":133169153,"p":[{"n":"parameters","p":5767176}],"n":"SetParametersAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x3B00000000n),"f":16809985},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"eventArgs","p":1048586}],"n":"OnValidateStateChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x3C00000000n),"f":16777218},{"r":65537,"n":"UpdateAdditionalValidationAttributes","d":this.$h,"h":Number(BigInt(this.$h)|0x3D00000000n),"f":16777218},{"r":262145,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"result","p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,"f":2}],"n":"ConvertToDictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x3E00000000n),"f":16777250},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x3F00000000n),"f":16777348}],"l":[{"t":$.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h,"n":"_validationStateChangedHandler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":262145,"n":"_hasInitializedParameters","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":262145,"n":"_parsingFailed","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":1310721,"n":"_incomingValueBeforeParsing","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":1310721,"n":"_formattedValueExpression","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":262145,"n":"_previousParsingAttemptFailed","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":917514,"n":"_parsingValidationMessages","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194306},{"t":142475265,"n":"_nullableUnderlyingType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4194306},{"t":262145,"n":"_shouldGenerateFieldNames","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x3400000000n),"f":16777220}],"i":[2752520,3145736,3080200,57540609],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputBase<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.FieldCssClassProvider", ($self) => class FieldCssClassProvider extends $.$$.System.Object
        {
            /*FieldCssClassProvider*/ static Instance = null;
            /*string */ GetFieldCssClass(/*EditContext*/ editContext, /*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let isValid = !$.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, editContext.GetValidationMessages$1(fieldIdentifier.$v));
                if (editContext.IsModified$2(fieldIdentifier))
                {
                    return isValid ? "modified valid" : "modified invalid";
                }
                else 
                {
                    return isValid ? "valid" : "invalid";
                }
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macw.Microsoft.AspNetCore.Components.Forms.FieldCssClassProvider().$ctor$1();
                }
            }
            static $h = 1179657;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"editContext","p":131082},{"n":"fieldIdentifier","p":655370,"f":8}],"n":"GetFieldCssClass","d":1179657,"h":8591114249,"f":16777345}],"l":[{"t":1179657,"n":"Instance","d":1179657,"h":4296146953,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$1","d":1179657,"h":12886081545,"f":16777217}],"h":1179657}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FieldCssClassProvider`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.RenderTree.WebEventDescriptor", ($self) => class WebEventDescriptor extends $.$$.System.Object
        {
            /*ulong*/ EventHandlerId = 0n;
            /*string*/ EventName = null;
            /*EventFieldInfo?*/ EventFieldInfo = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.EventName = null;
            }
            static $h = 3801097;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":983041,"g":{"r":0,"d":0,"h":12888702985,"f":50331649},"s":{"r":0,"d":0,"h":17183670281,"f":83886081},"n":"EventHandlerId","d":3801097,"h":8593735689,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30068572169,"f":50331649},"s":{"r":0,"d":0,"h":34363539465,"f":83886081},"n":"EventName","d":3801097,"h":25773604873,"f":2097153},{"p":8192008,"g":{"r":0,"d":0,"h":47248441353,"f":50331649},"s":{"r":0,"d":0,"h":51543408649,"f":83886081},"n":"EventFieldInfo","d":3801097,"h":42953474057,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":3801097,"h":55838375945,"f":16777217}],"h":3801097}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebEventDescriptor`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.AttributeUtilities", ($self) => class AttributeUtilities
        {
            static /*string? */ CombineClassNames(/*IReadOnlyDictionary<string, object>?*/ additionalAttributes, /*string?*/ classNames)
            {
                /*var*/ let $class;
                if (additionalAttributes === null || !additionalAttributes.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue("class", $.$ref(() => $class, ($v) => $class = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    return classNames;
                }
                /*var*/ let classAttributeValue = $.$$.System.Convert.ToString$23($class, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                if ($.$$.System.String.IsNullOrEmpty(classAttributeValue))
                {
                    return classNames;
                }
                if ($.$$.System.String.IsNullOrEmpty(classNames))
                {
                    return classAttributeValue;
                }
                return `${classAttributeValue} ${classNames}`;
            }
            static $h = 458761;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"additionalAttributes","p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"classNames","p":1310721}],"n":"CombineClassNames","d":458761,"h":4295426057,"f":16777249}],"h":458761}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AttributeUtilities`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.ElementReferenceExtensions", ($self) => class ElementReferenceExtensions
        {
            static /*ValueTask */ FocusAsync$1(/*this ElementReference*/ elementReference)
            {
                return $.$macw.Microsoft.AspNetCore.Components.ElementReferenceExtensions.FocusAsync(elementReference, false);
            }
            static /*ValueTask */ FocusAsync(/*this ElementReference*/ elementReference, /*bool*/ preventScroll)
            {
                /*var*/ let jsRuntime = $.$macw.Microsoft.AspNetCore.Components.ElementReferenceExtensions.GetJSRuntime(elementReference);
                if (jsRuntime === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("No JavaScript runtime found.");
                }
                return $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(jsRuntime, "Blazor._internal.domWrapper.focus"/*DomWrapperInterop.Focus*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ elementReference, $.$box(preventScroll, $.$$.System.Boolean) ], null, null));
            }
            static /*IJSRuntime */ GetJSRuntime(/*this ElementReference*/ elementReference)
            {
                let context;
                if (!($.$is(elementReference.Context, $.$macw.Microsoft.AspNetCore.Components.WebElementReferenceContext, { set $v(v){ context = v; } })))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("ElementReference has not been configured correctly.");
                }
                return context.JSRuntime;
            }
            static $h = 196617;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":135987201,"p":[{"n":"elementReference","p":1900552}],"n":"FocusAsync","o":"@$1","d":196617,"h":4295163913,"f":16777249},{"r":135987201,"p":[{"n":"elementReference","p":1900552},{"n":"preventScroll","p":262145}],"n":"FocusAsync","d":196617,"h":8590131209,"f":16777249},{"r":524318,"p":[{"n":"elementReference","p":1900552}],"n":"GetJSRuntime","d":196617,"h":12885098505,"f":16777256}],"h":196617}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ElementReferenceExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.DomWrapperInterop", ($self) => class DomWrapperInterop
        {
            /*string*/ static Prefix = null;
            /*string*/ static Focus = null;
            /*string*/ static FocusBySelector = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Prefix = "Blazor._internal.domWrapper.";
                }
                {
                    this.Focus = "Blazor._internal.domWrapper.focus";
                }
                {
                    this.FocusBySelector = "Blazor._internal.domWrapper.focusBySelector";
                }
            }
            static $h = 131081;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Prefix","d":131081,"h":4295098377,"f":4194338},{"t":1310721,"n":"Focus","d":131081,"h":8590065673,"f":4194337},{"t":1310721,"n":"FocusBySelector","d":131081,"h":12885032969,"f":4194337}],"h":131081}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DomWrapperInterop`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryRequestToken", ($self) => class AntiforgeryRequestToken extends $.$$.System.Object
        {
            $ctor$1(/*string*/ value, /*string*/ formFieldName)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(formFieldName, "formFieldName");
                    this.Value = value;
                    this.FormFieldName = formFieldName;
                }
                return this;
            }
            /*string*/ Value = null;
            /*string*/ FormFieldName = null;
            static $h = 262153;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180131337,"f":50331649},"n":"Value","d":262153,"h":12885164041,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065033225,"f":50331649},"n":"FormFieldName","d":262153,"h":25770065929,"f":2097153}],"c":[{"p":[{"n":"value","p":1310721},{"n":"formFieldName","p":1310721}],"n":".ctor","o":"$ctor$1","d":262153,"h":4295229449,"f":16777217}],"h":262153}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AntiforgeryRequestToken`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.HtmlFieldPrefix", ($self) => class HtmlFieldPrefix extends $.$$.System.Object
        {
            /*LambdaExpression[]*/ _rest = null;
            $ctor$1(/*LambdaExpression*/ expression, /*params LambdaExpression[]*/ rest)
            {
                this.$ctor$2(expression);
                {
                    this._rest = rest;
                }
                return this;
            }
            /*HtmlFieldPrefix */ Combine(/*LambdaExpression*/ other)
            {
                const $t1 = this._rest;
                /*var*/ let restLength = $.$ifnn($t1, ($t) => $t.length) ?? 0;
                /*var*/ let length = ((restLength + 1) | 0);
                /*var*/ let expressions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.LambdaExpression), null, [length], null);
                for(/*var*/ let i = 0; i < restLength; i++)
                {
                    $.$$.System.Array.$WriteT1.call(expressions, $.$$.System.Array.$ReadT1.call(this._rest, i), i);
                }
                $.$$.System.Array.$WriteT1.call(expressions, other, ((length - 1) | 0));
                return new $.$macw.Microsoft.AspNetCore.Components.Forms.HtmlFieldPrefix().$ctor$1(this.initial, expressions);
            }
            /*string */ GetFieldName(/*LambdaExpression*/ expression)
            {
                /*var*/ let prefix = $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatLambda$1(this.initial);
                const $t1 = this._rest;
                /*var*/ let restLength = $.$ifnn($t1, ($t) => $t.length) ?? 0;
                for(/*var*/ let i = 0; i < restLength; i++)
                {
                    prefix = $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatLambda($.$$.System.Array.$ReadT1.call(this._rest, i), prefix);
                }
                return $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatLambda(expression, prefix);
            }
            //Begin primary constructor
            /*LambdaExpression*/ initial = null;
            $ctor$2(/*LambdaExpression*/$initial)
            {
                this.initial = $initial;
                return this
            }
            //End primary constructor
            //default member initializer
            constructor()
            {
                super();
                this._rest = $.$$.System.Array.Empty($.$sle.System.Linq.Expressions.LambdaExpression);
            }
            static $h = 1376265;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1376265,"p":[{"n":"other","p":38506357}],"n":"Combine","d":1376265,"h":21476212745,"f":16777217},{"r":1310721,"p":[{"n":"expression","p":38506357}],"n":"GetFieldName","d":1376265,"h":25771180041,"f":16777217}],"l":[{"t":38506357,"n":"\u003Cinitial\u003EP","d":1376265,"h":8591310857,"f":4194306},{"t":$.$typeArray($.$sle.System.Linq.Expressions.LambdaExpression).$h,"n":"_rest","d":1376265,"h":12886278153,"f":4194306}],"c":[{"p":[{"n":"initial","p":38506357}],"n":".ctor","o":"$ctor$2","d":1376265,"h":4296343561,"f":16777217},{"p":[{"n":"expression","p":38506357},{"n":"rest","p":$.$typeArray($.$sle.System.Linq.Expressions.LambdaExpression).$h,"f":16}],"n":".ctor","o":"$ctor$1","d":1376265,"h":17181245449,"f":16777224}],"h":1376265}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HtmlFieldPrefix`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputRadioContext", ($self) => class InputRadioContext extends $.$$.System.Object
        {
            /*IInputRadioValueProvider*/ _valueProvider = null;
            /*InputRadioContext?*/ ParentContext = null;
            /*EventCallback<ChangeEventArgs>*/ ChangeEventCallback;
            /*object? */ get CurrentValue()
            {
                return this._valueProvider.Microsoft$AspNetCore$Components$IInputRadioValueProvider$CurrentValue;
            }
            /*string?*/ GroupName = null;
            /*string?*/ FieldClass = null;
            $ctor$1(/*IInputRadioValueProvider*/ valueProvider, /*InputRadioContext?*/ parentContext, /*EventCallback<ChangeEventArgs>*/ changeEventCallback)
            {
                super.$ctor();
                {
                    this._valueProvider = valueProvider;
                    this.ParentContext = parentContext;
                    this.ChangeEventCallback = changeEventCallback;
                }
                return this;
            }
            /*InputRadioContext? */ FindContextInAncestors(/*string*/ groupName)
            {
                return $.$$.System.String.Equals$3(this.GroupName, groupName) ? this : (this.ParentContext?.FindContextInAncestors(groupName) ?? null);
            }
            //default member initializer
            constructor()
            {
                super();
                this.ChangeEventCallback = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs));
            }
            static $h = 2359305;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2359305,"g":{"r":0,"d":0,"h":17182228489,"f":50331649},"n":"ParentContext","d":2359305,"h":12887261193,"f":2097153},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs).$h,"g":{"r":0,"d":0,"h":30067130377,"f":50331649},"n":"ChangeEventCallback","d":2359305,"h":25772163081,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":38657064969,"f":50331649},"n":"CurrentValue","d":2359305,"h":34362097673,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51541966857,"f":50331649},"s":{"r":0,"d":0,"h":55836934153,"f":83886081},"n":"GroupName","d":2359305,"h":47246999561,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":68721836041,"f":50331649},"s":{"r":0,"d":0,"h":73016803337,"f":83886081},"n":"FieldClass","d":2359305,"h":64426868745,"f":2097153}],"m":[{"r":2359305,"p":[{"n":"groupName","p":1310721}],"n":"FindContextInAncestors","d":2359305,"h":81606737929,"f":16777217}],"l":[{"t":3604489,"n":"_valueProvider","d":2359305,"h":4297326601,"f":4194306}],"c":[{"p":[{"n":"valueProvider","p":3604489},{"n":"parentContext","p":2359305},{"n":"changeEventCallback","p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs).$h}],"n":".ctor","o":"$ctor$1","d":2359305,"h":77311770633,"f":16777217}],"h":2359305}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InputRadioContext`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputExtensions", ($self) => class InputExtensions
        {
            static /*bool */ TryParseSelectableValueFromString(TValue, /*this InputBase<TValue>*/ input, /*string?*/ value, /*out TValue*/ result, /*out string?*/ validationErrorMessage)
            {
                try
                {
                    /*var*/ let parsedValue;
                    if ($.$$.System.Type.op_Equality$1(TValue.$type, $.$$.System.Boolean.$type))
                    {
                        if ($.$macw.Microsoft.AspNetCore.Components.Forms.InputExtensions.TryConvertToBool(TValue, value, result))
                        {
                            validationErrorMessage.$v = null;
                            return true;
                        }
                    }
                    else if ($.$$.System.Type.op_Equality$1(TValue.$type, $.$typeNullable($.$$.System.Boolean).$type))
                    {
                        if ($.$macw.Microsoft.AspNetCore.Components.Forms.InputExtensions.TryConvertToNullableBool(TValue, value, result))
                        {
                            validationErrorMessage.$v = null;
                            return true;
                        }
                    }
                    else if ($.$mac.Microsoft.AspNetCore.Components.BindConverter.TryConvertTo(TValue, value, $.$$.System.Globalization.CultureInfo.CurrentCulture, $.$ref(() => parsedValue, ($v) => parsedValue = $v, TValue)))
                    {
                        result.$v = parsedValue;
                        validationErrorMessage.$v = null;
                        return true;
                    }
                    result.$v = $.$default(TValue);
                    validationErrorMessage.$v = `The ${input.DisplayName ?? input.FieldIdentifier.FieldName} field is not valid.`;
                    return false;
                }
                catch(ex)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(input))} does not support the type '${$.$$.System.Type.ToString.call(TValue.$type)}'.`, ex);
                }
            }
            static /*bool */ TryConvertToBool(TValue, /*string?*/ value, /*out TValue*/ result)
            {
                /*var*/ let bool;
                if ($.$$.System.Boolean.TryParse$1(value, $.$ref(() => bool, ($v) => bool = $v, $.$$.System.Boolean)))
                {
                    result.$v = $.$cast($.$box(bool, $.$$.System.Boolean), TValue);
                    return true;
                }
                result.$v = $.$default(TValue);
                return false;
            }
            static /*bool */ TryConvertToNullableBool(TValue, /*string?*/ value, /*out TValue*/ result)
            {
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    result.$v = $.$default(TValue);
                    return true;
                }
                return $.$macw.Microsoft.AspNetCore.Components.Forms.InputExtensions.TryConvertToBool(TValue, value, result);
            }
            static $h = 1835017;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"input","p":(TValue) => $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue).$h},{"n":"value","p":1310721},{"n":"result","p":(TValue) => TValue.$h,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"g":["TValue"],"n":"TryParseSelectableValueFromString","d":1835017,"h":4296802313,"f":16908321},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":(TValue) => TValue.$h,"f":2}],"g":["TValue"],"n":"TryConvertToBool","d":1835017,"h":8591769609,"f":16908322},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":(TValue) => TValue.$h,"f":2}],"g":["TValue"],"n":"TryConvertToNullableBool","d":1835017,"h":12886736905,"f":16908322}],"h":1835017}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InputExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.EditContextFieldClassExtensions", ($self) => class EditContextFieldClassExtensions
        {
            /*object*/ static FieldCssClassProviderKey = null;
            static /*string */ FieldCssClass$1(TField, /*this EditContext*/ editContext, /*Expression<Func<TField>>*/ accessor)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Forms.EditContextFieldClassExtensions.FieldCssClass(editContext, $.$ref(() => $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create(TField, accessor), ));
            }
            static /*string */ FieldCssClass(/*this EditContext*/ editContext, /*in FieldIdentifier*/ fieldIdentifier)
            {
                /*var*/ let customProvider;
                /*var*/ let provider = editContext.Properties.TryGetValue($.$macw.Microsoft.AspNetCore.Components.Forms.EditContextFieldClassExtensions.FieldCssClassProviderKey, $.$ref(() => customProvider, ($v) => customProvider = $v, $.$$.System.Object)) ? $.$cast(customProvider, $.$macw.Microsoft.AspNetCore.Components.Forms.FieldCssClassProvider) : $.$macw.Microsoft.AspNetCore.Components.Forms.FieldCssClassProvider.Instance;
                return provider.GetFieldCssClass(editContext, fieldIdentifier);
            }
            static /*void */ SetFieldCssClassProvider(/*this EditContext*/ editContext, /*FieldCssClassProvider*/ fieldCssClassProvider)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fieldCssClassProvider, "fieldCssClassProvider");
                editContext.Properties.set_Item($.$macw.Microsoft.AspNetCore.Components.Forms.EditContextFieldClassExtensions.FieldCssClassProviderKey, fieldCssClassProvider);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.FieldCssClassProviderKey = new $.$$.System.Object().$ctor();
                }
            }
            static $h = 786441;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"editContext","p":131082},{"n":"accessor","p":(TField) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$(TField)).$h}],"g":["TField"],"n":"FieldCssClass","o":"@$1","d":786441,"h":8590721033,"f":16908321},{"r":1310721,"p":[{"n":"editContext","p":131082},{"n":"fieldIdentifier","p":655370,"f":8}],"n":"FieldCssClass","d":786441,"h":12885688329,"f":16777249},{"r":65537,"p":[{"n":"editContext","p":131082},{"n":"fieldCssClassProvider","p":1179657}],"n":"SetFieldCssClassProvider","d":786441,"h":17180655625,"f":16777249}],"l":[{"t":131073,"n":"FieldCssClassProviderKey","d":786441,"h":4295753737,"f":4194338}],"h":786441}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EditContextFieldClassExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationExtensions", ($self) => class JSComponentConfigurationExtensions
        {
            static /*void */ RegisterForJavaScript$3(TComponent, /*this IJSComponentConfiguration*/ configuration, /*string*/ identifier)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationExtensions.RegisterForJavaScript$1(configuration, TComponent.$type, identifier);
            }
            static /*void */ RegisterForJavaScript$2(TComponent, /*this IJSComponentConfiguration*/ configuration, /*string*/ identifier, /*string*/ javaScriptInitializer)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationExtensions.RegisterForJavaScript(configuration, TComponent.$type, identifier, javaScriptInitializer);
            }
            static /*void */ RegisterForJavaScript$1(/*this IJSComponentConfiguration*/ configuration, /*Type*/ componentType, /*string*/ identifier)
            {
                return configuration.Microsoft$AspNetCore$Components$Web$IJSComponentConfiguration$JSComponents.Add$1(componentType, identifier);
            }
            static /*void */ RegisterForJavaScript(/*this IJSComponentConfiguration*/ configuration, /*Type*/ componentType, /*string*/ identifier, /*string*/ javaScriptInitializer)
            {
                return configuration.Microsoft$AspNetCore$Components$Web$IJSComponentConfiguration$JSComponents.Add(componentType, identifier, javaScriptInitializer);
            }
            static $h = 6422537;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"configuration","p":5832713},{"n":"identifier","p":1310721}],"g":["TComponent"],"n":"RegisterForJavaScript","o":"@$3","d":6422537,"h":4301389833,"f":16908321},{"r":65537,"p":[{"n":"configuration","p":5832713},{"n":"identifier","p":1310721},{"n":"javaScriptInitializer","p":1310721}],"g":["TComponent"],"n":"RegisterForJavaScript","o":"@$2","d":6422537,"h":8596357129,"f":16908321},{"r":65537,"p":[{"n":"configuration","p":5832713},{"n":"componentType","p":142475265},{"n":"identifier","p":1310721}],"n":"RegisterForJavaScript","o":"@$1","d":6422537,"h":12891324425,"f":16777249},{"r":65537,"p":[{"n":"configuration","p":5832713},{"n":"componentType","p":142475265},{"n":"identifier","p":1310721},{"n":"javaScriptInitializer","p":1310721}],"n":"RegisterForJavaScript","d":6422537,"h":17186291721,"f":16777249}],"h":6422537}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSComponentConfigurationExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.RenderMode", ($self) => class RenderMode
        {
            /*InteractiveServerRenderMode*/ static InteractiveServer = null;
            /*InteractiveWebAssemblyRenderMode*/ static InteractiveWebAssembly = null;
            /*InteractiveAutoRenderMode*/ static InteractiveAuto = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.InteractiveServer = new $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveServerRenderMode().$ctor$1();
                }
                {
                    this.InteractiveWebAssembly = new $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveWebAssemblyRenderMode().$ctor$1();
                }
                {
                    this.InteractiveAuto = new $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveAutoRenderMode().$ctor$1();
                }
            }
            static $h = 7208969;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":6225929,"g":{"r":0,"d":0,"h":12892110857,"f":50331681},"n":"InteractiveServer","d":7208969,"h":8597143561,"f":2097185},{"p":6291465,"g":{"r":0,"d":0,"h":25777012745,"f":50331681},"n":"InteractiveWebAssembly","d":7208969,"h":21482045449,"f":2097185},{"p":6160393,"g":{"r":0,"d":0,"h":38661914633,"f":50331681},"n":"InteractiveAuto","d":7208969,"h":34366947337,"f":2097185}],"h":7208969}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RenderMode`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore", ($self) => class JSComponentConfigurationStore extends $.$$.System.Object
        {
            /*Dictionary<string, Type>*/ _jsComponentTypesByIdentifier = null;
            /*Dictionary<string, JSComponentParameter[]>*/ JSComponentParametersByIdentifier = null;
            /*Dictionary<string, List<string>>*/ JSComponentIdentifiersByInitializer = null;
            /*void */ Add$1(/*Type*/ componentType, /*string*/ identifier)
            {
                /*var*/ let parameterTypes = $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.GetComponentParameters(componentType).ParameterInfoByName;
                /*var*/ let parameters = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter), null, [parameterTypes.Count], null);
                /*var*/ let index = 0;
                var $en2 = parameterTypes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let [ name, type ] = $.$destructure($en2.Current);
                    {
                        $.$$.System.Array.$WriteT1.call(parameters, new $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter().$ctor$3(name, type.Type), index++);
                    }
                }
                this._jsComponentTypesByIdentifier.Add(identifier, componentType);
                this.JSComponentParametersByIdentifier.Add(identifier, parameters);
            }
            /*bool */ TryGetComponentType(/*string*/ identifier, /*out Type?*/ componentType)
            {
                return this._jsComponentTypesByIdentifier.TryGetValue(identifier, componentType);
            }
            /*void */ Add(/*Type*/ componentType, /*string*/ identifier, /*string*/ javaScriptInitializer)
            {
                this.Add$1(componentType, identifier);
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(javaScriptInitializer, "javaScriptInitializer");
                /*var*/ let identifiersForInitializer;
                if (!this.JSComponentIdentifiersByInitializer.TryGetValue(javaScriptInitializer, $.$ref(() => identifiersForInitializer, ($v) => identifiersForInitializer = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))))
                {
                    identifiersForInitializer = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    this.JSComponentIdentifiersByInitializer.Add(javaScriptInitializer, identifiersForInitializer);
                }
                identifiersForInitializer.Add(identifier);
            }
            static $_JSComponentParameter;
            static get JSComponentParameter()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore;
                return $cls.$_JSComponentParameter ??= $asm.$nstr("$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter", ($self) => class JSComponentParameter extends $.$$.System.ValueType
                {
                    /*string*/ Name = null;
                    /*string*/ Type = null;
                    $ctor$3(/*string*/ name, /*Type*/ dotNetType)
                    {
                        super.$ctor$1();
                        {
                            this.Name = name;
                            this.Type = $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.GetJSType(dotNetType);
                        }
                        return this;
                    }
                    static /*string */ GetJSType(/*Type*/ dotNetType)
                    {
                        return (() =>
                        {
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$$.System.String.$type))
                                {
                                    return "string";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$$.System.Boolean.$type))
                                {
                                    return "boolean";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$typeNullable($.$$.System.Boolean).$type))
                                {
                                    return "boolean?";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$$.System.Decimal.$type))
                                {
                                    return "number";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$typeNullable($.$$.System.Decimal).$type))
                                {
                                    return "number?";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$$.System.Double.$type))
                                {
                                    return "number";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$typeNullable($.$$.System.Double).$type))
                                {
                                    return "number?";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$$.System.Single.$type))
                                {
                                    return "number";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$typeNullable($.$$.System.Single).$type))
                                {
                                    return "number?";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$$.System.Int32.$type))
                                {
                                    return "number";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$typeNullable($.$$.System.Int32).$type))
                                {
                                    return "number?";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$$.System.Int64.$type))
                                {
                                    return "number";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$$.System.Type.op_Equality$1(x, $.$typeNullable($.$$.System.Int64).$type))
                                {
                                    return "number?";
                                }
                            }
                            {
                                let x;
                                if (((x = dotNetType)) && $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.IsEventCallbackType(x))
                                {
                                    return "eventcallback";
                                }
                            }
                            return "object";
                        })();
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Name = this.Name;
                        copy.Type = this.Type;
                        return copy;
                    }
                    static $h = 6553609;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12891455497,"f":50331649},"n":"Name","d":6553609,"h":8596488201,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":25776357385,"f":50331649},"n":"Type","d":6553609,"h":21481390089,"f":2097153}],"m":[{"r":1310721,"p":[{"n":"dotNetType","p":142475265}],"n":"GetJSType","d":6553609,"h":34366291977,"f":16777250}],"c":[{"p":[{"n":"name","p":1310721},{"n":"dotNetType","p":142475265}],"n":".ctor","o":"$ctor$3","d":6553609,"h":30071324681,"f":16777217},{"n":".ctor","o":"$ctor$2","d":6553609,"h":38661259273,"f":16777217}],"d":6488073,"h":6553609}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `JSComponentConfigurationStore.JSComponentParameter`; }
                }, $cls, ($v) => $cls.$_JSComponentParameter = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._jsComponentTypesByIdentifier = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Type))().$ctor$6($.$$.System.StringComparer.Ordinal);
                this.JSComponentParametersByIdentifier = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)))().$ctor$6($.$$.System.StringComparer.Ordinal);
                this.JSComponentIdentifiersByInitializer = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor$6($.$$.System.StringComparer.Ordinal);
            }
            static $h = 6488073;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)).$h,"g":{"r":0,"d":0,"h":17186357257,"f":50331656},"n":"JSComponentParametersByIdentifier","d":6488073,"h":12891389961,"f":2097160},{"p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)).$h,"g":{"r":0,"d":0,"h":30071259145,"f":50331656},"n":"JSComponentIdentifiersByInitializer","d":6488073,"h":25776291849,"f":2097160}],"m":[{"r":65537,"p":[{"n":"componentType","p":142475265},{"n":"identifier","p":1310721}],"n":"Add","o":"@$1","d":6488073,"h":34366226441,"f":16777224},{"r":262145,"p":[{"n":"identifier","p":1310721},{"n":"componentType","p":142475265,"f":2}],"n":"TryGetComponentType","d":6488073,"h":38661193737,"f":16777224},{"r":65537,"p":[{"n":"componentType","p":142475265},{"n":"identifier","p":1310721},{"n":"javaScriptInitializer","p":1310721}],"n":"Add","d":6488073,"h":42956161033,"f":16777224}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Type).$h,"n":"_jsComponentTypesByIdentifier","d":6488073,"h":4301455369,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":6488073,"h":51546095625,"f":16777217}],"j":[6553609],"h":6488073}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSComponentConfigurationStore`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions", ($self) => class RenderTreeBuilderExtensions
        {
            static /*void */ AddAttributeIfNotNullOrEmpty(/*this RenderTreeBuilder*/ builder, /*int*/ sequence, /*string*/ name, /*string?*/ value)
            {
                if (!$.$$.System.String.IsNullOrEmpty(value))
                {
                    builder.AddAttribute$3(sequence, name, value);
                }
            }
            static $h = 3735561;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"sequence","p":655361},{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"AddAttributeIfNotNullOrEmpty","d":3735561,"h":4298702857,"f":16777249}],"h":3735561}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RenderTreeBuilderExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter", ($self) => class ExpressionFormatter
        {
            /*Static constructor*/ static $cctor()
            {
                if ($.$mac.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$mac.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.System.Action().$ctor($.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter, $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.ClearCache));
                }
            }
            /*int*/ static StackAllocBufferSize = 128;
            static $_CapturedValueFormatter;
            static get CapturedValueFormatter()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter;
                return $cls.$_CapturedValueFormatter ??= $asm.$ncls("$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter", ($self) => class CapturedValueFormatter extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/*$.$$.System.Object*/ closure, /**/ builder)
                    {
                        return this.$nativeFunction.call(this.$target, closure, builder);
                    }
                    static $h = 1048585;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":3276809,"f":4}],"n":"Invoke","d":1048585,"h":8590983177,"f":16777345},{"r":57016321,"p":[{"n":"closure","p":131073},{"n":"builder","p":3276809,"f":4},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":1048585,"h":12885950473,"f":16777345},{"r":65537,"p":[{"n":"builder","p":3276809,"f":4},{"n":"result","p":57016321}],"n":"EndInvoke","d":1048585,"h":17180917769,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1048585,"h":4296015881,"f":16777217}],"i":[57212929,113246209],"d":983049,"h":1048585}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `ExpressionFormatter.CapturedValueFormatter`; }
                }, $cls, ($v) => $cls.$_CapturedValueFormatter = $v);
            }
            /*ConcurrentDictionary<MemberInfo, CapturedValueFormatter>*/ static s_capturedValueFormatterCache = null;
            /*ConcurrentDictionary<MethodInfo, MethodInfoData>*/ static s_methodInfoDataCache = null;
            static /*void */ ClearCache()
            {
                $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.Clear();
                $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.Clear();
            }
            static /*string */ FormatLambda$1(/*LambdaExpression*/ expression)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatLambda(expression, null);
            }
            static /*string */ FormatLambda(/*LambdaExpression*/ expression, /*string?*/ prefix)
            {
                /*var*/ let builder = new $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 128/*StackAllocBufferSize*/, null));
                /*var*/ let node = expression.Body;
                /*var*/ let wasLastExpressionMemberAccess = false;
                /*var*/ let wasLastExpressionIndexer = false;
                while(!(node === null))
                {
                    let $switch1 = node.NodeType;
                    switch($switch1)
                    {
                        case 9/*ExpressionType.Constant*/:
                        /*var*/ let constantExpression = $.$cast(node, $.$sle.System.Linq.Expressions.ConstantExpression);
                        node = null;
                        break;
                        case 6/*ExpressionType.Call*/:
                        /*var*/ let methodCallExpression = $.$cast(node, $.$sle.System.Linq.Expressions.MethodCallExpression);
                        if (!$.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.IsSingleArgumentIndexer(methodCallExpression))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("Method calls cannot be formatted.");
                        }
                        node = methodCallExpression.Object;
                        if ($.$$.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                        }
                        wasLastExpressionIndexer = true;
                        builder.InsertFront$1($.$$.System.String.op_Implicit("]"));
                        $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(methodCallExpression.Arguments.get_Item(0), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                        builder.InsertFront$1($.$$.System.String.op_Implicit("["));
                        break;
                        case 5/*ExpressionType.ArrayIndex*/:
                        /*var*/ let binaryExpression = $.$cast(node, $.$sle.System.Linq.Expressions.BinaryExpression);
                        node = binaryExpression.Left;
                        if ($.$$.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            wasLastExpressionMemberAccess = false;
                            builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                        }
                        builder.InsertFront$1($.$$.System.String.op_Implicit("]"));
                        $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(binaryExpression.Right, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                        builder.InsertFront$1($.$$.System.String.op_Implicit("["));
                        wasLastExpressionIndexer = true;
                        break;
                        case 23/*ExpressionType.MemberAccess*/:
                        /*var*/ let memberExpression = $.$cast(node, $.$sle.System.Linq.Expressions.MemberExpression);
                        node = memberExpression.Expression;
                        if ($.$$.System.String.op_Inequality(prefix, null) && $.$is(node, $.$sle.System.Linq.Expressions.ConstantExpression))
                        {
                            break;
                        }
                        if (wasLastExpressionMemberAccess)
                        {
                            builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                        }
                        wasLastExpressionMemberAccess = true;
                        wasLastExpressionIndexer = false;
                        /*var*/ let name = ($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$8($.$srsp.System.Runtime.Serialization.DataMemberAttribute, memberExpression.Member)?.Name ?? null) ?? memberExpression.Member.Name;
                        builder.InsertFront$1($.$$.System.String.op_Implicit(name));
                        break;
                        default:
                        node = null;
                        break;
                    }
                }
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    if (!builder.Empty && !wasLastExpressionIndexer)
                    {
                        builder.InsertFront$1($.$$.System.String.op_Implicit("."));
                    }
                    builder.InsertFront$1($.$$.System.String.op_Implicit(prefix));
                }
                /*var*/ let result = $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.call(builder);
                builder.Dispose();
                return result;
            }
            static /*bool */ IsSingleArgumentIndexer(/*Expression*/ expression)
            {
                let methodExpression;
                if (!$.$is(expression, $.$sle.System.Linq.Expressions.MethodCallExpression, { set $v(v){ methodExpression = v; } }) || methodExpression.Arguments.Count !== 1)
                {
                    return false;
                }
                /*var*/ let methodInfoData = $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.GetOrCreateMethodInfoData(methodExpression.Method);
                return methodInfoData.IsSingleArgumentIndexer;
            }
            static /*MethodInfoData */ GetOrCreateMethodInfoData(/*MethodInfo*/ methodInfo)
            {
                /*var*/ let methodInfoData;
                if (!$.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.TryGetValue(methodInfo, $.$ref(() => methodInfoData, ($v) => methodInfoData = $v, $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData)))
                {
                    methodInfoData = GetMethodInfoData(methodInfo);
                    $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_methodInfoDataCache.set_Item(methodInfo, methodInfoData);
                }
                return methodInfoData;
                /*static MethodInfoData*/  function GetMethodInfoData(/*MethodInfo*/ methodInfo)
                {
                    /*var*/ let declaringType = methodInfo.DeclaringType;
                    if (declaringType === null)
                    {
                        return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    /*var*/ let defaultMember = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$7($.$$.System.Reflection.DefaultMemberAttribute, declaringType, true);
                    if (defaultMember === null)
                    {
                        return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    /*var*/ let runtimeProperties = $.$$.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperties(declaringType);
                    if (runtimeProperties === null)
                    {
                        return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                    }
                    var $en3 = runtimeProperties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var property = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.Equals$2(defaultMember.MemberName, property.Name, 4/*StringComparison.Ordinal*/) && $.$$.System.Reflection.MethodInfo.op_Equality$2(property.GetMethod, methodInfo))
                            {
                                return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(true);
                            }
                        }
                    }
                    return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData().$ctor$3(false);
                }
            }
            static /*void */ FormatIndexArgument(/*Expression*/ indexExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //switch (indexExpression)
                {
                    let memberExpression;
                    let constantExpression;
                    $switchJumpStart1: 
                    //case MemberExpression memberExpression when memberExpression.Expression is ConstantExpression constantExpression:
                    if ($.$is(indexExpression, $.$sle.System.Linq.Expressions.MemberExpression, { set $v(v){ memberExpression = v; } }) && $.$is(memberExpression.Expression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constantExpression = v; } }))
                    {
                        $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatCapturedValue(memberExpression, constantExpression, builder);
                    }
                    //case ConstantExpression constantExpression:
                    else if ($.$is(indexExpression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ constantExpression = v; } }))
                    {
                        $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatConstantValue(constantExpression, builder);
                    }
                    //default
                    else
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Unable to evaluate index expressions of type '${$.$$.System.Object.GetType.call(indexExpression).Name}'.`);
                    }
                }
            }
            static /*string */ FormatIndexArgument$1(/*Expression*/ indexExpression)
            {
                /*var*/ let builder = new $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 128/*StackAllocBufferSize*/, null));
                try
                {
                    $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.FormatIndexArgument(indexExpression, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder, () => builder, ($v) => builder = $v, null));
                    /*var*/ let result = $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.call(builder);
                    return result;
                }
                finally
                {
                    {
                        builder.Dispose();
                    }
                }
            }
            static /*void */ FormatCapturedValue(/*MemberExpression*/ memberExpression, /*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                /*var*/ let member = memberExpression.Member;
                /*var*/ let format;
                if (!$.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.TryGetValue(member, $.$ref(() => format, ($v) => format = $v, $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter)))
                {
                    format = $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CreateCapturedValueFormatter(memberExpression);
                    $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.s_capturedValueFormatterCache.set_Item(member, format);
                }
                format.Invoke(constantExpression.Value, builder);
            }
            static /*CapturedValueFormatter */ CreateCapturedValueFormatter(/*MemberExpression*/ memberExpression)
            {
                /*var*/ let memberType = memberExpression.Type;
                if ($.$$.System.Type.op_Equality$1(memberType, $.$$.System.Int32.$type))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.Int32, memberExpression);
                    return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$2($.$$.System.Int32, func.Invoke(closure));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":3276809,"f":4}],"n":"","d":983049,"h":0,"f":17825794});
                }
                else if ($.$$.System.Type.op_Equality$1(memberType, $.$$.System.String.$type))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.String, memberExpression);
                    return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$1($.$$.System.String.op_Implicit(func.Invoke(closure)));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":3276809,"f":4}],"n":"","d":983049,"h":0,"f":17825794});
                }
                else if ($.$$.System.ISpanFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.ISpanFormattable, memberExpression);
                    return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront$2($.$$.System.ISpanFormattable, func.Invoke(closure));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":3276809,"f":4}],"n":"","d":983049,"h":0,"f":17825794});
                }
                else if ($.$$.System.IFormattable.$type.IsAssignableFrom(memberType))
                {
                    /*var*/ let func = CompileMemberEvaluator($.$$.System.IFormattable, memberExpression);
                    return new $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter().$ctor(this,  (/*object*/ closure, /*ReverseStringBuilder*/ builder) =>
                    {
                        return builder.$v.InsertFront(func.Invoke(closure));
                    }, {"r":65537,"p":[{"n":"closure","p":131073},{"n":"builder","p":3276809,"f":4}],"n":"","d":983049,"h":0,"f":17825794});
                }
                else 
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Cannot format an index argument of type '${$.$$.System.Type.ToString.call(memberType)}'.`);
                }
                /*static Func<object, TResult>*/  function CompileMemberEvaluator(TResult, /*MemberExpression*/ memberExpression)
                {
                    /*var*/ let parameterExpression = $.$sle.System.Linq.Expressions.Expression.Parameter$1($.$$.System.Object.$type);
                    /*var*/ let convertExpression = $.$sle.System.Linq.Expressions.Expression.Convert$1(parameterExpression, memberExpression.Member.DeclaringType);
                    /*var*/ let replacedMemberExpression = memberExpression.Update(convertExpression);
                    /*var*/ let replacedExpression = $.$sle.System.Linq.Expressions.Expression.Lambda$17($.$$.System.Func$$$($.$$.System.Object, TResult), replacedMemberExpression, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ parameterExpression ], null, null));
                    return replacedExpression.Compile$3();
                }
            }
            static /*void */ FormatConstantValue(/*ConstantExpression*/ constantExpression, /*ref ReverseStringBuilder*/ builder)
            {
                //switch (constantExpression.Value)
                let $switch1 = constantExpression.Value;
                {
                    let s;
                    let spanFormattable;
                    let formattable;
                    let x;
                    $switchJumpStart1: 
                    //case string s:
                    if ($.$is($switch1, $.$$.System.String, { set $v(v){ s = v; } }))
                    {
                        builder.$v.InsertFront$1($.$$.System.String.op_Implicit(s));
                    }
                    //case ISpanFormattable spanFormattable:
                    else if ($.$is($switch1, $.$$.System.ISpanFormattable, { set $v(v){ spanFormattable = v; } }))
                    {
                        builder.$v.InsertFront$2($.$$.System.ISpanFormattable, spanFormattable);
                    }
                    //case IFormattable formattable:
                    else if ($.$is($switch1, $.$$.System.IFormattable, { set $v(v){ formattable = v; } }))
                    {
                        builder.$v.InsertFront(formattable);
                    }
                    //case null:
                    else if ($switch1 == null)
                    {
                        builder.$v.InsertFront$1($.$$.System.String.op_Implicit("null"));
                    }
                    //case var x:
                    else if ($switch1 != null && (x = $switch1))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Unable to format constant values of type '${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(x))}'.`);
                    }
                }
            }
            static $_MethodInfoData;
            static get MethodInfoData()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter;
                return $cls.$_MethodInfoData ??= $asm.$nstr("$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData", ($self) => class MethodInfoData extends $.$$.System.ValueType
                {
                    /*bool*/ IsSingleArgumentIndexer = false;
                    $ctor$3(/*bool*/ isSingleArgumentIndexer)
                    {
                        super.$ctor$1();
                        {
                            this.IsSingleArgumentIndexer = isSingleArgumentIndexer;
                        }
                        return this;
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsSingleArgumentIndexer = this.IsSingleArgumentIndexer;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsSingleArgumentIndexer = false;
                    }
                    static $h = 1114121;
                    static $z = 1;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886016009,"f":50331649},"n":"IsSingleArgumentIndexer","d":1114121,"h":8591048713,"f":2097153}],"c":[{"p":[{"n":"isSingleArgumentIndexer","p":262145}],"n":".ctor","o":"$ctor$3","d":1114121,"h":17180983305,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1114121,"h":21475950601,"f":16777217}],"d":983049,"h":1114121}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `ExpressionFormatter.MethodInfoData`; }
                }, $cls, ($v) => $cls.$_MethodInfoData = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_capturedValueFormatterCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MemberInfo, $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter))().$ctor$1();
                }
                {
                    this.s_methodInfoDataCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MethodInfo, $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData))().$ctor$1();
                }
            }
            static $h = 983049;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ClearCache","d":983049,"h":25770786825,"f":16777249},{"r":1310721,"p":[{"n":"expression","p":38506357}],"n":"FormatLambda","o":"@$1","d":983049,"h":30065754121,"f":16777249},{"r":1310721,"p":[{"n":"expression","p":38506357},{"n":"prefix","p":1310721,"f":65}],"n":"FormatLambda","d":983049,"h":34360721417,"f":16777249},{"r":262145,"p":[{"n":"expression","p":8687477}],"n":"IsSingleArgumentIndexer","d":983049,"h":38655688713,"f":16777256},{"r":1114121,"p":[{"n":"methodInfo","p":79626241}],"n":"GetOrCreateMethodInfoData","d":983049,"h":42950656009,"f":16777250},{"r":65537,"p":[{"n":"indexExpression","p":8687477},{"n":"builder","p":3276809,"f":4}],"n":"FormatIndexArgument","d":983049,"h":47245623305,"f":16777250},{"r":1310721,"p":[{"n":"indexExpression","p":8687477}],"n":"FormatIndexArgument","o":"@$1","d":983049,"h":51540590601,"f":16777256},{"r":65537,"p":[{"n":"memberExpression","p":38965109},{"n":"constantExpression","p":7769973},{"n":"builder","p":3276809,"f":4}],"n":"FormatCapturedValue","d":983049,"h":55835557897,"f":16777250},{"r":1048585,"p":[{"n":"memberExpression","p":38965109}],"n":"CreateCapturedValueFormatter","d":983049,"h":60130525193,"f":16777250},{"r":65537,"p":[{"n":"constantExpression","p":7769973},{"n":"builder","p":3276809,"f":4}],"n":"FormatConstantValue","d":983049,"h":64425492489,"f":16777250}],"l":[{"t":655361,"n":"StackAllocBufferSize","d":983049,"h":8590917641,"f":4194344},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MemberInfo, $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.CapturedValueFormatter).$h,"n":"s_capturedValueFormatterCache","d":983049,"h":17180852233,"f":4194338},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Reflection.MethodInfo, $.$macw.Microsoft.AspNetCore.Components.Forms.ExpressionFormatter.MethodInfoData).$h,"n":"s_methodInfoDataCache","d":983049,"h":21475819529,"f":4194338}],"j":[1048585,1114121],"h":983049}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ExpressionFormatter`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.EventHandlers", ($self) => class EventHandlers
        {
            static $h = 5308425;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5308425,"a":[{"t":2490376,"c":8592424968,"a":[{"v":"onfocus","t":1310721},{"v":5373961,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onblur","t":1310721},{"v":5373961,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onfocusin","t":1310721},{"v":5373961,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onfocusout","t":1310721},{"v":5373961,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmouseover","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmouseout","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmouseleave","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmouseenter","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmousemove","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmousedown","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmouseup","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onclick","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondblclick","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onwheel","t":1310721},{"v":8192009,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onmousewheel","t":1310721},{"v":8192009,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oncontextmenu","t":1310721},{"v":6750217,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondrag","t":1310721},{"v":4980745,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondragend","t":1310721},{"v":4980745,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondragenter","t":1310721},{"v":4980745,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondragleave","t":1310721},{"v":4980745,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondragover","t":1310721},{"v":4980745,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondragstart","t":1310721},{"v":4980745,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondrop","t":1310721},{"v":4980745,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onkeydown","t":1310721},{"v":6619145,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onkeyup","t":1310721},{"v":6619145,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onkeypress","t":1310721},{"v":6619145,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onchange","t":1310721},{"v":1114120,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oninput","t":1310721},{"v":1114120,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oninvalid","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onreset","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onselect","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onselectstart","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onselectionchange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onsubmit","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onbeforecopy","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onbeforecut","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onbeforepaste","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oncopy","t":1310721},{"v":4718601,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oncut","t":1310721},{"v":4718601,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpaste","t":1310721},{"v":4718601,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontouchcancel","t":1310721},{"v":7274505,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontouchend","t":1310721},{"v":7274505,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontouchmove","t":1310721},{"v":7274505,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontouchstart","t":1310721},{"v":7274505,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontouchenter","t":1310721},{"v":7274505,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontouchleave","t":1310721},{"v":7274505,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ongotpointercapture","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onlostpointercapture","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointercancel","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerdown","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerenter","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerleave","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointermove","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerout","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerover","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerup","t":1310721},{"v":6946825,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oncanplay","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oncanplaythrough","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oncuechange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondurationchange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onemptied","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpause","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onplay","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onplaying","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onratechange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onseeked","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onseeking","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onstalled","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onstop","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onsuspend","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontimeupdate","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onvolumechange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onwaiting","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onloadstart","t":1310721},{"v":7077897,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontimeout","t":1310721},{"v":7077897,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onabort","t":1310721},{"v":7077897,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onload","t":1310721},{"v":7077897,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onloadend","t":1310721},{"v":7077897,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onprogress","t":1310721},{"v":7077897,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onerror","t":1310721},{"v":5177353,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onactivate","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onbeforeactivate","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onbeforedeactivate","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ondeactivate","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onended","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onfullscreenchange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onfullscreenerror","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onloadeddata","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onloadedmetadata","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerlockchange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onpointerlockerror","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onreadystatechange","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onscroll","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"ontoggle","t":1310721},{"v":46989313,"t":142475265},{"v":true,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"oncancel","t":1310721},{"v":46989313,"t":142475265},{"v":false,"t":262145},{"v":true,"t":262145}]},{"t":2490376,"c":8592424968,"a":[{"v":"onclose","t":1310721},{"v":46989313,"t":142475265},{"v":false,"t":262145},{"v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EventHandlers`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.DataTransfer", ($self) => class DataTransfer extends $.$$.System.Object
        {
            /*string*/ DropEffect = null;
            /*string?*/ EffectAllowed = null;
            /*string[]*/ Files = null;
            /*DataTransferItem[]*/ Items = null;
            /*string[]*/ Types = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.DropEffect = null;
                this.Files = $.$$.System.Array.Empty($.$$.System.String);
                this.Items = $.$$.System.Array.Empty($.$macw.Microsoft.AspNetCore.Components.Web.DataTransferItem);
                this.Types = $.$$.System.Array.Empty($.$$.System.String);
            }
            static $h = 4849673;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12889751561,"f":50331649},"s":{"r":0,"d":0,"h":17184718857,"f":83886081},"n":"DropEffect","d":4849673,"h":8594784265,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30069620745,"f":50331649},"s":{"r":0,"d":0,"h":34364588041,"f":83886081},"n":"EffectAllowed","d":4849673,"h":25774653449,"f":2097153},{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":47249489929,"f":50331649},"s":{"r":0,"d":0,"h":51544457225,"f":83886081},"n":"Files","d":4849673,"h":42954522633,"f":2097153},{"p":$.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.DataTransferItem).$h,"g":{"r":0,"d":0,"h":64429359113,"f":50331649},"s":{"r":0,"d":0,"h":68724326409,"f":83886081},"n":"Items","d":4849673,"h":60134391817,"f":2097153},{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":81609228297,"f":50331649},"s":{"r":0,"d":0,"h":85904195593,"f":83886081},"n":"Types","d":4849673,"h":77314261001,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":4849673,"h":90199162889,"f":16777217}],"h":4849673}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DataTransfer`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.TouchPoint", ($self) => class TouchPoint extends $.$$.System.Object
        {
            /*long*/ Identifier = 0n;
            /*double*/ ScreenX = 0;
            /*double*/ ScreenY = 0;
            /*double*/ ClientX = 0;
            /*double*/ ClientY = 0;
            /*double*/ PageX = 0;
            /*double*/ PageY = 0;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 7405577;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12892307465,"f":50331649},"s":{"r":0,"d":0,"h":17187274761,"f":83886081},"n":"Identifier","d":7405577,"h":8597340169,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":30072176649,"f":50331649},"s":{"r":0,"d":0,"h":34367143945,"f":83886081},"n":"ScreenX","d":7405577,"h":25777209353,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":47252045833,"f":50331649},"s":{"r":0,"d":0,"h":51547013129,"f":83886081},"n":"ScreenY","d":7405577,"h":42957078537,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":64431915017,"f":50331649},"s":{"r":0,"d":0,"h":68726882313,"f":83886081},"n":"ClientX","d":7405577,"h":60136947721,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":81611784201,"f":50331649},"s":{"r":0,"d":0,"h":85906751497,"f":83886081},"n":"ClientY","d":7405577,"h":77316816905,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":98791653385,"f":50331649},"s":{"r":0,"d":0,"h":103086620681,"f":83886081},"n":"PageX","d":7405577,"h":94496686089,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":115971522569,"f":50331649},"s":{"r":0,"d":0,"h":120266489865,"f":83886081},"n":"PageY","d":7405577,"h":111676555273,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":7405577,"h":124561457161,"f":16777217}],"h":7405577}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `TouchPoint`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgsReader", ($self) => class ClipboardEventArgsReader
        {
            /*JsonEncodedText*/ static TypeKey;
            static /*ClipboardEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgsReader.TypeKey.EncodedUtf8Bytes))
                        {
                            eventArgs.Type = property.Value.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return eventArgs;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TypeKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
            }
            static $h = 4784137;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4718601,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":4784137,"h":8594718729,"f":16777256}],"l":[{"t":2339779,"n":"TypeKey","d":4784137,"h":4299751433,"f":4194338}],"h":4784137}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ClipboardEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgsReader", ($self) => class FocusEventArgsReader
        {
            /*JsonEncodedText*/ static Type;
            static /*FocusEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgsReader.Type.EncodedUtf8Bytes))
                        {
                            eventArgs.Type = property.Value.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return eventArgs;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
            }
            static $h = 5439497;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":5373961,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":5439497,"h":8595374089,"f":16777256}],"l":[{"t":2339779,"n":"Type","d":5439497,"h":4300406793,"f":4194338}],"h":5439497}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FocusEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.WebEventCallbackFactoryEventArgsExtensions", ($self) => class WebEventCallbackFactoryEventArgsExtensions
        {
            static /*EventCallback<ClipboardEventArgs> */ Create(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<ClipboardEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs, receiver, callback);
            }
            static /*EventCallback<ClipboardEventArgs> */ Create$10(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<ClipboardEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs, receiver, callback);
            }
            static /*EventCallback<DragEventArgs> */ Create$1(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<DragEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs, receiver, callback);
            }
            static /*EventCallback<DragEventArgs> */ Create$11(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<DragEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs, receiver, callback);
            }
            static /*EventCallback<ErrorEventArgs> */ Create$2(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<ErrorEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs, receiver, callback);
            }
            static /*EventCallback<ErrorEventArgs> */ Create$12(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<ErrorEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs, receiver, callback);
            }
            static /*EventCallback<FocusEventArgs> */ Create$3(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<FocusEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs, receiver, callback);
            }
            static /*EventCallback<FocusEventArgs> */ Create$13(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<FocusEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs, receiver, callback);
            }
            static /*EventCallback<KeyboardEventArgs> */ Create$4(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<KeyboardEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs, receiver, callback);
            }
            static /*EventCallback<KeyboardEventArgs> */ Create$14(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<KeyboardEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs, receiver, callback);
            }
            static /*EventCallback<MouseEventArgs> */ Create$5(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<MouseEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, receiver, callback);
            }
            static /*EventCallback<MouseEventArgs> */ Create$15(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<MouseEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, receiver, callback);
            }
            static /*EventCallback<PointerEventArgs> */ Create$6(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<PointerEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs, receiver, callback);
            }
            static /*EventCallback<PointerEventArgs> */ Create$16(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<PointerEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs, receiver, callback);
            }
            static /*EventCallback<ProgressEventArgs> */ Create$7(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<ProgressEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs, receiver, callback);
            }
            static /*EventCallback<ProgressEventArgs> */ Create$17(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<ProgressEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs, receiver, callback);
            }
            static /*EventCallback<TouchEventArgs> */ Create$8(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<TouchEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs, receiver, callback);
            }
            static /*EventCallback<TouchEventArgs> */ Create$18(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<TouchEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs, receiver, callback);
            }
            static /*EventCallback<WheelEventArgs> */ Create$9(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Action<WheelEventArgs>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$6($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs, receiver, callback);
            }
            static /*EventCallback<WheelEventArgs> */ Create$19(/*this EventCallbackFactory*/ factory, /*object*/ receiver, /*Func<WheelEventArgs, Task>*/ callback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return factory.Create$8($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs, receiver, callback);
            }
            static $h = 7929865;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs).$h}],"n":"Create","d":7929865,"h":4302897161,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$10","d":7929865,"h":8597864457,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs).$h}],"n":"Create","o":"@$1","d":7929865,"h":12892831753,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$11","d":7929865,"h":17187799049,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs).$h}],"n":"Create","o":"@$2","d":7929865,"h":21482766345,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$12","d":7929865,"h":25777733641,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs).$h}],"n":"Create","o":"@$3","d":7929865,"h":30072700937,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$13","d":7929865,"h":34367668233,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs).$h}],"n":"Create","o":"@$4","d":7929865,"h":38662635529,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$14","d":7929865,"h":42957602825,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs).$h}],"n":"Create","o":"@$5","d":7929865,"h":47252570121,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$15","d":7929865,"h":51547537417,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs).$h}],"n":"Create","o":"@$6","d":7929865,"h":55842504713,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$16","d":7929865,"h":60137472009,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs).$h}],"n":"Create","o":"@$7","d":7929865,"h":64432439305,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$17","d":7929865,"h":68727406601,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs).$h}],"n":"Create","o":"@$8","d":7929865,"h":73022373897,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$18","d":7929865,"h":77317341193,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Action$$($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs).$h}],"n":"Create","o":"@$9","d":7929865,"h":81612308489,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]},{"r":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs).$h,"p":[{"n":"factory","p":2228232},{"n":"receiver","p":131073},{"n":"callback","p":$.$$.System.Func$$$($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs, $.$$.System.Threading.Tasks.Task).$h}],"n":"Create","o":"@$19","d":7929865,"h":85907275785,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This extension method is obsolete and will be removed in a future version. Use the generic overload instead.","t":1310721}]}]}],"h":7929865}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebEventCallbackFactoryEventArgsExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader", ($self) => class KeyboardEventArgsReader
        {
            /*JsonEncodedText*/ static Key;
            /*JsonEncodedText*/ static Code;
            /*JsonEncodedText*/ static Location;
            /*JsonEncodedText*/ static Repeat;
            /*JsonEncodedText*/ static CtrlKey;
            /*JsonEncodedText*/ static ShiftKey;
            /*JsonEncodedText*/ static AltKey;
            /*JsonEncodedText*/ static MetaKey;
            /*JsonEncodedText*/ static Type;
            /*JsonEncodedText*/ static IsComposing;
            static /*KeyboardEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.Key.EncodedUtf8Bytes))
                        {
                            eventArgs.Key = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.Code.EncodedUtf8Bytes))
                        {
                            eventArgs.Code = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.Location.EncodedUtf8Bytes))
                        {
                            eventArgs.Location = property.Value.GetSingle();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.Repeat.EncodedUtf8Bytes))
                        {
                            eventArgs.Repeat = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.CtrlKey.EncodedUtf8Bytes))
                        {
                            eventArgs.CtrlKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.AltKey.EncodedUtf8Bytes))
                        {
                            eventArgs.AltKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.ShiftKey.EncodedUtf8Bytes))
                        {
                            eventArgs.ShiftKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.MetaKey.EncodedUtf8Bytes))
                        {
                            eventArgs.MetaKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.Type.EncodedUtf8Bytes))
                        {
                            eventArgs.Type = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.IsComposing.EncodedUtf8Bytes))
                        {
                            eventArgs.IsComposing = property.Value.GetBoolean();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return eventArgs;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Key = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("key", null);
                }
                {
                    this.Code = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("code", null);
                }
                {
                    this.Location = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("location", null);
                }
                {
                    this.Repeat = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("repeat", null);
                }
                {
                    this.CtrlKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("ctrlKey", null);
                }
                {
                    this.ShiftKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("shiftKey", null);
                }
                {
                    this.AltKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("altKey", null);
                }
                {
                    this.MetaKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("metaKey", null);
                }
                {
                    this.Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
                {
                    this.IsComposing = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("isComposing", null);
                }
            }
            static $h = 6684681;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":6619145,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":6684681,"h":47251324937,"f":16777256}],"l":[{"t":2339779,"n":"Key","d":6684681,"h":4301651977,"f":4194338},{"t":2339779,"n":"Code","d":6684681,"h":8596619273,"f":4194338},{"t":2339779,"n":"Location","d":6684681,"h":12891586569,"f":4194338},{"t":2339779,"n":"Repeat","d":6684681,"h":17186553865,"f":4194338},{"t":2339779,"n":"CtrlKey","d":6684681,"h":21481521161,"f":4194338},{"t":2339779,"n":"ShiftKey","d":6684681,"h":25776488457,"f":4194338},{"t":2339779,"n":"AltKey","d":6684681,"h":30071455753,"f":4194338},{"t":2339779,"n":"MetaKey","d":6684681,"h":34366423049,"f":4194338},{"t":2339779,"n":"Type","d":6684681,"h":38661390345,"f":4194338},{"t":2339779,"n":"IsComposing","d":6684681,"h":42956357641,"f":4194338}],"h":6684681}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `KeyboardEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgsReader", ($self) => class ProgressEventArgsReader
        {
            /*JsonEncodedText*/ static LengthComputable;
            /*JsonEncodedText*/ static Loaded;
            /*JsonEncodedText*/ static Total;
            /*JsonEncodedText*/ static Type;
            static /*ProgressEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgsReader.LengthComputable.EncodedUtf8Bytes))
                        {
                            eventArgs.LengthComputable = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgsReader.Loaded.EncodedUtf8Bytes))
                        {
                            eventArgs.Loaded = property.Value.GetInt64();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgsReader.Total.EncodedUtf8Bytes))
                        {
                            eventArgs.Total = property.Value.GetInt64();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgsReader.Type.EncodedUtf8Bytes))
                        {
                            eventArgs.Type = property.Value.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return eventArgs;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.LengthComputable = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("lengthComputable", null);
                }
                {
                    this.Loaded = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("loaded", null);
                }
                {
                    this.Total = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("total", null);
                }
                {
                    this.Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
            }
            static $h = 7143433;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":7077897,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":7143433,"h":21481979913,"f":16777256}],"l":[{"t":2339779,"n":"LengthComputable","d":7143433,"h":4302110729,"f":4194338},{"t":2339779,"n":"Loaded","d":7143433,"h":8597078025,"f":4194338},{"t":2339779,"n":"Total","d":7143433,"h":12892045321,"f":4194338},{"t":2339779,"n":"Type","d":7143433,"h":17187012617,"f":4194338}],"h":7143433}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ProgressEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader", ($self) => class PointerEventArgsReader
        {
            /*JsonEncodedText*/ static PointerId;
            /*JsonEncodedText*/ static Width;
            /*JsonEncodedText*/ static Height;
            /*JsonEncodedText*/ static Pressure;
            /*JsonEncodedText*/ static TiltX;
            /*JsonEncodedText*/ static TiltY;
            /*JsonEncodedText*/ static PointerType;
            /*JsonEncodedText*/ static IsPrimary;
            static /*PointerEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs().$ctor$3();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.PointerId.EncodedUtf8Bytes))
                        {
                            eventArgs.PointerId = property.Value.GetInt64();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.Width.EncodedUtf8Bytes))
                        {
                            eventArgs.Width = property.Value.GetSingle();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.Height.EncodedUtf8Bytes))
                        {
                            eventArgs.Height = property.Value.GetSingle();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.Pressure.EncodedUtf8Bytes))
                        {
                            eventArgs.Pressure = property.Value.GetSingle();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.TiltX.EncodedUtf8Bytes))
                        {
                            eventArgs.TiltX = property.Value.GetSingle();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.TiltY.EncodedUtf8Bytes))
                        {
                            eventArgs.TiltY = property.Value.GetSingle();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.PointerType.EncodedUtf8Bytes))
                        {
                            eventArgs.PointerType = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.IsPrimary.EncodedUtf8Bytes))
                        {
                            eventArgs.IsPrimary = property.Value.GetBoolean();
                        }
                        else 
                        {
                            $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ReadProperty(eventArgs, property);
                        }
                    }
                }
                return eventArgs;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PointerId = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("pointerId", null);
                }
                {
                    this.Width = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("width", null);
                }
                {
                    this.Height = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("height", null);
                }
                {
                    this.Pressure = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("pressure", null);
                }
                {
                    this.TiltX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("tiltX", null);
                }
                {
                    this.TiltY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("tiltY", null);
                }
                {
                    this.PointerType = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("pointerType", null);
                }
                {
                    this.IsPrimary = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("isPrimary", null);
                }
            }
            static $h = 7012361;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":6946825,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":7012361,"h":38661718025,"f":16777256}],"l":[{"t":2339779,"n":"PointerId","d":7012361,"h":4301979657,"f":4194338},{"t":2339779,"n":"Width","d":7012361,"h":8596946953,"f":4194338},{"t":2339779,"n":"Height","d":7012361,"h":12891914249,"f":4194338},{"t":2339779,"n":"Pressure","d":7012361,"h":17186881545,"f":4194338},{"t":2339779,"n":"TiltX","d":7012361,"h":21481848841,"f":4194338},{"t":2339779,"n":"TiltY","d":7012361,"h":25776816137,"f":4194338},{"t":2339779,"n":"PointerType","d":7012361,"h":30071783433,"f":4194338},{"t":2339779,"n":"IsPrimary","d":7012361,"h":34366750729,"f":4194338}],"h":7012361}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `PointerEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputFileInterop", ($self) => class InputFileInterop
        {
            /*string*/ static JsFunctionsPrefix = null;
            /*string*/ static Init = null;
            /*string*/ static ReadFileData = null;
            /*string*/ static ToImageFile = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.JsFunctionsPrefix = "Blazor._internal.InputFile.";
                }
                {
                    this.Init = "Blazor._internal.InputFile.init";
                }
                {
                    this.ReadFileData = "Blazor._internal.InputFile.readFileData";
                }
                {
                    this.ToImageFile = "Blazor._internal.InputFile.toImageFile";
                }
            }
            static $h = 2031625;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"JsFunctionsPrefix","d":2031625,"h":4296998921,"f":4194338},{"t":1310721,"n":"Init","d":2031625,"h":8591966217,"f":4194337},{"t":1310721,"n":"ReadFileData","d":2031625,"h":12886933513,"f":4194337},{"t":1310721,"n":"ToImageFile","d":2031625,"h":17181900809,"f":4194337}],"h":2031625}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InputFileInterop`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.WebRenderTreeBuilderExtensions", ($self) => class WebRenderTreeBuilderExtensions
        {
            static /*void */ AddEventPreventDefaultAttribute(/*this RenderTreeBuilder*/ builder, /*int*/ sequence, /*string*/ eventName, /*bool*/ value)
            {
                builder.AddAttribute(sequence, `__internal_preventDefault_${eventName}`, value);
            }
            static /*void */ AddEventStopPropagationAttribute(/*this RenderTreeBuilder*/ builder, /*int*/ sequence, /*string*/ eventName, /*bool*/ value)
            {
                builder.AddAttribute(sequence, `__internal_stopPropagation_${eventName}`, value);
            }
            static $h = 8126473;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"sequence","p":655361},{"n":"eventName","p":1310721},{"n":"value","p":262145}],"n":"AddEventPreventDefaultAttribute","d":8126473,"h":4303093769,"f":16777249},{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"sequence","p":655361},{"n":"eventName","p":1310721},{"n":"value","p":262145}],"n":"AddEventStopPropagationAttribute","d":8126473,"h":8598061065,"f":16777249}],"h":8126473}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebRenderTreeBuilderExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ChangeEventArgsReader", ($self) => class ChangeEventArgsReader
        {
            /*JsonEncodedText*/ static ValueKey;
            static /*ChangeEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let changeArgs = new $.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ChangeEventArgsReader.ValueKey.EncodedUtf8Bytes))
                        {
                            /*var*/ let value = property.Value;
                            let $switch1 = value.ValueKind;
                            switch($switch1)
                            {
                                case 7/*JsonValueKind.Null*/:
                                break;
                                case 3/*JsonValueKind.String*/:
                                changeArgs.Value = value.GetString();
                                break;
                                case 5/*JsonValueKind.True*/:
                                case 6/*JsonValueKind.False*/:
                                changeArgs.Value = $.$box(value.GetBoolean(), $.$$.System.Boolean);
                                break;
                                case 2/*JsonValueKind.Array*/:
                                changeArgs.Value = $.$macw.Microsoft.AspNetCore.Components.Web.ChangeEventArgsReader.GetJsonElementStringArrayValue(value);
                                break;
                                default:
                                throw new $.$$.System.ArgumentException().$ctor$14(`Unsupported ${"ChangeEventArgs"} value ${$.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement)}.`);
                            }
                            return changeArgs;
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return changeArgs;
            }
            static /*string?[] */ GetJsonElementStringArrayValue(/*JsonElement*/ jsonElement)
            {
                /*var*/ let result = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [jsonElement.GetArrayLength()], null);
                /*var*/ let elementIndex = 0;
                var $en2 = jsonElement.EnumerateArray().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var arrayElement = $en2.Current;
                    {
                        if (arrayElement.ValueKind !== 3/*JsonValueKind.String*/)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`Unsupported ${"JsonElement"} value kind '${arrayElement.ValueKind}' ` + `(expected '${3/*JsonValueKind.String*/}').`);
                        }
                        $.$$.System.Array.$WriteT1.call(result, arrayElement.GetString(), elementIndex);
                        elementIndex++;
                    }
                }
                return result;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ValueKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("value", null);
                }
            }
            static $h = 4653065;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1114120,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":4653065,"h":8594587657,"f":16777256},{"r":$.$typeArray($.$$.System.String).$h,"p":[{"n":"jsonElement","p":2143171}],"n":"GetJsonElementStringArrayValue","d":4653065,"h":12889554953,"f":16777250}],"l":[{"t":2339779,"n":"ValueKey","d":4653065,"h":4299620361,"f":4194338}],"h":4653065}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ChangeEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader", ($self) => class WebEventDescriptorReader
        {
            /*JsonEncodedText*/ static EventHandlerIdKey;
            /*JsonEncodedText*/ static EventNameKey;
            /*JsonEncodedText*/ static EventFieldInfoKey;
            /*JsonEncodedText*/ static ComponentIdKey;
            /*JsonEncodedText*/ static FieldValueKey;
            static /*WebEventDescriptor */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let descriptor = new $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebEventDescriptor().$ctor$1();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader.EventHandlerIdKey.EncodedUtf8Bytes))
                        {
                            descriptor.EventHandlerId = property.Value.GetUInt64();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader.EventNameKey.EncodedUtf8Bytes))
                        {
                            descriptor.EventName = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader.EventFieldInfoKey.EncodedUtf8Bytes))
                        {
                            descriptor.EventFieldInfo = $.$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader.ReadEventFieldInfo(property.Value);
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return descriptor;
            }
            static /*EventFieldInfo? */ ReadEventFieldInfo(/*JsonElement*/ jsonElement)
            {
                if (jsonElement.ValueKind === 7)
                {
                    return null;
                }
                /*var*/ let eventFieldInfo = new $.$mac.Microsoft.AspNetCore.Components.RenderTree.EventFieldInfo().$ctor$1();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader.ComponentIdKey.EncodedUtf8Bytes))
                        {
                            eventFieldInfo.ComponentId = property.Value.GetInt32();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader.FieldValueKey.EncodedUtf8Bytes))
                        {
                            if ((property.Value.ValueKind === 5/*JsonValueKind.True*/) || (property.Value.ValueKind === 6/*JsonValueKind.False*/))
                            {
                                eventFieldInfo.FieldValue = $.$box(property.Value.GetBoolean(), $.$$.System.Boolean);
                            }
                            else 
                            {
                                eventFieldInfo.FieldValue = property.Value.GetString();
                            }
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return eventFieldInfo;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EventHandlerIdKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("eventHandlerId", null);
                }
                {
                    this.EventNameKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("eventName", null);
                }
                {
                    this.EventFieldInfoKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("eventFieldInfo", null);
                }
                {
                    this.ComponentIdKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("componentId", null);
                }
                {
                    this.FieldValueKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("fieldValue", null);
                }
            }
            static $h = 8060937;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3801097,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":8060937,"h":25777864713,"f":16777256},{"r":8192008,"p":[{"n":"jsonElement","p":2143171}],"n":"ReadEventFieldInfo","d":8060937,"h":30072832009,"f":16777250}],"l":[{"t":2339779,"n":"EventHandlerIdKey","d":8060937,"h":4303028233,"f":4194338},{"t":2339779,"n":"EventNameKey","d":8060937,"h":8597995529,"f":4194338},{"t":2339779,"n":"EventFieldInfoKey","d":8060937,"h":12892962825,"f":4194338},{"t":2339779,"n":"ComponentIdKey","d":8060937,"h":17187930121,"f":4194338},{"t":2339779,"n":"FieldValueKey","d":8060937,"h":21482897417,"f":4194338}],"h":8060937}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebEventDescriptorReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.BrowserFileExtensions", ($self) => class BrowserFileExtensions
        {
            static /*ValueTask<IBrowserFile> */ RequestImageFileAsync(/*this IBrowserFile*/ browserFile, /*string*/ format, /*int*/ maxWidth, /*int*/ maxHeight)
            {
                let browserFileInternal;
                if ($.$is(browserFile, $.$macw.Microsoft.AspNetCore.Components.Forms.BrowserFile, { set $v(v){ browserFileInternal = v; } }))
                {
                    return browserFileInternal.Owner.ConvertToImageFileAsync(browserFileInternal, format, maxWidth, maxHeight);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$12(`Cannot perform this operation on custom ${$.$$.System.Type.ToString.call($.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile.$type)} implementations.`);
            }
            static $h = 589833;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile).$h,"p":[{"n":"browserFile","p":1441801},{"n":"format","p":1310721},{"n":"maxWidth","p":655361},{"n":"maxHeight","p":655361}],"n":"RequestImageFileAsync","d":589833,"h":4295557129,"f":16777249}],"h":589833}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `BrowserFileExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.DataTransferItem", ($self) => class DataTransferItem extends $.$$.System.Object
        {
            /*string*/ Kind = null;
            /*string*/ Type = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Kind = null;
                this.Type = null;
            }
            static $h = 4915209;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12889817097,"f":50331649},"s":{"r":0,"d":0,"h":17184784393,"f":83886081},"n":"Kind","d":4915209,"h":8594849801,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30069686281,"f":50331649},"s":{"r":0,"d":0,"h":34364653577,"f":83886081},"n":"Type","d":4915209,"h":25774718985,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":4915209,"h":38659620873,"f":16777217}],"h":4915209}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DataTransferItem`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions", ($self) => class EditContextFormMappingExtensions
        {
            /*object*/ static _key = null;
            static /*IDisposable */ EnableFormMappingContextExtensions(/*this EditContext*/ context, /*FormMappingContext*/ mappingContext)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(context, "context");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(mappingContext, "mappingContext");
                context.Properties.set_Item($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions._key, mappingContext);
                return new $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions.MappingContextEventSubscriptions().$ctor$1(context, mappingContext);
            }
            static /*string? */ GetAttemptedValue(/*this EditContext*/ context, /*string*/ fieldName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(context, "context");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fieldName, "fieldName");
                /*var*/ let result;
                let mappingContext;
                if (context.Properties.TryGetValue($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions._key, $.$ref(() => result, ($v) => result = $v, $.$$.System.Object)) && $.$is(result, $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext, { set $v(v){ mappingContext = v; } }))
                {
                    return mappingContext.GetAttemptedValue$1(fieldName);
                }
                return null;
            }
            static $_MappingContextEventSubscriptions;
            static get MappingContextEventSubscriptions()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions;
                return $cls.$_MappingContextEventSubscriptions ??= $asm.$ncls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions.MappingContextEventSubscriptions", ($self) => class MappingContextEventSubscriptions extends $.$$.System.Object
                {
                    /*EditContext*/ _editContext = null;
                    /*FormMappingContext*/ _mappingContext = null;
                    /*ValidationMessageStore?*/ _messages = null;
                    /*bool*/ _hasmessages = false;
                    $ctor$1(/*EditContext*/ editContext, /*FormMappingContext*/ mappingContext)
                    {
                        super.$ctor();
                        {
                            this._editContext = editContext;
                            this._mappingContext = mappingContext;
                            this._editContext.add_OnValidationRequested(new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                        }
                        return this;
                    }
                    /*void */ OnValidationRequested(/*object?*/ sender, /*ValidationRequestedEventArgs*/ e)
                    {
                        if (this._messages !== null)
                        {
                            return;
                        }
                        this._messages = new $.$macf.Microsoft.AspNetCore.Components.Forms.ValidationMessageStore().$ctor$1(this._editContext);
                        /*var*/ let adddedMessages = false;
                        var $en4 = this._mappingContext.GetAllErrors().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var error = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*var*/ let owner = error.Container;
                                /*var*/ let key = error.Name;
                                /*var*/ let errors = error.ErrorMessages;
                                /*FieldIdentifier*/ let fieldIdentifier;
                                fieldIdentifier = new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$3(owner ?? this._editContext.Model, key);
                                var $en6 = errors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var errorMessage = $en6.System$Collections$Generic$IEnumerator$$$Current;
                                    {
                                        adddedMessages = true;
                                        this._messages.Add$3($.$ref(() => fieldIdentifier, ), errorMessage.ToString$1($.$$.System.Globalization.CultureInfo.CurrentCulture));
                                        this._hasmessages = true;
                                    }
                                }
                            }
                        }
                        if (adddedMessages)
                        {
                            this._editContext.NotifyValidationStateChanged();
                        }
                    }
                    /*void */ Dispose()
                    {
                        this._messages?.Clear();
                        this._editContext.remove_OnValidationRequested(new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationRequestedEventArgs))().$ctor(this, this.OnValidationRequested));
                        if (this._hasmessages)
                        {
                            this._editContext.NotifyValidationStateChanged();
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 2752521;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":983050}],"n":"OnValidationRequested","d":2752521,"h":25772556297,"f":16777218},{"r":65537,"n":"Dispose","d":2752521,"h":30067523593,"f":16777217}],"l":[{"t":131082,"n":"_editContext","d":2752521,"h":4297719817,"f":4194306},{"t":1245193,"n":"_mappingContext","d":2752521,"h":8592687113,"f":4194306},{"t":917514,"n":"_messages","d":2752521,"h":12887654409,"f":4194306},{"t":262145,"n":"_hasmessages","d":2752521,"h":17182621705,"f":4194306}],"c":[{"p":[{"n":"editContext","p":131082},{"n":"mappingContext","p":1245193}],"n":".ctor","o":"$ctor$1","d":2752521,"h":21477589001,"f":16777217}],"i":[57540609],"d":2686985,"h":2752521}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `EditContextFormMappingExtensions.MappingContextEventSubscriptions`; }
                }, $cls, ($v) => $cls.$_MappingContextEventSubscriptions = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._key = new $.$$.System.Object().$ctor();
                }
            }
            static $h = 2686985;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57540609,"p":[{"n":"context","p":131082},{"n":"mappingContext","p":1245193}],"n":"EnableFormMappingContextExtensions","d":2686985,"h":8592621577,"f":16777249},{"r":1310721,"p":[{"n":"context","p":131082},{"n":"fieldName","p":1310721}],"n":"GetAttemptedValue","d":2686985,"h":12887588873,"f":16777249}],"l":[{"t":131073,"n":"_key","d":2686985,"h":4297654281,"f":4194338}],"j":[2752521],"h":2686985}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EditContextFormMappingExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.SupplyParameterFromFormServiceCollectionExtensions", ($self) => class SupplyParameterFromFormServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddSupplyValueFromFormProvider(/*this IServiceCollection*/ serviceCollection)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable$1(serviceCollection, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$3($.$mac.Microsoft.AspNetCore.Components.ICascadingValueSupplier, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.SupplyParameterFromFormValueProvider, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.SupplyParameterFromFormValueProvider))().$ctor(this,  (/**/ services) =>
                {
                    return new $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.SupplyParameterFromFormValueProvider().$ctor$1($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.IFormValueMapper, services), "");
                }, {"r":3145737,"p":[{"n":"services","p":327717}],"n":"","d":3080201,"h":0,"f":17825794})));
                return serviceCollection;
            }
            static $h = 3080201;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"serviceCollection","p":786435}],"n":"AddSupplyValueFromFormProvider","d":3080201,"h":4298047497,"f":16777249}],"h":3080201}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `SupplyParameterFromFormServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.RemoteBrowserFileStreamOptions", ($self) => class RemoteBrowserFileStreamOptions extends $.$$.System.Object
        {
            /*int*/ MaxSegmentSize = 0;
            /*int*/ MaxBufferSize = 0;
            /*TimeSpan*/ SegmentFetchTimeout;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MaxSegmentSize = 20480;
                this.MaxBufferSize = 1048576;
                this.SegmentFetchTimeout = $.$$.System.TimeSpan.FromMinutes$2(1n);
            }
            static $h = 3211273;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12888113161,"f":50331649},"s":{"r":0,"d":0,"h":17183080457,"f":83886081},"n":"MaxSegmentSize","d":3211273,"h":8593145865,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30067982345,"f":50331649},"s":{"r":0,"d":0,"h":34362949641,"f":83886081},"n":"MaxBufferSize","d":3211273,"h":25773015049,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":47247851529,"f":50331649},"s":{"r":0,"d":0,"h":51542818825,"f":83886081},"n":"SegmentFetchTimeout","d":3211273,"h":42952884233,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":3211273,"h":55837786121,"f":16777217}],"h":3211273,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":70909953,"c":8660844545,"a":[{"v":"RemoteJSDataStream defaults are utilized instead of the options here.","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RemoteBrowserFileStreamOptions`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader", ($self) => class DragEventArgsReader
        {
            /*JsonEncodedText*/ static DataTransfer;
            /*JsonEncodedText*/ static DropEffect;
            /*JsonEncodedText*/ static EffectAllowed;
            /*JsonEncodedText*/ static Files;
            /*JsonEncodedText*/ static Items;
            /*JsonEncodedText*/ static Types;
            /*JsonEncodedText*/ static Kind;
            /*JsonEncodedText*/ static Type;
            static /*DragEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs().$ctor$3();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.DataTransfer.EncodedUtf8Bytes))
                        {
                            eventArgs.DataTransfer = $.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.ReadDataTransfer(property.Value);
                        }
                        else 
                        {
                            $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ReadProperty(eventArgs, property);
                        }
                    }
                }
                return eventArgs;
            }
            static /*DataTransfer */ ReadDataTransfer(/*JsonElement*/ jsonElement)
            {
                /*var*/ let dataTransfer = new $.$macw.Microsoft.AspNetCore.Components.Web.DataTransfer().$ctor$1();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.DropEffect.EncodedUtf8Bytes))
                        {
                            dataTransfer.DropEffect = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.EffectAllowed.EncodedUtf8Bytes))
                        {
                            dataTransfer.EffectAllowed = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.Files.EncodedUtf8Bytes))
                        {
                            dataTransfer.Files = $.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.ReadStringArray(property.Value);
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.Items.EncodedUtf8Bytes))
                        {
                            /*var*/ let value = property.Value;
                            /*var*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$macw.Microsoft.AspNetCore.Components.Web.DataTransferItem), null, [value.GetArrayLength()], null);
                            /*var*/ let i = 0;
                            var $en5 = value.EnumerateArray().GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var item = $en5.Current;
                                {
                                    $.$$.System.Array.$WriteT1.call(items, $.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.ReadDataTransferItem(item), i++);
                                }
                            }
                            dataTransfer.Items = items;
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.Types.EncodedUtf8Bytes))
                        {
                            dataTransfer.Types = $.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.ReadStringArray(property.Value);
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return dataTransfer;
            }
            static /*DataTransferItem */ ReadDataTransferItem(/*JsonElement*/ jsonElement)
            {
                /*var*/ let item = new $.$macw.Microsoft.AspNetCore.Components.Web.DataTransferItem().$ctor$1();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.Kind.EncodedUtf8Bytes))
                        {
                            item.Kind = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.Type.EncodedUtf8Bytes))
                        {
                            item.Type = property.Value.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return item;
            }
            static /*string[] */ ReadStringArray(/*JsonElement*/ value)
            {
                /*var*/ let values = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [value.GetArrayLength()], null);
                /*var*/ let i = 0;
                var $en2 = value.EnumerateArray().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        $.$$.System.Array.$WriteT1.call(values, item.GetString(), i++);
                    }
                }
                return values;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DataTransfer = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("dataTransfer", null);
                }
                {
                    this.DropEffect = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("dropEffect", null);
                }
                {
                    this.EffectAllowed = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("effectAllowed", null);
                }
                {
                    this.Files = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("files", null);
                }
                {
                    this.Items = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("items", null);
                }
                {
                    this.Types = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("types", null);
                }
                {
                    this.Kind = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("kind", null);
                }
                {
                    this.Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
            }
            static $h = 5046281;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4980745,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":5046281,"h":38659751945,"f":16777256},{"r":4849673,"p":[{"n":"jsonElement","p":2143171}],"n":"ReadDataTransfer","d":5046281,"h":42954719241,"f":16777250},{"r":4915209,"p":[{"n":"jsonElement","p":2143171}],"n":"ReadDataTransferItem","d":5046281,"h":47249686537,"f":16777250},{"r":$.$typeArray($.$$.System.String).$h,"p":[{"n":"value","p":2143171}],"n":"ReadStringArray","d":5046281,"h":51544653833,"f":16777250}],"l":[{"t":2339779,"n":"DataTransfer","d":5046281,"h":4300013577,"f":4194338},{"t":2339779,"n":"DropEffect","d":5046281,"h":8594980873,"f":4194338},{"t":2339779,"n":"EffectAllowed","d":5046281,"h":12889948169,"f":4194338},{"t":2339779,"n":"Files","d":5046281,"h":17184915465,"f":4194338},{"t":2339779,"n":"Items","d":5046281,"h":21479882761,"f":4194338},{"t":2339779,"n":"Types","d":5046281,"h":25774850057,"f":4194338},{"t":2339779,"n":"Kind","d":5046281,"h":30069817353,"f":4194338},{"t":2339779,"n":"Type","d":5046281,"h":34364784649,"f":4194338}],"h":5046281}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `DragEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormValueMappingContext", ($self) => class FormValueMappingContext extends $.$$.System.Object
        {
            /*bool*/ _resultSet = false;
            $ctor$1(/*string*/ acceptMappingScopeName, /*string?*/ acceptFormName, /*Type*/ valueType, /*string*/ parameterName)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(acceptMappingScopeName, "acceptMappingScopeName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(valueType, "valueType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(parameterName, "parameterName");
                    this.AcceptMappingScopeName = acceptMappingScopeName;
                    this.AcceptFormName = acceptFormName;
                    this.ParameterName = parameterName;
                    this.ValueType = valueType;
                }
                return this;
            }
            /*string*/ AcceptMappingScopeName = null;
            /*string?*/ AcceptFormName = null;
            /*string*/ ParameterName = null;
            /*Type*/ ValueType = null;
            /*Action<string, FormattableString, string?>?*/ OnError = null;
            /*Action<string, object>?*/ MapErrorToContainer = null;
            /*object?*/ Result = null;
            /*void */ SetResult(/*object?*/ result)
            {
                if (this._resultSet)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`The result has already been set to '${$.$$.System.Object.ToString.call(this.Result)}'.`);
                }
                this._resultSet = true;
                this.Result = result;
            }
            static $h = 2949129;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21477785609,"f":50331649},"n":"AcceptMappingScopeName","d":2949129,"h":17182818313,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34362687497,"f":50331649},"n":"AcceptFormName","d":2949129,"h":30067720201,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47247589385,"f":50331649},"n":"ParameterName","d":2949129,"h":42952622089,"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":60132491273,"f":50331649},"n":"ValueType","d":2949129,"h":55837523977,"f":2097153},{"p":$.$$.System.Action$$$$($.$$.System.String, $.$$.System.FormattableString, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":73017393161,"f":50331649},"s":{"r":0,"d":0,"h":77312360457,"f":83886081},"n":"OnError","d":2949129,"h":68722425865,"f":2097153},{"p":$.$$.System.Action$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":90197262345,"f":50331649},"s":{"r":0,"d":0,"h":94492229641,"f":83886081},"n":"MapErrorToContainer","d":2949129,"h":85902295049,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":107377131529,"f":50331649},"s":{"r":0,"d":0,"h":111672098825,"f":83886082},"n":"Result","d":2949129,"h":103082164233,"f":2097153}],"m":[{"r":65537,"p":[{"n":"result","p":131073}],"n":"SetResult","d":2949129,"h":115967066121,"f":16777217}],"l":[{"t":262145,"n":"_resultSet","d":2949129,"h":4297916425,"f":4194306}],"c":[{"p":[{"n":"acceptMappingScopeName","p":1310721},{"n":"acceptFormName","p":1310721},{"n":"valueType","p":142475265},{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2949129,"h":8592883721,"f":16777224}],"h":2949129}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FormValueMappingContext`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader", ($self) => class MouseEventArgsReader
        {
            /*JsonEncodedText*/ static Detail;
            /*JsonEncodedText*/ static ScreenX;
            /*JsonEncodedText*/ static ScreenY;
            /*JsonEncodedText*/ static ClientX;
            /*JsonEncodedText*/ static ClientY;
            /*JsonEncodedText*/ static OffsetX;
            /*JsonEncodedText*/ static OffsetY;
            /*JsonEncodedText*/ static PageX;
            /*JsonEncodedText*/ static PageY;
            /*JsonEncodedText*/ static MovementX;
            /*JsonEncodedText*/ static MovementY;
            /*JsonEncodedText*/ static Button;
            /*JsonEncodedText*/ static Buttons;
            /*JsonEncodedText*/ static CtrlKey;
            /*JsonEncodedText*/ static ShiftKey;
            /*JsonEncodedText*/ static AltKey;
            /*JsonEncodedText*/ static MetaKey;
            /*JsonEncodedText*/ static Type;
            static /*MouseEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ReadProperty(eventArgs, property);
                    }
                }
                return eventArgs;
            }
            static /*void */ ReadProperty(/*MouseEventArgs*/ eventArgs, /*JsonProperty*/ property)
            {
                if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.Detail.EncodedUtf8Bytes))
                {
                    eventArgs.Detail = property.Value.GetInt64();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ScreenX.EncodedUtf8Bytes))
                {
                    eventArgs.ScreenX = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ScreenY.EncodedUtf8Bytes))
                {
                    eventArgs.ScreenY = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ClientX.EncodedUtf8Bytes))
                {
                    eventArgs.ClientX = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ClientY.EncodedUtf8Bytes))
                {
                    eventArgs.ClientY = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.OffsetX.EncodedUtf8Bytes))
                {
                    eventArgs.OffsetX = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.OffsetY.EncodedUtf8Bytes))
                {
                    eventArgs.OffsetY = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.PageX.EncodedUtf8Bytes))
                {
                    eventArgs.PageX = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.PageY.EncodedUtf8Bytes))
                {
                    eventArgs.PageY = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.MovementX.EncodedUtf8Bytes))
                {
                    eventArgs.MovementX = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.MovementY.EncodedUtf8Bytes))
                {
                    eventArgs.MovementY = property.Value.GetDouble();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.Button.EncodedUtf8Bytes))
                {
                    eventArgs.Button = property.Value.GetInt64();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.Buttons.EncodedUtf8Bytes))
                {
                    eventArgs.Buttons = property.Value.GetInt64();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.CtrlKey.EncodedUtf8Bytes))
                {
                    eventArgs.CtrlKey = property.Value.GetBoolean();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ShiftKey.EncodedUtf8Bytes))
                {
                    eventArgs.ShiftKey = property.Value.GetBoolean();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.AltKey.EncodedUtf8Bytes))
                {
                    eventArgs.AltKey = property.Value.GetBoolean();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.MetaKey.EncodedUtf8Bytes))
                {
                    eventArgs.MetaKey = property.Value.GetBoolean();
                }
                else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.Type.EncodedUtf8Bytes))
                {
                    eventArgs.Type = property.Value.GetString();
                }
                else 
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Detail = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("detail", null);
                }
                {
                    this.ScreenX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("screenX", null);
                }
                {
                    this.ScreenY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("screenY", null);
                }
                {
                    this.ClientX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("clientX", null);
                }
                {
                    this.ClientY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("clientY", null);
                }
                {
                    this.OffsetX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("offsetX", null);
                }
                {
                    this.OffsetY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("offsetY", null);
                }
                {
                    this.PageX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("pageX", null);
                }
                {
                    this.PageY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("pageY", null);
                }
                {
                    this.MovementX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("movementX", null);
                }
                {
                    this.MovementY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("movementY", null);
                }
                {
                    this.Button = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("button", null);
                }
                {
                    this.Buttons = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("buttons", null);
                }
                {
                    this.CtrlKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("ctrlKey", null);
                }
                {
                    this.ShiftKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("shiftKey", null);
                }
                {
                    this.AltKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("altKey", null);
                }
                {
                    this.MetaKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("metaKey", null);
                }
                {
                    this.Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
            }
            static $h = 6815753;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":6750217,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":6815753,"h":81611194377,"f":16777256},{"r":65537,"p":[{"n":"eventArgs","p":6750217},{"n":"property","p":2798531}],"n":"ReadProperty","d":6815753,"h":85906161673,"f":16777256}],"l":[{"t":2339779,"n":"Detail","d":6815753,"h":4301783049,"f":4194338},{"t":2339779,"n":"ScreenX","d":6815753,"h":8596750345,"f":4194338},{"t":2339779,"n":"ScreenY","d":6815753,"h":12891717641,"f":4194338},{"t":2339779,"n":"ClientX","d":6815753,"h":17186684937,"f":4194338},{"t":2339779,"n":"ClientY","d":6815753,"h":21481652233,"f":4194338},{"t":2339779,"n":"OffsetX","d":6815753,"h":25776619529,"f":4194338},{"t":2339779,"n":"OffsetY","d":6815753,"h":30071586825,"f":4194338},{"t":2339779,"n":"PageX","d":6815753,"h":34366554121,"f":4194338},{"t":2339779,"n":"PageY","d":6815753,"h":38661521417,"f":4194338},{"t":2339779,"n":"MovementX","d":6815753,"h":42956488713,"f":4194338},{"t":2339779,"n":"MovementY","d":6815753,"h":47251456009,"f":4194338},{"t":2339779,"n":"Button","d":6815753,"h":51546423305,"f":4194338},{"t":2339779,"n":"Buttons","d":6815753,"h":55841390601,"f":4194338},{"t":2339779,"n":"CtrlKey","d":6815753,"h":60136357897,"f":4194338},{"t":2339779,"n":"ShiftKey","d":6815753,"h":64431325193,"f":4194338},{"t":2339779,"n":"AltKey","d":6815753,"h":68726292489,"f":4194338},{"t":2339779,"n":"MetaKey","d":6815753,"h":73021259785,"f":4194338},{"t":2339779,"n":"Type","d":6815753,"h":77316227081,"f":4194338}],"h":6815753}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MouseEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError", ($self) => class FormMappingError extends $.$$.System.Object
        {
            /*char[]*/ static Separators = null;
            /*List<FormattableString>*/ _errorMessages = null;
            $ctor$1(/*string*/ path, /*List<FormattableString>*/ errorMessages, /*string?*/ attemptedValue)
            {
                super.$ctor();
                {
                    this._errorMessages = errorMessages;
                    this.AttemptedValue = attemptedValue;
                    this.Path = path;
                    this.Name = $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError.GetName(this.Path);
                }
                return this;
            }
            /*object*/ Container = null;
            /*string*/ Name = null;
            /*string*/ Path = null;
            /*IReadOnlyList<FormattableString> */ get ErrorMessages()
            {
                return this._errorMessages;
            }
            /*string?*/ AttemptedValue = null;
            static /*string */ GetName(/*string*/ path)
            {
                /*var*/ let errorKey = path;
                /*var*/ let lastSeparatorIndex = $.$$.System.String.LastIndexOfAny$2.call(path, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError.Separators);
                if (lastSeparatorIndex >= 0)
                {
                    if ($.$$.System.String.get_Chars.call(path, lastSeparatorIndex) === /*[*/ 91)
                    {
                        /*var*/ let closingBracket = $.$$.System.String.IndexOf$1.call(path, /*]*/ 93, lastSeparatorIndex);
                        let $t1 = path;
                        errorKey = $.$$.System.String.Substring.call($t1, (((lastSeparatorIndex + 1) | 0)), closingBracket - (((lastSeparatorIndex + 1) | 0)));
                    }
                    else 
                    {
                        let $t1 = path;
                        errorKey = $.$$.System.String.Substring.call($t1, (((lastSeparatorIndex + 1) | 0)), $t1.length - (((lastSeparatorIndex + 1) | 0)));
                    }
                }
                return errorKey;
            }
            /*void */ AddError(/*FormattableString*/ error)
            {
                this._errorMessages.Add(error);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Container = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Separators = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*.*/ 46, /*[*/ 91], [-1], null);
                }
            }
            static $h = 2818057;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":25772621833,"f":50331649},"s":{"r":0,"d":0,"h":30067589129,"f":83886088},"n":"Container","d":2818057,"h":21477654537,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42952491017,"f":50331649},"n":"Name","d":2818057,"h":38657523721,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55837392905,"f":50331649},"n":"Path","d":2818057,"h":51542425609,"f":2097153},{"p":$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.FormattableString).$h,"g":{"r":0,"d":0,"h":64427327497,"f":50331649},"n":"ErrorMessages","d":2818057,"h":60132360201,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":77312229385,"f":50331649},"n":"AttemptedValue","d":2818057,"h":73017262089,"f":2097153}],"m":[{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetName","d":2818057,"h":81607196681,"f":16777250},{"r":65537,"p":[{"n":"error","p":47841281}],"n":"AddError","d":2818057,"h":85902163977,"f":16777224}],"l":[{"t":$.$typeArray($.$$.System.Char).$h,"n":"Separators","d":2818057,"h":4297785353,"f":4194338},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.FormattableString).$h,"n":"_errorMessages","d":2818057,"h":8592752649,"f":4194306}],"c":[{"p":[{"n":"path","p":1310721},{"n":"errorMessages","p":$.$$.System.Collections.Generic.List$$($.$$.System.FormattableString).$h},{"n":"attemptedValue","p":1310721}],"n":".ctor","o":"$ctor$1","d":2818057,"h":12887719945,"f":16777224}],"h":2818057}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FormMappingError`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop", ($self) => class JSComponentInterop extends $.$$.System.Object
        {
            /*string*/ static JSFunctionPropertyName = null;
            /*ConcurrentDictionary<Type, ParameterTypeCache>*/ static ParameterTypeCaches = null;
            /*Static constructor*/ static $cctor()
            {
                if ($.$mac.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$mac.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.System.Action().$ctor($.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCaches, $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCaches.Clear));
                }
            }
            /*int*/ static MaxParameters = 100;
            /*WebRenderer?*/ _renderer = null;
            /*JSComponentConfigurationStore*/ Configuration = null;
            /*WebRenderer */ get Renderer()
            {
                return $.$firstOf(this._renderer, () => { throw new $.$$.System.InvalidOperationException().$ctor$12("This instance is not initialized.") });
            }
            $ctor$1(/*JSComponentConfigurationStore*/ configuration)
            {
                super.$ctor();
                {
                    this.Configuration = configuration;
                }
                return this;
            }
            /*void */ AttachToRenderer(/*WebRenderer*/ renderer)
            {
                this._renderer = renderer;
            }
            /*int */ AddRootComponent(/*string*/ identifier, /*string*/ domElementSelector)
            {
                /*var*/ let componentType;
                if (!this.Configuration.TryGetComponentType(identifier, $.$ref(() => componentType, ($v) => componentType = $v, $.$$.System.Type)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14(`There is no registered JS component with identifier '${identifier}'.`);
                }
                return this.Renderer.AddRootComponent(componentType, domElementSelector);
            }
            /*void */ SetRootComponentParameters(/*int*/ componentId, /*int*/ parameterCount, /*JsonElement*/ parametersJson, /*JsonSerializerOptions*/ jsonOptions)
            {
                if (parameterCount < 0 || parameterCount > 100/*MaxParameters*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20(`${"parameterCount"} must be between 0 and ${100/*MaxParameters*/}.`);
                }
                /*var*/ let componentType = this.Renderer.GetRootTypeType(componentId);
                /*var*/ let parameterViewBuilder = new $.$mac.Microsoft.AspNetCore.Components.ParameterViewBuilder().$ctor$3(parameterCount);
                /*var*/ let parametersJsonEnumerator = parametersJson.EnumerateObject();
                var $en2 = parametersJsonEnumerator.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var jsonProperty = $en2.Current;
                    {
                        /*var*/ let parameterName = jsonProperty.Name;
                        /*var*/ let parameterJsonValue = jsonProperty.Value;
                        /*object?*/ let parameterValue;
                        /*var*/ let parameterInfo;
                        if ($.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.TryGetComponentParameterInfo(componentType, parameterName, $.$ref(() => parameterInfo, ($v) => parameterInfo = $v, $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterInfo)))
                        {
                            parameterValue = (() =>
                            {
                                let $switch2 = parameterInfo.Kind;
                                if ($switch2 === 0/*ParameterKind.Value*/)
                                {
                                    return $.$stj.System.Text.Json.JsonSerializer.Deserialize$15(parameterJsonValue, parameterInfo.Type, jsonOptions);
                                }
                                if ($switch2 === 1/*ParameterKind.EventCallbackWithNoParameters*/)
                                {
                                    return $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.CreateEventCallbackWithNoParameters($.$stj.System.Text.Json.JsonSerializer.Deserialize$34($.$mj.Microsoft.JSInterop.IJSObjectReference, parameterJsonValue, jsonOptions));
                                }
                                if ($switch2 === 2/*ParameterKind.EventCallbackWithSingleParameter*/)
                                {
                                    return $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.CreateEventCallbackWithSingleParameter(parameterInfo.Type, $.$stj.System.Text.Json.JsonSerializer.Deserialize$34($.$mj.Microsoft.JSInterop.IJSObjectReference, parameterJsonValue, jsonOptions));
                                }
                                {
                                    let x;
                                    if ((x = $switch2))
                                    {
                                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Invalid ${"ParameterKind"} '${x}'.`);
                                    }
                                }
                            })();
                        }
                        else 
                        {
                            let $switch2 = parameterJsonValue.ValueKind;
                            switch($switch2)
                            {
                                case 4/*JsonValueKind.Number*/:
                                parameterValue = $.$box(parameterJsonValue.GetDouble(), $.$$.System.Double);
                                break;
                                case 3/*JsonValueKind.String*/:
                                parameterValue = parameterJsonValue.GetString();
                                break;
                                case 5/*JsonValueKind.True*/:
                                case 6/*JsonValueKind.False*/:
                                parameterValue = $.$box(parameterJsonValue.GetBoolean(), $.$$.System.Boolean);
                                break;
                                case 7/*JsonValueKind.Null*/:
                                case 0/*JsonValueKind.Undefined*/:
                                parameterValue = null;
                                break;
                                default:
                                throw new $.$$.System.ArgumentException().$ctor$14(`There is no declared parameter named '${parameterName}', so the supplied object cannot be deserialized.`);
                            }
                        }
                        parameterViewBuilder.Add(parameterName, parameterValue);
                    }
                }
                _ = this.Renderer.RenderRootComponentAsync(componentId, parameterViewBuilder.ToParameterView());
            }
            /*void */ RemoveRootComponent(/*int*/ componentId)
            {
                return this.Renderer.RemoveRootComponent(componentId);
            }
            static /*ParameterTypeCache */ GetComponentParameters(/*Type*/ componentType)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCaches.GetOrAdd(componentType, new ($.$$.System.Func$$$($.$$.System.Type, $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCache))().$ctor($.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop, /*static*/ (/**/ type) =>
                {
                    return new $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCache().$ctor$3(type);
                }, {"r":6094857,"p":[{"n":"type","p":142475265}],"n":"","d":5898249,"h":0,"f":17825826}));
            }
            static /*bool */ IsEventCallbackType(/*Type*/ type)
            {
                return ($.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.GetParameterKind(type) === 1/*ParameterKind.EventCallbackWithNoParameters*/) || ($.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.GetParameterKind(type) === 2/*ParameterKind.EventCallbackWithSingleParameter*/);
            }
            static /*ParameterKind */ GetParameterKind(/*Type*/ type)
            {
                return (() =>
                {
                    {
                        let x;
                        if (((x = type)) && $.$$.System.Type.op_Equality$1(x, $.$mac.Microsoft.AspNetCore.Components.EventCallback.$type))
                        {
                            return 1/*ParameterKind.EventCallbackWithNoParameters*/;
                        }
                    }
                    {
                        let x;
                        if (((x = type)) && x.IsGenericType && $.$$.System.Type.op_Equality$1(x.GetGenericTypeDefinition(), $.$mac.Microsoft.AspNetCore.Components.EventCallback$$().$type))
                        {
                            return 2/*ParameterKind.EventCallbackWithSingleParameter*/;
                        }
                    }
                    return 0/*ParameterKind.Value*/;
                })();
            }
            static /*EventCallback */ CreateEventCallbackWithNoParameters(/*IJSObjectReference?*/ jsObjectReference)
            {
                /*var*/ let callback = jsObjectReference === null ? null : new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                {
                    return $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeVoidAsync(jsObjectReference, "invoke"/*JSFunctionPropertyName*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null)).AsTask();
                }, {"r":133169153,"n":"","d":5898249,"h":0,"f":17825794});
                return new $.$mac.Microsoft.AspNetCore.Components.EventCallback().$ctor$3(null, callback);
            }
            static /*object */ CreateEventCallbackWithSingleParameter(/*Type*/ eventCallbackType, /*IJSObjectReference?*/ jsObjectReference)
            {
                /*var*/ let callback = jsObjectReference === null ? null : new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Threading.Tasks.Task))().$ctor(this,  (/*value*/ value) =>
                {
                    return $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeVoidAsync(jsObjectReference, "invoke"/*JSFunctionPropertyName*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ value ], null, null)).AsTask();
                }, {"r":133169153,"p":[{"n":"value","p":131073}],"n":"","d":5898249,"h":0,"f":17825794});
                return $.$$.System.Activator.CreateInstance$6(eventCallbackType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ null, callback ], null, null));
            }
            static /*bool */ TryGetComponentParameterInfo(/*Type*/ componentType, /*string*/ parameterName, /*out ParameterInfo*/ parameterInfo)
            {
                /*var*/ let cacheForComponent = $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.GetComponentParameters(componentType);
                return cacheForComponent.ParameterInfoByName.TryGetValue(parameterName, parameterInfo);
            }
            static $_ParameterTypeCache;
            static get ParameterTypeCache()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop;
                return $cls.$_ParameterTypeCache ??= $asm.$nstr("$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCache", ($self) => class ParameterTypeCache extends $.$$.System.ValueType
                {
                    /*Dictionary<string, ParameterInfo>*/  get ParameterInfoByName() { return this.$getField(0, 4); }
                    /*Dictionary<string, ParameterInfo>*/  set ParameterInfoByName(value) { this.$setField(0, 4, value); }
                    $ctor$3(/*Type*/ componentType)
                    {
                        super.$ctor$1();
                        {
                            this.ParameterInfoByName = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterInfo))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                            /*var*/ let candidateProperties = $.$mac.Microsoft.AspNetCore.Components.Reflection.ComponentProperties.GetCandidateBindableProperties(componentType);
                            var $en5 = candidateProperties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var propertyInfo = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    if ($.$$.System.Reflection.CustomAttributeExtensions.IsDefined$2(propertyInfo, $.$mac.Microsoft.AspNetCore.Components.ParameterAttribute.$type))
                                    {
                                        this.ParameterInfoByName.Add(propertyInfo.Name, new $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterInfo().$ctor$3(propertyInfo.PropertyType));
                                    }
                                }
                            }
                        }
                        return this;
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ParameterInfoByName = this.ParameterInfoByName;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ParameterInfoByName = null;
                    }
                    static $h = 6094857;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterInfo).$h,"n":"ParameterInfoByName","d":6094857,"h":4301062153,"f":4194305}],"c":[{"p":[{"n":"componentType","p":142475265}],"n":".ctor","o":"$ctor$3","d":6094857,"h":8596029449,"f":16777217},{"n":".ctor","o":"$ctor$2","d":6094857,"h":12890996745,"f":16777217}],"d":5898249,"h":6094857}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `JSComponentInterop.ParameterTypeCache`; }
                }, $cls, ($v) => $cls.$_ParameterTypeCache = $v);
            }
            static $_ParameterKind;
            static get ParameterKind()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop;
                return $cls.$_ParameterKind ??= $asm.$nstr("$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterKind", ($self) => class ParameterKind extends $.$$.System.Enum
                {
                    static Value = 0;
                    static EventCallbackWithNoParameters = 1;
                    static EventCallbackWithSingleParameter = 2;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Value": 0n,
                            "EventCallbackWithNoParameters": 1n,
                            "EventCallbackWithSingleParameter": 2n
                        };
                    }
                    static $h = 6029321;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":6029321,"n":"Value","d":6029321,"h":4300996617,"f":4194337},{"t":6029321,"n":"EventCallbackWithNoParameters","d":6029321,"h":8595963913,"f":4194337},{"t":6029321,"n":"EventCallbackWithSingleParameter","d":6029321,"h":12890931209,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":6029321,"h":17185898505,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":5898249,"h":6029321}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `JSComponentInterop.ParameterKind`; }
                }, $cls, ($v) => $cls.$_ParameterKind = $v);
            }
            static $_ParameterInfo;
            static get ParameterInfo()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop;
                return $cls.$_ParameterInfo ??= $asm.$nstr("$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterInfo", ($self) => class ParameterInfo extends $.$$.System.ValueType
                {
                    /*Type*/ Type = null;
                    /*ParameterKind*/ Kind = 0;
                    $ctor$3(/*Type*/ parameterType)
                    {
                        super.$ctor$1();
                        {
                            this.Type = parameterType;
                            this.Kind = $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.GetParameterKind(parameterType);
                        }
                        return this;
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.Kind = this.Kind;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Kind = 0;
                    }
                    static $h = 5963785;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":12890865673,"f":50331649},"n":"Type","d":5963785,"h":8595898377,"f":2097153},{"p":6029321,"g":{"r":0,"d":0,"h":25775767561,"f":50331649},"n":"Kind","d":5963785,"h":21480800265,"f":2097153}],"c":[{"p":[{"n":"parameterType","p":142475265}],"n":".ctor","o":"$ctor$3","d":5963785,"h":30070734857,"f":16777217},{"n":".ctor","o":"$ctor$2","d":5963785,"h":34365702153,"f":16777217}],"d":5898249,"h":5963785}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `JSComponentInterop.ParameterInfo`; }
                }, $cls, ($v) => $cls.$_ParameterInfo = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.JSFunctionPropertyName = "invoke";
                }
                {
                    this.ParameterTypeCaches = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCache))().$ctor$1();
                }
            }
            static $h = 5898249;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":6488073,"g":{"r":0,"d":0,"h":34365636617,"f":50331656},"n":"Configuration","d":5898249,"h":30070669321,"f":2097160},{"p":3866633,"g":{"r":0,"d":0,"h":42955571209,"f":50331650},"n":"Renderer","d":5898249,"h":38660603913,"f":2097154}],"m":[{"r":65537,"p":[{"n":"renderer","p":3866633}],"n":"AttachToRenderer","d":5898249,"h":51545505801,"f":16777224},{"r":655361,"p":[{"n":"identifier","p":1310721},{"n":"domElementSelector","p":1310721}],"n":"AddRootComponent","d":5898249,"h":55840473097,"f":16777360},{"r":65537,"p":[{"n":"componentId","p":655361},{"n":"parameterCount","p":655361},{"n":"parametersJson","p":2143171},{"n":"jsonOptions","p":3388355}],"n":"SetRootComponentParameters","d":5898249,"h":60135440393,"f":16777232},{"r":65537,"p":[{"n":"componentId","p":655361}],"n":"RemoveRootComponent","d":5898249,"h":64430407689,"f":16777360},{"r":6094857,"p":[{"n":"componentType","p":142475265}],"n":"GetComponentParameters","d":5898249,"h":68725374985,"f":16777256},{"r":262145,"p":[{"n":"type","p":142475265}],"n":"IsEventCallbackType","d":5898249,"h":73020342281,"f":16777256},{"r":6029321,"p":[{"n":"type","p":142475265}],"n":"GetParameterKind","d":5898249,"h":77315309577,"f":16777250},{"r":2097160,"p":[{"n":"jsObjectReference","p":458782}],"n":"CreateEventCallbackWithNoParameters","d":5898249,"h":81610276873,"f":16777250},{"r":131073,"p":[{"n":"eventCallbackType","p":142475265},{"n":"jsObjectReference","p":458782}],"n":"CreateEventCallbackWithSingleParameter","d":5898249,"h":85905244169,"f":16777250},{"r":262145,"p":[{"n":"componentType","p":142475265},{"n":"parameterName","p":1310721},{"n":"parameterInfo","p":5963785,"f":2}],"n":"TryGetComponentParameterInfo","d":5898249,"h":90200211465,"f":16777250}],"l":[{"t":1310721,"n":"JSFunctionPropertyName","d":5898249,"h":4300865545,"f":4194338},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop.ParameterTypeCache).$h,"n":"ParameterTypeCaches","d":5898249,"h":8595832841,"f":4194338},{"t":655361,"n":"MaxParameters","d":5898249,"h":17185767433,"f":4194338},{"t":3866633,"n":"_renderer","d":5898249,"h":21480734729,"f":4194306}],"c":[{"p":[{"n":"configuration","p":6488073}],"n":".ctor","o":"$ctor$1","d":5898249,"h":47250538505,"f":16777217}],"j":[6094857,6029321,5963785],"h":5898249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSComponentInterop`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgsReader", ($self) => class WheelEventArgsReader
        {
            /*JsonEncodedText*/ static DeltaX;
            /*JsonEncodedText*/ static DeltaY;
            /*JsonEncodedText*/ static DeltaZ;
            /*JsonEncodedText*/ static DeltaMode;
            static /*WheelEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs().$ctor$3();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgsReader.DeltaX.EncodedUtf8Bytes))
                        {
                            eventArgs.DeltaX = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgsReader.DeltaY.EncodedUtf8Bytes))
                        {
                            eventArgs.DeltaY = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgsReader.DeltaZ.EncodedUtf8Bytes))
                        {
                            eventArgs.DeltaZ = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgsReader.DeltaMode.EncodedUtf8Bytes))
                        {
                            eventArgs.DeltaMode = property.Value.GetInt64();
                        }
                        else 
                        {
                            $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.ReadProperty(eventArgs, property);
                        }
                    }
                }
                return eventArgs;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DeltaX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("deltaX", null);
                }
                {
                    this.DeltaY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("deltaY", null);
                }
                {
                    this.DeltaZ = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("deltaZ", null);
                }
                {
                    this.DeltaMode = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("deltaMode", null);
                }
            }
            static $h = 8257545;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":8192009,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":8257545,"h":21483094025,"f":16777256}],"l":[{"t":2339779,"n":"DeltaX","d":8257545,"h":4303224841,"f":4194338},{"t":2339779,"n":"DeltaY","d":8257545,"h":8598192137,"f":4194338},{"t":2339779,"n":"DeltaZ","d":8257545,"h":12893159433,"f":4194338},{"t":2339779,"n":"DeltaMode","d":8257545,"h":17188126729,"f":4194338}],"h":8257545}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WheelEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext", ($self) => class FormMappingContext extends $.$$.System.Object
        {
            /*Dictionary<string, FormMappingError>?*/ _errors = null;
            /*List<KeyValuePair<string, FormMappingError>>?*/ _pendingErrors = null;
            /*Dictionary<string, Dictionary<string, FormMappingError>>?*/ _errorsByFormName = null;
            $ctor$1(/*string*/ mappingScopeName)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(mappingScopeName, "mappingScopeName");
                    this.MappingScopeName = mappingScopeName;
                }
                return this;
            }
            /*string*/ MappingScopeName = null;
            /*FormMappingError? */ GetErrors$1(/*string*/ key)
            {
                /*var*/ let mappingError;
                return (this._errors?.TryGetValue(key, $.$ref(() => mappingError, ($v) => mappingError = $v, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)) ?? null) === true ? mappingError : null;
            }
            /*FormMappingError? */ GetErrors(/*string*/ formName, /*string*/ key)
            {
                /*var*/ let formErrors;
                /*var*/ let mappingError;
                return (this._errorsByFormName?.TryGetValue(formName, $.$ref(() => formErrors, ($v) => formErrors = $v, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))) ?? null) === true && formErrors.TryGetValue(key, $.$ref(() => mappingError, ($v) => mappingError = $v, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)) === true ? mappingError : null;
            }
            /*IEnumerable<FormMappingError> */ GetAllErrors()
            {
                return $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext.GetAllErrorsCore(this._errors);
            }
            static /*IEnumerable<FormMappingError> */ GetAllErrorsCore(/*Dictionary<string, FormMappingError>?*/ errors)
            {
                if (errors === null)
                {
                    return $.$$.System.Array.Empty($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError);
                }
                return errors.Values;
            }
            /*IEnumerable<FormMappingError> */ GetAllErrors$1(/*string*/ formName)
            {
                /*var*/ let formErrors;
                return (this._errorsByFormName?.TryGetValue(formName, $.$ref(() => formErrors, ($v) => formErrors = $v, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))) ?? null) === true ? $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext.GetAllErrorsCore(formErrors) : $.$$.System.Array.Empty($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError);
            }
            /*string? */ GetAttemptedValue$1(/*string*/ key)
            {
                /*var*/ let mappingError;
                return (this._errors?.TryGetValue(key, $.$ref(() => mappingError, ($v) => mappingError = $v, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)) ?? null) === true ? mappingError.AttemptedValue : null;
            }
            /*string? */ GetAttemptedValue(/*string*/ formName, /*string*/ key)
            {
                /*var*/ let formErrors;
                /*var*/ let mappingError;
                return (this._errorsByFormName?.TryGetValue(formName, $.$ref(() => formErrors, ($v) => formErrors = $v, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))) ?? null) === true && formErrors.TryGetValue(key, $.$ref(() => mappingError, ($v) => mappingError = $v, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)) ? mappingError.AttemptedValue : null;
            }
            /*void */ AddError(/*string*/ key, /*FormattableString*/ error, /*string?*/ attemptedValue)
            {
                this._errors ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))().$ctor$1();
                $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext.AddErrorCore(this._errors, key, error, attemptedValue, $.$ref(() => this._pendingErrors, ($v) => this._pendingErrors = $v, $.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))));
            }
            static /*void */ AddErrorCore(/*Dictionary<string, FormMappingError>*/ errors, /*string*/ key, /*FormattableString*/ error, /*string?*/ attemptedValue, /*ref List<KeyValuePair<string, FormMappingError>>?*/ pendingErrors)
            {
                /*var*/ let mappingError;
                if (!errors.TryGetValue(key, $.$ref(() => mappingError, ($v) => mappingError = $v, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)))
                {
                    mappingError = new $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError().$ctor$1(key, (() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.FormattableString)()
                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.FormattableString);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Add(error);
                        return $i2;
                    })(), attemptedValue);
                    errors.Add(key, mappingError);
                    pendingErrors.$v ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)))().$ctor$1();
                    pendingErrors.$v.Add(new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))().$ctor$3(key, mappingError));
                }
                else 
                {
                    mappingError.AddError(error);
                }
            }
            /*void */ AddError$1(/*string*/ formName, /*string*/ key, /*FormattableString*/ error, /*string?*/ attemptedValue)
            {
                this._errorsByFormName ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)))().$ctor$1();
                /*var*/ let formErrors;
                if (!this._errorsByFormName.TryGetValue(formName, $.$ref(() => formErrors, ($v) => formErrors = $v, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))))
                {
                    formErrors = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))().$ctor$1();
                    this._errorsByFormName.Add(formName, formErrors);
                }
                $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext.AddErrorCore(formErrors, key, error, attemptedValue, $.$ref(() => this._pendingErrors, ($v) => this._pendingErrors = $v, $.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))));
            }
            /*void */ AttachParentValue(/*string*/ key, /*object*/ value)
            {
                if (this._pendingErrors === null)
                {
                    return;
                }
                for(/*var*/ let i = 0; i < this._pendingErrors.Count; i++)
                {
                    /*var*/ let  [ errorKey, error ] = $.$destructure(this._pendingErrors.get_Item(i));
                    if (!$.$$.System.String.StartsWith$2.call(errorKey, key, 4/*StringComparison.Ordinal*/))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`'${errorKey}' does must start with '${key}'`);
                    }
                    error.Container = value;
                }
                this._pendingErrors.Clear();
            }
            /*void */ SetErrors(/*string*/ formName, /*FormMappingContext*/ childContext)
            {
                /*var*/ let formErrors;
                if (this._errorsByFormName === null || !this._errorsByFormName.TryGetValue(formName, $.$ref(() => formErrors, ($v) => formErrors = $v, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError))))
                {
                    return;
                }
                childContext._errors = formErrors;
            }
            static $h = 1245193;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30066016265,"f":50331649},"n":"MappingScopeName","d":1245193,"h":25771048969,"f":2097153}],"m":[{"r":2818057,"p":[{"n":"key","p":1310721}],"n":"GetErrors","o":"@$1","d":1245193,"h":34360983561,"f":16777217},{"r":2818057,"p":[{"n":"formName","p":1310721},{"n":"key","p":1310721}],"n":"GetErrors","d":1245193,"h":38655950857,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError).$h,"n":"GetAllErrors","d":1245193,"h":42950918153,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError).$h,"p":[{"n":"errors","p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError).$h}],"n":"GetAllErrorsCore","d":1245193,"h":47245885449,"f":16777250},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError).$h,"p":[{"n":"formName","p":1310721}],"n":"GetAllErrors","o":"@$1","d":1245193,"h":51540852745,"f":16777217},{"r":1310721,"p":[{"n":"key","p":1310721}],"n":"GetAttemptedValue","o":"@$1","d":1245193,"h":55835820041,"f":16777217},{"r":1310721,"p":[{"n":"formName","p":1310721},{"n":"key","p":1310721}],"n":"GetAttemptedValue","d":1245193,"h":60130787337,"f":16777217},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"error","p":47841281},{"n":"attemptedValue","p":1310721}],"n":"AddError","d":1245193,"h":64425754633,"f":16777224},{"r":65537,"p":[{"n":"errors","p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError).$h},{"n":"key","p":1310721},{"n":"error","p":47841281},{"n":"attemptedValue","p":1310721},{"n":"pendingErrors","p":$.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)).$h,"f":4}],"n":"AddErrorCore","d":1245193,"h":68720721929,"f":16777250},{"r":65537,"p":[{"n":"formName","p":1310721},{"n":"key","p":1310721},{"n":"error","p":47841281},{"n":"attemptedValue","p":1310721}],"n":"AddError","o":"@$1","d":1245193,"h":73015689225,"f":16777224},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":131073}],"n":"AttachParentValue","d":1245193,"h":77310656521,"f":16777224},{"r":65537,"p":[{"n":"formName","p":1310721},{"n":"childContext","p":1245193}],"n":"SetErrors","d":1245193,"h":81605623817,"f":16777224}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError).$h,"n":"_errors","d":1245193,"h":4296212489,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)).$h,"n":"_pendingErrors","d":1245193,"h":8591179785,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingError)).$h,"n":"_errorsByFormName","d":1245193,"h":12886147081,"f":4194306}],"c":[{"p":[{"n":"mappingScopeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":1245193,"h":17181114377,"f":16777224}],"h":1245193}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FormMappingContext`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader", ($self) => class TouchEventArgsReader
        {
            /*JsonEncodedText*/ static Detail;
            /*JsonEncodedText*/ static ClientX;
            /*JsonEncodedText*/ static ClientY;
            /*JsonEncodedText*/ static PageX;
            /*JsonEncodedText*/ static PageY;
            /*JsonEncodedText*/ static ScreenX;
            /*JsonEncodedText*/ static ScreenY;
            /*JsonEncodedText*/ static CtrlKey;
            /*JsonEncodedText*/ static ShiftKey;
            /*JsonEncodedText*/ static AltKey;
            /*JsonEncodedText*/ static MetaKey;
            /*JsonEncodedText*/ static Type;
            /*JsonEncodedText*/ static Identifier;
            /*JsonEncodedText*/ static ChangedTouches;
            /*JsonEncodedText*/ static TargetTouches;
            /*JsonEncodedText*/ static Touches;
            static /*TouchEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.Detail.EncodedUtf8Bytes))
                        {
                            eventArgs.Detail = property.Value.GetInt64();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ChangedTouches.EncodedUtf8Bytes))
                        {
                            eventArgs.ChangedTouches = $.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ReadTouchPointArray(property.Value);
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.TargetTouches.EncodedUtf8Bytes))
                        {
                            eventArgs.TargetTouches = $.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ReadTouchPointArray(property.Value);
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.Touches.EncodedUtf8Bytes))
                        {
                            eventArgs.Touches = $.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ReadTouchPointArray(property.Value);
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.CtrlKey.EncodedUtf8Bytes))
                        {
                            eventArgs.CtrlKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ShiftKey.EncodedUtf8Bytes))
                        {
                            eventArgs.ShiftKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.AltKey.EncodedUtf8Bytes))
                        {
                            eventArgs.AltKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.MetaKey.EncodedUtf8Bytes))
                        {
                            eventArgs.MetaKey = property.Value.GetBoolean();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.Type.EncodedUtf8Bytes))
                        {
                            eventArgs.Type = property.Value.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return eventArgs;
            }
            static /*TouchPoint[] */ ReadTouchPointArray(/*JsonElement*/ jsonElement)
            {
                /*var*/ let touchPoints = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint), null, [jsonElement.GetArrayLength()], null);
                /*var*/ let i = 0;
                var $en2 = jsonElement.EnumerateArray().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        $.$$.System.Array.$WriteT1.call(touchPoints, $.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ReadTouchPoint(item), i++);
                    }
                }
                return touchPoints;
            }
            static /*TouchPoint */ ReadTouchPoint(/*JsonElement*/ jsonElement)
            {
                /*var*/ let touchPoint = new $.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint().$ctor$1();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ClientX.EncodedUtf8Bytes))
                        {
                            touchPoint.ClientX = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ClientY.EncodedUtf8Bytes))
                        {
                            touchPoint.ClientY = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.Identifier.EncodedUtf8Bytes))
                        {
                            touchPoint.Identifier = property.Value.GetInt64();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.PageX.EncodedUtf8Bytes))
                        {
                            touchPoint.PageX = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.PageY.EncodedUtf8Bytes))
                        {
                            touchPoint.PageY = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ScreenX.EncodedUtf8Bytes))
                        {
                            touchPoint.ScreenX = property.Value.GetDouble();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.ScreenY.EncodedUtf8Bytes))
                        {
                            touchPoint.ScreenY = property.Value.GetDouble();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return touchPoint;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Detail = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("detail", null);
                }
                {
                    this.ClientX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("clientX", null);
                }
                {
                    this.ClientY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("clientY", null);
                }
                {
                    this.PageX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("pageX", null);
                }
                {
                    this.PageY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("pageY", null);
                }
                {
                    this.ScreenX = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("screenX", null);
                }
                {
                    this.ScreenY = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("screenY", null);
                }
                {
                    this.CtrlKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("ctrlKey", null);
                }
                {
                    this.ShiftKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("shiftKey", null);
                }
                {
                    this.AltKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("altKey", null);
                }
                {
                    this.MetaKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("metaKey", null);
                }
                {
                    this.Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
                {
                    this.Identifier = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("identifier", null);
                }
                {
                    this.ChangedTouches = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("changedTouches", null);
                }
                {
                    this.TargetTouches = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("targetTouches", null);
                }
                {
                    this.Touches = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("touches", null);
                }
            }
            static $h = 7340041;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":7274505,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":7340041,"h":73021784073,"f":16777256},{"r":$.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint).$h,"p":[{"n":"jsonElement","p":2143171}],"n":"ReadTouchPointArray","d":7340041,"h":77316751369,"f":16777250},{"r":7405577,"p":[{"n":"jsonElement","p":2143171}],"n":"ReadTouchPoint","d":7340041,"h":81611718665,"f":16777250}],"l":[{"t":2339779,"n":"Detail","d":7340041,"h":4302307337,"f":4194338},{"t":2339779,"n":"ClientX","d":7340041,"h":8597274633,"f":4194338},{"t":2339779,"n":"ClientY","d":7340041,"h":12892241929,"f":4194338},{"t":2339779,"n":"PageX","d":7340041,"h":17187209225,"f":4194338},{"t":2339779,"n":"PageY","d":7340041,"h":21482176521,"f":4194338},{"t":2339779,"n":"ScreenX","d":7340041,"h":25777143817,"f":4194338},{"t":2339779,"n":"ScreenY","d":7340041,"h":30072111113,"f":4194338},{"t":2339779,"n":"CtrlKey","d":7340041,"h":34367078409,"f":4194338},{"t":2339779,"n":"ShiftKey","d":7340041,"h":38662045705,"f":4194338},{"t":2339779,"n":"AltKey","d":7340041,"h":42957013001,"f":4194338},{"t":2339779,"n":"MetaKey","d":7340041,"h":47251980297,"f":4194338},{"t":2339779,"n":"Type","d":7340041,"h":51546947593,"f":4194338},{"t":2339779,"n":"Identifier","d":7340041,"h":55841914889,"f":4194338},{"t":2339779,"n":"ChangedTouches","d":7340041,"h":60136882185,"f":4194338},{"t":2339779,"n":"TargetTouches","d":7340041,"h":64431849481,"f":4194338},{"t":2339779,"n":"Touches","d":7340041,"h":68726816777,"f":4194338}],"h":7340041}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `TouchEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Routing.NavigationLockInterop", ($self) => class NavigationLockInterop extends $.$$.System.Object
        {
            /*string*/ static Prefix = null;
            /*string*/ static EnableNavigationPrompt = null;
            /*string*/ static DisableNavigationPrompt = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Prefix = "Blazor._internal.NavigationLock.";
                }
                {
                    this.EnableNavigationPrompt = "Blazor._internal.NavigationLock.enableNavigationPrompt";
                }
                {
                    this.DisableNavigationPrompt = "Blazor._internal.NavigationLock.disableNavigationPrompt";
                }
            }
            static $h = 4259849;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Prefix","d":4259849,"h":4299227145,"f":4194338},{"t":1310721,"n":"EnableNavigationPrompt","d":4259849,"h":8594194441,"f":4194337},{"t":1310721,"n":"DisableNavigationPrompt","d":4259849,"h":12889161737,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":4259849,"h":17184129033,"f":16777217}],"h":4259849}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `NavigationLockInterop`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.WebEventData", ($self) => class WebEventData extends $.$$.System.Object
        {
            static /*WebEventData */ Parse$1(/*Renderer*/ renderer, /*JsonSerializerOptions*/ jsonSerializerOptions, /*JsonElement*/ eventDescriptorJson, /*JsonElement*/ eventArgsJson)
            {
                /*WebEventDescriptor*/ let eventDescriptor;
                try
                {
                    eventDescriptor = $.$macw.Microsoft.AspNetCore.Components.Web.WebEventDescriptorReader.Read(eventDescriptorJson);
                }
                catch(e)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11("Error parsing the event descriptor", e);
                }
                return $.$macw.Microsoft.AspNetCore.Components.Web.WebEventData.Parse(renderer, jsonSerializerOptions, eventDescriptor, eventArgsJson);
            }
            static /*WebEventData */ Parse(/*Renderer*/ renderer, /*JsonSerializerOptions*/ jsonSerializerOptions, /*WebEventDescriptor*/ eventDescriptor, /*JsonElement*/ eventArgsJson)
            {
                /*var*/ let parsedEventArgs = $.$macw.Microsoft.AspNetCore.Components.Web.WebEventData.ParseEventArgsJson(renderer, jsonSerializerOptions, eventDescriptor.EventHandlerId, eventDescriptor.EventName, eventArgsJson);
                return new $.$macw.Microsoft.AspNetCore.Components.Web.WebEventData().$ctor$1(eventDescriptor.EventHandlerId, eventDescriptor.EventFieldInfo, parsedEventArgs);
            }
            $ctor$1(/*ulong*/ eventHandlerId, /*EventFieldInfo?*/ eventFieldInfo, /*EventArgs*/ eventArgs)
            {
                super.$ctor();
                {
                    this.EventHandlerId = eventHandlerId;
                    this.EventFieldInfo = eventFieldInfo;
                    this.EventArgs = eventArgs;
                }
                return this;
            }
            /*ulong*/ EventHandlerId = 0n;
            /*EventFieldInfo?*/ EventFieldInfo = null;
            /*EventArgs*/ EventArgs = null;
            static /*EventArgs */ ParseEventArgsJson(/*Renderer*/ renderer, /*JsonSerializerOptions*/ jsonSerializerOptions, /*ulong*/ eventHandlerId, /*string*/ eventName, /*JsonElement*/ eventArgsJson)
            {
                try
                {
                    /*var*/ let eventArgs;
                    if ($.$macw.Microsoft.AspNetCore.Components.Web.WebEventData.TryDeserializeStandardWebEventArgs(eventName, eventArgsJson, $.$ref(() => eventArgs, ($v) => eventArgs = $v, $.$$.System.EventArgs)))
                    {
                        return eventArgs;
                    }
                    /*var*/ let eventArgsType = renderer.GetEventArgsType(eventHandlerId);
                    return $.$cast($.$stj.System.Text.Json.JsonSerializer.Deserialize$9(eventArgsJson.GetRawText(), eventArgsType, jsonSerializerOptions), $.$$.System.EventArgs);
                }
                catch(e)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11(`There was an error parsing the event arguments. EventId: '${eventHandlerId}'.`, e);
                }
            }
            static /*bool */ TryDeserializeStandardWebEventArgs(/*string*/ eventName, /*JsonElement*/ eventArgsJson, /*out EventArgs?*/ eventArgs)
            {
                switch(eventName)
                {
                    case "input":
                    case "change":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.ChangeEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "copy":
                    case "cut":
                    case "paste":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.DragEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "focus":
                    case "blur":
                    case "focusin":
                    case "focusout":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "keydown":
                    case "keyup":
                    case "keypress":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "contextmenu":
                    case "click":
                    case "mouseover":
                    case "mouseout":
                    case "mousemove":
                    case "mousedown":
                    case "mouseup":
                    case "dblclick":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "error":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "loadstart":
                    case "timeout":
                    case "abort":
                    case "load":
                    case "loadend":
                    case "progress":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchenter":
                    case "touchleave":
                    case "touchstart":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointerenter":
                    case "pointerleave":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "wheel":
                    case "mousewheel":
                    eventArgs.$v = $.$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgsReader.Read(eventArgsJson);
                    return true;
                    case "cancel":
                    case "close":
                    case "toggle":
                    eventArgs.$v = $.$$.System.EventArgs.Empty;
                    return true;
                    default:
                    eventArgs.$v = null;
                    return false;
                }
            }
            static $h = 7995401;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":983041,"g":{"r":0,"d":0,"h":25777799177,"f":50331649},"n":"EventHandlerId","d":7995401,"h":21482831881,"f":2097153},{"p":8192008,"g":{"r":0,"d":0,"h":38662701065,"f":50331649},"n":"EventFieldInfo","d":7995401,"h":34367733769,"f":2097153},{"p":46989313,"g":{"r":0,"d":0,"h":51547602953,"f":50331649},"n":"EventArgs","d":7995401,"h":47252635657,"f":2097153}],"m":[{"r":7995401,"p":[{"n":"renderer","p":8454152},{"n":"jsonSerializerOptions","p":3388355},{"n":"eventDescriptorJson","p":2143171},{"n":"eventArgsJson","p":2143171}],"n":"Parse","o":"@$1","d":7995401,"h":4302962697,"f":16777249},{"r":7995401,"p":[{"n":"renderer","p":8454152},{"n":"jsonSerializerOptions","p":3388355},{"n":"eventDescriptor","p":3801097},{"n":"eventArgsJson","p":2143171}],"n":"Parse","d":7995401,"h":8597929993,"f":16777249},{"r":46989313,"p":[{"n":"renderer","p":8454152},{"n":"jsonSerializerOptions","p":3388355},{"n":"eventHandlerId","p":983041},{"n":"eventName","p":1310721},{"n":"eventArgsJson","p":2143171}],"n":"ParseEventArgsJson","d":7995401,"h":55842570249,"f":16777250},{"r":262145,"p":[{"n":"eventName","p":1310721},{"n":"eventArgsJson","p":2143171},{"n":"eventArgs","p":46989313,"f":2}],"n":"TryDeserializeStandardWebEventArgs","d":7995401,"h":60137537545,"f":16777250}],"c":[{"p":[{"n":"eventHandlerId","p":983041},{"n":"eventFieldInfo","p":8192008},{"n":"eventArgs","p":46989313}],"n":".ctor","o":"$ctor$1","d":7995401,"h":12892897289,"f":16777218}],"h":7995401}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebEventData`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.BindAttributes", ($self) => class BindAttributes
        {
            static $h = 4587529;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4587529,"a":[{"t":65545,"c":4295032841,"a":[{"t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":false,"t":262145},{"t":1310721}]},{"t":65545,"c":4295032841,"a":[{"t":1310721},{"v":"value","t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":false,"t":262145},{"t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"checkbox","t":1310721},{"t":1310721},{"v":"checked","t":1310721},{"v":"onchange","t":1310721},{"v":false,"t":262145},{"t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"text","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":false,"t":262145},{"t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"number","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"number","t":1310721},{"v":"value","t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"date","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"yyyy-MM-dd","t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"date","t":1310721},{"v":"value","t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"yyyy-MM-dd","t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"datetime-local","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"yyyy-MM-ddTHH:mm:ss","t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"datetime-local","t":1310721},{"v":"value","t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"yyyy-MM-ddTHH:mm:ss","t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"month","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"yyyy-MM","t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"month","t":1310721},{"v":"value","t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"yyyy-MM","t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"time","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"HH:mm:ss","t":1310721}]},{"t":65545,"c":4295032841,"a":[{"v":"time","t":1310721},{"v":"value","t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721},{"v":true,"t":262145},{"v":"HH:mm:ss","t":1310721}]},{"t":458760,"c":4295426056,"a":[{"v":"select","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721}]},{"t":458760,"c":4295426056,"a":[{"v":"textarea","t":1310721},{"t":1310721},{"v":"value","t":1310721},{"v":"onchange","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `BindAttributes`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgsReader", ($self) => class ErrorEventArgsReader
        {
            /*JsonEncodedText*/ static Message;
            /*JsonEncodedText*/ static Colno;
            /*JsonEncodedText*/ static Filename;
            /*JsonEncodedText*/ static Lineno;
            /*JsonEncodedText*/ static Type;
            static /*ErrorEventArgs */ Read(/*JsonElement*/ jsonElement)
            {
                /*var*/ let eventArgs = new $.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs().$ctor$2();
                var $en2 = jsonElement.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgsReader.Message.EncodedUtf8Bytes))
                        {
                            eventArgs.Message = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgsReader.Colno.EncodedUtf8Bytes))
                        {
                            eventArgs.Colno = property.Value.GetInt32();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgsReader.Filename.EncodedUtf8Bytes))
                        {
                            eventArgs.Filename = property.Value.GetString();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgsReader.Lineno.EncodedUtf8Bytes))
                        {
                            eventArgs.Lineno = property.Value.GetInt32();
                        }
                        else if (property.NameEquals($.$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgsReader.Type.EncodedUtf8Bytes))
                        {
                            eventArgs.Type = property.Value.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unknown property ${property.Name}`);
                        }
                    }
                }
                return eventArgs;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Message = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("message", null);
                }
                {
                    this.Colno = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("colno", null);
                }
                {
                    this.Filename = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("filename", null);
                }
                {
                    this.Lineno = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("lineno", null);
                }
                {
                    this.Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                }
            }
            static $h = 5242889;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":5177353,"p":[{"n":"jsonElement","p":2143171}],"n":"Read","d":5242889,"h":25775046665,"f":16777256}],"l":[{"t":2339779,"n":"Message","d":5242889,"h":4300210185,"f":4194338},{"t":2339779,"n":"Colno","d":5242889,"h":8595177481,"f":4194338},{"t":2339779,"n":"Filename","d":5242889,"h":12890144777,"f":4194338},{"t":2339779,"n":"Lineno","d":5242889,"h":17185112073,"f":4194338},{"t":2339779,"n":"Type","d":5242889,"h":21480079369,"f":4194338}],"h":5242889}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ErrorEventArgsReader`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.JsonConverterFactoryTypeInfoResolver<>", (T) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.JsonConverterFactoryTypeInfoResolver<>", [T], ($self) => class JsonConverterFactoryTypeInfoResolver$$ extends $.$$.System.Object
        {
            /*JsonConverterFactoryTypeInfoResolver<T>*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*JsonTypeInfo? */ GetTypeInfo(/*Type*/ type, /*JsonSerializerOptions*/ options)
            {
                if ($.$$.System.Type.op_Inequality$1(type, T.$type))
                {
                    return null;
                }
                var $en2 = options.Converters.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var converter = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        let factory;
                        if (!$.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory, { set $v(v){ factory = v; } }) || !factory.CanConvert(type))
                        {
                            continue;
                        }
                        let converterToUse;
                        if (!(factory.CreateConverter(type, options) !== null && ((converterToUse = factory.CreateConverter(type, options), converterToUse != null && true))))
                        {
                            continue;
                        }
                        return $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo(T, options, converterToUse);
                    }
                }
                return null;
            }
            //Generated interface implemetation for System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver.GetTypeInfo(System.Type, System.Text.Json.JsonSerializerOptions)
            System$Text$Json$Serialization$Metadata$IJsonTypeInfoResolver$GetTypeInfo()
            {
                return this.GetTypeInfo(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new ($.$macw.Microsoft.AspNetCore.Components.JsonConverterFactoryTypeInfoResolver$$(T))().$ctor$1();
                }
            }
            static $h = 3670025;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":16823235,"p":[{"n":"type","p":142475265},{"n":"options","p":3388355}],"n":"GetTypeInfo","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"l":[{"t":this.$h,"n":"Instance","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777218}],"i":[15971267],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver ]; }
            static get $fullName() { return `JsonConverterFactoryTypeInfoResolver<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryToken", ($self) => class AntiforgeryToken extends $.$$.System.Object
        {
            /*RenderHandle*/ _handle;
            /*bool*/ _hasRendered = false;
            /*AntiforgeryRequestToken?*/ _requestToken = null;
            /*IServiceProvider*/ Services = null;
            /*void */ Microsoft$AspNetCore$Components$IComponent$Attach(/*RenderHandle*/ renderHandle)
            {
                this._handle = renderHandle;
                this._requestToken = ($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider, this.Services)?.GetAntiforgeryToken() ?? null);
            }
            /*Task */ Microsoft$AspNetCore$Components$IComponent$SetParametersAsync(/*ParameterView*/ parameters)
            {
                if (!this._hasRendered)
                {
                    this._hasRendered = true;
                    if (this._requestToken !== null)
                    {
                        this._handle.Render(new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.RenderField));
                    }
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            /*void */ RenderField(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "input");
                builder.AddAttribute$3(1, "type", "hidden");
                builder.AddAttribute$3(2, "name", this._requestToken.FormFieldName);
                builder.AddAttribute$3(3, "value", this._requestToken.Value);
                builder.CloseElement();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._handle = $.$default($.$mac.Microsoft.AspNetCore.Components.RenderHandle);
                this.Services = null;
            }
            static $h = 393225;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":327717,"g":{"r":0,"d":0,"h":25770197001,"f":50331650},"s":{"r":0,"d":0,"h":30065164297,"f":83886082},"n":"Services","d":393225,"h":21475229705,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"RenderField","d":393225,"h":42950066185,"f":16777218}],"l":[{"t":7012360,"n":"_handle","d":393225,"h":4295360521,"f":4194306},{"t":262145,"n":"_hasRendered","d":393225,"h":8590327817,"f":4194306},{"t":262153,"n":"_requestToken","d":393225,"h":12885295113,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":393225,"h":47245033481,"f":16777217}],"i":[2752520],"h":393225}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent ]; }
            static get $fullName() { return `AntiforgeryToken`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.InteractiveServerRenderMode", ($self) => class InteractiveServerRenderMode extends $.$$.System.Object
        {
            $ctor$1()
            {
                this.$ctor$2(true);
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ prerender)
            {
                super.$ctor();
                {
                    this.Prerender = prerender;
                }
                return this;
            }
            /*bool*/ Prerender = false;
            //default member initializer
            constructor()
            {
                super();
                this.Prerender = false;
            }
            static $h = 6225929;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21481062409,"f":50331649},"n":"Prerender","d":6225929,"h":17186095113,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":6225929,"h":4301193225,"f":16777217},{"p":[{"n":"prerender","p":262145}],"n":".ctor","o":"$ctor$2","d":6225929,"h":8596160521,"f":16777217}],"i":[2883592],"h":6225929}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponentRenderMode ]; }
            static get $fullName() { return `InteractiveServerRenderMode`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.BrowserFile", ($self) => class BrowserFile extends $.$$.System.Object
        {
            /*long*/ _size = 0n;
            /*InputFile*/ Owner = null;
            /*int*/ Id = 0;
            /*string*/ Name = null;
            /*DateTimeOffset*/ LastModified;
            /*long */ get Size()
            {
                return this._size;
            }
            /*long */ set Size(value)
            {
                if (value < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("Size", `Size must be a non-negative value. Value provided: ${value}.`);
                }
                this._size = value;
            }
            /*string*/ ContentType = null;
            /*string?*/ RelativePath = null;
            /*Stream */ OpenReadStream(/*long*/ maxAllowedSize, /*CancellationToken*/ cancellationToken)
            {
                if (this.Size > maxAllowedSize)
                {
                    throw new $.$$.System.IO.IOException().$ctor$13(`Supplied file with size ${this.Size} bytes exceeds the maximum of ${maxAllowedSize} bytes.`);
                }
                return this.Owner.OpenReadStream(this, maxAllowedSize, cancellationToken);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Forms.IBrowserFile.Name.get
            get Microsoft$AspNetCore$Components$Forms$IBrowserFile$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Forms.IBrowserFile.LastModified.get
            get Microsoft$AspNetCore$Components$Forms$IBrowserFile$LastModified()
            {
                return this.LastModified;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Forms.IBrowserFile.Size.get
            get Microsoft$AspNetCore$Components$Forms$IBrowserFile$Size()
            {
                return this.Size;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Forms.IBrowserFile.ContentType.get
            get Microsoft$AspNetCore$Components$Forms$IBrowserFile$ContentType()
            {
                return this.ContentType;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Forms.IBrowserFile.OpenReadStream(long, System.Threading.CancellationToken)
            Microsoft$AspNetCore$Components$Forms$IBrowserFile$OpenReadStream()
            {
                return this.OpenReadStream(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Owner = null;
                this.Name = $.$$.System.String.Empty;
                this.LastModified = $.$default($.$$.System.DateTimeOffset);
                this.ContentType = $.$$.System.String.Empty;
            }
            static $h = 524297;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1900553,"g":{"r":0,"d":0,"h":17180393481,"f":50331656},"s":{"r":0,"d":0,"h":21475360777,"f":83886088},"n":"Owner","d":524297,"h":12885426185,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":34360262665,"f":50331649},"s":{"r":0,"d":0,"h":38655229961,"f":83886081},"n":"Id","d":524297,"h":30065295369,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51540131849,"f":50331649},"s":{"r":0,"d":0,"h":55835099145,"f":83886081},"n":"Name","d":524297,"h":47245164553,"f":2097153},{"p":34471937,"g":{"r":0,"d":0,"h":68720001033,"f":50331649},"s":{"r":0,"d":0,"h":73014968329,"f":83886081},"n":"LastModified","d":524297,"h":64425033737,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":81604902921,"f":50331649},"s":{"r":0,"d":0,"h":85899870217,"f":83886081},"n":"Size","d":524297,"h":77309935625,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":98784772105,"f":50331649},"s":{"r":0,"d":0,"h":103079739401,"f":83886081},"n":"ContentType","d":524297,"h":94489804809,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":115964641289,"f":50331649},"s":{"r":0,"d":0,"h":120259608585,"f":83886081},"n":"RelativePath","d":524297,"h":111669673993,"f":2097153}],"m":[{"r":62193665,"p":[{"n":"maxAllowedSize","p":917505,"f":65,"v":512000},{"n":"cancellationToken","p":125829121,"f":65}],"n":"OpenReadStream","d":524297,"h":124554575881,"f":16777217}],"l":[{"t":917505,"n":"_size","d":524297,"h":4295491593,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":524297,"h":128849543177,"f":16777217}],"i":[1441801],"h":524297}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile ]; }
            static get $fullName() { return `BrowserFile`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.InteractiveWebAssemblyRenderMode", ($self) => class InteractiveWebAssemblyRenderMode extends $.$$.System.Object
        {
            $ctor$1()
            {
                this.$ctor$2(true);
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ prerender)
            {
                super.$ctor();
                {
                    this.Prerender = prerender;
                }
                return this;
            }
            /*bool*/ Prerender = false;
            //default member initializer
            constructor()
            {
                super();
                this.Prerender = false;
            }
            static $h = 6291465;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21481127945,"f":50331649},"n":"Prerender","d":6291465,"h":17186160649,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":6291465,"h":4301258761,"f":16777217},{"p":[{"n":"prerender","p":262145}],"n":".ctor","o":"$ctor$2","d":6291465,"h":8596226057,"f":16777217}],"i":[2883592],"h":6291465}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponentRenderMode ]; }
            static get $fullName() { return `InteractiveWebAssemblyRenderMode`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputFileJsCallbacksRelay", ($self) => class InputFileJsCallbacksRelay extends $.$$.System.Object
        {
            /*IInputFileJsCallbacks*/ _callbacks = null;
            /*IDisposable*/ DotNetReference = null;
            $ctor$1(/*IInputFileJsCallbacks*/ callbacks)
            {
                super.$ctor();
                {
                    this._callbacks = callbacks;
                    this.DotNetReference = $.$mj.Microsoft.JSInterop.DotNetObjectReference.Create($.$macw.Microsoft.AspNetCore.Components.Forms.InputFileJsCallbacksRelay, this);
                }
                return this;
            }
            /*Task */ NotifyChange(/*BrowserFile[]*/ files)
            {
                return this._callbacks.Microsoft$AspNetCore$Components$Forms$IInputFileJsCallbacks$NotifyChange(files);
            }
            /*void */ Dispose()
            {
                this.DotNetReference.System$IDisposable$Dispose();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 2097161;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":57540609,"g":{"r":0,"d":0,"h":17181966345,"f":50331649},"n":"DotNetReference","d":2097161,"h":12886999049,"f":2097153}],"m":[{"r":133169153,"p":[{"n":"files","p":$.$typeArray($.$macw.Microsoft.AspNetCore.Components.Forms.BrowserFile).$h}],"n":"NotifyChange","d":2097161,"h":25771900937,"f":16777217,"a":[{"t":2818078,"c":17182687262}]},{"r":65537,"n":"Dispose","d":2097161,"h":30066868233,"f":16777217}],"l":[{"t":1507337,"n":"_callbacks","d":2097161,"h":4297064457,"f":4194306}],"c":[{"p":[{"n":"callbacks","p":1507337}],"n":".ctor","o":"$ctor$1","d":2097161,"h":21476933641,"f":16777217}],"i":[57540609],"h":2097161}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputFileJsCallbacksRelay`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.InteractiveAutoRenderMode", ($self) => class InteractiveAutoRenderMode extends $.$$.System.Object
        {
            $ctor$1()
            {
                this.$ctor$2(true);
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ prerender)
            {
                super.$ctor();
                {
                    this.Prerender = prerender;
                }
                return this;
            }
            /*bool*/ Prerender = false;
            //default member initializer
            constructor()
            {
                super();
                this.Prerender = false;
            }
            static $h = 6160393;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21480996873,"f":50331649},"n":"Prerender","d":6160393,"h":17186029577,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":6160393,"h":4301127689,"f":16777217},{"p":[{"n":"prerender","p":262145}],"n":".ctor","o":"$ctor$2","d":6160393,"h":8596094985,"f":16777217}],"i":[2883592],"h":6160393}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponentRenderMode ]; }
            static get $fullName() { return `InteractiveAutoRenderMode`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.SupplyParameterFromFormValueProvider", ($self) => class SupplyParameterFromFormValueProvider extends $.$$.System.Object
        {
            /*IFormValueMapper?*/ _formValueMapper = null;
            /*FormMappingContext*/ _mappingContext = null;
            /*FormMappingContext */ get MappingContext()
            {
                return this._mappingContext;
            }
            $ctor$1(/*IFormValueMapper?*/ formValueMapper, /*string*/ mappingScopeName)
            {
                super.$ctor();
                {
                    this._formValueMapper = formValueMapper;
                    this._mappingContext = new $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext().$ctor$1(mappingScopeName);
                    this.MappingScopeName = mappingScopeName;
                }
                return this;
            }
            /*string*/ MappingScopeName = null;
            /*bool */ get Microsoft$AspNetCore$Components$ICascadingValueSupplier$IsFixed()
            {
                return true;
            }
            /*bool */ CanSupplyValue(/*in CascadingParameterInfo*/ parameterInfo)
            {
                if ($.$is(parameterInfo.$v.Attribute, $.$mac.Microsoft.AspNetCore.Components.CascadingParameterAttribute) && $.$$.System.Type.op_Equality$1(parameterInfo.$v.PropertyType, $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext.$type))
                {
                    return true;
                }
                let supplyParameterFromFormAttribute;
                if (!(this._formValueMapper === null) && $.$is(parameterInfo.$v.Attribute, $.$macw.Microsoft.AspNetCore.Components.SupplyParameterFromFormAttribute, { set $v(v){ supplyParameterFromFormAttribute = v; } }))
                {
                    return this._formValueMapper.Microsoft$AspNetCore$Components$Forms$Mapping$IFormValueMapper$CanMap(parameterInfo.$v.PropertyType, this.MappingScopeName, supplyParameterFromFormAttribute.FormName);
                }
                return false;
            }
            /*object? */ GetCurrentValue(/*object?*/ key, /*in CascadingParameterInfo*/ parameterInfo)
            {
                if ($.$is(parameterInfo.$v.Attribute, $.$mac.Microsoft.AspNetCore.Components.CascadingParameterAttribute) && $.$$.System.Type.op_Equality$1(parameterInfo.$v.PropertyType, $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext.$type))
                {
                    return this._mappingContext;
                }
                let valueMapper;
                if (this._formValueMapper !== null && ((valueMapper = this._formValueMapper, valueMapper != null && true)) && $.$is(parameterInfo.$v.Attribute, $.$macw.Microsoft.AspNetCore.Components.SupplyParameterFromFormAttribute))
                {
                    return $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.SupplyParameterFromFormValueProvider.GetFormPostValue(valueMapper, this._mappingContext, parameterInfo);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$12(`Received an unexpected attribute type ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(parameterInfo.$v.Attribute))}`);
            }
            /*void */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$Subscribe(/*ComponentState*/ subscriber, /*in CascadingParameterInfo*/ parameterInfo)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$Unsubscribe(/*ComponentState*/ subscriber, /*in CascadingParameterInfo*/ parameterInfo)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            static /*object? */ GetFormPostValue(/*IFormValueMapper*/ formValueMapper, /*FormMappingContext?*/ mappingContext, /*in CascadingParameterInfo*/ parameterInfo)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(mappingContext !== null, "mappingContext != null");
                /*var*/ let attribute = $.$cast(parameterInfo.$v.Attribute, $.$macw.Microsoft.AspNetCore.Components.SupplyParameterFromFormAttribute);
                /*var*/ let parameterName = attribute.Name ?? parameterInfo.$v.PropertyName;
                /*var*/ let restrictToFormName = attribute.FormName;
                /*Action<string, FormattableString, string?>*/ let errorHandler = $.$$.System.String.IsNullOrEmpty(restrictToFormName) ? new ($.$$.System.Action$$$$($.$$.System.String, $.$$.System.FormattableString, $.$$.System.String))().$ctor(mappingContext, mappingContext.AddError) : new ($.$$.System.Action$$$$($.$$.System.String, $.$$.System.FormattableString, $.$$.System.String))().$ctor(this,  (/**/ name, /*message*/ message, /*value*/ value) =>
                {
                    return mappingContext.AddError$1(restrictToFormName, parameterName, message, value);
                }, {"r":65537,"p":[{"n":"name","p":1310721},{"n":"message","p":47841281},{"n":"value","p":1310721}],"n":"","d":3145737,"h":0,"f":17825794});
                /*var*/ let context = (() =>
                {
                    //new $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormValueMappingContext()
                    const $t1 = $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormValueMappingContext;
                    const $i1 = new $t1();
                    $i1.$ctor$1(mappingContext.MappingScopeName, restrictToFormName, parameterInfo.$v.PropertyType, parameterName);
                    $i1.OnError = errorHandler;
                    $i1.MapErrorToContainer = new ($.$$.System.Action$$$($.$$.System.String, $.$$.System.Object))().$ctor(mappingContext, mappingContext.AttachParentValue);
                    return $i1;
                })();
                formValueMapper.Microsoft$AspNetCore$Components$Forms$Mapping$IFormValueMapper$Map(context);
                return context.Result;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.ICascadingValueSupplier.CanSupplyValue(in Microsoft.AspNetCore.Components.CascadingParameterInfo)
            Microsoft$AspNetCore$Components$ICascadingValueSupplier$CanSupplyValue()
            {
                return this.CanSupplyValue(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.ICascadingValueSupplier.GetCurrentValue(object?, in Microsoft.AspNetCore.Components.CascadingParameterInfo)
            Microsoft$AspNetCore$Components$ICascadingValueSupplier$GetCurrentValue()
            {
                return this.GetCurrentValue(...arguments);
            }
            static $h = 3145737;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1245193,"g":{"r":0,"d":0,"h":17183014921,"f":50331649},"n":"MappingContext","d":3145737,"h":12888047625,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34362884105,"f":50331649},"n":"MappingScopeName","d":3145737,"h":30067916809,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42952818697,"f":50331650},"n":"{2686984}.IsFixed","o":"Microsoft$AspNetCore$Components$ICascadingValueSupplier$IsFixed","d":3145737,"h":38657851401,"f":2097154}],"m":[{"r":262145,"p":[{"n":"parameterInfo","p":655368,"f":8}],"n":"CanSupplyValue","d":3145737,"h":47247785993,"f":16777217},{"r":131073,"p":[{"n":"key","p":131073},{"n":"parameterInfo","p":655368,"f":8}],"n":"GetCurrentValue","d":3145737,"h":51542753289,"f":16777217},{"r":131073,"p":[{"n":"formValueMapper","p":3014665},{"n":"mappingContext","p":1245193},{"n":"parameterInfo","p":655368,"f":8}],"n":"GetFormPostValue","d":3145737,"h":64427655177,"f":16777256}],"l":[{"t":3014665,"n":"_formValueMapper","d":3145737,"h":4298113033,"f":4194306},{"t":1245193,"n":"_mappingContext","d":3145737,"h":8593080329,"f":4194306}],"c":[{"p":[{"n":"formValueMapper","p":3014665},{"n":"mappingScopeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":3145737,"h":21477982217,"f":16777217}],"i":[2686984],"h":3145737}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.ICascadingValueSupplier ]; }
            static get $fullName() { return `SupplyParameterFromFormValueProvider`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.VirtualizeJsInterop", ($self) => class VirtualizeJsInterop extends $.$$.System.Object
        {
            /*string*/ static JsFunctionsPrefix = null;
            /*IVirtualizeJsCallbacks*/ _owner = null;
            /*IJSRuntime*/ _jsRuntime = null;
            /*DotNetObjectReference<VirtualizeJsInterop>?*/ _selfReference = null;
            $ctor$1(/*IVirtualizeJsCallbacks*/ owner, /*IJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    this._owner = owner;
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            /*ValueTask *//*async*/  InitializeAsync(/*ElementReference*/ spacerBefore, /*ElementReference*/ spacerAfter)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    this._selfReference = $.$mj.Microsoft.JSInterop.DotNetObjectReference.Create($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.VirtualizeJsInterop, this);
                    await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this._jsRuntime, `${"Blazor._internal.Virtualize"/*JsFunctionsPrefix*/}.init`, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._selfReference, spacerBefore, spacerAfter ], null, null));
                });
            }
            /*void */ OnSpacerBeforeVisible(/*float*/ spacerSize, /*float*/ spacerSeparation, /*float*/ containerSize)
            {
                this._owner.Microsoft$AspNetCore$Components$Web$Virtualization$IVirtualizeJsCallbacks$OnBeforeSpacerVisible(spacerSize, spacerSeparation, containerSize);
            }
            /*void */ OnSpacerAfterVisible(/*float*/ spacerSize, /*float*/ spacerSeparation, /*float*/ containerSize)
            {
                this._owner.Microsoft$AspNetCore$Components$Web$Virtualization$IVirtualizeJsCallbacks$OnAfterSpacerVisible(spacerSize, spacerSeparation, containerSize);
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    if (this._selfReference !== null)
                    {
                        try
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this._jsRuntime, `${"Blazor._internal.Virtualize"/*JsFunctionsPrefix*/}.dispose`, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._selfReference ], null, null));
                        }
                        catch($e)
                        {
                        }
                    }
                });
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.JsFunctionsPrefix = "Blazor._internal.Virtualize";
                }
            }
            static $h = 7864329;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":135987201,"p":[{"n":"spacerBefore","p":1900552},{"n":"spacerAfter","p":1900552}],"n":"InitializeAsync","d":7864329,"h":25777668105,"f":16781313},{"r":65537,"p":[{"n":"spacerSize","p":1114113},{"n":"spacerSeparation","p":1114113},{"n":"containerSize","p":1114113}],"n":"OnSpacerBeforeVisible","d":7864329,"h":30072635401,"f":16777217,"a":[{"t":2818078,"c":17182687262}]},{"r":65537,"p":[{"n":"spacerSize","p":1114113},{"n":"spacerSeparation","p":1114113},{"n":"containerSize","p":1114113}],"n":"OnSpacerAfterVisible","d":7864329,"h":34367602697,"f":16777217,"a":[{"t":2818078,"c":17182687262}]},{"r":135987201,"n":"DisposeAsync","d":7864329,"h":38662569993,"f":16781313}],"l":[{"t":1310721,"n":"JsFunctionsPrefix","d":7864329,"h":4302831625,"f":4194338},{"t":7667721,"n":"_owner","d":7864329,"h":8597798921,"f":4194306},{"t":524318,"n":"_jsRuntime","d":7864329,"h":12892766217,"f":4194306},{"t":$.$mj.Microsoft.JSInterop.DotNetObjectReference$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.VirtualizeJsInterop).$h,"n":"_selfReference","d":7864329,"h":17187733513,"f":4194306}],"c":[{"p":[{"n":"owner","p":7667721},{"n":"jsRuntime","p":524318}],"n":".ctor","o":"$ctor$1","d":7864329,"h":21482700809,"f":16777217}],"i":[56950785],"h":7864329}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `VirtualizeJsInterop`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.HtmlRenderer", ($self) => class HtmlRenderer extends $.$$.System.Object
        {
            /*StaticHtmlRenderer*/ _passiveHtmlRenderer = null;
            $ctor$1(/*IServiceProvider*/ services, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor();
                {
                    this._passiveHtmlRenderer = new $.$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer().$ctor$3(services, loggerFactory);
                }
                return this;
            }
            /*void */ Dispose()
            {
                return this._passiveHtmlRenderer.Dispose();
            }
            /*ValueTask */ DisposeAsync()
            {
                return this._passiveHtmlRenderer.DisposeAsync();
            }
            /*Dispatcher */ get Dispatcher()
            {
                return this._passiveHtmlRenderer.Dispatcher;
            }
            /*HtmlRootComponent */ BeginRenderingComponent$2(TComponent)
            {
                return this._passiveHtmlRenderer.BeginRenderingComponent(TComponent.$type, $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty);
            }
            /*HtmlRootComponent */ BeginRenderingComponent$3(TComponent, /*ParameterView*/ parameters)
            {
                return this._passiveHtmlRenderer.BeginRenderingComponent(TComponent.$type, parameters);
            }
            /*HtmlRootComponent */ BeginRenderingComponent$1(/*Type*/ componentType)
            {
                return this._passiveHtmlRenderer.BeginRenderingComponent(componentType, $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty);
            }
            /*HtmlRootComponent */ BeginRenderingComponent(/*Type*/ componentType, /*ParameterView*/ parameters)
            {
                return this._passiveHtmlRenderer.BeginRenderingComponent(componentType, parameters);
            }
            /*Task<HtmlRootComponent> */ RenderComponentAsync$2(TComponent)
            {
                return this.RenderComponentAsync$3(TComponent, $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty);
            }
            /*Task<HtmlRootComponent> */ RenderComponentAsync$1(/*Type*/ componentType)
            {
                return this.RenderComponentAsync(componentType, $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty);
            }
            /*Task<HtmlRootComponent> */ RenderComponentAsync$3(TComponent, /*ParameterView*/ parameters)
            {
                return this.RenderComponentAsync(TComponent.$type, parameters);
            }
            /*Task<HtmlRootComponent> *//*async*/  RenderComponentAsync(/*Type*/ componentType, /*ParameterView*/ parameters)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent), $.$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent, async () => 
                {
                    /*var*/ let content = this.BeginRenderingComponent(componentType, parameters);
                    await content.QuiescenceTask;
                    return content;
                });
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 5636105;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1703944,"g":{"r":0,"d":0,"h":25775439881,"f":50331649},"n":"Dispatcher","d":5636105,"h":21480472585,"f":2097153}],"m":[{"r":65537,"n":"Dispose","d":5636105,"h":12890537993,"f":16777217},{"r":135987201,"n":"DisposeAsync","d":5636105,"h":17185505289,"f":16777217},{"r":5701641,"g":["TComponent"],"n":"BeginRenderingComponent","o":"@$2","d":5636105,"h":30070407177,"f":16908289},{"r":5701641,"p":[{"n":"parameters","p":5767176}],"g":["TComponent"],"n":"BeginRenderingComponent","o":"@$3","d":5636105,"h":34365374473,"f":16908289},{"r":5701641,"p":[{"n":"componentType","p":142475265}],"n":"BeginRenderingComponent","o":"@$1","d":5636105,"h":38660341769,"f":16777217},{"r":5701641,"p":[{"n":"componentType","p":142475265},{"n":"parameters","p":5767176}],"n":"BeginRenderingComponent","d":5636105,"h":42955309065,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent).$h,"g":["TComponent"],"n":"RenderComponentAsync","o":"@$2","d":5636105,"h":47250276361,"f":16908289},{"r":$.$$.System.Threading.Tasks.Task$$($.$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent).$h,"p":[{"n":"componentType","p":142475265}],"n":"RenderComponentAsync","o":"@$1","d":5636105,"h":51545243657,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent).$h,"p":[{"n":"parameters","p":5767176}],"g":["TComponent"],"n":"RenderComponentAsync","o":"@$3","d":5636105,"h":55840210953,"f":16908289},{"r":$.$$.System.Threading.Tasks.Task$$($.$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent).$h,"p":[{"n":"componentType","p":142475265},{"n":"parameters","p":5767176}],"n":"RenderComponentAsync","d":5636105,"h":60135178249,"f":16781313}],"l":[{"t":3538953,"n":"_passiveHtmlRenderer","d":5636105,"h":4300603401,"f":4194306}],"c":[{"p":[{"n":"services","p":327717},{"n":"loggerFactory","p":1048597}],"n":".ctor","o":"$ctor$1","d":5636105,"h":8595570697,"f":16777217}],"i":[57540609,56950785],"h":5636105}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `HtmlRenderer`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.FormMappingScope", ($self) => class FormMappingScope extends $.$$.System.Object
        {
            /*SupplyParameterFromFormValueProvider?*/ _cascadingValueSupplier = null;
            /*RenderHandle*/ _handle;
            /*bool*/ _hasPendingQueuedRender = false;
            /*string*/ Name = null;
            /*RenderFragment<FormMappingContext>*/ ChildContent = null;
            /*IFormValueMapper?*/ FormValueModelBinder = null;
            /*void */ Microsoft$AspNetCore$Components$IComponent$Attach(/*RenderHandle*/ renderHandle)
            {
                this._handle = renderHandle;
            }
            /*Task */ Microsoft$AspNetCore$Components$IComponent$SetParametersAsync(/*ParameterView*/ parameters)
            {
                parameters.SetParameterProperties(this);
                if (this._cascadingValueSupplier === null)
                {
                    if ($.$$.System.String.IsNullOrEmpty(this.Name))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`The ${"FormMappingScope"} component requires a nonempty ${"Name"} parameter value.`);
                    }
                    else if ($.$$.System.String.StartsWith.call(this.Name, /*[*/ 91))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`The mapping scope name '${this.Name}' starts with a disallowed character.`);
                    }
                    this._cascadingValueSupplier = new $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.SupplyParameterFromFormValueProvider().$ctor$1(this.FormValueModelBinder, this.Name);
                }
                else if (!$.$$.System.String.Equals$3(this.Name, this._cascadingValueSupplier.MappingScopeName))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"FormMappingScope"} '${"Name"}' can't change after initialization.`);
                }
                if (!this._hasPendingQueuedRender)
                {
                    this._hasPendingQueuedRender = true;
                    this._handle.Render(new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.BuildRenderTree));
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                this._hasPendingQueuedRender = false;
                builder.AddContent$5($.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext, 0, this.ChildContent, this._cascadingValueSupplier.MappingContext);
            }
            /*bool */ get Microsoft$AspNetCore$Components$ICascadingValueSupplier$IsFixed()
            {
                return true;
            }
            /*bool */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$CanSupplyValue(/*in CascadingParameterInfo*/ parameterInfo)
            {
                return this._cascadingValueSupplier.CanSupplyValue(parameterInfo);
            }
            /*object? */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$GetCurrentValue(/*object?*/ key, /*in CascadingParameterInfo*/ parameterInfo)
            {
                return this._cascadingValueSupplier.GetCurrentValue(key, parameterInfo);
            }
            /*void */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$Subscribe(/*ComponentState*/ subscriber, /*in CascadingParameterInfo*/ parameterInfo)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Microsoft$AspNetCore$Components$ICascadingValueSupplier$Unsubscribe(/*ComponentState*/ subscriber, /*in CascadingParameterInfo*/ parameterInfo)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._handle = $.$default($.$mac.Microsoft.AspNetCore.Components.RenderHandle);
                this.Name = null;
                this.ChildContent = null;
            }
            static $h = 1310729;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25771114505,"f":50331649},"s":{"r":0,"d":0,"h":30066081801,"f":83886081},"n":"Name","d":1310729,"h":21476147209,"f":2097153,"a":[{"t":5636104,"c":21480472584},{"t":1835016,"c":4296802312}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext).$h,"g":{"r":0,"d":0,"h":42950983689,"f":50331649},"s":{"r":0,"d":0,"h":47245950985,"f":83886081},"n":"ChildContent","d":1310729,"h":38656016393,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":3014665,"g":{"r":0,"d":0,"h":60130852873,"f":50331656},"s":{"r":0,"d":0,"h":64425820169,"f":83886088},"n":"FormValueModelBinder","d":1310729,"h":55835885577,"f":2097160,"a":[{"t":4259848,"c":21479096328}]},{"p":262145,"g":{"r":0,"d":0,"h":85900656649,"f":50331650},"n":"{2686984}.IsFixed","o":"Microsoft$AspNetCore$Components$ICascadingValueSupplier$IsFixed","d":1310729,"h":81605689353,"f":2097154}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":1310729,"h":77310722057,"f":16777218}],"l":[{"t":3145737,"n":"_cascadingValueSupplier","d":1310729,"h":4296278025,"f":4194306},{"t":7012360,"n":"_handle","d":1310729,"h":8591245321,"f":4194306},{"t":262145,"n":"_hasPendingQueuedRender","d":1310729,"h":12886212617,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1310729,"h":107375493129,"f":16777217}],"i":[2686984,2752520],"h":1310729}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.ICascadingValueSupplier, $.$mac.Microsoft.AspNetCore.Components.IComponent ]; }
            static get $fullName() { return `FormMappingScope`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Routing.NavigationLock", ($self) => class NavigationLock extends $.$$.System.Object
        {
            /*string*/ _id = null;
            /*RenderHandle*/ _renderHandle;
            /*IDisposable?*/ _locationChangingRegistration = null;
            /*bool*/ _hasLocationChangingHandler = false;
            /*bool*/ _confirmExternalNavigation = false;
            /*bool */ get HasLocationChangingHandler()
            {
                return this.OnBeforeInternalNavigation.HasDelegate;
            }
            /*IJSRuntime*/ JSRuntime = null;
            /*NavigationManager*/ NavigationManager = null;
            /*EventCallback<LocationChangingContext>*/ OnBeforeInternalNavigation;
            /*bool*/ ConfirmExternalNavigation = false;
            /*void */ Microsoft$AspNetCore$Components$IComponent$Attach(/*RenderHandle*/ renderHandle)
            {
                this._renderHandle = renderHandle;
            }
            /*Task */ Microsoft$AspNetCore$Components$IComponent$SetParametersAsync(/*ParameterView*/ parameters)
            {
                var $en2 = parameters.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var parameter = $en2.Current;
                    {
                        if ($.$$.System.String.Equals$4.call(parameter.Name, "OnBeforeInternalNavigation", 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            this.OnBeforeInternalNavigation = $.$cast(parameter.Value, $.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$mac.Microsoft.AspNetCore.Components.Routing.LocationChangingContext));
                        }
                        else if ($.$$.System.String.Equals$4.call(parameter.Name, "ConfirmExternalNavigation", 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            this.ConfirmExternalNavigation = $.$cast(parameter.Value, $.$$.System.Boolean);
                        }
                        else 
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14(`The component '${"NavigationLock"}' does not accept a parameter with the name '${parameter.Name}'.`);
                        }
                    }
                }
                if (this._hasLocationChangingHandler !== this.HasLocationChangingHandler || this._confirmExternalNavigation !== this.ConfirmExternalNavigation)
                {
                    this._renderHandle.Render(new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor($.$macw.Microsoft.AspNetCore.Components.Routing.NavigationLock, /*static*/ (/*builder*/ builder) =>
                    {
                    }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":4194313,"h":0,"f":17825826}));
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            /*Task *//*async*/  Microsoft$AspNetCore$Components$IHandleAfterRender$OnAfterRenderAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (this._hasLocationChangingHandler !== this.HasLocationChangingHandler)
                    {
                        this._hasLocationChangingHandler = this.HasLocationChangingHandler;
                        this._locationChangingRegistration?.System$IDisposable$Dispose();
                        this._locationChangingRegistration = this._hasLocationChangingHandler ? this.NavigationManager.RegisterLocationChangingHandler(new ($.$$.System.Func$$$($.$mac.Microsoft.AspNetCore.Components.Routing.LocationChangingContext, $.$$.System.Threading.Tasks.ValueTask))().$ctor(this, this.OnLocationChanging)) : null;
                    }
                    if (this._confirmExternalNavigation !== this.ConfirmExternalNavigation)
                    {
                        this._confirmExternalNavigation = this.ConfirmExternalNavigation;
                        if (this._confirmExternalNavigation)
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JSRuntime, "Blazor._internal.NavigationLock.enableNavigationPrompt"/*NavigationLockInterop.EnableNavigationPrompt*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._id ], null, null));
                        }
                        else 
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JSRuntime, "Blazor._internal.NavigationLock.disableNavigationPrompt"/*NavigationLockInterop.DisableNavigationPrompt*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._id ], null, null));
                        }
                    }
                });
            }
            /*ValueTask *//*async*/  OnLocationChanging(/*LocationChangingContext*/ context)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    await this.OnBeforeInternalNavigation.InvokeAsync$1(context);
                });
            }
            /*ValueTask *//*async*/  System$IAsyncDisposable$DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    this._locationChangingRegistration?.System$IDisposable$Dispose();
                    if (this._confirmExternalNavigation)
                    {
                        try
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JSRuntime, "Blazor._internal.NavigationLock.disableNavigationPrompt"/*NavigationLockInterop.DisableNavigationPrompt*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._id ], null, null));
                        }
                        catch($e)
                        {
                        }
                    }
                });
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._id = $.$$.System.Guid.NewGuid().ToString$1("D", $.$$.System.Globalization.CultureInfo.InvariantCulture);
                this._renderHandle = $.$default($.$mac.Microsoft.AspNetCore.Components.RenderHandle);
                this.JSRuntime = null;
                this.NavigationManager = null;
                this.OnBeforeInternalNavigation = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$mac.Microsoft.AspNetCore.Components.Routing.LocationChangingContext));
                this.ConfirmExternalNavigation = false;
            }
            static $h = 4194313;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30068965385,"f":50331650},"n":"HasLocationChangingHandler","d":4194313,"h":25773998089,"f":2097154},{"p":524318,"g":{"r":0,"d":0,"h":42953867273,"f":50331650},"s":{"r":0,"d":0,"h":47248834569,"f":83886082},"n":"JSRuntime","d":4194313,"h":38658899977,"f":2097154,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":60133736457,"f":50331650},"s":{"r":0,"d":0,"h":64428703753,"f":83886082},"n":"NavigationManager","d":4194313,"h":55838769161,"f":2097154,"a":[{"t":4259848,"c":21479096328}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$mac.Microsoft.AspNetCore.Components.Routing.LocationChangingContext).$h,"g":{"r":0,"d":0,"h":77313605641,"f":50331649},"s":{"r":0,"d":0,"h":81608572937,"f":83886081},"n":"OnBeforeInternalNavigation","d":4194313,"h":73018638345,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":262145,"g":{"r":0,"d":0,"h":94493474825,"f":50331649},"s":{"r":0,"d":0,"h":98788442121,"f":83886081},"n":"ConfirmExternalNavigation","d":4194313,"h":90198507529,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":135987201,"p":[{"n":"context","p":10616840}],"n":"OnLocationChanging","d":4194313,"h":115968311305,"f":16781314}],"l":[{"t":1310721,"n":"_id","d":4194313,"h":4299161609,"f":4194306},{"t":7012360,"n":"_renderHandle","d":4194313,"h":8594128905,"f":4194306},{"t":57540609,"n":"_locationChangingRegistration","d":4194313,"h":12889096201,"f":4194306},{"t":262145,"n":"_hasLocationChangingHandler","d":4194313,"h":17184063497,"f":4194306},{"t":262145,"n":"_confirmExternalNavigation","d":4194313,"h":21479030793,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":4194313,"h":124558245897,"f":16777217}],"i":[2752520,3080200,56950785],"h":4194313}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `NavigationLock`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.DefaultAntiforgeryStateProvider", ($self) => class DefaultAntiforgeryStateProvider extends $.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider
        {
            /*AntiforgeryRequestToken?*/ _currentToken = null;
            /*AntiforgeryRequestToken? */ get CurrentToken()
            {
                return this._currentToken ??= this.GetAntiforgeryToken();
            }
            /*AntiforgeryRequestToken? */ set CurrentToken(value)
            {
                this._currentToken = value;
            }
            /*AntiforgeryRequestToken? */ GetAntiforgeryToken()
            {
                return this._currentToken;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 720905;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327689,"p":[{"p":262153,"g":{"r":0,"d":0,"h":12885622793,"f":50331649},"s":{"r":0,"d":0,"h":17180590089,"f":83886081},"n":"CurrentToken","d":720905,"h":8590655497,"f":2097153,"a":[{"t":6357000,"c":38661062664}]}],"m":[{"r":262153,"n":"GetAntiforgeryToken","d":720905,"h":21475557385,"f":16809985}],"l":[{"t":262153,"n":"_currentToken","d":720905,"h":4295688201,"f":4194308}],"c":[{"n":".ctor","o":"$ctor$2","d":720905,"h":25770524681,"f":16777217}],"h":720905}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider; }
            static get $fullName() { return `DefaultAntiforgeryStateProvider`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.WebElementReferenceContext", ($self) => class WebElementReferenceContext extends $.$mac.Microsoft.AspNetCore.Components.ElementReferenceContext
        {
            /*IJSRuntime*/ JSRuntime = null;
            $ctor$2(/*IJSRuntime*/ jsRuntime)
            {
                super.$ctor$1();
                {
                    this.JSRuntime = $.$firstOf(jsRuntime, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("jsRuntime") });
                }
                return this;
            }
            static $h = 8323081;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1966088,"p":[{"p":524318,"g":{"r":0,"d":0,"h":12893224969,"f":50331656},"n":"JSRuntime","d":8323081,"h":8598257673,"f":2097160}],"c":[{"p":[{"n":"jsRuntime","p":524318}],"n":".ctor","o":"$ctor$2","d":8323081,"h":17188192265,"f":16777217}],"h":8323081}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ElementReferenceContext; }
            static get $fullName() { return `WebElementReferenceContext`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.BindInputElementAttribute", ($self) => class BindInputElementAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string?*/ type, /*string?*/ suffix, /*string?*/ valueAttribute, /*string?*/ changeAttribute, /*bool*/ isInvariantCulture, /*string?*/ format)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(valueAttribute, "valueAttribute");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(changeAttribute, "changeAttribute");
                    this.Type = type;
                    this.Suffix = suffix;
                    this.ValueAttribute = valueAttribute;
                    this.ChangeAttribute = changeAttribute;
                    this.IsInvariantCulture = isInvariantCulture;
                    this.Format = format;
                }
                return this;
            }
            /*string?*/ Type = null;
            /*string?*/ Suffix = null;
            /*string?*/ ValueAttribute = null;
            /*string?*/ ChangeAttribute = null;
            /*bool*/ IsInvariantCulture = false;
            /*string?*/ Format = null;
            //default member initializer
            constructor()
            {
                super();
                this.IsInvariantCulture = false;
            }
            static $h = 65545;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17179934729,"f":50331649},"n":"Type","d":65545,"h":12884967433,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30064836617,"f":50331649},"n":"Suffix","d":65545,"h":25769869321,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42949738505,"f":50331649},"n":"ValueAttribute","d":65545,"h":38654771209,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55834640393,"f":50331649},"n":"ChangeAttribute","d":65545,"h":51539673097,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":68719542281,"f":50331649},"n":"IsInvariantCulture","d":65545,"h":64424574985,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":81604444169,"f":50331649},"n":"Format","d":65545,"h":77309476873,"f":2097153}],"c":[{"p":[{"n":"type","p":1310721},{"n":"suffix","p":1310721},{"n":"valueAttribute","p":1310721},{"n":"changeAttribute","p":1310721},{"n":"isInvariantCulture","p":262145},{"n":"format","p":1310721}],"n":".ctor","o":"$ctor$2","d":65545,"h":4295032841,"f":16777217}],"h":65545,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}],"n":[{"n":"AllowMultiple","v":true,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `BindInputElementAttribute`; }
        });
        
        $asm.$str("$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder", ($self) => class ReverseStringBuilder extends $.$$.System.ValueType
        {
            /*int*/ static MinimumRentedArraySize = 1024;
            /*ArrayPool<char>*/ static s_arrayPool = null;
            /*int*/  get _nextEndIndex() { return this.$getField(0, 4); }
            /*int*/  set _nextEndIndex(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _currentBuffer() { return this.$getField(4, 6); }
            /*Span<char>*/  set _currentBuffer(value) { this.$setField(4, 6, value); }
            /*SequenceSegment?*/  get _fallbackSequenceSegment() { return this.$getField(10, 4); }
            /*SequenceSegment?*/  set _fallbackSequenceSegment(value) { this.$setField(10, 4, value); }
            /*int */ get SequenceSegmentCount()
            {
                return (this._fallbackSequenceSegment?.Count() ?? null) ?? 0;
            }
            $ctor$3(/*int*/ conservativeEstimatedStringLength)
            {
                super.$ctor$1();
                {
                    /*var*/ let array = $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(conservativeEstimatedStringLength);
                    this._fallbackSequenceSegment = new $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(array, null);
                    this._currentBuffer = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(array);
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._currentBuffer = initialBuffer;
                    this._nextEndIndex = this._currentBuffer.Length;
                }
                return this;
            }
            /*bool */ get Empty()
            {
                return this._nextEndIndex === this._currentBuffer.Length;
            }
            /*void */ InsertFront$1(/*scoped ReadOnlySpan<char>*/ span)
            {
                /*var*/ let startIndex = ((this._nextEndIndex - span.Length) | 0);
                if (startIndex >= 0)
                {
                    let $t1 = this._currentBuffer;
                    span.CopyTo($t1.Slice(startIndex, $t1.Length - startIndex));
                    this._nextEndIndex = startIndex;
                    return;
                }
                if (this._fallbackSequenceSegment === null)
                {
                    /*var*/ let remainingLength = -startIndex;
                    /*var*/ let sizeToRent = ((this._currentBuffer.Length + $.$$.System.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0))) | 0);
                    /*var*/ let newBuffer = $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, null);
                    /*var*/ let newEndIndex = ((((newBuffer.length - this._currentBuffer.Length) | 0) + this._nextEndIndex) | 0);
                    let $t1 = this._currentBuffer;
                    $t1.Slice(this._nextEndIndex, $t1.Length - this._nextEndIndex).CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, newBuffer, newEndIndex));
                    newEndIndex -= span.Length;
                    span.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, newBuffer, newEndIndex));
                    this._currentBuffer = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(newBuffer);
                    this._nextEndIndex = newEndIndex;
                }
                else 
                {
                    /*var*/ let remainingLength = -startIndex;
                    let $t1 = span;
                    $t1.Slice(remainingLength, $t1.Length - remainingLength).CopyTo(this._currentBuffer);
                    let $t2 = span;
                    span = $t2.Slice(0, remainingLength);
                    /*var*/ let sizeToRent = $.$$.System.Math.Max$4(1024/*MinimumRentedArraySize*/, ((remainingLength * 2) | 0));
                    /*var*/ let newBuffer = $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Rent(sizeToRent);
                    this._fallbackSequenceSegment = new $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment().$ctor$2(newBuffer, this._fallbackSequenceSegment);
                    this._currentBuffer = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(newBuffer);
                    startIndex = ((this._currentBuffer.Length - remainingLength) | 0);
                    let $t3 = this._currentBuffer;
                    span.CopyTo($t3.Slice(startIndex, $t3.Length - startIndex));
                    this._nextEndIndex = startIndex;
                }
            }
            /*void */ InsertFront$2(T, /*T*/ value)
            {
                /*Span<char>*/ let result = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 11, null);
                /*var*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, result, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), $.$$.System.Globalization.CultureInfo.InvariantCulture))
                {
                    let $t2 = result;
                    this.InsertFront$1($.$$.System.Span$$($.$$.System.Char).op_Implicit($t2.Slice(0, charsWritten)));
                }
                else 
                {
                    this.InsertFront($.$box(value, T));
                }
            }
            /*void */ InsertFront(/*IFormattable*/ formattable)
            {
                return this.InsertFront$1($.$$.System.String.op_Implicit(formattable.System$IFormattable$ToString(null, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
            }
            static/*conventional*/ /*string */ ToString()
            {
                let $t1 = this._currentBuffer;
                return this._fallbackSequenceSegment === null ? $.$$.System.String.Create$2($.$$.System.Span$$($.$$.System.Char).op_Implicit($t1.Slice(this._nextEndIndex, $t1.Length - this._nextEndIndex))) : this._fallbackSequenceSegment.ToString$1(this._nextEndIndex);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.ToString.apply(this, arguments); }
            /*void */ Dispose()
            {
                this._fallbackSequenceSegment?.Dispose();
            }
            static $_SequenceSegment;
            static get SequenceSegment()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder;
                return $cls.$_SequenceSegment ??= $asm.$ncls("$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment", ($self) => class SequenceSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$$.System.Char)
                {
                    /*char[]*/ _array = null;
                    $ctor$2(/*char[]*/ array, /*SequenceSegment?*/ next)
                    {
                        super.$ctor$1();
                        {
                            this._array = array;
                            this.Memory = $.$$.System.ReadOnlyMemory$$($.$$.System.Char).op_Implicit$1(array);
                            this.Next = next;
                        }
                        return this;
                    }
                    /*int */ Count()
                    {
                        /*var*/ let count = 0;
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment))
                        {
                            count++;
                        }
                        return count;
                    }
                    /*string */ ToString$1(/*int*/ startIndex)
                    {
                        this.RunningIndex = 0n;
                        /*var*/ let tail = this;
                        let next;
                        while($.$is(tail.Next, $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment, { set $v(v){ next = v; } }))
                        {
                            next.RunningIndex = tail.RunningIndex + BigInt(tail.Memory.Length);
                            tail = next;
                        }
                        /*var*/ let sequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char))().$ctor$7(this, startIndex, tail, tail.Memory.Length);
                        return $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).ToString.call(sequence);
                    }
                    /*void */ Dispose()
                    {
                        for(/*var*/ let current = this; !(current === null); current = $.$as(current.Next, $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.SequenceSegment))
                        {
                            $.$macw.Microsoft.AspNetCore.Components.Forms.ReverseStringBuilder.s_arrayPool.Return(current._array, false);
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 3342345;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":655361,"n":"Count","d":3342345,"h":12888244233,"f":16777224},{"r":1310721,"p":[{"n":"startIndex","p":655361}],"n":"ToString","o":"@$1","d":3342345,"h":17183211529,"f":16777217},{"r":65537,"n":"Dispose","d":3342345,"h":21478178825,"f":16777217}],"l":[{"t":$.$typeArray($.$$.System.Char).$h,"n":"_array","d":3342345,"h":4298309641,"f":4194306}],"c":[{"p":[{"n":"array","p":$.$typeArray($.$$.System.Char).$h},{"n":"next","p":3342345,"f":65}],"n":".ctor","o":"$ctor$2","d":3342345,"h":8593276937,"f":16777217}],"i":[57540609],"d":3276809,"h":3342345}; }
                    static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$$.System.Char); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `ReverseStringBuilder.SequenceSegment`; }
                }, $cls, ($v) => $cls.$_SequenceSegment = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._nextEndIndex = this._nextEndIndex;
                copy._currentBuffer = this._currentBuffer.Clone();
                copy._fallbackSequenceSegment = this._fallbackSequenceSegment;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._nextEndIndex = 0;
                this._currentBuffer = $.$default($.$$.System.Span$$($.$$.System.Char));
                this._fallbackSequenceSegment = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_arrayPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared;
                }
            }
            static $h = 3276809;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30068047881,"f":50331656},"n":"SequenceSegmentCount","d":3276809,"h":25773080585,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":47247917065,"f":50331649},"n":"Empty","d":3276809,"h":42952949769,"f":2097153}],"m":[{"r":65537,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"InsertFront","o":"@$1","d":3276809,"h":51542884361,"f":16777217},{"r":65537,"p":[{"n":"value","p":(T) => T.$h}],"g":["T"],"n":"InsertFront","o":"@$2","d":3276809,"h":55837851657,"f":16908289},{"r":65537,"p":[{"n":"formattable","p":57737217}],"n":"InsertFront","d":3276809,"h":60132818953,"f":16777217},{"r":1310721,"n":"ToString","d":3276809,"h":64427786249,"f":16809985},{"r":65537,"n":"Dispose","d":3276809,"h":68722753545,"f":16777217}],"l":[{"t":655361,"n":"MinimumRentedArraySize","d":3276809,"h":4298244105,"f":4194337},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,"n":"s_arrayPool","d":3276809,"h":8593211401,"f":4194338},{"t":655361,"n":"_nextEndIndex","d":3276809,"h":12888178697,"f":4194306},{"t":$.$$.System.Span$$($.$$.System.Char).$h,"n":"_currentBuffer","d":3276809,"h":17183145993,"f":4194306},{"t":3342345,"n":"_fallbackSequenceSegment","d":3276809,"h":21478113289,"f":4194306}],"c":[{"p":[{"n":"conservativeEstimatedStringLength","p":655361}],"n":".ctor","o":"$ctor$3","d":3276809,"h":34363015177,"f":16777217},{"p":[{"n":"initialBuffer","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$4","d":3276809,"h":38657982473,"f":16777217},{"n":".ctor","o":"$ctor$2","d":3276809,"h":77312688137,"f":16777217}],"j":[3342345],"h":3276809}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ReverseStringBuilder`; }
        });
        
        $asm.$str("$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent", ($self) => class HtmlRootComponent extends $.$$.System.ValueType
        {
            /*StaticHtmlRenderer?*/  get _renderer() { return this.$getField(0, 4); }
            /*StaticHtmlRenderer?*/  set _renderer(value) { this.$setField(0, 4, value); }
            /*int*/  get _componentId() { return this.$getField(4, 4); }
            /*int*/  set _componentId(value) { this.$setField(4, 4, value); }
            $ctor$3(/*StaticHtmlRenderer*/ renderer, /*int*/ componentId, /*Task*/ quiescenceTask)
            {
                super.$ctor$1();
                {
                    this._renderer = renderer;
                    this._componentId = componentId;
                    this.QuiescenceTask = quiescenceTask;
                }
                return this;
            }
            /*Task*/ QuiescenceTask = null;
            /*string */ ToHtmlString()
            {
                if (this._renderer === null)
                {
                    return $.$$.System.String.Empty;
                }
                /*var*/ let writer = new $.$$.System.IO.StringWriter().$ctor$4();
                try
                {
                    this.WriteHtmlTo(writer);
                    return $.$$.System.IO.StringWriter.ToString.call(writer);
                }
                finally
                {
                    writer?.System$IDisposable$Dispose();
                }
            }
            /*void */ WriteHtmlTo(/*TextWriter*/ output)
            {
                return (this._renderer?.WriteComponentHtml(this._componentId, output) ?? null);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._renderer = this._renderer;
                copy._componentId = this._componentId;
                copy.QuiescenceTask = this.QuiescenceTask;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._renderer = null;
                this._componentId = 0;
            }
            static $h = 5701641;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":133169153,"g":{"r":0,"d":0,"h":25775505417,"f":50331649},"n":"QuiescenceTask","d":5701641,"h":21480538121,"f":2097153}],"m":[{"r":1310721,"n":"ToHtmlString","d":5701641,"h":30070472713,"f":16777217},{"r":65537,"p":[{"n":"output","p":63045633}],"n":"WriteHtmlTo","d":5701641,"h":34365440009,"f":16777217}],"l":[{"t":3538953,"n":"_renderer","d":5701641,"h":4300668937,"f":4194306},{"t":655361,"n":"_componentId","d":5701641,"h":8595636233,"f":4194306}],"c":[{"p":[{"n":"renderer","p":3538953},{"n":"componentId","p":655361},{"n":"quiescenceTask","p":133169153}],"n":".ctor","o":"$ctor$3","d":5701641,"h":12890603529,"f":16777224},{"n":".ctor","o":"$ctor$2","d":5701641,"h":38660407305,"f":16777217}],"h":5701641}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `HtmlRootComponent`; }
        });
        
        $asm.$str("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult<>", (TItem) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult<>", [TItem], ($self) => class ItemsProviderResult$$ extends $.$$.System.ValueType
        {
            /*IEnumerable<TItem>*/ Items = null;
            /*int*/ TotalItemCount = 0;
            $ctor$3(/*IEnumerable<TItem>*/ items, /*int*/ totalItemCount)
            {
                super.$ctor$1();
                {
                    this.Items = items;
                    this.TotalItemCount = totalItemCount;
                }
                return this;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Items = this.Items;
                copy.TotalItemCount = this.TotalItemCount;
                return copy;
            }
            static $h = 7602185;
            static $g = 1;
            static $z = 8;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"TotalItemCount","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153}],"c":[{"p":[{"n":"items","p":$.$$.System.Collections.Generic.IEnumerable$$(TItem).$h},{"n":"totalItemCount","p":655361}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217}],"g":[TItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ItemsProviderResult<${TItem?.$fullName}>`; }
        }));
        
        $asm.$str("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderRequest", ($self) => class ItemsProviderRequest extends $.$$.System.ValueType
        {
            /*int*/ StartIndex = 0;
            /*int*/ Count = 0;
            /*CancellationToken*/ CancellationToken;
            $ctor$3(/*int*/ startIndex, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$1();
                {
                    this.StartIndex = startIndex;
                    this.Count = count;
                    this.CancellationToken = cancellationToken;
                }
                return this;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.StartIndex = this.StartIndex;
                copy.Count = this.Count;
                copy.CancellationToken = this.CancellationToken.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.CancellationToken = $.$default($.$$.System.Threading.CancellationToken);
            }
            static $h = 7536649;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12892438537,"f":50331649},"n":"StartIndex","d":7536649,"h":8597471241,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25777340425,"f":50331649},"n":"Count","d":7536649,"h":21482373129,"f":2097153},{"p":125829121,"g":{"r":0,"d":0,"h":38662242313,"f":50331649},"n":"CancellationToken","d":7536649,"h":34367275017,"f":2097153}],"c":[{"p":[{"n":"startIndex","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":".ctor","o":"$ctor$3","d":7536649,"h":42957209609,"f":16777217},{"n":".ctor","o":"$ctor$2","d":7536649,"h":47252176905,"f":16777217}],"h":7536649}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ItemsProviderRequest`; }
        });
        
        $asm.$str("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext", ($self) => class PlaceholderContext extends $.$$.System.ValueType
        {
            /*int*/ Index = 0;
            /*float*/ Size = 0;
            $ctor$3(/*int*/ index, /*float*/ size)
            {
                super.$ctor$1();
                {
                    this.Index = index;
                    this.Size = size;
                }
                return this;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Index = this.Index;
                copy.Size = this.Size;
                return copy;
            }
            static $h = 7733257;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12892635145,"f":50331649},"n":"Index","d":7733257,"h":8597667849,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":25777537033,"f":50331649},"n":"Size","d":7733257,"h":21482569737,"f":2097153}],"c":[{"p":[{"n":"index","p":655361},{"n":"size","p":1114113,"f":65,"v":0}],"n":".ctor","o":"$ctor$3","d":7733257,"h":30072504329,"f":16777217},{"n":".ctor","o":"$ctor$2","d":7733257,"h":34367471625,"f":16777217}],"h":7733257}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `PlaceholderContext`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext", ($self) => class WebRendererSerializerContext extends $.$stj.System.Text.Json.Serialization.JsonSerializerContext
        {
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object[]>?*/ _ObjectArray = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object[]> */ get ObjectArray()
            {
                return this._ObjectArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$$.System.Object).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$$.System.Object)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object[]> */ Create_ObjectArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object[]>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$$.System.Object), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$$.System.Object)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$$.System.Object))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$$.System.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = null;
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateArrayInfo($.$$.System.Object, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_Name;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_Type;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>?*/ _String = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ get String()
            {
                return this._String ??= $.$cast(this.Options.GetTypeInfo($.$$.System.String.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ Create_String(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.String, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.String, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.StringConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::System.Collections.Generic.List<string>>>?*/ _DictionaryStringListString = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::System.Collections.Generic.List<string>>> */ get DictionaryStringListString()
            {
                return this._DictionaryStringListString ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String))));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::System.Collections.Generic.List<string>>> */ Create_DictionaryStringListString(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::System.Collections.Generic.List<string>>>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String))))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String))))().$ctor(this,  () =>
                        {
                            return new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor$1();
                        }, {"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)).$h,"n":"","d":3997705,"h":0,"f":17825794});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String))))().$ctor(this, this.DictionaryStringListStringSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateDictionaryInfo($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)), $.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String), options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*void */ DictionaryStringListStringSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::System.Collections.Generic.Dictionary<string, global::System.Collections.Generic.List<string>>?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                var $en2 = value.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        writer.WritePropertyName$11(entry.Key);
                        this.ListStringSerializeHandler(writer, entry.Value);
                    }
                }
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]>>?*/ _DictionaryStringJSComponentParameterArray = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]>> */ get DictionaryStringJSComponentParameterArray()
            {
                return this._DictionaryStringJSComponentParameterArray ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]>> */ Create_DictionaryStringJSComponentParameterArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]>>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))))().$ctor(this,  () =>
                        {
                            return new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)))().$ctor$1();
                        }, {"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)).$h,"n":"","d":3997705,"h":0,"f":17825794});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))))().$ctor(this, this.DictionaryStringJSComponentParameterArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateDictionaryInfo($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)), $.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter), options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*void */ DictionaryStringJSComponentParameterArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::System.Collections.Generic.Dictionary<string, global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]>?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                var $en2 = value.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        writer.WritePropertyName$11(entry.Key);
                        this.JSComponentParameterArraySerializeHandler(writer, entry.Value);
                    }
                }
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.JsonSerializerOptions*/ static s_defaultOptions = null;
            /*global::System.Reflection.BindingFlags*/ static InstanceMemberBindingFlags = 52;
            /*global::Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext*/ static Default = null;
            /*global::System.Text.Json.JsonSerializerOptions?*/ GeneratedSerializerOptions = null;
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                }
                return this;
            }
            $ctor$3(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                super.$ctor$1(options);
                {
                }
                return this;
            }
            static /*bool */ TryGetTypeInfoForRuntimeCustomConverter(TJsonMetadataType, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*out global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<TJsonMetadataType>*/ jsonTypeInfo)
            {
                /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.GetRuntimeConverterForType(TJsonMetadataType.$type, options);
                if (converter !== null)
                {
                    jsonTypeInfo.$v = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo(TJsonMetadataType, options, converter);
                    return true;
                }
                jsonTypeInfo.$v = null;
                return false;
            }
            static /*global::System.Text.Json.Serialization.JsonConverter? */ GetRuntimeConverterForType(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                for(/*int*/ let i = 0; i < options.Converters.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = options.Converters.System$Collections$Generic$IList$$$get_Item(i, [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                    if ((converter?.CanConvert(type) ?? null) === true)
                    {
                        return $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.ExpandConverter(type, converter, options, false);
                    }
                }
                return null;
            }
            static /*global::System.Text.Json.Serialization.JsonConverter */ ExpandConverter(/*global::System.Type*/ type, /*global::System.Text.Json.Serialization.JsonConverter*/ converter, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*bool*/ validateCanConvert)
            {
                if (validateCanConvert && !converter.CanConvert(type))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$$.System.String.Format$8("The converter '{0}' is not compatible with the type '{1}'.", $.$$.System.Object.GetType.call(converter), type));
                }
                let factory;
                if ($.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory, { set $v(v){ factory = v; } }))
                {
                    converter = factory.CreateConverter(type, options);
                    if (converter === null || $.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$$.System.String.Format$9("The converter '{0}' cannot return null or a JsonConverterFactory instance.", $.$$.System.Object.GetType.call(factory)));
                    }
                }
                return converter;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ GetTypeInfo(/*global::System.Type*/ type)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo?*/ let typeInfo;
                this.Options.TryGetTypeInfo(type, $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo));
                return typeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ System$Text$Json$Serialization$Metadata$IJsonTypeInfoResolver$GetTypeInfo(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                if ($.$$.System.Type.op_Equality$1(type, $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.$type))
                {
                    return this.Create_JSComponentParameter(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter).$type))
                {
                    return this.Create_JSComponentParameterArray(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)).$type))
                {
                    return this.Create_DictionaryStringJSComponentParameterArray(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)).$type))
                {
                    return this.Create_DictionaryStringListString(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Collections.Generic.List$$($.$$.System.String).$type))
                {
                    return this.Create_ListString(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int32.$type))
                {
                    return this.Create_Int32(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Object.$type))
                {
                    return this.Create_Object(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Object).$type))
                {
                    return this.Create_ObjectArray(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.String.$type))
                {
                    return this.Create_String(options);
                }
                return null;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>?*/ _Int32 = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ get Int32()
            {
                return this._Int32 ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Int32.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int32));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ Create_Int32(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Int32, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int32))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.Int32, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.Int32Converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter>?*/ _JSComponentParameter = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter> */ get JSComponentParameter()
            {
                return this._JSComponentParameter ??= $.$cast(this.Options.GetTypeInfo($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter> */ Create_JSComponentParameter(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))().$ctor(this,  () =>
                        {
                            return new $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter().$ctor$2();
                        }, {"r":6553609,"n":"","d":3997705,"h":0,"f":17825794});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.JSComponentParameterPropInit(options);
                        }, {"r":$.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,"p":[{"n":"_","p":14791619}],"n":"","d":3997705,"h":0,"f":17825794});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext, /*static*/ () =>
                        {
                            return $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {"r":76939265,"n":"","d":3997705,"h":0,"f":17825826});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))().$ctor(this, this.JSComponentParameterSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ JSComponentParameterPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)).Name;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":3997705,"h":0,"f":17825826});
                    $i1.Setter = null;
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Name";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext, /*static*/ () =>
                    {
                        return $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.$type.GetProperty("Name", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {"r":76939265,"n":"","d":3997705,"h":0,"f":17825826});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info0), 0);
                $.$$.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)).Type;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":3997705,"h":0,"f":17825826});
                    $i2.Setter = null;
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "Type";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext, /*static*/ () =>
                    {
                        return $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter.$type.GetProperty("Type", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {"r":76939265,"n":"","d":3997705,"h":0,"f":17825826});
                    return $i2;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info1), 1);
                $.$$.System.Array.$ReadT1.call(properties, 1).IsGetNullable = false;
                return properties;
            }
            /*void */ JSComponentParameterSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter*/ value)
            {
                writer.WriteStartObject();
                writer.WriteString$26($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.PropName_Name, (value).Name);
                writer.WriteString$26($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.PropName_Type, (value).Type);
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]>?*/ _JSComponentParameterArray = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]> */ get JSComponentParameterArray()
            {
                return this._JSComponentParameterArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]> */ Create_JSComponentParameterArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter)))().$ctor(this, this.JSComponentParameterArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateArrayInfo($.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*void */ JSComponentParameterArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore.JSComponentParameter[]?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    this.JSComponentParameterSerializeHandler(writer, $.$$.System.Array.$ReadT1.call(value, i));
                }
                writer.WriteEndArray();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.List<string>>?*/ _ListString = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.List<string>> */ get ListString()
            {
                return this._ListString ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Collections.Generic.List$$($.$$.System.String).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.List$$($.$$.System.String)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.List<string>> */ Create_ListString(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.List<string>>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Collections.Generic.List$$($.$$.System.String), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.List$$($.$$.System.String)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.List$$($.$$.System.String))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.List$$($.$$.System.String));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor(this,  () =>
                        {
                            return new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                        }, {"r":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"n":"","d":3997705,"h":0,"f":17825794});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor(this, this.ListStringSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateListInfo($.$$.System.Collections.Generic.List$$($.$$.System.String), $.$$.System.String, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*void */ ListStringSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::System.Collections.Generic.List<string>?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.Count; i++)
                {
                    writer.WriteStringValue$5(value.get_Item(i));
                }
                writer.WriteEndArray();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>?*/ _Object = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ get Object()
            {
                return this._Object ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Object.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Object));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ Create_Object(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>*/ let jsonTypeInfo;
                if (!$.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Object, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Object))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.Object, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.ObjectConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //default member initializer
            constructor()
            {
                super();
                this.GeneratedSerializerOptions = $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.s_defaultOptions;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PropName_Name = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("Name", null);
                }
                {
                    this.PropName_Type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("Type", null);
                }
                {
                    this.s_defaultOptions = new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$1();
                }
                {
                    this.Default = new $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext().$ctor$3(new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$3($.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext.s_defaultOptions));
                }
            }
            static $h = 3997705;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14791619,"h":3997705}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonSerializerContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.System.Text.Json.Serialization.Metadata.IBuiltInJsonTypeInfoResolver, $.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver ]; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.RenderTree.WebRendererSerializerContext`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer", ($self) => class StaticHtmlRenderer extends $.$mac.Microsoft.AspNetCore.Components.RenderTree.Renderer
        {
            /*RendererInfo*/ static _componentPlatform = null;
            /*NavigationManager?*/ _navigationManager = null;
            $ctor$3(/*IServiceProvider*/ serviceProvider, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor$2(serviceProvider, loggerFactory);
                {
                    this._navigationManager = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$mac.Microsoft.AspNetCore.Components.NavigationManager, serviceProvider);
                    this._htmlEncoder = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$stew.System.Text.Encodings.Web.HtmlEncoder, serviceProvider) ?? $.$stew.System.Text.Encodings.Web.HtmlEncoder.Default;
                    this._javaScriptEncoder = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$stew.System.Text.Encodings.Web.JavaScriptEncoder, serviceProvider) ?? $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.Default;
                }
                return this;
            }
            /*Dispatcher*/ Dispatcher = null;
            /*RendererInfo */ get RendererInfo()
            {
                return $.$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer._componentPlatform;
            }
            /*HtmlRootComponent */ BeginRenderingComponent(/*Type*/ componentType, /*ParameterView*/ initialParameters)
            {
                /*var*/ let component = this.InstantiateComponent(componentType);
                return this.BeginRenderingComponent$1(component, initialParameters);
            }
            /*HtmlRootComponent */ BeginRenderingComponent$1(/*IComponent*/ component, /*ParameterView*/ initialParameters)
            {
                /*var*/ let componentId = this.AssignRootComponentId(component);
                /*var*/ let quiescenceTask = this.RenderRootComponentAsync(componentId, initialParameters);
                if (quiescenceTask.IsFaulted)
                {
                    $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(quiescenceTask.Exception.InnerException ?? quiescenceTask.Exception).Throw();
                }
                return new $.$macw.Microsoft.AspNetCore.Components.Web.HtmlRendering.HtmlRootComponent().$ctor$3(this, componentId, quiescenceTask);
            }
            /*void */ HandleException(/*Exception*/ exception)
            {
                return $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception).Throw();
            }
            /*Task */ UpdateDisplayAsync(/*in RenderBatch*/ renderBatch)
            {
                return $.$mac.Microsoft.AspNetCore.Components.RenderTree.Renderer.CanceledRenderTask;
            }
            /*ArrayRange<RenderTreeFrame> */ GetCurrentRenderTreeFrames$1(/*int*/ componentId)
            {
                return super.GetCurrentRenderTreeFrames(componentId);
            }
            /*HashSet<string>*/ static SelfClosingElements = null;
            /*CascadingParameterInfo*/ static _findFormMappingContext;
            /*TextEncoder*/ _javaScriptEncoder = null;
            /*TextEncoder*/ _htmlEncoder = null;
            /*string?*/ _closestSelectValueAsString = null;
            /*void */ WriteComponentHtml(/*int*/ componentId, /*TextWriter*/ output)
            {
                this.Dispatcher.AssertAccess();
                /*var*/ let frames = this.GetCurrentRenderTreeFrames$1(componentId);
                this.RenderFrames(componentId, output, frames, 0, frames.Count);
            }
            /*void */ RenderChildComponent$1(/*TextWriter*/ output, /*ref RenderTreeFrame*/ componentFrame)
            {
                this.WriteComponentHtml(componentFrame.$v.ComponentId, output);
            }
            /*int */ RenderFrames(/*int*/ componentId, /*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ position, /*int*/ maxElements)
            {
                /*var*/ let nextPosition = position;
                /*var*/ let endPosition = ((position + maxElements) | 0);
                while(position < endPosition)
                {
                    nextPosition = this.RenderCore(componentId, output, frames, position);
                    if (position === nextPosition)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12("We didn't consume any input.");
                    }
                    position = nextPosition;
                }
                return nextPosition;
            }
            /*int */ RenderCore(/*int*/ componentId, /*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ position)
            {
                /*ref var*/ let frame = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame, frames.Array, position, false, true);
                let $switch1 = frame.$v.FrameType;
                switch($switch1)
                {
                    case 1/*RenderTreeFrameType.Element*/:
                    return this.RenderElement(componentId, output, frames, position);
                    case 3/*RenderTreeFrameType.Attribute*/:
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Attributes should only be encountered within ${"RenderElement"}`);
                    case 2/*RenderTreeFrameType.Text*/:
                    this._htmlEncoder.Encode$2(output, frame.$v.TextContent);
                    return ++position;
                    case 8/*RenderTreeFrameType.Markup*/:
                    output.Write$16(frame.$v.MarkupContent);
                    return ++position;
                    case 4/*RenderTreeFrameType.Component*/:
                    return this.RenderChildComponent(output, frames, position);
                    case 5/*RenderTreeFrameType.Region*/:
                    return this.RenderFrames(componentId, output, frames, ((position + 1) | 0), ((frame.$v.RegionSubtreeLength - 1) | 0));
                    case 6/*RenderTreeFrameType.ElementReferenceCapture*/:
                    case 7/*RenderTreeFrameType.ComponentReferenceCapture*/:
                    return ++position;
                    case 10/*RenderTreeFrameType.NamedEvent*/:
                    this.RenderHiddenFieldForNamedSubmitEvent(componentId, output, frames, position);
                    return ++position;
                    default:
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Invalid element frame type '${frame.$v.FrameType}'.`);
                }
            }
            /*int */ RenderElement(/*int*/ componentId, /*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ position)
            {
                /*ref var*/ let frame = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame, frames.Array, position, false, true);
                output.Write$1(/*<*/ 60);
                output.Write$16(frame.$v.ElementName);
                /*int*/ let afterElement;
                /*var*/ let isTextArea = $.$$.System.String.Equals$2(frame.$v.ElementName, "textarea", 5/*StringComparison.OrdinalIgnoreCase*/);
                /*var*/ let isForm = $.$$.System.String.Equals$2(frame.$v.ElementName, "form", 5/*StringComparison.OrdinalIgnoreCase*/);
                /*var*/ let capturedValueAttribute;
                /*var*/ let afterAttributes = this.RenderAttributes(output, frames, ((position + 1) | 0), ((frame.$v.ElementSubtreeLength - 1) | 0), !isTextArea, isForm, $.$ref(() => capturedValueAttribute, ($v) => capturedValueAttribute = $v, $.$$.System.String));
                if ($.$$.System.String.op_Inequality(this._closestSelectValueAsString, null) && $.$$.System.String.Equals$2(frame.$v.ElementName, "option", 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.System.String.Equals$2(capturedValueAttribute, this._closestSelectValueAsString, 4/*StringComparison.Ordinal*/))
                {
                    output.Write$16(" selected");
                }
                /*var*/ let remainingElements = ((((frame.$v.ElementSubtreeLength + position) | 0) - afterAttributes) | 0);
                if (remainingElements > 0 || isTextArea)
                {
                    output.Write$1(/*>*/ 62);
                    /*var*/ let isSelect = $.$$.System.String.Equals$2(frame.$v.ElementName, "select", 5/*StringComparison.OrdinalIgnoreCase*/);
                    if (isSelect)
                    {
                        this._closestSelectValueAsString = capturedValueAttribute;
                    }
                    if (isTextArea && !$.$$.System.String.IsNullOrEmpty(capturedValueAttribute))
                    {
                        this._htmlEncoder.Encode$2(output, capturedValueAttribute);
                        afterElement = ((position + frame.$v.ElementSubtreeLength) | 0);
                    }
                    else if ($.$$.System.String.Equals$2(frame.$v.ElementNameField, "script", 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        afterElement = this.RenderScriptElementChildren(componentId, output, frames, afterAttributes, remainingElements);
                    }
                    else 
                    {
                        afterElement = this.RenderChildren(componentId, output, frames, afterAttributes, remainingElements);
                    }
                    if (isSelect)
                    {
                        this._closestSelectValueAsString = null;
                    }
                    output.Write$16("</");
                    output.Write$16(frame.$v.ElementName);
                    output.Write$1(/*>*/ 62);
                    $.$$.System.Diagnostics.Debug.Assert$2(afterElement === ((position + frame.$v.ElementSubtreeLength) | 0), "afterElement == position + frame.ElementSubtreeLength");
                    return afterElement;
                }
                else 
                {
                    if ($.$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer.SelfClosingElements.Contains(frame.$v.ElementName))
                    {
                        output.Write$16(" />");
                    }
                    else 
                    {
                        output.Write$16("></");
                        output.Write$16(frame.$v.ElementName);
                        output.Write$1(/*>*/ 62);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(afterAttributes === ((position + frame.$v.ElementSubtreeLength) | 0), "afterAttributes == position + frame.ElementSubtreeLength");
                    return afterAttributes;
                }
            }
            /*int */ RenderScriptElementChildren(/*int*/ componentId, /*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ position, /*int*/ maxElements)
            {
                /*var*/ let originalEncoder = this._htmlEncoder;
                try
                {
                    this._htmlEncoder = this._javaScriptEncoder;
                    return this.RenderChildren(componentId, output, frames, position, maxElements);
                }
                finally
                {
                    {
                        this._htmlEncoder = originalEncoder;
                    }
                }
            }
            /*void */ RenderHiddenFieldForNamedSubmitEvent(/*int*/ componentId, /*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ namedEventFramePosition)
            {
                /*ref var*/ let namedEventFrame = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame, frames.Array, namedEventFramePosition, false, true);
                /*var*/ let enclosingElementFrameIndex;
                if ($.$$.System.String.Equals$2(namedEventFrame.$v.NamedEventType, "onsubmit", 4/*StringComparison.Ordinal*/) && $.$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer.TryFindEnclosingElementFrame(frames, namedEventFramePosition, $.$ref(() => enclosingElementFrameIndex, ($v) => enclosingElementFrameIndex = $v, $.$$.System.Int32)))
                {
                    /*ref var*/ let enclosingElementFrame = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame, frames.Array, enclosingElementFrameIndex, false, true);
                    if ($.$$.System.String.Equals$2(enclosingElementFrame.$v.ElementName, "form", 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        /*var*/ let combinedFormName;
                        if (this.TryCreateScopeQualifiedEventName(componentId, namedEventFrame.$v.NamedEventAssignedName, $.$ref(() => combinedFormName, ($v) => combinedFormName = $v, $.$$.System.String)))
                        {
                            output.Write$16("<input type=\"hidden\" name=\"_handler\" value=\"");
                            this._htmlEncoder.Encode$2(output, combinedFormName);
                            output.Write$16("\" />");
                        }
                    }
                }
            }
            /*bool */ TryCreateScopeQualifiedEventName(/*int*/ componentId, /*string*/ assignedEventName, /*out string?*/ scopeQualifiedEventName)
            {
                let mappingContext;
                if (this.FindFormMappingContext(componentId) !== null && ((mappingContext = this.FindFormMappingContext(componentId), mappingContext != null && true)))
                {
                    /*var*/ let mappingScopeName = mappingContext.MappingScopeName;
                    scopeQualifiedEventName.$v = $.$$.System.String.IsNullOrEmpty(mappingScopeName) ? assignedEventName : `[${mappingScopeName}]${assignedEventName}`;
                    return true;
                }
                else 
                {
                    scopeQualifiedEventName.$v = null;
                    return false;
                }
            }
            /*FormMappingContext? */ FindFormMappingContext(/*int*/ forComponentId)
            {
                /*var*/ let componentState = this.GetComponentState(forComponentId);
                /*var*/ let supplier = $.$mac.Microsoft.AspNetCore.Components.CascadingParameterState.GetMatchingCascadingValueSupplier($.$ref(() => $.$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer._findFormMappingContext, undefined, $.$mac.Microsoft.AspNetCore.Components.CascadingParameterInfo), componentState.Renderer, componentState);
                return $.$cast((supplier?.Microsoft$AspNetCore$Components$ICascadingValueSupplier$GetCurrentValue(null, $.$ref(() => $.$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer._findFormMappingContext, )) ?? null), $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext);
            }
            static /*bool */ TryFindEnclosingElementFrame(/*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ frameIndex, /*out int*/ result)
            {
                while(--frameIndex >= 0)
                {
                    if ($.$$.System.Array.$ReadT1.call(frames.Array, frameIndex).FrameType === 1/*RenderTreeFrameType.Element*/)
                    {
                        result.$v = frameIndex;
                        return true;
                    }
                }
                result.$v = 0;
                return false;
            }
            /*int */ RenderAttributes(/*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ position, /*int*/ maxElements, /*bool*/ includeValueAttribute, /*bool*/ isForm, /*out string?*/ capturedValueAttribute)
            {
                capturedValueAttribute.$v = null;
                if (maxElements === 0)
                {
                    EmitFormActionIfNotExplicit.call(this, output, isForm, false);
                    return position;
                }
                /*var*/ let hasExplicitActionValue = false;
                for(/*var*/ let i = 0; i < maxElements; i++)
                {
                    /*var*/ let candidateIndex = ((position + i) | 0);
                    /*ref var*/ let frame = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame, frames.Array, candidateIndex, false, true);
                    if (frame.$v.FrameType !== 3/*RenderTreeFrameType.Attribute*/)
                    {
                        if (frame.$v.FrameType === 6/*RenderTreeFrameType.ElementReferenceCapture*/)
                        {
                            continue;
                        }
                        EmitFormActionIfNotExplicit.call(this, output, isForm, hasExplicitActionValue);
                        return candidateIndex;
                    }
                    if ($.$$.System.String.Equals$4.call(frame.$v.AttributeName, "value", 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        capturedValueAttribute.$v = $.$as(frame.$v.AttributeValue, $.$$.System.String);
                        if (!includeValueAttribute)
                        {
                            continue;
                        }
                    }
                    if (isForm && $.$$.System.String.Equals$4.call(frame.$v.AttributeName, "action", 5/*StringComparison.OrdinalIgnoreCase*/) && !$.$$.System.String.IsNullOrEmpty($.$as(frame.$v.AttributeValue, $.$$.System.String)))
                    {
                        hasExplicitActionValue = true;
                    }
                    //switch (frame.AttributeValue)
                    let $switch1 = frame.$v.AttributeValue;
                    {
                        let flag;
                        let value;
                        $switchJumpStart1: 
                        //case bool flag when flag:
                        if ($.$is($switch1, $.$$.System.Boolean, { set $v(v){ flag = v; } }) && flag)
                        {
                            output.Write$1(/* */ 32);
                            output.Write$16(frame.$v.AttributeName);
                        }
                        //case string value:
                        else if ($.$is($switch1, $.$$.System.String, { set $v(v){ value = v; } }))
                        {
                            output.Write$1(/* */ 32);
                            output.Write$16(frame.$v.AttributeName);
                            output.Write$1(/*=*/ 61);
                            output.Write$1(/*\"*/ 34);
                            this._htmlEncoder.Encode$2(output, value);
                            output.Write$1(/*\"*/ 34);
                        }
                        //default
                        else
                        {
                        }
                    }
                }
                EmitFormActionIfNotExplicit.call(this, output, isForm, hasExplicitActionValue);
                return ((position + maxElements) | 0);
                /*void*/  function EmitFormActionIfNotExplicit(/*TextWriter*/ output, /*bool*/ isForm, /*bool*/ hasExplicitActionValue)
                {
                    if (isForm && this._navigationManager !== null && !hasExplicitActionValue)
                    {
                        output.Write$1(/* */ 32);
                        output.Write$16("action");
                        output.Write$1(/*=*/ 61);
                        output.Write$1(/*\"*/ 34);
                        this._htmlEncoder.Encode$2(output, $.$macw.Microsoft.AspNetCore.Components.HtmlRendering.Infrastructure.StaticHtmlRenderer.GetRootRelativeUrlForFormAction(this._navigationManager));
                        output.Write$1(/*\"*/ 34);
                    }
                }
            }
            static /*string */ GetRootRelativeUrlForFormAction(/*NavigationManager*/ navigationManager)
            {
                return new $.$spu.System.Uri().$ctor$3(navigationManager.Uri, 1/*UriKind.Absolute*/).PathAndQuery;
            }
            /*int */ RenderChildren(/*int*/ componentId, /*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ position, /*int*/ maxElements)
            {
                if (maxElements === 0)
                {
                    return position;
                }
                return this.RenderFrames(componentId, output, frames, position, maxElements);
            }
            /*int */ RenderChildComponent(/*TextWriter*/ output, /*ArrayRange<RenderTreeFrame>*/ frames, /*int*/ position)
            {
                /*ref var*/ let frame = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame, frames.Array, position, false, true);
                this.RenderChildComponent$1(output, frame);
                return ((position + frame.$v.ComponentSubtreeLength) | 0);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Dispatcher = $.$mac.Microsoft.AspNetCore.Components.Dispatcher.CreateDefault();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._componentPlatform = new $.$mac.Microsoft.AspNetCore.Components.RendererInfo().$ctor$1("Static", false);
                }
                {
                    this.SelfClosingElements = (() =>
                    {
                        //new $.$$.System.Collections.Generic.HashSet$$($.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.HashSet$$($.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                        $i1.Add("area");
                        $i1.Add("base");
                        $i1.Add("br");
                        $i1.Add("col");
                        $i1.Add("embed");
                        $i1.Add("hr");
                        $i1.Add("img");
                        $i1.Add("input");
                        $i1.Add("link");
                        $i1.Add("meta");
                        $i1.Add("param");
                        $i1.Add("source");
                        $i1.Add("track");
                        $i1.Add("wbr");
                        return $i1;
                    })();
                }
                {
                    this._findFormMappingContext = new $.$mac.Microsoft.AspNetCore.Components.CascadingParameterInfo().$ctor$3(new $.$mac.Microsoft.AspNetCore.Components.CascadingParameterAttribute().$ctor$3(), $.$$.System.String.Empty, $.$macw.Microsoft.AspNetCore.Components.Forms.FormMappingContext.$type);
                }
            }
            static $h = 3538953;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8454152,"p":[{"p":1703944,"g":{"r":0,"d":0,"h":25773342729,"f":50364417},"n":"Dispatcher","d":3538953,"h":21478375433,"f":2129921},{"p":6815752,"g":{"r":0,"d":0,"h":34363277321,"f":50364432},"n":"RendererInfo","d":3538953,"h":30068310025,"f":2129936}],"m":[{"r":5701641,"p":[{"n":"componentType","p":142475265},{"n":"initialParameters","p":5767176}],"n":"BeginRenderingComponent","d":3538953,"h":38658244617,"f":16777217},{"r":5701641,"p":[{"n":"component","p":2752520},{"n":"initialParameters","p":5767176}],"n":"BeginRenderingComponent","o":"@$1","d":3538953,"h":42953211913,"f":16777217},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"HandleException","d":3538953,"h":47248179209,"f":16809988},{"r":133169153,"p":[{"n":"renderBatch","p":8388616,"f":8}],"n":"UpdateDisplayAsync","d":3538953,"h":51543146505,"f":16809988},{"r":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h,"p":[{"n":"componentId","p":655361}],"n":"GetCurrentRenderTreeFrames","o":"@$1","d":3538953,"h":55838113801,"f":16777224},{"r":65537,"p":[{"n":"componentId","p":655361},{"n":"output","p":63045633}],"n":"WriteComponentHtml","d":3538953,"h":81607917577,"f":16777360},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"componentFrame","p":9109512,"f":4}],"n":"RenderChildComponent","o":"@$1","d":3538953,"h":85902884873,"f":16777348},{"r":655361,"p":[{"n":"componentId","p":655361},{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"position","p":655361},{"n":"maxElements","p":655361}],"n":"RenderFrames","d":3538953,"h":90197852169,"f":16777218},{"r":655361,"p":[{"n":"componentId","p":655361},{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"position","p":655361}],"n":"RenderCore","d":3538953,"h":94492819465,"f":16777218},{"r":655361,"p":[{"n":"componentId","p":655361},{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"position","p":655361}],"n":"RenderElement","d":3538953,"h":98787786761,"f":16777218},{"r":655361,"p":[{"n":"componentId","p":655361},{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"position","p":655361},{"n":"maxElements","p":655361}],"n":"RenderScriptElementChildren","d":3538953,"h":103082754057,"f":16777218},{"r":65537,"p":[{"n":"componentId","p":655361},{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"namedEventFramePosition","p":655361}],"n":"RenderHiddenFieldForNamedSubmitEvent","d":3538953,"h":107377721353,"f":16777218},{"r":262145,"p":[{"n":"componentId","p":655361},{"n":"assignedEventName","p":1310721},{"n":"scopeQualifiedEventName","p":1310721,"f":2}],"n":"TryCreateScopeQualifiedEventName","d":3538953,"h":111672688649,"f":16777220},{"r":1245193,"p":[{"n":"forComponentId","p":655361}],"n":"FindFormMappingContext","d":3538953,"h":115967655945,"f":16777218},{"r":262145,"p":[{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"frameIndex","p":655361},{"n":"result","p":655361,"f":2}],"n":"TryFindEnclosingElementFrame","d":3538953,"h":120262623241,"f":16777250},{"r":655361,"p":[{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"position","p":655361},{"n":"maxElements","p":655361},{"n":"includeValueAttribute","p":262145},{"n":"isForm","p":262145},{"n":"capturedValueAttribute","p":1310721,"f":2}],"n":"RenderAttributes","d":3538953,"h":124557590537,"f":16777218},{"r":1310721,"p":[{"n":"navigationManager","p":4980744}],"n":"GetRootRelativeUrlForFormAction","d":3538953,"h":128852557833,"f":16777250},{"r":655361,"p":[{"n":"componentId","p":655361},{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"position","p":655361},{"n":"maxElements","p":655361}],"n":"RenderChildren","d":3538953,"h":133147525129,"f":16777218},{"r":655361,"p":[{"n":"output","p":63045633},{"n":"frames","p":$.$mac.Microsoft.AspNetCore.Components.RenderTree.ArrayRange$$($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderTreeFrame).$h},{"n":"position","p":655361}],"n":"RenderChildComponent","d":3538953,"h":137442492425,"f":16777218}],"l":[{"t":6815752,"n":"_componentPlatform","d":3538953,"h":4298506249,"f":4194338},{"t":4980744,"n":"_navigationManager","d":3538953,"h":8593473545,"f":4194306},{"t":$.$$.System.Collections.Generic.HashSet$$($.$$.System.String).$h,"n":"SelfClosingElements","d":3538953,"h":60133081097,"f":4194338},{"t":655368,"n":"_findFormMappingContext","d":3538953,"h":64428048393,"f":4194338},{"t":1501605,"n":"_javaScriptEncoder","d":3538953,"h":68723015689,"f":4194306},{"t":1501605,"n":"_htmlEncoder","d":3538953,"h":73017982985,"f":4194306},{"t":1310721,"n":"_closestSelectValueAsString","d":3538953,"h":77312950281,"f":4194306}],"c":[{"p":[{"n":"serviceProvider","p":327717},{"n":"loggerFactory","p":1048597}],"n":".ctor","o":"$ctor$3","d":3538953,"h":12888440841,"f":16777217}],"i":[57540609,56950785],"h":3538953}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.RenderTree.Renderer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `StaticHtmlRenderer`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.EditForm", ($self) => class EditForm extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*Func<Task>*/ _handleSubmitDelegate = null;
            /*EditContext?*/ _editContext = null;
            /*bool*/ _hasSetEditContextExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._handleSubmitDelegate = new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this, this.HandleSubmitAsync);
                }
                return this;
            }
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            /*EditContext? */ get EditContext()
            {
                return this._editContext;
            }
            /*EditContext? */ set EditContext(value)
            {
                this._editContext = value;
                this._hasSetEditContextExplicitly = value !== null;
            }
            /*bool*/ Enhance = false;
            /*object?*/ Model = null;
            /*RenderFragment<EditContext>?*/ ChildContent = null;
            /*EventCallback<EditContext>*/ OnSubmit;
            /*EventCallback<EditContext>*/ OnValidSubmit;
            /*EventCallback<EditContext>*/ OnInvalidSubmit;
            /*FormMappingContext?*/ MappingContext = null;
            /*string?*/ FormName = null;
            /*void */ OnParametersSet()
            {
                if (this._hasSetEditContextExplicitly && this.Model !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"EditForm"} requires a ${"Model"} ` + `parameter, or an ${"EditContext"} parameter, but not both.`);
                }
                else if (!this._hasSetEditContextExplicitly && this.Model === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"EditForm"} requires either a ${"Model"} ` + `parameter, or an ${"EditContext"} parameter, please provide one of these.`);
                }
                if (this.OnSubmit.HasDelegate && (this.OnValidSubmit.HasDelegate || this.OnInvalidSubmit.HasDelegate))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`When supplying an ${"OnSubmit"} parameter to ` + `${"EditForm"}, do not also supply ${"OnValidSubmit"} or ${"OnInvalidSubmit"}.`);
                }
                if (this.Model !== null && this.Model !== (this._editContext?.Model ?? null))
                {
                    this._editContext = new $.$macf.Microsoft.AspNetCore.Components.Forms.EditContext().$ctor$1(this.Model);
                }
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._editContext !== null, "_editContext != null");
                builder.OpenRegion($.$$.System.Object.GetHashCode.call(this._editContext));
                builder.OpenElement(0, "form");
                if (this.MappingContext !== null)
                {
                    builder.AddAttribute$3(2, "method", "post");
                }
                if (this.Enhance)
                {
                    builder.AddAttribute$3(3, "data-enhance", "");
                }
                builder.AddMultipleAttributes(4, this.AdditionalAttributes);
                builder.AddAttribute$1(5, "onsubmit", this._handleSubmitDelegate);
                if (this.MappingContext !== null)
                {
                    if (!$.$$.System.String.IsNullOrEmpty(this.FormName))
                    {
                        builder.AddNamedEvent("onsubmit", this.FormName);
                    }
                    this.RenderSSRFormHandlingChildren(builder, 6);
                }
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.CascadingValue$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext), 7);
                builder.AddComponentParameter(7, "IsFixed", $.$box(true, $.$$.System.Boolean));
                builder.AddComponentParameter(8, "Value", this._editContext);
                builder.AddComponentParameter(9, "ChildContent", (this.ChildContent?.Invoke(this._editContext) ?? null));
                builder.CloseComponent();
                builder.CloseElement();
                builder.CloseRegion();
            }
            /*void */ RenderSSRFormHandlingChildren(/*RenderTreeBuilder*/ builder, /*int*/ sequence)
            {
                builder.OpenRegion(sequence);
                builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingValidator, 1);
                builder.AddComponentParameter(2, "CurrentEditContext", this.EditContext);
                builder.CloseComponent();
                builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryToken, 3);
                builder.CloseComponent();
                builder.CloseRegion();
            }
            /*Task *//*async*/  HandleSubmitAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._editContext !== null, "_editContext != null");
                    if (this.OnSubmit.HasDelegate)
                    {
                        await this.OnSubmit.InvokeAsync$1(this._editContext);
                    }
                    else 
                    {
                        /*var*/ let isValid = this._editContext.Validate();
                        if (isValid && this.OnValidSubmit.HasDelegate)
                        {
                            await this.OnValidSubmit.InvokeAsync$1(this._editContext);
                        }
                        if (!isValid && this.OnInvalidSubmit.HasDelegate)
                        {
                            await this.OnInvalidSubmit.InvokeAsync$1(this._editContext);
                        }
                    }
                });
            }
            //default member initializer
            constructor()
            {
                super();
                this.Enhance = false;
                this.OnSubmit = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext));
                this.OnValidSubmit = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext));
                this.OnInvalidSubmit = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext));
            }
            static $h = 851977;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":30065623049,"f":50331649},"s":{"r":0,"d":0,"h":34360590345,"f":83886081},"n":"AdditionalAttributes","d":851977,"h":25770655753,"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":131082,"g":{"r":0,"d":0,"h":42950524937,"f":50331649},"s":{"r":0,"d":0,"h":47245492233,"f":83886081},"n":"EditContext","d":851977,"h":38655557641,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":262145,"g":{"r":0,"d":0,"h":60130394121,"f":50331649},"s":{"r":0,"d":0,"h":64425361417,"f":83886081},"n":"Enhance","d":851977,"h":55835426825,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":131073,"g":{"r":0,"d":0,"h":77310263305,"f":50331649},"s":{"r":0,"d":0,"h":81605230601,"f":83886081},"n":"Model","d":851977,"h":73015296009,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext).$h,"g":{"r":0,"d":0,"h":94490132489,"f":50331649},"s":{"r":0,"d":0,"h":98785099785,"f":83886081},"n":"ChildContent","d":851977,"h":90195165193,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext).$h,"g":{"r":0,"d":0,"h":111670001673,"f":50331649},"s":{"r":0,"d":0,"h":115964968969,"f":83886081},"n":"OnSubmit","d":851977,"h":107375034377,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext).$h,"g":{"r":0,"d":0,"h":128849870857,"f":50331649},"s":{"r":0,"d":0,"h":133144838153,"f":83886081},"n":"OnValidSubmit","d":851977,"h":124554903561,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macf.Microsoft.AspNetCore.Components.Forms.EditContext).$h,"g":{"r":0,"d":0,"h":146029740041,"f":50331649},"s":{"r":0,"d":0,"h":150324707337,"f":83886081},"n":"OnInvalidSubmit","d":851977,"h":141734772745,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1245193,"g":{"r":0,"d":0,"h":163209609225,"f":50331650},"s":{"r":0,"d":0,"h":167504576521,"f":83886082},"n":"MappingContext","d":851977,"h":158914641929,"f":2097154,"a":[{"t":524296,"c":21475360776}]},{"p":1310721,"g":{"r":0,"d":0,"h":180389478409,"f":50331649},"s":{"r":0,"d":0,"h":184684445705,"f":83886081},"n":"FormName","d":851977,"h":176094511113,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"n":"OnParametersSet","d":851977,"h":188979413001,"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":851977,"h":193274380297,"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648},{"n":"sequence","p":655361}],"n":"RenderSSRFormHandlingChildren","d":851977,"h":197569347593,"f":16777218},{"r":133169153,"n":"HandleSubmitAsync","d":851977,"h":201864314889,"f":16781314}],"l":[{"t":$.$$.System.Func$$($.$$.System.Threading.Tasks.Task).$h,"n":"_handleSubmitDelegate","d":851977,"h":4295819273,"f":4194306},{"t":131082,"n":"_editContext","d":851977,"h":8590786569,"f":4194306},{"t":262145,"n":"_hasSetEditContextExplicitly","d":851977,"h":12885753865,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":851977,"h":17180721161,"f":16777217}],"i":[2752520,3145736,3080200],"h":851977}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `EditForm`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet", ($self) => class HeadOutlet extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*string*/ static GetAndRemoveExistingTitle = null;
            /*object*/ static HeadSectionId = null;
            /*object*/ static TitleSectionId = null;
            /*string?*/ _defaultTitle = null;
            /*IJSRuntime*/ JSRuntime = null;
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        this._defaultTitle = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$$.System.String, this.JSRuntime, "Blazor._internal.PageTitle.getAndRemoveExistingTitle"/*GetAndRemoveExistingTitle*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                        this.StateHasChanged();
                    }
                });
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.Sections.SectionOutlet, 0);
                builder.AddComponentParameter(1, "SectionId", $.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet.TitleSectionId);
                builder.CloseComponent();
                if (!$.$$.System.String.IsNullOrEmpty(this._defaultTitle))
                {
                    builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.Sections.SectionContent, 2);
                    builder.AddComponentParameter(3, "SectionId", $.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet.TitleSectionId);
                    builder.AddComponentParameter(4, "IsDefaultContent", $.$box(true, $.$$.System.Boolean));
                    builder.AddComponentParameter(5, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.BuildDefaultTitleRenderTree));
                    builder.CloseComponent();
                }
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.Sections.SectionOutlet, 6);
                builder.AddComponentParameter(7, "SectionId", $.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet.HeadSectionId);
                builder.CloseComponent();
            }
            /*void */ BuildDefaultTitleRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "title");
                builder.AddContent$2(1, this._defaultTitle);
                builder.CloseElement();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.JSRuntime = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.GetAndRemoveExistingTitle = "Blazor._internal.PageTitle.getAndRemoveExistingTitle";
                }
                {
                    this.HeadSectionId = new $.$$.System.Object().$ctor();
                }
                {
                    this.TitleSectionId = new $.$$.System.Object().$ctor();
                }
            }
            static $h = 5570569;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":30070341641,"f":50331650},"s":{"r":0,"d":0,"h":34365308937,"f":83886082},"n":"JSRuntime","d":5570569,"h":25775374345,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":5570569,"h":38660276233,"f":16814084},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":5570569,"h":42955243529,"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildDefaultTitleRenderTree","d":5570569,"h":47250210825,"f":16777218}],"l":[{"t":1310721,"n":"GetAndRemoveExistingTitle","d":5570569,"h":4300537865,"f":4194338},{"t":131073,"n":"HeadSectionId","d":5570569,"h":8595505161,"f":4194344},{"t":131073,"n":"TitleSectionId","d":5570569,"h":12890472457,"f":4194344},{"t":1310721,"n":"_defaultTitle","d":5570569,"h":17185439753,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":5570569,"h":51545178121,"f":16777217}],"i":[2752520,3145736,3080200],"h":5570569}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `HeadOutlet`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.PageTitle", ($self) => class PageTitle extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*RenderFragment?*/ ChildContent = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.Sections.SectionContent, 0);
                builder.AddComponentParameter(1, "SectionId", $.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet.TitleSectionId);
                builder.AddComponentParameter(2, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, this.BuildTitleRenderTree));
                builder.CloseComponent();
            }
            /*void */ BuildTitleRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "title");
                builder.AddContent$4(1, this.ChildContent);
                builder.CloseElement();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6881289;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":6881288,"g":{"r":0,"d":0,"h":12891783177,"f":50331649},"s":{"r":0,"d":0,"h":17186750473,"f":83886081},"n":"ChildContent","d":6881289,"h":8596815881,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":6881289,"h":21481717769,"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildTitleRenderTree","d":6881289,"h":25776685065,"f":16777218}],"c":[{"n":".ctor","o":"$ctor$2","d":6881289,"h":30071652361,"f":16777217}],"i":[2752520,3145736,3080200],"h":6881289}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `PageTitle`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.HeadContent", ($self) => class HeadContent extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*RenderFragment?*/ ChildContent = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.Sections.SectionContent, 0);
                builder.AddComponentParameter(1, "SectionId", $.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet.HeadSectionId);
                builder.AddComponentParameter(2, "ChildContent", this.ChildContent);
                builder.CloseComponent();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 5505033;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":6881288,"g":{"r":0,"d":0,"h":12890406921,"f":50331649},"s":{"r":0,"d":0,"h":17185374217,"f":83886081},"n":"ChildContent","d":5505033,"h":8595439625,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":5505033,"h":21480341513,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":5505033,"h":25775308809,"f":16777217}],"i":[2752520,3145736,3080200],"h":5505033}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `HeadContent`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate", ($self) => class FocusOnNavigate extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*string*/ static CustomElementName = null;
            /*Type?*/ _lastNavigatedPageType = null;
            /*bool*/ _focusAfterRender = false;
            /*IJSRuntime*/ JSRuntime = null;
            /*RouteData?*/ RouteData = null;
            /*string?*/ Selector = null;
            /*void */ OnParametersSet()
            {
                if (this.RouteData === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"FocusOnNavigate"} requires a non-null value for the parameter '${"RouteData"}'.`);
                }
                if ($.$$.System.String.IsNullOrWhiteSpace(this.Selector))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"FocusOnNavigate"} requires a nonempty value for the parameter '${"Selector"}'.`);
                }
                if ($.$$.System.Type.op_Inequality$1(this.RouteData.PageType, this._lastNavigatedPageType))
                {
                    this._lastNavigatedPageType = this.RouteData.PageType;
                    this._focusAfterRender = true;
                }
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                if (!(this.AssignedRenderMode === null))
                {
                    return;
                }
                builder.OpenElement(0, "blazor-focus-on-navigate"/*CustomElementName*/);
                builder.AddAttribute$3(1, "selector", this.Selector);
                builder.CloseElement();
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (this._focusAfterRender)
                    {
                        this._focusAfterRender = false;
                        await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JSRuntime, "Blazor._internal.domWrapper.focusBySelector"/*DomWrapperInterop.FocusBySelector*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this.Selector ], null, null));
                    }
                });
            }
            static $_NonMatchingType;
            static get NonMatchingType()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate;
                return $cls.$_NonMatchingType ??= $asm.$ncls("$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate.NonMatchingType", ($self) => class NonMatchingType extends $.$$.System.Object
                {
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 4128777;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":4128777,"h":4299096073,"f":16777217}],"d":4063241,"h":4128777}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `FocusOnNavigate.NonMatchingType`; }
                }, $cls, ($v) => $cls.$_NonMatchingType = $v);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._lastNavigatedPageType = $.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate.NonMatchingType.$type;
                this.JSRuntime = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.CustomElementName = "blazor-focus-on-navigate";
                }
            }
            static $h = 4063241;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":25773867017,"f":50331650},"s":{"r":0,"d":0,"h":30068834313,"f":83886082},"n":"JSRuntime","d":4063241,"h":21478899721,"f":2097154,"a":[{"t":4259848,"c":21479096328}]},{"p":9961480,"g":{"r":0,"d":0,"h":42953736201,"f":50331649},"s":{"r":0,"d":0,"h":47248703497,"f":83886081},"n":"RouteData","d":4063241,"h":38658768905,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":60133605385,"f":50331649},"s":{"r":0,"d":0,"h":64428572681,"f":83886081},"n":"Selector","d":4063241,"h":55838638089,"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"n":"OnParametersSet","d":4063241,"h":68723539977,"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":4063241,"h":73018507273,"f":16809988},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":4063241,"h":77313474569,"f":16814084}],"l":[{"t":1310721,"n":"CustomElementName","d":4063241,"h":4299030537,"f":4194338},{"t":142475265,"n":"_lastNavigatedPageType","d":4063241,"h":8593997833,"f":4194306},{"t":262145,"n":"_focusAfterRender","d":4063241,"h":12888965129,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":4063241,"h":85903409161,"f":16777217}],"i":[2752520,3145736,3080200],"j":[4128777],"h":4063241}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `FocusOnNavigate`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputRadio<>", (TValue) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.InputRadio<>", [TValue], ($self) => class InputRadio$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*bool*/ _trueValueToggle = false;
            /*InputRadioContext?*/ Context = null;
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            /*TValue?*/ Value = null;
            /*string?*/ Name = null;
            /*ElementReference?*/ Element = null;
            /*InputRadioContext?*/ CascadedContext = null;
            /*void */ OnParametersSet()
            {
                this.Context = $.$$.System.String.IsNullOrEmpty(this.Name) ? this.CascadedContext : (this.CascadedContext?.FindContextInAncestors(this.Name) ?? null);
                if (this.Context === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} must have an ancestor ${$.$$.System.Type.ToString.call($.$macw.Microsoft.AspNetCore.Components.Forms.InputRadioGroup$$(TValue).$type)} ` + `with a matching 'Name' property, if specified.`);
                }
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.Context !== null, "Context != null");
                builder.OpenElement(0, "input");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 2, "class", $.$macw.Microsoft.AspNetCore.Components.Forms.AttributeUtilities.CombineClassNames(this.AdditionalAttributes, this.Context.FieldClass));
                builder.AddAttribute$3(3, "type", "radio");
                builder.AddAttribute$3(4, "name", this.Context.GroupName);
                const $t1 = this.Value;
                builder.AddAttribute$3(5, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$28($.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t)), null));
                const $t2 = () => this.Context.CurrentValue;
                builder.AddAttribute$3(6, "checked", $.$ifnn($t2, ($t) => $.$$.System.Object.Equals$1.call($t, $.$box(this.Value, TValue))) === true ? this.GetToggledTrueValue() : null);
                builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 7, "onchange", this.Context.ChangeEventCallback);
                builder.SetUpdatesAttributeName("checked");
                builder.AddElementReferenceCapture(8, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/**/ __inputReference) =>
                {
                    return this.Element = __inputReference;
                }, {"r":65537,"p":[{"n":"__inputReference","p":1900552}],"n":"","d":this.$h,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*string */ GetToggledTrueValue()
            {
                this._trueValueToggle = !this._trueValueToggle;
                return this._trueValueToggle ? "a" : "b";
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Element = null;
            }
            static $h = 2293769;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":2359305,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331656},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":83886082},"n":"Context","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097160},{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":83886081},"n":"AdditionalAttributes","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":TValue?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":83886081},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":83886081},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1500000000n),"f":83886084},"n":"Element","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2097153},{"p":2359305,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1800000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1900000000n),"f":83886082},"n":"CascadedContext","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":2097154,"a":[{"t":524296,"c":21475360776}]}],"m":[{"r":65537,"n":"OnParametersSet","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16809988},{"r":1310721,"n":"GetToggledTrueValue","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":16777218}],"l":[{"t":262145,"n":"_trueValueToggle","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":16777217}],"i":[2752520,3145736,3080200],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `InputRadio<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.ValidationSummary", ($self) => class ValidationSummary extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*EditContext?*/ _previousEditContext = null;
            /*EventHandler<ValidationStateChangedEventArgs>*/ _validationStateChangedHandler = null;
            /*object?*/ Model = null;
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            /*EditContext*/ CurrentEditContext = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._validationStateChangedHandler = new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs))().$ctor(this,  (/*sender*/ sender, /*eventArgs*/ eventArgs) =>
                    {
                        return this.StateHasChanged();
                    }, {"r":65537,"p":[{"n":"sender","p":131073},{"n":"eventArgs","p":1048586}],"n":"","d":3473417,"h":0,"f":17825794});
                }
                return this;
            }
            /*void */ OnParametersSet()
            {
                if (this.CurrentEditContext === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"ValidationSummary"} requires a cascading parameter ` + `of type ${"EditContext"}. For example, you can use ${"ValidationSummary"} inside ` + `an ${"EditForm"}.`);
                }
                if (this.CurrentEditContext !== this._previousEditContext)
                {
                    this.DetachValidationStateChangedListener();
                    this.CurrentEditContext.add_OnValidationStateChanged(this._validationStateChangedHandler);
                    this._previousEditContext = this.CurrentEditContext;
                }
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                /*var*/ let validationMessages = this.Model === null ? this.CurrentEditContext.GetValidationMessages() : this.CurrentEditContext.GetValidationMessages$1(new $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier().$ctor$3(this.Model, $.$$.System.String.Empty));
                /*var*/ let first = true;
                var $en2 = validationMessages.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var error = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                            builder.OpenElement(0, "ul");
                            builder.AddAttribute$3(1, "class", "validation-errors");
                            builder.AddMultipleAttributes(2, this.AdditionalAttributes);
                        }
                        builder.OpenElement(3, "li");
                        builder.AddAttribute$3(4, "class", "validation-message");
                        builder.AddContent$2(5, error);
                        builder.CloseElement();
                    }
                }
                if (!first)
                {
                    builder.CloseElement();
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
            }
            /*void */ System$IDisposable$Dispose()
            {
                this.DetachValidationStateChangedListener();
                this.Dispose(true);
            }
            /*void */ DetachValidationStateChangedListener()
            {
                if (this._previousEditContext !== null)
                {
                    this._previousEditContext.remove_OnValidationStateChanged(this._validationStateChangedHandler);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.CurrentEditContext = null;
            }
            static $h = 3473417;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":131073,"g":{"r":0,"d":0,"h":21478309897,"f":50331649},"s":{"r":0,"d":0,"h":25773277193,"f":83886081},"n":"Model","d":3473417,"h":17183342601,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":38658179081,"f":50331649},"s":{"r":0,"d":0,"h":42953146377,"f":83886081},"n":"AdditionalAttributes","d":3473417,"h":34363211785,"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":131082,"g":{"r":0,"d":0,"h":55838048265,"f":50331650},"s":{"r":0,"d":0,"h":60133015561,"f":83886082},"n":"CurrentEditContext","d":3473417,"h":51543080969,"f":2097154,"a":[{"t":524296,"c":21475360776}]}],"m":[{"r":65537,"n":"OnParametersSet","d":3473417,"h":68722950153,"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":3473417,"h":73017917449,"f":16809988},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":3473417,"h":77312884745,"f":16777348},{"r":65537,"n":"DetachValidationStateChangedListener","d":3473417,"h":85902819337,"f":16777218}],"l":[{"t":131082,"n":"_previousEditContext","d":3473417,"h":4298440713,"f":4194306},{"t":$.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h,"n":"_validationStateChangedHandler","d":3473417,"h":8593408009,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":3473417,"h":64427982857,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":3473417}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `ValidationSummary`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Routing.NavLink", ($self) => class NavLink extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*string*/ static EnableMatchAllForQueryStringAndFragmentSwitchKey = null;
            /*bool*/ static _enableMatchAllForQueryStringAndFragment = false;
            /*string*/ static DefaultActiveClass = null;
            /*bool*/ _isActive = false;
            /*string?*/ _hrefAbsolute = null;
            /*string?*/ _class = null;
            /*string?*/ ActiveClass = null;
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            /*string?*/ CssClass = null;
            /*RenderFragment?*/ ChildContent = null;
            /*NavLinkMatch*/ Match = 0;
            /*NavigationManager*/ NavigationManager = null;
            /*void */ OnInitialized()
            {
                this.NavigationManager.add_LocationChanged(new ($.$$.System.EventHandler$$($.$mac.Microsoft.AspNetCore.Components.Routing.LocationChangedEventArgs))().$ctor(this, this.OnLocationChanged));
            }
            /*void */ OnParametersSet()
            {
                /*var*/ let href = null;
                /*var*/ let obj;
                if (this.AdditionalAttributes !== null && this.AdditionalAttributes.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue("href", $.$ref(() => obj, ($v) => obj = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    href = $.$$.System.Convert.ToString$23(obj, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                }
                this._hrefAbsolute = $.$$.System.String.op_Equality(href, null) ? null : this.NavigationManager.ToAbsoluteUri(href).AbsoluteUri;
                this._isActive = this.ShouldMatch(this.NavigationManager.Uri);
                this._class = null;
                if (this.AdditionalAttributes !== null && this.AdditionalAttributes.System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue("class", $.$ref(() => obj, ($v) => obj = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    this._class = $.$$.System.Convert.ToString$23(obj, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                }
                this.UpdateCssClass();
            }
            /*void */ Dispose()
            {
                this.NavigationManager.remove_LocationChanged(new ($.$$.System.EventHandler$$($.$mac.Microsoft.AspNetCore.Components.Routing.LocationChangedEventArgs))().$ctor(this, this.OnLocationChanged));
            }
            /*void */ UpdateCssClass()
            {
                this.CssClass = this._isActive ? $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.CombineWithSpace(this._class, this.ActiveClass ?? "active"/*DefaultActiveClass*/) : this._class;
            }
            /*void */ OnLocationChanged(/*object?*/ sender, /*LocationChangedEventArgs*/ args)
            {
                /*var*/ let shouldBeActiveNow = this.ShouldMatch(args.Location);
                if (shouldBeActiveNow !== this._isActive)
                {
                    this._isActive = shouldBeActiveNow;
                    this.UpdateCssClass();
                    this.StateHasChanged();
                }
            }
            /*bool */ ShouldMatch(/*string*/ uriAbsolute)
            {
                if ($.$$.System.String.op_Equality(this._hrefAbsolute, null))
                {
                    return false;
                }
                /*var*/ let uriAbsoluteSpan = $.$$.System.MemoryExtensions.AsSpan$4(uriAbsolute);
                /*var*/ let hrefAbsoluteSpan = $.$$.System.MemoryExtensions.AsSpan$4(this._hrefAbsolute);
                if ($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.EqualsHrefExactlyOrIfTrailingSlashAdded(uriAbsoluteSpan, hrefAbsoluteSpan))
                {
                    return true;
                }
                if (this.Match === 0/*NavLinkMatch.Prefix*/ && $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.IsStrictlyPrefixWithSeparator(uriAbsolute, this._hrefAbsolute))
                {
                    return true;
                }
                if ($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink._enableMatchAllForQueryStringAndFragment || this.Match !== 1/*NavLinkMatch.All*/)
                {
                    return false;
                }
                /*var*/ let uriWithoutQueryAndFragment = $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.GetUriIgnoreQueryAndFragment(uriAbsoluteSpan);
                if ($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.EqualsHrefExactlyOrIfTrailingSlashAdded(uriWithoutQueryAndFragment, hrefAbsoluteSpan))
                {
                    return true;
                }
                hrefAbsoluteSpan = $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.GetUriIgnoreQueryAndFragment(hrefAbsoluteSpan);
                return $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.EqualsHrefExactlyOrIfTrailingSlashAdded(uriWithoutQueryAndFragment, hrefAbsoluteSpan);
            }
            static /*ReadOnlySpan<char> */ GetUriIgnoreQueryAndFragment(/*ReadOnlySpan<char>*/ uri)
            {
                if (uri.IsEmpty)
                {
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                }
                /*var*/ let queryStartPos = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, uri, /*?*/ 63);
                /*var*/ let fragmentStartPos = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, uri, /*#*/ 35);
                if (queryStartPos < 0 && fragmentStartPos < 0)
                {
                    return uri;
                }
                /*int*/ let minPos;
                if (queryStartPos < 0)
                {
                    minPos = fragmentStartPos;
                }
                else if (fragmentStartPos < 0)
                {
                    minPos = queryStartPos;
                }
                else 
                {
                    minPos = $.$$.System.Math.Min$4(queryStartPos, fragmentStartPos);
                }
                return uri.Slice(0, minPos);
            }
            /*CaseInsensitiveCharComparer*/ static CaseInsensitiveComparer = null;
            static /*bool */ EqualsHrefExactlyOrIfTrailingSlashAdded(/*ReadOnlySpan<char>*/ currentUriAbsolute, /*ReadOnlySpan<char>*/ hrefAbsolute)
            {
                if ($.$$.System.MemoryExtensions.SequenceEqual($.$$.System.Char, currentUriAbsolute, hrefAbsolute, $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.CaseInsensitiveComparer))
                {
                    return true;
                }
                if (currentUriAbsolute.Length === ((hrefAbsolute.Length - 1) | 0))
                {
                    if (hrefAbsolute.get_Item(((hrefAbsolute.Length - 1) | 0)).$v === /*/*/ 47 && $.$$.System.MemoryExtensions.SequenceEqual($.$$.System.Char, currentUriAbsolute, hrefAbsolute.Slice(0, ((hrefAbsolute.Length - 1) | 0)), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.CaseInsensitiveComparer))
                    {
                        return true;
                    }
                }
                return false;
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "a");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                builder.AddAttribute$3(2, "class", this.CssClass);
                if (this._isActive)
                {
                    builder.AddAttribute$3(3, "aria-current", "page");
                }
                builder.AddContent$4(4, this.ChildContent);
                builder.CloseElement();
            }
            static /*string? */ CombineWithSpace(/*string?*/ str1, /*string*/ str2)
            {
                return $.$$.System.String.op_Equality(str1, null) ? str2 : `${str1} ${str2}`;
            }
            static /*bool */ IsStrictlyPrefixWithSeparator(/*string*/ value, /*string*/ prefix)
            {
                /*var*/ let prefixLength = prefix.length;
                if (value.length > prefixLength)
                {
                    return $.$$.System.String.StartsWith$2.call(value, prefix, 5/*StringComparison.OrdinalIgnoreCase*/) && (prefixLength === 0 || !$.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.IsUnreservedCharacter($.$$.System.String.get_Chars.call(prefix, ((prefixLength - 1) | 0))) || !$.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.IsUnreservedCharacter($.$$.System.String.get_Chars.call(value, prefixLength)));
                }
                else 
                {
                    return false;
                }
            }
            static /*bool */ IsUnreservedCharacter(/*char*/ c)
            {
                return $.$$.System.Char.IsLetterOrDigit(c) || c === /*-*/ 45 || c === /*.*/ 46 || c === /*_*/ 95 || c === /*~*/ 126;
            }
            static $_CaseInsensitiveCharComparer;
            static get CaseInsensitiveCharComparer()
            {
                let $cls = $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink;
                return $cls.$_CaseInsensitiveCharComparer ??= $asm.$ncls("$macw.Microsoft.AspNetCore.Components.Routing.NavLink.CaseInsensitiveCharComparer", ($self) => class CaseInsensitiveCharComparer extends $.$$.System.Object
                {
                    /*bool */ Equals$2(/*char*/ x, /*char*/ y)
                    {
                        return $.$$.System.Char.ToLowerInvariant(x) === $.$$.System.Char.ToLowerInvariant(y);
                    }
                    /*int */ GetHashCode$1(/*char*/ obj)
                    {
                        return $.$$.System.Char.GetHashCode.call($.$$.System.Char.ToLowerInvariant(obj));
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<char>.Equals(char, char)
                    System$Collections$Generic$IEqualityComparer$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<char>.GetHashCode(char)
                    System$Collections$Generic$IEqualityComparer$$$GetHashCode()
                    {
                        return this.GetHashCode$1(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 4390921;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"x","p":458753},{"n":"y","p":458753}],"n":"Equals","o":"@$2","d":4390921,"h":4299358217,"f":16777217},{"r":655361,"p":[{"n":"obj","p":458753}],"n":"GetHashCode","o":"@$1","d":4390921,"h":8594325513,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":4390921,"h":12889292809,"f":16777217}],"i":[$.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.Char).$h],"d":4325385,"h":4390921}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.Char) ]; }
                    static get $fullName() { return `NavLink.CaseInsensitiveCharComparer`; }
                }, $cls, ($v) => $cls.$_CaseInsensitiveCharComparer = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Match = 0;
                this.NavigationManager = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EnableMatchAllForQueryStringAndFragmentSwitchKey = "Microsoft.AspNetCore.Components.Routing.NavLink.EnableMatchAllForQueryStringAndFragment";
                }
                {
                    /*var*/ let switchValue;
                    this._enableMatchAllForQueryStringAndFragment = $.$$.System.AppContext.TryGetSwitch("Microsoft.AspNetCore.Components.Routing.NavLink.EnableMatchAllForQueryStringAndFragment"/*EnableMatchAllForQueryStringAndFragmentSwitchKey*/, $.$ref(() => switchValue, ($v) => switchValue = $v, $.$$.System.Boolean)) && switchValue;
                }
                {
                    this.DefaultActiveClass = "active";
                }
                {
                    this.CaseInsensitiveComparer = new $.$macw.Microsoft.AspNetCore.Components.Routing.NavLink.CaseInsensitiveCharComparer().$ctor$1();
                }
            }
            static $h = 4325385;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":38659031049,"f":50331649},"s":{"r":0,"d":0,"h":42953998345,"f":83886081},"n":"ActiveClass","d":4325385,"h":34364063753,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":55838900233,"f":50331649},"s":{"r":0,"d":0,"h":60133867529,"f":83886081},"n":"AdditionalAttributes","d":4325385,"h":51543932937,"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":73018769417,"f":50331652},"s":{"r":0,"d":0,"h":77313736713,"f":83886084},"n":"CssClass","d":4325385,"h":68723802121,"f":2097156},{"p":6881288,"g":{"r":0,"d":0,"h":90198638601,"f":50331649},"s":{"r":0,"d":0,"h":94493605897,"f":83886081},"n":"ChildContent","d":4325385,"h":85903671305,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":4456457,"g":{"r":0,"d":0,"h":107378507785,"f":50331649},"s":{"r":0,"d":0,"h":111673475081,"f":83886081},"n":"Match","d":4325385,"h":103083540489,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":4980744,"g":{"r":0,"d":0,"h":124558376969,"f":50331650},"s":{"r":0,"d":0,"h":128853344265,"f":83886082},"n":"NavigationManager","d":4325385,"h":120263409673,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"n":"OnInitialized","d":4325385,"h":133148311561,"f":16809988},{"r":65537,"n":"OnParametersSet","d":4325385,"h":137443278857,"f":16809988},{"r":65537,"n":"Dispose","d":4325385,"h":141738246153,"f":16777217},{"r":65537,"n":"UpdateCssClass","d":4325385,"h":146033213449,"f":16777218},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"args","p":10551304}],"n":"OnLocationChanged","d":4325385,"h":150328180745,"f":16777218},{"r":262145,"p":[{"n":"uriAbsolute","p":1310721}],"n":"ShouldMatch","d":4325385,"h":154623148041,"f":16777348},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"uri","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"GetUriIgnoreQueryAndFragment","d":4325385,"h":158918115337,"f":16777250},{"r":262145,"p":[{"n":"currentUriAbsolute","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"hrefAbsolute","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"EqualsHrefExactlyOrIfTrailingSlashAdded","d":4325385,"h":167508049929,"f":16777250},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":4325385,"h":171803017225,"f":16809988},{"r":1310721,"p":[{"n":"str1","p":1310721},{"n":"str2","p":1310721}],"n":"CombineWithSpace","d":4325385,"h":176097984521,"f":16777250},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"prefix","p":1310721}],"n":"IsStrictlyPrefixWithSeparator","d":4325385,"h":180392951817,"f":16777250},{"r":262145,"p":[{"n":"c","p":458753}],"n":"IsUnreservedCharacter","d":4325385,"h":184687919113,"f":16777250}],"l":[{"t":1310721,"n":"EnableMatchAllForQueryStringAndFragmentSwitchKey","d":4325385,"h":4299292681,"f":4194338},{"t":262145,"n":"_enableMatchAllForQueryStringAndFragment","d":4325385,"h":8594259977,"f":4194338},{"t":1310721,"n":"DefaultActiveClass","d":4325385,"h":12889227273,"f":4194338},{"t":262145,"n":"_isActive","d":4325385,"h":17184194569,"f":4194306},{"t":1310721,"n":"_hrefAbsolute","d":4325385,"h":21479161865,"f":4194306},{"t":1310721,"n":"_class","d":4325385,"h":25774129161,"f":4194306},{"t":4390921,"n":"CaseInsensitiveComparer","d":4325385,"h":163213082633,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$2","d":4325385,"h":193277853705,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"j":[4390921],"h":4325385}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `NavLink`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.ValidationMessage<>", (TValue) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.ValidationMessage<>", [TValue], ($self) => class ValidationMessage$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*EditContext?*/ _previousEditContext = null;
            /*Expression<Func<TValue>>?*/ _previousFieldAccessor = null;
            /*EventHandler<ValidationStateChangedEventArgs>?*/ _validationStateChangedHandler = null;
            /*FieldIdentifier*/ _fieldIdentifier;
            /*IReadOnlyDictionary<string, object>?*/ AdditionalAttributes = null;
            /*EditContext*/ CurrentEditContext = null;
            /*Expression<Func<TValue>>?*/ For = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._validationStateChangedHandler = new ($.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs))().$ctor(this,  (/**/ sender, /*eventArgs*/ eventArgs) =>
                    {
                        return this.StateHasChanged();
                    }, {"r":65537,"p":[{"n":"sender","p":131073},{"n":"eventArgs","p":1048586}],"n":"","d":this.$h,"h":0,"f":17825794});
                }
                return this;
            }
            /*void */ OnParametersSet()
            {
                if (this.CurrentEditContext === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} requires a cascading parameter ` + `of type ${"EditContext"}. For example, you can use ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} inside ` + `an ${"EditForm"}.`);
                }
                if (this.For === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} requires a value for the ` + `${"For"} parameter.`);
                }
                else if (this.For !== this._previousFieldAccessor)
                {
                    this._fieldIdentifier = $.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier.Create(TValue, this.For);
                    this._previousFieldAccessor = this.For;
                }
                if (this.CurrentEditContext !== this._previousEditContext)
                {
                    this.DetachValidationStateChangedListener();
                    this.CurrentEditContext.add_OnValidationStateChanged(this._validationStateChangedHandler);
                    this._previousEditContext = this.CurrentEditContext;
                }
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                var $en2 = this.CurrentEditContext.GetValidationMessages$1(this._fieldIdentifier).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var message = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        builder.OpenElement(0, "div");
                        builder.AddAttribute$3(1, "class", "validation-message");
                        builder.AddMultipleAttributes(2, this.AdditionalAttributes);
                        builder.AddContent$2(3, message);
                        builder.CloseElement();
                    }
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
            }
            /*void */ System$IDisposable$Dispose()
            {
                this.DetachValidationStateChangedListener();
                this.Dispose(true);
            }
            /*void */ DetachValidationStateChangedListener()
            {
                if (this._previousEditContext !== null)
                {
                    this._previousEditContext.remove_OnValidationStateChanged(this._validationStateChangedHandler);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._fieldIdentifier = $.$default($.$macf.Microsoft.AspNetCore.Components.Forms.FieldIdentifier);
                this.CurrentEditContext = null;
            }
            static $h = 3407881;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":83886081},"n":"AdditionalAttributes","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":131082,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":83886082},"n":"CurrentEditContext","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2097154,"a":[{"t":524296,"c":21475360776}]},{"p":$.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$(TValue)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":83886081},"n":"For","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"n":"OnParametersSet","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16809988},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777348},{"r":65537,"n":"DetachValidationStateChangedListener","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777218}],"l":[{"t":131082,"n":"_previousEditContext","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$(TValue)).$h,"n":"_previousFieldAccessor","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$$.System.EventHandler$$($.$macf.Microsoft.AspNetCore.Components.Forms.ValidationStateChangedEventArgs).$h,"n":"_validationStateChangedHandler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":655370,"n":"_fieldIdentifier","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777217}],"i":[2752520,3145736,3080200,57540609],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `ValidationMessage<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.Mapping.FormMappingValidator", ($self) => class FormMappingValidator extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*IDisposable?*/ _subscriptions = null;
            /*EditContext?*/ _originalEditContext = null;
            /*EditContext?*/ CurrentEditContext = null;
            /*FormMappingContext?*/ MappingContext = null;
            /*void */ OnInitialized()
            {
                if (this.CurrentEditContext === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${"FormMappingValidator"} requires a ` + `parameter of type ${"EditContext"}.`);
                }
                if (this.MappingContext === null)
                {
                    return;
                }
                this._subscriptions = $.$macw.Microsoft.AspNetCore.Components.Forms.Mapping.EditContextFormMappingExtensions.EnableFormMappingContextExtensions(this.CurrentEditContext, this.MappingContext);
                this._originalEditContext = this.CurrentEditContext;
            }
            /*void */ OnParametersSet()
            {
                if (this.MappingContext === null)
                {
                    return;
                }
                if (this.CurrentEditContext !== this._originalEditContext)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} does not support changing the ` + `${"EditContext"} dynamically.`);
                }
            }
            /*void */ System$IDisposable$Dispose()
            {
                this._subscriptions?.System$IDisposable$Dispose();
                this._subscriptions = null;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2883593;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":131082,"g":{"r":0,"d":0,"h":21477720073,"f":50331649},"s":{"r":0,"d":0,"h":25772687369,"f":83886081},"n":"CurrentEditContext","d":2883593,"h":17182752777,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1245193,"g":{"r":0,"d":0,"h":38657589257,"f":50331656},"s":{"r":0,"d":0,"h":42952556553,"f":83886088},"n":"MappingContext","d":2883593,"h":34362621961,"f":2097160,"a":[{"t":524296,"c":21475360776}]}],"m":[{"r":65537,"n":"OnInitialized","d":2883593,"h":47247523849,"f":16809988},{"r":65537,"n":"OnParametersSet","d":2883593,"h":51542491145,"f":16809988}],"l":[{"t":57540609,"n":"_subscriptions","d":2883593,"h":4297850889,"f":4194306},{"t":131082,"n":"_originalEditContext","d":2883593,"h":8592818185,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":2883593,"h":60132425737,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":2883593}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `FormMappingValidator`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputFile", ($self) => class InputFile extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*ElementReference*/ _inputFileElement;
            /*InputFileJsCallbacksRelay?*/ _jsCallbacksRelay = null;
            /*IJSRuntime*/ JSRuntime = null;
            /*EventCallback<InputFileChangeEventArgs>*/ OnChange;
            /*IDictionary<string, object>?*/ AdditionalAttributes = null;
            /*ElementReference? */ get Element()
            {
                return this._inputFileElement;
            }
            /*ElementReference? */ set Element(value)
            {
                this._inputFileElement = $.$$.System.Nullable$$($.$mac.Microsoft.AspNetCore.Components.ElementReference).Value$get.call(value);
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        this._jsCallbacksRelay = new $.$macw.Microsoft.AspNetCore.Components.Forms.InputFileJsCallbacksRelay().$ctor$1(this);
                        await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JSRuntime, "Blazor._internal.InputFile.init"/*InputFileInterop.Init*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._jsCallbacksRelay.DotNetReference, this._inputFileElement ], null, null));
                    }
                });
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "input");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                builder.AddAttribute$3(2, "type", "file");
                builder.AddElementReferenceCapture(3, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/**/ elementReference) =>
                {
                    return this._inputFileElement = elementReference;
                }, {"r":65537,"p":[{"n":"elementReference","p":1900552}],"n":"","d":1900553,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*Stream */ OpenReadStream(/*BrowserFile*/ file, /*long*/ maxAllowedSize, /*CancellationToken*/ cancellationToken)
            {
                return new $.$macw.Microsoft.AspNetCore.Components.Forms.BrowserFileStream().$ctor$3(this.JSRuntime, this._inputFileElement, file, maxAllowedSize, cancellationToken);
            }
            /*ValueTask<IBrowserFile> *//*async*/  ConvertToImageFileAsync(/*BrowserFile*/ file, /*string*/ format, /*int*/ maxWidth, /*int*/ maxHeight)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile), $.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile, async () => 
                {
                    /*var*/ let imageFile = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$macw.Microsoft.AspNetCore.Components.Forms.BrowserFile, this.JSRuntime, "Blazor._internal.InputFile.toImageFile"/*InputFileInterop.ToImageFile*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._inputFileElement, $.$box(file.Id, $.$$.System.Int32), format, $.$box(maxWidth, $.$$.System.Int32), $.$box(maxHeight, $.$$.System.Int32) ], null, null));
                    if (imageFile === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12("ToImageFile returned an unexpected null result.");
                    }
                    imageFile.Owner = this;
                    return imageFile;
                });
            }
            /*Task */ Microsoft$AspNetCore$Components$Forms$IInputFileJsCallbacks$NotifyChange(/*BrowserFile[]*/ files)
            {
                let $i1 = 0;
                let $arr1 = files;
                while ($i1 < $arr1.length)
                {
                    let file = $arr1[$i1++];
                    file.Owner = this;
                }
                return this.OnChange.InvokeAsync$1(new $.$macw.Microsoft.AspNetCore.Components.Forms.InputFileChangeEventArgs().$ctor$2(files));
            }
            /*void */ System$IDisposable$Dispose()
            {
                this._jsCallbacksRelay?.Dispose();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._inputFileElement = $.$default($.$mac.Microsoft.AspNetCore.Components.ElementReference);
                this.JSRuntime = null;
                this.OnChange = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Forms.InputFileChangeEventArgs));
            }
            static $h = 1900553;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":21476737033,"f":50331656},"s":{"r":0,"d":0,"h":25771704329,"f":83886088},"n":"JSRuntime","d":1900553,"h":17181769737,"f":2097160,"a":[{"t":4259848,"c":21479096328}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$macw.Microsoft.AspNetCore.Components.Forms.InputFileChangeEventArgs).$h,"g":{"r":0,"d":0,"h":38656606217,"f":50331649},"s":{"r":0,"d":0,"h":42951573513,"f":83886081},"n":"OnChange","d":1900553,"h":34361638921,"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":55836475401,"f":50331649},"s":{"r":0,"d":0,"h":60131442697,"f":83886081},"n":"AdditionalAttributes","d":1900553,"h":51541508105,"f":2097153,"a":[{"t":5636104,"c":21480472584,"n":[{"n":"CaptureUnmatchedValues","v":true,"t":262145}]}]},{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":68721377289,"f":50331649},"s":{"r":0,"d":0,"h":73016344585,"f":83886084},"n":"Element","d":1900553,"h":64426409993,"f":2097153}],"m":[{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1900553,"h":77311311881,"f":16814084},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":1900553,"h":81606279177,"f":16809988},{"r":62193665,"p":[{"n":"file","p":524297},{"n":"maxAllowedSize","p":917505},{"n":"cancellationToken","p":125829121}],"n":"OpenReadStream","d":1900553,"h":85901246473,"f":16777224},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile).$h,"p":[{"n":"file","p":524297},{"n":"format","p":1310721},{"n":"maxWidth","p":655361},{"n":"maxHeight","p":655361}],"n":"ConvertToImageFileAsync","d":1900553,"h":90196213769,"f":16781320}],"l":[{"t":1900552,"n":"_inputFileElement","d":1900553,"h":4296867849,"f":4194306},{"t":2097161,"n":"_jsCallbacksRelay","d":1900553,"h":8591835145,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1900553,"h":103081115657,"f":16777217}],"i":[2752520,3145736,3080200,1507337,57540609],"h":1900553}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$macw.Microsoft.AspNetCore.Components.Forms.IInputFileJsCallbacks, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputFile`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize<>", (TItem) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize<>", [TItem], ($self) => class Virtualize$$ extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*VirtualizeJsInterop?*/ _jsInterop = null;
            /*ElementReference*/ _spacerBefore;
            /*ElementReference*/ _spacerAfter;
            /*int*/ _itemsBefore = 0;
            /*int*/ _visibleItemCapacity = 0;
            /*int*/ _unusedItemCapacity = 0;
            /*int*/ _itemCount = 0;
            /*int*/ _loadedItemsStartIndex = 0;
            /*int*/ _lastRenderedItemCount = 0;
            /*int*/ _lastRenderedPlaceholderCount = 0;
            /*float*/ _itemSize = 0;
            /*IEnumerable<TItem>?*/ _loadedItems = null;
            /*CancellationTokenSource?*/ _refreshCts = null;
            /*Exception?*/ _refreshException = null;
            /*ItemsProviderDelegate<TItem>*/ _itemsProvider = null;
            /*RenderFragment<TItem>?*/ _itemTemplate = null;
            /*RenderFragment<PlaceholderContext>?*/ _placeholder = null;
            /*RenderFragment?*/ _emptyContent = null;
            /*bool*/ _loading = false;
            /*IJSRuntime*/ JSRuntime = null;
            /*RenderFragment<TItem>?*/ ChildContent = null;
            /*RenderFragment<TItem>?*/ ItemContent = null;
            /*RenderFragment<PlaceholderContext>?*/ Placeholder = null;
            /*RenderFragment?*/ EmptyContent = null;
            /*float*/ ItemSize = 0;
            /*ItemsProviderDelegate<TItem>?*/ ItemsProvider = null;
            /*ICollection<TItem>?*/ Items = null;
            /*int*/ OverscanCount = 0;
            /*string*/ SpacerElement = null;
            /*int*/ MaxItemCount = 0;
            /*Task *//*async*/  RefreshDataAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.RefreshDataCoreAsync(false);
                });
            }
            /*void */ OnParametersSet()
            {
                if (this.ItemSize <= 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} requires a positive value for parameter '${"ItemSize"}'.`);
                }
                if (this._itemSize <= 0)
                {
                    this._itemSize = this.ItemSize;
                }
                if (this.ItemsProvider !== null)
                {
                    if (this.Items !== null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} can only accept one item source from its parameters. ` + `Do not supply both '${"Items"}' and '${"ItemsProvider"}'.`);
                    }
                    this._itemsProvider = this.ItemsProvider;
                }
                else if (this.Items !== null)
                {
                    this._itemsProvider = new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate$$(TItem))().$ctor(this, this.DefaultItemsProvider);
                    /*var*/ let refreshTask = this.RefreshDataCoreAsync(false);
                    $.$$.System.Diagnostics.Debug.Assert$2(refreshTask.IsCompletedSuccessfully, "refreshTask.IsCompletedSuccessfully");
                }
                else 
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} requires either the '${"Items"}' or '${"ItemsProvider"}' parameters to be specified ` + `and non-null.`);
                }
                this._itemTemplate = this.ItemContent ?? this.ChildContent;
                this._placeholder = this.Placeholder ?? new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext))().$ctor(this, this.DefaultPlaceholder);
                this._emptyContent = this.EmptyContent;
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        this._jsInterop = new $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.VirtualizeJsInterop().$ctor$1(this, this.JSRuntime);
                        await this._jsInterop.InitializeAsync(this._spacerBefore, this._spacerAfter);
                    }
                });
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                if (this._refreshException !== null)
                {
                    /*var*/ let oldRefreshException = this._refreshException;
                    this._refreshException = null;
                    throw oldRefreshException;
                }
                builder.OpenElement(0, this.SpacerElement);
                builder.AddAttribute$3(1, "style", this.GetSpacerStyle$1(this._itemsBefore));
                builder.AddAttribute$3(2, "aria-hidden", "true");
                builder.AddElementReferenceCapture(3, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*elementReference*/ elementReference) =>
                {
                    return this._spacerBefore = elementReference;
                }, {"r":65537,"p":[{"n":"elementReference","p":1900552}],"n":"","d":this.$h,"h":0,"f":17825794}));
                builder.CloseElement();
                /*var*/ let lastItemIndex = $.$$.System.Math.Min$4(((this._itemsBefore + this._visibleItemCapacity) | 0), this._itemCount);
                /*var*/ let renderIndex = this._itemsBefore;
                /*var*/ let placeholdersBeforeCount = $.$$.System.Math.Min$4(this._loadedItemsStartIndex, lastItemIndex);
                builder.OpenRegion(3);
                for(; renderIndex < placeholdersBeforeCount; renderIndex++)
                {
                    builder.AddContent$5($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext, renderIndex, this._placeholder, new $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext().$ctor$3(renderIndex, this._itemSize));
                }
                builder.CloseRegion();
                this._lastRenderedItemCount = 0;
                if (this._loadedItems !== null && !this._loading && this._itemCount === 0 && this._emptyContent !== null)
                {
                    builder.AddContent$4(4, this._emptyContent);
                }
                else if (this._loadedItems !== null && this._itemTemplate !== null)
                {
                    /*var*/ let itemsToShow = $.$sl.System.Linq.Enumerable.Take(TItem, $.$sl.System.Linq.Enumerable.Skip(TItem, this._loadedItems, ((this._itemsBefore - this._loadedItemsStartIndex) | 0)), ((lastItemIndex - this._loadedItemsStartIndex) | 0));
                    builder.OpenRegion(5);
                    var $en3 = itemsToShow.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this._itemTemplate.Invoke(item).Invoke(builder);
                            this._lastRenderedItemCount++;
                        }
                    }
                    renderIndex += this._lastRenderedItemCount;
                    builder.CloseRegion();
                }
                this._lastRenderedPlaceholderCount = $.$$.System.Math.Max$4(0, ((((lastItemIndex - this._itemsBefore) | 0) - this._lastRenderedItemCount) | 0));
                builder.OpenRegion(6);
                for(; renderIndex < lastItemIndex; renderIndex++)
                {
                    builder.AddContent$5($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext, renderIndex, this._placeholder, new $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext().$ctor$3(renderIndex, this._itemSize));
                }
                builder.CloseRegion();
                /*var*/ let itemsAfter = $.$$.System.Math.Max$4(0, ((((this._itemCount - this._visibleItemCapacity) | 0) - this._itemsBefore) | 0));
                builder.OpenElement(7, this.SpacerElement);
                builder.AddAttribute$3(8, "aria-hidden", "true");
                builder.AddAttribute$3(9, "style", this.GetSpacerStyle(itemsAfter, this._unusedItemCapacity));
                builder.AddElementReferenceCapture(10, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*elementReference*/ elementReference) =>
                {
                    return this._spacerAfter = elementReference;
                }, {"r":65537,"p":[{"n":"elementReference","p":1900552}],"n":"","d":this.$h,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*string */ GetSpacerStyle(/*int*/ itemsInSpacer, /*int*/ numItemsGapAbove)
            {
                return numItemsGapAbove === 0 ? this.GetSpacerStyle$1(itemsInSpacer) : `height: ${$.$$.System.Single.ToString$1.call((itemsInSpacer * this._itemSize), $.$$.System.Globalization.CultureInfo.InvariantCulture)}px; flex-shrink: 0; transform: translateY(${$.$$.System.Single.ToString$1.call((numItemsGapAbove * this._itemSize), $.$$.System.Globalization.CultureInfo.InvariantCulture)}px);`;
            }
            /*string */ GetSpacerStyle$1(/*int*/ itemsInSpacer)
            {
                return `height: ${$.$$.System.Single.ToString$1.call((itemsInSpacer * this._itemSize), $.$$.System.Globalization.CultureInfo.InvariantCulture)}px; flex-shrink: 0;`;
            }
            /*void */ Microsoft$AspNetCore$Components$Web$Virtualization$IVirtualizeJsCallbacks$OnBeforeSpacerVisible(/*float*/ spacerSize, /*float*/ spacerSeparation, /*float*/ containerSize)
            {
                /*var*/ let itemsBefore;
                /*var*/ let visibleItemCapacity;
                /*var*/ let unusedItemCapacity;
                this.CalcualteItemDistribution(spacerSize, spacerSeparation, containerSize, $.$ref(() => itemsBefore, ($v) => itemsBefore = $v, $.$$.System.Int32), $.$ref(() => visibleItemCapacity, ($v) => visibleItemCapacity = $v, $.$$.System.Int32), $.$ref(() => unusedItemCapacity, ($v) => unusedItemCapacity = $v, $.$$.System.Int32));
                if (itemsBefore === this._itemsBefore && itemsBefore > 0)
                {
                    itemsBefore--;
                }
                this.UpdateItemDistribution(itemsBefore, visibleItemCapacity, unusedItemCapacity);
            }
            /*void */ Microsoft$AspNetCore$Components$Web$Virtualization$IVirtualizeJsCallbacks$OnAfterSpacerVisible(/*float*/ spacerSize, /*float*/ spacerSeparation, /*float*/ containerSize)
            {
                /*var*/ let itemsAfter;
                /*var*/ let visibleItemCapacity;
                /*var*/ let unusedItemCapacity;
                this.CalcualteItemDistribution(spacerSize, spacerSeparation, containerSize, $.$ref(() => itemsAfter, ($v) => itemsAfter = $v, $.$$.System.Int32), $.$ref(() => visibleItemCapacity, ($v) => visibleItemCapacity = $v, $.$$.System.Int32), $.$ref(() => unusedItemCapacity, ($v) => unusedItemCapacity = $v, $.$$.System.Int32));
                /*var*/ let itemsBefore = $.$$.System.Math.Max$4(0, ((((this._itemCount - itemsAfter) | 0) - visibleItemCapacity) | 0));
                if (itemsBefore === this._itemsBefore && itemsBefore < ((this._itemCount - visibleItemCapacity) | 0))
                {
                    itemsBefore++;
                }
                this.UpdateItemDistribution(itemsBefore, visibleItemCapacity, unusedItemCapacity);
            }
            /*void */ CalcualteItemDistribution(/*float*/ spacerSize, /*float*/ spacerSeparation, /*float*/ containerSize, /*out int*/ itemsInSpacer, /*out int*/ visibleItemCapacity, /*out int*/ unusedItemCapacity)
            {
                if (this._lastRenderedItemCount > 0)
                {
                    this._itemSize = (spacerSeparation - (this._lastRenderedPlaceholderCount * this._itemSize)) / this._lastRenderedItemCount;
                }
                if (this._itemSize <= 0)
                {
                    this._itemSize = this.ItemSize;
                }
                /*var*/ let maxItemCount = (() =>
                {
                    let $switch1 = $.$$.System.AppContext.GetData("Microsoft.AspNetCore.Components.Web.Virtualization.Virtualize.MaxItemCount");
                    {
                        let val;
                        if ((val = $switch1, $.$is(val, $.$$.System.Int32)))
                        {
                            return $.$$.System.Math.Min$4(val, this.MaxItemCount);
                        }
                    }
                    return this.MaxItemCount;
                })();
                maxItemCount += ((this.OverscanCount * 2) | 0);
                itemsInSpacer.$v = $.$$.System.Math.Max$4(0, (($.$cast(Math.floor(spacerSize / this._itemSize), $.$$.System.Int32) - this.OverscanCount) | 0));
                visibleItemCapacity.$v = (($.$cast(Math.ceil(containerSize / this._itemSize), $.$$.System.Int32) + ((2 * this.OverscanCount) | 0)) | 0);
                unusedItemCapacity.$v = $.$$.System.Math.Max$4(0, ((visibleItemCapacity.$v - maxItemCount) | 0));
                visibleItemCapacity.$v -= unusedItemCapacity.$v;
            }
            /*void */ UpdateItemDistribution(/*int*/ itemsBefore, /*int*/ visibleItemCapacity, /*int*/ unusedItemCapacity)
            {
                if (((itemsBefore + visibleItemCapacity) | 0) > this._itemCount)
                {
                    itemsBefore = $.$$.System.Math.Max$4(0, ((this._itemCount - visibleItemCapacity) | 0));
                }
                if (itemsBefore !== this._itemsBefore || visibleItemCapacity !== this._visibleItemCapacity || unusedItemCapacity !== this._unusedItemCapacity)
                {
                    this._itemsBefore = itemsBefore;
                    this._visibleItemCapacity = visibleItemCapacity;
                    this._unusedItemCapacity = unusedItemCapacity;
                    /*var*/ let refreshTask = this.RefreshDataCoreAsync(true);
                    if (!refreshTask.IsCompleted)
                    {
                        this.StateHasChanged();
                    }
                }
            }
            /*ValueTask *//*async*/  RefreshDataCoreAsync(/*bool*/ renderOnSuccess)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    this._refreshCts?.Cancel();
                    /*CancellationToken*/ let cancellationToken;
                    if (this._itemsProvider === new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate$$(TItem))().$ctor(this, this.DefaultItemsProvider))
                    {
                        this._refreshCts = null;
                        cancellationToken = $.$$.System.Threading.CancellationToken.None;
                    }
                    else 
                    {
                        this._refreshCts = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                        cancellationToken = this._refreshCts.Token;
                        this._loading = true;
                    }
                    /*var*/ let request = new $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderRequest().$ctor$3(this._itemsBefore, this._visibleItemCapacity, cancellationToken);
                    try
                    {
                        /*var*/ let result = await this._itemsProvider.Invoke(request);
                        if (!cancellationToken.IsCancellationRequested)
                        {
                            this._itemCount = result.TotalItemCount;
                            this._loadedItems = result.Items;
                            this._loadedItemsStartIndex = request.StartIndex;
                            this._loading = false;
                            if (renderOnSuccess)
                            {
                                this.StateHasChanged();
                            }
                        }
                    }
                    catch(e)
                    {
                        let oce;
                        if ($.$is(e, $.$$.System.OperationCanceledException, { set $v(v){ oce = v; } }) && $.$$.System.Threading.CancellationToken.op_Equality(oce.CancellationToken, cancellationToken))
                        {
                        }
                        else 
                        {
                            this._refreshException = e;
                            this.StateHasChanged();
                        }
                    }
                });
            }
            /*ValueTask<ItemsProviderResult<TItem>> */ DefaultItemsProvider(/*ItemsProviderRequest*/ request)
            {
                return $.$$.System.Threading.Tasks.ValueTask.FromResult($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$(TItem), new ($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$(TItem))().$ctor$3($.$sl.System.Linq.Enumerable.Take(TItem, $.$sl.System.Linq.Enumerable.Skip(TItem, this.Items, request.StartIndex), request.Count), this.Items.System$Collections$Generic$ICollection$$$Count));
            }
            /*RenderFragment */ DefaultPlaceholder(/*PlaceholderContext*/ context)
            {
                return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenElement(0, "div");
                    builder.AddAttribute$3(1, "style", `height: ${$.$$.System.Single.ToString$1.call(this._itemSize, $.$$.System.Globalization.CultureInfo.InvariantCulture)}px; flex-shrink: 0;`);
                    builder.CloseElement();
                }, {"r":65537,"p":[{"n":"builder","p":7536648}],"n":"","d":this.$h,"h":0,"f":17825794});
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    this._refreshCts?.Cancel();
                    if (this._jsInterop !== null)
                    {
                        await this._jsInterop.DisposeAsync();
                    }
                });
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._spacerBefore = $.$default($.$mac.Microsoft.AspNetCore.Components.ElementReference);
                this._spacerAfter = $.$default($.$mac.Microsoft.AspNetCore.Components.ElementReference);
                this._itemsProvider = null;
                this.JSRuntime = null;
                this.ItemSize = 50;
                this.OverscanCount = 3;
                this.SpacerElement = "div";
                this.MaxItemCount = 100;
            }
            static $h = 7798793;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1600000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1700000000n),"f":83886082},"n":"JSRuntime","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2097154,"a":[{"t":4259848,"c":21479096328}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":83886081},"n":"ChildContent","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":83886081},"n":"ItemContent","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2200000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2300000000n),"f":83886081},"n":"Placeholder","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":6881288,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2600000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2700000000n),"f":83886081},"n":"EmptyContent","d":this.$h,"h":Number(BigInt(this.$h)|0x2500000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1114113,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2A00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":83886081},"n":"ItemSize","d":this.$h,"h":Number(BigInt(this.$h)|0x2900000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2E00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2F00000000n),"f":83886081},"n":"ItemsProvider","d":this.$h,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$$.System.Collections.Generic.ICollection$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3200000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3300000000n),"f":83886081},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x3100000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3600000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3700000000n),"f":83886081},"n":"OverscanCount","d":this.$h,"h":Number(BigInt(this.$h)|0x3500000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3A00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3B00000000n),"f":83886081},"n":"SpacerElement","d":this.$h,"h":Number(BigInt(this.$h)|0x3900000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3E00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3F00000000n),"f":83886081},"n":"MaxItemCount","d":this.$h,"h":Number(BigInt(this.$h)|0x3D00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":133169153,"n":"RefreshDataAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x4000000000n),"f":16781313},{"r":65537,"n":"OnParametersSet","d":this.$h,"h":Number(BigInt(this.$h)|0x4100000000n),"f":16809988},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x4200000000n),"f":16814084},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0x4300000000n),"f":16809988},{"r":1310721,"p":[{"n":"itemsInSpacer","p":655361},{"n":"numItemsGapAbove","p":655361}],"n":"GetSpacerStyle","d":this.$h,"h":Number(BigInt(this.$h)|0x4400000000n),"f":16777218},{"r":1310721,"p":[{"n":"itemsInSpacer","p":655361}],"n":"GetSpacerStyle","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x4500000000n),"f":16777218},{"r":65537,"p":[{"n":"spacerSize","p":1114113},{"n":"spacerSeparation","p":1114113},{"n":"containerSize","p":1114113},{"n":"itemsInSpacer","p":655361,"f":2},{"n":"visibleItemCapacity","p":655361,"f":2},{"n":"unusedItemCapacity","p":655361,"f":2}],"n":"CalcualteItemDistribution","d":this.$h,"h":Number(BigInt(this.$h)|0x4800000000n),"f":16777218},{"r":65537,"p":[{"n":"itemsBefore","p":655361},{"n":"visibleItemCapacity","p":655361},{"n":"unusedItemCapacity","p":655361}],"n":"UpdateItemDistribution","d":this.$h,"h":Number(BigInt(this.$h)|0x4900000000n),"f":16777218},{"r":135987201,"p":[{"n":"renderOnSuccess","p":262145}],"n":"RefreshDataCoreAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x4A00000000n),"f":16781314},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$(TItem)).$h,"p":[{"n":"request","p":7536649}],"n":"DefaultItemsProvider","d":this.$h,"h":Number(BigInt(this.$h)|0x4B00000000n),"f":16777218},{"r":6881288,"p":[{"n":"context","p":7733257}],"n":"DefaultPlaceholder","d":this.$h,"h":Number(BigInt(this.$h)|0x4C00000000n),"f":16777218},{"r":135987201,"n":"DisposeAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x4D00000000n),"f":16781313}],"l":[{"t":7864329,"n":"_jsInterop","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":1900552,"n":"_spacerBefore","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":1900552,"n":"_spacerAfter","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":655361,"n":"_itemsBefore","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":655361,"n":"_visibleItemCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":655361,"n":"_unusedItemCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":655361,"n":"_itemCount","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194306},{"t":655361,"n":"_loadedItemsStartIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4194306},{"t":655361,"n":"_lastRenderedItemCount","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":4194306},{"t":655361,"n":"_lastRenderedPlaceholderCount","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":4194306},{"t":1114113,"n":"_itemSize","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.IEnumerable$$(TItem).$h,"n":"_loadedItems","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":4194306},{"t":125960193,"n":"_refreshCts","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":4194306},{"t":47251457,"n":"_refreshException","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":4194306},{"t":$.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate$$(TItem).$h,"n":"_itemsProvider","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":4194306},{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$(TItem).$h,"n":"_itemTemplate","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":4194306},{"t":$.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.PlaceholderContext).$h,"n":"_placeholder","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":4194306},{"t":6881288,"n":"_emptyContent","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":4194306},{"t":262145,"n":"_loading","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x4E00000000n),"f":16777217}],"i":[2752520,3145736,3080200,7667721,56950785],"g":[TItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.IVirtualizeJsCallbacks, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `Virtualize<${TItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.SupplyParameterFromFormAttribute", ($self) => class SupplyParameterFromFormAttribute extends $.$mac.Microsoft.AspNetCore.Components.CascadingParameterAttributeBase
        {
            /*string?*/ Name = null;
            /*string?*/ FormName = null;
            /*bool */ get SingleDelivery()
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 4521993;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589832,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12889423881,"f":50331649},"s":{"r":0,"d":0,"h":17184391177,"f":83886081},"n":"Name","d":4521993,"h":8594456585,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30069293065,"f":50331649},"s":{"r":0,"d":0,"h":34364260361,"f":83886081},"n":"FormName","d":4521993,"h":25774325769,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42954194953,"f":50364424},"n":"SingleDelivery","d":4521993,"h":38659227657,"f":2129928}],"c":[{"n":".ctor","o":"$ctor$3","d":4521993,"h":47249162249,"f":16777217}],"h":4521993,"a":[{"t":14745601,"c":21489582081,"a":[{"v":128,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.CascadingParameterAttributeBase; }
            static get $fullName() { return `SupplyParameterFromFormAttribute`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate<>", (TItem) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderDelegate<>", [TItem], ($self) => class ItemsProviderDelegate$$ extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*ValueTask<ItemsProviderResult<TItem>>*/ Invoke(/**/ request)
            {
                return this.$nativeFunction.call(this.$target, request);
            }
            static $h = 7471113;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$(TItem)).$h,"p":[{"n":"request","p":7536649}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777345},{"r":57016321,"p":[{"n":"request","p":7536649},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$macw.Microsoft.AspNetCore.Components.Web.Virtualization.ItemsProviderResult$$(TItem)).$h,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[57212929,113246209],"g":[TItem?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `ItemsProviderDelegate<${TItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.BrowserFileStream", ($self) => class BrowserFileStream extends $.$$.System.IO.Stream
        {
            /*long*/ _position = 0n;
            /*IJSRuntime*/ _jsRuntime = null;
            /*ElementReference*/ _inputFileElement;
            /*BrowserFile*/ _file = null;
            /*long*/ _maxAllowedSize = 0n;
            /*CancellationTokenSource*/ _openReadStreamCts = null;
            /*Task<Stream>*/ OpenReadStreamTask = null;
            /*IJSStreamReference?*/ _jsStreamReference = null;
            /*bool*/ _isDisposed = false;
            /*CancellationTokenSource?*/ _copyFileDataCts = null;
            $ctor$3(/*IJSRuntime*/ jsRuntime, /*ElementReference*/ inputFileElement, /*BrowserFile*/ file, /*long*/ maxAllowedSize, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$2();
                {
                    this._jsRuntime = jsRuntime;
                    this._inputFileElement = inputFileElement;
                    this._file = file;
                    this._maxAllowedSize = maxAllowedSize;
                    this._openReadStreamCts = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$2(cancellationToken);
                    this.OpenReadStreamTask = this.OpenReadStreamAsync(this._openReadStreamCts.Token);
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                return this._file.Size;
            }
            /*long */ get Position()
            {
                return this._position;
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12("Synchronous reads are not supported.");
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsync$2(new ($.$$.System.Memory$$($.$$.System.Byte))().$ctor$5(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    /*var*/ let bytesAvailableToRead = this.Length - this.Position;
                    /*var*/ let maxBytesToRead = $.$cast($.$$.System.Math.Min$5(bytesAvailableToRead, BigInt(buffer.Length)), $.$$.System.Int32);
                    if (maxBytesToRead <= 0)
                    {
                        return 0;
                    }
                    /*var*/ let bytesRead = await this.CopyFileDataIntoBuffer(buffer.Slice(0, maxBytesToRead), cancellationToken);
                    this._position += BigInt(bytesRead);
                    return bytesRead;
                });
            }
            /*Task<Stream> *//*async*/  OpenReadStreamAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream), $.$$.System.IO.Stream, async () => 
                {
                    this._jsStreamReference = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync$1($.$mj.Microsoft.JSInterop.IJSStreamReference, this._jsRuntime, "Blazor._internal.InputFile.readFileData"/*InputFileInterop.ReadFileData*/, cancellationToken, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._inputFileElement, $.$box(this._file.Id, $.$$.System.Int32) ], null, null));
                    return await this._jsStreamReference.Microsoft$JSInterop$IJSStreamReference$OpenReadStreamAsync(512000n, cancellationToken);
                });
            }
            /*ValueTask<int> *//*async*/  CopyFileDataIntoBuffer(/*Memory<byte>*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    /*var*/ let stream = await this.OpenReadStreamTask;
                    this._copyFileDataCts = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$2(cancellationToken);
                    return await stream.ReadAsync$2(destination, this._copyFileDataCts.Token);
                });
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (this._isDisposed)
                {
                    return;
                }
                this._openReadStreamCts.Cancel();
                this._copyFileDataCts?.Cancel();
                try
                {
                    _ = (this._jsStreamReference?.System$IAsyncDisposable$DisposeAsync().Preserve() ?? null);
                }
                catch($e)
                {
                }
                this._isDisposed = true;
                super.Dispose$1(disposing);
            }
            //default member initializer
            constructor()
            {
                super();
                this._inputFileElement = $.$default($.$mac.Microsoft.AspNetCore.Components.ElementReference);
            }
            static $h = 655369;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":55835230217,"f":50364417},"n":"CanRead","d":655369,"h":51540262921,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":64425164809,"f":50364417},"n":"CanSeek","d":655369,"h":60130197513,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":73015099401,"f":50364417},"n":"CanWrite","d":655369,"h":68720132105,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":81605033993,"f":50364417},"n":"Length","d":655369,"h":77310066697,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":90194968585,"f":50364417},"s":{"r":0,"d":0,"h":94489935881,"f":83918849},"n":"Position","d":655369,"h":85900001289,"f":2129921}],"m":[{"r":65537,"n":"Flush","d":655369,"h":98784903177,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":655369,"h":103079870473,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":655369,"h":107374837769,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":655369,"h":111669805065,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":655369,"h":115964772361,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":655369,"h":120259739657,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":655369,"h":124554706953,"f":16814081},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"OpenReadStreamAsync","d":655369,"h":128849674249,"f":16781314},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"destination","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"CopyFileDataIntoBuffer","d":655369,"h":133144641545,"f":16781314},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":655369,"h":137439608841,"f":16809988}],"l":[{"t":917505,"n":"_position","d":655369,"h":4295622665,"f":4194306},{"t":524318,"n":"_jsRuntime","d":655369,"h":8590589961,"f":4194306},{"t":1900552,"n":"_inputFileElement","d":655369,"h":12885557257,"f":4194306},{"t":524297,"n":"_file","d":655369,"h":17180524553,"f":4194306},{"t":917505,"n":"_maxAllowedSize","d":655369,"h":21475491849,"f":4194306},{"t":125960193,"n":"_openReadStreamCts","d":655369,"h":25770459145,"f":4194306},{"t":$.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h,"n":"OpenReadStreamTask","d":655369,"h":30065426441,"f":4194306},{"t":589854,"n":"_jsStreamReference","d":655369,"h":34360393737,"f":4194306},{"t":262145,"n":"_isDisposed","d":655369,"h":38655361033,"f":4194306},{"t":125960193,"n":"_copyFileDataCts","d":655369,"h":42950328329,"f":4194306}],"c":[{"p":[{"n":"jsRuntime","p":524318},{"n":"inputFileElement","p":1900552},{"n":"file","p":524297},{"n":"maxAllowedSize","p":917505},{"n":"cancellationToken","p":125829121}],"n":".ctor","o":"$ctor$3","d":655369,"h":47245295625,"f":16777217}],"i":[57540609,56950785],"h":655369}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `BrowserFileStream`; }
        });
        
        $asm.$str("$macw.Microsoft.AspNetCore.Components.Forms.InputDateType", ($self) => class InputDateType extends $.$$.System.Enum
        {
            static Date = 0;
            static DateTimeLocal = 1;
            static Month = 2;
            static Time = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Date": 0n,
                    "DateTimeLocal": 1n,
                    "Month": 2n,
                    "Time": 3n
                };
            }
            static $h = 1769481;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1769481,"n":"Date","d":1769481,"h":4296736777,"f":4194337},{"t":1769481,"n":"DateTimeLocal","d":1769481,"h":8591704073,"f":4194337},{"t":1769481,"n":"Month","d":1769481,"h":12886671369,"f":4194337},{"t":1769481,"n":"Time","d":1769481,"h":17181638665,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1769481,"h":21476605961,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1769481}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `InputDateType`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputSelect<>", (TValue) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.InputSelect<>", [TValue], ($self) => class InputSelect$$ extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue)
        {
            /*bool*/ _isMultipleSelect = false;
            $ctor$3()
            {
                super.$ctor$2();
                {
                    this._isMultipleSelect = TValue.$type.IsArray;
                }
                return this;
            }
            /*RenderFragment?*/ ChildContent = null;
            /*ElementReference?*/ Element = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "select");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 2, "name", this.NameAttributeValue);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 3, "class", this.CssClass);
                builder.AddAttribute(4, "multiple", this._isMultipleSelect);
                if (this._isMultipleSelect)
                {
                    const $t1 = () => $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$31(TValue, this.CurrentValue, null);
                    builder.AddAttribute$3(5, "value", $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t)));
                    builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 6, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$typeArray($.$$.System.String), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$typeArray($.$$.System.String)))().$ctor(this, this.SetCurrentValueAsStringArray), null, null));
                    builder.SetUpdatesAttributeName("value");
                }
                else 
                {
                    builder.AddAttribute$3(7, "value", this.CurrentValueAsString);
                    builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 8, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.String, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.CurrentValueAsString = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":this.$h,"h":0,"f":17825794}), null, null));
                    builder.SetUpdatesAttributeName("value");
                }
                builder.AddElementReferenceCapture(9, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*__selectReference*/ __selectReference) =>
                {
                    return this.Element = __selectReference;
                }, {"r":65537,"p":[{"n":"__selectReference","p":1900552}],"n":"","d":this.$h,"h":0,"f":17825794}));
                builder.AddContent$4(10, this.ChildContent);
                builder.CloseElement();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out TValue*/ result, /*out string?*/ validationErrorMessage)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Forms.InputExtensions.TryParseSelectableValueFromString(TValue, this, value, result, validationErrorMessage);
            }
            /*string? */ FormatValueAsString(/*TValue?*/ value)
            {
                if ($.$$.System.Type.op_Equality$1(TValue.$type, $.$$.System.Boolean.$type))
                {
                    return $.$cast($.$box(value, TValue), $.$$.System.Boolean) ? "true" : "false";
                }
                else if ($.$$.System.Type.op_Equality$1(TValue.$type, $.$typeNullable($.$$.System.Boolean).$type))
                {
                    return !(value === null) && $.$cast($.$box(value, TValue), $.$$.System.Boolean) ? "true" : "false";
                }
                return super.FormatValueAsString(value);
            }
            /*void */ SetCurrentValueAsStringArray(/*string?[]?*/ value)
            {
                /*var*/ let result;
                this.CurrentValue = $.$mac.Microsoft.AspNetCore.Components.BindConverter.TryConvertTo(TValue, value, $.$$.System.Globalization.CultureInfo.CurrentCulture, $.$ref(() => result, ($v) => result = $v, TValue)) ? result : $.$default(TValue);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Element = null;
            }
            static $h = 2490377;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":6881288,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":83886081},"n":"ChildContent","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":83886084},"n":"Element","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":TValue?.$h??1507328,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16809988},{"r":1310721,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"FormatValueAsString","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16809988},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.String).$h}],"n":"SetCurrentValueAsStringArray","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777218}],"l":[{"t":262145,"n":"_isMultipleSelect","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"i":[2752520,3145736,3080200,57540609],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputSelect<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputNumber<>", (TValue) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.InputNumber<>", [TValue], ($self) => class InputNumber$$ extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue)
        {
            /*string*/ static _stepAttributeValue = null;
            static /*string */ GetStepAttributeValue()
            {
                /*var*/ let targetType = $.$$.System.Nullable.GetUnderlyingType(TValue.$type) ?? TValue.$type;
                if ($.$$.System.Type.op_Equality$1(targetType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(targetType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(targetType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(targetType, $.$$.System.Single.$type) || $.$$.System.Type.op_Equality$1(targetType, $.$$.System.Double.$type) || $.$$.System.Type.op_Equality$1(targetType, $.$$.System.Decimal.$type))
                {
                    return "any";
                }
                else 
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`The type '${$.$$.System.Type.ToString.call(targetType)}' is not a supported numeric type.`);
                }
            }
            /*string*/ ParsingErrorMessage = null;
            /*ElementReference?*/ Element = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "input");
                builder.AddAttribute$3(1, "step", $.$macw.Microsoft.AspNetCore.Components.Forms.InputNumber$$(TValue)._stepAttributeValue);
                builder.AddAttribute$3(2, "type", "number");
                builder.AddMultipleAttributes(3, this.AdditionalAttributes);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 4, "name", this.NameAttributeValue);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 5, "class", this.CssClass);
                builder.AddAttribute$3(6, "value", this.CurrentValueAsString);
                builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 7, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.String, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.CurrentValueAsString = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":this.$h,"h":0,"f":17825794}), this.CurrentValueAsString, null));
                builder.SetUpdatesAttributeName("value");
                builder.AddElementReferenceCapture(8, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/**/ __inputReference) =>
                {
                    return this.Element = __inputReference;
                }, {"r":65537,"p":[{"n":"__inputReference","p":1900552}],"n":"","d":this.$h,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out TValue*/ result, /*out string?*/ validationErrorMessage)
            {
                if ($.$mac.Microsoft.AspNetCore.Components.BindConverter.TryConvertTo(TValue, value, $.$$.System.Globalization.CultureInfo.InvariantCulture, result))
                {
                    validationErrorMessage.$v = null;
                    return true;
                }
                else 
                {
                    validationErrorMessage.$v = $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, this.ParsingErrorMessage, this.DisplayName ?? this.FieldIdentifier.FieldName);
                    return false;
                }
            }
            /*string? */ FormatValueAsString(/*TValue?*/ value)
            {
                //switch (value)
                {
                    let int;
                    let long;
                    let short;
                    let float;
                    let double;
                    let decimal;
                    $switchJumpStart1: 
                    //case null:
                    if (value == null)
                    {
                        return null;
                    }
                    //case int @int:
                    else if ($.$is(value, $.$$.System.Int32, { set $v(v){ int = v; } }))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$10(int, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    //case long @long:
                    else if ($.$is(value, $.$$.System.Int64, { set $v(v){ long = v; } }))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$11(long, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    //case short @short:
                    else if ($.$is(value, $.$$.System.Int16, { set $v(v){ short = v; } }))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$9(short, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    //case float @float:
                    else if ($.$is(value, $.$$.System.Single, { set $v(v){ float = v; } }))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$27(float, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    //case double @double:
                    else if ($.$is(value, $.$$.System.Double, { set $v(v){ double = v; } }))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$8(double, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    //case decimal @decimal:
                    else if ($.$is(value, $.$$.System.Decimal, { set $v(v){ decimal = v; } }))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$7(decimal, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    //default
                    else
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Unsupported type ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(value))}`);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ParsingErrorMessage = "The {0} field must be a number.";
                this.Element = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._stepAttributeValue = $.$macw.Microsoft.AspNetCore.Components.Forms.InputNumber$$(TValue).GetStepAttributeValue();
                }
            }
            static $h = 2228233;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":83886081},"n":"ParsingErrorMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":83886084},"n":"Element","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2097153}],"m":[{"r":1310721,"n":"GetStepAttributeValue","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777250},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":TValue?.$h??1507328,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16809988},{"r":1310721,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"FormatValueAsString","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16809988}],"l":[{"t":1310721,"n":"_stepAttributeValue","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777217}],"i":[2752520,3145736,3080200,57540609],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputNumber<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputDate<>", (TValue) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.InputDate<>", [TValue], ($self) => class InputDate$$ extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue)
        {
            /*string*/ static DateFormat = null;
            /*string*/ static DateTimeLocalFormat = null;
            /*string*/ static MonthFormat = null;
            /*string*/ static TimeFormat = null;
            /*string*/ _typeAttributeValue = null;
            /*string*/ _format = null;
            /*string*/ _parsingErrorMessage = null;
            /*InputDateType*/ Type = 0;
            /*string*/ ParsingErrorMessage = null;
            /*ElementReference?*/ Element = null;
            $ctor$3()
            {
                super.$ctor$2();
                {
                    /*var*/ let type = $.$$.System.Nullable.GetUnderlyingType(TValue.$type) ?? TValue.$type;
                    if ($.$$.System.Type.op_Inequality$1(type, $.$$.System.DateTime.$type) && $.$$.System.Type.op_Inequality$1(type, $.$$.System.DateTimeOffset.$type) && $.$$.System.Type.op_Inequality$1(type, $.$$.System.DateOnly.$type) && $.$$.System.Type.op_Inequality$1(type, $.$$.System.TimeOnly.$type))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Unsupported ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))} type param '${$.$$.System.Type.ToString.call(type)}'.`);
                    }
                }
                return this;
            }
            /*void */ OnParametersSet()
            {
                /*var*/ let formatDescription;
        $.$tupleUnpack(($tp) =>
                {
                    this._typeAttributeValue = $tp.Item1;
                    this._format = $tp.Item2;
                    formatDescription = $tp.Item3;
                }).$v = (() =>
                {
                    if (this.Type === 0/*InputDateType.Date*/)
                    {
                        return new ($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3("date", "yyyy-MM-dd"/*DateFormat*/, "date");
                    }
                    if (this.Type === 1/*InputDateType.DateTimeLocal*/)
                    {
                        return new ($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3("datetime-local", "yyyy-MM-ddTHH:mm:ss"/*DateTimeLocalFormat*/, "date and time");
                    }
                    if (this.Type === 2/*InputDateType.Month*/)
                    {
                        return new ($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3("month", "yyyy-MM"/*MonthFormat*/, "year and month");
                    }
                    if (this.Type === 3/*InputDateType.Time*/)
                    {
                        return new ($.$$.System.ValueTuple$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3("time", "HH:mm:ss"/*TimeFormat*/, "time");
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Unsupported ${"InputDateType"} '${this.Type}'.`);
                })();
                this._parsingErrorMessage = $.$$.System.String.IsNullOrEmpty(this.ParsingErrorMessage) ? `The {{0}} field must be a ${formatDescription}.` : this.ParsingErrorMessage;
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "input");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                builder.AddAttribute$3(2, "type", this._typeAttributeValue);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 3, "name", this.NameAttributeValue);
                builder.AddAttribute$3(4, "class", this.CssClass);
                builder.AddAttribute$3(5, "value", this.CurrentValueAsString);
                builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 6, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.String, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.String))().$ctor(this,  (/**/ __value) =>
                {
                    return this.CurrentValueAsString = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":this.$h,"h":0,"f":17825794}), this.CurrentValueAsString, null));
                builder.SetUpdatesAttributeName("value");
                builder.AddElementReferenceCapture(7, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*__inputReference*/ __inputReference) =>
                {
                    return this.Element = __inputReference;
                }, {"r":65537,"p":[{"n":"__inputReference","p":1900552}],"n":"","d":this.$h,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*string */ FormatValueAsString(/*TValue?*/ value)
            {
                return (() =>
                {
                    {
                        let dateTimeValue;
                        if ((dateTimeValue = value, $.$is(dateTimeValue, $.$$.System.DateTime)))
                        {
                            return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$4(dateTimeValue, this._format, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    {
                        let dateTimeOffsetValue;
                        if ((dateTimeOffsetValue = value, $.$is(dateTimeOffsetValue, $.$$.System.DateTimeOffset)))
                        {
                            return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$6(dateTimeOffsetValue, this._format, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    {
                        let dateOnlyValue;
                        if ((dateOnlyValue = value, $.$is(dateOnlyValue, $.$$.System.DateOnly)))
                        {
                            return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$2(dateOnlyValue, this._format, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    {
                        let timeOnlyValue;
                        if ((timeOnlyValue = value, $.$is(timeOnlyValue, $.$$.System.TimeOnly)))
                        {
                            return $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$30(timeOnlyValue, this._format, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    return $.$$.System.String.Empty;
                })();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out TValue*/ result, /*out string?*/ validationErrorMessage)
            {
                if ($.$mac.Microsoft.AspNetCore.Components.BindConverter.TryConvertTo(TValue, value, $.$$.System.Globalization.CultureInfo.InvariantCulture, result))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$box(result, TValue).$v !== null, "result != null");
                    validationErrorMessage.$v = null;
                    return true;
                }
                else 
                {
                    validationErrorMessage.$v = $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, this._parsingErrorMessage, this.DisplayName ?? this.FieldIdentifier.FieldName);
                    return false;
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._typeAttributeValue = null;
                this._format = null;
                this._parsingErrorMessage = null;
                this.Type = 0;
                this.ParsingErrorMessage = $.$$.System.String.Empty;
                this.Element = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DateFormat = "yyyy-MM-dd";
                }
                {
                    this.DateTimeLocalFormat = "yyyy-MM-ddTHH:mm:ss";
                }
                {
                    this.MonthFormat = "yyyy-MM";
                }
                {
                    this.TimeFormat = "HH:mm:ss";
                }
            }
            static $h = 1703945;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1769481,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":83886081},"n":"Type","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":83886081},"n":"ParsingErrorMessage","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1200000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":83886084},"n":"Element","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2097153}],"m":[{"r":65537,"n":"OnParametersSet","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16809988},{"r":1310721,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"FormatValueAsString","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":TValue?.$h??1507328,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16809988}],"l":[{"t":1310721,"n":"DateFormat","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338},{"t":1310721,"n":"DateTimeLocalFormat","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194338},{"t":1310721,"n":"MonthFormat","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194338},{"t":1310721,"n":"TimeFormat","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194338},{"t":1310721,"n":"_typeAttributeValue","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":1310721,"n":"_format","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":1310721,"n":"_parsingErrorMessage","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217}],"i":[2752520,3145736,3080200,57540609],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputDate<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ErrorBoundary", ($self) => class ErrorBoundary extends $.$mac.Microsoft.AspNetCore.Components.ErrorBoundaryBase
        {
            /*IErrorBoundaryLogger?*/ ErrorBoundaryLogger = null;
            /*Task *//*async*/  OnErrorAsync(/*Exception*/ exception)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.ErrorBoundaryLogger.Microsoft$AspNetCore$Components$Web$IErrorBoundaryLogger$LogErrorAsync(exception);
                });
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                if (this.CurrentException === null)
                {
                    builder.AddContent$4(0, this.ChildContent);
                }
                else if (!(this.ErrorContent === null))
                {
                    builder.AddContent$4(1, this.ErrorContent.Invoke(this.CurrentException));
                }
                else 
                {
                    builder.OpenElement(2, "div");
                    builder.AddAttribute$3(3, "class", "blazor-error-boundary");
                    builder.CloseElement();
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5111817;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2031624,"p":[{"p":5767177,"g":{"r":0,"d":0,"h":12890013705,"f":50331650},"s":{"r":0,"d":0,"h":17184981001,"f":83886082},"n":"ErrorBoundaryLogger","d":5111817,"h":8595046409,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":133169153,"p":[{"n":"exception","p":47251457}],"n":"OnErrorAsync","d":5111817,"h":21479948297,"f":16814084},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":5111817,"h":25774915593,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":5111817,"h":30069882889,"f":16777217}],"i":[2752520,3145736,3080200,2949128],"h":5111817}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ErrorBoundaryBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$mac.Microsoft.AspNetCore.Components.IErrorBoundary ]; }
            static get $fullName() { return `ErrorBoundary`; }
        });
        
        $asm.$str("$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch", ($self) => class NavLinkMatch extends $.$$.System.Enum
        {
            static Prefix = 0;
            static All = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Prefix": 0n,
                    "All": 1n
                };
            }
            static $h = 4456457;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4456457,"n":"Prefix","d":4456457,"h":4299423753,"f":4194337},{"t":4456457,"n":"All","d":4456457,"h":8594391049,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4456457,"h":12889358345,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4456457}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `NavLinkMatch`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputRadioGroup<>", (TValue) => $asm.$gt("$macw.Microsoft.AspNetCore.Components.Forms.InputRadioGroup<>", [TValue], ($self) => class InputRadioGroup$$ extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue)
        {
            /*string*/ _defaultGroupName = null;
            /*InputRadioContext?*/ _context = null;
            /*RenderFragment?*/ ChildContent = null;
            /*string?*/ Name = null;
            /*InputRadioContext?*/ CascadedContext = null;
            /*object? */ get Microsoft$AspNetCore$Components$IInputRadioValueProvider$CurrentValue()
            {
                return $.$box(this.CurrentValue, TValue);
            }
            /*void */ OnParametersSet()
            {
                if (this._context === null)
                {
                    /*var*/ let changeEventCallback = $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.String, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.CurrentValueAsString = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":this.$h,"h":0,"f":17825794}), this.CurrentValueAsString, null);
                    this._context = new $.$macw.Microsoft.AspNetCore.Components.Forms.InputRadioContext().$ctor$1(this, this.CascadedContext, changeEventCallback);
                }
                else if (this._context.ParentContext !== this.CascadedContext)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("An InputRadioGroup cannot change context after creation");
                }
                if (!$.$$.System.String.IsNullOrEmpty(this.Name))
                {
                    this._context.GroupName = this.Name;
                }
                else if (!$.$$.System.String.IsNullOrEmpty(this.NameAttributeValue))
                {
                    this._context.GroupName = this.NameAttributeValue;
                }
                else 
                {
                    this._context.GroupName = this._defaultGroupName;
                }
                /*Microsoft.AspNetCore.Components.Forms.EditContext*/ let __ca1__;
                this._context.FieldClass = ((__ca1__ = this.EditContext) !== null ? $.$macw.Microsoft.AspNetCore.Components.Forms.EditContextFieldClassExtensions.FieldCssClass(__ca1__, $.$ref(() => this.FieldIdentifier, )) : null);
            }
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._context !== null, "_context != null");
                builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.CascadingValue$$($.$macw.Microsoft.AspNetCore.Components.Forms.InputRadioContext), 0);
                builder.AddComponentParameter(2, "Value", this._context);
                builder.AddComponentParameter(3, "ChildContent", this.ChildContent);
                builder.CloseComponent();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out TValue*/ result, /*out string?*/ validationErrorMessage)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Forms.InputExtensions.TryParseSelectableValueFromString(TValue, this, value, result, validationErrorMessage);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._defaultGroupName = $.$$.System.Guid.NewGuid().ToString$2("N");
            }
            static $h = 2424841;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":6881288,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":83886081},"n":"ChildContent","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":83886081},"n":"Name","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2097153,"a":[{"t":5636104,"c":21480472584}]},{"p":2359305,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":83886082},"n":"CascadedContext","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097154,"a":[{"t":524296,"c":21475360776}]},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331650},"n":"{3604489}.CurrentValue","o":"Microsoft$AspNetCore$Components$IInputRadioValueProvider$CurrentValue","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097154}],"m":[{"r":65537,"n":"OnParametersSet","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16809988},{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":TValue?.$h??1507328,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16809988}],"l":[{"t":1310721,"n":"_defaultGroupName","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":2359305,"n":"_context","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217}],"i":[2752520,3145736,3080200,57540609,3604489],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$(TValue); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable, $.$macw.Microsoft.AspNetCore.Components.IInputRadioValueProvider ]; }
            static get $fullName() { return `InputRadioGroup<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputCheckbox", ($self) => class InputCheckbox extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.Boolean)
        {
            /*ElementReference?*/ Element = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "input");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                builder.AddAttribute$3(2, "type", "checkbox");
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 3, "name", this.NameAttributeValue);
                builder.AddAttribute$3(4, "class", this.CssClass);
                builder.AddAttribute(5, "checked", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.CurrentValue, null));
                builder.AddAttribute$3(6, "value", $.$$.System.Boolean.TrueString);
                builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 7, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.Boolean, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.Boolean))().$ctor(this,  (/**/ __value) =>
                {
                    return this.CurrentValue = __value;
                }, {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":1638409,"h":0,"f":17825794}), this.CurrentValue, null));
                builder.SetUpdatesAttributeName("checked");
                builder.AddElementReferenceCapture(8, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/**/ __inputReference) =>
                {
                    return this.Element = __inputReference;
                }, {"r":65537,"p":[{"n":"__inputReference","p":1900552}],"n":"","d":1638409,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out bool*/ result, /*out string?*/ validationErrorMessage)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12(`This component does not parse string inputs. Bind to the '${"CurrentValue"}' property, not '${"CurrentValueAsString"}'.`);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Element = null;
            }
            static $h = 1638409;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":12886540297,"f":50331649},"s":{"r":0,"d":0,"h":17181507593,"f":83886084},"n":"Element","d":1638409,"h":8591573001,"f":2097153}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":1638409,"h":21476474889,"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":262145,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":1638409,"h":25771442185,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":1638409,"h":30066409481,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":1638409}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.Boolean); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputCheckbox`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputHidden", ($self) => class InputHidden extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.String)
        {
            /*ElementReference?*/ Element = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "input");
                builder.AddAttribute$3(1, "type", "hidden");
                builder.AddMultipleAttributes(2, this.AdditionalAttributes);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 3, "name", this.NameAttributeValue);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 4, "class", this.CssClass);
                builder.AddAttribute$3(5, "value", this.CurrentValueAsString);
                builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 6, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.String, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.CurrentValueAsString = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2162697,"h":0,"f":17825794}), this.CurrentValueAsString, null));
                builder.SetUpdatesAttributeName("value");
                builder.AddElementReferenceCapture(7, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*__inputReference*/ __inputReference) =>
                {
                    return this.Element = __inputReference;
                }, {"r":65537,"p":[{"n":"__inputReference","p":1900552}],"n":"","d":2162697,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out string?*/ result, /*out string?*/ validationErrorMessage)
            {
                result.$v = value;
                validationErrorMessage.$v = null;
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Element = null;
            }
            static $h = 2162697;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":12887064585,"f":50331649},"s":{"r":0,"d":0,"h":17182031881,"f":83886084},"n":"Element","d":2162697,"h":8592097289,"f":2097153}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":2162697,"h":21476999177,"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":1310721,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":2162697,"h":25771966473,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":2162697,"h":30066933769,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":2162697}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.String); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputHidden`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputTextArea", ($self) => class InputTextArea extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.String)
        {
            /*ElementReference?*/ Element = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "textarea");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 2, "name", this.NameAttributeValue);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 3, "class", this.CssClass);
                builder.AddAttribute$3(4, "value", this.CurrentValueAsString);
                builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 5, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.String, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.CurrentValueAsString = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2621449,"h":0,"f":17825794}), this.CurrentValueAsString, null));
                builder.SetUpdatesAttributeName("value");
                builder.AddElementReferenceCapture(6, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/**/ __inputReference) =>
                {
                    return this.Element = __inputReference;
                }, {"r":65537,"p":[{"n":"__inputReference","p":1900552}],"n":"","d":2621449,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out string?*/ result, /*out string?*/ validationErrorMessage)
            {
                result.$v = value;
                validationErrorMessage.$v = null;
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Element = null;
            }
            static $h = 2621449;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":12887523337,"f":50331649},"s":{"r":0,"d":0,"h":17182490633,"f":83886084},"n":"Element","d":2621449,"h":8592556041,"f":2097153}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":2621449,"h":21477457929,"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":1310721,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":2621449,"h":25772425225,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":2621449,"h":30067392521,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":2621449}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.String); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputTextArea`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputText", ($self) => class InputText extends $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.String)
        {
            /*ElementReference?*/ Element = null;
            /*void */ BuildRenderTree(/*RenderTreeBuilder*/ builder)
            {
                builder.OpenElement(0, "input");
                builder.AddMultipleAttributes(1, this.AdditionalAttributes);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 2, "name", this.NameAttributeValue);
                $.$macw.Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilderExtensions.AddAttributeIfNotNullOrEmpty(builder, 3, "class", this.CssClass);
                builder.AddAttribute$3(4, "value", this.CurrentValueAsString);
                builder.AddAttribute$7($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 5, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$$.System.String, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$$.System.Action$$($.$$.System.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.CurrentValueAsString = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":2555913,"h":0,"f":17825794}), this.CurrentValueAsString, null));
                builder.SetUpdatesAttributeName("value");
                builder.AddElementReferenceCapture(6, new ($.$$.System.Action$$($.$mac.Microsoft.AspNetCore.Components.ElementReference))().$ctor(this,  (/*__inputReference*/ __inputReference) =>
                {
                    return this.Element = __inputReference;
                }, {"r":65537,"p":[{"n":"__inputReference","p":1900552}],"n":"","d":2555913,"h":0,"f":17825794}));
                builder.CloseElement();
            }
            /*bool */ TryParseValueFromString(/*string?*/ value, /*out string?*/ result, /*out string?*/ validationErrorMessage)
            {
                result.$v = value;
                validationErrorMessage.$v = null;
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Element = null;
            }
            static $h = 2555913;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$typeNullable($.$mac.Microsoft.AspNetCore.Components.ElementReference).$h,"g":{"r":0,"d":0,"h":12887457801,"f":50331649},"s":{"r":0,"d":0,"h":17182425097,"f":83886084},"n":"Element","d":2555913,"h":8592490505,"f":2097153}],"m":[{"r":65537,"p":[{"n":"builder","p":7536648}],"n":"BuildRenderTree","d":2555913,"h":21477392393,"f":16809988},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":1310721,"f":2},{"n":"validationErrorMessage","p":1310721,"f":2}],"n":"TryParseValueFromString","d":2555913,"h":25772359689,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":2555913,"h":30067326985,"f":16777217}],"i":[2752520,3145736,3080200,57540609],"h":2555913}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.InputBase$$($.$$.System.String); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$$.System.IDisposable ]; }
            static get $fullName() { return `InputText`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$$.System.EventArgs
        {
            /*string?*/ Message = null;
            /*string?*/ Filename = null;
            /*int*/ Lineno = 0;
            /*int*/ Colno = 0;
            /*string?*/ Type = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 5177353;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12890079241,"f":50331649},"s":{"r":0,"d":0,"h":17185046537,"f":83886081},"n":"Message","d":5177353,"h":8595111945,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30069948425,"f":50331649},"s":{"r":0,"d":0,"h":34364915721,"f":83886081},"n":"Filename","d":5177353,"h":25774981129,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47249817609,"f":50331649},"s":{"r":0,"d":0,"h":51544784905,"f":83886081},"n":"Lineno","d":5177353,"h":42954850313,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":64429686793,"f":50331649},"s":{"r":0,"d":0,"h":68724654089,"f":83886081},"n":"Colno","d":5177353,"h":60134719497,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":81609555977,"f":50331649},"s":{"r":0,"d":0,"h":85904523273,"f":83886081},"n":"Type","d":5177353,"h":77314588681,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":5177353,"h":90199490569,"f":16777217}],"h":5177353}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `ErrorEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.FocusEventArgs", ($self) => class FocusEventArgs extends $.$$.System.EventArgs
        {
            /*string?*/ Type = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 5373961;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12890275849,"f":50331649},"s":{"r":0,"d":0,"h":17185243145,"f":83886081},"n":"Type","d":5373961,"h":8595308553,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":5373961,"h":21480210441,"f":16777217}],"h":5373961}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `FocusEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ProgressEventArgs", ($self) => class ProgressEventArgs extends $.$$.System.EventArgs
        {
            /*bool*/ LengthComputable = false;
            /*long*/ Loaded = 0n;
            /*long*/ Total = 0n;
            /*string*/ Type = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.LengthComputable = false;
                this.Type = null;
            }
            static $h = 7077897;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12891979785,"f":50331649},"s":{"r":0,"d":0,"h":17186947081,"f":83886081},"n":"LengthComputable","d":7077897,"h":8597012489,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":30071848969,"f":50331649},"s":{"r":0,"d":0,"h":34366816265,"f":83886081},"n":"Loaded","d":7077897,"h":25776881673,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":47251718153,"f":50331649},"s":{"r":0,"d":0,"h":51546685449,"f":83886081},"n":"Total","d":7077897,"h":42956750857,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":64431587337,"f":50331649},"s":{"r":0,"d":0,"h":68726554633,"f":83886081},"n":"Type","d":7077897,"h":60136620041,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":7077897,"h":73021521929,"f":16777217}],"h":7077897}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `ProgressEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.TouchEventArgs", ($self) => class TouchEventArgs extends $.$$.System.EventArgs
        {
            /*long*/ Detail = 0n;
            /*TouchPoint[]*/ Touches = null;
            /*TouchPoint[]*/ TargetTouches = null;
            /*TouchPoint[]*/ ChangedTouches = null;
            /*bool*/ CtrlKey = false;
            /*bool*/ ShiftKey = false;
            /*bool*/ AltKey = false;
            /*bool*/ MetaKey = false;
            /*string*/ Type = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Touches = $.$$.System.Array.Empty($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint);
                this.TargetTouches = $.$$.System.Array.Empty($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint);
                this.ChangedTouches = $.$$.System.Array.Empty($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint);
                this.CtrlKey = false;
                this.ShiftKey = false;
                this.AltKey = false;
                this.MetaKey = false;
                this.Type = null;
            }
            static $h = 7274505;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12892176393,"f":50331649},"s":{"r":0,"d":0,"h":17187143689,"f":83886081},"n":"Detail","d":7274505,"h":8597209097,"f":2097153},{"p":$.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint).$h,"g":{"r":0,"d":0,"h":30072045577,"f":50331649},"s":{"r":0,"d":0,"h":34367012873,"f":83886081},"n":"Touches","d":7274505,"h":25777078281,"f":2097153},{"p":$.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint).$h,"g":{"r":0,"d":0,"h":47251914761,"f":50331649},"s":{"r":0,"d":0,"h":51546882057,"f":83886081},"n":"TargetTouches","d":7274505,"h":42956947465,"f":2097153},{"p":$.$typeArray($.$macw.Microsoft.AspNetCore.Components.Web.TouchPoint).$h,"g":{"r":0,"d":0,"h":64431783945,"f":50331649},"s":{"r":0,"d":0,"h":68726751241,"f":83886081},"n":"ChangedTouches","d":7274505,"h":60136816649,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81611653129,"f":50331649},"s":{"r":0,"d":0,"h":85906620425,"f":83886081},"n":"CtrlKey","d":7274505,"h":77316685833,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98791522313,"f":50331649},"s":{"r":0,"d":0,"h":103086489609,"f":83886081},"n":"ShiftKey","d":7274505,"h":94496555017,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":115971391497,"f":50331649},"s":{"r":0,"d":0,"h":120266358793,"f":83886081},"n":"AltKey","d":7274505,"h":111676424201,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":133151260681,"f":50331649},"s":{"r":0,"d":0,"h":137446227977,"f":83886081},"n":"MetaKey","d":7274505,"h":128856293385,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":150331129865,"f":50331649},"s":{"r":0,"d":0,"h":154626097161,"f":83886081},"n":"Type","d":7274505,"h":146036162569,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":7274505,"h":158921064457,"f":16777217}],"h":7274505}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `TouchEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.KeyboardEventArgs", ($self) => class KeyboardEventArgs extends $.$$.System.EventArgs
        {
            /*string*/ Key = null;
            /*string*/ Code = null;
            /*float*/ Location = 0;
            /*bool*/ Repeat = false;
            /*bool*/ CtrlKey = false;
            /*bool*/ ShiftKey = false;
            /*bool*/ AltKey = false;
            /*bool*/ MetaKey = false;
            /*string*/ Type = null;
            /*bool*/ IsComposing = false;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Key = null;
                this.Code = null;
                this.Repeat = false;
                this.CtrlKey = false;
                this.ShiftKey = false;
                this.AltKey = false;
                this.MetaKey = false;
                this.Type = null;
                this.IsComposing = false;
            }
            static $h = 6619145;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12891521033,"f":50331649},"s":{"r":0,"d":0,"h":17186488329,"f":83886081},"n":"Key","d":6619145,"h":8596553737,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30071390217,"f":50331649},"s":{"r":0,"d":0,"h":34366357513,"f":83886081},"n":"Code","d":6619145,"h":25776422921,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":47251259401,"f":50331649},"s":{"r":0,"d":0,"h":51546226697,"f":83886081},"n":"Location","d":6619145,"h":42956292105,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64431128585,"f":50331649},"s":{"r":0,"d":0,"h":68726095881,"f":83886081},"n":"Repeat","d":6619145,"h":60136161289,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81610997769,"f":50331649},"s":{"r":0,"d":0,"h":85905965065,"f":83886081},"n":"CtrlKey","d":6619145,"h":77316030473,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98790866953,"f":50331649},"s":{"r":0,"d":0,"h":103085834249,"f":83886081},"n":"ShiftKey","d":6619145,"h":94495899657,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":115970736137,"f":50331649},"s":{"r":0,"d":0,"h":120265703433,"f":83886081},"n":"AltKey","d":6619145,"h":111675768841,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":133150605321,"f":50331649},"s":{"r":0,"d":0,"h":137445572617,"f":83886081},"n":"MetaKey","d":6619145,"h":128855638025,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":150330474505,"f":50331649},"s":{"r":0,"d":0,"h":154625441801,"f":83886081},"n":"Type","d":6619145,"h":146035507209,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":167510343689,"f":50331649},"s":{"r":0,"d":0,"h":171805310985,"f":83886081},"n":"IsComposing","d":6619145,"h":163215376393,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":6619145,"h":176100278281,"f":16777217}],"h":6619145}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `KeyboardEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Forms.InputFileChangeEventArgs", ($self) => class InputFileChangeEventArgs extends $.$$.System.EventArgs
        {
            /*IReadOnlyList<IBrowserFile>*/ _files = null;
            $ctor$2(/*IReadOnlyList<IBrowserFile>*/ files)
            {
                super.$ctor$1();
                {
                    this._files = $.$firstOf(files, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("files") });
                }
                return this;
            }
            /*int */ get FileCount()
            {
                return this._files.System$Collections$Generic$IReadOnlyCollection$$$Count;
            }
            /*IBrowserFile */ get File()
            {
                return (() =>
                {
                    let $switch1 = this._files.System$Collections$Generic$IReadOnlyCollection$$$Count;
                    if ($switch1 === 0)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12("No file was supplied.");
                    }
                    if ($switch1 === 1)
                    {
                        return this._files.System$Collections$Generic$IReadOnlyList$$$get_Item(0, [$.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile]);
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`More than one file was supplied. Call ${"GetMultipleFiles"} to receive multiple files.`);
                })();
            }
            /*IReadOnlyList<IBrowserFile> */ GetMultipleFiles(/*int*/ maximumFileCount)
            {
                if (this._files.System$Collections$Generic$IReadOnlyCollection$$$Count > maximumFileCount)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`The maximum number of files accepted is ${maximumFileCount}, but ${this._files.System$Collections$Generic$IReadOnlyCollection$$$Count} were supplied.`);
                }
                return this._files;
            }
            static $h = 1966089;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181835273,"f":50331649},"n":"FileCount","d":1966089,"h":12886867977,"f":2097153},{"p":1441801,"g":{"r":0,"d":0,"h":25771769865,"f":50331649},"n":"File","d":1966089,"h":21476802569,"f":2097153}],"m":[{"r":$.$$.System.Collections.Generic.IReadOnlyList$$($.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile).$h,"p":[{"n":"maximumFileCount","p":655361,"f":65,"v":10}],"n":"GetMultipleFiles","d":1966089,"h":30066737161,"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.IReadOnlyList$$($.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile).$h,"n":"_files","d":1966089,"h":4296933385,"f":4194306}],"c":[{"p":[{"n":"files","p":$.$$.System.Collections.Generic.IReadOnlyList$$($.$macw.Microsoft.AspNetCore.Components.Forms.IBrowserFile).$h}],"n":".ctor","o":"$ctor$2","d":1966089,"h":8591900681,"f":16777217}],"h":1966089}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `InputFileChangeEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs", ($self) => class MouseEventArgs extends $.$$.System.EventArgs
        {
            /*long*/ Detail = 0n;
            /*double*/ ScreenX = 0;
            /*double*/ ScreenY = 0;
            /*double*/ ClientX = 0;
            /*double*/ ClientY = 0;
            /*double*/ OffsetX = 0;
            /*double*/ OffsetY = 0;
            /*double*/ PageX = 0;
            /*double*/ PageY = 0;
            /*double*/ MovementX = 0;
            /*double*/ MovementY = 0;
            /*long*/ Button = 0n;
            /*long*/ Buttons = 0n;
            /*bool*/ CtrlKey = false;
            /*bool*/ ShiftKey = false;
            /*bool*/ AltKey = false;
            /*bool*/ MetaKey = false;
            /*string*/ Type = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.CtrlKey = false;
                this.ShiftKey = false;
                this.AltKey = false;
                this.MetaKey = false;
                this.Type = null;
            }
            static $h = 6750217;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12891652105,"f":50331649},"s":{"r":0,"d":0,"h":17186619401,"f":83886081},"n":"Detail","d":6750217,"h":8596684809,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":30071521289,"f":50331649},"s":{"r":0,"d":0,"h":34366488585,"f":83886081},"n":"ScreenX","d":6750217,"h":25776553993,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":47251390473,"f":50331649},"s":{"r":0,"d":0,"h":51546357769,"f":83886081},"n":"ScreenY","d":6750217,"h":42956423177,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":64431259657,"f":50331649},"s":{"r":0,"d":0,"h":68726226953,"f":83886081},"n":"ClientX","d":6750217,"h":60136292361,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":81611128841,"f":50331649},"s":{"r":0,"d":0,"h":85906096137,"f":83886081},"n":"ClientY","d":6750217,"h":77316161545,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":98790998025,"f":50331649},"s":{"r":0,"d":0,"h":103085965321,"f":83886081},"n":"OffsetX","d":6750217,"h":94496030729,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":115970867209,"f":50331649},"s":{"r":0,"d":0,"h":120265834505,"f":83886081},"n":"OffsetY","d":6750217,"h":111675899913,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":133150736393,"f":50331649},"s":{"r":0,"d":0,"h":137445703689,"f":83886081},"n":"PageX","d":6750217,"h":128855769097,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":150330605577,"f":50331649},"s":{"r":0,"d":0,"h":154625572873,"f":83886081},"n":"PageY","d":6750217,"h":146035638281,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":167510474761,"f":50331649},"s":{"r":0,"d":0,"h":171805442057,"f":83886081},"n":"MovementX","d":6750217,"h":163215507465,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":184690343945,"f":50331649},"s":{"r":0,"d":0,"h":188985311241,"f":83886081},"n":"MovementY","d":6750217,"h":180395376649,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":201870213129,"f":50331649},"s":{"r":0,"d":0,"h":206165180425,"f":83886081},"n":"Button","d":6750217,"h":197575245833,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":219050082313,"f":50331649},"s":{"r":0,"d":0,"h":223345049609,"f":83886081},"n":"Buttons","d":6750217,"h":214755115017,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":236229951497,"f":50331649},"s":{"r":0,"d":0,"h":240524918793,"f":83886081},"n":"CtrlKey","d":6750217,"h":231934984201,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":253409820681,"f":50331649},"s":{"r":0,"d":0,"h":257704787977,"f":83886081},"n":"ShiftKey","d":6750217,"h":249114853385,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":270589689865,"f":50331649},"s":{"r":0,"d":0,"h":274884657161,"f":83886081},"n":"AltKey","d":6750217,"h":266294722569,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":287769559049,"f":50331649},"s":{"r":0,"d":0,"h":292064526345,"f":83886081},"n":"MetaKey","d":6750217,"h":283474591753,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":304949428233,"f":50331649},"s":{"r":0,"d":0,"h":309244395529,"f":83886081},"n":"Type","d":6750217,"h":300654460937,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":6750217,"h":313539362825,"f":16777217}],"h":6750217}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `MouseEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.ClipboardEventArgs", ($self) => class ClipboardEventArgs extends $.$$.System.EventArgs
        {
            /*string*/ Type = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Type = null;
            }
            static $h = 4718601;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12889620489,"f":50331649},"s":{"r":0,"d":0,"h":17184587785,"f":83886081},"n":"Type","d":4718601,"h":8594653193,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":4718601,"h":21479555081,"f":16777217}],"h":4718601}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `ClipboardEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.DragEventArgs", ($self) => class DragEventArgs extends $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs
        {
            /*DataTransfer*/ DataTransfer = null;
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.DataTransfer = null;
            }
            static $h = 4980745;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6750217,"p":[{"p":4849673,"g":{"r":0,"d":0,"h":12889882633,"f":50331649},"s":{"r":0,"d":0,"h":17184849929,"f":83886081},"n":"DataTransfer","d":4980745,"h":8594915337,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$3","d":4980745,"h":21479817225,"f":16777217}],"h":4980745}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs; }
            static get $fullName() { return `DragEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.WheelEventArgs", ($self) => class WheelEventArgs extends $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs
        {
            /*double*/ DeltaX = 0;
            /*double*/ DeltaY = 0;
            /*double*/ DeltaZ = 0;
            /*long*/ DeltaMode = 0n;
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8192009;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6750217,"p":[{"p":1179649,"g":{"r":0,"d":0,"h":12893093897,"f":50331649},"s":{"r":0,"d":0,"h":17188061193,"f":83886081},"n":"DeltaX","d":8192009,"h":8598126601,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":30072963081,"f":50331649},"s":{"r":0,"d":0,"h":34367930377,"f":83886081},"n":"DeltaY","d":8192009,"h":25777995785,"f":2097153},{"p":1179649,"g":{"r":0,"d":0,"h":47252832265,"f":50331649},"s":{"r":0,"d":0,"h":51547799561,"f":83886081},"n":"DeltaZ","d":8192009,"h":42957864969,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":64432701449,"f":50331649},"s":{"r":0,"d":0,"h":68727668745,"f":83886081},"n":"DeltaMode","d":8192009,"h":60137734153,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$3","d":8192009,"h":73022636041,"f":16777217}],"h":8192009}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs; }
            static get $fullName() { return `WheelEventArgs`; }
        });
        
        $asm.$cls("$macw.Microsoft.AspNetCore.Components.Web.PointerEventArgs", ($self) => class PointerEventArgs extends $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs
        {
            /*long*/ PointerId = 0n;
            /*float*/ Width = 0;
            /*float*/ Height = 0;
            /*float*/ Pressure = 0;
            /*float*/ TiltX = 0;
            /*float*/ TiltY = 0;
            /*string*/ PointerType = null;
            /*bool*/ IsPrimary = false;
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PointerType = null;
                this.IsPrimary = false;
            }
            static $h = 6946825;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6750217,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12891848713,"f":50331649},"s":{"r":0,"d":0,"h":17186816009,"f":83886081},"n":"PointerId","d":6946825,"h":8596881417,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":30071717897,"f":50331649},"s":{"r":0,"d":0,"h":34366685193,"f":83886081},"n":"Width","d":6946825,"h":25776750601,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":47251587081,"f":50331649},"s":{"r":0,"d":0,"h":51546554377,"f":83886081},"n":"Height","d":6946825,"h":42956619785,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":64431456265,"f":50331649},"s":{"r":0,"d":0,"h":68726423561,"f":83886081},"n":"Pressure","d":6946825,"h":60136488969,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":81611325449,"f":50331649},"s":{"r":0,"d":0,"h":85906292745,"f":83886081},"n":"TiltX","d":6946825,"h":77316358153,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":98791194633,"f":50331649},"s":{"r":0,"d":0,"h":103086161929,"f":83886081},"n":"TiltY","d":6946825,"h":94496227337,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":115971063817,"f":50331649},"s":{"r":0,"d":0,"h":120266031113,"f":83886081},"n":"PointerType","d":6946825,"h":111676096521,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":133150933001,"f":50331649},"s":{"r":0,"d":0,"h":137445900297,"f":83886081},"n":"IsPrimary","d":6946825,"h":128855965705,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$3","d":6946825,"h":141740867593,"f":16777217}],"h":6946825}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs; }
            static get $fullName() { return `PointerEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop"))